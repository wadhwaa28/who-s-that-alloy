/* =============== THE MAP IS DRAWN IN PIECES ===============
   Every tile is still built from the same full-detail art, but a tile's drawing is only put into the page when the camera gets near it,
   in 5 x 5 chunks. Chunks the camera has moved well away from are hidden (no painting, no animation) until it comes back. */
const CH={b:0,inner:[],W:0,H:0,N:5,win:null,live:new Set,tm:null};
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const r=_tl(c,x,y,seed,M);if(!CH.b)return r;CH.W=M[0].length;CH.H=M.length;CH.inner[y*CH.W+x]=r[1]||"";return[(r[0]||"")+" cull",""]}}
{const _se=startExplore;startExplore=function(){CH.b++;if(CH.b===1){CH.inner=[];CH.live=new Set;CH.win=null}try{_se()}finally{CH.b--}if(!CH.b)chunkSync(true)}}
function chunkView(){const w=$("#world");if(!w||!EXP.W)return null;const m=(w.style.transform||"").match(/translate\((-?[\d.]+)%\s*,\s*(-?[\d.]+)%\)/),cx=m?-parseFloat(m[1])/100*EXP.W:0,cy=m?-parseFloat(m[2])/100*EXP.H:0;
  return[cx,cy,cx+VIEW.w,cy+VIEW.h]}
function chunkTiles(){const m=$("#map");return m&&CH.W===EXP.W&&CH.H===EXP.H&&m.children.length===CH.W*CH.H?m.children:null}
function chunkFill(T,x0,y0,x1,y1){const N=CH.N;for(let gy=Math.max(0,Math.floor(y0/N));gy<=Math.min(Math.ceil(CH.H/N)-1,Math.floor(y1/N));gy++)for(let gx=Math.max(0,Math.floor(x0/N));gx<=Math.min(Math.ceil(CH.W/N)-1,Math.floor(x1/N));gx++){const k=gx+","+gy;if(CH.live.has(k))continue;CH.live.add(k);
    for(let y=gy*N;y<Math.min(CH.H,gy*N+N);y++)for(let x=gx*N;x<Math.min(CH.W,gx*N+N);x++){const i=y*CH.W+x,el=T[i];if(!el)continue;if(!el.dataset.f){el.dataset.f=1;const h=CH.inner[i];if(h)el.insertAdjacentHTML("afterbegin",h)}el.classList.remove("cull")}}}
function chunkCull(T,x0,y0,x1,y1){const N=CH.N;for(const k of[...CH.live]){const[gx,gy]=k.split(",").map(Number);if(gx*N+N-1>=x0&&gx*N<=x1&&gy*N+N-1>=y0&&gy*N<=y1)continue;CH.live.delete(k);
    for(let y=gy*N;y<Math.min(CH.H,gy*N+N);y++)for(let x=gx*N;x<Math.min(CH.W,gx*N+N);x++){const el=T[y*CH.W+x];if(el)el.classList.add("cull")}}}
function chunkSync(){const T=chunkTiles(),v=chunkView();if(!T||!v)return;const p=CH.win||v,M=2;
  /* everything between where the camera was and where it is going gets drawn, so a long cutscene pan never shows a hole */
  chunkFill(T,Math.min(p[0],v[0])-M,Math.min(p[1],v[1])-M,Math.max(p[2],v[2])+M,Math.max(p[3],v[3])+M);CH.win=v;
  clearTimeout(CH.tm);CH.tm=setTimeout(()=>{const T2=chunkTiles(),v2=chunkView();if(T2&&v2)chunkCull(T2,v2[0]-6,v2[1]-6,v2[2]+6,v2[3]+6)},1200)}
{const _c=cam;cam=function(instant){_c(instant);if(!CH.b)chunkSync()}}
{const _cs=camSetup;camSetup=function(){_cs();if(!CH.b)chunkSync()}}
/* a crate or boulder that gets opened must stay opened when its chunk is drawn again */
{const _mo=markOpened;markOpened=function(x,y){_mo(x,y);if(CH.W===EXP.W){const i=y*CH.W+x;CH.inner[i]="";const T=chunkTiles();if(T&&T[i])T[i].dataset.f=1}}}
/* ---- only what the camera can actually see is animated ----
   Rubble sparkles, water ripples and screen flickers keep running on screen exactly as before; just off the edge of the view they are
   paused (not removed), and pick up again the moment they scroll back in. Hundreds of off-screen SVG animations were the main source of lag. */
CH.anim=null;
function animSync(){const T=chunkTiles(),v=chunkView();if(!T||!v)return;const x0=Math.floor(v[0])-1,y0=Math.floor(v[1])-1,x1=Math.ceil(v[2])+1,y1=Math.ceil(v[3])+1;
  if(!CH.anim||CH.anim.length!==T.length)CH.anim=new Uint8Array(T.length);
  for(let i=0;i<T.length;i++){const x=i%CH.W,y=(i/CH.W)|0,on=x>=x0&&x<=x1&&y>=y0&&y<=y1?1:2;if(CH.anim[i]===on)continue;CH.anim[i]=on;const el=T[i];
    el.classList.toggle("still",on===2);if(el.dataset.f&&el._smil!==0){if(el._smil===undefined)el._smil=el.querySelector("animate,animateTransform,animateMotion")?1:0;if(el._smil)el.querySelectorAll("svg").forEach(s=>on===1?s.unpauseAnimations&&s.unpauseAnimations():s.pauseAnimations&&s.pauseAnimations())}}}
{const _cs=chunkSync;chunkSync=function(){_cs();CH.anim=null;animSync()}}
{const _cf=chunkFill;chunkFill=function(T,a,b,c,d){_cf(T,a,b,c,d);if(CH.anim)CH.anim.fill(0)}}
/* ---- sparkles and glows, made cheap ----
   The rubble's twinkling stars and pulsing glows were SVG animations, which the browser has to redraw on the main thread every single frame.
   The same stars (same shape, colour, size, spot, timing) are now drawn as tiny HTML pieces the graphics card animates by itself,
   and the pulsing glows are lifted onto their own layer whose fade the graphics card handles. Nothing looks different. */
const STAR_A="polygon(50% 0,59.8% 40.2%,100% 50%,59.8% 59.8%,50% 100%,40.2% 59.8%,0 50%,40.2% 40.2%)",STAR_B="polygon(50% 0,62.5% 37.5%,100% 50%,62.5% 62.5%,50% 100%,37.5% 62.5%,0 50%,37.5% 37.5%)";
function twinkleHTML(h,tx,ty){if(!h||h.indexOf('class="tw"')<0)return h;
  const star=(cx,cy,r,col,del,dur,inner)=>CH.sparks.push({x:tx+cx/40,y:ty+cy/40,r:r/40,col,del:+del,dur:+(dur||2.4),inner});
  h=h.replace(/<g transform="translate\(([\d.-]+) ([\d.-]+)\)"><path class="tw" d="M0 -2\.8 [^"]*" fill="([^"]+)" style="animation-delay:([\d.]+)s;animation-duration:([\d.]+)s"\/><\/g>/g,(m,x,y,c,d,u)=>{star(+x,+y,2.8,c,d,u,.196);return""});
  h=h.replace(/<path class="tw" d="M([\d.-]+) ([\d.-]+) l1 -3 l1 3 l3 1 l-3 1 l-1 3 l-1 -3 l-3 -1 z" fill="([^"]+)" style="animation-delay:([\d.]+)s"\/>/g,(m,x,y,c,d)=>{star(+x+1,+y+1,4,c,d,0,.25);return""});
  return h}
/* every sparkle on the map is drawn on ONE small canvas that only covers the camera view, instead of hundreds of separately animated pieces */
CH.sparks=[];
const SPK={cv:null,ctx:null,ox:0,oy:0,w:0,h:0,tp:0,last:0,run:false};
function spkEase(t){/* CSS ease-in-out, cubic-bezier(.42,0,.58,1) */let lo=0,hi=1,u=t;for(let i=0;i<14;i++){u=(lo+hi)/2;const x=3*.42*u*(1-u)*(1-u)+3*.58*u*u*(1-u)+u*u*u;if(x<t)lo=u;else hi=u}return 3*u*u*(1-u)+u*u*u}
function spkPlace(){const w=$("#world"),v=chunkView();if(!w||!v||!EXP.W)return;if(!SPK.cv||!SPK.cv.isConnected){SPK.cv=document.createElement("canvas");SPK.cv.id="sparks";w.insertBefore(SPK.cv,$("#player"));SPK.ctx=SPK.cv.getContext("2d",window.__SWC?{willReadFrequently:true}:undefined)}
  const tp=w.offsetWidth/EXP.W;if(!tp)return;const p=SPK.prev||v,M=1;
  const x0=Math.max(0,Math.floor(Math.min(p[0],v[0]))-M),y0=Math.max(0,Math.floor(Math.min(p[1],v[1]))-M),x1=Math.min(EXP.W,Math.ceil(Math.max(p[2],v[2]))+M),y1=Math.min(EXP.H,Math.ceil(Math.max(p[3],v[3]))+M);SPK.prev=v;
  const dpr=Math.min(2,window.devicePixelRatio||1),cw=Math.max(1,Math.round((x1-x0)*tp*dpr)),chh=Math.max(1,Math.round((y1-y0)*tp*dpr));
  if(SPK.cv.width!==cw)SPK.cv.width=cw;if(SPK.cv.height!==chh)SPK.cv.height=chh;Object.assign(SPK,{ox:x0,oy:y0,w:x1-x0,h:y1-y0,tp:tp*dpr});
  const st=SPK.cv.style;st.left=(x0/EXP.W*100)+"%";st.top=(y0/EXP.H*100)+"%";st.width=((x1-x0)/EXP.W*100)+"%";st.height=((y1-y0)/EXP.H*100)+"%";
  clearTimeout(SPK.tm);SPK.tm=setTimeout(()=>{SPK.prev=null;if(EXP.W)spkPlace()},1100);
  if(S.phase==="explore"&&(CH.sparks.length||WT.tiles.length))spkRender(performance.now());
  if(!SPK.run){SPK.run=true;requestAnimationFrame(spkDraw)}}
function spkDraw(now){if(S.phase!=="explore"||!SPK.cv||!SPK.cv.isConnected||(!CH.sparks.length&&!WT.tiles.length)){SPK.run=false;if(SPK.ctx&&SPK.cv)SPK.ctx.clearRect(0,0,SPK.cv.width,SPK.cv.height);return}
  requestAnimationFrame(spkDraw);if(document.hidden||now-SPK.last<30)return;spkRender(now)}
/* draws one frame; also called straight away whenever the canvas is moved or resized, so the water never sits a step behind the map */
function spkRender(now){if(!SPK.cv||!SPK.ctx)return;SPK.last=now;
  const c=SPK.ctx,T=SPK.tp,t=now/1000,reduce=window.matchMedia&&matchMedia("(prefers-reduced-motion:reduce)").matches;if(SPK.full!==SPK.cv.width+'x'+SPK.cv.height+','+SPK.ox+','+SPK.oy){SPK.full=SPK.cv.width+'x'+SPK.cv.height+','+SPK.ox+','+SPK.oy;c.clearRect(0,0,SPK.cv.width,SPK.cv.height);SPK.dirty=[]}else{for(const d of SPK.dirty||[])c.clearRect(d[0],d[1],d[2],d[3])}SPK.dirty=[];waterDraw(c,T,t,reduce);if(reduce)return;
  for(const s of CH.sparks){if(s.x<SPK.ox-.2||s.y<SPK.oy-.2||s.x>SPK.ox+SPK.w+.2||s.y>SPK.oy+SPK.h+.2)continue;
    let f=((t+(s.dur-s.del%s.dur))%s.dur)/s.dur;const k=spkEase(f<.5?f*2:2-f*2);if(k<.01)continue;
    const sc=.2+.8*k,R=s.r*T*sc,ri=R*s.inner,a=k*Math.PI/4,cx=(s.x-SPK.ox)*T,cy=(s.y-SPK.oy)*T;
    SPK.dirty.push([Math.floor(cx-R-2),Math.floor(cy-R-2),Math.ceil(2*R+4),Math.ceil(2*R+4)]);c.globalAlpha=k;c.fillStyle=s.col;c.beginPath();for(let i=0;i<8;i++){const ang=a+i*Math.PI/4-Math.PI/2,rr=i%2?ri*Math.SQRT2:R;c.lineTo(cx+Math.cos(ang)*rr,cy+Math.sin(ang)*rr)}c.closePath();c.fill()}
  c.globalAlpha=1}
{const _se=startExplore;startExplore=function(){CH.sparks=[];SPK.prev=null;_se();if(SPK.cv&&!SPK.cv.isConnected)SPK.cv=null;spkPlace()}}
{const _c=cam;cam=function(instant){_c(instant);if(!CH.b&&EXP.W)spkPlace()}}
function glowLift(el){el.querySelectorAll(":scope > svg").forEach(svg=>{const gl=[...svg.querySelectorAll(".glow")].filter(g=>!g.hasAttribute("opacity"));
  svg.querySelectorAll(".glow[opacity]").forEach(g=>g.classList.remove("glow"));if(!gl.length)return;
  const ov=svg.cloneNode(true);ov.classList.add("glowsvg");const keep=new Set();ov.querySelectorAll(".glow").forEach(g=>{if(g.hasAttribute("opacity"))return;let n=g;while(n&&n!==ov){keep.add(n);n=n.parentNode}});
  [...ov.querySelectorAll("*")].reverse().forEach(n=>{if(!keep.has(n)&&n.tagName!=="defs"&&!n.closest("defs"))n.remove()});ov.querySelectorAll(".glow").forEach(g=>g.classList.remove("glow"));
  gl.forEach(g=>g.remove());svg.after(ov)})}
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const r=_tl(c,x,y,seed,M);if(CH.b&&CH.W){const i=y*CH.W+x;if(CH.inner[i])CH.inner[i]=twinkleHTML(CH.inner[i],x,y)}return r}}
{const _cf=chunkFill;chunkFill=function(T,x0,y0,x1,y1){const before=new Set();for(let i=0;i<T.length;i++)if(T[i].dataset.f)before.add(i);_cf(T,x0,y0,x1,y1);
  for(let i=0;i<T.length;i++)if(T[i].dataset.f&&!before.has(i)&&T[i].querySelector(".glow"))glowLift(T[i])}}

/* ---- water, the same way ----
   Every rippling water tile used to carry its own animated overlay. The browser now paints each kind of ripple ONCE into a picture
   (using exactly the same CSS gradients), and the shared canvas slides that picture across every visible water tile at the same speed. */
const WT={pats:{},tiles:[],gen:0};
function waterScan(){const gen=++WT.gen;WT.tiles=[];const m=$("#map");if(!m||!EXP.W)return;const T=m.children,tp=$("#world").offsetWidth/EXP.W;if(!tp)return;
  const keys={};for(let i=0;i<T.length;i++){const t=T[i];if(!/\b(lq|sh|sl-pond)\b/.test(t.className))continue;const cs=getComputedStyle(t,"::after");if(cs.animationName!=="lqmove"||cs.filter!=="none"||cs.mixBlendMode!=="normal"||cs.backgroundImage==="none")continue;
    const ins=cs.top.endsWith("%")?parseFloat(cs.top)/100*tp:parseFloat(cs.top),dur=parseFloat(cs.animationDuration)||4,k=cs.backgroundImage+"|"+cs.backgroundColor+"|"+cs.backgroundSize+"|"+cs.backgroundPosition+"|"+dur+"|"+cs.opacity+"|"+(ins/tp).toFixed(3);
    if(!keys[k])keys[k]={k,img:cs.backgroundImage,col:cs.backgroundColor,size:cs.backgroundSize,pos:cs.backgroundPosition,rep:cs.backgroundRepeat,dur,op:+cs.opacity,ins:ins/tp,ov:getComputedStyle(t).overflow==="hidden"};
    WT.tiles.push({i,x:i%EXP.W,y:(i/EXP.W)|0,k,el:t})}
  Object.values(keys).forEach(K=>{if(WT.pats[K.k]){if(WT.pats[K.k].ready)waterOn(K.k);return}const P=WT.pats[K.k]={...K,ready:false};
    const box=(1-2*K.ins)*tp,dpr=Math.min(2,window.devicePixelRatio||1),px=Math.ceil(box*dpr);P.boxT=1-2*K.ins;
    const div=`<div xmlns="http://www.w3.org/1999/xhtml" style="width:${box}px;height:${box}px;transform:scale(${dpr});transform-origin:0 0;background-image:${K.img};background-color:${K.col};background-size:${K.size};background-position:${K.pos};background-repeat:${K.rep}"></div>`;
    const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${px}" height="${px}"><foreignObject width="100%" height="100%">${div}</foreignObject></svg>`;
    const im=new Image();im.onload=()=>{P.img=im;P.ready=true;if(gen===WT.gen)waterOn(K.k)};im.onerror=()=>{P.failed=true};im.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg)})}
function waterOn(k){WT.tiles.forEach(w=>{if(w.k===k)w.el.classList.add("wcv")});if(!SPK.run&&SPK.cv){SPK.run=true;requestAnimationFrame(spkDraw)}}
function waterDraw(c,T,t,reduce){if(!WT.tiles.length)return;const ts=Math.max(1,Math.round(T)),spr={};
  /* each kind of water is painted into ONE tile-sized picture per frame, then stamped onto every visible tile of that kind */
  for(const w of WT.tiles){if(w.x<SPK.ox-1||w.y<SPK.oy-1||w.x>SPK.ox+SPK.w||w.y>SPK.oy+SPK.h)continue;const P=WT.pats[w.k];if(!P||!P.ready)continue;
    let sp=spr[w.k];if(!sp){if(!P.cv){P.cv=document.createElement("canvas")}if(P.cv.width!==ts){P.cv.width=ts;P.cv.height=ts}const x=P.cv.getContext("2d"),f=reduce?0:(t%P.dur)/P.dur;
      x.clearRect(0,0,ts,ts);x.globalAlpha=P.op;x.drawImage(P.img,(P.ins+P.boxT*.25*f)*ts,(P.ins+P.boxT*.12*f)*ts,P.boxT*ts,P.boxT*ts);sp=spr[w.k]=P.cv}
    const px=Math.round((w.x-SPK.ox)*T),py=Math.round((w.y-SPK.oy)*T),pw=Math.ceil(T)+1;SPK.dirty.push([px,py,pw,pw]);c.clearRect(px,py,pw,pw);c.drawImage(sp,px,py,Math.ceil(T),Math.ceil(T))}}
{const _se=startExplore;startExplore=function(){WT.tiles=[];_se();setTimeout(()=>{if(S.phase==="explore")waterScan()},60)}}
addEventListener("resize",()=>{WT.pats={};if(S.phase==="explore"){document.querySelectorAll("#map .tile.wcv").forEach(t=>t.classList.remove("wcv"));waterScan()}});

/* =============== BAKED FLOORS ===============
   The ground, walls and rubble of each 5 x 5 chunk are drawn once, at full screen resolution, into a single picture, using the browser's own
   renderer so every gradient, outline and sparkle-free detail comes out pixel-identical. That picture replaces hundreds of separate pieces
   the browser otherwise has to re-layer and repaint every time anything moves. Furniture, people, anything animated, and anything that can
   change stays live exactly as before. */
const BK={on:true,gen:0,imgs:[],q:[],busy:false};
const BK_HTML=["position","left","top","right","bottom","width","height","display","visibility","opacity","overflow","background-color","background-image","background-size","background-position","background-repeat","background-clip","border-top-left-radius","border-top-right-radius","border-bottom-left-radius","border-bottom-right-radius","border-top","border-right","border-bottom","border-left","box-shadow","transform","transform-origin","filter","clip-path","mix-blend-mode","z-index","margin-top","margin-left","box-sizing"];
const BK_SVG=["display","visibility","opacity","fill","stroke","stroke-width","font-family","font-size","font-weight","text-anchor"];
function bkStyle(el,props,extra){const cs=getComputedStyle(el,extra||null);return props.map(p=>{const v=cs.getPropertyValue(p);return v?`${p}:${v}`:""}).filter(Boolean).join(";")}
function bkEsc(s){return s.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}
function bkPseudo(el,ps){const cs=getComputedStyle(el,ps);if(cs.content==="none"||cs.display==="none"||cs.visibility==="hidden")return"";
  return `<div style="${bkEsc(bkStyle(el,BK_HTML,ps))}"></div>`}
/* SVG shapes only carry the styles a stylesheet actually changed: the rest is already in their attributes, which keeps each picture small */
const BK_SVG_DEF={display:"inline",visibility:"visible",opacity:"1"};
function bkSvgStyle(el,tag){const cs=getComputedStyle(el),cls=el.hasAttribute("class"),out=[];
  for(const p of BK_SVG){if(/^font|text-anchor/.test(p)&&tag!=="text"&&tag!=="tspan")continue;const v=cs.getPropertyValue(p);if(!v)continue;
    if(BK_SVG_DEF[p]===v)continue;if(!cls&&el.hasAttribute(p))continue;if((p==="stroke"&&v==="none"&&!el.hasAttribute("stroke"))||(p==="stroke-width"&&v==="1px"&&!el.hasAttribute("stroke-width"))||(p==="fill"&&v==="rgb(0, 0, 0)"&&!el.hasAttribute("fill")))continue;
    out.push(p+":"+v)}
  return out.join(";")}
/* a static copy of one element and everything inside it, with every style written inline */
function bkClone(el,svgMode,root){const tag=el.tagName.toLowerCase();if(tag==="script")return"";
  const isSvg=svgMode||tag==="svg";let attrs="";
  for(const a of el.attributes){if(a.name==="style"||a.name==="class"||a.name==="id"||a.name.startsWith("data-"))continue;attrs+=` ${a.name}="${bkEsc(a.value)}"`}
  let st=isSvg&&tag!=="svg"?bkSvgStyle(el,tag):bkStyle(el,BK_HTML);if(root)st+=";position:absolute;left:0;top:0;right:auto;bottom:auto;width:100%;height:100%;margin:0;z-index:auto;visibility:visible";
  let inner="";for(const c of el.childNodes){if(c.nodeType===3)inner+=bkEsc(c.textContent);else if(c.nodeType===1)inner+=bkClone(c,isSvg)}
  if(isSvg)return `<${tag}${tag==="svg"?' xmlns="http://www.w3.org/2000/svg"':""}${attrs} style="${bkEsc(st)}">${inner}</${tag}>`;
  return `<${tag==="span"||tag==="i"||tag==="b"?tag:"div"} style="${bkEsc(st)}">${bkPseudo(el,"::before")}${inner}${bkPseudo(el,"::after")}</${tag==="span"||tag==="i"||tag==="b"?tag:"div"}>`}
/* just the floor under a piece of furniture: the tile's own background, none of what stands on it */
function bkFloorClone(el){const pz=el.classList.contains("oakp")?bkPseudo(el,"::before")+bkPseudo(el,"::after"):"";return `<div style="${bkEsc(bkStyle(el,BK_HTML))};position:absolute;left:0;top:0;right:auto;bottom:auto;width:100%;height:100%;margin:0;z-index:auto;visibility:visible;opacity:1">${pz}</div>`}
function bkFloorOk(t){if(!(t.classList.contains("pr")||t.classList.contains("tl")))return false;if(t.getAnimations().some(a=>a.playState!=="idle"))return false;
  const cs=getComputedStyle(t);return cs.backgroundImage!=="none"||cs.backgroundColor!=="rgba(0, 0, 0, 0)"}
/* which tiles can be frozen into the picture */
function bkOk(t){if(t.classList.contains("pr")||t.classList.contains("tl")||t.classList.contains("rustle"))return false;
  if(t.getAnimations({subtree:true}).some(a=>a.playState!=="idle"))return false;
  const a=getComputedStyle(t,"::after"),b=getComputedStyle(t,"::before");if((a.animationName!=="none"&&a.display!=="none")||(b.animationName!=="none"&&b.display!=="none"))return false;
  if(t.querySelector("animate,animateTransform,animateMotion,.glowsvg,canvas,img"))return false;return true}
function bkChunk(gx,gy){const T=chunkTiles();if(!T||!BK.on)return;const N=CH.N,gen=BK.gen,m=$("#map");if(!m)return;
  /* whole tiles go into the picture; furniture tiles give it just their bit of floor, so the floor pattern runs on unbroken underneath them */
  const tiles=[],floors=new Set();for(let y=gy*N;y<Math.min(CH.H,gy*N+N);y++)for(let x=gx*N;x<Math.min(CH.W,gx*N+N);x++){const el=T[y*CH.W+x];if(!el||!el.dataset.f)continue;
    /* a see-through tile over a material sheet with nothing on it needs no picture at all */
    if(!el.dataset.bk&&el.classList.contains("mtx")&&!el.childElementCount&&getComputedStyle(el,"::before").content==="none"&&getComputedStyle(el,"::after").content==="none"&&!el.getAnimations().length&&getComputedStyle(el).boxShadow==="none"){el.dataset.bk=1;el.classList.add("baked");continue}
    if(!el.dataset.bk&&bkOk(el))tiles.push(el);else if(!el.dataset.bkf&&bkFloorOk(el)){tiles.push(el);floors.add(el)}}
  if(tiles.length<3)return;
  const tp=m.offsetWidth/EXP.W;if(!tp)return;const mr=m.getBoundingClientRect(),R=new Map(tiles.map(t=>{const r=t.getBoundingClientRect();return[t,{l:r.left-mr.left,t:r.top-mr.top,w:r.width,h:r.height}]})),pad=Math.ceil(tp*.5),
    x0=Math.floor(Math.min(...tiles.map(t=>R.get(t).l)))-pad,y0=Math.floor(Math.min(...tiles.map(t=>R.get(t).t)))-pad,x1=Math.ceil(Math.max(...tiles.map(t=>R.get(t).l+R.get(t).w)))+pad,y1=Math.ceil(Math.max(...tiles.map(t=>R.get(t).t+R.get(t).h)))+pad,w=x1-x0,h=y1-y0,dpr=Math.min(2,window.devicePixelRatio||1);
  /* hide the live tiles' visuals while cloning them is not needed: computed styles are read straight off the page */
  let body="";for(const t of tiles){const c=floors.has(t)?bkFloorClone(t):bkClone(t,false,true);const q=R.get(t);body+=`<div style="position:absolute;left:${q.l-x0}px;top:${q.t-y0}px;width:${q.w}px;height:${q.h}px">${c}</div>`}
  const mapCs=getComputedStyle(m);
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${Math.ceil(w*dpr)}" height="${Math.ceil(h*dpr)}"><foreignObject width="100%" height="100%"><div xmlns="http://www.w3.org/1999/xhtml" style="position:relative;width:${w}px;height:${h}px;transform:scale(${dpr});transform-origin:0 0;font-family:${bkEsc(mapCs.fontFamily)}">${body}</div></foreignObject></svg>`;
  const im=new Image();im.decoding="async";im.className="bake";im.alt="";im.dataset.k=gx+","+gy;
  im.onload=()=>{if(gen!==BK.gen||!m.isConnected){return}const W=mr.width,H=mr.height;im.style.cssText=`position:absolute;left:${x0/W*100}%;top:${y0/H*100}%;width:${w/W*100}%;height:${h/H*100}%;pointer-events:none`;
    m.parentNode.insertBefore(im,m);BK.imgs.push(im);tiles.forEach(t=>{if(floors.has(t)){t.dataset.bkf=1;t.classList.add("bkf")}else{t.dataset.bk=1;t.classList.add("baked")}})};
  im.onerror=()=>{};im.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg)}
function bkPump(){if(BK.busy)return;BK.busy=true;const go=()=>{const j=BK.q.shift();if(!j){BK.busy=false;return}if(j.gen===BK.gen&&S.phase==="explore")bkChunk(j.gx,j.gy);(window.requestIdleCallback||setTimeout)(go,{timeout:120})};go()}
function bkQueue(keys){keys.forEach(k=>{const[gx,gy]=k.split(",").map(Number);BK.q.push({gx,gy,gen:BK.gen})});bkPump()}
function bkReset(){BK.gen++;BK.q=[];BK.imgs.forEach(i=>i.remove());BK.imgs=[];document.querySelectorAll("#map .tile.baked,#map .tile.bkf").forEach(t=>{t.classList.remove("baked","bkf");delete t.dataset.bk;delete t.dataset.bkf})}
{const _cf=chunkFill;chunkFill=function(T,x0,y0,x1,y1){const before=new Set(CH.live);_cf(T,x0,y0,x1,y1);const fresh=[...CH.live].filter(k=>!before.has(k));if(fresh.length)setTimeout(()=>bkQueue(fresh),400)}}
{const _se=startExplore;startExplore=function(){bkReset();_se()}}
addEventListener("resize",()=>{if(S.phase!=="explore")return;bkReset();setTimeout(()=>bkQueue([...CH.live]),500)});
{const _mo=markOpened;markOpened=function(x,y){_mo(x,y);/* a tile that changed: rebake its chunk */const N=CH.N;const k=Math.floor(x/N)+","+Math.floor(y/N);
  const T=chunkTiles();if(T){for(let yy=Math.floor(y/N)*N;yy<Math.floor(y/N)*N+N;yy++)for(let xx=Math.floor(x/N)*N;xx<Math.floor(x/N)*N+N;xx++){const el=T[yy*CH.W+xx];if(el){el.classList.remove("baked","bkf");delete el.dataset.bk;delete el.dataset.bkf}}}
  BK.imgs=BK.imgs.filter(im=>{const r=im.dataset.k===k;if(r)im.remove();return!r});bkQueue([k])}}
/* if the map is shown at a different size (window resized, view changed), the pictures are redrawn at the new size so they stay sharp */
{const _cs=chunkSync;chunkSync=function(){_cs();const m=$("#map");if(!m||CH.b)return;const w=m.offsetWidth;if(BK.mw&&w&&Math.abs(w-BK.mw)>1){bkReset();setTimeout(()=>bkQueue([...CH.live]),300)}if(w)BK.mw=w}}
{const _se=startExplore;startExplore=function(){BK.mw=0;_se()}}

/* =============== ONE ENTRY PER ALLOY ===============
   Old saves rebuild any registered alloy they can't find yet ("recovered" entries). That runs before the Sealbreaker and the Kiln Heart are added,
   so anyone who had registered either got a rebuilt copy AND the real one: the same name twice in the Alloydex. Keep the real one, drop the copy, renumber. */
(function dedupeAlloys(){const keep=new Map();
  ALLOYS.forEach(a=>{const k=a.name.toLowerCase(),o=keep.get(k);if(!o){keep.set(k,a);return}
    const better=(o.recovered&&!o.quest&&!o.threat)&&(!a.recovered||a.quest||a.threat)?a:o.recovered&&a.recovered&&(a.quest||a.threat||a.lore)&&!o.lore?a:o;keep.set(k,better)});
  const out=ALLOYS.filter(a=>keep.get(a.name.toLowerCase())===a);if(out.length===ALLOYS.length)return;
  ALLOYS.length=0;out.forEach((a,i)=>{a.no=i+1;ALLOYS.push(a)})})();

/* =============== DEPTH: things further down the screen are in front ===============
   Every furniture tile and every person or object on the map is layered by its row, so somebody standing just above a bookshelf,
   pillar or lamp is drawn BEHIND it (it hides their feet) instead of looking as if they're standing on top of it. */
const DEPTH_SEL=".npc,.mapobj,.mapitem,#player";
function depthRow(el){const t=parseFloat(el.style.top);return isNaN(t)||!EXP.H?null:Math.round(t/100*EXP.H)}
function depthPeople(){const w=$("#world");if(!w||!EXP.H)return;w.querySelectorAll(DEPTH_SEL).forEach(el=>{const y=el.id==="player"?EXP.y:depthRow(el);if(y==null)return;const z=String(11+2*y);if(el.style.zIndex!==z)el.style.zIndex=z})}
function depthTiles(){const m=$("#map");if(!m||!EXP.W)return;const T=m.children;for(let i=0;i<T.length;i++){const el=T[i];if(el.classList.contains("pr")||el.classList.contains("tl")){el.style.zIndex=String(10+2*Math.floor(i/EXP.W))}else if(el.style.zIndex)el.style.zIndex=""}}
{const _se=startExplore;startExplore=function(){_se();depthTiles();depthPeople()}}
{const _pp=placePlayer;placePlayer=function(instant){_pp(instant);depthPeople()}}
{const _mo=markOpened;markOpened=function(x,y){_mo(x,y);depthTiles()}}
setInterval(()=>{if(S.phase==="explore"&&!document.hidden)depthPeople()},120);
/* ---- click to move, by position ----
   Clicking used to find the tile under the pointer by asking which tile element was clicked. Floor that's been baked into a picture,
   tall furniture overhanging the tile above it, and people standing on tiles all got in the way of that. Now the click is turned straight
   into map coordinates, so you always walk to the square you actually clicked. */
(function(){const w=$("#world")||null;const bind=()=>{const W=$("#world");if(!W||W.__clickMove)return;W.__clickMove=1;
  W.addEventListener("click",e=>{if(S.phase!=="explore"||!EXP.W)return;const m=$("#map");if(!m)return;const r=m.getBoundingClientRect();if(!r.width)return;
    const x=Math.floor((e.clientX-r.left)/r.width*EXP.W),y=Math.floor((e.clientY-r.top)/r.height*EXP.H);if(x<0||y<0||x>=EXP.W||y>=EXP.H)return;
    e.stopPropagation();if(!EXP.busy)walkTo(x,y)},true)};
  bind();const _cs=camSetup;camSetup=function(){_cs();bind()}})();

/* =============== THE KILN HEART, REWORKED AND REDRAWN — and now the training alloy every recruit meets first ===============
   Look: a rod of living melt clamped in kiln tongs over a crucible, inside the brick throat of the Great Kiln. Its skin churns and glows,
   cracks pulse, stolen trinkets (a coin, a bolt, a spoon, a ring) ride around inside it, it drips into the crucible, and it visibly crusts
   over when it's too cold and blazes white when it's too hot.
   Play: the same heat band, stoke and quench, settling and turning-over as before, plus it SPITS stolen trinkets out onto the bench.
   Catch one and it goes in the quench bucket (a free bucket); miss it and it lands on a station and slags it. */
TLOOK["Kiln Heart"]={k:"kiln",a:"#2A1206",b:"#120702",core:"255,150,60",tag:"fire",tagc:"#FF7A1A",part:"ember",part2:"ash"};
TRACKS["threat_kiln"]={base:"threat",bpm:132,swing:.12,lead:{type:"square",vol:.085,stac:true},parts:[{k:"power",type:"triangle",vol:.05,oct:3},{k:"ostinato",type:"sawtooth",vol:.018,oct:5}],bass:{s:"root8",type:"square",vol:.12},drum:"k . s k k . s .",fill:"k k s s k k c c"};
const KH_TRINKETS=[["coin","a stolen coin"],["bolt","a stolen bolt"],["spoon","somebody's teaspoon"],["ring","a wedding ring"],["cap","a vial cap"]];
function khTrinketSVG(k,s){s=s||1;const g={coin:`<ellipse rx="${6*s}" ry="${5.2*s}" fill="#E0B820" stroke="#7A5A10" stroke-width="1"/><ellipse rx="${3.6*s}" ry="${3*s}" fill="none" stroke="#B88A10" stroke-width=".7"/>`,
  bolt:`<polygon points="${[0,1,2,3,4,5].map(i=>`${(6*s*Math.cos(i*1.047)).toFixed(1)},${(6*s*Math.sin(i*1.047)).toFixed(1)}`).join(" ")}" fill="#9AA4B0" stroke="#3A4048" stroke-width="1"/><circle r="${2.2*s}" fill="#5A6068"/>`,
  spoon:`<ellipse cx="${-4*s}" rx="${4*s}" ry="${3*s}" fill="#C8CCD4" stroke="#5A5E66" stroke-width=".8"/><path d="M0 0 L${9*s} ${2*s}" stroke="#C8CCD4" stroke-width="${2*s}" stroke-linecap="round"/>`,
  ring:`<circle r="${5*s}" fill="none" stroke="#E0B820" stroke-width="${2.2*s}"/><circle cx="0" cy="${-5*s}" r="${1.6*s}" fill="#BFE6FF" stroke="#7A5A10" stroke-width=".5"/>`,
  cap:`<rect x="${-5*s}" y="${-4*s}" width="${10*s}" height="${8*s}" rx="${2*s}" fill="#3A3A40" stroke="#121214" stroke-width="1"/><path d="M${-5*s} ${-1*s} H${5*s}" stroke="#FF7A1A" stroke-width="1"/>`}[k];return g}
/* the scene, the vessel and the living rod */
{const _tf=threatFx;threatFx=function(host,a,mini){if(!a||a.name!=="Kiln Heart")return _tf(host,a,mini);const svg=host&&host.querySelector("svg");if(!svg||svg.querySelector(".tfx"))return;
  const U="kh"+(threatFx.n=(threatFx.n||0)+1),R=mulberry(77+(threatFx.n||0)),rn=(x,y)=>(x+R()*(y-x)).toFixed(1),F=v=>(+v).toFixed(1);svg.style.overflow="visible";
  /* the brick throat of the Great Kiln, the fire bed, rising heat */
  let back=`<defs><radialGradient id="${U}g" gradientUnits="userSpaceOnUse" cx="150" cy="210" r="260"><stop offset="0" stop-color="#FFB24A" stop-opacity=".85"/><stop offset=".3" stop-color="#FF6A1A" stop-opacity=".45"/><stop offset=".7" stop-color="#5A1A08" stop-opacity=".2"/><stop offset="1" stop-color="#1A0804" stop-opacity="0"/></radialGradient>
    <linearGradient id="${U}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A120A"/><stop offset=".7" stop-color="#6A2E18"/><stop offset="1" stop-color="#A84A20"/></linearGradient>
    <filter id="${U}bl" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter></defs>`;
  back+=`<rect x="-260" y="-200" width="820" height="640" fill="url(#${U}b)"/>`;
  for(let row=0;row<14;row++){const y=-200+row*30,off=row%2?0:-40;for(let x=-260+off;x<560;x+=80){back+=`<rect x="${x}" y="${y}" width="78" height="28" rx="2" fill="${["#5A2414","#4A1E10","#6A2A16","#3E1A0E"][(row*7+x)%4|0]}" opacity="${row>8?.9:.75}"/>`}}
  back+=`<path d="M-260 -40 Q150 -260 560 -40 L560 -200 L-260 -200 Z" fill="#120804" opacity=".85"/>`;
  back+=`<circle cx="150" cy="210" r="260" fill="url(#${U}g)"><animate attributeName="opacity" values=".8;1;.85;1;.8" dur="1.7s" repeatCount="indefinite"/></circle>`;
  back+=`<path d="M-260 236 Q-100 222 40 236 Q150 246 260 234 Q400 224 560 236 L560 440 L-260 440 Z" fill="#2A1008"/>`;
  for(let i=0;i<26;i++){const x=+rn(-240,540);back+=`<ellipse cx="${F(x)}" cy="${rn(240,262)}" rx="${rn(8,22)}" ry="${rn(3,6)}" fill="${["#FF8A2A","#FFB24A","#C8401A"][i%3]}" opacity=".85"><animate attributeName="opacity" values=".5;1;.6;.9;.5" dur="${rn(1,2.4)}s" repeatCount="indefinite"/></ellipse>`}
  let em="";for(let i=0;i<18;i++){const x=+rn(-200,500),d=rn(2.5,5),b=rn(0,5);em+=`<circle cx="${F(x)}" cy="240" r="${rn(1.2,2.6)}" fill="#FFC060"><animate attributeName="cy" values="250;-120" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="cx" values="${F(x)};${F(x+(+rn(-40,40)))}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;.8;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
  back+=em;
  /* the crucible underneath and the tongs that hold the rod (the rod lies at -20 degrees: x36..262, y94..146 before turning) */
  const ROT=`rotate(-20 150 120)`;
  let box=`<defs><linearGradient id="${U}cr" x1="0" x2="1"><stop offset="0" stop-color="#1A1A1E"/><stop offset=".35" stop-color="#4A4A52"/><stop offset=".6" stop-color="#2A2A30"/><stop offset="1" stop-color="#121216"/></linearGradient>
    <radialGradient id="${U}pool" cx=".5" cy=".4" r=".7"><stop offset="0" stop-color="#FFF2A0"/><stop offset=".35" stop-color="#FFB24A"/><stop offset=".8" stop-color="#E8501A"/><stop offset="1" stop-color="#8A2A0A"/></radialGradient></defs>`;
  box+=`<g class="khpot"><path d="M92 176 Q94 230 150 232 Q206 230 208 176 Z" fill="url(#${U}cr)" stroke="#0A0A0C" stroke-width="2.4"/><ellipse cx="150" cy="176" rx="58" ry="11" fill="#2A2A30" stroke="#0A0A0C" stroke-width="2"/>
    <ellipse cx="150" cy="178" rx="50" ry="7.5" fill="url(#${U}pool)" class="khpool"><animate attributeName="ry" values="7.5;8.4;7.5" dur="2.2s" repeatCount="indefinite"/></ellipse>
    <path d="M104 204 Q150 214 196 204" stroke="#FF8A2A" stroke-width="1.4" opacity=".35" fill="none"/><path d="M98 190 L84 186 M202 190 L216 186" stroke="#2A2A30" stroke-width="5" stroke-linecap="round"/></g>`;
  box+=`<g class="khtongs" transform="${ROT}"><path d="M-40 70 L56 98 M-40 170 L56 142" stroke="#1E1E22" stroke-width="7" stroke-linecap="round"/><path d="M-40 70 L56 98 M-40 170 L56 142" stroke="#5A5A62" stroke-width="2.2" stroke-linecap="round"/>
    <path d="M340 70 L242 98 M340 170 L242 142" stroke="#1E1E22" stroke-width="7" stroke-linecap="round"/><path d="M340 70 L242 98 M340 170 L242 142" stroke="#5A5A62" stroke-width="2.2" stroke-linecap="round"/></g>`;
  /* the living rod: churning melt, glowing cracks, trinkets riding round inside, a crust that grows when it's cold, drips */
  let f=`<defs><clipPath id="${U}rc"><rect x="36" y="94" width="226" height="52"/><ellipse cx="36" cy="120" rx="10" ry="26"/></clipPath><filter id="${U}bl2" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="8"/></filter>
    <linearGradient id="${U}m" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE9A0"/><stop offset=".25" stop-color="#FFB24A"/><stop offset=".65" stop-color="#E8601A"/><stop offset="1" stop-color="#7A240A"/></linearGradient>
    <radialGradient id="${U}end" cx=".45" cy=".4" r=".7"><stop offset="0" stop-color="#FFF6C8"/><stop offset=".5" stop-color="#FFB24A"/><stop offset="1" stop-color="#C8401A"/></radialGradient>
    <linearGradient id="${U}w" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFF8D0" stop-opacity="0"/><stop offset=".5" stop-color="#FFF8D0" stop-opacity=".85"/><stop offset="1" stop-color="#FFF8D0" stop-opacity="0"/></linearGradient></defs>`;
  let cell="";for(let i=0;i<9;i++){const x=+rn(36,149),y=+rn(96,144);cell+=`<ellipse cx="${F(x)}" cy="${F(y)}" rx="${rn(9,22)}" ry="${rn(3,8)}" fill="${["#FFD25A","#FF8A2A","#C8401A","#FFF2A0","#E8601A"][i%5]}" opacity=".7"/>`}
  const flow=[-113,0,113].map(o=>`<g transform="translate(${o} 0)">${cell}</g>`).join("");
  f+=`<g transform="${ROT}"><g clip-path="url(#${U}rc)"><rect x="20" y="94" width="250" height="52" fill="url(#${U}m)" class="khlava"/>
    <g class="khlava"><g>${flow}<animateTransform attributeName="transform" type="translate" values="0 0;113 0" dur="6s" repeatCount="indefinite"/></g></g>
    <rect x="0" y="94" width="50" height="52" fill="url(#${U}w)" class="khlava" opacity=".55"><animate attributeName="x" values="0;270" dur="2.8s" repeatCount="indefinite"/></rect>`;
  [["coin",78,112,3.2],["bolt",128,132,4.6],["spoon",178,108,3.8],["ring",224,130,5.4],["cap",104,122,4.2]].forEach(([k,x,y,d],i)=>{f+=`<g opacity=".85"><g transform="translate(${x} ${y}) rotate(${i*47})">${khTrinketSVG(k,.9)}</g><animateTransform attributeName="transform" type="translate" values="0 0;${i%2?7:-7} ${i%2?-4:4};0 0" dur="${d}s" repeatCount="indefinite"/></g>`});
  let crack="";for(let i=0;i<7;i++){const x=56+i*30+(+rn(-8,8));crack+=`<path d="M${F(x)} 94 L${F(x+(+rn(-7,7)))} ${rn(104,112)} L${F(x+(+rn(-9,9)))} ${rn(118,128)} L${F(x+(+rn(-7,7)))} 146" stroke="#FFF2A0" stroke-width="1.6" fill="none"><animate attributeName="opacity" values=".3;1;.4;.9;.3" dur="${rn(1,2.2)}s" repeatCount="indefinite"/></path>`}
  f+=`<g class="khcracks">${crack}</g>`;
  let crust="";for(let row=0;row<3;row++)for(let i=0;i<14;i++){const x=28+i*17+(+rn(-4,4))+(row%2?8:0),y=92+row*17+(+rn(-3,3));crust+=`<path d="M${F(x)} ${F(y)} l${rn(10,16)} ${rn(-2,2)} l${rn(-2,3)} ${rn(10,16)} l${rn(-15,-10)} ${rn(-2,2)} Z" fill="${["#2A2420","#3A302A","#221C18"][(row+i)%3]}" stroke="#120E0C" stroke-width=".8"/>`}
  f+=`<g class="khcrust">${crust}</g></g>`;
  f+=`<path d="M36 94 H262 M36 146 H262" stroke="#3A1A0A" stroke-width="2"/><ellipse cx="262" cy="120" rx="10" ry="26" fill="url(#${U}end)" stroke="#3A1A0A" stroke-width="2" class="khlava"/>
    <ellipse cx="262" cy="120" rx="5" ry="15" fill="#FFF6C8" opacity=".6" class="khlava"><animate attributeName="opacity" values=".3;.8;.3" dur="1.6s" repeatCount="indefinite"/></ellipse>
    <g class="khclamp"><rect x="50" y="90" width="14" height="60" rx="3" fill="#3A3A40" stroke="#121214" stroke-width="2"/><rect x="234" y="90" width="14" height="60" rx="3" fill="#3A3A40" stroke="#121214" stroke-width="2"/><path d="M53 93 V147 M237 93 V147" stroke="#7A7A84" stroke-width="1.2"/></g>
    <g class="khblaze"><rect x="26" y="78" width="246" height="84" rx="40" fill="#FFF2C0" opacity=".35" filter="url(#${U}bl2)"/></g></g>`;
  /* drips leave the underside of the rod and fall into the crucible */
  for(let i=0;i<4;i++){const dx=+rn(-45,30),X=150+.94*dx+8.9,Y=120-.342*dx+24.4,d=rn(1.2,2),b=rn(0,2);f+=`<circle cx="${F(X)}" cy="${F(Y)}" r="2.6" fill="#FFB24A" class="khdrip"><animate attributeName="cy" values="${F(Y)};${F(Y)};176" keyTimes="0;.5;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="r" values="1;3;2" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
  f+=`<path d="M100 92 Q116 76 110 58 M156 74 Q146 56 158 38 M206 56 Q220 42 212 24" stroke="#FFD27A" stroke-width="1.6" fill="none" class="khhaze"><animate attributeName="opacity" values=".08;.32;.08" dur="1.8s" repeatCount="indefinite"/></path>`;
  svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${box}</g>`);
  if(!mini){const cont=host.closest("#stage,.ddscreen");if(cont){cont.querySelectorAll(":scope>.tscene").forEach(e=>e.remove());const lay=document.createElementNS("http://www.w3.org/2000/svg","svg");lay.setAttribute("class","tscene");lay.setAttribute("aria-hidden","true");
      lay.innerHTML=`<g pointer-events="none">${back}</g>`;lay._spec=svg;cont.prepend(lay);fitScene(lay)}else svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${back}</g>`)}
  svg.insertAdjacentHTML("beforeend",`<g class="tfx" pointer-events="none">${f}</g>`);if(mini){svg.style.overflow="hidden";const dd=(back.match(/<defs>[\s\S]*?<\/defs>/g)||[]).join("");if(dd)svg.insertAdjacentHTML("afterbegin",dd)}}}
/* the rod shows its heat */
function khLook(){const sp=$("#specimen");if(!sp)return;const on=bossActive()&&TB.a&&TB.a.name==="Kiln Heart"&&TB.slag;
  sp.classList.toggle("kh-cold",!!on&&TB.heat<TB.lo);sp.classList.toggle("kh-hot",!!on&&TB.heat>TB.lo+TB.bw);sp.classList.toggle("kh-ok",!!on&&khInBand());sp.classList.toggle("kh-crust",!!on&&TB.crust>55)}
{const _bh=bossHud;bossHud=function(){_bh();if(TB.on&&TB.a&&TB.a.name==="Kiln Heart")khLook()}}
{const _be=bossEnd;bossEnd=function(){const sp=$("#specimen");if(sp)sp.classList.remove("kh-cold","kh-hot","kh-ok","kh-crust");document.querySelectorAll(".khtrinket").forEach(e=>e.remove());_be()}}
/* trinkets: it spits its plunder out onto the bench */
function khSpit(){const st=$("#stage");if(!st||!bossActive())return;const[k,label]=KH_TRINKETS[Math.random()*KH_TRINKETS.length|0];
  const b=document.createElement("button");b.className="khtrinket";b.setAttribute("aria-label","Catch "+label);b.innerHTML=`<svg viewBox="-10 -10 20 20">${khTrinketSVG(k,1.2)}</svg>`;
  b.style.setProperty("--dx",((Math.random()<.5?-1:1)*(80+Math.random()*120)).toFixed(0)+"px");b.style.left=(42+Math.random()*16)+"%";
  b.onpointerdown=e=>{e.stopPropagation();e.preventDefault();if(b.dataset.done)return;b.dataset.done=1;b.remove();if(TB.buckets<KH.buckets+1)TB.buckets++;if(gate("khcatch",200))sfx("pickup");say(`You caught ${label} before it hit the bench. It goes in the quench bucket: one more QUENCH.`);bossHud()};
  b.addEventListener("animationend",()=>{if(b.dataset.done||!bossActive())return;b.dataset.done=1;b.remove();const free=STATION_KEYS.filter(s=>!TB.slag[s]);if(free.length){const s=free[Math.random()*free.length|0];TB.slag[s]=8;const el=$("#st-"+s);if(el)el.classList.add("slagged");if(gate("khclunk",300))sfx("clunk");say(`${label[0].toUpperCase()+label.slice(1)} bounced off the bench and slagged the ${STATION_NAMES[s]}! Catch them next time.`)}bossHud()});
  st.appendChild(b);sfx("whoomph")}
/* the tutorial version: gentle, can't escape, and only moves when Dr. Marlow isn't talking */
const khTut=()=>typeof TUT!=="undefined"&&TUT.on&&S.r&&S.r.tut;
{const _bt=bossTick;bossTick=function(){const isK=TB.on&&TB.a&&TB.a.name==="Kiln Heart"&&TB.slag,tut=isK&&khTut();
  if(tut){const st=TUT_STEPS[TUT.i];if(!st.wait||(TUT.hold&&performance.now()<TUT.hold)){TB.khLast=TB.khT2=performance.now();return}}
  const pre=TB.settle;_bt();if(!isK||!bossActive())return;
  if(tut){const now=performance.now(),dt=Math.min(.25,(now-(TB.khT2||now))/1000);TB.khT2=now;
    TB.hp=Math.max(TB.hp,40);TB.crust=Math.min(TB.crust,75);TB.woke=false;TB.shiftIn=999;TB.leapOn=0;TB.taint=null;
    if(khInBand())TB.settle=Math.min(100,TB.settle+KH.settleUp*dt);
    Object.keys(TB.slag).forEach(s=>{delete TB.slag[s];const el=$("#st-"+s);if(el)el.classList.remove("slagged")});return}
  /* spitting starts once it has had a few seconds to warm up to you */
  if(TB.t>8&&!TB.leapOn&&!document.hidden&&!(TB.grace>0)&&S.r.stage==="elements"){TB.spitIn=(TB.spitIn==null?6:TB.spitIn)-.1;if(TB.spitIn<=0){TB.spitIn=TB.woke?7+Math.random()*3:11+Math.random()*4;khSpit()}}}}
{const _bs=bossStart;bossStart=function(){_bs();if(TB.on&&TB.a.name==="Kiln Heart"){TB.spitIn=6;if(typeof TUT!=="undefined"&&TUT.on&&TUT.i<=3){S.r.tries=S.r.maxTries=5;TB.heat=TB.lo+TB.bw/2;TB.taint=null;TB.shiftIn=999;renderActions()}khLook()}}}
{const _bc=bossControls;bossControls=function(){_bc();if(!TB.a||TB.a.name!=="Kiln Heart")return;const s=$("#bb-stoke"),q=$("#bb-quench");if(s)s.addEventListener("click",()=>TB.khS=1);if(q)q.addEventListener("click",()=>TB.khQ=1)}}
BOSS["Kiln Heart"].tell="A hoard of stolen metal fused into one living melt. It only holds still inside a narrow HEAT BAND, and the band MOVES every time you scan it. Ride the FLARES and COOLING spells with STOKE and QUENCH. The scanner can't read it until the pour has SETTLED (hold it in the band). Readings taken out of the band come back TAINTED. It SPITS stolen trinkets onto the bench: catch them for a free quench, or they'll slag a station.";

/* =============== CLEAN FLOORS, WALLS AND DOORWAYS ===============
   1. The map is laid out on a whole number of screen pixels per tile, so every floor line lands on a real pixel and none of them
      fade, double up or drift between one part of the map and the next.
   2. Institute walls read as walls: a run of wall seen from above is one solid top, and only the end you look at shows its face.
   3. Doorways get a sill and posts, so a gap in a wall is obviously a way through.
   4. The Institute's spilled samples are scattered by hand, each spill is different, and nothing is sliced off at a tile's edge.
   5. Plank floors are laid with staggered joints, like real boards. */

/* ---- 1. whole-pixel tiles ---- */
function snapWorld(){const mw=$("#mapwrap"),w=$("#world");if(!mw||!w||!EXP.W||!VIEW.w)return;const dpr=window.devicePixelRatio||1,raw=mw.clientWidth/VIEW.w;if(!raw)return;
  const tp=Math.max(2,Math.round(raw*dpr/2)*2)/dpr;w.style.width=(EXP.W*tp)+"px";w.style.height=(EXP.H*tp)+"px";w.style.setProperty("--tp",tp+"px");w.classList.add("snap");tileCoords()}
/* every tile knows where it sits, so floor textures can run on across tiles as one surface */
function tileCoords(){const m=$("#map");if(!m)return;const f=m.querySelector(".tile");if(!f||f.style.getPropertyValue("--gx"))return;m.querySelectorAll(".tile").forEach(t=>{if(t.dataset.x!=null){t.style.setProperty("--gx",t.dataset.x);t.style.setProperty("--gy",t.dataset.y)}})}
{const _cs=camSetup;camSetup=function(){_cs();snapWorld();cam(true)}}
addEventListener("resize",()=>{snapWorld();cam(true)});
if(window.ResizeObserver){const ro=new ResizeObserver(()=>{if(S.phase==="explore"){snapWorld();cam(true)}});const go=()=>{const mw=$("#mapwrap");if(mw)ro.observe(mw);else setTimeout(go,500)};go()}

/* ---- 2 + 3. walls everywhere, and Institute doorways ---- */
/* A run of wall seen from above is one solid top; only a wall with open floor in front of it shows its face. */
const isWallCh=ch=>ch==="#"||ch==="W";
/* ---- 5. plank floors: boards run on across tiles, each with its own length and shade, so joints never line up into a grid ---- */
const OAKPLAN=new WeakMap();
function oakPlan(M){let P=OAKPLAN.get(M);if(P)return P;P=[];const H=M.length,W=M[0].length;
  for(let y=0;y<H;y++){const row=[[],[]];for(let h=0;h<2;h++){const R=mulberry((y*2+h)*7919+W*31+H),rn=(a,b)=>a+R()*(b-a);let sh=R()*3|0,rem=rn(.3,3);
      for(let x=0;x<W;x++){if(rem>=1){row[h].push("n"+sh);rem-=1;continue}
        let J=Math.round(rem*4);J=J<1?1:J>3?3:J;let ns=(sh+1+(R()*2|0))%3;row[h].push("j"+J+sh+ns);sh=ns;rem=rn(1.6,3.6)-(1-J/4)}}
    P.push(row)}
  OAKPLAN.set(M,P);return P}
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const r=_tl(c,x,y,seed,M);if(!EXP.zone||!r||!M)return r;
  const at=(xx,yy,out)=>{const row=M[yy];if(row==null||xx<0||xx>=row.length)return out;return isWallCh(row[xx])};
  if(c==="#"&&/^w\b/.test(r[0])){
    if(at(x,y+1,false)){let k=r[0]+" wtop";if(!at(x-1,y,true))k+=" ww";if(!at(x+1,y,true))k+=" we";if(!at(x,y-1,true))k+=" wn";r[0]=k}
    else{let k=r[0];if(!at(x-1,y,true))k+=" fw";if(!at(x+1,y,true))k+=" fe";r[0]=k}
    return r}
  if(EXP.zone.cls!=="z-quill")return r;
  let door=false;
  if(/^f\b/.test(r[0])&&!/\b(pr|tl)\b/.test(r[0])){
    if(at(x,y-1,false)&&at(x,y+1,false)&&!at(x-1,y,false)&&!at(x+1,y,false)){r[0]+=" dframe dv";door=true}
    else if(at(x-1,y,false)&&at(x+1,y,false)&&!at(x,y-1,false)&&!at(x,y+1,false)){r[0]+=" dframe dh";door=true}}
  if(!door&&/\boak\b/.test(r[0])){const P=oakPlan(M)[y];if(P)r[0]+=` oakp pt-${P[0][x]} pb-${P[1][x]}`}
  return r}}

/* ---- 4. spilled samples: every spill its own, nothing crossing the tile's edge ---- */
quillSpill=function(seed){const R=mulberry(seed*7919+13),rn=(a,b)=>a+R()*(b-a),f=v=>v.toFixed(1),pick=a=>a[R()*a.length|0];
  const cols=["#B8C0CC","#D9B86A","#C98A5A","#9AA8B8","#D0D4DA","#8FC4A0","#C8A0C8"];let g="";
  /* each piece is drawn round its own centre, and the centre is kept far enough in that turning it can't push it past the edge */
  const B=[],bd=(x,y,r)=>B.push([x,y,r]);
  const paper=(cx,cy,a,s=1)=>(bd(cx,cy,8.3*s),`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)}) scale(${s})"><rect x="-5" y="-6.5" width="10" height="13" fill="#F7F4EA" stroke="#B8B0A0" stroke-width=".5"/><path d="M-3 -3.5 h6 M-3 -1 h5 M-3 1.5 h6 M-3 4 h4" stroke="#8A94A8" stroke-width=".6"/></g>`);
  const jar=(cx,cy,a,c)=>{let s="";bd(cx,cy,12);const dx=Math.cos((a+90)*Math.PI/180),dy=Math.sin((a+90)*Math.PI/180);for(let i=0;i<5;i++){const t=3.5+i*1.2;s+=`<ellipse cx="${f(cx-dx*t+rn(-1.5,1.5))}" cy="${f(cy-dy*t+rn(-1.5,1.5))}" rx="${f(rn(.9,1.8))}" ry="${f(rn(.7,1.3))}" fill="${c}" stroke="rgba(0,0,0,.35)" stroke-width=".4"/>`}
    return s+`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><rect x="-3.5" y="-5" width="7" height="10" rx="2" fill="rgba(210,235,250,.55)" stroke="#6A8AA8" stroke-width=".8"/><rect x="-4" y="-6.8" width="8" height="2.4" rx="1" fill="#3A4A6A"/><rect x="-2.5" y="-1" width="5" height="2.6" fill="#F7F4EA"/></g>`};
  const flask=(cx,cy,a,c)=>(bd(cx,cy,8.5),`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><path d="M-1.6 -6 v4 l-3.6 6 q-.8 1.6 .8 1.6 h8.8 q1.6 0 .8-1.6 l-3.6 -6 v-4 z" fill="rgba(210,235,250,.6)" stroke="#6A8AA8" stroke-width=".8"/><path d="M-3.9 2 h7.8 l.9 1.6 q0 .8 -.8 .8 h-8 q-.8 0 -.8-.8 z" fill="${c}" opacity=".85"/><rect x="-2.2" y="-7" width="4.4" height="1.4" rx=".5" fill="#C8B89A"/></g>`);
  const puddle=(cx,cy,c)=>(bd(cx,cy,6.5),`<path d="M${f(cx-6)} ${f(cy)} q2 -3 6 -2.4 q5 -.6 6 1.8 q.6 2.6 -4 2.8 q-3 1.6 -6 .2 q-3 -.4 -2 -2.4z" fill="${c}" opacity=".45"/>`);
  const shards=(cx,cy)=>{let s="";bd(cx,cy,7.6);for(let i=0;i<5;i++){const x=cx+rn(-5,5),y=cy+rn(-4,4),r=rn(1.2,2.4),a=rn(0,6.28);s+=`<path d="M${f(x)} ${f(y)} l${f(Math.cos(a)*r)} ${f(Math.sin(a)*r)} l${f(Math.cos(a+2)*r*.8)} ${f(Math.sin(a+2)*r*.8)} z" fill="rgba(210,235,250,.7)" stroke="#6A8AA8" stroke-width=".4"/>`}return s};
  const tube=(cx,cy,a,c)=>(bd(cx,cy,7.4),`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><rect x="-1.6" y="-7" width="3.2" height="14" rx="1.6" fill="rgba(210,235,250,.6)" stroke="#6A8AA8" stroke-width=".7"/><rect x="-1.2" y="1" width="2.4" height="5.6" rx="1.2" fill="${c}" opacity=".85"/></g>`);
  const clip=(cx,cy,a)=>(bd(cx,cy,10.9),`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><rect x="-6" y="-8" width="12" height="16" rx="1" fill="#8A5E38" stroke="#4A3018" stroke-width=".7"/><rect x="-4.6" y="-5.6" width="9.2" height="12.4" fill="#F7F4EA"/><path d="M-3 -3 h6 M-3 -.5 h5 M-3 2 h6" stroke="#8A94A8" stroke-width=".6"/><rect x="-2.6" y="-9" width="5.2" height="2.8" rx=".8" fill="#9AA4B0" stroke="#4A5058" stroke-width=".5"/></g>`);
  const book=(cx,cy,a)=>{bd(cx,cy,7.6);const cv=pick(["#3A5A8A","#8A3A34","#2E6A4A","#6A3A5A","#8A6A2A"]);return `<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><rect x="-6" y="-4.5" width="12" height="9" rx="1" fill="${cv}" stroke="#1A1A1A" stroke-width=".6"/><rect x="-6" y="2.6" width="12" height="1.6" fill="#EDE6D2"/><path d="M-3.5 -1.5 h7" stroke="rgba(255,255,255,.45)" stroke-width=".8"/></g>`};
  const pen=(cx,cy,a)=>(bd(cx,cy,6.2),`<g transform="translate(${f(cx)} ${f(cy)}) rotate(${f(a)})"><rect x="-5" y="-.7" width="9" height="1.4" rx=".6" fill="${pick(["#3A4A6A","#8A2A24","#2A2A2A"])}"/><path d="M4 -.7 l2 .7 l-2 .7 z" fill="#C8A060"/></g>`);
  const C=()=>[rn(13,27),rn(13,27)],A=()=>rn(-180,180),kinds=["papers","jar","flask","tubes","clip","books","mess"];
  const k=kinds[(seed*5+(R()*7|0))%kinds.length],c=pick(cols);
  if(k==="papers"){const n=3+(R()*2|0);for(let i=0;i<n;i++){const[x,y]=C();g+=paper(x,y,A(),rn(.85,1.05))}if(R()<.5){const[x,y]=C();g+=pen(x,y,A())}}
  else if(k==="jar"){const[x,y]=[rn(16,24),rn(16,24)];g+=jar(x,y,rn(-120,-40)+(R()<.5?180:0),c);if(R()<.5){const[a,b]=C();g=paper(a,b,A())+g}}
  else if(k==="flask"){const[x,y]=[rn(14,26),rn(14,24)];g+=puddle(x+rn(-2,2),y+4,c)+flask(x,y,R()<.5?rn(-12,12):rn(70,110),c)}
  else if(k==="tubes"){const[x,y]=[rn(14,26),rn(14,26)];g+=shards(x+rn(-3,3),y+rn(2,4))+tube(x,y,A(),c);if(R()<.6){const[a,b]=C();g+=tube(a,b,A(),pick(cols))}}
  else if(k==="clip"){const[x,y]=[rn(15,25),rn(15,25)];g+=clip(x,y,rn(-40,40));if(R()<.6){const[a,b]=C();g=paper(a,b,A())+g}}
  else if(k==="books"){const[x,y]=[rn(16,24),rn(16,24)];g+=book(x,y,A());if(R()<.7)g+=book(x+rn(-3,3),y+rn(-3,3),A());if(R()<.4){const[a,b]=C();g+=paper(a,b,A())}}
  else{const[x,y]=C(),[a,b]=C();g+=paper(x,y,A())+(R()<.5?flask(a,b,rn(60,120),c):jar(Math.min(24,Math.max(16,a)),Math.min(24,Math.max(16,b)),A(),c))}
  /* centre the spill and blow it up as large as the tile allows, never past its edge */
  const x0=Math.min(...B.map(b=>b[0]-b[2])),x1=Math.max(...B.map(b=>b[0]+b[2])),y0=Math.min(...B.map(b=>b[1]-b[2])),y1=Math.max(...B.map(b=>b[1]+b[2])),mx=(x0+x1)/2,my=(y0+y1)/2,sc=Math.min(1.7,37/Math.max(x1-x0,y1-y0));
  g=`<g transform="translate(${f(20+rn(-1.5,1.5))} ${f(20+rn(-1.5,1.5))}) scale(${sc.toFixed(3)}) translate(${f(-mx)} ${f(-my)})">${g}</g>`;
  g+=`<path class="tw" d="M${f(rn(10,30))} ${f(rn(10,28))} l1 -3 l1 3 l3 1 l-3 1 l-1 3 l-1 -3 l-3 -1 z" fill="#FFFFFF" style="animation-delay:${f(rn(0,2.4))}s"/>`;
  return `<svg viewBox="0 0 40 40" aria-hidden="true">${g}</svg>`};
/* the hall's two neat blocks of spills become one long, untidy trail along both sides of the runner */
function quillScatter(map){if(!map||map.length<22||map[16].length<36)return map;const M=map.map(r=>r.split(""));
  for(let y=16;y<=21;y++)for(let x=20;x<=35;x++)if(M[y][x]===",")M[y][x]=".";
  [[22,16],[32,16],[34,16],[21,17],[22,17],[25,17],[30,17],[32,17],[33,17],[22,18],[23,18],[31,18],[32,18],[35,18],[21,19],[24,19],[25,19],[30,19],[34,19],[23,20],[31,20],[32,20],[21,21],[33,21]].forEach(([x,y])=>{if(M[y][x]===".")M[y][x]=","});
  return M.map(r=>r.join(""))}
if(typeof MAPS!=="undefined"&&MAPS["z-quill"])MAPS["z-quill"]=quillScatter(MAPS["z-quill"]);
{const Z=ZONES.find(z=>z.cls==="z-quill");if(Z)Z.map=quillScatter(Z.map)}

/* ---- floor textures, sized in whole screen pixels for the current tile size so they join seamlessly ---- */
const FLOOR_TEX=[{"s": ".z-mine .map .tile.f,.z-mine .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.07) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.14) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.14) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.07) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.14) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#6E5B47", "i": true}, {"s": ".z-mine .map .tile.f.fd", "l": [["linear-gradient(#5A3E24 0 1.5px,transparent 1.5px)", 1, 0.34, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#5A3E24 270deg)", 3.8, 0.68, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#5A3E24 270deg)", 3.8, 0.68, 1.9, 0.34], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#5A3E24 270deg)", 6.27, 1.02, 1.045, 0.68], ["linear-gradient(#8A6440 50%,#82603C 50%)", 1, 0.68, 0, 0]], "c": "#8A6440", "i": true}, {"s": ".z-scrap .map .tile.f,.z-scrap .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.08) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(40,30,20,.2) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(40,30,20,.2) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.08) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(40,30,20,.2) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["radial-gradient(ellipse at 40% 60%,rgba(40,30,20,.06) 0 14%,transparent 15.5%)", 3.3, 2.7, 0, 0], ["radial-gradient(ellipse at 60% 30%,rgba(40,30,20,.05) 0 10%,transparent 11.5%)", 4.7, 3.9, 1.9, 1.3]], "c": "#8A8579", "i": true}, {"s": ".z-scrap .map .tile.f.fd", "l": [["radial-gradient(ellipse at 30% 60%,rgba(40,30,20,.14) 0 16%,transparent 17.5%)", 2.9, 2.3, 0, 0], ["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.1) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.1) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.1) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#A3A19A", "i": true}, {"s": ".z-scrap .map .tile.pa", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.09) 0 3.2%,transparent 4.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.22) 0 2.8%,transparent 3.6%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.22) 0 1.8%,transparent 2.4%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.09) 0 2.8%,transparent 3.6%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.22) 0 2.4%,transparent 3.2%)", 1.61, 2.37, 0, 0]], "c": "#4E4E54", "i": true}, {"s": ".z-wreck .map .tile.f,.z-wreck .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.18) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(120,90,40,.16) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(120,90,40,.16) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.18) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(120,90,40,.16) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#D9C38F", "i": true}, {"s": ".z-wreck .map .tile.f.fd", "l": [["radial-gradient(ellipse at 50% 120%,transparent 0 40%,rgba(255,255,255,.1) 41% 44%,transparent 45%)", 1.3, 0.9, 0, 0], ["radial-gradient(ellipse at 50% 120%,transparent 0 40%,rgba(255,255,255,.07) 41% 43%,transparent 44%)", 1.9, 1.2, 0.6, 0.4], ["radial-gradient(circle at 30% 40%,rgba(255,255,255,.12) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(90,70,30,.14) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(90,70,30,.14) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.12) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(90,70,30,.14) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#BBA474", "i": true}, {"s": ".z-wreck .map .tile.pa", "l": [["linear-gradient(90deg,#6E4424 0 1.5px,transparent 1.5px)", 0.3, 1, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#6E4424 270deg)", 0.6, 3.4, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#6E4424 270deg)", 0.6, 3.4, 0.3, 1.7], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#6E4424 270deg)", 0.8999999999999999, 5.609999999999999, 0.6, 0.935], ["linear-gradient(90deg,#9A6A3C 50%,#93653A 50%)", 0.6, 1, 0, 0]], "c": "#9A6A3C", "i": true}, {"s": ".z-volcano .map .tile.f,.z-volcano .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,140,80,.07) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,140,80,.07) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#4A3530", "i": true}, {"s": ".z-volcano .map .tile.f.fd", "l": [["linear-gradient(35deg,transparent 44%,rgba(255,110,30,.6) 46% 48%,transparent 50%)", 1.7, 1.3, 0, 0], ["linear-gradient(-50deg,transparent 60%,rgba(255,110,30,.35) 61% 62%,transparent 63%)", 2.3, 1.9, 0.8, 0.5], ["linear-gradient(80deg,transparent 30%,rgba(255,150,60,.3) 31% 32%,transparent 33%)", 3.1, 2.6, 1.4, 1.1], ["radial-gradient(circle at 30% 40%,rgba(255,120,60,.08) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.25) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.25) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,120,60,.08) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.25) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#35282A", "i": true}, {"s": ".z-volcano .map .tile.pa", "l": [["radial-gradient(ellipse at 50% 50%,#7A6A64 0 34%,transparent 36%)", 0.62, 0.55, 0, 0], ["radial-gradient(ellipse at 50% 50%,#6E5E58 0 32%,transparent 34%)", 0.71, 0.6, 0.31, 0.27], ["radial-gradient(ellipse at 50% 50%,#84746C 0 28%,transparent 30%)", 0.93, 0.81, 0.2, 0.5]], "c": "#4E403C", "i": true}, {"s": ".z-vault .map .tile.f,.z-vault .map .tile.r", "l": [["linear-gradient(35deg,transparent 47%,rgba(150,135,100,.22) 48% 49%,transparent 50%)", 2.3, 1.7, 0, 0], ["linear-gradient(-25deg,transparent 60%,rgba(150,135,100,.18) 61% 62%,transparent 63%)", 3.1, 2.2, 0.9, 0.4]], "c": "#D8CFB8", "i": true}, {"s": ".z-vault .map .tile.f.fd", "l": [["radial-gradient(circle,#9A5A8A 0 14%,transparent calc(14% + 1%))", 0.55, 0.55, 0, 0], ["radial-gradient(circle,#9A5A8A 0 14%,transparent calc(14% + 1%))", 0.55, 0.55, 0.275, 0.275]], "c": "#5A2A4A", "i": true}, {"s": ".z-vault .map .tile.pa", "l": [["radial-gradient(circle,#C23A52 0 12%,transparent calc(12% + 1%))", 0.62, 0.62, 0, 0], ["radial-gradient(circle,#C23A52 0 12%,transparent calc(12% + 1%))", 0.62, 0.62, 0.31, 0.31]], "c": "#A8243A", "i": false}, {"s": ".z-reactor .map .tile.f,.z-reactor .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.16) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.16) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.16) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["radial-gradient(ellipse at 40% 50%,rgba(40,50,40,.1) 0 18%,transparent 19.5%)", 3.4, 2.6, 0, 0]], "c": "#5E6A66", "i": true}, {"s": ".z-reactor .map .tile.f.fd", "l": [["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#4A5652 270deg)", 0.3, 0.17, 0, 0], ["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#4A5652 270deg)", 0.3, 0.17, 0.15, 0.085]], "c": "#7A8682", "i": true}, {"s": ".z-reactor .map .tile.pa", "l": [["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#5A6662 270deg)", 0.3, 0.17, 0, 0], ["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#5A6662 270deg)", 0.3, 0.17, 0.15, 0.085]], "c": "#8A9692", "i": true}, {"s": ".z-glacier .map .tile.f,.z-glacier .map .tile.r", "l": [["linear-gradient(120deg,transparent 40%,rgba(255,255,255,.35) 42% 44%,transparent 46%)", 2.3, 1.7, 0, 0], ["linear-gradient(150deg,transparent 55%,rgba(255,255,255,.25) 56% 57%,transparent 58%)", 3.1, 2.4, 1.1, 0.7], ["radial-gradient(circle at 30% 40%,rgba(255,255,255,.3) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(90,140,180,.15) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(90,140,180,.15) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.3) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(90,140,180,.15) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#BFDDF0", "i": true}, {"s": ".z-glacier .map .tile.f.fd", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.8) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(200,225,240,.5) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(200,225,240,.5) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.8) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(200,225,240,.5) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#F6FBFF", "i": true}, {"s": ".z-glacier .map .tile.pa", "l": [["linear-gradient(90deg,#7A5A3A 0 1.5px,transparent 1.5px)", 0.3, 1, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#7A5A3A 270deg)", 0.6, 3.2, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#7A5A3A 270deg)", 0.6, 3.2, 0.3, 1.6], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#7A5A3A 270deg)", 0.8999999999999999, 5.28, 0.6, 0.8800000000000001], ["linear-gradient(90deg,#B08A60 50%,#A88258 50%)", 0.6, 1, 0, 0]], "c": "#B08A60", "i": true}, {"s": ".z-crater .map .tile.f,.z-crater .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.08) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.18) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.18) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.08) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.18) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#4B4562", "i": true}, {"s": ".z-crater .map .tile.f.fd", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.08) 0 5.2%,transparent 6.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 4.5%,transparent 5.9%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.9%,transparent 3.9%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.08) 0 4.5%,transparent 5.9%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 3.9%,transparent 5.2%)", 1.61, 2.37, 0, 0], ["radial-gradient(circle at 50% 50%,transparent 0 18%,rgba(0,0,0,.08) 19% 23%,rgba(255,255,255,.04) 24% 26%,transparent 27%)", 3.7, 3.1, 0, 0], ["radial-gradient(circle at 50% 50%,transparent 0 12%,rgba(0,0,0,.07) 13% 16%,transparent 17%)", 2.3, 2.9, 1.1, 0.7]], "c": "#4B4562", "i": true}, {"s": ".z-crater .map .tile.pa", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.14) 0 5.2%,transparent 6.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(255,255,255,.08) 0 4.5%,transparent 5.9%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(255,255,255,.08) 0 2.9%,transparent 3.9%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.14) 0 4.5%,transparent 5.9%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(255,255,255,.08) 0 3.9%,transparent 5.2%)", 1.61, 2.37, 0, 0]], "c": "#7A6E98", "i": true}, {"s": ".z-quill .map .tile.f,.z-quill .map .tile.r", "l": [["radial-gradient(circle at 30% 40%,rgba(120,130,150,.18) 0 2.8%,transparent 3.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(150,160,180,.18) 0 2.4%,transparent 3.1%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(150,160,180,.18) 0 1.5%,transparent 2.1%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(120,130,150,.18) 0 2.4%,transparent 3.1%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(150,160,180,.18) 0 2.1%,transparent 2.8%)", 1.61, 2.37, 0, 0]], "c": "#E9EEF3", "i": true}, {"s": ".z-quill .map .tile.f.fd", "l": [["radial-gradient(circle,#B25A62 0 13%,transparent calc(13% + 1%))", 0.47, 0.47, 0, 0], ["radial-gradient(circle,#B25A62 0 13%,transparent calc(13% + 1%))", 0.47, 0.47, 0.235, 0.235]], "c": "#7A2E38", "i": true}, {"s": ".z-quill .map .tile.f.fd.plush", "l": [["radial-gradient(circle,#D8B060 0 9%,transparent calc(9% + 1%))", 0.47, 0.47, 0, 0], ["radial-gradient(circle,#D8B060 0 9%,transparent calc(9% + 1%))", 0.47, 0.47, 0.235, 0.235], ["linear-gradient(45deg,#6A1E2A 25%,#7A2833 25% 50%,#6A1E2A 50% 75%,#7A2833 75%)", "14px", "14px", 0, 0]], "c": "#6A1E2A", "i": true}, {"s": ".z-quill .map .tile.f.dated", "l": [["radial-gradient(circle at 30% 40%,rgba(120,100,60,.22) 0 3.6%,transparent 4.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(255,255,255,.4) 0 3.1%,transparent 4.0%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(255,255,255,.4) 0 2.0%,transparent 2.7%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(120,100,60,.22) 0 3.1%,transparent 4.0%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(255,255,255,.4) 0 2.7%,transparent 3.6%)", 1.61, 2.37, 0, 0]], "c": "#E0D6BE", "i": true}, {"s": ".z-slag .map .tile.f.sl-rim,.z-slag .map .tile.r.sl-rim", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.07) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.18) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.18) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.07) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.18) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#6E675C", "i": true}, {"s": ".z-slag .map .tile.f.sl-bench,.z-slag .map .tile.r.sl-bench", "l": [["radial-gradient(circle at 30% 40%,rgba(120,140,110,.12) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.16) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.16) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(120,140,110,.12) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.16) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#596058", "i": true}, {"s": ".z-slag .map .tile.f.sl-road,.z-slag .map .tile.r.sl-road", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.07) 0 4.8%,transparent 6.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 4.2%,transparent 5.4%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.6%,transparent 3.6%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.07) 0 4.2%,transparent 5.4%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 3.6%,transparent 4.8%)", 1.61, 2.37, 0, 0], ["radial-gradient(ellipse at 50% 50%,rgba(0,0,0,.08) 0 20%,transparent 21.5%)", 2.9, 2.1, 0, 0]], "c": "#78684F", "i": true}, {"s": ".z-slag .map .tile.f.sl-pit,.z-slag .map .tile.r.sl-pit", "l": [["radial-gradient(circle at 30% 40%,rgba(140,160,180,.12) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.22) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.22) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(140,160,180,.12) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.22) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#3A3532", "i": true}, {"s": ".z-slag .map .tile.f.sl-drift,.z-slag .map .tile.r.sl-drift", "l": [["radial-gradient(circle at 30% 40%,rgba(255,200,120,.05) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.25) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.25) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,200,120,.05) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.25) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0]], "c": "#2E2A28", "i": true}, {"s": ".z-slag .map .tile.f.sl-plank", "l": [["linear-gradient(90deg,#3A2A1E 0 1.5px,transparent 1.5px)", 0.23, 1, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3A2A1E 270deg)", 0.46, 3.6, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3A2A1E 270deg)", 0.46, 3.6, 0.23, 1.8], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3A2A1E 270deg)", 0.6900000000000001, 5.9399999999999995, 0.46, 0.9900000000000001], ["linear-gradient(90deg,#5E4632 50%,#584230 50%)", 0.46, 1, 0, 0]], "c": "#5E4632", "i": true}, {"s": ".z-slag .map .tile.f.sl-grate", "l": [["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#3A3E44 270deg)", 0.3, 0.17, 0, 0], ["conic-gradient(from 0deg at 58% 34%,transparent 0 270deg,#3A3E44 270deg)", 0.3, 0.17, 0.15, 0.085]], "c": "#1E2A2C", "i": true}, {"s": ".z-slag .map .tile.r.sl-rail", "l": [["linear-gradient(90deg,transparent 0 10%,#4A3424 10% 22%,transparent 22% 33.3%)", 1, 1, 0, 0], ["linear-gradient(transparent 28%,#8A9098 28% 34%,transparent 34% 66%,#8A9098 66% 72%,transparent 72%)", 1, 1, 0, 0]], "c": "#5E5850", "i": true}, {"s": ".z-basement .map .tile.f,.z-basement .map .tile.r,.z-basement .map .tile.f.bm-flag", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["radial-gradient(ellipse at 50% 50%,rgba(0,0,0,.08) 0 18%,transparent 19.5%)", 2.9, 2.3, 0, 0], ["radial-gradient(ellipse at 40% 60%,rgba(255,255,255,.04) 0 14%,transparent 15.5%)", 3.7, 3.1, 1.3, 0.8]], "c": "#57504A", "i": true}, {"s": ".z-basement .map .tile.f.bm-board", "l": [["linear-gradient(#553F2A 0 1.5px,transparent 1.5px)", 1, 0.33, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#553F2A 270deg)", 3.8, 0.66, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#553F2A 270deg)", 3.8, 0.66, 1.9, 0.33], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#553F2A 270deg)", 6.27, 0.99, 1.045, 0.66], ["linear-gradient(#76593C 50%,#6E5236 50%)", 1, 0.66, 0, 0]], "c": "#76593C", "i": true}, {"s": ".z-basement .map .tile.f.bm-earth", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 4.8%,transparent 6.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.22) 0 4.2%,transparent 5.4%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.22) 0 2.6%,transparent 3.6%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 4.2%,transparent 5.4%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.22) 0 3.6%,transparent 4.8%)", 1.61, 2.37, 0, 0]], "c": "#4C4336", "i": true}, {"s": ".z-basement .map .tile.f.bm-damp", "l": [["radial-gradient(circle at 30% 40%,rgba(150,180,180,.1) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(150,180,180,.1) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["radial-gradient(ellipse at 50% 50%,rgba(120,150,150,.14) 0 22%,transparent 23.5%)", 2.7, 2.1, 0, 0], ["radial-gradient(ellipse at 30% 60%,rgba(120,150,150,.1) 0 16%,transparent 17.5%)", 3.9, 3.3, 1.2, 0.7]], "c": "#3C3830", "i": true}, {"s": ".z-basement .map .tile.f.bm-haz", "l": [["linear-gradient(45deg,#8A7428 25%,#2E2E2C 25% 50%,#8A7428 50% 75%,#2E2E2C 75%)", 0.56, 0.56, 0, 0]], "c": "#2E2E2C", "i": true}, {"s": ".z-basement .map .tile.f.bm-rag", "l": [["linear-gradient(#8A5A4A 0 25%,#5A6A7A 25% 50%,#9A8A5A 50% 75%,#6A7A5A 75%)", 1, 0.53, 0, 0], ["radial-gradient(circle at 30% 40%,rgba(255,255,255,.08) 0 2.8%,transparent 3.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.12) 0 2.4%,transparent 3.1%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.12) 0 1.5%,transparent 2.1%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.08) 0 2.4%,transparent 3.1%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.12) 0 2.1%,transparent 2.8%)", 1.61, 2.37, 0, 0]], "c": "#8A5A4A", "i": true}, {"s": ".z-basement .map .tile.f.bm-steel", "l": [["linear-gradient(45deg,transparent 40%,rgba(200,210,220,.35) 40% 60%,transparent 60%)", 0.21, 0.21, 0, 0], ["linear-gradient(-45deg,transparent 40%,rgba(200,210,220,.35) 40% 60%,transparent 60%)", 0.21, 0.21, 0.105, 0.105]], "c": "#5E666E", "i": true}, {"s": ".z-basement .map .tile.f.bm-rug", "l": [["linear-gradient(45deg,rgba(200,160,90,.18) 17%,transparent 17% 50%,rgba(200,160,90,.18) 50% 67%,transparent 67%)", "17px", "17px", 0, 0], ["linear-gradient(-45deg,rgba(200,160,90,.18) 17%,transparent 17% 50%,rgba(200,160,90,.18) 50% 67%,transparent 67%)", "17px", "17px", 0, 0]], "c": "#6E2C28", "i": true}, {"s": ".z-basement .map .tile.f.bm-oak", "l": [["linear-gradient(90deg,#3E2C1E 0 1.5px,transparent 1.5px)", 0.23, 1, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3E2C1E 270deg)", 0.46, 3.4, 0, 0], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3E2C1E 270deg)", 0.46, 3.4, 0.23, 1.7], ["conic-gradient(from 0deg at 50% 1.5px,transparent 0 270deg,#3E2C1E 270deg)", 0.6900000000000001, 5.609999999999999, 0.46, 0.935], ["linear-gradient(90deg,#5E4632 50%,#5A4230 50%)", 0.46, 1, 0, 0]], "c": "#5E4632", "i": true}, {"s": ".z-mine .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-scrap .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-volcano .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-vault .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-reactor .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-glacier .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-crater .map .tile.w:not(.wtop)::after", "l": [["radial-gradient(ellipse at 50% 55%,var(--wall-bump) 0 38%,transparent 41%)", 0.92, 0.5, 0, -0.16], ["radial-gradient(ellipse at 50% 50%,var(--wall-bump) 0 34%,transparent 37%)", 1.37, 0.46, 0.4, 0.09], ["radial-gradient(ellipse at 40% 50%,var(--wall-bump) 0 30%,transparent 33%)", 0.71, 0.42, 0.2, -0.04000000000000001]], "c": "transparent", "i": true, "after": 1}, {"s": ":where(.map) .tile.w.wtop", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.16) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.16) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.16) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["linear-gradient(rgba(0,0,0,.32),rgba(0,0,0,.32))", 1, 1, 0, 0]], "c": "var(--wall)", "i": false}, {"s": ".z-slag .map .tile.w.sl-rock", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.05) 0 4.0%,transparent 5.0%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.25) 0 3.5%,transparent 4.5%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.25) 0 2.2%,transparent 3.0%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.05) 0 3.5%,transparent 4.5%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.25) 0 3.0%,transparent 4.0%)", 1.61, 2.37, 0, 0], ["linear-gradient(135deg,transparent 46%,rgba(0,0,0,.22) 47% 49%,transparent 50%)", 1.7, 1.3, 0, 0], ["linear-gradient(60deg,transparent 46%,rgba(0,0,0,.18) 47% 48.5%,transparent 50%)", 2.3, 1.9, 0.9, 0.6]], "c": "#34322F", "i": true}, {"s": ".z-slag .map .tile.w.sl-brick:not(.wtop):not(.sl-union)", "l": [["linear-gradient(#2A1E18 0 16%,transparent 16%)", 1, 1, 0, 0], ["linear-gradient(#3A2018 0 1.5px,transparent 1.5px)", 1, 0.155, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#3A2018 270deg)", 0.48, 0.31, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#3A2018 270deg)", 0.48, 0.31, 0.24, 0.155]], "c": "#7A4A34", "i": true}, {"s": ".z-slag .map .tile.w.sl-union:not(.wtop)", "l": [["linear-gradient(#2A1E18 0 16%,transparent 16%)", 1, 1, 0, 0], ["linear-gradient(transparent 70%,#FF7A1A 70% 78%,transparent 78%)", 1, 1, 0, 0], ["linear-gradient(#3A2018 0 1.5px,transparent 1.5px)", 1, 0.155, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#3A2018 270deg)", 0.48, 0.31, 0, 0], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,#3A2018 270deg)", 0.48, 0.31, 0.24, 0.155]], "c": "#7A4A34", "i": true}, {"s": ".z-basement .map .tile.w:not(.wtop)::after", "l": [["linear-gradient(rgba(0,0,0,.35) 0 1.5px,transparent 1.5px)", 1, 0.14, 0, -0.22], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,rgba(0,0,0,.35) 270deg)", 0.46, 0.28, 0, -0.22], ["conic-gradient(from 0deg at 1.5px 50%,transparent 0 270deg,rgba(0,0,0,.35) 270deg)", 0.46, 0.28, 0.23, -0.07999999999999999]], "c": "transparent", "i": true, "after": 1}, {"s": ".z-reactor .map .tile.w:not(.wtop)", "l": [["linear-gradient(transparent 0 22%,var(--wall) 22%)", 1, 1, 0, 0], ["linear-gradient(45deg,#E0B820 25%,#1E2420 25% 50%,#E0B820 50% 75%,#1E2420 75%)", "14px", "14px", 0, 0]], "c": "var(--wall)", "i": true}, {"s": ".z-basement .map .tile.f.bm-chk", "l": [["radial-gradient(circle at 30% 40%,rgba(255,255,255,.06) 0 3.6%,transparent 4.5%)", 1.37, 1.19, 0, 0], ["radial-gradient(circle at 70% 25%,rgba(0,0,0,.2) 0 3.1%,transparent 4.0%)", 0.83, 1.07, 0, 0], ["radial-gradient(circle at 25% 75%,rgba(0,0,0,.2) 0 2.0%,transparent 2.7%)", 2.21, 1.73, 0, 0], ["radial-gradient(circle at 60% 60%,rgba(255,255,255,.06) 0 3.1%,transparent 4.0%)", 1.03, 0.71, 0, 0], ["radial-gradient(circle at 45% 15%,rgba(0,0,0,.2) 0 2.7%,transparent 3.6%)", 1.61, 2.37, 0, 0]], "c": "#6E6A60", "i": true}];
function floorCSS(tp){const dpr=window.devicePixelRatio||1,px=k=>Math.max(1,Math.round(k*tp*dpr))/dpr,sz=v=>typeof v==="string"?(/^[\d.]+px$/.test(v)?Math.max(1,Math.round(parseFloat(v)*dpr))/dpr+"px":v):px(v)+"px";
  floorCSS.sig={};return FLOOR_TEX.map((r,ri)=>{const I=r.i?"!important":"";
    const imgs=r.l.map(l=>l[0]).join(","),sizes=r.l.map(l=>sz(l[1])+" "+sz(l[2])).join(","),
      pos=r.l.map(l=>(l[3]||l[4])?`calc(var(--wpx) + ${Math.round(l[3]*tp*dpr)/dpr}px) calc(var(--wpy) + ${Math.round(l[4]*tp*dpr)/dpr}px)`:"var(--wpx) var(--wpy)").join(",");
    return `${r.s}{${r.after?"inset:22% 0 0 0!important;border-radius:0!important;":""}background-image:${imgs}${I};background-size:${sizes}${I};background-position:${pos}${I};background-repeat:repeat${I};background-color:${r.c}${I}${r.after?"":";filter:none;--mat:"+(floorCSS.sig[ri]=sizes.replace(/\s+/g,""),ri)}${r.i&&!r.after?";box-shadow:none":""}}`}).join("\n")}
function floorTex(tp){if(!tp)return;if(floorTex.tp===tp&&floorTex.dpr===window.devicePixelRatio)return;floorTex.tp=tp;floorTex.dpr=window.devicePixelRatio;
  let st=document.getElementById("floortex");if(!st){st=document.createElement("style");st.id="floortex";document.head.appendChild(st)}st.textContent=floorCSS(tp)}
{const _sw=snapWorld;snapWorld=function(){_sw();const w=$("#world");if(w)floorTex(parseFloat(w.style.getPropertyValue("--tp")))}}

/* =============== WATER, LAVA AND GOO WITHOUT A GRID ===============
   Each pool used to be painted one tile at a time with the same little picture, so every tile had the same ring or streak in the
   same place and the whole pool read as a grid. Now each kind of liquid gets one large, seamless, hand-scattered texture that is laid
   across the whole map and drifts as one body, the way water does. */
const WSTY={
 "z-wreck|lq":{k:[3.3,2.7],dur:16,it:[["ring","rgba(255,255,255,.2)",10,.06,.12],["arc","rgba(255,255,255,.16)",12,.14,.26],["dot","rgba(255,255,255,.12)",8,.015,.03]]},
 "z-wreck|sh":{k:[2.9,2.3],dur:12,it:[["streak","rgba(255,255,255,.3)",14,.18,.4,-12],["dot","rgba(255,255,255,.22)",8,.015,.03]]},
 "z-mine|lq":{k:[3.1,2.5],dur:14,it:[["streak","rgba(255,255,255,.1)",14,.2,.5,-20],["dot","rgba(255,255,255,.08)",6,.02,.04]]},
 "z-mine|sh":{k:[2.7,2.1],dur:12,it:[["streak","rgba(255,255,255,.22)",12,.15,.35,-15]]},
 "z-glacier|lq":{k:[3.7,2.9],dur:20,it:[["streak","rgba(255,255,255,.5)",9,.25,.6,35],["streak","rgba(255,255,255,.35)",7,.2,.5,-20],["dot","rgba(255,255,255,.3)",8,.015,.03]]},
 "z-glacier|sh":{k:[2.9,2.3],dur:14,it:[["streak","rgba(255,255,255,.3)",12,.15,.35,-15]]},
 "z-volcano|lq":{k:[3.1,2.6],dur:18,it:[["blob","rgba(255,236,150,.55)",9,.08,.2],["blob","rgba(255,210,80,.45)",9,.1,.24],["blob","rgba(70,20,6,.35)",8,.06,.14],["dot","rgba(255,250,210,.7)",10,.015,.03]]},
 "z-reactor|lq":{k:[2.9,2.4],dur:14,it:[["ring","rgba(255,255,255,.45)",10,.03,.07],["dot","rgba(255,255,255,.4)",12,.015,.035],["blob","rgba(220,255,160,.3)",6,.1,.2]]},
 "z-crater|lq":{k:[3.3,2.7],dur:16,it:[["dot","rgba(255,255,255,.55)",12,.01,.025],["dot","rgba(190,230,255,.5)",10,.01,.025],["blob","rgba(190,160,255,.22)",6,.12,.24]]},
 "z-scrap|lq":{k:[3.5,2.8],dur:22,it:[["sheen","",7,.14,.3],["streak","rgba(150,180,200,.12)",10,.2,.45,-20]]},
 "z-basement|lq":{k:[3.1,2.5],dur:16,it:[["ring","rgba(200,220,210,.14)",10,.05,.12]]},
 "z-reactor|sh":{k:[2.9,2.3],dur:12,it:[["streak","rgba(255,255,255,.26)",12,.15,.35,-15],["dot","rgba(255,255,255,.18)",6,.015,.03]]},
 "*|sh":{k:[2.9,2.3],dur:12,it:[["streak","rgba(255,255,255,.26)",12,.15,.35,-15]]},
 "*|lq":{k:[3.1,2.5],dur:14,it:[["streak","rgba(255,255,255,.12)",12,.2,.45,-20],["dot","rgba(255,255,255,.1)",6,.015,.03]]},
 "z-slag|pond":{k:[3.3,2.6],dur:18,it:[["blob","rgba(150,120,220,.16)",7,.05,.1],["blob","rgba(90,200,180,.14)",7,.05,.1],["streak","rgba(255,255,255,.08)",8,.25,.5,-20]]}
};
function wtTexture(sty,T,seed){const R=mulberry(seed),sw=Math.max(8,Math.round(sty.k[0]*T)),sh=Math.max(8,Math.round(sty.k[1]*T)),cv=document.createElement("canvas");cv.width=sw;cv.height=sh;const x=cv.getContext("2d");
  const lw=Math.max(1,T*.035);
  for(const [type,col,n,r0,r1,ang] of sty.it)for(let i=0;i<n;i++){const px=R()*sw,py=R()*sh,r=(r0+R()*(r1-r0))*T,a=((ang||0)+(R()-.5)*20)*Math.PI/180;
    for(const dx of [-sw,0,sw])for(const dy of [-sh,0,sh]){const cx=px+dx,cy=py+dy;if(cx<-r*2-T||cy<-r*2-T||cx>sw+r*2+T||cy>sh+r*2+T)continue;x.save();
      if(type==="ring"){x.strokeStyle=col;x.lineWidth=lw;x.beginPath();x.arc(cx,cy,r,0,6.283);x.stroke()}
      else if(type==="arc"){x.strokeStyle=col;x.lineWidth=lw;x.beginPath();x.ellipse(cx,cy,r,r*.45,0,Math.PI*1.1,Math.PI*1.9);x.stroke()}
      else if(type==="streak"){x.strokeStyle=col;x.lineWidth=lw;x.lineCap="round";x.beginPath();x.moveTo(cx-Math.cos(a)*r/2,cy-Math.sin(a)*r/2);x.lineTo(cx+Math.cos(a)*r/2,cy+Math.sin(a)*r/2);x.stroke()}
      else if(type==="dot"){x.fillStyle=col;x.beginPath();x.arc(cx,cy,Math.max(.8,r),0,6.283);x.fill()}
      else if(type==="blob"){x.fillStyle=col;x.beginPath();x.ellipse(cx,cy,r,r*.62,a,0,6.283);x.fill()}
      else if(type==="sheen"){const g=x.createRadialGradient(cx,cy,0,cx,cy,r);g.addColorStop(0,"rgba(190,90,220,.32)");g.addColorStop(.45,"rgba(80,200,190,.26)");g.addColorStop(.75,"rgba(240,200,80,.16)");g.addColorStop(1,"rgba(240,200,80,0)");x.fillStyle=g;x.beginPath();x.ellipse(cx,cy,r*1.6,r*.6,a,0,6.283);x.fill()}
      x.restore()}}
  return cv}
waterScan=function(){WT.gen++;WT.tiles=[];const m=$("#map");if(!m||!EXP.W||!EXP.zone)return;const T=m.children,z=EXP.zone.cls;
  for(let i=0;i<T.length;i++){const t=T[i],c=t.className;const kind=/\bsl-pond\b/.test(c)?"pond":/\blq\b/.test(c)?"lq":/\bsh\b/.test(c)?"sh":null;if(!kind)continue;let k=z+"|"+kind;if(!WSTY[k])k="*|"+kind;if(!WSTY[k])continue;
    WT.tiles.push({i,x:i%EXP.W,y:(i/EXP.W)|0,k,el:t});t.classList.add("wcv")}
  if(WT.tiles.length&&!SPK.run&&SPK.cv){SPK.run=true;requestAnimationFrame(spkDraw)}};
waterDraw=function(c,T,t,reduce){if(!WT.tiles.length)return;const kinds={};
  /* every pool of one kind is filled in a single stroke of the brush */
  for(const w of WT.tiles){if(w.x<SPK.ox-1||w.y<SPK.oy-1||w.x>SPK.ox+SPK.w||w.y>SPK.oy+SPK.h)continue;const sty=WSTY[w.k];if(!sty)continue;
    let K=kinds[w.k];if(!K){let tex=WT.pats[w.k];if(!tex||tex.T!==T){tex=WT.pats[w.k]={T,cv:wtTexture(sty,T,[...w.k].reduce((a,ch)=>a*31+ch.charCodeAt(0)|0,7))};tex.pat=c.createPattern(tex.cv,"repeat")}
      const f=reduce?0:(t%sty.dur)/sty.dur,sw=tex.cv.width,shh=tex.cv.height;
      tex.pat.setTransform(new DOMMatrix().translate(-(SPK.ox*T)+f*sw,-(SPK.oy*T)+f*shh*.35));K=kinds[w.k]={pat:tex.pat,path:new Path2D()}}
    const x0=Math.round((w.x-SPK.ox)*T),y0=Math.round((w.y-SPK.oy)*T),x1=Math.round((w.x+1-SPK.ox)*T),y1=Math.round((w.y+1-SPK.oy)*T);
    SPK.dirty.push([x0,y0,x1-x0,y1-y0]);c.clearRect(x0,y0,x1-x0,y1-y0);K.path.rect(x0,y0,x1-x0,y1-y0)}
  for(const k in kinds){c.fillStyle=kinds[k].pat;c.fill(kinds[k].path)}};
addEventListener("resize",()=>{WT.pats={}});

/* =============== ONE SHEET PER FLOOR MATERIAL ===============
   The continuous floor textures used to be drawn tile by tile: every tile repainted ten layers of pattern, and every chunk picture had
   to redraw them all again. Now each material (sand, concrete, snow, slabs...) is one sheet laid under the whole map, cut to the shape
   of the tiles that use it, and painted once. The tiles above it go see-through. Same pixels, a fraction of the work. */
const MAT={divs:[],sig:""};
function matClear(){MAT.divs.forEach(d=>d.remove());MAT.divs=[];document.querySelectorAll("#map .tile.mtx,#map .tile.nr,#map .tile.nb").forEach(t=>t.classList.remove("mtx","nr","nb"));MAT.sig=""}
function matBuild(){const m=$("#map"),w=$("#world");if(!m||!w||!EXP.W||S.phase!=="explore")return;const tp=parseFloat(w.style.getPropertyValue("--tp"));if(!tp)return;
  const sig=EXP.zone.cls+"|"+(EXP.zone.special||"")+"|"+tp+"|"+(window.devicePixelRatio||1)+"|"+m.childElementCount;if(sig===MAT.sig&&MAT.divs.length)return;
  matClear();document.querySelectorAll("#map .tile[data-mk]").forEach(t=>delete t.dataset.mk);const groups=new Map(),T=m.children;
  /* tiles that look alike share one style lookup: dozens of lookups instead of thousands */
  const look=new Map();
  for(let i=0;i<T.length;i++){const t=T[i];if(t.dataset.x==null)continue;const gx=+t.dataset.x,gy=+t.dataset.y,ck=t.className.replace(/\b(cull|still|baked|bkf|rustle|mtx|nr|nb)\b/g,"")+"|"+(t.dataset.e||"");
    let L=look.get(ck);
    if(L===undefined){const cs=getComputedStyle(t);
      const mi=cs.getPropertyValue("--mat").trim(),sg=floorCSS.sig&&floorCSS.sig[mi];
      /* the tile must really be wearing that material: another rule may have won its background */
      if(cs.backgroundImage==="none"||!sg||cs.backgroundSize.replace(/\s+/g,"")!==sg)L=null;
      else{const P=cs.backgroundPosition.split(",").map(s=>s.trim().split(/\s+/).map(parseFloat));
        const ox=P.map(p=>p[0]+gx*tp),oy=P.map(p=>p[1]+gy*tp);
        L=ox.some(isNaN)||oy.some(isNaN)?null:{img:cs.backgroundImage,size:cs.backgroundSize,col:cs.backgroundColor,pos:ox.map((x,k)=>`${+x.toFixed(2)}px ${+oy[k].toFixed(2)}px`).join(",")}}
      look.set(ck,L)}
    if(!L)continue;const key=L.img+"|"+L.size+"|"+L.col+"|"+L.pos;
    let g=groups.get(key);if(!g){g={...L,tiles:[]};groups.set(key,g)}g.tiles.push([gx,gy,t]);t.dataset.mk=key}
  const W=EXP.W*tp,H=EXP.H*tp;
  groups.forEach(g=>{if(g.tiles.length<2)return;const d=document.createElement("div");d.className="matsheet";
    const path=g.tiles.map(([x,y])=>`M${+(x*tp).toFixed(2)} ${+(y*tp).toFixed(2)}h${tp+1}v${tp+1}h${-tp-1}z`).join("");
    d.style.cssText=`position:absolute;left:0;top:0;width:${W}px;height:${H}px;pointer-events:none;background-image:${g.img};background-size:${g.size};background-position:${g.pos};background-repeat:repeat;background-color:${g.col};clip-path:path('${path}')`;
    m.parentNode.insertBefore(d,m.parentNode.querySelector("img.bake")||m);MAT.divs.push(d);g.tiles.forEach(([, ,t])=>t.classList.add("mtx"))});
  /* tiles next to a sheet stop overhanging by a pixel: the sheet already runs a pixel under them */
  const TT=chunkTiles(),isM=(x,y)=>{const t=TT[y*CH.W+x];return t&&t.classList.contains("mtx")};
  for(let y=0;y<EXP.H;y++)for(let x=0;x<EXP.W;x++){const t=TT[y*CH.W+x];if(!t)continue;t.classList.toggle("nr",!!isM(x+1,y));t.classList.toggle("nb",!!isM(x,y+1))}
  MAT.sig=sig;if(typeof bkReset==="function"&&BK.imgs.length){bkReset();setTimeout(()=>{if(S.phase==="explore")bkQueue([...CH.live])},200)}}
{const _sw=snapWorld;snapWorld=function(){_sw();matBuild()}}
{const _se=startExplore;startExplore=function(){matClear();_se()}}
/* a tile that changes (a rubble pile picked clean) keeps its place in the sheet if its floor is still the same material */
{const _mo=markOpened;markOpened=function(x,y){const T=chunkTiles(),t=T&&T[y*CH.W+x];const k=t&&t.dataset.mk;_mo(x,y);if(!t||!k)return;
  t.classList.remove("mtx");const cs=getComputedStyle(t);const P=cs.backgroundPosition.split(",").map(s=>s.trim().split(/\s+/).map(parseFloat)),tp=parseFloat($("#world").style.getPropertyValue("--tp"));
  const pos=P.map(p=>`${+(p[0]+x*tp).toFixed(2)}px ${+(p[1]+y*tp).toFixed(2)}px`).join(",");
  if(floorCSS.sig&&floorCSS.sig[cs.getPropertyValue("--mat").trim()]&&cs.backgroundImage+"|"+cs.backgroundSize+"|"+cs.backgroundColor+"|"+pos===k)t.classList.add("mtx");else delete t.dataset.mk}}

/* =============== QUIET FOR THE BIG MOMENTS ===============
   The background music steps aside when a quest is completed, so the completion fanfare is heard clearly, and stays silent for the
   whole promotion ceremony, which now has its own rank-up jingle. It fades out and back in rather than cutting, and picks up exactly
   where it left off. */
const MUS_VOL=.55,MUS_HOLD=new Set();
function musFade(){const target=MUS_HOLD.size?0:MUS_VOL,m=AU.music;if(!m)return;clearInterval(musFade.iv);
  musFade.iv=setInterval(()=>{const v=m.volume,d=target-v;if(Math.abs(d)<.03){m.volume=target;clearInterval(musFade.iv);return}m.volume=Math.max(0,Math.min(1,v+Math.sign(d)*.06))},25)}
function musHold(k){MUS_HOLD.add(k);musFade()}
function musRelease(k){if(MUS_HOLD.delete(k))musFade()}
/* a promotion gets its own jingle: brass-band rising, a held top note, and a drum-roll finish */
SFX.promote=()=>melody("C5 E5 G5 C6 - G5 C6 E6 - - G6 - - E6 F6 G6 A6 - - G6 - - C7 - - - - - -",.085,{vol:.12},"C3 . . . G2 . . . C3 . . . F2 . . . G2 . . . C3 - - - - - - -");
{const _sfx=sfx;sfx=function(name){
  if(name==="fanfare"&&CS.on&&CS.promo){name="promote"}
  const playing=AU.on&&AU.sfxOn&&SFX[name];_sfx(name);
  if(playing&&(name==="fanfare"||name==="promote")){const ms=((AU.dur&&AU.dur[name])||2.4)*1000+350;musHold("sfx:"+name);clearTimeout(sfx["t_"+name]);sfx["t_"+name]=setTimeout(()=>musRelease("sfx:"+name),ms)}}}
/* the music stays down for the whole ceremony, from the first fade to the walk back out */
{const _ps=playScene;playScene=function(id,after){if(!/^promo\d+$/.test(id)||!SCENES[id])return _ps(id,after);
  musHold("promo");CS.promo=true;
  return _ps(id,()=>{CS.promo=false;setTimeout(()=>musRelease("promo"),400);after&&after()})}}
/* a skipped or broken scene can never leave the music stuck at silence */
{const _ce=csEnd;csEnd=function(){_ce();if(!CS.on&&MUS_HOLD.has("promo")&&!CS.promo)musRelease("promo")}}

/* =============== THE EAST WING: Dr. A.'s acoustics lab ===============
   The Institute grows a new wing off the old lab: the lab where Dr. A. works, the quiet room she listens in, and her sample store.
   Everything is added to the east, so nothing already on the map moves. */
const EWING={x0:56,w:14,
 rows:{
  1:"VVVVVVVVVVVVV#",
  2:"VZ.........ZV#",
  3:"V...........V#",
  4:"V...........V#",
  5:"V.....U.....V#",
  6:"V.....C.....V#",
  7:"V...........V#",
  8:"V...........V#",
  9:"V...........V#",
  10:"VZ.........ZV#",
  11:"VVVVV.VVVVVVV#",
  12:"#####.########",
  13:"xxxZ..Q..Zxxx#",
  14:"S............#",
  15:".HH.......HH.#",
  16:".............#",
  17:"y...........y#",
  18:".....J.......#",
  19:".............#",
  20:".HH.......HH.#",
  21:".............#",
  22:"y....x.x....y#",
  23:"######.#######",
  24:"xx.c.....c.xx#",
  25:".............#",
  26:".,,,.....,,,.#",
  27:".,,,.....,,,.#",
  28:".............#",
  29:"..c.......c..#",
  30:".,,,.....,,,.#",
  31:"S............#",
  32:"y...........y#"}};
function eastWing(map){if(!map||map[0].length!==56)return map;
  return map.map((r,y)=>{let add=EWING.rows[y]||"#".repeat(EWING.w);
    /* a door from the old lab into the new one */
    if(y===18)r=r.slice(0,55)+".";
    return r+add})}
if(typeof MAPS!=="undefined"&&MAPS["z-quill"])MAPS["z-quill"]=eastWing(MAPS["z-quill"]);
{const Z=ZONES.find(z=>z.cls==="z-quill");if(Z&&Z.map)Z.map=eastWing(Z.map)}
const inAcoustic=(x,y)=>x>=56&&x<=68&&y>=1&&y<=22,inAStore=(x,y)=>x>=56&&x<=68&&y>=24&&y<=32;

/* ---- her furniture ---- */
const APROPS={
 /* foam wedges: the quiet room is lined with them, floor to ceiling */
 V:{tall:1,svg:`<rect x="0" y="0" width="40" height="40" fill="#3A3E48"/>${[0,10,20,30].map((x,i)=>[0,10,20,30].map((y,j)=>(i+j)%2?`<path d="M${x} ${y} L${x+5} ${y+5} L${x+10} ${y} M${x} ${y+10} L${x+5} ${y+5} L${x+10} ${y+10}" fill="#2C2F37" stroke="#4E5360" stroke-width=".7"/>`:`<path d="M${x} ${y} L${x+5} ${y+5} L${x} ${y+10} M${x+10} ${y} L${x+5} ${y+5} L${x+10} ${y+10}" fill="#2C2F37" stroke="#4E5360" stroke-width=".7"/>`).join("")).join("")}`},
 /* one chair */
 C:{svg:`<rect x="13" y="8" width="14" height="13" rx="2" fill="#5A4A44" stroke="#2A2220" stroke-width="1.1"/><rect x="12" y="20" width="16" height="5" rx="1.5" fill="#6A5850" stroke="#2A2220" stroke-width="1.1"/><path d="M14 25 V35 M26 25 V35" stroke="#2A2220" stroke-width="1.6"/>`},
 /* a microphone on a stand, pointed at the chair */
 U:{svg:`<path d="M20 34 V14" stroke="#4A4E58" stroke-width="1.4"/><path d="M14 35 L20 33 L26 35" stroke="#4A4E58" stroke-width="1.4" fill="none"/><rect x="17.6" y="5" width="4.8" height="10" rx="2.4" fill="#C9CED4" stroke="#2A2E34" stroke-width="1"/><path d="M17.8 8 H22.2 M17.8 10 H22.2 M17.8 12 H22.2" stroke="#8E949B" stroke-width=".5"/>`},
 /* a tall cabinet speaker with a cloth front */
 Z:{tall:1,svg:`<rect x="9" y="2" width="22" height="33" rx="1.5" fill="#2E3038" stroke="#15161A" stroke-width="1.3"/><rect x="11" y="4" width="18" height="29" rx="1" fill="#4A4C56"/>${[6,9,12,15,18,21,24,27,30].map(y=>`<path d="M11.5 ${y} H28.5" stroke="#3A3C44" stroke-width=".6"/>`).join("")}<circle cx="20" cy="11" r="5" fill="#3A3C44" stroke="#1E1F24" stroke-width=".8"/><circle cx="20" cy="11" r="1.8" fill="#24252B"/><circle cx="20" cy="24.5" r="6.4" fill="#3A3C44" stroke="#1E1F24" stroke-width=".8"/><circle cx="20" cy="24.5" r="2.4" fill="#24252B"/><rect x="18" y="33" width="4" height="1.4" fill="#C8CDD4"/>`},
 /* an oscilloscope trolley: a little green screen with one flat line on it */
 Q:{svg:`<rect x="5" y="22" width="30" height="4" fill="#9AA2AC" stroke="#3A4048" stroke-width="1.1"/><rect x="7" y="26" width="2.6" height="8" fill="#6A7280"/><rect x="30.4" y="26" width="2.6" height="8" fill="#6A7280"/><circle cx="8.3" cy="34.6" r="1.2" fill="#2A2E34"/><circle cx="31.7" cy="34.6" r="1.2" fill="#2A2E34"/><rect x="8" y="7" width="24" height="15" rx="1.5" fill="#C8CCD2" stroke="#3A4048" stroke-width="1.2"/><rect x="10" y="9" width="14" height="11" rx="1" fill="#14261C" stroke="#3A4048" stroke-width=".7"/><path d="M10.6 14.5 H23.4" stroke="#6CF0A0" stroke-width=".7"/><path d="M14 9 V20 M17.5 9 V20 M21 9 V20 M10 12 H24 M10 17 H24" stroke="#2A4A36" stroke-width=".35"/>${[[27.5,11],[27.5,15],[27.5,19]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.3" fill="#3A4048"/><path d="M${x} ${y} l.8 -.8" stroke="#E8ECF0" stroke-width=".4"/>`).join("")}`},
 /* a bench with a rack of sealed sample vials */
 H:{svg:`<rect x="2" y="18" width="36" height="5" fill="#D8DCE2" stroke="#4A5058" stroke-width="1.1"/><rect x="4" y="23" width="3" height="12" fill="#8A929C"/><rect x="33" y="23" width="3" height="12" fill="#8A929C"/><rect x="6" y="15" width="18" height="3" rx=".6" fill="#6A7280" stroke="#3A4048" stroke-width=".6"/>${[8,11.5,15,18.5].map((x,i)=>`<rect x="${x}" y="8" width="2.4" height="8" rx="1" fill="rgba(215,230,240,.75)" stroke="#5A6A7A" stroke-width=".5"/><rect x="${x}" y="${12+i%2}" width="2.4" height="${3.6-i%2}" fill="${["#B8B6A8","#9EA6A2","#C2BAA4","#A8AEB0"][i]}"/><rect x="${x-.2}" y="7" width="2.8" height="1.4" fill="#2E3440"/>`).join("")}<rect x="27" y="11" width="8" height="7" rx="1" fill="#F4F0E4" stroke="#8A8272" stroke-width=".6"/><path d="M28.4 13.2 H33.6 M28.4 15 H32" stroke="#8A8272" stroke-width=".5"/>`},
 /* a glovebox: a sealed glass case with two black gloves reaching in */
 J:{svg:`<rect x="3" y="24" width="34" height="3" fill="#8A929C" stroke="#3A4048" stroke-width="1"/><rect x="5" y="27" width="3" height="8" fill="#6A7280"/><rect x="32" y="27" width="3" height="8" fill="#6A7280"/><path d="M4 24 V10 Q4 7 7 7 H33 Q36 7 36 10 V24 Z" fill="rgba(200,220,232,.55)" stroke="#3A4048" stroke-width="1.2"/><circle cx="13" cy="18" r="3.4" fill="#1E2024" stroke="#3A4048" stroke-width=".8"/><circle cx="27" cy="18" r="3.4" fill="#1E2024" stroke="#3A4048" stroke-width=".8"/><path d="M13 18 Q15 13 18 13 M27 18 Q25 13 22 13" stroke="#1E2024" stroke-width="2.4" fill="none" stroke-linecap="round"/><rect x="18" y="11" width="4" height="5" rx="1" fill="rgba(230,236,240,.85)" stroke="#5A6A7A" stroke-width=".5"/><path d="M8 9 L12 9" stroke="#FFFFFF" stroke-width=".8" opacity=".6"/><rect x="30" y="8.4" width="4" height="2" rx=".5" fill="#E0B820" stroke="#6A5410" stroke-width=".4"/>`}};
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const z=EXP.zone;if(z.cls!=="z-quill"||z.special||!(inAcoustic(x,y)||inAStore(x,y)))return _tl(c,x,y,seed,M);
  const src=APROPS[c];if(src)return[(src.tall?"f tl":"f pr")+" alab",PS(src.svg)];
  const r=_tl(c,x,y,seed,M);if(r&&/^f\b/.test(r[0])&&inAcoustic(x,y))r[0]+=" alab";return r}}

/* ---- the signs ---- */
Object.assign(SIGNS["z-quill"],{
 "56,14":["ACOUSTICS. Dr. A.","Quiet, please. This is not a request."],
 "56,31":["SAMPLE STORE. Dr. A.","Everything on these shelves is sealed. Everything that fell off the shelves is your problem now."]});

{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z||z.cls!=="z-quill"||z.special)return;
  EXP.objs.push({x:62,y:6,tile:1,use:()=>talk("",["One chair, in a room lined with foam. The microphone in front of it is pointed at whoever sits down.","You sit. After a while you can hear your own heartbeat, and then something like a hum that might be your own ears.","You get up again rather quickly."])})}}

/* ---- Dr. A. ---- */
function drASVG(){
  const ink=PI_K,hair="#3E2619",hl="#7A5038",hd="#22140C",skin="#E2B38C",sk2="#C58E68",cardi="#BE8B95",cd="#9A6672",tee="#F2EBDD";
  /* a soft outline made of little bulges, so the curls read as one cloud and not a pile of balls */
  const cloud=(pts,b)=>{let d=`M${pts[0][0]} ${pts[0][1]}`;for(let i=0;i<pts.length;i++){const [x1,y1]=pts[i],[x2,y2]=pts[(i+1)%pts.length],mx=(x1+x2)/2,my=(y1+y2)/2,dx=x2-x1,dy=y2-y1,l=Math.hypot(dx,dy)||1,k=b*l;
      d+=` Q${(mx+dy/l*k).toFixed(2)} ${(my-dx/l*k).toFixed(2)} ${x2} ${y2}`}return d+"Z"};
  /* the whole mass of hair, wide at the cheeks and stopping at the shoulders */
  const mass=cloud([[20,2.2],[23.6,2.6],[26.8,4.2],[29.4,7],[30.8,10.4],[31.6,14],[31.8,17.4],[30.8,20.6],[28.6,22.6],[25.8,22.2],[24,20.4],[16,20.4],[14.2,22.2],[11.4,22.6],[9.2,20.6],[8.2,17.4],[8.4,14],[9.2,10.4],[10.6,7],[13.2,4.2],[16.4,2.6]],.42);
  const curl=(x,y,s,c,w)=>`<path d="M${x} ${y} a${1*s} ${1*s} 0 1 1 ${1.4*s} ${.9*s}" stroke="${c}" stroke-width="${w||.4}" fill="none" stroke-linecap="round" opacity=".75"/>`;
  let o=`<path d="${mass}" fill="${hair}" stroke="${ink}" stroke-width="1.2" stroke-linejoin="round"/>`;
  o+=[[10.4,9],[9.6,13.4],[9.8,17.6],[11.6,20.4],[28.2,9.4],[29.4,13.2],[29.2,17.4],[27.4,20.6],[12.6,5.6],[26,5.2]].map(([x,y],i)=>curl(x,y,1,i%2?hd:hl,.5)).join("");
  /* the body, from the shared figure: a pink knit cardigan over a cream tee */
  let body=personInner({skin,hair,hs:"bald",acc:[],coat:cardi,style:"cardigan",shirt:tee,legs:"#3A4258",shoes:"#2A2420",mouth:"flat",noblush:1});
  o+=body;
  /* the tee shows between the open fronts, with the word across it */
  o+=`<path d="M16.2 20.6 Q20 22 23.8 20.6 L23.6 31.9 L16.4 31.9 Z" fill="${tee}" stroke="${ink}" stroke-width=".5"/>`
    +`<text x="20" y="25.4" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="1.5" fill="#141414" textLength="5.8" lengthAdjust="spacingAndGlyphs">DREAMER</text>`
    +`<path d="M16 20.7 L16.3 31.9 M24 20.7 L23.7 31.9" stroke="${cd}" stroke-width="1.2"/>`
    +[22.4,24,25.6,27.2,28.8,30.4].map(y=>`<path d="M15.4 ${y} h1.2 M23.4 ${y} h1.2" stroke="${shade(cardi,.2)}" stroke-width=".35"/>`).join("")
    +[12.6,13.8,26.2,27.4].map(x=>`<path d="M${x} 22.4 V31.2" stroke="${cd}" stroke-width=".3" opacity=".55"/>`).join("")
    +`<path d="M11.2 30.6 H16 M24 30.6 H28.8" stroke="${cd}" stroke-width=".6" opacity=".7"/>`;
  /* her own face, drawn over the stock one */
  o+=`<ellipse cx="13.1" cy="13.8" rx="1" ry="1.4" fill="${skin}" stroke="${ink}" stroke-width=".7"/><ellipse cx="26.9" cy="13.8" rx="1" ry="1.4" fill="${skin}" stroke="${ink}" stroke-width=".7"/>`
    +`<path d="M13 12.6 Q13 6 20 6 Q27 6 27 12.6 Q27 20 20 20.2 Q13 20 13 12.6 Z" fill="${skin}" stroke="${ink}" stroke-width="1.4"/>`
    
    /* eyes: dark, steady, lids a little low. Not tired, not cross. Just looking. */
    +[17.5,22.5].map(x=>`<ellipse cx="${x}" cy="13.75" rx=".85" ry=".95" fill="#24170F"/><circle cx="${x+.3}" cy="13.45" r=".27" fill="#FFFFFF"/><path d="M${x-1.05} 13.05 Q${x} 12.75 ${x+1.05} 13.05" stroke="${ink}" stroke-width=".55" fill="none" stroke-linecap="round"/>`).join("")
    /* straight, level brows */
    +`<path d="M15.8 11.15 L18.9 11.25 M24.2 11.15 L21.1 11.25" stroke="${hd}" stroke-width=".8" stroke-linecap="round"/>`
    /* black rectangular frames */
    +`<rect x="15.3" y="11.95" width="4.3" height="3.45" rx=".45" fill="#FFFFFF" fill-opacity=".14" stroke="#121212" stroke-width=".8"/><rect x="20.4" y="11.95" width="4.3" height="3.45" rx=".45" fill="#FFFFFF" fill-opacity=".14" stroke="#121212" stroke-width=".8"/><path d="M19.6 12.9 Q20 12.6 20.4 12.9 M15.3 12.6 L13.6 12.4 M24.7 12.6 L26.4 12.4" stroke="#121212" stroke-width=".7" fill="none"/><path d="M15.9 12.6 l.7 -.01" stroke="#FFFFFF" stroke-width=".35" opacity=".8"/>`
    /* nose and a flat, closed mouth */
    +`<path d="M20.1 14.6 Q19.5 16 20 16.4 Q20.5 16.6 21 16.3" stroke="${sk2}" stroke-width=".6" fill="none" stroke-linecap="round"/>`
    +`<path d="M18.9 17.85 Q20 17.7 21.1 17.85" stroke="${ink}" stroke-width=".75" fill="none" stroke-linecap="round"/>`;
  /* curls falling in front: a fringe over the forehead and loose ringlets down each cheek */
  const fringe=cloud([[13,10.2],[13.2,7.2],[15.4,4.8],[18.4,3.8],[21.6,3.8],[24.6,4.8],[26.8,7.2],[27,10.2],[25.6,9],[24,9.8],[22.4,8.6],[20.6,9.6],[19,8.4],[17.2,9.6],[15.8,8.6],[14.4,9.6]],.32);
  o+=`<path d="${fringe}" fill="${hair}" stroke="${ink}" stroke-width="1" stroke-linejoin="round"/>`;
  const side=(s)=>{const X=x=>20+s*(x-20);return cloud([[X(12.6),8.6],[X(14.4),10],[X(14.6),13],[X(14.2),16],[X(14.6),18.8],[X(13.6),21],[X(11.8),20.8],[X(11.4),17.4],[X(11.2),13.4],[X(11.4),10.4]].map(([x,y])=>[+x.toFixed(2),y]),.34)};
  o+=[-1,1].map(s=>`<path d="${side(s)}" fill="${hair}" stroke="${ink}" stroke-width=".9" stroke-linejoin="round"/>`).join("");
  o+=[[15,7],[18.2,5.6],[21.4,5.4],[24.2,6.6],[12.2,12],[12.4,16.4],[27,12.2],[26.8,16.6],[16.6,8],[22.6,7.6]].map(([x,y],i)=>curl(x,y,.85,i%3?hl:hd)).join("");
  /* pale grey over-ear headphones, band over the curls, cups over the ears */
  o+=`<path d="M10.2 13.4 Q9.6 2.8 20 2.6 Q30.4 2.8 29.8 13.4" stroke="${ink}" stroke-width="2.3" fill="none" stroke-linecap="round"/><path d="M10.2 13.4 Q9.6 2.8 20 2.6 Q30.4 2.8 29.8 13.4" stroke="#CDD2D8" stroke-width="1.3" fill="none" stroke-linecap="round"/><path d="M14.6 4.6 Q20 2.9 25.4 4.6" stroke="#F4F6F8" stroke-width=".4" fill="none"/>`
    +[[10.1,-1],[29.9,1]].map(([x,s])=>`<ellipse cx="${x}" cy="15.2" rx="2.1" ry="2.9" fill="#C3C8CF" stroke="${ink}" stroke-width=".8"/><ellipse cx="${x-s*.35}" cy="15.2" rx="1.1" ry="2" fill="#9AA0A8"/><path d="M${x+s*.9} 13.6 Q${x+s*1.5} 15.2 ${x+s*.9} 16.8" stroke="#EEF0F3" stroke-width=".45" fill="none"/>`).join("");
  return `<svg viewBox="0 0 40 40" aria-hidden="true"><ellipse cx="20" cy="37.5" rx="10.5" ry="2.2" fill="#000" opacity=".3"/>${o}</svg>`}
{const _n=npcSVG;npcSVG=function(L){if(L&&L.drA)return drASVG();return _n(L)}}
const DR_A={n:"Dr. A.",look:{drA:1,coat:"#B88590",hair:"#3B2418",hs:"curly",skin:"#E3B48E"},talks:[
 ["Dr. A. Acoustics.","The headphones aren't playing anything. They keep the hall out."],
 ["I made Jestiphonatacicis. One batch, in the glovebox, with the lights off.","The register says the vial is not to be opened. The register is correct."],
 ["You're standing where I measure from.","...","Thank you."],
 ["People ask what the A stands for.","It stands for A."],
 ["The shirt was a gift. I didn't choose the word.","I wear it because it's clean."],
 ["Marlow brings me tea when he wants a favour. He has brought me tea four times this week.","I haven't decided yet."]]};
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z||z.cls!=="z-quill"||z.special||(typeof TUT!=="undefined"&&TUT.on))return;
  if((EXP.npcs||[]).some(p=>p.n===DR_A.n))return;const x=62,y=16,W=EXP.W,H=EXP.H;
  const d=document.createElement("div");d.className="npc";d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";
  d.innerHTML=`<span class="talkmark">...</span>`+npcSVG(DR_A.look);$("#world").insertBefore(d,$("#player"));
  EXP.npcs.push({...DR_A,x,y,el:d,said:0});nearMarks()}}
if(typeof lookOf==="function"){const _lo=lookOf;lookOf=function(n){return n===DR_A.n?DR_A.look:_lo(n)}}

/* ---- her alloy ---- */
slagAlloy({name:"Jestiphonatacicis",cat:"Sealed Sample",rar:"rare",comp:[["Na",41.9],["U",28.4],["I",16],["Fr",13.7]],origin:"Dr. A.",kind:"person",fill:"granules",
  uses:"None. It stays in its vial",made:"Mixed in Dr. A.'s glovebox, in the dark, in one batch",
  lore:"Dr. A. made exactly one batch, sealed it, and wrote a single line in the register beside it: 'Do not open. Do not shake. Do not ask.' Nobody has asked. A few grains of it got loose when a shelf in her sample store came down."});
{const a=ALLOYS.find(a=>a.name==="Jestiphonatacicis");if(a){a.slagWild=false;
  /* francium has no measured density, so the mix is worked out with the usual estimate for it */
  const est={Fr:2.48};a.d=+(1/a.comp.reduce((t,[s,p])=>t+p/100/(BY[s].d||est[s]),0)).toFixed(2);a.types=typesOf(a);a.fixedHab="z-quill";a.hab="z-quill"}}


