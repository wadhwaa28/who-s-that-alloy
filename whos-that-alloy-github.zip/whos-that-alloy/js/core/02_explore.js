/* =============== EXPLORATION (random encounters) =============== */
const ZONES=[
 {name:"RUSTVEIN MINE",sub:"Old tunnels. Something glints in the rubble.",cls:"z-mine",map:["#################", "#P.==========..o#", "#..=,,,#,,,,=.,,#", "#o.=,,,#,,,,=,,,#", "###=####L##.=####", "#,,=,,,,,,,.=..o#", "#,,=,,o,,,~~=,,,#", "#..=....,,~~=,,,#", "####.#######=####", "#o,,,,,,,,,,=,,L#", "#################"]},
 {name:"TINKER'S SCRAPYARD",sub:"Heaps of forgotten metal. Watch your step.",cls:"z-scrap",map:["#################", "#P....o...,,,,.T#", "#.===========,,.#", "#.=,,,T,,o,,=,,.#", "#.=,,,,,,,,,=...#", "#o=...##=##.=.o.#", "#.=,,,##=##,=,,,#", "#.=,,,,,=,,,=,,,#", "#.=======,,,===.#", "#T..o...,,,,..oT#", "#################"]},
 {name:"SUNKEN GALLEON COVE",sub:"A shipwreck at low tide. The sea left treasures in the sand.",cls:"z-wreck",map:["~~~~~~~~~~~~~~~~~", "~~~~~~~####~~~~~~", "~P..,,~#,,#~,,.~~", "~.T.,,..,,..,,,.~", "~...==========.T~", "~,,.=.,,,,,,.=.,~", "~,,.=.,T,,o,.=.,~", "~o..=.......,=..~", "~~..===========.~", "~~~.T,,,,.,,,.~~~", "~~~~~~~~~~~~~~~~~"]},
 {name:"EMBERFORGE CALDERA",sub:"The ground is hot. Only the toughest metals survive here.",cls:"z-volcano",map:["#################", "#P..,,,~~~,,,..T#", "#.T.,,,~~~,,,,..#", "#...=========...#", "#,,,.,.=~=.,.,,,#", "#,,,.,.=~=.,.,,,#", "#~~~~~~=~=~~~~~~#", "#.,,,,..~..,,,L.#", "#T.,,,,.~.,,,,..#", "#....==.~.==...T#", "#################"]},
 {name:"GILDED VAULT",sub:"A forgotten treasury. Mind the coin piles.",cls:"z-vault",map:["#################", "#P.=====L=====..#", "#..=.T.,,,.T.=..#", "#o.=.,,,,,,,.=.o#", "#..=.T.,,,.T.=..#", "###=####.####=###", "#,,=,,,o.o,,,=,,#", "#,,=,T,,.,,T,=,,#", "#..=====.=====..#", "#o,,,,,.o.,,,,,o#", "#################"]},
 {name:"OLD REACTOR HALL",sub:"Decommissioned decades ago. Something still glows.",cls:"z-reactor",map:["#################", "#P..=====..,,,.o#", "#.o.=,,,=..,,,..#", "#...=,~~~~~~,=..#", "#,,.=,~~~~~~,=.,#", "#,,.=,~~~~~~,=,,#", "#,,.=,,,,,,,,=,,#", "#o..====..====.L#", "#.,,,,.o..o.,,,,#", "#L.,,,,..,,,,,.o#", "#################"]},
 {name:"FROSTBITE CAVERN",sub:"So cold that strange liquids freeze in the ice.",cls:"z-glacier",map:["#################", "#,,,,..P..,,,,T.#", "#,T,,.....,,,,..#", "#,,,.===.===.,,,#", "#...=~~~~~~~=...#", "#.T.=~~~~~~~=.T.#", "#...=~~~~~~~=...#", "#,,,.===.===.,,,#", "#,,,,,..T..,,,,,#", "#T.,,,,...,,,,.T#", "#################"]},
 {name:"QUILLMOOR INSTITUTE",sub:"The Institute's main specimen hall. Samples from every habitat end up somewhere in here.",cls:"z-quill",map:["####L#######L####", "#TT.,,o.P.o,,.TT#", "#...,,,.=.,,,...#", "#.o====.=.====o.#", "#.,=,,..=..,,=,.#", "#.,=.~~~=~~~.=,.#", "#.,=.~~~=~~~.=,.#", "#.,=,,..=..,,=,.#", "#.o====.=.====o.#", "#TT.,,,,=,,,,.TT#", "#################"]},
 {name:"STARFALL CRATER",sub:"A meteor landed here long ago.",cls:"z-crater",map:["#################", "####,,,,,,,,,####", "##,,,,T...,,,,,##", "#,,,.........,,,#", "#,T..,~~~~~,..T,#", "#,,,.,~~~~~,.,,,#", "#,,..,~~~~~,..,,#", "#,o,........P,o,#", "##,,,,,T,,,,,,,##", "####,,,,,,,,,####", "#################"]}
];
const MINER=`<svg viewBox="0 0 40 40" aria-hidden="true"><ellipse cx="20" cy="37.5" rx="10" ry="2.2" fill="#000" opacity=".3"/>
<rect x="14.5" y="31" width="4.5" height="5.5" rx="1" fill="#2E3548"/><rect x="21" y="31" width="4.5" height="5.5" rx="1" fill="#2E3548"/>
<rect x="13.5" y="35.5" width="6" height="2.5" rx="1.2" fill="#121B40"/><rect x="20.5" y="35.5" width="6" height="2.5" rx="1.2" fill="#121B40"/>
<path d="M12 22 Q20 19 28 22 L29.5 34 L10.5 34 Z" fill="#FFFFFF" stroke="#121B40" stroke-width="1.6" stroke-linejoin="round"/>
<path d="M17 21 L20 27 L23 21" fill="#7FB6E8" stroke="#121B40" stroke-width="1.1" stroke-linejoin="round"/>
<path d="M20 27 L20 34" stroke="#C9D2E6" stroke-width="1"/>
<rect x="13.2" y="26.5" width="4" height="3.6" rx=".6" fill="#EEF2FA" stroke="#9AA6C2" stroke-width=".7"/><path d="M14.2 26.8 V25 M15.4 26.8 V24.6 M16.4 26.8 V25.2" stroke-linecap="round" stroke-width="1" stroke="#E8412C"/><path d="M15.4 26.8 V24.6" stroke="#3B7BF0" stroke-width="1" stroke-linecap="round"/>
<rect x="22.6" y="27" width="3.4" height="2.4" rx=".5" fill="#FFD23F" stroke="#121B40" stroke-width=".6"/>
<path d="M11.5 23 Q9 28 10 32" stroke="#121B40" stroke-width="3.6" stroke-linecap="round" fill="none"/><path d="M11.5 23 Q9 28 10 32" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" fill="none"/>
<circle cx="10.2" cy="32.4" r="1.6" fill="#F2C7A5" stroke="#121B40" stroke-width=".8"/>
<path d="M28.5 23 Q31.5 25 32 28" stroke="#121B40" stroke-width="3.6" stroke-linecap="round" fill="none"/><path d="M28.5 23 Q31.5 25 32 28" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round" fill="none"/>
<path d="M31 24.5 L31 27 L28.6 31.5 Q28.2 32.6 29.4 32.6 L35.6 32.6 Q36.8 32.6 36.4 31.5 L34 27 L34 24.5 Z" fill="#E6F3FF" stroke="#121B40" stroke-width=".9" stroke-linejoin="round"/>
<path d="M29.4 30.2 L35.6 30.2 L36.4 31.5 Q36.8 32.6 35.6 32.6 L29.4 32.6 Q28.2 32.6 28.6 31.5 Z" fill="#6BE08A"/><rect x="30.6" y="23.6" width="3.8" height="1.4" rx=".5" fill="#9AA6C2"/>
<circle cx="32" cy="28" r="1.8" fill="#F2C7A5" stroke="#121B40" stroke-width=".8"/>
<circle cx="20" cy="13.5" r="7.2" fill="#F2C7A5" stroke="#121B40" stroke-width="1.6"/>
<path d="M12.6 12.5 Q12 5.5 19 5.6 Q21 3.4 24 5 Q28.6 5.4 27.6 11 Q25.6 8.6 22.4 9.2 Q18.4 7.8 16 10 Q14 10.4 12.6 12.5Z" fill="#6B4424" stroke="#121B40" stroke-width="1.3" stroke-linejoin="round"/>
<path d="M12.8 13 L27.4 13" stroke="#2E3548" stroke-width="1.6"/>
<circle cx="19.6" cy="13.4" r="2.6" fill="#BFE6FF" stroke="#2E3548" stroke-width="1.2"/><circle cx="25.2" cy="13.4" r="2.6" fill="#BFE6FF" stroke="#2E3548" stroke-width="1.2"/>
<circle cx="18.9" cy="12.6" r=".7" fill="#fff"/><circle cx="24.5" cy="12.6" r=".7" fill="#fff"/>
<path d="M21.5 17.6 Q23 18.6 24.4 17.6" stroke="#121B40" stroke-width=".9" fill="none" stroke-linecap="round"/></svg>`;
const EXP={zone:null,x:0,y:0,face:1,busy:true,since:0,target:null,timer:null,hold:null};

function quillSpill(seed){const R=mulberry(seed*7919+13),rn=(a,b)=>a+R()*(b-a),f=v=>v.toFixed(1);let g="";
  // loose papers
  for(let i=0;i<2+(R()*2|0);i++){const x=rn(4,26),y=rn(4,26),a=rn(-35,35);g+=`<g transform="rotate(${f(a)} ${f(x+6)} ${f(y+7)})"><rect x="${f(x)}" y="${f(y)}" width="12" height="15" fill="#F7F4EA" stroke="#B8B0A0" stroke-width=".5"/><path d="M${f(x+2)} ${f(y+4)} h8 M${f(x+2)} ${f(y+7)} h7 M${f(x+2)} ${f(y+10)} h8" stroke="#8A94A8" stroke-width=".7"/></g>`}
  // a knocked-over sample jar with its contents spilled out
  const jx=rn(10,24),jy=rn(16,26),ja=rn(-80,-20),cols=["#B8C0CC","#D9B86A","#C98A5A","#9AA8B8","#D0D4DA"],c=cols[R()*5|0];
  for(let i=0;i<6;i++)g+=`<ellipse cx="${f(jx+rn(4,14))}" cy="${f(jy+rn(-3,5))}" rx="${f(rn(1,2.2))}" ry="${f(rn(.8,1.6))}" fill="${c}" stroke="rgba(0,0,0,.35)" stroke-width=".4"/>`;
  g+=`<g transform="rotate(${f(ja)} ${f(jx)} ${f(jy)})"><rect x="${f(jx-4)}" y="${f(jy-10)}" width="8" height="11" rx="2" fill="rgba(210,235,250,.55)" stroke="#6A8AA8" stroke-width=".8"/><rect x="${f(jx-4.6)}" y="${f(jy-12)}" width="9.2" height="2.6" rx="1" fill="#3A4A6A"/><rect x="${f(jx-3)}" y="${f(jy-6)}" width="6" height="3" fill="#F7F4EA"/></g>`;
  // a small flask or test tube, sometimes
  if(R()<.6){const x=rn(24,34),y=rn(22,32);g+=`<path d="M${f(x-2)} ${f(y-9)} v5 l-4 7 q-1 2 1 2 h10 q2 0 1-2 l-4 -7 v-5 z" fill="rgba(210,235,250,.6)" stroke="#6A8AA8" stroke-width=".8"/><path d="M${f(x-4.6)} ${f(y+1)} h9.2 l1 2 q0 1 -1 1 h-10 q-1 0 -1-1 z" fill="${cols[R()*5|0]}" opacity=".8"/>`}
  // a glint
  g+=`<path class="tw" d="M${f(rn(8,32))} ${f(rn(8,30))} l1 -3 l1 3 l3 1 l-3 1 l-1 3 l-1 -3 l-3 -1 z" fill="#FFFFFF" style="animation-delay:${f(rn(0,2.4))}s"/>`;
  return `<svg viewBox="0 0 40 40" aria-hidden="true">${g}</svg>`}
function rubbleSVG(z,seed){if(z==="z-quill")return quillSpill(seed);const R=mulberry(seed*7919+13),rn=(a,b)=>a+R()*(b-a),f=v=>v.toFixed(1);
  const rocks={"z-wreck":["#9C8B6E","#B7A583","#7E8C86"],"z-volcano":["#3A2E2E","#5A4640","#2A2226"],"z-vault":["#8C7A5E","#A48E6A","#6E6048"],"z-reactor":["#6E7A76","#87938E","#56605C"],"z-glacier":["#DCEFFA","#A9D2EC","#C4E2F4"],"z-mine":["#8C7A66","#A08C74","#766553"],"z-scrap":["#8E949C","#A7ADB5","#7A6F66"],"z-crater":["#6D6488","#877DA6","#5A5272"],"z-quill":["#C9CFD8","#9AA6B8","#E4E8EE"]}[z];
  let g="";
  for(let i=0;i<9;i++)g+=`<ellipse cx="${f(rn(2,38))}" cy="${f(rn(2,38))}" rx="${f(rn(.5,1.3))}" ry="${f(rn(.4,.9))}" fill="rgba(0,0,0,.28)"/>`;
  for(let i=0;i<6;i++)g+=`<circle cx="${f(rn(2,38))}" cy="${f(rn(2,38))}" r="${f(rn(.3,.7))}" fill="rgba(255,255,255,.18)"/>`;
  const n=3+(R()*2|0),rk=[];
  for(let i=0;i<n;i++){const cx=rn(9,31),cy=rn(10,30),r=rn(5,8.5),k=6+(R()*3|0),col=rocks[i%3],pts=[];
    for(let j=0;j<k;j++){const a=j/k*Math.PI*2+rn(-.25,.25),rr=r*rn(.72,1.1);pts.push([cx+Math.cos(a)*rr,cy+Math.sin(a)*rr*.72])}
    const P=q=>q.map(p=>f(p[0])+","+f(p[1])).join(" "),top=Math.floor(k*.75),bot=Math.floor(k*.25);
    g+=`<ellipse cx="${f(cx)}" cy="${f(cy+r*.55)}" rx="${f(r*1.05)}" ry="${f(r*.3)}" fill="rgba(0,0,0,.32)"/>`+
      `<polygon points="${P(pts)}" fill="${col}" stroke="rgba(0,0,0,.5)" stroke-width=".6"/>`+
      `<polygon points="${P([[cx,cy],pts[top-1],pts[top],pts[(top+1)%k]])}" fill="${shade(col,.35)}"/>`+
      `<polygon points="${P([[cx,cy],pts[bot],pts[bot+1]])}" fill="${shade(col,-.3)}"/>`;
    rk.push([cx,cy,r])}
  const items=2+(R()*2|0);
  for(let i=0;i<items;i++){const[cx,cy,r]=rk[i%rk.length],x=cx+rn(-r*.6,r*.6),y=cy+rn(-r*.4,r*.3);const g0=g.length;
    if(z==="z-mine"){const col=["#E9B949","#D07A3A","#D9DEE4"][R()*3|0];
      if(R()<.5)g+=`<path d="M${f(x-r*.7)} ${f(y)} q${f(r*.4)} ${f(-r*.5)} ${f(r*.8)} ${f(-r*.1)} t${f(r*.6)} ${f(r*.2)}" stroke="${col}" stroke-width=".9" fill="none" stroke-linecap="round"/>`;
      g+=`<polygon points="${f(x-1.6)},${f(y)} ${f(x-.4)},${f(y-1.7)} ${f(x+1.5)},${f(y-.9)} ${f(x+1.2)},${f(y+1)} ${f(x-.6)},${f(y+1.3)}" fill="${col}" stroke="${shade(col,-.45)}" stroke-width=".5"/><polygon points="${f(x-.4)},${f(y-1.7)} ${f(x+1.5)},${f(y-.9)} ${f(x+.2)},${f(y-.2)}" fill="${shade(col,.5)}"/><circle cx="${f(x-.2)}" cy="${f(y-.9)}" r=".45" fill="#fff"/>`}
    else if(z==="z-scrap"){const t=R()*4|0;
      if(t===0)g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(0,90))})"><circle r="3" fill="#8E969F" stroke="#5E656D" stroke-width="1.6" stroke-dasharray="1.1 .8"/><circle r="1.9" fill="#A9B0B8"/><circle r=".8" fill="#4A5058"/></g>`;
      else if(t===1)g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-40,40))})"><rect x="-4.5" y="-1.2" width="9" height="2.4" rx="1" fill="#B06A3E" stroke="#6E3A1C" stroke-width=".5"/><rect x="-4.5" y="-1.2" width="9" height=".7" fill="#D89A6A"/><ellipse cx="4.5" cy="0" rx=".6" ry="1.2" fill="#4A2A18"/></g>`;
      else if(t===2)g+=`<g transform="translate(${f(x)} ${f(y)})"><polygon points="-1.6,0 -.8,-1.4 .8,-1.4 1.6,0 .8,1.4 -.8,1.4" fill="#C3C9D0" stroke="#5E656D" stroke-width=".5"/><circle r=".6" fill="#6E757D"/></g>`;
      else g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-25,25))})"><rect x="-3.5" y="-2.2" width="7" height="4.4" rx=".6" fill="#8A8F96" stroke="#555A61" stroke-width=".5"/><circle cx="-2.5" cy="-1.3" r=".4" fill="#D0D5DB"/><circle cx="2.5" cy="-1.3" r=".4" fill="#D0D5DB"/><circle cx="-2.5" cy="1.3" r=".4" fill="#D0D5DB"/><circle cx="2.5" cy="1.3" r=".4" fill="#D0D5DB"/><path d="M-3.5 1 L-1 2.2" stroke="#B06A3E" stroke-width=".7"/></g>`}
    else if(z==="z-wreck"){const t=R()*3|0;
      if(t===0)g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-40,40))})"><rect x="-5" y="-1.3" width="10" height="2.6" rx=".5" fill="#8A5A34" stroke="#4A2E18" stroke-width=".5"/><path d="M-5 -.3 H5 M-2 -1.3 V1.3" stroke="#6E4424" stroke-width=".4"/></g>`;
      else if(t===1)g+=`<g transform="translate(${f(x)} ${f(y)})"><circle r="2.8" fill="none" stroke="#C99A48" stroke-width="1.3"/><circle r="1.8" fill="#9FD3F0" opacity=".7"/></g>`;
      else g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-30,30))})"><path d="M0 -2.6 Q2.8 -1.4 2.4 1.6 L-2.4 1.6 Q-2.8 -1.4 0 -2.6Z" fill="#F2D8C8" stroke="#B88A72" stroke-width=".5"/><path d="M0 -2.4 V1.6 M-1.3 -1.8 L-1.2 1.6 M1.3 -1.8 L1.2 1.6" stroke="#C99A82" stroke-width=".4"/></g>`}
    else if(z==="z-volcano"){const hot=R()<.5;
      g+=hot?`<g transform="translate(${f(x)} ${f(y)})"><circle class="glow" r="3.4" fill="#FF6A1F" opacity=".45"/><polygon points="-2,1.2 -1,-1.8 1.4,-1.6 2.2,.8 .4,1.8" fill="#3A2420"/><path d="M-1 -1 L.4 0 L1.2 -.8" stroke="#FF8A2A" stroke-width=".6" fill="none"/></g>`
        :`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-30,30))})"><polygon points="0,-3.4 1.8,0 0,2 -1.6,-.4" fill="#141018" stroke="#3E3848" stroke-width=".4"/><path d="M0 -3 L.8 -.4" stroke="#9AA0C0" stroke-width=".4"/></g>`}
    else if(z==="z-vault"){const t=R()*2|0;
      if(t===0)for(let c=0;c<4;c++)g+=`<ellipse cx="${f(x+rn(-2,2))}" cy="${f(y-c*.8)}" rx="1.9" ry=".8" fill="#E9B949" stroke="#9A6A12" stroke-width=".4"/>`;
      else{const col=["#E23A5A","#3AA0E2","#3AD08A","#B04AE2"][R()*4|0];g+=`<g transform="translate(${f(x)} ${f(y)})"><polygon points="0,-2.4 2,-.6 1.2,1.8 -1.2,1.8 -2,-.6" fill="${col}" stroke="${shade(col,-.45)}" stroke-width=".4"/><polygon points="0,-2.4 2,-.6 0,-.2" fill="${shade(col,.5)}"/></g>`}}
    else if(z==="z-reactor"){const t=R()*2|0;
      if(t===0)g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-20,20))})"><rect x="-1.8" y="-3" width="3.6" height="5.6" rx=".6" fill="#C9D0C4" stroke="#556" stroke-width=".4"/><rect x="-1.8" y="-1" width="3.6" height="1.4" fill="#E0B820"/><circle class="glow" r="4" fill="#9CFF4A" opacity=".25"/></g>`;
      else for(let c=0;c<3;c++)g+=`<circle class="glow" cx="${f(x+rn(-2.5,2.5))}" cy="${f(y+rn(-1.5,1.5))}" r=".9" fill="#B6FF6A"/>`}
    else if(z==="z-glacier"){const t=R()*2|0;
      if(t===0)g+=`<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-25,25))})"><polygon points="0,-4 1.6,-1 1,2 -1,2 -1.6,-1" fill="#EAF7FF" stroke="#7FB6D8" stroke-width=".5" opacity=".95"/><path d="M0 -4 L0 2" stroke="#FFFFFF" stroke-width=".4"/></g>`;
      else for(let c=0;c<3;c++){const cx2=x+rn(-2.5,2.5),cy2=y+rn(-1.5,1.5);g+=`<circle cx="${f(cx2)}" cy="${f(cy2)}" r="${f(rn(.6,1.1))}" fill="#C9CED4" stroke="#8A9098" stroke-width=".3"/><circle cx="${f(cx2-.3)}" cy="${f(cy2-.3)}" r=".25" fill="#fff"/>`}}
    else{const hgt=rn(5,9),w=rn(1.8,2.8),col=["#8FD8FF","#B9A6FF","#8FF0D0"][R()*3|0];
      g+=`<ellipse class="glow" cx="${f(x)}" cy="${f(y)}" rx="${f(w*2.2)}" ry="${f(hgt*.5)}" fill="${col}" opacity=".35"/>`+
        `<g transform="translate(${f(x)} ${f(y)}) rotate(${f(rn(-20,20))})"><polygon points="${f(-w)},0 ${f(-w)},${f(-hgt*.7)} 0,${f(-hgt)} ${f(w)},${f(-hgt*.7)} ${f(w)},0 0,${f(w*.6)}" fill="${col}" stroke="${shade(col,-.4)}" stroke-width=".5" opacity=".95"/><polygon points="0,${f(-hgt)} ${f(w)},${f(-hgt*.7)} ${f(w)},0 0,${f(w*.6)}" fill="${shade(col,-.2)}"/><path d="M${f(-w*.5)} ${f(-hgt*.6)} L${f(-w*.5)} ${f(-hgt*.15)}" stroke="#fff" stroke-width=".5" opacity=".8"/></g>`}
    g=g.slice(0,g0)+`<g transform="translate(${f(x)} ${f(y)}) scale(1.45) translate(${f(-x)} ${f(-y)})">`+g.slice(g0)+"</g>"}
  const glintCol={"z-wreck":"#FFFFFF","z-volcano":"#FFB347","z-vault":"#FFF3B0","z-reactor":"#D8FFB0","z-glacier":"#FFFFFF","z-mine":"#FFE9A8","z-scrap":"#FFFFFF","z-crater":"#DDF2FF"}[z];
  for(let i=0;i<3;i++)g+=`<g transform="translate(${f(rn(6,34))} ${f(rn(6,32))})"><path class="tw" d="M0 -2.8 L.55 -.55 L2.8 0 L.55 .55 L0 2.8 L-.55 .55 L-2.8 0 L-.55 -.55Z" fill="${glintCol}" style="animation-delay:${f(rn(0,3))}s;animation-duration:${f(rn(1.6,3.2))}s"/></g>`;
  return `<svg viewBox="0 0 40 40" preserveAspectRatio="none" aria-hidden="true">${g}</svg>`}
function propSVG(z,kind,seed){const R=mulberry(seed*131+7),r=(a,b)=>a+R()*(b-a),S=b=>`<svg viewBox="0 0 40 40" preserveAspectRatio="xMidYMid meet" aria-hidden="true">${b}</svg>`,sh=`<ellipse cx="20" cy="35" rx="14" ry="3.5" fill="#000" opacity=".3"/>`;
  if(kind==="T"){switch(z){
    case"z-mine":return S(`${sh}<rect x="8" y="4" width="5" height="32" fill="#7A5230" stroke="#3A2414" stroke-width="1.2"/><rect x="27" y="4" width="5" height="32" fill="#7A5230" stroke="#3A2414" stroke-width="1.2"/><rect x="5" y="3" width="30" height="6" fill="#8E6238" stroke="#3A2414" stroke-width="1.2"/>`);
    case"z-scrap":return S(`${sh}<path d="M4 30 L8 20 Q12 15 20 15 L28 16 L34 22 L36 30 Z" fill="#9A4A36" stroke="#3A1E16" stroke-width="1.3"/><path d="M12 20 L18 17 L26 17 L30 21 Z" fill="#8FB8D0" stroke="#3A1E16" stroke-width="1"/><circle cx="11" cy="31" r="4" fill="#2A2A2E"/><circle cx="29" cy="31" r="4" fill="#2A2A2E"/><path d="M20 22 l3 5" stroke="#B87A4A" stroke-width="1.5"/>`);
    case"z-wreck":return S(`${sh}<path d="M20 36 Q19 22 22 10" stroke="#8A5A34" stroke-width="3.2" fill="none"/><path d="M22 10 Q12 6 5 12 Q13 9 22 11 Q18 2 9 1 Q19 4 22 10 Q28 1 36 3 Q27 5 22 11 Q31 7 37 14 Q29 9 22 11Z" fill="#3E9E4E" stroke="#1E5A2A" stroke-width=".8"/><circle cx="21" cy="12" r="1.8" fill="#6B4424"/>`);
    case"z-volcano":return S(`${sh}<polygon points="20,2 27,34 13,34" fill="#1A1420" stroke="#3E3848" stroke-width="1"/><polygon points="20,2 23,20 20,34 16,20" fill="#2E2838"/><path d="M20 6 L22 18" stroke="#9AA0C0" stroke-width=".8"/><path d="M14 30 L26 30" stroke="#FF6A1F" stroke-width="1" opacity=".6"/>`);
    case"z-vault":return S(`${sh}<rect x="12" y="7" width="16" height="27" fill="#EDE6D2" stroke="#8C7A5E" stroke-width="1.2"/><path d="M15 8 V33 M20 8 V33 M25 8 V33" stroke="#C9BFA2" stroke-width="1"/><rect x="9" y="3" width="22" height="5" fill="#D9A92A" stroke="#8C6A12" stroke-width="1"/><rect x="9" y="33" width="22" height="4" fill="#D9A92A" stroke="#8C6A12" stroke-width="1"/>`);
    case"z-reactor":return S(`${sh}<rect x="9" y="6" width="22" height="29" rx="10" fill="#B8C2BC" stroke="#3A4440" stroke-width="1.3"/><rect x="9" y="15" width="22" height="5" fill="#E0B820"/><path d="M9 15 l5 5 M14 15 l5 5 M19 15 l5 5 M24 15 l5 5" stroke="#1E2420" stroke-width="1.2"/><circle cx="20" cy="27" r="3.5" fill="#9CFF4A" opacity=".8"/>`);
    case"z-quill":return R()<.5
      ? S(`${sh}<rect x="7" y="2" width="26" height="33" rx="1.5" fill="#5A3A24" stroke="#2E1C10" stroke-width="1.2"/><rect x="9" y="4" width="22" height="29" fill="rgba(200,230,250,.35)" stroke="#8C6A48" stroke-width=".8"/><path d="M9 13.5 H31 M9 23.5 H31" stroke="#8C6A48" stroke-width="1.2"/>${[[11,7],[17,6],[24,8],[12,16],[19,17],[25,15],[11,26],[18,27],[24,25]].map(([x,y],k)=>`<rect x="${x}" y="${y}" width="5" height="${[6,7,5][k%3]}" rx="1.2" fill="rgba(220,240,255,.8)" stroke="#6A8AA8" stroke-width=".5"/><rect x="${x+.6}" y="${y+2.5}" width="3.8" height="${[3,4,2][k%3]}" fill="${["#C98A5A","#9AA8B8","#D9B86A","#8FC0A0","#B8A0D0"][k%5]}"/>`).join("")}<rect x="17" y="34" width="6" height="1.5" fill="#D9A92A"/>`)
      : S(`${sh}<rect x="7" y="2" width="26" height="33" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/>${[5,15,25].map(y=>`<rect x="9" y="${y}" width="22" height="8" fill="#2A1C12"/>`).join("")}${[[10,6,"#8A3A34"],[13,5,"#2E4A7A"],[16,6,"#3A6A4A"],[19,7,"#6A4A2A"],[22,5,"#4A3A6A"],[26,6,"#8A6A2A"],[10,16,"#2E4A7A"],[13,17,"#6A4A2A"],[17,16,"#8A3A34"],[24,18,"#3A6A4A"],[11,26,"#4A3A6A"],[15,27,"#8A6A2A"],[21,26,"#2E4A7A"],[25,26,"#8A3A34"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="2.6" height="${13-(y%10)}" fill="${c}"/>`).join("")}<rect x="21" y="18" width="3" height="5" fill="#F4F1E6"/>`);
    case"z-glacier":return S(`${sh}<polygon points="14,35 18,4 22,35" fill="#DDF2FF" stroke="#7FB6D8" stroke-width="1"/><polygon points="20,35 25,12 29,35" fill="#C4E6FA" stroke="#7FB6D8" stroke-width="1"/><polygon points="8,35 11,20 14,35" fill="#EAF7FF" stroke="#7FB6D8" stroke-width="1"/><path d="M18 8 L18 30" stroke="#fff" stroke-width=".8"/>`);
    default:return S(`${sh}<g><polygon points="12,34 14,14 18,34" fill="#9AE8FF" stroke="#3F7FA8" stroke-width="1"/><polygon points="17,34 21,4 25,34" fill="#C2A8FF" stroke="#6A4FA8" stroke-width="1"/><polygon points="24,34 28,18 30,34" fill="#8FF0D0" stroke="#3FA884" stroke-width="1"/><path d="M21 8 L21 30" stroke="#fff" stroke-width=".8" opacity=".8"/></g>`)}}
  switch(z){
    case"z-mine":return S(`${sh}<path d="M6 16 L34 16 L30 31 L10 31 Z" fill="#6E7680" stroke="#2E3440" stroke-width="1.3"/><path d="M8 16 Q20 7 32 16" fill="#8C7A66"/><circle cx="16" cy="12" r="2.5" fill="#E9B949"/><circle cx="12" cy="33" r="3" fill="#2A2A2E"/><circle cx="28" cy="33" r="3" fill="#2A2A2E"/>`);
    case"z-scrap":return S(`${sh}<ellipse cx="20" cy="30" rx="12" ry="4" fill="#26262A"/><rect x="8" y="17" width="24" height="13" fill="#2E2E34"/><ellipse cx="20" cy="17" rx="12" ry="4" fill="#3A3A42"/><ellipse cx="20" cy="17" rx="5" ry="1.6" fill="#18181C"/><ellipse cx="20" cy="22" rx="12" ry="4" fill="none" stroke="#18181C" stroke-width="1"/>`);
    case"z-wreck":return S(`${sh}<rect x="10" y="10" width="20" height="24" rx="5" fill="#9A6A3C" stroke="#4A2E18" stroke-width="1.3"/><path d="M10 16 H30 M10 28 H30" stroke="#5A5F66" stroke-width="2"/><path d="M15 10 V34 M20 10 V34 M25 10 V34" stroke="#6E4424" stroke-width=".7"/>`);
    case"z-volcano":return S(`${sh}<path d="M6 32 Q4 18 16 12 Q30 8 34 22 Q36 32 26 34 Z" fill="#3A2E2E" stroke="#1A1212" stroke-width="1.2"/><path d="M14 20 L18 24 L24 19 L27 25" stroke="#FF7A2A" stroke-width="1.6" fill="none"/>`);
    case"z-vault":return S(`${sh}<rect x="7" y="17" width="26" height="16" rx="2" fill="#8A5A2E" stroke="#3E2410" stroke-width="1.3"/><path d="M7 17 Q20 6 33 17 Z" fill="#9C6A36" stroke="#3E2410" stroke-width="1.3"/><rect x="7" y="21" width="26" height="3" fill="#D9A92A"/><rect x="18" y="20" width="4" height="6" rx="1" fill="#F2D060" stroke="#8C6A12" stroke-width=".8"/><ellipse cx="20" cy="14" rx="8" ry="2" fill="#F2D060" opacity=".7"/>`);
    case"z-reactor":return S(`${sh}<rect x="10" y="10" width="20" height="24" rx="3" fill="#E0B820" stroke="#5A4A08" stroke-width="1.3"/><ellipse cx="20" cy="10" rx="10" ry="3" fill="#F0CC40" stroke="#5A4A08" stroke-width="1"/><circle cx="20" cy="22" r="5.5" fill="#1E2420"/><path d="M20 22 L20 16.8 A5.2 5.2 0 0 1 24.5 19.4 Z M20 22 L24.5 24.6 A5.2 5.2 0 0 1 15.5 24.6 Z M20 22 L15.5 19.4 A5.2 5.2 0 0 1 20 16.8 Z" fill="#E0B820"/>`);
    case"z-quill":{const v=R();return v<.34
      ? S(`${sh}<rect x="4" y="19" width="32" height="4" rx="1" fill="#E8E4DA" stroke="#6A6458" stroke-width="1"/><rect x="6" y="23" width="3" height="12" fill="#8A8478"/><rect x="31" y="23" width="3" height="12" fill="#8A8478"/><path d="M14 19 v-3 h6 v3" fill="#2E3548"/><path d="M17 16 L15 8 L19 6 L22 10 L19 12" stroke="#2E3548" stroke-width="2.4" fill="none" stroke-linecap="round"/><rect x="13.5" y="12" width="6" height="2" rx="1" fill="#3A4A6A"/><circle cx="17" cy="6" r="1.6" fill="#9AB8E0"/><rect x="24" y="14" width="8" height="5" fill="#F7F4EA" transform="rotate(-6 28 16)"/>`)
      : v<.67
      ? S(`${sh}<rect x="6" y="20" width="28" height="4" fill="#8A6A48" stroke="#3E2A18" stroke-width="1"/><rect x="8" y="24" width="3" height="11" fill="#6B4A2E"/><rect x="29" y="24" width="3" height="11" fill="#6B4A2E"/><rect x="10" y="6" width="20" height="14" rx="2" fill="#D8D2C2" stroke="#5A5448" stroke-width="1"/><rect x="12.5" y="8" width="15" height="9" rx="1" fill="#1A2E22"/><path d="M14 10.5 h7 M14 12.5 h10 M14 14.5 h5" stroke="#7CF0A0" stroke-width=".9"><animate attributeName="opacity" values="1;.5;1" dur="1.6s" repeatCount="indefinite"/></path><rect x="12" y="20" width="16" height="2" fill="#B8B2A2"/>`)
      : S(`${sh}<rect x="6" y="20" width="28" height="4" fill="#8A6A48" stroke="#3E2A18" stroke-width="1"/><rect x="8" y="24" width="3" height="11" fill="#6B4A2E"/><rect x="29" y="24" width="3" height="11" fill="#6B4A2E"/><path d="M11 20 L13 10 L17 10 L19 20 Z" fill="rgba(210,235,250,.7)" stroke="#6A8AA8" stroke-width="1"/><rect x="13.5" y="6" width="3" height="4" fill="rgba(210,235,250,.7)" stroke="#6A8AA8" stroke-width=".8"/><path d="M12 16 L18 16 L19 20 L11 20 Z" fill="#8FD0B0" opacity=".85"/><rect x="22" y="9" width="3" height="11" rx="1.5" fill="rgba(210,235,250,.7)" stroke="#6A8AA8" stroke-width=".8"/><rect x="22.3" y="14" width="2.4" height="5.5" fill="#D9B86A"/><rect x="27" y="11" width="3" height="9" rx="1.5" fill="rgba(210,235,250,.7)" stroke="#6A8AA8" stroke-width=".8"/><rect x="27.3" y="15" width="2.4" height="4.5" fill="#B8A0D0"/>`)}
    case"z-glacier":return S(`${sh}<path d="M5 33 Q6 20 15 17 Q22 11 30 18 Q37 23 35 33 Z" fill="#F4FAFF" stroke="#A9D2EC" stroke-width="1.2"/><path d="M12 24 Q18 21 24 24" stroke="#C4E2F4" stroke-width="1" fill="none"/>`);
    default:return S(`${sh}<path d="M7 31 Q5 19 15 14 Q27 9 33 20 Q37 30 27 33 Z" fill="#3A3448" stroke="#1A1628" stroke-width="1.2"/><circle cx="15" cy="22" r="2.2" fill="#2A2438"/><circle cx="24" cy="18" r="1.6" fill="#2A2438"/><circle cx="26" cy="27" r="2.6" fill="#2A2438"/><path d="M10 16 Q20 10 30 15" stroke="#BFE3FF" stroke-width=".8" fill="none" opacity=".6"/>`)}}
function startExplore(){S.phase="explore";S.r=null;
  $("#game").hidden=true;$("#endscreen").hidden=true;$("#explore").hidden=false;
  EXP.zone=EXP.forceZone||(()=>{const o=ZONES.filter(z=>z.cls!=="z-slag");return o[Math.random()*o.length|0]})();EXP.forceZone=null;EXP.since=0;EXP.path=null;EXP.busy=false;clearInterval(EXP.timer);
  const M=EXP.zone.map;EXP.W=M[0].length;EXP.H=M.length;
  $("#zone-name").textContent=EXP.zone.name;$("#zone-sub").textContent=EXP.zone.sub;const mw=$("#mapwrap");mw.className="mapwrap "+EXP.zone.cls;mw.style.aspectRatio=`${EXP.W}/${EXP.H}`;
  $("#map").style.gridTemplateColumns=`repeat(${EXP.W},1fr)`;$("#map").style.gridTemplateRows=`repeat(${EXP.H},1fr)`;
  const edge=(x,y,c)=>{const n=[[0,-1],[1,0],[0,1],[-1,0]].map(([dx,dy])=>(M[y+dy]||"")[x+dx]===c?1:0);return n.join("")};
  let h="",k=0;M.forEach((row,y)=>row.split("").forEach((c,x)=>{if(c==="P"){EXP.x=x;EXP.y=y}
    const seed=x*31+y*17+EXP.zone.name.length;
    const[cls,inner]=tileLook(c,x,y,seed,M);
    h+=`<div class="tile ${cls}" data-x="${x}" data-y="${y}" data-e="${c==="="?edge(x,y,"="):c==="~"?edge(x,y,"~"):""}" style="--d:${(k++%7)*.35}s">${inner}</div>`}));
  $("#map").innerHTML=h;$("#wipe").innerHTML=Array.from({length:8},(_,i)=>`<i style="--k:${i}"></i>`).join("");$("#wipe").className="wipe";
  const pl=$("#player");pl.className="player";pl.style.width=(100/EXP.W)+"%";pl.style.height=(100/EXP.H)+"%";pl.innerHTML=`<span class="bang">!</span>`+MINER;placePlayer(true);
  $("#expmsg").textContent=S.run.idx===0?"Walk through the glittering rubble to find a wild alloy.":"Keep exploring. More alloys hide in the rubble.";
  renderHud()}
function placePlayer(instant){const pl=$("#player");if(instant){pl.style.transition="none"}
  pl.style.left=(EXP.x/EXP.W*100)+"%";pl.style.top=(EXP.y/EXP.H*100)+"%";pl.style.setProperty("--face",EXP.face);
  if(instant){void pl.offsetWidth;pl.style.transition=""}}
const tileAt=(x,y)=>(EXP.zone.map[y]||"")[x]||"#";
const passable=c=>canWalk(c);
function step(dx,dy){if(EXP.busy||S.phase!=="explore")return false;
  if(dx)EXP.face=dx;const nx=EXP.x+dx,ny=EXP.y+dy;
  if(!passable(tileAt(nx,ny))){placePlayer();return false}
  EXP.x=nx;EXP.y=ny;const pl=$("#player");pl.classList.remove("walk");void pl.offsetWidth;pl.classList.add("walk");placePlayer();
  if(tileAt(nx,ny)===","){const t=document.querySelector(`.tile[data-x="${nx}"][data-y="${ny}"]`);t.classList.remove("rustle");void t.offsetWidth;t.classList.add("rustle");
    EXP.since++;if(Math.random()<(EXP.since>=RUBBLE_PITY?1:RUBBLE_P)){encounter();return false}}
  return true}
function encounter(){EXP.busy=true;EXP.path=null;clearInterval(EXP.timer);clearInterval(EXP.hold);
  $("#player").classList.add("alert");$("#expmsg").textContent="Something moved in the rubble!";
  setTimeout(()=>{$("#wipe").classList.add("go");
    setTimeout(()=>{$("#explore").hidden=true;$("#game").hidden=false;S.phase="round";startRound();reveal();
      document.querySelector(".arena").scrollIntoView({behavior:"smooth",block:"start"})},1000)},700)}
/* Click-to-move: shortest path (breadth-first search). If the tapped tile can't be reached,
   the scientist walks to the closest reachable tile and stops, never pushing into walls. */
function findPath(tx,ty){const W=EXP.W,H=EXP.H,key=(x,y)=>y*W+x,prev=new Map([[key(EXP.x,EXP.y),-1]]),q=[[EXP.x,EXP.y]];let best=[EXP.x,EXP.y],bd=Math.abs(tx-EXP.x)+Math.abs(ty-EXP.y);
  for(let i=0;i<q.length;i++){const[x,y]=q[i];const d=Math.abs(tx-x)+Math.abs(ty-y);if(d<bd){bd=d;best=[x,y]}if(d===0)break;
    for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=H||prev.has(key(nx,ny))||!passable(tileAt(nx,ny)))continue;prev.set(key(nx,ny),key(x,y));q.push([nx,ny])}}
  const path=[];let k=key(best[0],best[1]);while(k!==-1&&k!==key(EXP.x,EXP.y)){path.unshift([k%W,Math.floor(k/W)]);k=prev.get(k)}return path}
function walkTo(tx,ty){clearInterval(EXP.timer);if(EXP.busy)return;EXP.path=findPath(tx,ty);
  if(!EXP.path.length){$("#expmsg").textContent="You can't get any closer to that spot.";return}
  EXP.timer=setInterval(()=>{if(!EXP.path||!EXP.path.length||EXP.busy){clearInterval(EXP.timer);return}
    const[nx,ny]=EXP.path.shift();if(!step(nx-EXP.x,ny-EXP.y)){clearInterval(EXP.timer);EXP.path=null}},170)}
$("#map").addEventListener("click",e=>{const t=e.target.closest(".tile");if(t&&!EXP.busy)walkTo(+t.dataset.x,+t.dataset.y)});
document.querySelectorAll(".dpad button").forEach(b=>{const go=()=>{EXP.path=null;clearInterval(EXP.timer);step(+b.dataset.dx,+b.dataset.dy)};
  b.addEventListener("pointerdown",e=>{e.preventDefault();go();clearInterval(EXP.hold);EXP.hold=setInterval(go,180)});
  ["pointerup","pointerleave","pointercancel"].forEach(ev=>b.addEventListener(ev,()=>clearInterval(EXP.hold)));
  b.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();go()}})});
const KEYS={ArrowUp:[0,-1],ArrowDown:[0,1],ArrowLeft:[-1,0],ArrowRight:[1,0],w:[0,-1],s:[0,1],a:[-1,0],d:[1,0],W:[0,-1],S:[0,1],A:[-1,0],D:[1,0]};
let lastKey=0;
document.addEventListener("keydown",e=>{if(S.phase!=="explore"||$("#view-play").hidden)return;if(e.target.closest&&e.target.closest("input,textarea"))return;
  const k=KEYS[e.key];if(!k)return;e.preventDefault();const now=performance.now();if(now-lastKey<150)return;lastKey=now;EXP.path=null;clearInterval(EXP.timer);step(...k)});

/* =============== ANTI-SPAM: a button can't be re-triggered while its sound/action is still playing =============== */
const BTN_CD={"dd-rad":900,"btn-letter":600,"btn-hint":600,"btn-analyze":700,"fl-ign":600,"startbtn":1500,"btn-next":800,"btn-again":1200};
document.addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;
  const k=b.id||(b.dataset.no?"no"+b.dataset.no:b.dataset.s?"el"+b.dataset.s:b.dataset.mode?"mode":b.dataset.view?"tab"+b.dataset.view:b.dataset.f?"f"+b.dataset.f:b.textContent.trim());
  const ms=BTN_CD[b.id]||(b.dataset.mode?1000:b.closest(".ctrl")?400:300);
  if(!gate("btn:"+k,ms)){e.stopImmediatePropagation();e.preventDefault()}},true);
document.addEventListener("submit",e=>{if(!gate("submit",700)){e.stopImmediatePropagation();e.preventDefault()}},true);

/* =============== WIRING =============== */
function setView(v){document.querySelectorAll(".tab").forEach(t=>t.setAttribute("aria-selected",t.dataset.view===v));
  $("#view-play").hidden=v!=="play";$("#view-table").hidden=v!=="table";$("#view-dex").hidden=v!=="dex";
  if(v==="table")renderElCard();if(v==="dex")renderDexGrid()}
document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>setView(t.dataset.view));
document.querySelectorAll(".mode").forEach(b=>b.onclick=()=>{S.mode=b.dataset.mode;newRun()});
buildTable($("#pick-table"),false);buildTable($("#ref-table"),true);
$("#legend").innerHTML=Object.values(CATS).map(c=>`<span><i style="--c:${c.c}"></i>${c.name}</span>`).join("");
$("#pick-table").addEventListener("click",ev=>{const b=ev.target.closest(".el");if(b)togglePick(b.dataset.s)});
const showInfo=ev=>{const b=ev.target.closest&&ev.target.closest(".el");if(b)$("#pickinfo").innerHTML=elSummary(BY[b.dataset.s])};
$("#pick-table").addEventListener("mouseover",showInfo);$("#pick-table").addEventListener("focusin",showInfo);
$("#ref-table").addEventListener("click",ev=>{const b=ev.target.closest(".el");if(b){curEl=b.dataset.s;renderElCard()}});

/* =============== AUDIO: chiptune music + sound effects ===============
   Everything is synthesized in plain JavaScript into WAV clips and played with <audio>
   elements, which works in browsers and embedded viewers where Web Audio stays silent. */
const SR=22050;
const AU={on:false,sfxOn:store.get("wta_sfx",true),musOn:store.get("wta_mus",true),want:null,cur:null,music:new Audio(),cache:{},pools:{},err:false};
AU.music.loop=true;AU.music.volume=.55;AU.music.preload="auto";
let CUR=null;
function nf(n){const m=n.match(/^([A-G])(#|b)?(\d)$/);const midi=(+m[3]+1)*12+{C:0,D:2,E:4,F:5,G:7,A:9,B:11}[m[1]]+(m[2]==="#"?1:m[2]==="b"?-1:0);return 440*Math.pow(2,(midi-69)/12)}
function tone(f,t,d,o={}){const{type="square",vol=.2,to=null,a=.005,sus=false}=o,b=CUR;if(!b)return;
  const i0=Math.floor(t*SR),n=Math.floor((d+.02)*SR);let ph=0;
  for(let i=0;i<n;i++){const idx=i0+i;if(idx>=b.length)break;const tt=i/SR;
    const fr=to?f*Math.pow(to/f,Math.min(tt/d,1)):f;ph+=fr/SR;ph-=Math.floor(ph);
    const w=type==="pulse"?(ph<.125?.8:-.8):type==="square"?(ph<.5?.8:-.8):type==="triangle"?4*Math.abs(ph-.5)-1:type==="sawtooth"?(2*ph-1)*.8:Math.sin(6.2832*ph);
    let env;if(tt<a)env=vol*tt/a;else if(sus)env=tt<d-.02?vol*.85:tt<d?vol*.85*(d-tt)/.02:0;else env=tt>d?0:vol*Math.pow(.002,(tt-a)/Math.max(.001,d-a));
    b[idx]+=w*env}}
function nz(t,d,o={}){const{vol=.2,type="highpass",f=2000,to=null}=o,b=CUR;if(!b)return;
  const i0=Math.floor(t*SR),n=Math.floor(d*SR);let lp=0,lp2=0;
  for(let i=0;i<n;i++){const idx=i0+i;if(idx>=b.length)break;const tt=i/SR,cut=to?f*Math.pow(to/f,tt/d):f;
    const al=1-Math.exp(-6.2832*Math.min(cut,SR*.45)/SR),x=Math.random()*2-1;lp+=al*(x-lp);
    let y=type==="lowpass"?lp*1.6:type==="highpass"?x-lp:0;
    if(type==="bandpass"){const hp=x-lp;const al2=1-Math.exp(-6.2832*Math.min(cut*1.8,SR*.45)/SR);lp2+=al2*(hp-lp2);y=lp2*2}
    b[idx]+=y*vol*Math.pow(.002,tt/d)}}
function melody(lead,step,o={},bass){[[lead,{type:"square",vol:.13,sus:true,...o}],[bass||"",{type:"triangle",vol:.25,sus:true}]].forEach(([str,opt])=>{const arr=str.split(/\s+/).filter(Boolean);
  arr.forEach((n,i)=>{if(n==="."||n==="-")return;let len=1;while(arr[i+len]==="-")len++;tone(nf(n),.02+i*step,step*len*.95,opt)})})}
const SFX={
  sel:t=>tone(1320,t,.045,{vol:.1}),
  step:t=>nz(t,.05,{vol:.12,type:"bandpass",f:700}),
  rustle:t=>{nz(t,.11,{vol:.3,f:3200});nz(t+.07,.09,{vol:.2,f:5200})},
  bump:t=>tone(105,t,.08,{vol:.25}),
  alert:t=>{tone(nf("E6"),t,.07,{vol:.2});tone(nf("B6"),t+.08,.14,{vol:.2})},
  encounter:t=>{tone(160,t,.95,{type:"sawtooth",vol:.18,to:1500});nz(t+.35,.65,{vol:.25,f:700,to:6000})},
  clack:t=>{nz(t,.06,{vol:.5,type:"bandpass",f:1800});tone(95,t,.14,{type:"triangle",vol:.5})},
  tick:t=>{tone(700,t,.04,{vol:.12});tone(320,t+.3,.6,{type:"triangle",vol:.2,to:110})},
  thud:t=>tone(170,t+.25,.22,{type:"triangle",vol:.45,to:60}),
  scrub:t=>{nz(t,.22,{vol:.18,type:"bandpass",f:1200,to:1800})},
  scratch:t=>{nz(t,.38,{vol:.35,type:"bandpass",f:2400,to:5200});tone(3100,t,.3,{type:"sawtooth",vol:.04,to:2600})},
  skid:t=>nz(t,.2,{vol:.2,type:"bandpass",f:1300,to:900}),
  swirl:t=>nz(t,.5,{vol:.25,type:"lowpass",f:900,to:400}),
  beep:t=>{tone(2000,t,.07,{vol:.12});tone(2000,t+.12,.07,{vol:.12})},
  plunk:t=>{tone(720,t,.16,{type:"sine",vol:.5,to:210});nz(t,.22,{vol:.15,type:"lowpass",f:1600})},
  clunk:t=>tone(150,t,.14,{vol:.3,to:75}),
  splash:t=>nz(t,.5,{vol:.4,type:"lowpass",f:3200,to:500}),
  fizz:t=>{nz(t,1.3,{vol:.3,f:4200});nz(t,.6,{vol:.4,type:"lowpass",f:700,to:180})},
  whoomph:t=>nz(t,.7,{vol:.6,type:"lowpass",f:180,to:1600}),
  spark:t=>nz(t,.03,{vol:.5,f:5000}),
  click:t=>nz(t,.02,{vol:.5,f:3000}),
  gclick:t=>nz(t,.006,{vol:.8,f:1000}),
  hiss:t=>nz(t,1.1,{vol:.15,f:6000}),
  sizzle:t=>nz(t,.8,{vol:.18,type:"bandpass",f:5000}),
  pickup:t=>{tone(nf("C6"),t,.05,{vol:.1});tone(nf("G6"),t+.05,.06,{vol:.1})},
  super:()=>melody("C6 E6 G6 C7",.06,{vol:.14}),
  partial:()=>melody("E5 G5 E5",.08,{vol:.14}),
  miss:()=>melody("E4 C4",.12,{vol:.16}),
  wrong:t=>tone(110,t,.3,{vol:.2,type:"sawtooth"}),
  right:()=>melody("G5 C6 E6 G6 -",.07),
  hint:()=>melody("A6 E7",.08,{vol:.12,type:"triangle"}),
  caught:()=>melody("C5 E5 G5 C6 - - G5 C6 E6 - - -",.1,{},"C3 . . G2 . . C3 . . C3 - -"),
  flee:()=>melody("G5 F#5 F5 E5 - D#5 D5 - -",.08,{vol:.14},"G2 . . . . . G1 - -"),
  fanfare:()=>melody("G4 C5 E5 G5 - E5 G5 - C6 - - - - -",.11,{},"C3 . . . . G2 . . C3 - - - - -"),
  radiant:()=>melody("E6 B6 E7 G#7 B7 - E7 B7 -",.055,{vol:.1,type:"triangle"}),
  pour:t=>nz(t,2,{vol:.22,type:"bandpass",f:1400}),
  roar:t=>nz(t,2,{vol:.5,type:"lowpass",f:260}),
  chillhiss:t=>nz(t,2,{vol:.12,f:5000})
};
const LOOPS={pour:1,roar:1,chillhiss:1};
function wavURL(buf){let peak=0;for(const v of buf)peak=Math.max(peak,Math.abs(v));const g=peak>.95?.95/peak:1;
  const n=buf.length,ab=new ArrayBuffer(44+n*2),dv=new DataView(ab),ws=(o,s)=>{for(let i=0;i<s.length;i++)dv.setUint8(o+i,s.charCodeAt(i))};
  ws(0,"RIFF");dv.setUint32(4,36+n*2,true);ws(8,"WAVE");ws(12,"fmt ");dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);
  dv.setUint32(24,SR,true);dv.setUint32(28,SR*2,true);dv.setUint16(32,2,true);dv.setUint16(34,16,true);ws(36,"data");dv.setUint32(40,n*2,true);
  for(let i=0;i<n;i++)dv.setInt16(44+i*2,Math.max(-1,Math.min(1,buf[i]*g))*32767,true);
  let bin="";const u=new Uint8Array(ab);for(let i=0;i<u.length;i+=8192)bin+=String.fromCharCode.apply(null,u.subarray(i,i+8192));
  return"data:audio/wav;base64,"+btoa(bin)}
const BLOBS={};
function asURL(u){if(!AU.blob)return u;if(BLOBS[u])return BLOBS[u];const bin=atob(u.split(",")[1]),a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);
  return BLOBS[u]=URL.createObjectURL(new Blob([a],{type:"audio/wav"}))}
AU.music.addEventListener("error",()=>{if(AU.blob){AU.err=true;setAudioButtons();return}AU.blob=true;AU.pools={};const w=AU.cur;AU.cur=null;if(w&&AU.want)startTrack(AU.want)});
function renderSfx(name){if(AU.cache[name])return asURL(AU.cache[name]);
  CUR=new Float32Array(Math.ceil(SR*(LOOPS[name]?2:2.2)));try{SFX[name](0)}catch(e){}
  let end=CUR.length;if(!LOOPS[name]){while(end>1&&Math.abs(CUR[end-1])<.001)end--;end=Math.min(CUR.length,end+200)}
  AU.dur=AU.dur||{};AU.dur[name]=end/SR;const url=wavURL(CUR.subarray(0,end));CUR=null;AU.cache[name]=url;return asURL(url)}
const FAST_CD={sel:80,step:110,rustle:110,bump:200,gclick:20,click:120,spark:120,pickup:200};
function sfx(name){if(!AU.on||!AU.sfxOn||!SFX[name])return;
  renderSfx(name);const cd=FAST_CD[name]!=null?FAST_CD[name]:Math.max(150,(AU.dur&&AU.dur[name]||.3)*900);if(!gate("sfx:"+name,cd))return;
  const pool=AU.pools[name]||(AU.pools[name]={els:[],i:0});
  let el=pool.els[pool.i];if(!el){el=new Audio(renderSfx(name));pool.els[pool.i]=el}
  pool.i=(pool.i+1)%(name==="gclick"||name==="step"||name==="sel"?6:3);
  try{el.currentTime=0;const p=el.play();if(p)p.catch(()=>{})}catch(e){}}
function loopNoise(name){if(!AU.on||!AU.sfxOn)return()=>{};const el=new Audio(renderSfx(name));el.loop=true;el.play().catch(()=>{});return()=>{el.pause()}}

/* Original chiptune loops: one bar = 8 eighth-notes */
const TRACKS={
  explore:{bpm:112,lv:.13,bv:.26,
    lead:"E5 - G5 - C6 - B5 A5 G5 - E5 - C5 - D5 E5 F5 - A5 - C6 - A5 F5 G5 - - - D5 E5 F5 D5 E5 - G5 - C6 - D6 C6 B5 - A5 - E5 - A5 B5 C6 - A5 - F5 - G5 A5 G5 - - - . . . . A5 - C6 - A5 - F5 G5 B5 - D6 - B5 - G5 A5 G5 - E5 - B4 - E5 G5 A5 - - - C6 - B5 A5 F5 A5 C6 A5 F5 A5 C6 D6 D6 - B5 - G5 - A5 B5 C6 - G5 - E5 - G5 E5 D5 - E5 - F5 - G5 - E5 - G5 - C6 - B5 A5 G5 - E5 - C5 - D5 E5 F5 - A5 - C6 - A5 F5 G5 - - - D5 E5 F5 D5 E5 - G5 - C6 - D6 C6 B5 - A5 - E5 - A5 B5 C6 - A5 - F5 - G5 A5 C6 - - - - - . .",
    bass:"C3 . G3 . C3 . G3 . A2 . E3 . A2 . E3 . F2 . C3 . F2 . C3 . G2 . D3 . G2 . B2 . C3 . G3 . C3 . G3 . A2 . E3 . A2 . E3 . F2 . C3 . F2 . C3 . G2 . D3 . G2 . B2 . F2 . C3 . F2 . C3 . G2 . D3 . G2 . D3 . E2 . B2 . E2 . B2 . A2 . E3 . A2 . E3 . F2 . C3 . F2 . A2 . G2 . D3 . G2 . B2 . C3 . G3 . C3 . G3 . G2 . D3 . G2 . F2 . C3 . G3 . C3 . G3 . A2 . E3 . A2 . E3 . F2 . C3 . F2 . C3 . G2 . D3 . G2 . B2 . C3 . G3 . C3 . G3 . A2 . E3 . A2 . E3 . F2 . C3 . F2 . C3 . C3 . G2 . C3 - - -",
    drum:"k . h . s . h h",fill:"k . s s k s s s"},
  battle:{bpm:140,lv:.12,bv:.3,
    lead:"A4 C5 E5 A5 G5 E5 C5 E5 F4 A4 C5 F5 E5 C5 A4 C5 G4 B4 D5 G5 F5 D5 B4 D5 E5 - G#5 - B5 - E6 - A5 - . A5 C6 - B5 A5 F5 - . F5 A5 - G5 F5 G5 - . G5 B5 - D6 B5 E6 - - - G#5 - B5 - D5 F5 A5 D6 C6 A5 F5 A5 B4 D5 G5 B5 A5 G5 D5 G5 C5 E5 G5 C6 B5 G5 E5 G5 E5 G#5 B5 E6 D6 B5 G#5 B5 D6 - A5 - F5 - A5 D6 B5 - G5 - D5 - G5 B5 C6 - B5 A5 E5 - A5 C6 B5 - - - E5 G#5 B5 E6 A4 C5 E5 A5 G5 E5 C5 E5 F4 A4 C5 F5 E5 C5 A4 C5 G4 B4 D5 G5 F5 D5 B4 D5 E5 - G#5 - B5 - E6 - A5 - . A5 C6 - B5 A5 F5 - . F5 A5 - G5 F5 G5 - . G5 B5 - D6 B5 E6 - - - G#5 - B5 -",
    bass:"A2 A3 A2 A3 A2 A3 A2 A3 F2 F3 F2 F3 F2 F3 F2 F3 G2 G3 G2 G3 G2 G3 G2 G3 E2 E3 E2 E3 E2 E3 E2 E3 A2 A3 A2 A3 A2 A3 A2 A3 F2 F3 F2 F3 F2 F3 F2 F3 G2 G3 G2 G3 G2 G3 G2 G3 E2 E3 E2 E3 E2 E3 E2 E3 D2 D3 D2 D3 D2 D3 D2 D3 G2 G3 G2 G3 G2 G3 G2 G3 C2 C3 C2 C3 C2 C3 C2 C3 E2 E3 E2 E3 E2 E3 E2 E3 D2 D3 D2 D3 D2 D3 D2 D3 G2 G3 G2 G3 G2 G3 G2 G3 C2 C3 C2 C3 C2 C3 C2 C3 E2 E3 E2 E3 E2 E3 E2 E3 A2 A3 A2 A3 A2 A3 A2 A3 F2 F3 F2 F3 F2 F3 F2 F3 G2 G3 G2 G3 G2 G3 G2 G3 E2 E3 E2 E3 E2 E3 E2 E3 A2 A3 A2 A3 A2 A3 A2 A3 F2 F3 F2 F3 F2 F3 F2 F3 G2 G3 G2 G3 G2 G3 G2 G3 E2 E3 E2 E3 E2 E3 E2 E3",
    drum:"k h s h k k s h",fill:"k s k s s s s s"}
};
const SEMI={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
/* Chords under each bar of the two themes; remixes build new accompaniment from these so everything stays in key. */
const CHORDS={explore:"C Am F G C Am F G F G Em Am F G C G C Am F G C Am F C".split(" "),battle:"Am F G E Am F G E Dm G C E Dm G Am E Am F G E Am F G E".split(" ")};
const CH_Q={"":[0,4,7],m:[0,3,7]};
function triad(ch,oct){const m=ch.match(/^([A-G][#b]?)(m?)$/),root=SEMI[m[1][0]]+(m[1][1]==="#"?1:m[1][1]==="b"?-1:0);return CH_Q[m[2]].map(iv=>(oct+1)*12+root+iv)}
const mf=m=>440*Math.pow(2,(m-69)/12);
const nm=n=>{const m=n.match(/^([A-G])(#|b)?(\d)$/);return(+m[3]+1)*12+SEMI[m[1]]+(m[2]==="#"?1:m[2]==="b"?-1:0)};
/* Remix recipes: new tempo, instruments, rhythm feel, bass line, accompaniment and section order. No echoes, no key changes. */
Object.assign(TRACKS,{
  "explore_z-wreck":{base:"explore",bpm:100,swing:.3,lead:{type:"triangle",vol:.22},parts:[{k:"third",type:"triangle",vol:.09},{k:"stab",type:"square",vol:.03,oct:4}],bass:{s:"oompah",vol:.3},drum:"k . . h s . . h",fill:"k . s . k s s s",waves:true},
  "explore_z-volcano":{base:"explore",bpm:132,lead:{type:"sawtooth",vol:.085,stac:true},parts:[{k:"power",type:"sawtooth",vol:.045,oct:3}],bass:{s:"root8",vol:.3},drum:"k h s h k k s h",fill:"k s k s s s c c"},
  "explore_z-vault":{base:"explore",bpm:108,lead:{type:"triangle",vol:.2},parts:[{k:"arp",type:"pulse",vol:.035,oct:5}],bass:{s:"half",vol:.24},drum:"h . . . h . . .",fill:"h . h . h . c .",chime:true},
  "explore_z-reactor":{base:"explore",bpm:124,lead:{type:"pulse",vol:.12,stac:true},parts:[{k:"arp",type:"square",vol:.028,oct:4}],bass:{s:"root8",type:"pulse",vol:.13},drum:"k h s h k h s h",fill:"k k s s k k c c",hat16:true},
  "explore_z-glacier":{base:"explore",bpm:88,lead:{type:"sine",vol:.22,oct:1,stac:true},parts:[{k:"broken",type:"triangle",vol:.08,oct:4}],bass:{s:"half",vol:.17},drum:". . . . . . . .",fill:". . . . c . . .",chime:true},
  "explore_z-crater":{base:"explore",bpm:96,lead:{type:"triangle",vol:.19},parts:[{k:"pad",type:"triangle",vol:.045,oct:4},{k:"third",type:"sine",vol:.07}],bass:{s:"half",vol:.22},drum:"k . . . s . . .",fill:"k . . . s . c .",chime:true},
  "battle_radiant":{base:"battle",bpm:126,intro:2,lead:{type:"triangle",vol:.22,half:true},parts:[{k:"counter",type:"square",vol:.05,oct:5},{k:"arp",type:"pulse",vol:.028,oct:5},{k:"pad",type:"sine",vol:.045,oct:4}],bass:{s:"octave",vol:.24},drum:"k . h k s . h h",fill:"k . s k s s c c",chime:true}
});
function zoneTrack(){const z=EXP.zone&&EXP.zone.cls;return TRACKS["explore_"+z]?"explore_"+z:"explore"}
function renderTrack(name){const key="trk_"+name;if(AU.cache[key])return asURL(AU.cache[key]);
  const T=TRACKS[name],baseName=T.base||name,B=TRACKS[baseName],P=x=>x.split(/\s+/).filter(Boolean);
  const order=T.order||[0,1,2],sec=(arr,n)=>order.flatMap(o=>arr.slice(o*n,(o+1)*n));
  const lead0=P(B.lead),bass0=P(B.bass);const lead=sec(lead0,64),bassO=sec(bass0,64),chords=sec(CHORDS[baseName],8);
  const drum=P(T.drum||B.drum),fill=P(T.fill||T.drum||B.fill||B.drum),bpm=T.bpm||B.bpm,dur=60/bpm/2,steps=lead.length,total=steps*dur;
  const L=T.base?T.lead:{type:"square",vol:B.lv},BS=T.base?T.bass:{s:"orig",vol:B.bv};
  const intro=(T.intro||0)*8*dur,full=total+intro;
  CUR=new Float32Array(Math.ceil(full*SR));
  const at=i=>intro+i*dur+(T.swing&&i%2===1?dur*T.swing:0),left=t=>full-t-.03;
  for(let j=0;j<(T.intro||0)*8;j++){const t=j*dur,tr=triad(chords[0],5);tone(mf([tr[0],tr[1],tr[2],tr[0]+12][j%4]),t,dur*.45,{type:"pulse",vol:.05});tone(mf([tr[2],tr[0]+12,tr[1]+12,tr[2]+12][j%4]),t+dur/2,dur*.4,{type:"triangle",vol:.05});if(j%8===0)triad(chords[0],4).forEach(x=>tone(mf(x),t,dur*7.5,{type:"sine",vol:.04,sus:true,a:.3}));nz(t,.02,{vol:.05,f:8000})}
  const lenAt=(arr,i)=>{let n=1;while(i+n<arr.length&&arr[i+n]==="-")n++;return n};
  let lastMel=null;
  for(let i=0;i<steps;i++){const t=at(i),bar=Math.floor(i/8),pos=i%8,ch=chords[bar%chords.length];
    // melody
    let ln=lead[i];if(L.half){ln=i%2?".":(lead[i]!=="."&&lead[i]!=="-"?lead[i]:(lead[i+1]&&lead[i+1]!=="."&&lead[i+1]!=="-"?lead[i+1]:"."))}
    if(ln!=="."&&ln!=="-"){const n=L.half?2:lenAt(lead,i),m=nm(ln)+12*(L.oct||0);lastMel=m;
      const d=Math.min(L.stac?Math.min(dur*n*.9,dur*.75):dur*n*.92,left(t));tone(mf(m),t,d,{type:L.type,vol:L.vol,sus:!L.stac});
      for(const p of T.parts||[])if(p.k==="third"){const cand=[];for(let o=3;o<=6;o++)triad(ch,o).forEach(x=>cand.push(x));const h=cand.filter(x=>x<=m-3).pop();if(h)tone(mf(h),t,d,{type:p.type,vol:p.vol,sus:!L.stac})}}
    // bass
    const tri2=triad(ch,2);
    if(BS.s==="orig"){const bn=bassO[i];if(bn&&bn!=="."&&bn!=="-")tone(mf(nm(bn)),t,Math.min(dur*lenAt(bassO,i)*.92,left(t)),{type:BS.type||"triangle",vol:BS.vol,sus:true})}
    else if(BS.s==="root8")tone(mf(tri2[0]+(pos%2?12:0)),t,Math.min(dur*.8,left(t)),{type:BS.type||"triangle",vol:BS.vol,sus:true});
    else if(BS.s==="oompah"){if(pos===0)tone(mf(tri2[0]),t,Math.min(dur*1.8,left(t)),{type:"triangle",vol:BS.vol,sus:true});if(pos===4)tone(mf(tri2[2]-12),t,Math.min(dur*1.8,left(t)),{type:"triangle",vol:BS.vol,sus:true})}
    else if(BS.s==="half"){if(pos===0||pos===4)tone(mf(tri2[0]),t,Math.min(dur*3.6,left(t)),{type:BS.type||"triangle",vol:BS.vol,sus:true})}
    else if(BS.s==="octave"){if(pos!==3&&pos!==7)tone(mf(tri2[0]+(pos%2?12:0)),t,Math.min(dur*.7,left(t)),{type:"triangle",vol:BS.vol,sus:true})}
    else if(BS.s==="walk"){if(pos%2===0){const w=[tri2[0],tri2[1],tri2[2],tri2[2]+2][pos/2];tone(mf(w),t,Math.min(dur*1.8,left(t)),{type:"triangle",vol:BS.vol,sus:true})}}
    // accompaniment
    for(const p of T.parts||[]){const tr=triad(ch,p.oct||4);
      if(p.k==="stab"&&pos%2===1)tr.forEach(x=>tone(mf(x),t,Math.min(dur*.45,left(t)),{type:p.type,vol:p.vol}));
      else if(p.k==="arp"){const seq=[tr[0],tr[1],tr[2],tr[0]+12];tone(mf(seq[(i*2)%4]),t,Math.min(dur*.45,left(t)),{type:p.type,vol:p.vol});tone(mf(seq[(i*2+1)%4]),t+dur/2,Math.min(dur*.45,left(t+dur/2)),{type:p.type,vol:p.vol})}
      else if(p.k==="counter"&&pos>=4&&pos<=6){const c5=triad(ch,p.oct||5);tone(mf([c5[2],c5[1],c5[0]][pos-4]),t,Math.min(dur*.8,left(t)),{type:p.type,vol:p.vol})}
      else if(p.k==="broken"){const seq=[tr[0],tr[2],tr[1],tr[2]];tone(mf(seq[pos%4]),t,Math.min(dur*.9,left(t)),{type:p.type,vol:p.vol})}
      else if(p.k==="pad"&&pos===0)tr.forEach(x=>tone(mf(x),t,Math.min(dur*7.8,left(t)),{type:p.type,vol:p.vol,sus:true,a:.25}));
      else if(p.k==="chug"&&pos!==3&&pos!==7){const r=triad(ch,p.oct||3)[0];[r,r+7].forEach(x=>tone(mf(x),t,Math.min(dur*.35,left(t)),{type:p.type,vol:p.vol}))}
      else if(p.k==="ostinato"){const o=triad(ch,p.oct||5);tone(mf([o[0],o[0]+12,o[2],o[0]+12][pos%4]),t,Math.min(dur*.4,left(t)),{type:p.type,vol:p.vol})}
      else if(p.k==="power"&&(pos===0||pos===4)){const r=triad(ch,p.oct||3)[0];[r,r+7].forEach(x=>tone(mf(x),t,Math.min(dur*3.8,left(t)),{type:p.type,vol:p.vol,sus:true}))}}
    if(T.chime&&pos===0&&bar%2===0)tone(mf(triad(ch,6)[0]),t,.6,{type:"sine",vol:.06});
    // drums
    const d=(bar%8===7?fill:drum)[pos];
    if(d==="k")tone(150,t,.12,{type:"sine",vol:.5,to:45});else if(d==="s")nz(t,.12,{vol:.2,f:1500});else if(d==="h")nz(t,.03,{vol:.1,f:7000});else if(d==="c")nz(t,.25,{vol:.12,f:5000});
    if(T.hat16)nz(t+dur/2,.02,{vol:.06,f:8000});
    if(T.waves&&i%16===0)nz(t,Math.min(dur*14,left(t)),{vol:.12,type:"lowpass",f:300,to:900})}
  const url=wavURL(CUR);CUR=null;AU.cache[key]=url;return asURL(url)}
function startTrack(name){AU.want=name;if(!AU.on||!AU.musOn)return;
  if(AU.cur!==name){AU.music.src=renderTrack(name);AU.cur=name;AU.music.load()}
  try{AU.music.currentTime=0}catch(e){}const p=AU.music.play();if(p)p.catch(e=>{AU.err=true;setAudioButtons()})}
function stopTrack(){AU.want=null;AU.music.pause()}
function auInit(){if(AU.on)return;AU.on=true;
  // unlock a handful of elements inside the user's gesture (needed on Safari/iOS)
  AU.music.src=renderTrack(AU.want||"explore");AU.cur=AU.want||"explore";
  if(AU.want&&AU.musOn)startTrack(AU.want);
  ["sel","step","gclick"].forEach(n=>{const pool=AU.pools[n]={els:[],i:0};for(let i=0;i<3;i++){const el=new Audio(renderSfx(n));el.volume=0;el.play().then(()=>{el.pause();el.volume=1},()=>{el.volume=1});pool.els.push(el)}});
  setAudioButtons();$("#startgate").hidden=true}
function setAudioButtons(){const m=$("#au-mus"),s=$("#au-sfx");
  m.textContent=AU.err?"♪ SOUND BLOCKED":AU.musOn?"♪ MUSIC: ON":"♪ MUSIC: OFF";s.textContent=AU.sfxOn?"SFX: ON":"SFX: OFF";
  m.setAttribute("aria-pressed",AU.musOn);s.setAttribute("aria-pressed",AU.sfxOn)}
$("#au-mus").onclick=()=>{if(!AU.on){auInit();return}AU.musOn=!AU.musOn;store.set("wta_mus",AU.musOn);if(AU.musOn&&AU.want)startTrack(AU.want);else AU.music.pause();setAudioButtons()};
$("#au-sfx").onclick=()=>{if(!AU.on)auInit();AU.sfxOn=!AU.sfxOn;store.set("wta_sfx",AU.sfxOn);setAudioButtons()};
setAudioButtons();
["pointerup","click","touchend","keydown"].forEach(ev=>document.addEventListener(ev,()=>{if(!AU.on)auInit()},{capture:true}));
$("#startbtn").onclick=()=>{auInit();$("#startgate").hidden=true;if(S.phase==="explore")startTrack(zoneTrack());setTimeout(()=>sfx("right"),60)};
document.addEventListener("click",e=>{const b=e.target.closest(".btn,.tab,.mode,.ctrl button,.filters button,.el");if(b&&!b.disabled)sfx("sel")});

function cry(a,rad){if(!AU.on||!AU.sfxOn||!gate("cry",1000))return;const key="cry"+(rad?"R":"")+a.no;
  if(!AU.cache[key]){const R=mulberry(a.no*97+5),sc=[0,3,5,7,10,12,15,17];CUR=new Float32Array(Math.ceil(SR*1.3));
    const f0=110*Math.pow(2,clamp((22-a.d)/22,0,1)*2+R()),n=3+(R()*4|0),types=["square","sawtooth","triangle"];let t=0;
    for(let i=0;i<n;i++){const k=sc[R()*sc.length|0],f=f0*Math.pow(2,k/12),d=.06+R()*.1;tone(f,t,d,{type:types[(a.no+i)%3],vol:.16,to:f*Math.pow(2,(R()-.5)*.8)});t+=d*.8}
    const fl=f0*Math.pow(2,sc[R()*sc.length|0]/12);tone(fl,t,.35,{type:types[a.no%3],vol:.18,to:fl*(a.mag?1.5:.55)});if(a.mag||a.reactive)nz(t,.3,{vol:.08,f:3000});if(rad){[0,4,7,12,16].forEach((k,j)=>tone(fl*4*Math.pow(2,k/12),t+.05+j*.05,.12,{type:"triangle",vol:.08}))}
    const url=wavURL(CUR.subarray(0,Math.ceil((t+.4)*SR)));CUR=null;AU.cache[key]=url}
  const el=new Audio(asURL(AU.cache[key]));el.play().catch(()=>{})}
/* Sound cues keyed to what the dialog box says */
const SAY_FX=[[/^It's super effective/,"super"],[/^It's not very effective/,"partial"],[/^It missed/,"miss"],[/^It's not /,"wrong"],[/^It's [A-Z0-9'’ -]+!/,"right"],
  [/^Gotcha/,""],[/^Got away|^Oh no!/,""],[/^HINT/,"hint"],[/^✦/,"radiant"],[/^DANGER/,"alert"],[/^KABOOM|^FWOOM/,"whoomph"],[/^FLASH/,"spark"],[/^A glowing|^It boiled|^A choking|^It's eating|^It crumbled|^It glows/,"hiss"],[/^CLACK/,"clack"],[/^A faint tug/,"tick"],[/^Nothing\. The magnet|^The magnet slides/,"thud"],
  [/^Screeech/,"scratch"],[/skids across/,"skid"],[/swirls through/,"swirl"],[/^The scale beeps/,"beep"],[/^Plunk|^It floats/,"plunk"],[/^Clunk/,"clunk"],
  [/^Splash/,"splash"],[/^FWOOSH/,"fizz"],[/^Whoomph/,"whoomph"],[/^Click! Just a spark/,"spark"],[/^Click\./,"click"],[/^Sniff/,"hiss"],
  [/^Sample picked up|^Tool ready/,"pickup"],[/^Seven days later/,"hint"],[/^FWOOM|^FLASH/,"whoomph"],[/^Crackle/,"sizzle"],[/^Hisss/,"hiss"],[/^Pop!/,"spark"],[/^POP!/,"clack"],[/^The needle slams/,"wrong"],[/^You set the cylinder aside/,"swirl"],
  [/^You hold a scraping|^It slumps|^It pours/,"sizzle"]];
const _say=say;say=function(msg){const hit=SAY_FX.find(([re])=>re.test(msg));if(hit&&hit[1])sfx(hit[1]);_say(msg)};
const _step=step;step=function(dx,dy){const ox=EXP.x,oy=EXP.y,wasBusy=EXP.busy||S.phase!=="explore";const r=_step(dx,dy);if(wasBusy)return r;
  if(EXP.x===ox&&EXP.y===oy)sfx("bump");else sfx(tileAt(EXP.x,EXP.y)===","?"rustle":"step");return r};
const _encounter=encounter;encounter=function(){stopTrack();EXP.nextRadiant=!(typeof TUT!=="undefined"&&TUT.on&&TUT.i<=3)&&(Math.random()<1/40||(!!EXP.fromGated&&Math.random()<.1));$("#wipe").classList.toggle("gold",EXP.nextRadiant);sfx("alert");setTimeout(()=>sfx(EXP.nextRadiant?"radiant":"encounter"),600);_encounter()};
const _startExplore=startExplore;startExplore=function(){_startExplore();startTrack(zoneTrack())};
const _startRound=startRound;startRound=function(){_startRound();startTrack(S.r&&S.r.a.threat&&TLOOK[S.r.a.name]?"threat_"+TLOOK[S.r.a.name].k:S.r&&S.r.radiant?"battle_radiant":"battle");const a=S.r&&S.r.a;const rd=S.r&&S.r.radiant;setTimeout(()=>{if(a)cry(a,rd)},250)};
const _win=win;win=function(){stopTrack();sfx("caught");_win()};
const _lose=lose;lose=function(ran){stopTrack();sfx("flee");_lose(ran)};
const _endRun=endRun;endRun=function(){stopTrack();sfx("fanfare");_endRun()};
let lastClick=0;click=function(){if(!LAB.gm.sound)return;const now=performance.now();if(now-lastClick<25)return;lastClick=now;sfx("gclick")};
(function(){let stopHeat=null,stopChill=null;
  const hold=(id,name,get,set)=>{const b=$(id);b.addEventListener("pointerdown",()=>{if(b.disabled||get()||!gate("hold"+id,250))return;set(loopNoise(name))});
    ["pointerup","pointerleave","pointercancel"].forEach(ev=>b.addEventListener(ev,()=>{const s=get();if(s){s();set(null)}}))};
  hold("#btn-heat","roar",()=>stopHeat,v=>stopHeat=v);
  hold("#btn-chill","chillhiss",()=>stopChill,v=>stopChill=v)})();

