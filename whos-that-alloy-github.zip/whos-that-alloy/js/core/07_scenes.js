/* =============== CUTSCENES: letterboxed scenes played out on the map, title cards, and sepia flashbacks =============== */
const CS={on:false,skip:false,act:{},cam:null,res:null,timers:[],hid:[],adopted:[]};
function csSeen(id){return store.get("wta_cs",[]).includes(id)}
function csMark(id){const L=store.get("wta_cs",[]);if(!L.includes(id)){L.push(id);store.set("wta_cs",L)}}
function csLayer(){let L=$("#csl");if(!L){L=document.createElement("div");L.id="csl";
    L.innerHTML=`<div class="cs-panel"><div class="cs-pic"></div><b class="cs-ptitle"></b></div><div class="cs-tint"></div><div class="cs-fade"></div><div class="cs-card"><b></b><span></span></div><i class="cs-bar t"></i><i class="cs-bar b"></i><button class="cs-skip" type="button">SKIP SCENE</button>`;
    $("#mapwrap").appendChild(L);L.querySelector(".cs-skip").onclick=e=>{e.stopPropagation();csSkip()};L.onclick=()=>{if(CS.on&&DLG.open)dlgNext()}}
  return L}
const csWait=ms=>new Promise(r=>{if(CS.skip)return r();const t=setTimeout(()=>{CS.timers=CS.timers.filter(x=>x[0]!==t);r()},ms);CS.timers.push([t,r])});
function csSkip(){if(!CS.on||CS.skip)return;CS.skip=true;CS.timers.forEach(([t,r])=>{clearTimeout(t);r()});CS.timers=[];
  if(CS.res){const r=CS.res;CS.res=null;if(DLG.open){DLG.done=null;DLG.prompt=null;dlgClose()}r()}}
function csSay(who,lines){return new Promise(r=>{if(CS.skip)return r();CS.res=r;talk(who,lines,()=>{CS.res=null;EXP.busy=true;r()})})}
function csStart(){const L=csLayer();CS.on=true;CS.skip=false;CS.act={};CS.cam=null;CS.hid=[];CS.adopted=[];EXP.busy=true;EXP.path=null;clearInterval(EXP.timer);
  L.classList.add("on");$("#explore").classList.add("cs-on")}
function csEnd(){const L=csLayer();
  Object.values(CS.act).forEach(a=>{if(a.el&&!a.pl&&!a.real)a.el.remove()});
  CS.adopted.forEach(({p,x,y,op})=>{p.x=x;p.y=y;p.el.style.transition="none";p.el.style.left=(x/EXP.W*100)+"%";p.el.style.top=(y/EXP.H*100)+"%";p.el.style.opacity=op;p.el.style.removeProperty("--face");void p.el.offsetWidth;p.el.style.transition=""});
  CS.hid.forEach(e=>e.style.visibility="");CS.act={};CS.hid=[];CS.adopted=[];CS.cam=null;
  L.classList.remove("on");["cs-fade","cs-tint","cs-card","cs-panel"].forEach(c=>{const e=L.querySelector("."+c);e.style.opacity="";e.classList.remove("show")});
  $("#explore").classList.remove("cs-on");const pl=$("#player");pl.style.transition="";
  CS.on=false;CS.skip=false;EXP.busy=false;placePlayer(true)}
const SCENES={};
async function playScene(id,after){const f=SCENES[id];if(!f||CS.on||S.phase!=="explore"){after&&after();return}
  csStart();try{await f()}catch(e){console.error("scene "+id,e)}csMark(id);csEnd();after&&after()}

/* ---- actors ---- */
function csEl(x,y,html){const d=document.createElement("div");d.className="npc csact";d.style.width=(100/EXP.W)+"%";d.style.height=(100/EXP.H)+"%";d.style.left=(x/EXP.W*100)+"%";d.style.top=(y/EXP.H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));return d}
function csActor(id,look,x,y,face){const a={id,x,y,el:csEl(x,y,typeof look==="string"?look:npcSVG(look))};CS.act[id]=a;if(face)csFace(id,face);return a}
function csAdopt(id,p){CS.adopted.push({p,x:p.x,y:p.y,op:p.el.style.opacity||""});const a={id,real:1,p,el:p.el,get x(){return p.x},set x(v){p.x=v},get y(){return p.y},set y(v){p.y=v}};CS.act[id]=a;const t=p.el.querySelector(".talkmark");if(t)t.style.opacity=0;return a}
function csA(id){if(id==="player")return{pl:1,el:$("#player"),get x(){return EXP.x},set x(v){EXP.x=v},get y(){return EXP.y},set y(v){EXP.y=v}};return CS.act[id]}
function csPos(id,x,y,ms){const a=csA(id);if(!a)return;a.x=x;a.y=y;
  if(a.pl){a.el.style.transition=ms?`left ${ms}ms linear,top ${ms}ms linear`:"none";placePlayer(!ms);if(!ms){void a.el.offsetWidth}return}
  a.el.style.transition=ms?`left ${ms}ms linear,top ${ms}ms linear,opacity .5s`:"opacity .5s";a.el.style.left=(x/EXP.W*100)+"%";a.el.style.top=(y/EXP.H*100)+"%"}
function csFace(id,dx){const a=csA(id);if(!a||!dx)return;if(a.pl){EXP.face=dx;a.el.style.setProperty("--face",dx)}else a.el.style.setProperty("--face",dx)}
function csShow(id,v){const a=csA(id);if(a)a.el.style.opacity=v?"":"0"}
function csPath(a,b){const W=EXP.W,H=EXP.H,k=(x,y)=>y*W+x,[x0,y0]=a,[x1,y1]=b,prev=new Map([[k(x0,y0),-1]]),q=[[x0,y0]];
  while(q.length){const[x,y]=q.shift();if(x===x1&&y===y1)break;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,kk=k(nx,ny);if(nx<0||ny<0||nx>=W||ny>=H||prev.has(kk))continue;if(!(nx===x1&&ny===y1)&&!canWalk(tileAt(nx,ny)))continue;prev.set(kk,k(x,y));q.push([nx,ny])}}
  if(!prev.has(k(x1,y1)))return null;const P=[];let c=k(x1,y1);while(c!==k(x0,y0)){P.unshift([c%W,c/W|0]);c=prev.get(c)}return P}
async function csWalk(id,to,ms=300,o={}){const a=csA(id);if(!a)return;let P=csPath([a.x,a.y],to)||[to];if(o.max)P=P.slice(0,o.max);
  if(CS.skip){const e=P[P.length-1];if(e)csPos(id,e[0],e[1],0);return}
  for(let i=0;i<P.length;i++){const[x,y]=P[i];if(x!==a.x)csFace(id,Math.sign(x-a.x));csPos(id,x,y,ms);
    a.el.classList.remove("cs-hop");void a.el.offsetWidth;a.el.classList.add("cs-hop");if(i%2===0)sfx("step");
    if(o.follow){CS.cam=[x,y];cam()}await csWait(ms);if(CS.skip){const e=P[P.length-1];csPos(id,e[0],e[1],0);return}}}
async function csEmote(id,t,hold=1300){const a=csA(id);if(!a)return;const s=document.createElement("span");s.className="cs-emote";s.textContent=t;a.el.appendChild(s);setTimeout(()=>s.remove(),hold);if(t==="!")sfx("alert");await csWait(650)}
function csCamTo(x,y,instant){CS.cam=[x,y];cam(instant)}
{const _c=cam;cam=function(instant){const w=$("#world");if(CS.on&&CS.cam&&w&&EXP.W){const ax=(v,W,V,o)=>W<=V?-(V-W)/2:Math.max(0,Math.min(W-V+o,v-(V-1)/2)),cx=ax(CS.cam[0],EXP.W,VIEW.w,0),cy=ax(CS.cam[1]+2,EXP.H,VIEW.h,3);
    w.style.transition=instant?"none":"transform .9s ease-in-out";w.style.transform=`translate(${-cx/EXP.W*100}%,${-cy/EXP.H*100}%)`;if(instant)void w.offsetWidth;return}
  if(w&&w.style.transition.includes(".9s"))w.style.transition="";_c(instant)}}
async function csFade(v,ms=700){const f=csLayer().querySelector(".cs-fade");f.style.transition=`opacity ${ms}ms`;f.style.opacity=v;await csWait(ms)}
function csTint(v){csLayer().querySelector(".cs-tint").style.opacity=v?1:0}
async function csCard(t,sub,ms=2600){const c=csLayer().querySelector(".cs-card");c.querySelector("b").textContent=t;c.querySelector("span").textContent=sub||"";c.classList.add("show");await csWait(ms);c.classList.remove("show");await csWait(500)}
function csHideWorld(){document.querySelectorAll("#world .npc:not(.csact),#world .mapitem,#world .mapobj,#world .glintmark").forEach(e=>{if(e.style.visibility!=="hidden"){e.style.visibility="hidden";CS.hid.push(e)}})}
/* flashback panels: a sepia picture, 340 x 220, with figures stood on it */
async function csPanel(P){const L=csLayer(),pn=L.querySelector(".cs-panel");
  if(!P){pn.classList.remove("show");await csWait(700);return}
  const fig=f=>{const w=f.w||13,h=w*340/220;return`<div class="cs-fig" style="left:${f.x-w/2}%;top:${f.y-h}%;width:${w}%;height:${h}%;--face:${f.face||1}">${typeof f.look==="string"?f.look:npcSVG(f.look)}</div>`};
  pn.querySelector(".cs-pic").innerHTML=`<svg class="bg" viewBox="0 0 340 220" preserveAspectRatio="xMidYMid slice">${P.bg}</svg>`+(P.figs||[]).map(fig).join("")+(P.fg?`<svg class="bg" viewBox="0 0 340 220" preserveAspectRatio="xMidYMid slice">${P.fg}</svg>`:"");
  pn.querySelector(".cs-ptitle").textContent=P.title||"";pn.querySelector(".cs-ptitle").hidden=!P.title;pn.classList.add("show");await csWait(900)}
/* keep the player's hands off everything while a scene plays */
{const _st=step;step=function(dx,dy){if(CS.on)return false;return _st(dx,dy)}}
{const _in=interact;interact=function(){if(CS.on&&!DLG.open)return;_in()}}
{const _ob=openBag;openBag=function(){if(CS.on)return;_ob()}}
{const _oj=openJournal;openJournal=function(){if(CS.on)return;_oj()}}
{const _en=encounter;encounter=function(){if(CS.on)return;_en()}}

/* ---- helpers for placing people ---- */
function lookOf(n){for(const k in KEEPERS)if(KEEPERS[k].n===n)return KEEPERS[k].look;for(const z in AMBIENT)for(const p of AMBIENT[z])if(p.n===n)return p.look;return{coat:"#8A8A8A",hair:"#3A2414",hs:"short",acc:[]}}
const MLOOK=()=>marlowNPC(false).look;
const ODILE={coat:"#3E5A3A",hair:"#E8E8E8",hs:"bun",acc:["glasses","scarf","cane"],scarf:"#F07A1A",skin:"#E8B894"};
const ODILE_YOUNG={coat:"#3E5A3A",hair:"#2A1A10",hs:"bun",acc:["scarf"],scarf:"#F07A1A",skin:"#E8B894"};
const LITTLE_V={coat:"#4A2A5A",hair:"#E8D8A8",hs:"long",acc:["book"],skin:"#F2C7A5"};
function occupied(x,y){return(x===EXP.x&&y===EXP.y)||thingsAt(x,y).length>0||Object.values(CS.act).some(a=>a.x===x&&a.y===y)}
function nearWalk(x,y,ok){for(let r=0;r<10;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){if(Math.max(Math.abs(dx),Math.abs(dy))!==r)continue;const nx=x+dx,ny=y+dy;
    if(nx<1||ny<1||nx>=EXP.W-1||ny>=EXP.H-1)continue;const c=tileAt(nx,ny);if(canWalk(c)&&c!==","&&!occupied(nx,ny)&&(!ok||ok(nx,ny)))return[nx,ny]}return[x,y]}
function distMap(x0,y0){const D=new Map([[x0+","+y0,0]]),q=[[x0,y0]];while(q.length){const[x,y]=q.shift(),d=D.get(x+","+y);for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=nx+","+ny;if(D.has(k)||!canWalk(tileAt(nx,ny)))continue;D.set(k,d+1);q.push([nx,ny])}}return D}
function storyNPC(p,at){const d=document.createElement("div");d.className="npc";d.style.width=(100/EXP.W)+"%";d.style.height=(100/EXP.H)+"%";d.style.left=(at[0]/EXP.W*100)+"%";d.style.top=(at[1]/EXP.H*100)+"%";
  d.innerHTML=`<span class="talkmark">...</span>`+npcSVG(p.look);$("#world").insertBefore(d,$("#player"));const n={...p,x:at[0],y:at[1],el:d,said:0};EXP.npcs.push(n);return n}
function storyObj(at,svg,use,tag){const d=document.createElement("div");d.className="mapobj storyobj";d.style.width=(100/EXP.W)+"%";d.style.height=(100/EXP.H)+"%";d.style.left=(at[0]/EXP.W*100)+"%";d.style.top=(at[1]/EXP.H*100)+"%";
  d.innerHTML=svg;$("#world").insertBefore(d,$("#player"));const o={x:at[0],y:at[1],el:d,use,story:tag};EXP.objs.push(o);return o}

/* =============== FIELD ORDER STEPS: go somewhere, talk to someone, pick something up =============== */
function foStep(){const o=foCur();if(!o||!o.steps||store.get("wta_fo_on",0)!==1||foReady())return null;return o.steps[store.get("wta_fo_n",0)]||null}
function foStepDone(inRound){const o=foCur();store.set("wta_fo_n",store.get("wta_fo_n",0)+1);store.set("wta_qf_seenJ",0);journalDot();
  const m=foReady()?`Field order "${o.title}" complete! Report to Dr. Marlow.`:`New objective: ${foGoal(o)}`;
  if(inRound)setTimeout(()=>say(m),3400);else{setTimeout(()=>say0(m),80);stepPlace()}}
const STEP_TALK={
 "other:Archivist Wren":["The second line on the roster? I've been waiting months for somebody to ask me.","I held the page up to a lamp at a slant and rubbed a soft pencil over the scratches. A knife cuts the ink. It doesn't cut the dent the nib left.","'O. GRANE. Deputy Director. Surveyor. Badge 002.'","And in the back cover, in pencil, a forwarding address nobody ever rubbed out: 'care of the observatory, Starfall Crater'.","Sixty years old. I'd go and ask the projectionist. Projectionists never throw anything away."],
 "other:Projectionist Tamsin":["An old woman? Orange scarf, silver cane, sits on the rim of the crater and argues with the sky?","She comes up most clear nights. Puts a gold coin in the projector fund every time. Never gives a name.","She told me once that if anybody from the Institute ever came asking, I was to give them a message. I wrote it on the inside of a film can so I wouldn't lose it.","'Tell him I'm still counting. And tell him to come himself.'","I've no idea who 'him' is. Don't tell me. I like it better as a mystery."]};
{const _tt=talkTo;talkTo=function(p){const st=foStep();if(st&&st.kind==="talk"&&p.n===st.n&&!EXP.zone.special){const L=STEP_TALK[foCur().id+":"+st.n];if(L){talk(p.n,L,()=>foStepDone());return}}_tt(p)}}
{const _w=win;win=function(){const r=S.r,st=foStep(),z=EXP.zone&&EXP.zone.cls;_w();if(st&&st.kind==="win"&&r&&!r.tut&&!r.quest&&!r.trial&&!r.duel&&z===st.zone)foStepDone(true)}}
{const _se=startExplore;startExplore=function(){_se();if(typeof TUT!=="undefined"&&TUT.on)return;const z=EXP.zone,st=foStep();
  if(st&&st.kind==="enter"&&z.cls===st.zone&&!z.special)setTimeout(()=>{if(EXP.zone===z&&S.phase==="explore"&&!CS.on&&!DLG.open&&foStep()===st)playScene(st.scene,()=>foStepDone())},900);
  if(z===BASEMENT&&Q.s===13&&!csSeen("night"))setTimeout(()=>{if(EXP.zone===z&&S.phase==="explore"&&!CS.on&&!DLG.open)playScene("night",()=>{const m=EXP.npcs.find(p=>p.n==="Dr. Marlow");if(m)talkTo(m)})},700)}}

/* things that only exist while an order needs them */
const STONE_SVG=`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="35.5" rx="11" ry="2.4" fill="#000" opacity=".3"/><path d="M12 35 L12 12 Q12 7 20 7 Q28 7 28 12 L28 35 Z" fill="#8E877C" stroke="#3A342E" stroke-width="1.3"/><path d="M13.5 13 Q14 9 20 9" stroke="#B8B0A4" stroke-width="1" fill="none"/><path d="M16 16 H24 M16 19.5 H24 M16 23 H22" stroke="#5A544C" stroke-width="1"/><path d="M17 31 L20 26 L23 31 Z" fill="none" stroke="#3A342E" stroke-width=".9"/><circle cx="20" cy="29.4" r=".8" fill="#3A342E"/><path d="M12 30 Q9 33 10 35 M28 28 Q31 31 30 35" stroke="#5A7A3A" stroke-width="1.4" fill="none"/></svg>`;
const SATCHEL_SVG=`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="34" rx="10" ry="2" fill="#000" opacity=".3"/><path d="M9 20 Q9 17 12 17 L28 17 Q31 17 31 20 L31 32 L9 32 Z" fill="#5A4430" stroke="#2A1E12" stroke-width="1.2"/><path d="M9 20 L31 20 L28 26 L12 26 Z" fill="#6E5438" stroke="#2A1E12" stroke-width="1"/><circle cx="20" cy="26" r="2.2" fill="#FF7A1A" stroke="#2A1E12" stroke-width=".8"/><path d="M14 17 Q16 9 24 11" stroke="#2A1E12" stroke-width="1.4" fill="none"/><path d="M26 30 L33 27" stroke="#2A1E12" stroke-width="1"/></svg>`;
const STONES={"z-reactor":{at:[5,17],lines:["A squat stone post, knee high. The hall's floor has been laid carefully round it, as if the builders weren't allowed to move it.","You press the paper flat and rub the charcoal across. Letters come up white: 'Q.I. SURVEY. STONE 4 OF 9. THE HEAT RUNS NORTH.'","Underneath is a surveyor's mark: a small triangle with a dot in the middle, like an eye. Beside it, two initials. 'O.G.'"]},
 "z-vault":{at:[16,24],lines:["A marker stone by the vault's front steps, worn smooth where a century of hands have patted it for luck.","The rubbing comes up: 'Q.I. SURVEY. STONE 6 OF 9. THE GOLD IS NOT THE TREASURE.'","The same mark again. The triangle with the eye in it. 'O.G.'"]},
 "z-scrap":{at:[37,5],lines:["The last stone stands alone in the corner of the yard. The scrap has been heaped all round it for decades and never once on top of it.","The rubbing comes up: 'Q.I. SURVEY. STONE 9 OF 9. LAST STONE. WHAT THE MOOR COOKS, THE MOOR KEEPS.'","The triangle with the eye. 'O.G.'","Below it, cut much more recently, in shaky, careful letters: 'STILL COUNTING. O.'"],last:1}};
function stepPlace(){if(S.phase!=="explore"||!EXP.zone||EXP.zone.special)return;EXP.objs=EXP.objs.filter(o=>{if(o.story==="satchel"||o.story==="stone"){o.el.remove();return false}return true});
  const st=foStep(),z=EXP.zone.cls,o=foCur();if(!st||st.kind!=="obj"||st.zone!==z){nearMarks();return}
  if(st.what==="satchel"){const at=store.get("wta_fo_drop",null)||nearWalk(20,12);
    storyObj(at,SATCHEL_SVG,()=>talk("",["A Syndicate satchel, dropped in a hurry. Half a sandwich, an orange badge, and a small black ledger.","Columns of dates and samples, in pencil. 'Rod, no name, Rustvein. Vial, green, off the cove.' Beside each one, a price. Far more than the Institute pays for anything.","Most entries end the same way: 'Sold on. For the Old Lady.'","One line is underlined twice. 'She says: anything that doesn't tarnish. Anything that doesn't age. Pays in gold.'","Pressed inside the front cover in faded ink: a small stamp. A triangle with a dot in the middle, like an eye.","(You pocket the ledger. Dr. Marlow will want to see this.)"],()=>{sfx("pickup");foStepDone()}),"satchel")}
  if(st.what==="stone"){const S0=STONES[z];if(!S0)return;storyObj(S0.at,STONE_SVG,()=>talk("",S0.lines,()=>{sfx("scratch");if(S0.last)playScene("survey",()=>foStepDone());else foStepDone()}),"stone")}
  nearMarks()}
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z||z.special||(typeof TUT!=="undefined"&&TUT.on))return;const st=foStep();
  if(st&&st.kind==="win"&&st.zone==="z-mine"&&z.cls==="z-mine"&&foCur().id==="ride"){const at=store.get("wta_fo_mpos",null);if(at)storyNPC(rideMarlow(),at)}
  if(z.cls==="z-crater"&&(foDone("meet")||(foCur()&&foCur().id==="meet"&&foReady())))storyNPC(odileNPC(),nearWalk(30,9));
  stepPlace()}}
function rideMarlow(){return{n:"Dr. Marlow",look:MLOOK(),talks:[["I'm not watching. I'm looking at a rock. It's a very interesting rock."],["Walk the glittering patches slowly. That's where things settle."],["Don't mind me. I'm just standing here being proud in advance."]]}}
function odileNPC(){return{n:"Odile Grane",look:ODILE,talks:[
  ["Nine stones. Six still standing. I counted them again this spring.","My knees say it's the last time. My knees have said that for twenty years."],
  ["Aldous thinks he's the only one of us who stayed the same. He's wrong. I've been exactly this stubborn since 1962."],
  ["Grist was a decent grunt once. Quick hands, good eye. Then somebody told him what's under the Institute floor, and now he doesn't want anything else."],
  ["The quarry men said the moor cooks its rubble. They were right. They just never asked what was doing the cooking."],
  ["You've got my badge. Keep it polished. I never did."]]}}

/* =============== THE SCENES =============== */
/* 1. meeting Dr. Marlow properly */
SCENES.welcome=async()=>{const m=EXP.npcs.find(p=>p.n==="Dr. Marlow");if(!m)return;const a=csAdopt("m",m),hx=m.x,hy=m.y;
  csCamTo(hx-2,hy+1,true);csPos("m",44,4,0);csFace("m",-1);await csWait(500);
  await csSay("",["(A man in a lab coat is bent over the map table, nose almost touching a survey sheet. He's talking to it.)"]);
  await csSay("Dr. Marlow",["No, no. You were further east last spring. Don't argue with me. I have notes."]);
  await csEmote("m","!");csFace("m",1);await csWalk("m",[hx,hy],260);csFace("m",Math.sign(EXP.x-hx)||-1);
  await csSay("Dr. Marlow",["Sorry! I talk to the maps. They never talk back, which is most of what I like about them.","Dr. Marlow, head of the field team. We've met, in a way. I held the tongs in your tutorial and you did all the looking."])};

/* 2. out in the field with him */
SCENES.ride=async()=>{const px=EXP.x,py=EXP.y,D=distMap(px,py);
  let from=null;for(const[k,d]of D)if(d>=5&&d<=6){const[x,y]=k.split(",").map(Number);if(tileAt(x,y)!==","){from=[x,y];break}}from=from||nearWalk(px+3,py);
  csActor("m",MLOOK(),from[0],from[1],Math.sign(px-from[0])||-1);csCamTo((px+from[0])/2,(py+from[1])/2,true);await csWait(500);
  await csEmote("m","!");const P=csPath(from,[px,py])||[];await csWalk("m",P.length>1?P[P.length-2]:from,260);csFace("m",Math.sign(px-csA("m").x)||-1);
  await csSay("Dr. Marlow",["There you are! I've been here an hour. I came early so I could look clever when you arrived.","Come on. Let me show you something."]);
  let spot=null,best=1e9;for(const[k,d]of D){const[x,y]=k.split(",").map(Number);if(tileAt(x,y)===","||d>=best||d<2)continue;if([[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>tileAt(x+dx,y+dy)===",")&&!thingsAt(x,y).length){spot=[x,y];best=d}}
  spot=spot||nearWalk(px,py);await csWalk("m",spot,300,{follow:1});const stand=nearWalk(spot[0],spot[1],(x,y)=>!(x===spot[0]&&y===spot[1]));await csWalk("player",stand,300);
  csFace("player",Math.sign(spot[0]-EXP.x)||1);
  await csSay("",["(He crouches at the edge of the rubble and lets a handful of grit run through his fingers.)"]);
  await csSay("Dr. Marlow",["The old quarry men had a saying: the moor cooks its rubble. Leave a heap alone long enough and it comes back with metal in it. Mixed already.","Brass where there was never any copper. Bronze where nobody ever brought tin.","Nobody knows why. That's what the Institute is for. We've been asking for sixty years, and the rubble still hasn't told us."]);
  await csEmote("m","...");
  await csSay("Dr. Marlow",["Watch the surface. Where it glitters in patches, something's settled underneath. Walk through slowly, like you've got all day.","Your turn. Register something here in the mine. I'll be right here, pretending not to watch."]);
  store.set("wta_fo_mpos",[csA("m").x,csA("m").y]);
  const mm=csA("m");mm.el.remove();delete CS.act.m;storyNPC(rideMarlow(),[mm.x,mm.y])};

/* 3. the grunt at the scrapyard */
SCENES.ledger=async()=>{const px=EXP.x,py=EXP.y,D=distMap(px,py);const far=[...D].filter(([k,d])=>d>=7&&d<=9).map(([k])=>k.split(",").map(Number)).filter(([x,y])=>tileAt(x,y)!==",");
  const level=far.filter(([x,y])=>Math.abs(y-py)<=2),pool=level.length?level:far,from=pool.length?pool[Math.random()*pool.length|0]:nearWalk(px+6,py);
  await csSay("",["(You duck behind a heap of old bicycle frames and wait. It doesn't take long.)"]);
  csActor("g",gruntSVG(false),from[0],from[1],Math.sign(px-from[0])||-1);csCamTo((px+from[0])/2,(py+from[1])/2);await csWait(700);
  await csWalk("g",[px,py],330,{max:3});await csEmote("g","!");
  await csSay("Syndicate Grunt",["Oi! Institute! You never saw me! I was never here! I'm not even a grunt!"]);
  const g=csA("g"),drop=[g.x,g.y];store.set("wta_fo_drop",drop);
  await csSay("",["(The grunt spins round so fast the satchel strap snaps. It thumps to the ground, and they don't stop for it.)"]);
  const G=distMap(g.x,g.y);let run=drop,bd=-1;for(const[k,d]of G){if(d>12)continue;const[x,y]=k.split(",").map(Number),dp=D.get(k)||0;if(dp>bd){bd=dp;run=[x,y]}}
  csActor("s",SATCHEL_SVG,drop[0],drop[1]);await csWalk("g",run,150,{max:9});g.el.style.opacity=0;await csWait(600)};

/* 4. the first survey, sixty years ago */
const PANEL={
 survey:{title:"QUILLMOOR · SPRING, SIXTY YEARS AGO",bg:`<defs><linearGradient id="sv1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E8B070"/><stop offset=".6" stop-color="#F4E0B0"/></linearGradient></defs><rect width="340" height="220" fill="url(#sv1)"/><circle cx="250" cy="120" r="26" fill="#FFF0C8" opacity=".8"/><path d="M0 128 Q60 108 120 122 T240 116 T340 124 V220 H0 Z" fill="#8A7A56"/><path d="M0 150 Q90 136 170 148 T340 146 V220 H0 Z" fill="#6E6044"/><path d="M0 182 H340 V220 H0 Z" fill="#5A4E36"/><path d="M40 196 Q120 186 200 192 T330 188" stroke="#C8B070" stroke-width="1.6" stroke-dasharray="3 3" fill="none"/>${[[60,178],[90,170],[300,172]].map(([x,y])=>`<path d="M${x} ${y} q3 -8 6 0" stroke="#4A5A2A" stroke-width="1.4" fill="none"/>`).join("")}<g transform="translate(176 150)"><path d="M0 40 V8 Q0 0 12 0 Q24 0 24 8 V40 Z" fill="#8E877C" stroke="#3A342E" stroke-width="1.5"/><path d="M6 30 L12 21 L18 30 Z" fill="none" stroke="#3A342E" stroke-width="1.2"/><circle cx="12" cy="27" r="1.3" fill="#3A342E"/></g><path d="M156 106 V196" stroke="#4A3A28" stroke-width="2.4"/><path d="M152 106 H160" stroke="#C8242A" stroke-width="3"/>`,
  figs:[{look:ODILE_YOUNG,x:40,y:90,w:15}]},
 teams:{title:"THE FIRST FIVE FIELD TEAMS SET OUT",bg:`<rect width="340" height="220" fill="#EAD8B0"/><path d="M0 110 Q80 96 170 104 T340 100 V220 H0 Z" fill="#8A7A56"/><path d="M150 104 Q170 130 140 150 T160 220 H210 Q190 170 206 150 T176 104 Z" fill="#B8A478"/>${[[176,108,.35],[172,116,.42],[178,126,.5],[166,138,.6],[172,152,.72]].map(([x,y,s])=>`<g transform="translate(${x} ${y}) scale(${s})"><circle cx="0" cy="-22" r="5" fill="#3A2E20"/><path d="M-6 -16 H6 L5 0 H-5 Z" fill="#3A2E20"/><rect x="3" y="-16" width="7" height="10" rx="2" fill="#5A4430"/></g>`).join("")}<g transform="translate(262 146)"><path d="M0 60 V12 Q0 0 18 0 Q36 0 36 12 V60 Z" fill="#8E877C" stroke="#3A342E" stroke-width="2"/><path d="M9 44 L18 30 L27 44 Z" fill="none" stroke="#3A342E" stroke-width="1.6"/><circle cx="18" cy="40" r="1.8" fill="#3A342E"/></g>`},
 quarry:{title:"QUILLMOOR · 1962",bg:`<rect width="340" height="220" fill="#DCC89C"/><path d="M0 60 L70 40 L110 70 L96 150 L0 150 Z" fill="#7A6A4E"/>${[70,90,110,130].map(y=>`<path d="M0 ${y} L${100-(y-60)/10} ${y+4}" stroke="#5A4E38" stroke-width="1.2"/>`).join("")}<path d="M0 150 H340 V220 H0 Z" fill="#6E6044"/><rect x="214" y="78" width="96" height="74" fill="#9A8A6A" stroke="#4A3E2C" stroke-width="2"/><path d="M206 80 L262 44 L318 80 Z" fill="#5A4A38" stroke="#3A2E20" stroke-width="2"/><rect x="232" y="96" width="20" height="18" fill="#F2D27A" stroke="#4A3E2C" stroke-width="2"/><rect x="272" y="110" width="20" height="42" fill="#3A2E20"/><rect x="132" y="96" width="46" height="36" fill="#EFE4C4" stroke="#5A4A38" stroke-width="2"/><path d="M138 104 Q150 98 160 108 T174 104 M140 118 H170 M144 124 L152 112 L160 124" stroke="#8A6A3A" stroke-width="1.2" fill="none"/><path d="M142 132 L136 170 M168 132 L174 170" stroke="#4A3A28" stroke-width="2.4"/>`,
  figs:[{look:"M",x:30,y:88,w:15},{look:ODILE_YOUNG,x:64,y:88,w:15,face:-1}]},
 opening:{title:"OPENING DAY · MAY '64",bg:`<rect width="340" height="220" fill="#E8DCBC"/><rect x="60" y="30" width="220" height="140" fill="#B8A888" stroke="#5A4E38" stroke-width="2"/><path d="M50 34 L170 4 L290 34 Z" fill="#A89878" stroke="#5A4E38" stroke-width="2"/>${[76,106,214,244].map(x=>`<rect x="${x}" y="50" width="16" height="120" fill="#CFC2A2" stroke="#6A5E48" stroke-width="1.4"/>`).join("")}<rect x="136" y="70" width="68" height="100" fill="#3A2E20"/><rect x="118" y="40" width="104" height="16" fill="#9A8A6A" stroke="#5A4E38"/><text x="170" y="52" text-anchor="middle" font-family="Georgia,serif" font-size="10" letter-spacing="2" fill="#3A2E20">QVAERE POST MVRVM</text><path d="M126 120 Q170 128 214 120" stroke="#C8242A" stroke-width="4" fill="none"/><path d="M166 118 l-8 -8 v16 z M174 118 l8 -8 v16 z" fill="#C8242A"/><path d="M60 30 Q110 44 170 30 T280 30" stroke="#6A5A40" stroke-width="1" fill="none"/>${Array.from({length:10},(_,i)=>`<path d="M${66+i*22} ${31+Math.sin(i)*3} l6 10 l6 -10" fill="${i%2?"#C8242A":"#3B7BF0"}"/>`).join("")}<path d="M0 170 H340 V220 H0 Z" fill="#8A7A5A"/>${Array.from({length:14},(_,i)=>`<circle cx="${10+i*25}" cy="${204+(i%3)*4}" r="9" fill="#5A4A36"/>`).join("")}<path d="M236 118 V188" stroke="#4A3A28" stroke-width="2.4"/>`,
  figs:[{look:LITTLE_V,x:30,y:88,w:10},{look:"M",x:46,y:88,w:14},{look:ODILE_YOUNG,x:66,y:88,w:14,face:-1}]},
 cell:{title:"THE BASEMENT · THAT WINTER",bg:`<defs><radialGradient id="cg1"><stop offset="0" stop-color="#E8F6FF"/><stop offset=".35" stop-color="#9FD4F4" stop-opacity=".7"/><stop offset="1" stop-color="#9FD4F4" stop-opacity="0"/></radialGradient></defs><rect width="340" height="220" fill="#1C1812"/>${[40,80,120].map(y=>`<path d="M0 ${y} H90 M250 ${y} H340" stroke="#4A3E2C" stroke-width="3"/>`).join("")}${[[14,30],[30,70],[60,110],[270,30],[300,70],[282,110]].map(([x,y])=>`<rect x="${x}" y="${y-12}" width="8" height="12" fill="#6A5E48"/>`).join("")}<circle cx="170" cy="110" r="90" fill="url(#cg1)"/><rect x="146" y="70" width="48" height="84" rx="4" fill="#2A2E36" stroke="#9FD4F4" stroke-width="2"/><rect x="154" y="80" width="32" height="44" fill="#0A0C10"/><circle cx="170" cy="100" r="7" fill="#E8F6FF"/><path d="M0 176 H340 V220 H0 Z" fill="#2A241C"/>`,
  figs:[{look:ODILE_YOUNG,x:30,y:92,w:15},{look:"M",x:72,y:92,w:15,face:-1}]},
 rain:{title:"THE LAST NIGHT",bg:`<rect width="340" height="220" fill="#23272E"/><rect x="230" y="40" width="110" height="150" fill="#3A3E46"/><rect x="262" y="84" width="46" height="100" fill="#E8C878"/><path d="M0 184 H340 V220 H0 Z" fill="#1A1D22"/><path d="M262 184 L220 220 H350 L308 184 Z" fill="#E8C878" opacity=".25"/>${Array.from({length:60},(_,i)=>{const x=(i*53)%340,y=(i*37)%200;return`<path d="M${x} ${y} l-4 12" stroke="#9AA4B4" stroke-width=".9" opacity=".6"/>`}).join("")}`,
  figs:[{look:ODILE_YOUNG,x:22,y:92,w:14,face:-1},{look:"M",x:84,y:84,w:9,face:-1}]}};
/* Marlow's portrait in a flashback is always the same: he never changed */
{const _cp=csPanel;csPanel=function(P){if(P&&P.figs)P={...P,figs:P.figs.map(f=>f.look==="M"?{...f,look:marlowSVG()}:f)};return _cp(P)}}

SCENES.survey=async()=>{await csFade(1);await csCard("SIXTY YEARS AGO","Quillmoor Moor");await csPanel(PANEL.survey);await csFade(0);
  await csSay("",["Before the Institute had a roof, it had a surveyor.","She walked every map on the moor on foot, with a measuring chain, a notebook, and a temper the quarry men still talk about.","Where each map ended, she sank a stone into the ground and cut her mark into it."]);
  await csFade(1,500);await csPanel(PANEL.teams);await csFade(0,500);
  await csSay("",["When the stones were set, the first five field teams walked out past them, each one to a different corner of the moor.","Some of them never came back to Quillmoor. The stones stayed.","Somebody has been back to visit them. Recently."]);
  await csFade(1);await csPanel(null);await csFade(0)};

/* 5. two in the morning, in the basement */
SCENES.night=async()=>{const m=EXP.npcs.find(p=>p.n==="Dr. Marlow");if(!m)return;const a=csAdopt("m",m),tx=m.x,ty=m.y;
  await csFade(1,10);csTint(1);csPos("player",21,6,0);csFace("player",1);csPos("m",16,18,0);csShow("m",0);csCamTo(20,9,true);
  await csCard("2:00 AM","The founder's basement");
  await csSay("",["(You wait in the dark between the shelves. Somewhere far above you, a clock strikes two.)","(Footsteps on the stairs. Slow and careful, like someone who has come down them every night for a very long time.)"]);
  await csFade(0);csCamTo(16,15);await csWait(700);csShow("m",1);await csWait(500);
  await csWalk("m",[tx,ty],380,{follow:1});csFace("m",1);await csWait(500);
  await csSay("",["(He lays a hand flat against the cracked door of the cell, the way you'd settle a nervous horse.)"]);
  await csSay("Dr. Marlow",["Easy. Easy now. Not long.","You're growing again. I know. I can feel it through the door."]);
  await csSay("",["(The glow inside the cell slows until it matches his breathing. Then he goes very still.)"]);
  await csEmote("m","...");csFace("m",-1);csCamTo((tx+21)/2,6);await csWait(600)};

/* 6. promotions, in the Great Hall */
const PROMO={
 1:{rank:"FIELD ASSISTANT",staff:["Archivist Wren","Dr. Ines Parr","Quartermaster Hobbs","Intern Toby","Mrs. Gale"],lines:[
   ["Dr. Marlow","Right, everybody. Thank you for coming. I know Dr. Parr has a kettle on."],["Dr. Ines Parr","Two kettles. One of them works."],
   ["Dr. Marlow","Every season I stand under this seal and promote somebody, and every season Quartermaster Hobbs tells me I do it too often."],["Quartermaster Hobbs","You do."],
   ["Dr. Marlow","The men who quarried this moor used to say it cooks its rubble. The Institute was built to find out what they meant. Sixty years on, we're still asking."],
   ["Dr. Marlow","This recruit named a sample cold, with nothing but a bench and a bit of nerve. That's how the asking gets done.","Field Assistant. Congratulations."]],
  coat:["Quartermaster Hobbs","Field Assistant's coat. Blue lapels, one chevron. Sign here. And here. And there. Lovely."],after:[["Archivist Wren","Welcome to the paperwork."]]},
 2:{rank:"FIELD SCIENTIST",staff:["Archivist Wren","Dr. Ines Parr","Quartermaster Hobbs","Intern Toby","Mrs. Gale"],lines:[
   ["Dr. Marlow","Twice in one season. Hobbs, don't."],["Quartermaster Hobbs","I didn't say anything.","I wrote it down."],
   ["Dr. Marlow","Forty years ago the Slag Syndicate was three scrap dealers and a handcart, buying rods at our back door. Now they have foremen."],["Dr. Ines Parr","And badges. Orange ones. Hideous."],
   ["Dr. Marlow","This month, the Syndicate started complaining about one of us by name. In field work, I'm told, there's no higher honour.","Field Scientist. Two chevrons. Wear them where the grunts can see."]],
  coat:["Quartermaster Hobbs","Field Scientist's coat. Loops on the belt for sample vials. Please put sample vials in them and not sandwiches."],after:[["Intern Toby","I put a sandwich in mine."],["Quartermaster Hobbs","I know, Toby."]]},
 3:{rank:"FIELD STAFF",staff:["Archivist Wren","Dr. Ines Parr","Quartermaster Hobbs","Intern Toby","Mrs. Gale"],lines:[
   ["Dr. Marlow","Thirty samples. Every one of them found, tested and named by the person standing on this carpet."],
   ["Dr. Marlow","When the Institute opened, the first field teams stood exactly here and said three lines before they went out onto the moor. We've said them ever since. Field staff say them with us."],
   ["Archivist Wren","Look closely."],["Dr. Ines Parr","Name truly."],["Quartermaster Hobbs","Leave the rubble as you found it."],
   ["","(Everyone says the last line again, together. You find you already know the words.)"],
   ["Dr. Marlow","Field Staff. One of us."]],
  coat:["Quartermaster Hobbs","Long white staff coat, navy collar, three rank bars under the pocket. That one I had tailored. Don't tell him I said so."],after:[["Archivist Wren","And now you're allowed in the records room. I'll want a word with you about that, some day soon."]]},
 4:{rank:"DEPUTY SURVEYOR",staff:["Archivist Wren","Dr. Ines Parr","Quartermaster Hobbs","Chronicler Vell","Mrs. Gale"],odile:1,lines:[
   ["Dr. Marlow","I'd like to do something I should have done sixty years ago.","This is Odile Grane. Badge 002. Deputy Director of this Institute, and its first surveyor. Every map you've ever walked started with her chain."],
   ["Archivist Wren","She's back on the roster. In ink. I did it myself."],["Odile Grane","Get on with it, Aldous. My knees."],
   ["Dr. Marlow","This Institute has had one deputy surveyor. Now it has two.","For the one who looked behind the walls, and then kept looking. Deputy Surveyor."],
   ["Odile Grane","Walk the edges. Count the stones. Leave them standing."],["Chronicler Vell","She said that to me when I was nine. I thought it was about tidying up."]],
  coat:["Quartermaster Hobbs","Surveyor's coat, first-survey pattern. Miss Grane sent the measurements. I've no idea how she knew them."],after:[["Odile Grane","I counted."]]}};
function promoScene(n){return async()=>{const R=PROMO[n],ox=EXP.x,oy=EXP.y,of=EXP.face;
  await csFade(1);csHideWorld();csPos("player",27,12,0);csFace("player",1);csCamTo(27.5,4,true);
  csActor("m",MLOOK(),27,3,1);const spots=[[24,5,1],[31,5,-1],[24,8,1],[31,8,-1],[24,11,1],[31,11,-1]];
  R.staff.forEach((nm,i)=>csActor("s"+i,lookOf(nm),...spots[i]));if(R.odile)csActor("o",ODILE,30,3,-1);
  await csCard("THAT EVENING","The Great Hall, Quillmoor Institute");await csFade(0);
  await csWalk("player",[27,5],300);csFace("player",1);
  for(const[who,...L]of R.lines)await csSay(who,L);
  sfx("fanfare");for(let i=0;i<R.staff.length;i++){csEmote("s"+i,"!!");await csWait(90)}if(R.odile)csEmote("o","!!");await csWait(900);
  await csSay("",[`(Applause echoes round the hall. You are now a ${R.rank}.)`]);
  const hi=R.staff.indexOf("Quartermaster Hobbs");if(hi>=0){await csWalk("s"+hi,[26,5],260);csFace("s"+hi,1)}
  await csSay(R.coat[0],R.coat.slice(1));for(const[who,...L]of R.after)await csSay(who,L);
  await csFade(1);csPos("player",ox,oy,0);EXP.face=of;CS.cam=null;await csFade(0,500)}}
[1,2,3,4].forEach(n=>SCENES["promo"+n]=promoScene(n));

/* 7. the other line on the roster, told by the only person left who can */
SCENES.other=async()=>{const m=EXP.npcs.find(p=>p.n==="Dr. Marlow");if(m){csAdopt("m",m);csFace("m",Math.sign(EXP.x-m.x)||-1)}
  await csSay("Dr. Marlow",["Sit down a moment. There's something I should have told you in the study, and didn't.","Two lines were scratched off the first staff roster. You found out whose the first one was."]);
  await csFade(1);await csPanel(PANEL.quarry);await csFade(0);
  await csSay("Dr. Marlow",["Before there was an Institute there was a quarry house with a leaking roof, and two people who thought they could explain the rubble.","Odile Grane. She was the better scientist of the two of us, and she'd tell you so."]);
  await csFade(1,500);await csPanel(PANEL.opening);await csFade(0,500);
  await csSay("Dr. Marlow",["Opening day. I cut the ribbon. She'd surveyed every map on the moor by then, on foot, with a chain and a notebook.","Deputy Director. Badge 002. And that's little V at the front, holding a book bigger than her head."]);
  await csFade(1,500);await csPanel(PANEL.cell);await csFade(0,500);
  await csSay("Dr. Marlow",["That winter there was a fever in the quarry town. Children, mostly.","When sample one wouldn't stop growing, I wanted it locked away where it couldn't hurt anybody. Odile wanted it studied, bottled, and carried down the hill to every sickbed in Quillmoor.","Something that won't let you age, she said. Think what it could do for people who won't live to be old."]);
  await csFade(1,500);await csPanel(PANEL.rain);await csFade(0,500);
  await csSay("Dr. Marlow",["I said no. I said it badly. She took her survey notes and walked out into the rain.","That same night I scratched both our names off the roster. Mine, so nobody would come looking for what I'd made. Hers, because I was angry.","I've been sorry for sixty years. It's a long time to be sorry. I should know."]);
  await csFade(1);await csPanel(null);await csFade(0);
  await csSay("Dr. Marlow",foDone("ledger")?["Somebody has been paying for unregistered samples ever since. Anything that doesn't age. You brought me their ledger yourself, with the stamp inside the cover.","A triangle with a dot in it, like an eye. It's the surveyor's mark she cut into every stone."]:["Somebody has been paying the Syndicate for unregistered samples ever since. Anything that doesn't age.","And the payments come stamped with a triangle with a dot in it, like an eye. It's the mark she cut into every survey stone."])};

/* 8. dusk at Starfall Crater */
SCENES.meet=async()=>{const px=EXP.x,py=EXP.y,od=nearWalk(30,9);
  csActor("o",ODILE,od[0],od[1],1);csTint(0);await csWait(200);csCamTo(od[0],od[1]);
  await csSay("",["(The sun is going down behind the crater rim. An old woman in an orange scarf is sitting on an upturned crate, looking at the sky as if it owes her money.)"]);
  const P=csPath([px,py],od)||[];const stop=P.length>2?P[P.length-3]:[px,py];csCamTo((px+od[0])/2,(py+od[1])/2);await csWalk("player",stop,300);csFace("player",Math.sign(od[0]-EXP.x)||1);csFace("o",Math.sign(EXP.x-od[0])||-1);csCamTo((EXP.x+od[0])/2,(EXP.y+od[1])/2);
  await csSay("Odile Grane",["You're the recruit. The one who found him out. Wren writes to me, you know. Terrible handwriting.","Sit, if your knees still bend. Mine mostly don't."]);
  const D=distMap(EXP.x,EXP.y);let from=null;for(const[k,d]of D)if(d>=6&&d<=7){const[x,y]=k.split(",").map(Number);if(tileAt(x,y)!==","){from=[x,y];break}}from=from||nearWalk(EXP.x-5,EXP.y);
  csActor("m",MLOOK(),from[0],from[1]);await csWait(500);const beside=nearWalk(EXP.x,EXP.y,(x,y)=>Math.abs(x-EXP.x)+Math.abs(y-EXP.y)===1);csCamTo((EXP.x+from[0])/2,(EXP.y+from[1])/2);await csWalk("m",beside,340);csFace("m",Math.sign(od[0]-csA("m").x)||1);csCamTo((EXP.x+od[0]+csA("m").x)/3,(EXP.y+od[1]+csA("m").y)/3);
  await csEmote("o","...");
  await csSay("Odile Grane",["Aldous."]);await csSay("Dr. Marlow",["Odile."]);await csWait(900);
  await csSay("Odile Grane",["You look dreadful. Exactly the same, and dreadful."]);await csSay("Dr. Marlow",["You look old."]);await csSay("Odile Grane",["I am old. It's allowed. You should try it some time."]);
  await csSay("Dr. Marlow",["The stones. You've been going back to them."]);await csSay("Odile Grane",["Every spring. Somebody has to keep count, and you never would."]);
  await csSay("Odile Grane",["I didn't start the Syndicate, Aldous. I started paying people to bring me metal. Anything that wouldn't tarnish, anything that wouldn't age.","I thought that if I could make sample one again, properly, safely, I could finally carry it down the hill like I wanted to.","The people I paid told other people. Then they had foremen. Then they had badges. And I got old, and they stopped listening to old women.","Varrow runs them now. Kilnmaster Varrow, out at the old works. Grist just does her shouting for her. She doesn't want to help anybody. She wants what's under your floor."]);
  await csSay("Dr. Marlow",["He won't get it."]);
  await csSay("Odile Grane",["He'll try. That's why I wanted the recruit here as well.","(She turns to you.) He can't cut his own seals, and he can't undo what he made. One day somebody who isn't him will have to stand in that door. It could be you."]);
  await csSay("",["(She presses something small and cold into your hand. A field badge, the enamel worn right through at the edges. The number on it is 002.)"]);
  await csSay("Odile Grane",["Keep it. I haven't earned it in sixty years. You might."]);
  await csSay("Dr. Marlow",["Odile. I scratched your name off the roster."]);await csSay("Odile Grane",["I know. I read it with a pencil. Put it back."]);await csSay("Dr. Marlow",["I will."]);
  csTint(1);await csWait(900);csFace("m",1);csFace("o",1);csFace("player",1);await csWait(700);
  await csFade(1,1200);await csCard("","They sat on the rim of the crater, the three of you, until the stars came out.",3400);
  csA("m").el.remove();delete CS.act.m;csA("o").el.remove();delete CS.act.o;storyNPC(odileNPC(),od);await csFade(0,900)};

/* ---- the first survey's coat, for the second deputy surveyor ---- */
COATS.push({id:"surveyor",name:"Surveyor's Coat",desc:"A long field coat of the first survey's pattern: deep green, a leather shoulder yoke, a measuring chain looped at the belt, and badge 002 on the pocket.",how:"Earned by going to Starfall Crater at dusk.",cut:"long",body:"#3E5A3A",sleeve:"#3E5A3A",cuff:"#8A5A2E",open:()=>foDone("meet"),
  detail:`<path d="M13.6 20.6 Q20 23.6 26.4 20.6 L26 23.8 Q20 26 14 23.8 Z" fill="#8A5A2E" stroke="${INK}" stroke-width=".7"/><path d="M17.2 22.8 L20 32 L22.8 22.8" fill="none" stroke="#2E4A2A" stroke-width=".9"/>${btns(20,[26.4,28.8,31.2],"#C8A060",.6)}<rect x="22.6" y="27" width="3.6" height="3.2" rx=".5" fill="#2E4A2A" stroke="${INK}" stroke-width=".5"/><circle cx="24.4" cy="28.6" r="1" fill="#E8E0C8" stroke="${INK}" stroke-width=".3"/><path d="M10.6 32.4 H29.4" stroke="#6A4A22" stroke-width="1.3"/><path d="M12 33 q1.2 1.6 2.4 0 q1.2 1.6 2.4 0 q1.2 1.6 2.4 0" stroke="#B8B0A0" stroke-width=".6" fill="none"/><path d="M15 21 L16.2 26.4 M25 21 L23.8 26.4" stroke="#F07A1A" stroke-width=".8"/>`,
  arms:chev(4,"#F07A1A")});

/* =============== WHEN PEOPLE SAY THEY'RE GOING SOMEWHERE, THEY GO =============== */
function npcTravel(p,to,vanish,after){if(!p||!p.el||S.phase!=="explore"){after&&after();return}
  SCENES.__go=async()=>{const a={real:1,el:p.el,get x(){return p.x},set x(v){p.x=v},get y(){return p.y},set y(v){p.y=v}};CS.act.t=a;const tm=p.el.querySelector(".talkmark");if(tm)tm.style.opacity=0;
    await csWalk("t",to,220,{follow:1});
    if(vanish){p.el.style.transition="opacity .6s";p.el.style.opacity=0;await csWait(650);p.el.remove();EXP.npcs=EXP.npcs.filter(q=>q!==p)}else if(tm)tm.style.opacity=""};
  playScene("__go",()=>{delete SCENES.__go;after&&after()})}
{const _mk=csMark;csMark=function(id){if(!id.startsWith("__"))_mk(id)}}
const OFFICE_DOOR=[36,6];
function marlowAway(){const o=foCur();return !!o&&store.get("wta_fo_on",0)===1&&!foReady()&&(o.id==="ride"||o.id==="meet")}
/* he takes his coat and heads out as soon as he's given you the order */
{const _fa=foAccept;foAccept=function(){_fa();const o=foCur();if(!o||(o.id!=="ride"&&o.id!=="meet"))return;const m=EXP.npcs&&EXP.npcs.find(p=>p.n==="Dr. Marlow");if(!m||EXP.zone.cls!=="z-quill"||EXP.zone.special)return;
  setTimeout(()=>{if(DLG.open||CS.on)return;npcTravel(m,OFFICE_DOOR,true,()=>say0(o.id==="ride"?"Dr. Marlow grabbed his coat and headed off to Rustvein Mine.":"Dr. Marlow straightened his collar and set off for Starfall Crater."))},250)}}
/* after you've registered something in the mine, he says goodbye and walks out */
SCENES.rideBye=async()=>{const at=store.get("wta_fo_mpos",null)||nearWalk(EXP.x+3,EXP.y);csActor("m",MLOOK(),at[0],at[1]);csCamTo(EXP.x,EXP.y);await csWait(300);
  const beside=nearWalk(EXP.x,EXP.y,(x,y)=>Math.abs(x-EXP.x)+Math.abs(y-EXP.y)===1);await csWalk("m",beside,260);csFace("m",Math.sign(EXP.x-csA("m").x)||1);
  await csSay("Dr. Marlow",["Lovely! I watched the whole thing. I wasn't very good at pretending not to.","I'm heading back to the office to write it up while it's fresh. Come and find me there."]);
  await csWalk("m",nearWalk(24,24),240,{follow:1});csA("m").el.style.opacity=0;await csWait(600)};
{const _se=startExplore;startExplore=function(){_se();const z=EXP.zone,o=foCur();
  if(z&&z.cls==="z-mine"&&!z.special&&o&&o.id==="ride"&&foReady()&&!csSeen("rideBye")&&store.get("wta_fo_mpos",null))setTimeout(()=>{if(EXP.zone===z&&S.phase==="explore"&&!CS.on&&!DLG.open)playScene("rideBye")},900)}}
/* the keepers who hand over a page and then say they're going home */
const HOMEWARD={wreck:["Right. I'm off home to write my grandmother an apology. Harbour office, north-west corner of the cove, if you need me."],volcano:["I will carry my thanks back up to the fire now, and sit with it a while. You know where to find me."]};
{const _pt=pageTake;pageTake=function(id){_pt(id);const L=HOMEWARD[id],z="z-"+id;if(!L||!EXP.zone||EXP.zone.cls!==z||EXP.zone.special)return;const K=EXP.npcs.find(p=>p.keeper),home=SPOTS[z]&&SPOTS[z].home;if(!K||!home||(K.x===home[0]&&K.y===home[1]))return;
  setTimeout(()=>{if(DLG.open||CS.on)return;talk(K.n,L,()=>npcTravel(K,home,false))},400)}}

/* journal order: every objective first, then side quests, then evidence and notes */
function journalTidy(){const m=$("#journal");if(!m||m.hidden)return;const list=m.querySelector(".bag-list"),kids=[...list.children];
  const obj=kids.filter(e=>(e.classList.contains("obj")&&!e.classList.contains("fav"))||e.classList.contains("obj-h")),side=kids.filter(e=>e.classList.contains("side")||e.classList.contains("sq-h")),rest=kids.filter(e=>!obj.includes(e)&&!side.includes(e)&&!e.classList.contains("obj-none"));
  const sd=side.filter(e=>!e.classList.contains("sq-h"));sd.forEach(e=>{e.classList.add("obj","fav");const b=e.querySelector("b");if(b)b.textContent=b.textContent.replace(/^Favour:\s*/,"")});
  let keep=rest;if(typeof FIN==="function"&&FIN()>=4)keep=rest.filter(e=>!(e.classList.contains("clue")||(e.tagName==="H5"&&/EVIDENCE|NOTES/.test(e.textContent))));
  const all=[...obj,...sd];if(all.length<=1){const n=document.createElement("div");n.className="bag-item key obj obj-none";n.innerHTML=`<b>NOTHING URGENT</b><p>No quests on the go. Dr. Marlow always has field orders, and people around the maps often need a hand.</p>`;all.push(n)}
  list.replaceChildren(...all,...keep)}
{const _oj=openJournal;openJournal=function(){_oj();journalTidy()}}


/* =============== DR. MARLOW, REDRAWN: a young man of the 1920s who never got any older. Big dark wavy hair, thick round glasses (the left lens chipped), a grin that won't quit, and a tweed suit under an open lab coat. =============== */
/* (marlowSVG: superseded; the version in use is further up) */

/* =============== THE BASEMENT, REBUILT: six rooms, each one with a job. His office, the first lab, the cell, a storeroom with a leak, the landing, and the corner where he slept. =============== */
const bmRoom=(x,y)=>y<=8?(x<=8?"off":x<=22?"lab":"cel"):(x<=8?"sto":x<=22?"lan":"nok");
function bmFloor(x,y,M){const r=bmRoom(x,y),h=(x*7+y*13)%11;
  if(r==="off"){if(x>=3&&x<=6&&y>=5&&y<=7)return"bm-rug"+(y===5?" rt":"")+(y===7?" rb":"");return"bm-oak v"+(y%2)}
  if(r==="lab")return"bm-chk"+(h===0?" crk":"");
  if(r==="cel"){const ring=x>=25&&x<=29&&y>=2&&y<=7&&(x===25||x===29||y===2||y===7);return ring?"bm-haz":"bm-steel"}
  if(r==="sto"){const n=[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>(M[y+dy]||"")[x+dx]==="~");return n?"bm-damp":"bm-earth v"+(h%3)}
  if(r==="nok"){if(x>=26&&x<=28&&y>=13&&y<=15)return"bm-rag";return"bm-board"}
  return"bm-flag v"+((x+y*3)%4)+(h===5?" stain":"")}
const BM={
 H:{tall:1,svg:(x,y,M,s)=>{const cols=[["#6A2A2A","#2E4A6A","#6A5A2A","#3A5A3A","#5A3A5A"],["#3A4A5A","#7A5A2A","#5A2A2A","#2A4A3A","#6A6A5A"]][s%2];let b="";
   [[4,10],[12,18],[20,26]].forEach(([t,bt],r)=>{let xx=9;for(let i=0;i<6;i++){const w=2.2+((s+i*3+r)%3)*.6,gap=(s+i+r)%5===0;if(!gap)b+=`<rect x="${xx}" y="${bt-6+((i+r)%2)}" width="${w}" height="${6-((i+r)%2)}" fill="${cols[(i+r)%5]}" stroke="#1A1008" stroke-width=".4"/>`;xx+=w+.4;if(xx>29)break}});
   if(s%3===0)b+=`<rect x="24" y="21" width="2.4" height="6" fill="#6A5A2A" stroke="#1A1008" stroke-width=".4" transform="rotate(24 25 26)"/>`;
   return`<rect x="7" y="2" width="26" height="33" fill="#4E3420" stroke="#1E1208" stroke-width="1.3"/><rect x="8.4" y="3.4" width="23.2" height="30" fill="#2A1C10"/>${b}${[10,18,26,33].map(y=>`<rect x="8" y="${y}" width="24" height="1.6" fill="#5E4028"/>`).join("")}<path d="M8 3.6 H32" stroke="#B8B0A0" stroke-width=".6" opacity=".5"/>`}},
 j:{tall:1,svg:(x,y,M,s)=>{const L=["#9AC89A","#D8B870","#C8D8E0","#B89AC8","#E0C0A0"];let b="";[[12,5],[24,17]].forEach(([bt,top],r)=>{for(let i=0;i<3;i++){const cx=12+i*8,h=5+((s+i+r)%3);b+=`<rect x="${cx-2.8}" y="${bt-h}" width="5.6" height="${h}" rx="1.2" fill="${L[(s+i*2+r)%5]}" fill-opacity=".7" stroke="#3A342C" stroke-width=".6"/><rect x="${cx-2.2}" y="${bt-h-1.2}" width="4.4" height="1.4" fill="#5A4A38"/><rect x="${cx-2}" y="${bt-h/2-.8}" width="4" height="1.8" fill="#EFE6D0" opacity=".85"/>`}});
   return`<rect x="6" y="3" width="28" height="31" fill="#4A3624" stroke="#1E1208" stroke-width="1.2"/><rect x="7.4" y="4.4" width="25.2" height="28" fill="#261A10"/>${b}${[12.4,24.4,32.4].map(y=>`<rect x="7" y="${y}" width="26" height="1.6" fill="#5E4428"/>`).join("")}`}},
 C:{tall:1,svg:(x,y,M)=>{const l=M[y][x-1]!=="C",r=M[y][x+1]!=="C",k=x%5;const scr=[`<path d="M6 12 H16 M8 15 L12 11 L14 15 M20 12 q2 -3 4 0 t4 0" />`,`<path d="M4 11 H14 M9 8 V14 M18 13 H30 M22 10 Q26 7 28 12" /><circle cx="33" cy="12" r="2.4"/>`,`<path d="M5 12 L10 12 L12 9 L14 16 L16 12 H22 M26 9 V16 M24 12.5 H28"/>`,`<path d="M4 10 Q10 5 16 10 T28 10 M6 16 H30"/><path d="M30 8 l3 2 l-3 2"/>`,`<path d="M6 11 H12 M6 14 H16 M20 9 L26 15 M26 9 L20 15 M30 10 V16"/>`][k];
   return`<rect x="${l?2:0}" y="5" width="${40-(l?2:0)-(r?2:0)}" height="21" fill="#2F3B33"/><rect x="${l?1:0}" y="4" width="${40-(l?1:0)-(r?1:0)}" height="2" fill="#6B4A2E"/><rect x="${l?1:0}" y="25" width="${40-(l?1:0)-(r?1:0)}" height="2.4" fill="#6B4A2E"/>${l?`<rect x="1" y="4" width="2" height="23.4" fill="#6B4A2E"/>`:""}${r?`<rect x="37" y="4" width="2" height="23.4" fill="#6B4A2E"/>`:""}<g stroke="#D8DCD0" stroke-width=".8" fill="none" opacity=".55">${scr}</g><path d="M4 20 Q14 18 24 21 T38 19" stroke="#B8C0B4" stroke-width="3" opacity=".12" fill="none"/>${k===2?`<rect x="14" y="26" width="4" height="1.2" fill="#E8E8E0"/>`:""}`}},
 B:{svg:(x,y,M)=>{const l=M[y][x-1]!=="B",r=M[y][x+1]!=="B",k=x%3;const glass=[`<path d="M11 18 L11 13 L9 9 H15 L13 13 L13 18 Z" fill="#CFE6E4" fill-opacity=".6" stroke="#4A5A5A" stroke-width=".7"/><path d="M22 18 V11 M26 18 V12 M30 18 V13" stroke="#A8C8C4" stroke-width="2.2"/><rect x="20" y="15" width="12" height="1.4" fill="#6B4A2E"/>`,`<circle cx="18" cy="14" r="3.6" fill="#D8C8A0" fill-opacity=".55" stroke="#5A4A3A" stroke-width=".7"/><path d="M21 12.6 L31 9" stroke="#5A4A3A" stroke-width="1.4"/><path d="M13 18 L16 16" stroke="#5A4A3A" stroke-width="1"/>`,`<path d="M10 18 L14 10 L18 18 Z" fill="#CFE0D8" fill-opacity=".5" stroke="#4A5A5A" stroke-width=".7"/><rect x="24" y="12" width="7" height="6" fill="#EFE6D0" stroke="#5A4A3A" stroke-width=".6"/><path d="M25 14 H30 M25 16 H29" stroke="#8A7A5A" stroke-width=".5"/>`][k];
   return`${glass}<rect x="${l?3:0}" y="18" width="${40-(l?3:0)-(r?3:0)}" height="4" fill="#6E5236" stroke="#2A1C10" stroke-width="1"/><rect x="${l?3:0}" y="22" width="${40-(l?3:0)-(r?3:0)}" height="2" fill="#4A3622"/>${l?`<rect x="5" y="24" width="3" height="11" fill="#4A3622"/>`:""}${r?`<rect x="32" y="24" width="3" height="11" fill="#4A3622"/>`:""}<path d="M${l?3:0} 18.6 H${40-(r?3:0)}" stroke="#B8B0A0" stroke-width=".5" opacity=".5"/>`}},
 F:{tall:1,svg:`<path d="M24 1 V9" stroke="#3A3430" stroke-width="4"/><rect x="6" y="9" width="28" height="26" rx="2" fill="#7A4A34" stroke="#2A1810" stroke-width="1.3"/>${[13,18,23,28].map((y,i)=>`<path d="M6 ${y} H34" stroke="#5A3424" stroke-width=".7"/>${[10,16,22,28].map(x=>`<path d="M${x+(i%2?3:0)} ${y-5} V${y}" stroke="#5A3424" stroke-width=".6"/>`).join("")}`).join("")}<path d="M13 34 V24 Q20 16 27 24 V34 Z" fill="#2A2624" stroke="#1A1614" stroke-width="1.2"/><path d="M15 32 H25 M15 29 H25" stroke="#3E3A36" stroke-width=".8"/><circle cx="24" cy="27" r=".9" fill="#8A8278"/><path d="M8 10 Q12 6 18 9" stroke="#1A1614" stroke-width="2" opacity=".4" fill="none"/>`},
 X:{svg:(x,y,M,s)=>s%3===0?`<ellipse cx="14" cy="20" rx="7" ry="3" fill="#6A4A2E" stroke="#2A1C10"/><path d="M7 20 V32 Q14 35 21 32 V20" fill="#6A4A2E" stroke="#2A1C10"/><path d="M7 24 Q14 27 21 24 M7 29 Q14 32 21 29" stroke="#3A3430" stroke-width="1.2" fill="none"/><ellipse cx="27" cy="24" rx="6" ry="2.6" fill="#5E4228" stroke="#2A1C10"/><path d="M21 24 V33 Q27 35.6 33 33 V24" fill="#5E4228" stroke="#2A1C10"/><path d="M21 28 Q27 30.6 33 28" stroke="#3A3430" stroke-width="1.2" fill="none"/>`
   :s%3===1?`<rect x="6" y="18" width="16" height="16" fill="#8A6A44" stroke="#2A1C10" stroke-width="1.1"/><path d="M6 18 L22 34 M22 18 L6 34" stroke="#6A4E30" stroke-width="1"/><rect x="20" y="22" width="14" height="12" fill="#7A5C3A" stroke="#2A1C10" stroke-width="1.1"/><path d="M20 28 H34" stroke="#5A4028"/><rect x="11" y="9" width="12" height="9" fill="#9A7A52" stroke="#2A1C10" stroke-width="1"/><text x="17" y="15.6" text-anchor="middle" font-size="4" font-family="Georgia,serif" fill="#3A2A1A">Q.I.</text>`
   :`<path d="M6 34 Q5 24 11 22 Q17 21 18 28 Q19 34 12 35 Z" fill="#A89A7A" stroke="#4A4030" stroke-width="1"/><path d="M16 34 Q15 22 23 20 Q31 20 32 28 Q33 35 24 35 Z" fill="#B8AA88" stroke="#4A4030" stroke-width="1"/><path d="M21 22 Q23 19 26 21" stroke="#4A4030" stroke-width="1.4" fill="none"/><path d="M9 27 Q12 25 14 28" stroke="#8A7A5A" fill="none"/>`},
 D:{svg:`<path d="M5 34 Q4 18 12 14 Q20 11 28 14 Q36 18 35 34 Z" fill="#D8D2C4" stroke="#6A6458" stroke-width="1.1"/><path d="M12 15 Q14 24 11 34 M20 12.6 Q21 24 19 34 M28 15 Q26 24 29 34" stroke="#B0A898" stroke-width=".9" fill="none"/><path d="M5 34 Q12 31 20 34 T35 34" stroke="#8A8478" fill="none"/><ellipse cx="20" cy="14" rx="7" ry="1.4" fill="#EFEAE0" opacity=".6"/>`},
 N:{svg:(x,y,M)=>{const head=M[y][x+1]==="N";return head?`<rect x="4" y="12" width="4" height="23" fill="#3A3A40" stroke="#1A1A1E"/><rect x="6" y="19" width="34" height="9" fill="#6A6A62" stroke="#2A2A26" stroke-width="1"/><path d="M6 22 H40" stroke="#8A8A80"/><rect x="9" y="16" width="10" height="5" rx="2" fill="#E8E4DA" stroke="#6A6458"/><path d="M8 34 V28" stroke="#3A3A40" stroke-width="2"/>`
   :`<rect x="0" y="19" width="32" height="9" fill="#6A6A62" stroke="#2A2A26" stroke-width="1"/><path d="M0 22 H32" stroke="#8A8A80"/><path d="M4 19 Q14 15 22 19 L22 28 L4 28 Z" fill="#5A6A7A" stroke="#2A3440" stroke-width=".8"/><rect x="32" y="15" width="4" height="20" fill="#3A3A40" stroke="#1A1A1E"/><path d="M31 34 V28" stroke="#3A3A40" stroke-width="2"/>`}},
 t:{svg:`<rect x="8" y="18" width="24" height="4" fill="#6E5236" stroke="#2A1C10"/><path d="M11 22 V34 M29 22 V34" stroke="#4A3622" stroke-width="2.4"/><rect x="12" y="13" width="3" height="5" fill="#EFE6C8" stroke="#6A6458" stroke-width=".6"/><path d="M13.5 13 V11.6" stroke="#2A2420" stroke-width=".7"/><path d="M19 13.6 H24 V18 H19 Z" fill="#8A9098" stroke="#3A3E44" stroke-width=".7"/><path d="M24 14.6 Q26.4 15.8 24 17" stroke="#3A3E44" stroke-width=".7" fill="none"/><rect x="25" y="15.6" width="6" height="2.4" fill="#6A2A22" stroke="#2A1C10" stroke-width=".5"/>`},
 l:{tall:1,svg:`<path d="M20 12 V34 M14 35 H26" stroke="#3A3430" stroke-width="2"/><path d="M16 12 H24 L23 4 H17 Z" fill="#D8D0B8" fill-opacity=".45" stroke="#3A3430" stroke-width="1"/><path d="M18 12 V8 H22 V12" stroke="#3A3430" stroke-width=".8" fill="none"/><rect x="18.5" y="7.4" width="3" height="1.6" fill="#1A1614"/>`},
 k:{svg:`<rect x="17" y="16" width="6" height="19" fill="#4A4E54" stroke="#1E2024" stroke-width="1"/><rect x="15" y="14" width="10" height="3" fill="#5E646A" stroke="#1E2024" stroke-width=".8"/>${[20,24,28,32].map((y,i)=>`<ellipse cx="${26+i%2}" cy="${y}" rx="2.2" ry="1.4" fill="none" stroke="#7A7E84" stroke-width="1"/>`).join("")}<circle cx="20" cy="20" r="1" fill="#8A9098"/>`},
 m:{svg:`<rect x="7" y="8" width="26" height="22" rx="1.5" fill="#4E555C" stroke="#1E2024" stroke-width="1.1"/>${[[14,16],[26,16]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4.4" fill="#E8E4D8" stroke="#1E2024"/><path d="M${x} ${y} L${x+2.4} ${y-2}" stroke="#B8242A" stroke-width=".9"/>`).join("")}<rect x="11" y="23" width="18" height="3" fill="#2A2E32"/><path d="M13 30 V35 M27 30 V35" stroke="#3A3E44" stroke-width="2.4"/>`},
 a:{svg:`<path d="M9 34 V17 Q9 10 20 10 Q31 10 31 17 V34 Z" fill="#6A3A2A" stroke="#2A140C" stroke-width="1.2"/><rect x="6" y="20" width="7" height="13" rx="3" fill="#7A4632" stroke="#2A140C"/><rect x="27" y="20" width="7" height="13" rx="3" fill="#7A4632" stroke="#2A140C"/><rect x="12" y="24" width="16" height="8" rx="2" fill="#7A4632" stroke="#2A140C"/><path d="M20 12 Q18 16 21 18" stroke="#4A2418" fill="none"/><path d="M14 27 q2 -2 3 0" stroke="#E8DCC0" stroke-width="1.4" fill="none"/>`}};
/* what sixty years leaves behind, put down on purpose rather than sprinkled on every tile */
const BM_WEB=`<path d="M0 0 L16 0 M0 0 L0 16 M0 0 L13 9 M0 0 L9 13" stroke="#D8D4C8" stroke-width=".5" opacity=".7"/><path d="M5 0 Q4 4 0 5 M10 0 Q8 8 0 10 M15 0 Q12 12 0 15" stroke="#D8D4C8" stroke-width=".45" fill="none" opacity=".6"/>`;
const BM_DECAL={"2,3":"papers","4,3":"papers","3,4":"chair","5,2":"papers","14,6":"glass","19,2":"glass","12,7":"book","21,6":"chalk","5,15":"trail","6,16":"trail","27,6":"scorch","28,3":"scorch","26,2":"frost","26,14":"candles","28,11":"blanket","16,4":"ash"};
const BM_STEPS=[[16,17],[16,16],[16,15],[16,14],[16,13],[16,12],[16,11],[16,10],[16,8],[17,7],[18,6],[19,6],[20,6],[21,5],[22,4],[24,4],[25,5]];
function bmDecal(x,y,M){let d="";const k=x+","+y,n=(dx,dy)=>(M[y+dy]||"")[x+dx]==="#";
  if(n(-1,0)&&n(0,-1))d+=BM_WEB;if(n(1,0)&&n(0,-1))d+=`<g transform="translate(40 0) scale(-1 1)">${BM_WEB}</g>`;
  const t=BM_DECAL[k];
  if(t==="papers")d+=`<rect x="8" y="16" width="10" height="13" fill="#E8E0CC" transform="rotate(-18 13 22)" opacity=".85"/><rect x="20" y="20" width="10" height="13" fill="#DCD2BA" transform="rotate(24 25 26)" opacity=".85"/><path d="M10 20 H16 M10 23 H15" stroke="#8A7A5A" stroke-width=".5" transform="rotate(-18 13 22)"/>`;
  if(t==="chair")d+=`<g transform="rotate(80 20 26)"><rect x="12" y="18" width="16" height="3" fill="#5A3E26" stroke="#2A1C10"/><path d="M14 21 V32 M26 21 V32 M14 18 V8 M26 18 V8 M14 11 H26" stroke="#4A3220" stroke-width="2"/></g>`;
  if(t==="glass")d+=`<path d="M12 28 l3 -3 l2 3 z M20 31 l4 -2 l1 3 z M26 26 l2 -1 l.6 2 z M16 33 l2 -1 l.5 1.5z" fill="#CFE6E4" opacity=".75"/>`;
  if(t==="book")d+=`<rect x="13" y="22" width="12" height="9" fill="#6A2A22" stroke="#2A1C10" stroke-width=".6" transform="rotate(12 19 26)"/><path d="M19 22 V31" stroke="#EFE6D0" stroke-width=".6" transform="rotate(12 19 26)"/>`;
  if(t==="chalk")d+=`<rect x="16" y="28" width="5" height="1.6" fill="#EDEDE6" transform="rotate(-20 18 29)"/><ellipse cx="22" cy="30" rx="5" ry="1.6" fill="#D8D8D0" opacity=".35"/>`;
  if(t==="trail")d+=`<path d="M10 0 Q16 14 12 24 T18 40" stroke="#6A8484" stroke-width="5" fill="none" opacity=".35"/>`;
  if(t==="scorch")d+=`<ellipse cx="20" cy="26" rx="12" ry="6" fill="#1A1A18" opacity=".45"/><ellipse cx="20" cy="26" rx="6" ry="3" fill="#0E0E0C" opacity=".4"/>`;
  if(t==="frost")d+=`<path d="M20 20 l0 -8 M20 20 l7 -4 M20 20 l7 4 M20 20 l0 8 M20 20 l-7 4 M20 20 l-7 -4" stroke="#CFEAF4" stroke-width=".8" opacity=".6"/>`;
  if(t==="candles")d+=`<rect x="12" y="26" width="2.4" height="5" fill="#EFE6C8"/><rect x="18" y="28" width="2.4" height="3.4" fill="#EFE6C8"/><rect x="24" y="25" width="2.4" height="6" fill="#EFE6C8"/><ellipse cx="19" cy="31.6" rx="9" ry="1.6" fill="#EFE6C8" opacity=".4"/>`;
  if(t==="blanket")d+=`<path d="M6 30 Q14 22 24 28 T36 30 L34 36 L8 36 Z" fill="#5A6A7A" opacity=".85" stroke="#2A3440" stroke-width=".6"/>`;
  if(t==="ash")d+=`<ellipse cx="20" cy="34" rx="10" ry="2.4" fill="#2A2624" opacity=".4"/>`;
  const si=BM_STEPS.findIndex(([a,b])=>a===x&&b===y);if(si>=0)d+=`<g fill="#2A241C" opacity=".32"><ellipse cx="${si%2?15:25}" cy="14" rx="2.4" ry="3.6"/><ellipse cx="${si%2?25:15}" cy="30" rx="2.4" ry="3.6"/></g>`;
  if(bmRoom(x,y)==="lab"&&!t&&si<0&&(x*5+y*3)%7===0)d+=`<ellipse cx="${14+(x%3)*6}" cy="${18+(y%3)*6}" rx="9" ry="5" fill="#4A463C" opacity=".22"/>`;
  return d?`<svg viewBox="0 0 40 40" aria-hidden="true" style="position:absolute;inset:0;width:100%;height:100%">${d}</svg>`:""}
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){if(EXP.zone.cls!=="z-basement")return _tl(c,x,y,seed,M);
  if(c==="#"||c==="~")return _tl(c,x,y,seed,M);const fl=bmFloor(x,y,M),P=BM[c];
  if(P)return[`f ${P.tall?"tl":"pr"} ${fl}`,PS(typeof P.svg==="function"?P.svg(x,y,M,seed):P.svg)];
  if(c==="c")return[`f pr ${fl}`,PS(CRATE+`<path d="M7 11 Q13 7 19 11" stroke="#E8E4D8" stroke-width=".5" fill="none" opacity=".6"/>`)];
  if(c==="K"||c==="S")return[`f pr ${fl}`,PS(BPROPS[c])];
  return[`f ${fl}`,bmDecal(x,y,M)]}}

/* the basement gets its own remix: a slow music-box version of the theme over a heartbeat and a ticking clock, two in the morning */
TRACKS["explore_z-basement"]={base:"explore",bpm:74,lead:{type:"sine",vol:.21,oct:1,stac:true,half:true},parts:[{k:"pad",type:"sine",vol:.05,oct:3},{k:"broken",type:"triangle",vol:.045,oct:5}],bass:{s:"half",type:"sine",vol:.2},drum:"k . k . h . . .",fill:"k . k . h . c .",chime:true};
/* and the Slag Works gets its own: a swung, clanking foundry shuffle */
TRACKS["explore_z-slag"]={base:"explore",bpm:118,swing:.18,lead:{type:"square",vol:.075,stac:true},parts:[{k:"chug",type:"sawtooth",vol:.032,oct:2},{k:"stab",type:"pulse",vol:.028,oct:4}],bass:{s:"walk",vol:.28},drum:"k . s k k . s .",fill:"k s k s c . c c"};


/* =============== TOOLS CAN ALWAYS BE EARNED: each tool favour has its own state, so no page progress, old save or odd order can ever lock one out =============== */
const TQ=k=>store.get("wta_tq_"+k,0),setTQ=(k,v)=>store.set("wta_tq_"+k,v);
/* pick: Ole's favour runs whenever you haven't got it */
QFIND.pick.when=()=>!hasTool("pick")&&(PQ("glacier")===2||TQ("pick")===1);
QFIND.pick.done=()=>{giveTool("pick");if(PQ("glacier")===2)setPQ("glacier",3);setTQ("pick",2);say0("You found the INSTITUTE ICE PICK at the bottom of the pool. Cracked rock and ice blocks can be broken now.")};
/* lamp: Dray's favour runs whenever you haven't got one */
QFIND.draylamp.when=()=>!hasTool("lamp")&&(PQ("mine")===1||TQ("lamp")===1);
QFIND.draylamp.done=()=>{if(PQ("mine")===1)setPQ("mine",2);else setTQ("lamp",2);say0("You found Foreman Dray's brass lamp! Take it back to him at the mine entrance.")};
{const _ph=pageHooks;pageHooks=function(z){_ph(z);const N=n=>(EXP.npcs||[]).find(p=>p.n===n);
  if(z==="z-mine"){const d=N("Foreman Dray");if(d){const old=d.quest;d.quest=()=>{const p=PQ("mine");
    if(!hasTool("lamp")&&p>=3){const t=TQ("lamp");
      if(t===0){talk(d.n,["You've lost your pit lamp? Don't look at me like that. Everyone loses a lamp once.","Tell you what. My dad's brass lamp went missing again along the top tunnel, east end. Some joker keeps moving it.","Fetch it back and I'll find you another pit lamp."],()=>{setTQ("lamp",1);questSeed();say0("Find Foreman Dray's brass lamp at the east end of the top tunnel.")});return}
      if(t===1){talk(d.n,["Top tunnel, east end. Brass. Sulking."]);return}
      talk(d.n,["That's the one. Here's a pit lamp, full of oil. Try to hang on to this one."],()=>{giveTool("lamp");setTQ("lamp",3);say0("You got the MINER'S LAMP. Unlit tunnels are walkable now.")});return}
    return old?old():false}}}
  if(z==="z-glacier"){const o=N("Ole");if(o){const old=o.quest;o.quest=()=>{const p=PQ("glacier");
    if(!hasTool("pick")&&p>=3){const t=TQ("pick");
      if(t===1){talk(o.n,["Meltwater pool, west side. It went in again. Don't ask how. Fish."]);return}
      talk(o.n,["The ice pick? I borrowed it back for my fishing holes. And dropped it through the ice. Again.","It'll be in the meltwater pool on the west side, same as last time. You'll want waders."],()=>{setTQ("pick",1);questSeed();say0("Find the Institute ice pick in Frostbite Cavern's meltwater pool, on the west side.")});return}
    return old?old():false}}}
  if(z==="z-scrap"){const K=(EXP.npcs||[]).find(p=>p.keeper);if(K){const old=K.quest;K.quest=()=>{if(PQ("bolt")>=2&&!hasTool("crowbar")){talk(K.n,["You lost Maureen? Poor Maureen.","Fine. Here's her cousin. Don't tell Doreen.","(You got the CROWBAR. Nailed-shut crates can be opened now.)"],()=>{giveTool("crowbar");say0("You got the CROWBAR.")});return}return old?old():false}}}}}
/* waders: if the harbour crate was ever opened without them landing in your bag, a spare pair hangs in the office */
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z||z.special||z.cls!=="z-wreck"||hasTool("boots")||tileAt(6,10)==="c")return;
  storyObj([4,12],`<svg viewBox="0 0 40 40"><path d="M20 4 V9" stroke="#6A6254" stroke-width="1.6"/><path d="M13 9 H27" stroke="#4A3A28" stroke-width="2"/><path d="M14 10 V28 Q14 33 19 33 H21 V10 Z M22 10 V28 Q22 33 27 33 H29 V10 Z" fill="#3E5A3A" stroke="#1E2E1C" stroke-width="1"/><path d="M14 16 H21 M22 16 H29" stroke="#2E4A2A"/></svg>`,
    ()=>talk("",["A spare pair of waders hangs on a peg by the door, with a label in capitals: 'SPARE. FOR WHOEVER BROKE MY CRATE. — Y.F.'","(You got the WADING BOOTS. Shallow water is walkable now.)"],()=>{giveTool("boots");EXP.objs=EXP.objs.filter(o=>{if(o.story&&o.x===4&&o.y===12){o.el.remove();return false}return true})}),"waders")}}
/* the journal shows any tool favour that's running */
{const _oj=openJournal;openJournal=function(){_oj();const m=$("#journal");if(!m||m.hidden)return;const list=m.querySelector(".bag-list"),L=[];
  if(TQ("lamp")===1)L.push(["Favour: Foreman Dray","Find Foreman Dray's brass lamp at the east end of Rustvein Mine's top tunnel."]);if(TQ("lamp")===2)L.push(["Favour: Foreman Dray","Take the brass lamp back to Foreman Dray for a new pit lamp."]);
  if(TQ("pick")===1)L.push(["Favour: Ole","Find the Institute ice pick in Frostbite Cavern's meltwater pool, on the west side. You'll need waders."]);
  if(!L.length)return;const anchor=list.querySelector(".bag-item.side")||list.querySelector(".bag-h:not(.obj-h)");L.forEach(([t,x])=>{const d=document.createElement("div");d.className="bag-item clue side";d.innerHTML=`<b>${t}</b><p>${x}</p>`;list.insertBefore(d,anchor)});
  if(!list.querySelector(".sq-h")){const h=document.createElement("h5");h.className="bag-h sq-h";h.textContent="SIDE QUESTS";list.insertBefore(h,list.querySelector(".bag-item.side"))}}}


