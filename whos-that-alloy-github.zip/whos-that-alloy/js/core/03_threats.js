/* =============== THREAT ENCOUNTERS (boss fights) ===============
   Every threat is a boss: a CONTAINMENT meter drains while you work, wrong scans hit it hard, hints can't lock on,
   and each threat has its OWN behavior that attacks a different part of the game. Containment at 0 = breach (it escapes).
   DESIGN RULE: every threat must keep a behavior that no other threat uses. */
const STATION_KEYS=["scale","cyl","furnace","circuit","flame","geiger"];
const BOSS={
 "Cinder Mercury":{act:"BOILING POINT",tell:"It boils inside its sealed vial. VENT the pressure before the stopper blows, but every vent lets AIR in, and air makes it ignite. Flush the air with ARGON (only 2 canisters). Taking it out for a test lets air in too.",drain:.3},
 "Drowned Fire":{act:"RISING TIDE",tell:"The sea is flooding the lab. Stations under the water line stop working, so PUMP it out. It also burns underwater, spitting up bubbles of explosive gas: POP them on the stage before they reach the surface!",drain:.28},
 "Everburn":{act:"WILDFIRE",tell:"It spits embers at your stations (the target glows first). Fires GROW, then SPREAD to neighbouring stations, and one left burning too long BURNS OUT the station for a while. Extinguishers share one foam tank: small fires are cheap, big ones cost a lot.",drain:.28},
 "The Unmaker":{act:"DEVOURER",tell:"Every station you use on it gets INFECTED, and it seeps into stations on its own too (the target flashes first). Infection eats the station away and spreads to its neighbours. WIPE infected stations clean: hold the mouse down on one and scrub back and forth. Left too long, a station CRUMBLES.",drain:.28},
 "Widow's Vein":{act:"VENOM WEB",tell:"It spins webs over your scanner (the spot flashes first), and webbed elements can't be picked. Tear webs by clicking them, but the WIDOW sits on one: tear that one and she bites. Old webs harden into cocoons. Wrong guesses inject venom; the antidote recharges slowly.",drain:.3},
 "Hollow Star":{act:"HALF-LIFE",tell:"While it's out in the open it decays: every 18 seconds of exposure it boils further out of the vial and burns out a scanner charge (heat makes it decay 3× faster). SHIELD it between tests, but the shield heats up and has to vent. Let it all escape and it re-forms somewhere else!",drain:.42},
 "Crown of Rays":{act:"DAZZLE",tell:"Handling it poisons you. Your DOSE climbs while you hold it, test it or touch it with tools, and only falls while your hands are off it. A high dose blurs your eyes and brings on DAZZLE fits that scramble your scanner; a full dose makes you drop it. Containment keeps draining, so you can't just wait: work fast, then let go.",drain:.55},
 "Founder's Folly":{act:"CRITICAL MASS",tell:"It creeps toward criticality on its own, and every test, tool and scan pushes it closer. Past 50% its radiation eats containment. Drop a CONTROL ROD to pull it back, but you only have 3 and they recharge slowly. At 100%: an EXCURSION. It also REDACTS your notebook.",drain:.3},
 "Phoenix Lattice":{act:"REBIRTH CYCLE",tell:"You can only see it through the projector. While it FLICKERS, scans and tests pass straight through it and it bleeds containment. Hit SYNC on the stage when the moving ring lines up with the fixed one to snap it back. Every 45s it burns out and is reborn stronger, taking one of your locks.",drain:.3}
};
const TB={on:false};
const DRAIN_SCALE=.8;   // containment drains 20% slower than the first version
function bossActive(){return TB.on&&S.r&&S.r.a===TB.a}
function bossEl(){let b=$("#bossbar");if(b)return b;b=document.createElement("div");b.id="bossbar";b.hidden=true;
  b.innerHTML=`<div class="bb-top"><b id="bb-name"></b><span id="bb-act"></span></div><div class="bb-meter" title="Containment"><i id="bb-fill"></i><span id="bb-pct"></span></div><div class="bb-ctrl" id="bb-ctrl"></div>`;
  const ar=document.querySelector(".arena");ar.parentNode.insertBefore(b,ar);return b}
function bossStart(){const a=S.r.a,B=BOSS[a.name];if(!B)return;
  Object.assign(TB,{on:true,a,B,hp:100,t:0,grace:3.2,drainX:0,lives:1,phase:1,cyc:0,stable:true,flashIn:14,flashWarn:0,saved:false,
    press:20,oxy:0,argon:2,argonIn:22,ventCd:0,surgeIn:13,surge:0,tide:0,pumpCd:0,flooded:[],bubIn:10,bubWarn:false,fireIn:9,fires:{},foam:100,scorched:[],burntOut:{},emberAt:null,eatIn:11,eaten:[],rot:{},crumbled:{},seepIn:10,seepAt:null,crit:0,rods:3,rodIn:25,rodCd:0,burnt:{},critWarn:false,redactIn:15,redacted:[],venom:0,anti:1,antiIn:0,webs:[],webIn:8,webWarn:null,widowOn:null,widowIn:7,widowAway:0,missSeen:0,halfIn:18,shielded:false,sheat:0,vent:0,hot:false,dazzleIn:12,dose:0,sickWarn:false,rebirthIn:45,win:0,winLen:1,syncCd:0,ringT0:0,shuffled:false});
  if(a.name==="Hollow Star"){S.r.tries++;S.r.maxTries++}
  if(a.name==="Phoenix Lattice"){TB.stable=true;TB.win=PHX[0].st;TB.winLen=TB.win}   // decays one charge at a time, so it starts with a spare
  const bar=bossEl();bar.hidden=false;bar.className="b-"+a.name.replace(/\W/g,"");
  $("#bb-name").textContent=""+a.name.toUpperCase();$("#bb-act").textContent="BEHAVIOR: "+B.act;
  bossControls();bossHud();
  // intro card
  const c=document.createElement("div");c.className="bosscard";c.innerHTML=`<div class="bc-stripe"></div><div class="bc-in"><small>THREAT DETECTED </small><b>${a.name.toUpperCase()}</b><em>${B.act}</em><p>${B.tell}</p></div><div class="bc-stripe"></div>`;
  $("#stage").appendChild(c);setTimeout(()=>c.remove(),3100);
  sfx("siren");clearInterval(TB.iv);TB.last=performance.now();TB.iv=setInterval(bossTick,100);
  setTimeout(()=>{if(bossActive())say(`${a.name.toUpperCase()}: ${B.tell}`)},400)}
function bossControls(){const n=TB.a.name,c=$("#bb-ctrl");let h="";
  if(n==="Cinder Mercury")h=`<div class="bb-gauge"><span>PRESSURE</span><div><i id="bb-press"></i></div></div><button class="bb-btn vent" id="bb-vent">VENT</button><div class="bb-gauge"><span>AIR IN VIAL</span><div><i id="bb-oxy"></i></div></div><button class="bb-btn argon" id="bb-argon">ARGON ×2</button><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Drowned Fire")h=`<div class="bb-gauge"><span>FLOODING</span><div><i id="bb-tide"></i></div></div><button class="bb-btn pump" id="bb-pump">PUMP</button><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Widow's Vein")h=`<span class="bb-venom" id="bb-venom"></span><button class="bb-btn anti" id="bb-anti">ANTIDOTE ×1</button><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Everburn")h=`<div class="bb-gauge"><span>FOAM</span><div><i id="bb-foam"></i></div></div><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Hollow Star")h=`<div class="bb-gauge"><span>EXPOSURE</span><div><i id="bb-exp"></i></div></div><button class="bb-btn shield" id="bb-shield">SHIELD IT</button><div class="bb-gauge sheat"><span>SHIELD HEAT</span><div><i id="bb-sheat"></i></div></div><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Crown of Rays")h=`<div class="bb-gauge"><span>YOUR DOSE</span><div><i id="bb-dose"></i></div></div><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Founder's Folly")h=`<div class="bb-gauge"><span>CRITICALITY</span><div><i id="bb-crit"></i></div></div><button class="bb-btn rod" id="bb-rod">CONTROL ROD ×3</button><span class="bb-info" id="bb-info"></span>`;
  else if(n==="Phoenix Lattice")h=`<span class="bb-lives" id="bb-phase"></span><div class="bb-stab"><i id="bb-stab"></i><span id="bb-stabt"></span></div><span class="bb-info" id="bb-info"></span>`;
  else h=`<span class="bb-info" id="bb-info"></span>`;
  c.innerHTML=h;
  if(n==="Cinder Mercury"){$("#bb-vent").onclick=()=>{if(TB.ventCd>0)return;TB.ventCd=1.2;TB.press=Math.max(0,TB.press-45);TB.oxy=Math.min(100,TB.oxy+28);sfx("hiss");stageFx("vapor");say(TB.oxy>70?"You crack the stopper and the pressure hisses out... but air rushed in. It's close to igniting!":"Vented. Pressure drops, but some air got in.");bossHud()};
    $("#bb-argon").onclick=()=>{if(TB.argon<=0)return;TB.argon--;TB.oxy=0;sfx("chillhiss");say(TB.argon?`Argon floods the vial and pushes the air out. (${TB.argon} canister left)`:"Last argon canister used. The next one takes 22 seconds.");bossHud()}}
  if(n==="Drowned Fire")$("#bb-pump").onclick=()=>{if(TB.pumpCd>0)return;TB.pumpCd=.6;TB.tide=Math.max(0,TB.tide-15);if(gate("pumpsfx",550))sfx("clunk");dfFlood();bossHud()};
  if(n==="Founder's Folly")$("#bb-rod").onclick=()=>{if(TB.rods<=0||TB.rodCd>0)return;TB.rods--;TB.rodCd=2.5;TB.crit=Math.max(0,TB.crit-50);sfx("clunk");stageFx("flash");
    say(TB.rods?`You drop a control rod into the assembly. Criticality falls away. (${TB.rods} left; one more every 25s)`:"Your last control rod is in. The next one won't be ready for a while, so go easy on the tests!");bossHud()};
  if(n==="Hollow Star")$("#bb-shield").onclick=()=>{if(TB.vent>0)return;if(!TB.shielded&&(S.held&&S.held.kind==="sample"||LAB.inFurnace||LAB.fl.inFlame)){say("Get it off the bench first, then shield it.");return}hsShield(!TB.shielded)};

  if(n==="Widow's Vein")$("#bb-anti").onclick=()=>{if(TB.anti<=0)return;if(!TB.venom){say("No venom in your system yet. Save the antidote!");return}TB.anti=0;TB.antiIn=40;TB.venom=0;sfx("right");say("You inject the antidote. The venom burns away... that was your only dose.");bossHud()}}
function bossHud(){const hp=Math.max(0,TB.hp);$("#bb-fill").style.width=hp+"%";$("#bb-fill").className=hp<25?"low":hp<50?"mid":"";$("#bb-pct").textContent="CONTAINMENT "+Math.ceil(hp)+"%";
  const n=TB.a.name,info=$("#bb-info"),sec=v=>Math.max(0,Math.ceil(v))+"s";
  if(n==="Cinder Mercury"){const pr=$("#bb-press"),ox=$("#bb-oxy");pr.style.width=TB.press+"%";pr.className=TB.press>75?"hot":TB.press>50?"warm":"";ox.style.width=TB.oxy+"%";ox.className=TB.oxy>75?"hot":TB.oxy>50?"warm":"";
    const v=$("#bb-vent");v.disabled=TB.ventCd>0;v.classList.toggle("urgent",TB.press>80);const ag=$("#bb-argon");ag.disabled=TB.argon<=0;ag.classList.toggle("urgent",TB.oxy>80&&TB.argon>0);ag.textContent=TB.argon>0?`ARGON ×${TB.argon}`:`ARGON · ${sec(TB.argonIn)}`;
    info.textContent=TB.press>75?"The stopper is straining!":TB.oxy>75?"Too much air: it's about to ignite!":"Vent lets pressure out and air in"}
  if(n==="Drowned Fire"){const t=$("#bb-tide");t.style.width=TB.tide+"%";t.className=TB.tide>66?"hot":TB.tide>33?"warm":"";const f=(TB.flooded||[]).length,bb=document.querySelectorAll("#stage .h2bub").length;
    info.textContent=(bb?`${bb} gas bubble${bb>1?"s":""} rising! · `:"")+(f?`${f} station${f>1?"s":""} underwater · `:"")+"next eruption in "+sec(TB.bubIn)}
  if(n==="Everburn"){const fo=$("#bb-foam");fo.style.width=TB.foam+"%";fo.className=TB.foam<30?"hot":"";const f=Object.keys(TB.fires).length,sc=TB.scorched.length;
    Object.values(TB.fires).forEach(F0=>F0.lab&&F0.lab());info.textContent=(f?`${f} burning · `:"")+(sc?`${sc} burnt out · `:"")+(TB.emberAt?`ember heading for the ${STATION_NAMES[TB.emberAt]}!`:"next ember in "+sec(TB.fireIn))}
  if(n==="The Unmaker"){const inf=Object.keys(TB.rot).length,cr=Object.keys(TB.crumbled).length;info.textContent=(inf?`${inf} infected · `:"")+(cr?`${cr} crumbled · `:"")+(TB.seepAt?`seeping into the ${STATION_NAMES[TB.seepAt]}!`:"next seep in "+sec(TB.seepIn))}
  if(n==="Widow's Vein"){$("#bb-venom").innerHTML="VENOM "+(TB.venom?`<b>${"●".repeat(Math.min(TB.venom,8))}</b> ×${TB.venom}`:"<i>clean</i>");const an=$("#bb-anti");an.disabled=TB.anti<=0;an.textContent=TB.anti>0?"ANTIDOTE ×1":"ANTIDOTE USED";
    const w=TB.webs.length;an.textContent=TB.anti>0?"ANTIDOTE ×1":`ANTIDOTE · ${sec(TB.antiIn)}`;info.textContent=(w?`${w} web${w>1?"s":""}${TB.widowOn?" · the widow is on one":""} · `:"")+(TB.webWarn?"web incoming!":"new web in "+sec(TB.webIn))}
  if(n==="Hollow Star"){const e=$("#bb-exp");e.style.width=(100-TB.halfIn/18*100)+"%";e.className=TB.halfIn<5?"hot":TB.halfIn<10?"warm":"";const sh=$("#bb-sheat");sh.style.width=TB.sheat+"%";sh.className=TB.sheat>75?"hot":"";
    const b=$("#bb-shield");b.disabled=TB.vent>0;b.textContent=TB.vent>0?`VENTING ${Math.ceil(TB.vent)}s`:TB.shielded?"TAKE IT OUT":"SHIELD IT";b.classList.toggle("on",TB.shielded);
    info.textContent=(TB.shielded?"Shielded: decay paused · ":(TB.hot?"heat: decaying 3× faster! · ":"Exposed · "))+`half-life in ${sec(TB.halfIn/(TB.hot?3:1))} · charges: ${S.r.tries}`}
  if(n==="Crown of Rays"){const g=$("#bb-dose");g.style.width=TB.dose+"%";g.className=TB.dose>80?"hot":TB.dose>50?"warm":"";info.textContent=(crHolding()?"Handling it: dose rising":"Hands off: dose falling")+" · next dazzle in "+sec(TB.dazzleIn)}
  if(n==="Founder's Folly"){const c=$("#bb-crit");c.style.width=TB.crit+"%";c.className=TB.crit>75?"hot":TB.crit>50?"warm":"";
    const rb=$("#bb-rod");rb.disabled=TB.rods<=0||TB.rodCd>0;rb.textContent=TB.rods>0?`CONTROL ROD ×${TB.rods}`:`NO RODS · next in ${sec(TB.rodIn)}`;rb.classList.toggle("urgent",TB.crit>75&&TB.rods>0);
    const bt=Object.keys(TB.burnt).length;info.textContent=`${Math.floor(TB.crit)}%${TB.crit>50?" RADIATION DRAIN":""} · `+(bt?`${bt} station${bt>1?"s":""} irradiated · `:"")+(TB.redacted.length?`▇ ${TB.redacted.length} redacted · `:"")+"next redaction in "+sec(TB.redactIn);
    $("#stage").classList.toggle("ff-hot",TB.crit>75)}
  if(n==="Phoenix Lattice"){const P=PHX[TB.phase-1];$("#bb-phase").textContent=`PHASE ${"I".repeat(TB.phase)} · ${P.n}`;
    const bar=$("#bb-stab");bar.style.width=Math.max(0,TB.win/(TB.winLen||1))*100+"%";bar.className=TB.stable?"ok":"bad";
    $("#bb-stabt").textContent=TB.stable?"STABLE":"FLICKERING";info.textContent=(TB.stable?"":"SYNC it on the stage! · ")+(TB.phase<3?"rebirth in "+sec(TB.rebirthIn):"final form");
    const an=$("#btn-analyze");if(an&&S.r.stage==="elements"){an.classList.toggle("unstable",!TB.stable);if(!TB.stable){an.disabled=true;an.textContent="UNSTABLE…"}else if(an.textContent==="UNSTABLE…"){an.textContent="ANALYZE!";an.disabled=!S.r.sel.size}}}}
function stageFx(kind){const st=$("#stage"),d=document.createElement("div");d.className="hzfx "+kind;st.appendChild(d);setTimeout(()=>d.remove(),2700);
  st.classList.remove("shake");void st.offsetWidth;st.classList.add("shake")}
function hurt(n){TB.hp-=n;const f=$("#bossbar");f.classList.remove("hit");void f.offsetWidth;f.classList.add("hit")}
function bossTick(){if(!bossActive()){bossEnd();return}
  const now=performance.now(),dt=Math.min(.25,(now-TB.last)/1000);TB.last=now;
  if(document.hidden||S.r.stage!=="elements"||$("#stage").offsetParent===null)return;   // paused off-screen
  if(typeof TUT!=="undefined"&&TUT.on&&(!TUT_STEPS[TUT.i].wait||(TUT.hold&&performance.now()<TUT.hold)))return;   // paused while the tutorial is explaining something
  if(TB.grace>0){TB.grace-=dt;return}
  TB.t+=dt;const n=TB.a.name,r=S.r;let drain=TB.B.drain+TB.drainX;
  if(n==="Cinder Mercury"){const inTut=typeof TUT!=="undefined"&&TUT.on,k=inTut?.5:1;
    // decay heat boils it inside its sealed vial: pressure builds and has to be vented, but every vent lets air in, and air is what sets it alight. Argon pushes the air back out, but canisters are few
    TB.ventCd=Math.max(0,TB.ventCd-dt);TB.press=Math.min(100,TB.press+(2.6+TB.t*.03)*k*dt);TB.oxy=Math.min(100,TB.oxy+.6*k*dt);
    if(TB.argon<2&&(TB.argonIn-=dt)<=0){TB.argon++;TB.argonIn=22;sfx("sel")}
    if(TB.oxy>50)drain+=(TB.oxy-50)/50*.8;   // it smoulders where the air gets in
    if(TB.press>=100){TB.press=35;TB.oxy=Math.min(100,TB.oxy+35);hurt(20);stageFx("boom");stageFx("fire");sfx("breach");resetLab();renderAll();
      say("The stopper BLEW! Boiling metal sprayed across the bench: every station tripped off and needs setting up again, and air is pouring into the vial!")}
    else if(TB.oxy>=100){TB.oxy=20;TB.press=Math.min(100,TB.press+40);hurt(16);stageFx("fire");sfx("whoomph");
      say("FWOOM! Too much air got in and it ignited! The fire boiled it hard: pressure is spiking!")}}
  if(n==="Drowned Fire"){const inTut=typeof TUT!=="undefined"&&TUT.on;TB.pumpCd=Math.max(0,TB.pumpCd-dt);
    // the sea keeps coming in, faster as the hull gives way; stations under the water line stop working
    TB.tide=Math.min(100,TB.tide+(1+TB.t*.012)*(inTut?.4:1)*dt);dfFlood();if(TB.tide>=100)drain+=1.2;
    // it burns on underwater, belching bubbles of explosive gas up the stage
    // eruptions come on a steady, readable rhythm: a rumble warns you a second before, then a volley that grows as the fight goes on
    TB.bubIn-=dt;if(TB.bubIn<=1&&!TB.bubWarn){TB.bubWarn=true;const s=$("#stage");s.classList.remove("shake");void s.offsetWidth;s.classList.add("shake");sfx("fizz");say("It's rumbling... gas is coming up!")}
    if(TB.bubIn<=0){TB.bubWarn=false;TB.bubIn=Math.max(7,12-TB.t*.05);const n2=TB.t<40?2:TB.t<90?3:4;for(let k=0;k<n2;k++)setTimeout(()=>{if(bossActive())dfBubble()},k*450)}}
  if(n==="Everburn"){const inTut=typeof TUT!=="undefined"&&TUT.on,ks=Object.keys(TB.fires);TB.foam=Math.min(100,TB.foam+3*dt);
    for(const k of Object.keys(TB.burntOut)){if((TB.burntOut[k]-=dt)<=0){delete TB.burntOut[k];TB.scorched=TB.scorched.filter(x=>x!==k);const st=$("#st-"+k);if(st)st.classList.remove("scorched");say(`The ${STATION_NAMES[k]} has cooled off and works again.`)}}
    // each fire grows; a big one throws flames onto its neighbours, and one left too long burns the station out for good
    ks.forEach(k=>{const F0=TB.fires[k];F0.int=Math.min(1,F0.int+(inTut?.05:.1)*dt);F0.age+=dt;drain+=.1+.3*F0.int;const st=$("#st-"+k);if(st)st.style.setProperty("--fi",F0.int.toFixed(2));
      if(F0.int>=1){F0.spread-=dt;if(F0.spread<=0){F0.spread=7;const nb=evNeighbours(k).filter(n=>!TB.fires[n]&&!TB.scorched.includes(n));if(nb.length){const n=nb[Math.random()*nb.length|0];igniteStation(n,true);say(`The fire on the ${STATION_NAMES[k]} jumped to the ${STATION_NAMES[n]}!`)}}}
      if(F0.age>=(inTut?60:26)&&!(inTut&&tutStillNeeds("st-"+k))){evScorch(k)}});
    // embers come on a steady rhythm, and the station they're heading for glows a warning two seconds before they land
    TB.fireIn-=dt;if(TB.fireIn<=2&&!TB.emberAt){const free=STATION_KEYS.filter(k=>!TB.fires[k]&&!TB.scorched.includes(k));if(free.length){TB.emberAt=free[Math.random()*free.length|0];const st=$("#st-"+TB.emberAt);if(st)st.classList.add("ember-target");sfx("alert");say(`An ember is arcing toward the ${STATION_NAMES[TB.emberAt]}! Get your foam ready.`)}}
    if(TB.fireIn<=0){TB.fireIn=Math.max(8,12-TB.t*.03);const k=TB.emberAt;TB.emberAt=null;if(k){const st=$("#st-"+k);if(st)st.classList.remove("ember-target");if(!TB.fires[k]&&!TB.scorched.includes(k))igniteStation(k)}}}
  if(n==="The Unmaker"){const inTut=typeof TUT!=="undefined"&&TUT.on;
    // infection eats each station it's in; badly eaten stations pass it on to their neighbours; a fully eaten one crumbles for a while
    for(const k of Object.keys(TB.rot)){const R0=TB.rot[k];R0.v=Math.min(100,R0.v+(inTut?2:4.5)*dt);drain+=.06+.25*R0.v/100;umPaint(k);
      if(R0.v>=60){R0.sp-=dt;if(R0.sp<=0){R0.sp=7;const nb=evNeighbours(k).filter(n=>!TB.rot[n]&&!TB.crumbled[n]&&!(inTut&&tutStillNeeds("st-"+n)));if(nb.length){const n=nb[Math.random()*nb.length|0];umInfect(n,20);say(`The rot crept from the ${STATION_NAMES[k]} into the ${STATION_NAMES[n]}!`)}}}
      if(R0.v>=100&&!(inTut&&tutStillNeeds("st-"+k))){delete TB.rot[k];TB.crumbled[k]=18;const st=$("#st-"+k);if(st){st.classList.remove("infected");st.classList.add("eaten");const o=st.querySelector(".rot");if(o)o.remove()}hurt(8);sfx("scratch");stationFx&&stationFx(k,"fumes");say(`The ${STATION_NAMES[k]} crumbled into grit! A spare will take 18 seconds to set up.`)}}
    for(const k of Object.keys(TB.crumbled)){if((TB.crumbled[k]-=dt)<=0){delete TB.crumbled[k];const st=$("#st-"+k);if(st)st.classList.remove("eaten");say(`A spare ${STATION_NAMES[k]} is set up and ready.`)}}
    // it seeps out on its own on a steady rhythm; the target flashes first
    TB.seepIn-=dt;if(TB.seepIn<=2&&!TB.seepAt){const free=STATION_KEYS.filter(k=>!TB.rot[k]&&!TB.crumbled[k]&&!(inTut&&tutStillNeeds("st-"+k)));if(free.length){TB.seepAt=free[Math.random()*free.length|0];const st=$("#st-"+TB.seepAt);if(st)st.classList.add("seep-target");sfx("alert");say(`It's seeping toward the ${STATION_NAMES[TB.seepAt]}!`)}else TB.seepIn=4}
    if(TB.seepIn<=0){TB.seepIn=Math.max(9,14-TB.t*.04);const k=TB.seepAt;TB.seepAt=null;if(k){const st=$("#st-"+k);if(st)st.classList.remove("seep-target");if(!TB.crumbled[k])umInfect(k,25)}}}
  if(n==="Widow's Vein"){const inTut=typeof TUT!=="undefined"&&TUT.on;drain+=.22*TB.venom;
    // webs on a steady rhythm, telegraphed two seconds ahead
    TB.webIn-=dt*(inTut?.5:1);if(TB.webIn<=2&&!TB.webWarn)wvWarn();if(TB.webIn<=0){TB.webIn=Math.max(8,12-TB.t*.03);spinWeb()}
    // old webs harden into cocoons that take twice the tearing
    TB.webs.forEach(w=>{w.age+=dt;drain+=w.cocoon?.2:.1;if(w.cocoon&&(w.drip=(w.drip||20)-dt)<=0){w.drip=20;TB.venom++;sfx("hiss");say("Venom oozed out of a cocoon and got into you. Tear the cocoons down!")}
      if(!w.cocoon&&w.age>=16){w.cocoon=true;w.hp+=3;document.querySelectorAll(`#pick-table [data-web="${w.id}"]`).forEach(e=>e.classList.add("cocoon"));say("A web you left hardened into a COCOON. It'll take more tearing now.")}});
    // the widow creeps from web to web
    // she creeps from web to web; with only one web, she wanders off it now and then, which is your chance
    if(TB.webs.length){if(!TB.widowOn){if((TB.widowAway-=dt)<=0)wvMove()}else if((TB.widowIn-=dt)<=0){const others=TB.webs.filter(w=>w.id!==TB.widowOn);if(others.length)wvMove(others[Math.random()*others.length|0].id);else{TB.widowOn=null;TB.widowAway=3.5;wvPaint();say("The widow crawled off her web for a moment. Tear it now!")}}}else if(TB.widowOn){TB.widowOn=null;wvPaint()}
    if(TB.widowOn)wvPaint();
    if(TB.antiIn>0&&TB.anti<=0&&(TB.antiIn-=dt)<=0){TB.anti=1;sfx("sel");say("A fresh antidote is ready.")}}
  if(n==="Hollow Star"){const inTut=typeof TUT!=="undefined"&&TUT.on;TB.vent=Math.max(0,TB.vent-dt);
    // the shield heats while it's closed and cools while it's open; if it overheats it throws itself open to vent
    TB.sheat=clamp(TB.sheat+(TB.shielded?(inTut?4:8):-10)*dt,0,100);if(TB.shielded&&TB.sheat>=100){hsShield(false);TB.vent=6;sfx("breach");stageFx("vapor");say("The shield overheated and blew open to vent! It's exposed for at least 6 seconds.")}
    TB.hot=!!(LAB.inFurnace||LAB.fl.inFlame);drain+=TB.shielded?-.2:.1}
  if(n==="Hollow Star"&&!TB.shielded&&!(typeof TUT!=="undefined"&&TUT.on&&!/SCANNER|RESULT/.test(TUT_STEPS[TUT.i].t))&&(TB.halfIn-=dt*(TB.hot?3:1))<=0){TB.halfIn=18;r.tries--;sfx("miss");const sp=$("#specimen");sp.style.scale=String(Math.max(.45,+(sp.style.scale||1)-.12));
    if(r.tries<=0){bossBreach("The last of it boiled out of the vial, taking your final scanner charge with it. Somewhere else, it is already gathering itself back together.");return}
    renderActions();say("HALF-LIFE! More of it boils out of the vial, and the radiation fries a scanner charge!")}
  if(n==="Crown of Rays"){const inTut=typeof TUT!=="undefined"&&TUT.on,hold=crHolding();
    // dose climbs while your hands are on it and ebbs while they're off
    TB.dose=clamp(TB.dose+(hold?(inTut?5:9):-5)*dt,0,100);crBlur();
    if(TB.dose>=100){TB.dose=45;hurt(15);if(S.held)setHeld(null);const gh=document.querySelector(".ghost");if(gh)gh.remove();stageFx("flash");sfx("breach");say("RADIATION SICKNESS! Your hands gave out and you dropped it. Put it down between tests and let your dose fall!")}
    else if(TB.dose>=80&&!TB.sickWarn){TB.sickWarn=true;sfx("alert");say("Your dose is dangerously high. Let go of it!")}else if(TB.dose<65)TB.sickWarn=false;
    // its glare pulses: a dazzle fit scrambles the scanner (no damage), more often the higher your dose
    if((TB.dazzleIn-=dt)<=0){TB.dazzleIn=TB.dose>70?7:TB.dose>40?11:16;dazzle()}}
  if(n==="Founder's Folly"){const inTut=typeof TUT!=="undefined"&&TUT.on;
    // it creeps toward criticality by itself, faster the longer it's out; above 50% the radiation eats containment
    TB.crit=Math.min(100,TB.crit+(1.6+TB.t*.02)*(inTut?.5:1)*dt);if(TB.crit>50)drain+=(TB.crit-50)/50*1.1;
    TB.rodCd=Math.max(0,TB.rodCd-dt);if(TB.rods<3&&(TB.rodIn-=dt)<=0){TB.rods++;TB.rodIn=25;sfx("sel")}
    for(const k of Object.keys(TB.burnt)){if((TB.burnt[k]-=dt)<=0){delete TB.burnt[k];const st=$("#st-"+k);if(st)st.classList.remove("irradiated");say(`The ${STATION_NAMES[k]} has cooled down enough to use again.`)}}
    if(TB.crit>75&&!TB.critWarn){TB.critWarn=true;sfx("alert");say(TB.rods?"SUPERCRITICAL! Drop a control rod NOW!":"SUPERCRITICAL and no rods left! Stop testing and let the next rod come in!")}else if(TB.crit<65)TB.critWarn=false;
    if(TB.crit>=100){TB.crit=40;hurt(22);stageFx("flash");stageFx("boom");sfx("breach");const k=ffRedact(2);
      const free=STATION_KEYS.filter(s=>!TB.burnt[s]&&!(inTut&&tutStillNeeds("st-"+s)));let fried="";if(free.length){const s=free[Math.random()*free.length|0];TB.burnt[s]=20;const el=$("#st-"+s);if(el){el.classList.add("irradiated");stationFx&&stationFx(s,"flash")}fried=STATION_NAMES[s]}
      say(`CRITICALITY EXCURSION! A blue flash${k?` scrambled ${k} notebook entr${k>1?"ies":"y"}`:""}${fried?` and irradiated the ${fried} (out of action for 20s)`:""}!`)}
    if((TB.redactIn-=dt)<=0){TB.redactIn=TB.t>60?11:15;const k=ffRedact(1);sfx("scratch");say(k?"▇ A classified stamp comes down on your notebook. One reading is REDACTED. Re-run that test to recover it.":"▇ It tries to redact your notebook, but there's nothing to hide yet.")}}
  if(n==="Phoenix Lattice"){const inTut=typeof TUT!=="undefined"&&TUT.on,P=PHX[TB.phase-1];TB.win-=dt;TB.syncCd=Math.max(0,TB.syncCd-dt);
    // it alternates between holding STABLE and FLICKERING; while it flickers nothing touches it and the projection bleeds containment, unless you SYNC it back
    if(TB.win<=0)phxSet(!TB.stable);if(!TB.stable)drain+=1.3;
    // every 45 seconds it burns out and is reborn stronger: one lock is lost in the flash
    if((TB.rebirthIn-=dt)<=0){if(TB.phase<3)phxRebirth();else TB.rebirthIn=1e9}}
  TB.hp-=drain*dt*DRAIN_SCALE;
  if(TB.hp<=0){if(TB.lives>1){TB.lives--;TB.hp=60;TB.rebirthIn=20;r.hit.clear();stageFx("flash");sfx("radiant");renderActions();renderPicker();say("It burst apart... and RISES AGAIN from the light! Every lock was lost!")}
    else{bossBreach("CONTAINMENT BREACH! The threat broke loose and escaped!");return}}
  bossHud()}
/* Drowned Fire: the flood over the bench, and the gas bubbles on the stage */
function dfFlood(){const wrap=document.querySelector(".stations");if(!wrap)return;let fl=$("#flood");if(!fl){fl=document.createElement("div");fl.id="flood";fl.className="flood";wrap.appendChild(fl)}
  fl.style.height=TB.tide+"%";const W=wrap.getBoundingClientRect(),top=W.bottom-W.height*TB.tide/100,inTut=typeof TUT!=="undefined"&&TUT.on,now=[];
  STATION_KEYS.forEach(k=>{const el=$("#st-"+k);if(!el)return;const r=el.getBoundingClientRect(),under=r.bottom-top>r.height*.55&&!(inTut&&tutStillNeeds("st-"+k));el.classList.toggle("flooded",under);if(under)now.push(k)});
  const fresh=now.filter(k=>!TB.flooded.includes(k));if(fresh.length){sfx("fizz");say(`The water's over the ${fresh.map(k=>STATION_NAMES[k]).join(" and ")}! Pump it out to use ${fresh.length>1?"them":"it"} again.`)}TB.flooded=now}
function dfBubble(){const st=$("#stage"),b=document.createElement("button");b.className="h2bub";b.setAttribute("aria-label","Pop the gas bubble");const sz=26+Math.random()*18,dur=(5.6-Math.min(1.2,TB.t*.01)+Math.random()*.6).toFixed(2);
  b.style.cssText=`left:${38+Math.random()*24}%;width:${sz}px;height:${sz}px;--dx:${((Math.random()-.5)*160).toFixed(0)}px;animation-duration:${dur}s`;
  b.onpointerdown=e=>{e.stopPropagation();e.preventDefault();if(b.classList.contains("pop"))return;b.style.transform=getComputedStyle(b).transform;b.classList.add("pop");if(gate("bubsfx",120))sfx("sel");setTimeout(()=>b.remove(),250);bossHud()};
  b.onanimationend=e=>{if(e.animationName!=="h2rise"||b.classList.contains("pop")||!bossActive())return;b.remove();hurt(5);TB.tide=Math.min(100,TB.tide+10);stageFx("boom");if(gate("bubboom",300))sfx("whoomph");say("A gas bubble reached the surface and EXPLODED! The blast cracked the hull further.");bossHud()};
  st.appendChild(b)}
function evNeighbours(k){const me=$("#st-"+k);if(!me)return[];const a=me.getBoundingClientRect();return STATION_KEYS.filter(n=>{if(n===k)return false;const e=$("#st-"+n);if(!e)return false;const b=e.getBoundingClientRect(),dx=Math.abs((b.left+b.right)/2-(a.left+a.right)/2),dy=Math.abs((b.top+b.bottom)/2-(a.top+a.bottom)/2);
  return (dy<a.height*.5&&dx<a.width*1.4)||(dx<a.width*.5&&dy<a.height*1.4)})}
function evScorch(k){const F0=TB.fires[k];if(F0&&F0.btn)F0.btn.remove();delete TB.fires[k];TB.scorched.push(k);const st=$("#st-"+k);if(st){st.classList.remove("burning");st.classList.add("scorched");st.style.removeProperty("--fi")}TB.burntOut[k]=20;hurt(8);sfx("breach");say(`The ${STATION_NAMES[k]} burned out! It's useless until it cools off (20s).`)}
function igniteStation(k,spread){const st=$("#st-"+k);if(!st||TB.fires[k])return;const F0={int:spread?.35:.15,age:0,spread:6};TB.fires[k]=F0;st.classList.add("burning");st.style.setProperty("--fi",F0.int);sfx("whoomph");
  const b=document.createElement("button");b.className="exting";F0.btn=b;const cost=()=>Math.round(15+35*F0.int);const lab=()=>{b.textContent=`EXTINGUISH (${cost()} foam)`};lab();F0.lab=lab;
  b.onclick=e=>{e.stopPropagation();if(!gate("ext",400))return;const c=cost();if(TB.foam<c){sfx("miss");say(`Not enough foam! That fire needs ${c}, and the tank has ${Math.floor(TB.foam)}. Wait for it to refill... if the station can wait.`);return}
    TB.foam-=c;delete TB.fires[k];st.classList.remove("burning");st.style.removeProperty("--fi");b.remove();sfx("hiss");bossHud()};st.appendChild(b);
  if(!spread)say(`An ember landed on the ${STATION_NAMES[k]}! Put it out while it's small!`)}
const TUT_NEEDS={"magnet":"FIELD KIT: MAGNET","scratch":"FIELD KIT: SCRATCH TEST","st-scale":"LAB STATIONS: SET UP FIRST","st-cyl":"GRADUATED CYLINDER: RUST TEST","st-circuit":"CONDUCTIVITY TESTER","st-flame":"BUNSEN BURNER","st-geiger":"GEIGER COUNTER","st-furnace":"FURNACE"};
function tutStillNeeds(id){if(typeof TUT==="undefined"||!TUT.on)return false;const t=TUT_NEEDS[id]||TUT_NEEDS[id==="magnet"?"magnet":id.startsWith("st-")?id:"scratch"],i=TUT_STEPS.findIndex(s=>s.t===t);return i>=TUT.i}
/* The Unmaker: infection on the stations, and wiping it off */
function umInfect(k,amt,add){const st=$("#st-"+k);if(!st)return;if(TB.rot[k]){TB.rot[k].v=Math.min(100,TB.rot[k].v+amt);umPaint(k);return}
  TB.rot[k]={v:amt,sp:7};st.classList.add("infected");let o=st.querySelector(".rot");if(!o){o=document.createElement("div");o.className="rot";o.innerHTML=`<svg viewBox="0 0 100 100" preserveAspectRatio="none"><path d="M0 30 L22 36 L30 18 L48 28 L60 8 L74 30 L100 22 M0 64 L18 58 L34 72 L52 60 L66 78 L82 62 L100 70 M22 36 L18 58 M48 28 L52 60 M74 30 L82 62 M34 72 L30 100 M66 78 L70 100 M30 18 L26 0 M60 8 L64 0" stroke="#EAF0F6" stroke-width="2.4" fill="none" vector-effect="non-scaling-stroke"/></svg><span></span>`;st.appendChild(o);umWipe(st,k)}
  if(!add){sfx("scratch")}umPaint(k)}
function umPaint(k){const st=$("#st-"+k),R0=TB.rot[k];if(!st||!R0)return;st.style.setProperty("--rot",(R0.v/100).toFixed(2));const s=st.querySelector(".rot span");if(s)s.textContent=`${Math.ceil(R0.v)}% · SCRUB IT OFF`}
function umWipe(st,k){let down=false,lx=0,ly=0;const o=st.querySelector(".rot");
  o.addEventListener("pointerdown",e=>{if(!TB.rot[k])return;down=true;lx=e.clientX;ly=e.clientY;o.setPointerCapture&&o.setPointerCapture(e.pointerId);e.preventDefault();e.stopPropagation()});
  o.addEventListener("pointermove",e=>{if(!down||!TB.rot[k]||!bossActive())return;const d=Math.hypot(e.clientX-lx,e.clientY-ly);lx=e.clientX;ly=e.clientY;TB.rot[k].v-=d*.13;if(gate("scrubsfx",320))sfx("scrub");
    if(TB.rot[k].v<=0){delete TB.rot[k];st.classList.remove("infected");st.style.removeProperty("--rot");o.remove();down=false;sfx("right");say(`✨ The ${STATION_NAMES[k]} is clean.`);bossHud()}else umPaint(k)});
  const up=()=>{down=false};o.addEventListener("pointerup",up);o.addEventListener("pointercancel",up)}
/* Hollow Star: the lead shield over the sample on the stage */
function hsShield(on){TB.shielded=on;const st=$("#stage");let d=$("#hs-shield");if(!d){d=document.createElement("div");d.id="hs-shield";d.innerHTML=`<div class="hs-lid"></div><div class="hs-body"><span>SHIELDED</span></div>`;st.appendChild(d)}
  d.classList.toggle("on",on);sfx(on?"clunk":"sel");if(on)setHeld&&S.held&&S.held.kind==="sample"&&setHeld(null);bossHud()}
/* Crown of Rays: RADIATION DOSE. Handling it poisons you: holding it, testing it and touching it with tools all raise your dose, which only falls while your hands are off it.
   High dose blurs your eyes and brings on dazzle fits that scramble the scanner (annoying, never damaging); a full dose makes you drop it. Meanwhile containment drains, so you can't just wait. */
function crHolding(){return !!(S.held&&S.held.kind==="sample")||!!document.querySelector(".ghost")}
function crBlur(){const px=TB.dose>50?((TB.dose-50)/50*1.8).toFixed(2):0,pt=$("#pick-table");if(pt)pt.style.filter=px?`blur(${px}px)`:"";const st=$("#stage");if(st)st.classList.toggle("cr-hot",TB.dose>70)}
function devour(){let pool=STATION_KEYS.filter(k=>!TB.eaten.includes("st-"+k)).map(k=>"st-"+k).concat(SCRATCH.map(t=>t.id).concat(["magnet"]).filter(id=>!TB.eaten.includes(id)));
  const inTut=typeof TUT!=="undefined"&&TUT.on;pool=pool.filter(id=>!tutStillNeeds(id));   // during the tutorial it only eats things you've already been taught
  if(!pool.length){if(!inTut)hurt(10);return}const id=pool[Math.random()*pool.length|0];TB.eaten.push(id);
  const el=id.startsWith("st-")?$("#"+id):document.querySelector(`.tool[data-id="${id}"]`);if(el){el.classList.add("eaten");stationFx&&id.startsWith("st-")&&stationFx(id.slice(3),"fumes")}
  sfx("scratch");const nm=id.startsWith("st-")?"the "+STATION_NAMES[id.slice(3)]:"your "+(id==="magnet"?"magnet":SCRATCH.find(t=>t.id===id).name.toLowerCase());
  say(`It crumbled ${nm} into dust!`)}
function dazzle(){let d=$("#dazzle");if(!d){d=document.createElement("div");d.id="dazzle";document.body.appendChild(d)}d.classList.remove("on");void d.offsetWidth;d.classList.add("on");sfx("radiant");
  const els=[...document.querySelectorAll("#pick-table .el")];if(!TB.orig)TB.orig=els.map(e=>[e,e.style.gridRow,e.style.gridColumn]);
  const spots=els.map(e=>[e.style.gridRow,e.style.gridColumn]);for(let i=spots.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[spots[i],spots[j]]=[spots[j],spots[i]]}
  els.forEach((e,i)=>{e.style.gridRow=spots[i][0];e.style.gridColumn=spots[i][1]});
  say("DAZZLE! Its glare scrambled your scanner. Find the elements by their symbols!")}
let webN=0;
/* Widow's Vein: webs are spun over the scanner (the spot flashes first), the widow herself sits on one of them and moves between them, and tearing the web she's sitting on gets you bitten. Old webs harden into cocoons. */
function wvCluster(c){const cr=+c.style.gridRow,cc=+c.style.gridColumn;return [...document.querySelectorAll("#pick-table .el:not(.webbed)")].filter(e=>Math.abs(+e.style.gridRow-cr)<=1&&Math.abs(+e.style.gridColumn-cc)<=1)}
function wvWarn(){const tiles=[...document.querySelectorAll("#pick-table .el:not(.webbed)")];if(!tiles.length)return;const c=tiles[Math.random()*tiles.length|0];TB.webWarn=wvCluster(c).map(e=>e.dataset.s);
  TB.webWarn.forEach(s=>{const e=$("#p-"+s);if(e)e.classList.add("web-warn")});sfx("swirl");say(`A thread drops toward ${TB.webWarn.join(", ")}! Pick what you need from there NOW.`)}
function spinWeb(){const ss=(TB.webWarn||[]).filter(s=>{const e=$("#p-"+s);return e&&!e.classList.contains("webbed")});document.querySelectorAll(".web-warn").forEach(e=>e.classList.remove("web-warn"));TB.webWarn=null;if(!ss.length)return;
  const id="w"+(webN++);ss.forEach(s=>{const e=$("#p-"+s);e.classList.add("webbed");e.dataset.web=id;S.r.sel.delete(s)});TB.webs.push({id,hp:3,age:0,cocoon:false});sfx("hiss");renderActions();renderPicker();
  if(!TB.widowOn)wvMove(id);say(`It spun a web over ${ss.join(", ")}! Click a webbed tile to tear it (3 tugs), but NOT while the widow is on it.`)}
function wvMove(to){const ids=TB.webs.map(w=>w.id);TB.widowOn=to||(ids.length?ids[Math.random()*ids.length|0]:null);TB.widowIn=7;wvPaint()}
function wvPaint(){let sp=$("#widow");const sc=document.querySelector("#picker .scroll");if(!TB.widowOn||!sc){if(sp)sp.remove();return}
  const tiles=[...document.querySelectorAll(`#pick-table [data-web="${TB.widowOn}"]`)];if(!tiles.length){if(sp)sp.remove();TB.widowOn=null;return}
  if(!sp){sp=document.createElement("div");sp.id="widow";sp.innerHTML=`<svg viewBox="-20 -20 40 40"><g stroke="#050605" stroke-width="2.2" fill="none" stroke-linecap="round"><path d="M-3 -2 Q-10 -12 -16 -8 M-3 0 Q-12 -4 -18 0 M-3 2 Q-12 6 -17 10 M-3 4 Q-8 12 -12 16 M3 -2 Q10 -12 16 -8 M3 0 Q12 -4 18 0 M3 2 Q12 6 17 10 M3 4 Q8 12 12 16"/></g><ellipse cy="-6" rx="4" ry="3.5" fill="#050605"/><ellipse cy="4" rx="7" ry="8" fill="#050605"/><path d="M-2 1 L2 1 L0 4 L2 7 L-2 7 L0 4 Z" fill="#E8242E"/><circle cx="-1.3" cy="-7" r=".8" fill="#FF6A6A"/><circle cx="1.3" cy="-7" r=".8" fill="#FF6A6A"/></svg>`;sc.appendChild(sp)}
  const t=tiles[Math.floor(tiles.length/2)],S0=sc.getBoundingClientRect(),r=t.getBoundingClientRect();sp.style.left=(r.left-S0.left+sc.scrollLeft+r.width/2)+"px";sp.style.top=(r.top-S0.top+sc.scrollTop+r.height/2)+"px"}
{const _tp=togglePick;togglePick=function(s){if(bossActive()&&TB.a.name==="Widow's Vein"){const el=$("#p-"+s);if(el&&el.classList.contains("webbed")){const w=TB.webs.find(x=>x.id===el.dataset.web);if(!w)return;
    if(!gate("tear",140))return;
    if(TB.widowOn===w.id){TB.venom++;hurt(5);stageFx("fumes");sfx("hiss");const sp=$("#widow");if(sp){sp.classList.remove("bite");void sp.offsetWidth;sp.classList.add("bite")}say("The widow was sitting on that web and BIT you! Wait for her to move, or tear a different one.");bossHud();return}
    w.hp--;const grp=document.querySelectorAll(`#pick-table [data-web="${w.id}"]`);
    if(w.hp<=0){grp.forEach(e=>{e.classList.remove("webbed","w1","w2","cocoon");delete e.dataset.web});TB.webs=TB.webs.filter(x=>x!==w);sfx("scratch");say("Torn! The web falls apart.")}
    else{grp.forEach(e=>{e.classList.toggle("w1",w.hp===2||w.hp===4);e.classList.toggle("w2",w.hp===1||w.hp===3)});sfx("sel")}bossHud();return}}
  _tp(s)}}
/* Phoenix Lattice: three escalating phases. Each phase: stable/flicker cycle length, flash timer, ember warning, locks burned per missed ember. */
const PHX=[{n:"EMBER",st:7,fl:3.5,ring:1.4},{n:"BLAZE",st:5.5,fl:4,ring:1.2},{n:"INFERNO",st:4.5,fl:4.5,ring:1.0}];
/* switch between STABLE and FLICKERING; the SYNC ring on the stage lets you cut a flicker short with a well-timed click */
function phxSet(stable){const P=PHX[TB.phase-1],inTut=typeof TUT!=="undefined"&&TUT.on;TB.stable=stable;TB.win=stable?P.st*(inTut?1.6:1):P.fl;TB.winLen=TB.win;$("#specimen").classList.toggle("phx-flicker",!stable);
  let s=$("#phx-sync");if(!stable){sfx("swirl");if(!s){s=document.createElement("button");s.id="phx-sync";s.setAttribute("aria-label","Sync the projection");s.innerHTML=`<i class="ps-target"></i><i class="ps-ring"></i><b>SYNC</b>`;$("#stage").appendChild(s);
      s.onpointerdown=e=>{e.stopPropagation();e.preventDefault();phxSync()}}
    s.style.setProperty("--p",P.ring+"s");TB.ringT0=performance.now();const r=s.querySelector(".ps-ring");r.style.animation="none";void r.offsetWidth;r.style.animation="";s.hidden=false}
  else if(s)s.hidden=true;bossHud()}
function phxSync(){if(!bossActive()||TB.stable||TB.syncCd>0)return;const P=PHX[TB.phase-1],t=((performance.now()-TB.ringT0)/1000/P.ring)%1;
  if(Math.abs(t-.667)<.1){sfx("super");phxSet(true);say("SYNCED! The projection snaps back to STABLE.")}
  else{TB.syncCd=.5;TB.win+=1;TB.winLen+=1;sfx("miss");const s=$("#phx-sync");if(s){s.classList.remove("bad");void s.offsetWidth;s.classList.add("bad")}say("Off the beat! Click when the moving ring lines up with the fixed one.")}bossHud()}
function phxRebirth(){const r=S.r;TB.phase++;TB.rebirthIn=45;hurt(8);const hs=[...r.hit];if(hs.length){r.hit.delete(hs[Math.random()*hs.length|0])}r.tries++;r.maxTries++;
  $("#specimen").classList.toggle("phx-drift",TB.phase===3);$("#stage").classList.add("phx-p"+TB.phase);phxSet(true);
  stageFx("flash");stageFx("fire");sfx("breach");setTimeout(()=>sfx("radiant"),500);renderActions();renderPicker();
  say(TB.phase===2?`It burned out... and RISES AGAIN as a BLAZE!${hs.length?" The flash burned away one of your locks.":""} (+1 scanner charge)`:`It RISES A FINAL TIME as an INFERNO! Shorter stable windows, faster rhythm.${hs.length?" One lock burned away.":""} (+1 scanner charge)`)}
/* Founder's Folly: redact notebook entries (they come back if you re-run the test) */
const FF_NOTE={mass:"scale",vol:"cylinder",rust:"soak test",cond:"conductivity",flame:"flame test",rad:"Geiger",melt:"furnace",react:"furnace",freeze:"furnace",magnet:"magnet"};
function ffRedact(n){const r=S.r,keys=Object.keys(r.notes).filter(k=>FF_NOTE[k]&&!(TB.pending||[]).includes(k));let done=0;TB.pending=TB.pending||[];
  for(let i=0;i<n&&keys.length;i++){const k=keys.splice(Math.random()*keys.length|0,1)[0];done++;TB.pending.push(k);
    const li=document.querySelector(`#dexcard li[data-k="${k}"]`);if(li){li.classList.add("redacting");li.scrollIntoView&&0}
    setTimeout(()=>{TB.pending=TB.pending.filter(x=>x!==k);if(!bossActive()||S.r!==r)return;delete r.notes[k];TB.redacted.push(k);renderDex();
      const nl=document.querySelector("#dexcard li.redacted:last-of-type");if(nl){nl.classList.add("fresh")}},li?1300:0)}
  return done}
function bossBreach(msg){const r=S.r;stageFx("boom");sfx("breach");bossEnd();lose(false);say(msg)}
function bossEnd(){if(!TB.on)return;TB.on=false;clearInterval(TB.iv);if(TB.stopHiss){TB.stopHiss();TB.stopHiss=null}
  const bar=$("#bossbar");if(bar)bar.hidden=true;document.querySelectorAll(".phx-ember,#phx-sync").forEach(e=>e.remove());const spx=$("#specimen");if(spx)spx.classList.remove("phx-flicker","phx-drift");$("#stage").classList.remove("phx-p2","phx-p3");
  document.querySelectorAll(".station.burning,.station.eaten,.tool.eaten,.station.irradiated,.station.scorched").forEach(e=>{e.classList.remove("burning","eaten","irradiated","scorched");e.style.removeProperty("--fi")});TB.scorched=[];TB.burntOut={};{const pt=$("#pick-table");if(pt)pt.style.filter=""}$("#stage").classList.remove("cr-hot");const hsd=$("#hs-shield");if(hsd)hsd.remove();TB.shielded=false;document.querySelectorAll(".station .rot").forEach(e=>e.remove());document.querySelectorAll(".station.infected,.seep-target").forEach(e=>{e.classList.remove("infected","seep-target");e.style.removeProperty("--rot")});TB.rot={};TB.crumbled={};document.querySelectorAll(".ember-target").forEach(e=>e.classList.remove("ember-target"));TB.burnt={};$("#stage").classList.remove("ff-hot");const fl=$("#flood");if(fl)fl.remove();document.querySelectorAll(".station.flooded").forEach(e=>e.classList.remove("flooded"));document.querySelectorAll(".h2bub").forEach(e=>e.remove());TB.flooded=[];document.querySelectorAll(".exting").forEach(e=>e.remove());
  if(TB.orig){TB.orig.forEach(([e,r,c])=>{e.style.gridRow=r;e.style.gridColumn=c});TB.orig=null}
  document.querySelectorAll("#pick-table .webbed,#pick-table .web-warn").forEach(e=>{e.classList.remove("webbed","w1","w2","cocoon","web-warn");delete e.dataset.web});TB.webs=[];TB.widowOn=null;TB.webWarn=null;const wd=$("#widow");if(wd)wd.remove();const sp=$("#specimen");if(sp)sp.style.scale=""}
Object.assign(SFX,{
  siren:t=>{for(let k=0;k<3;k++){tone(nf("A5"),t+k*.5,.24,{vol:.16});tone(nf("E5"),t+k*.5+.25,.24,{vol:.16})}},
  breach:t=>{nz(t,1.4,{vol:.55,type:"lowpass",f:120,to:1400});tone(220,t,.9,{type:"sawtooth",vol:.18,to:55})}});
/* hooks into the round flow */
{const _sr=startRound;startRound=function(){bossEnd();_sr();if(S.r&&S.r.a.threat&&BOSS[S.r.a.name]){bossStart();
}}}
{const _an0=analyze;analyze=function(){if(bossActive()&&TB.a.name==="Phoenix Lattice"&&!TB.stable){sfx("miss");say("The projection is flickering! The scanner can't lock on. Wait for it to stabilize.");return}_an0()}}
{const _an=analyze;analyze=function(){const b=bossActive(),before=S.r.tries;_an();if(b&&bossActive()&&S.r.stage==="elements"&&S.r.tries<before){hurt(12);stageFx("fire");
  if(TB.a.name==="The Unmaker"&&!TB.seepAt){TB.seepIn=Math.min(TB.seepIn,2.05)}bossHud()}
  if(b&&bossActive()&&TB.a.name==="Widow's Vein"){const nm=S.r.miss.size-(TB.missSeen||0);if(nm>0){TB.venom+=nm;TB.missSeen=S.r.miss.size;say(`Wrong! The widow injects ${nm} dose${nm>1?"s":""} of venom.`);bossHud()}}}}
{const _an2=analyze;analyze=function(){const b=bossActive()&&TB.a.name==="Founder's Folly"&&S.r.stage==="elements";_an2();if(b&&bossActive()){TB.crit=Math.min(100,TB.crit+8);bossHud()}}}   // even a scan adds neutrons
{const _h=hint;hint=function(){if(bossActive()){say("The interference is too strong. Hints can't lock on to a threat!");return}_h()}}
{const _ra=renderActions;renderActions=function(){_ra();if(S.r&&S.r.a.threat&&S.r.stage==="elements"){const h=$("#btn-hint");if(h){h.disabled=true;h.textContent="HINT: JAMMED"}const f=$("#btn-flee");if(f)f.textContent="RETREAT"}}}
{const _w=win;win=function(){const b=bossActive(),r=S.r;bossEnd();_w();if(!b)return;const R=S.run,extra=r.pts*2;r.pts+=extra;R.score+=extra;
  if(R.score>S.best){S.best=R.score;store.set("wta_best2",S.best)}const d=S.dex[r.a.name];if(d){d.cont=(d.cont||0)+1;saveDex()}
  stageFx("flash");renderAll();say(`CONTAINED! ${r.a.name.toUpperCase()} is sealed in the Alloydex. Threat bonus: points tripled!`)}}
{const _l=lose;lose=function(ran){const b=bossActive();bossEnd();_l(ran);if(b&&ran)say("You pulled back and sealed the lab doors. The threat is still out there.")}}
{const _se=startExplore;startExplore=function(){bossEnd();_se()}}
{const _dd=doDrop;doDrop=function(p,key){if(bossActive()){
    if(TB.a.name==="Phoenix Lattice"&&!TB.stable&&(STATION_NAMES[key]||key==="sample")){hurt(4);bossHud();say("The projection flickered and your test passed straight through it! Wait until it's STABLE.");setHeld(null);return}
    if(p.kind==="sample"&&TB.shielded){say("It's sealed in the shield. Take it out first.");setHeld(null);return}
    if(p.kind==="sample"&&STATION_NAMES[key]&&TB.scorched&&TB.scorched.includes(key)){say(`The ${STATION_NAMES[key]} is burnt out. Give it a moment to cool off.`);setHeld(null);return}
    if(p.kind==="sample"&&STATION_NAMES[key]){if(TB.fires[key]){say(`The ${STATION_NAMES[key]} is on fire! Put it out first.`);setHeld(null);return}
      if(TB.flooded&&TB.flooded.includes(key)){say(`The ${STATION_NAMES[key]} is underwater! Pump the flood down first.`);setHeld(null);return}
      if(TB.a.name==="Drowned Fire"&&gate("dfout",1500))setTimeout(()=>{if(bossActive())dfBubble()},300);
      if(TB.crumbled&&TB.crumbled[key]){say(`The ${STATION_NAMES[key]} crumbled. The spare isn't set up yet.`);setHeld(null);return}
      if(TB.a.name==="The Unmaker"){const inTut=typeof TUT!=="undefined"&&TUT.on;if(!(inTut&&tutStillNeeds("st-"+key))){const was=TB.rot[key];umInfect(key,was?Math.min(100,was.v+15)-was.v:15,true);if(gate("uminf",2500))setTimeout(()=>say(`Touching it infected the ${STATION_NAMES[key]}. Wipe it clean before it spreads!`),900)}}
      if(TB.eaten.includes("st-"+key)){say(`The ${STATION_NAMES[key]} is gone. It crumbled to dust.`);setHeld(null);return}
      if(TB.burnt&&TB.burnt[key]){say(`The ${STATION_NAMES[key]} is still irradiated from the excursion. Give it a few seconds.`);setHeld(null);return}
      if(TB.a.name==="Cinder Mercury"&&gate("cmheat",800)){TB.oxy=Math.min(100,TB.oxy+16);const add={furnace:28,flame:24}[key]||0;TB.press=Math.min(100,TB.press+add);bossHud();say(add?`Out of the vial it meets the air, and the ${STATION_NAMES[key]}'s heat boils it harder!`:"Taking it out of the vial let air at it.")}
      if(TB.a.name==="Founder's Folly"&&gate("ffcrit",800)){TB.crit=Math.min(100,TB.crit+22);bossHud()}
      if(TB.a.name==="Crown of Rays"&&gate("crtest",900)){TB.dose=Math.min(100,TB.dose+6);bossHud()}}
    if(p.kind!=="sample"&&TB.eaten.includes(p.id)){say("That tool is gone.");setHeld(null);return}
    if(p.kind!=="sample"&&key==="sample"&&TB.a.name==="Crown of Rays"&&gate("crtool",700)){TB.dose=Math.min(100,TB.dose+4);bossHud()}
    if(p.kind!=="sample"&&key==="sample"&&TB.a.name==="Founder's Folly"&&gate("ffcrit",800)){TB.crit=Math.min(100,TB.crit+14);bossHud()}}
  _dd(p,key)}}

/* ---- Threat looks: every threat gets its own stage palette, drifting particles, hazard placard and animated sample effects ---- */
const TLOOK={
 "Cinder Mercury":{k:"cinder",a:"#0C1E38",b:"#050E1E",core:"255,170,90",tag:"fire",tagc:"#E8412C",part:"flake",part2:"ember"},
 "Drowned Fire":{k:"drowned",a:"#06222C",b:"#020D12",core:"255,140,60",tag:"fire",tagc:"#E8412C",part:"bubble"},
 "Everburn":{k:"everburn",a:"#2A0804",b:"#120302",core:"255,120,40",tag:"fire",tagc:"#E8412C",part:"ember",part2:"ash"},
 "The Unmaker":{k:"unmaker",a:"#3A3F48",b:"#1C2026",core:"205,218,235",tag:"flask",tagc:"#FFFFFF",part:"shard",part2:"drip"},
 "Widow's Vein":{k:"widow",a:"#101408",b:"#060804",core:"170,220,110",tag:"skull",tagc:"#FFFFFF",part:"spore"},
 "Hollow Star":{k:"hollow",a:"#12081F",b:"#05020C",core:"150,110,230",tag:"rad",tagc:"#F2D12C",part:"mote"},
 "Crown of Rays":{k:"crown",a:"#1A0A1C",b:"#0C040E",core:"140,255,158",tag:"rad",tagc:"#F2D12C",part:"gold"},
 "Founder's Folly":{k:"quill",a:"#1A2340",b:"#0A0F22",core:"170,215,255",tag:"rad",tagc:"#F2D12C",part:"doc",part2:"ffdust"},
 "Phoenix Lattice":{k:"phoenix",a:"#150A24",b:"#050812",core:"120,200,255",tag:"warn",tagc:"#FF4AC8",part:"scan"}};
/* hazard placard icons, drawn rather than typed */
function placardSVG(k,c){const P={fire:`<path d="M12 3 C14 8 19 10 18 16 C17.5 20 14.5 22 12 22 C9.5 22 6.5 20 6 16 C5.6 12.5 8 11 9 8 C10 11 11 12 12 12 C12.5 9 11 6 12 3 Z" fill="${c}"/><path d="M12 14 C13.5 16 14.5 17 14 19 C13.6 20.6 12.8 21 12 21 C11.2 21 10.3 20.5 10 19 C9.8 17.5 11 16.5 12 14 Z" fill="#FFE27A"/>`,
  rad:`<circle cx="12" cy="12" r="2.2" fill="${c}"/>${[0,120,240].map(r=>`<path d="M12 12 L${(12+9*Math.cos((r-90-30)*Math.PI/180)).toFixed(2)} ${(12+9*Math.sin((r-90-30)*Math.PI/180)).toFixed(2)} A9 9 0 0 1 ${(12+9*Math.cos((r-90+30)*Math.PI/180)).toFixed(2)} ${(12+9*Math.sin((r-90+30)*Math.PI/180)).toFixed(2)} Z" fill="${c}"/>`).join("")}<circle cx="12" cy="12" r="3.6" fill="none" stroke="#111" stroke-width="1.2"/>`,
  skull:`<path d="M12 3 C7 3 4.5 6.5 4.5 10.5 C4.5 13.5 6 15 7.5 15.8 V19 H16.5 V15.8 C18 15 19.5 13.5 19.5 10.5 C19.5 6.5 17 3 12 3 Z" fill="${c}"/><circle cx="9" cy="10.5" r="2" fill="#111"/><circle cx="15" cy="10.5" r="2" fill="#111"/><path d="M11 14 L12 12.5 L13 14 Z M10 17 V19 M12 17 V19 M14 17 V19" stroke="#111" fill="#111" stroke-width=".9"/>`,
  flask:`<path d="M9.5 3 H14.5 M10.5 3 V9 L5 19.5 C4.6 20.4 5.2 21 6 21 H18 C18.8 21 19.4 20.4 19 19.5 L13.5 9 V3" fill="none" stroke="${c}" stroke-width="1.8" stroke-linejoin="round"/><path d="M7.5 15.5 H16.5 L18.4 19.8 H5.6 Z" fill="${c}"/>`,
  warn:`<path d="M12 3 L22 20 H2 Z" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round"/><path d="M12 9 V14.5" stroke="${c}" stroke-width="2.4" stroke-linecap="round"/><circle cx="12" cy="17.4" r="1.4" fill="${c}"/>`};
  return `<svg viewBox="0 0 24 24" width="100%" height="100%" aria-hidden="true">${P[k]||P.warn}</svg>`}
function threatSkin(stage,a){const L=a&&a.threat&&TLOOK[a.name];
  stage.className=stage.className.replace(/\btz-\w+/g,"").trim();
  let pl=stage.querySelector(".tparts"),tg=stage.querySelector(".tplac");
  if(!L){if(pl)pl.remove();if(tg)tg.remove();stage.style.removeProperty("--tcore");return}
  stage.classList.add("tz-"+L.k);stage.style.setProperty("--tcore",L.core);
  if(!pl){pl=document.createElement("div");pl.className="tparts";stage.prepend(pl)}
  const R=mulberry(a.no*97+5);let h="";
  for(let i=0;i<22;i++){const kind=L.part2&&i%3===0?L.part2:L.part;h+=`<i class="p-${kind}" style="--x:${(R()*100).toFixed(1)}%;--y:${(R()*100).toFixed(1)}%;--d:${(2.5+R()*4).toFixed(2)}s;--dl:${(-R()*6).toFixed(2)}s;--s:${(.6+R()*.9).toFixed(2)}"></i>`}
  pl.innerHTML=h;
  if(!tg){tg=document.createElement("div");tg.className="tplac";stage.appendChild(tg)}
  tg.innerHTML=placardSVG(L.tag,L.tagc);tg.style.setProperty("--pc",L.a)}
function threatFx(host,a,mini){const svg=host&&host.querySelector("svg");if(!svg||!a||!a.threat||svg.querySelector(".tfx"))return;const L=TLOOK[a.name];if(!L)return;
  const UID=a.no+"x"+(threatFx.n=(threatFx.n||0)+1),R=mulberry(a.no*13+1),rn=(x,y)=>(x+R()*(y-x)).toFixed(1);let f="",back="",box="";   // back: the scene · box: parts of the vessel that sit behind the glass (shown on cards too) · f: in front
  const bubble=(n,y0,y1,x0,x1,col,op)=>{let s="";for(let i=0;i<n;i++){const x=rn(x0,x1),d=rn(1.2,2.6),b=rn(0,2.5);s+=`<circle cx="${x}" cy="${y0}" r="${rn(1.5,3.5)}" fill="${col}" opacity="0"><animate attributeName="cy" values="${y0};${y1}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;${op};0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}return s};
  const flame=(x,y,w,hgt,col,dur)=>`<g transform="translate(${x} ${y})"><path d="M${-w} 0 Q${-w*.6} ${-hgt*.55} 0 ${-hgt} Q${w*.6} ${-hgt*.55} ${w} 0 Z" fill="${col}"><animateTransform attributeName="transform" type="scale" values="1 1;.85 1.25;1.1 .8;1 1" dur="${dur}s" repeatCount="indefinite"/></path></g>`;
  if(a.name==="Cinder Mercury"){   // a trapped sun in a glacier: ice crystals erupting around it, lit from within by its fire, light spearing out through the gaps, heat haze warping the flames
    const N=UID,c=a.color,hi=shade(c,.6),F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    back+=`<defs>
      <radialGradient id="cmg${N}" gradientUnits="userSpaceOnUse" cx="150" cy="150" r="190"><stop offset="0" stop-color="#FFD27A" stop-opacity=".9"/><stop offset=".25" stop-color="#FF8A2A" stop-opacity=".45"/><stop offset=".6" stop-color="#FF5A10" stop-opacity=".12"/><stop offset="1" stop-color="#FF5A10" stop-opacity="0"/></radialGradient>
      <linearGradient id="cmi${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#0B2A4E"/><stop offset=".55" stop-color="#2E7FC0"/><stop offset="1" stop-color="#BFF0FF"/></linearGradient>
      <linearGradient id="cmo${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF7A1A" stop-opacity=".75"/><stop offset=".6" stop-color="#FFB24A" stop-opacity=".35"/><stop offset="1" stop-color="#FFE7A0" stop-opacity="0"/></linearGradient>
      <linearGradient id="cmsh${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFC060" stop-opacity=".55"/><stop offset="1" stop-color="#FF7A1A" stop-opacity="0"/></linearGradient>
      <filter id="cmb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4"/></filter></defs>`;
    // the fire's light filling the cavern
    back+=`<circle cx="150" cy="150" r="190" fill="url(#cmg${N})"><animate attributeName="opacity" values=".75;1;.8;.95;.75" dur="1.4s" repeatCount="indefinite"/></circle>`;
    // shafts of firelight spearing out between the crystals
    let sh="";[[-160,18],[-128,14],[-52,16],[-20,12],[196,14],[340,10],[160,10]].forEach(([deg,wd],k)=>{const a1=(deg-wd/2)*Math.PI/180,a2=(deg+wd/2)*Math.PI/180;
      sh+=`<polygon points="150,150 ${F(150+420*Math.cos(a1))},${F(150+420*Math.sin(a1))} ${F(150+420*Math.cos(a2))},${F(150+420*Math.sin(a2))}" fill="#FFB050" opacity=".22"><animate attributeName="opacity" values=".1;.32;.14;.28;.1" dur="${(1.3+k*.37).toFixed(2)}s" repeatCount="indefinite"/></polygon>`});
    back+=`<g filter="url(#cmb${N})">${sh}</g>`;
    // ice crystals erupting behind it, lit orange on the faces that look at the fire
    const spire=(bx,bw,h,tilt,front)=>{const tx=bx+tilt,ty=232-h,lx=bx-bw/2,rx=bx+bw/2,toward=bx<150?1:-1,mid=bx+tilt*.4+toward*bw*.15;
      return `<g opacity="${front?.88:1}"><polygon points="${F(lx)},232 ${F(tx)},${F(ty)} ${F(rx)},232" fill="url(#cmi${N})" stroke="#CFF4FF" stroke-width="${front?1.1:.8}" stroke-linejoin="round"/>
        <polygon points="${F(toward>0?rx:lx)},232 ${F(tx)},${F(ty)} ${F(mid)},232" fill="url(#cmo${N})"><animate attributeName="opacity" values=".7;1;.75;.95;.7" dur="1.4s" repeatCount="indefinite"/></polygon>
        <path d="M${F(tx)} ${F(ty)} L${F(mid)} 232" stroke="#FFFFFF" stroke-width=".8" opacity=".6"/></g>`};
    box+=spire(58,40,150,-18)+spire(92,46,205,6)+spire(126,30,120,-4)+spire(176,34,140,6)+spire(212,48,215,-8)+spire(248,38,150,16)+spire(30,30,90,-10)+spire(272,30,100,12);
    // meltwater pooled at the foot, glowing with reflected fire
    back+=`<ellipse cx="150" cy="233" rx="120" ry="8" fill="#FF9A3A" opacity=".35" filter="url(#cmb${N})"><animate attributeName="opacity" values=".25;.45;.25" dur="1.4s" repeatCount="indefinite"/></ellipse><ellipse cx="150" cy="233" rx="100" ry="4" fill="#BFEFFF" opacity=".5"/>`;
    // inside the glass: a white-hot heart, a slow convection spiral, rising bubbles and a surface that won't sit still
    f+=`<defs><clipPath id="cmv${N}"><path d="M117 46 L183 46 L183 196 Q183 223 150 223 Q117 223 117 196 Z"/></clipPath>
      <radialGradient id="cmh${N}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".3" stop-color="#FFE9A0"/><stop offset=".7" stop-color="#FF9A2A" stop-opacity=".6"/><stop offset="1" stop-color="#FF5A10" stop-opacity="0"/></radialGradient>
      <linearGradient id="cmfl${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF5A00"/><stop offset=".4" stop-color="#FF9A2A" stop-opacity=".9"/><stop offset="1" stop-color="#FFE27A" stop-opacity="0"/></linearGradient>
      <linearGradient id="cmfi${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FFFBEA"/><stop offset="1" stop-color="#FFE27A" stop-opacity="0"/></linearGradient>
      <filter id="cmhz${N}" x="-30%" y="-30%" width="160%" height="160%"><feTurbulence type="fractalNoise" baseFrequency=".03 .09" numOctaves="2" seed="4" result="n"><animate attributeName="baseFrequency" values=".03 .09;.035 .12;.03 .09" dur="2s" repeatCount="indefinite"/></feTurbulence><feDisplacementMap in="SourceGraphic" in2="n" scale="7"/></filter></defs>
      <g clip-path="url(#cmv${N})">
      <circle cx="150" cy="200" r="34" fill="url(#cmh${N})" style="mix-blend-mode:screen"><animate attributeName="r" values="28;38;30;36;28" dur="1.4s" repeatCount="indefinite"/></circle>
      <path d="M150 205 C120 200 122 170 150 168 C178 166 180 140 150 138" stroke="#FFF1C0" stroke-width="2" fill="none" opacity=".45" stroke-dasharray="8 10"><animate attributeName="stroke-dashoffset" from="0" to="-36" dur="1.6s" repeatCount="indefinite"/></path>`;
    for(let k=0;k<14;k++){const x=+rn(122,178),d=rn(1,2),b=rn(0,2);f+=`<circle cx="${x}" cy="215" r="${rn(1.2,3)}" fill="none" stroke="#FFF4C8" stroke-width=".9" opacity="0"><animate attributeName="cy" values="215;124" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.9;.9;0" keyTimes="0;.1;.85;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    const surf=k=>`M117 ${120+k} Q133 ${114-k} 150 ${120+k} T183 ${120+k} L183 128 L117 128 Z`;
    f+=`<path d="${surf(0)}" fill="${hi}"><animate attributeName="d" values="${surf(0)};${surf(3)};${surf(-2)};${surf(0)}" dur="1.1s" repeatCount="indefinite"/></path>`;
    const tongue=(cx,base,w,h,dur,gr)=>{const shp=(dx,hh)=>`M${cx-w} ${base} C${cx-w} ${base-hh*.35} ${cx-w*.55+dx*.3} ${base-hh*.6} ${cx+dx} ${base-hh} C${cx+w*.55+dx*.3} ${base-hh*.6} ${cx+w} ${base-hh*.35} ${cx+w} ${base} Z`;
      return `<path d="${shp(0,h)}" fill="url(#${gr})"><animate attributeName="d" values="${[shp(0,h),shp(-w*.45,h*.85),shp(w*.35,h*1.1),shp(-w*.1,h*.95),shp(0,h)].join(";")}" dur="${dur}s" repeatCount="indefinite" calcMode="spline" keySplines=".4 0 .6 1;.4 0 .6 1;.4 0 .6 1;.4 0 .6 1"/></path>`};
    f+=`<g filter="url(#cmhz${N})">`+tongue(126,123,10,52,1.1,"cmfl"+N)+tongue(141,121,13,70,.95,"cmfl"+N)+tongue(159,121,14,76,1.05,"cmfl"+N)+tongue(175,123,10,56,.85,"cmfl"+N)+tongue(149,121,7,44,.8,"cmfi"+N)+tongue(165,121,6,36,.9,"cmfi"+N)+`</g>`;
    f+=`<rect x="117" y="46" width="66" height="30" fill="#FFB050" opacity=".25"><animate attributeName="opacity" values=".15;.35;.15" dur="1s" repeatCount="indefinite"/></rect></g>`;   // flames pressing against the seal
    // the glass: rimed with frost at the edges, sweating where fire meets ice
    f+=`<defs><filter id="cmfr${N}" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="1.1" numOctaves="2" seed="11"/><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1.5 -.6"/></filter>
      <linearGradient id="cmfm${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff"/><stop offset=".18" stop-color="#fff" stop-opacity="0"/><stop offset=".82" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#fff"/></linearGradient>
      <mask id="cmmk${N}"><rect x="112" y="40" width="76" height="190" fill="url(#cmfm${N})"/></mask></defs>
      <g mask="url(#cmmk${N})"><rect x="112" y="40" width="76" height="190" filter="url(#cmfr${N})" opacity=".8"/></g>`;
    // icicles hanging off the seal, dripping
    [[122,14],[132,20],[168,18],[178,12]].forEach(([x,l],k)=>{f+=`<path d="M${x-3} 46 L${x} ${46+l} L${x+3} 46 Z" fill="#DFF6FF" stroke="#FFFFFF" stroke-width=".5" opacity=".9"/><circle cx="${x}" cy="${46+l}" r="1.4" fill="#DFF6FF"><animate attributeName="cy" values="${46+l};${60+l};${46+l}" keyTimes="0;.3;1" dur="${(2.2+k*.4).toFixed(1)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;0;0;1" keyTimes="0;.3;.95;1" dur="${(2.2+k*.4).toFixed(1)}s" repeatCount="indefinite"/></circle>`});
    // steam hissing off the top where the heat escapes
    for(let k=0;k<5;k++){const x=+rn(120,180),d=rn(2,3.2),b=rn(0,3);f+=`<circle cx="${x}" cy="20" r="6" fill="#FFFFFF" filter="url(#cmb${N})" opacity="0"><animate attributeName="cy" values="22;-24" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="r" values="4;12" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.5;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // a foreground ring of ice around the foot
    f+=spire(96,30,70,10,1)+spire(112,22,44,-4,1)+spire(190,24,54,6,1)+spire(206,32,80,-12,1)+spire(78,20,40,-6,1)+spire(224,22,46,8,1);}
  if(a.name==="Drowned Fire"){    // deep, dark water, and in it a fire the sea can't touch: the water boils away into a shimmering pocket of steam, and flames roar around the glass inside it
    const N=UID,F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    back+=`<defs>
      <radialGradient id="dfg${N}" gradientUnits="userSpaceOnUse" cx="150" cy="150" r="230"><stop offset="0" stop-color="#FFE6A8" stop-opacity=".9"/><stop offset=".18" stop-color="#FF9A3A" stop-opacity=".55"/><stop offset=".5" stop-color="#FF6A1A" stop-opacity=".14"/><stop offset="1" stop-color="#FF6A1A" stop-opacity="0"/></radialGradient>
      <radialGradient id="dfp${N}" cx=".5" cy=".5" r=".5"><stop offset=".72" stop-color="#FFFFFF" stop-opacity="0"/><stop offset=".93" stop-color="#FFE9C8" stop-opacity=".22"/><stop offset="1" stop-color="#FFFFFF" stop-opacity=".55"/></radialGradient>
      <linearGradient id="dff${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF4A00" stop-opacity=".95"/><stop offset=".45" stop-color="#FF9A2A" stop-opacity=".85"/><stop offset="1" stop-color="#FFE27A" stop-opacity="0"/></linearGradient>
      <linearGradient id="dfi${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FFFBEA"/><stop offset="1" stop-color="#FFE27A" stop-opacity="0"/></linearGradient>
      <filter id="dfb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>
      <filter id="dfs${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>
      <filter id="dfw${N}" x="-20%" y="-20%" width="140%" height="140%"><feTurbulence type="fractalNoise" baseFrequency=".02 .05" numOctaves="2" seed="8" result="n"><animate attributeName="baseFrequency" values=".02 .05;.026 .07;.02 .05" dur="3s" repeatCount="indefinite"/></feTurbulence><feDisplacementMap in="SourceGraphic" in2="n" scale="10"/></filter></defs>`;
    // the fire's light pushing out into black water, wavering as it goes
    let rays="";for(let k=0;k<14;k++){const an=k/14*Math.PI*2+.1,w=.07+(k%3)*.02;rays+=`<polygon points="150,150 ${F(150+380*Math.cos(an-w))},${F(150+380*Math.sin(an-w))} ${F(150+380*Math.cos(an+w))},${F(150+380*Math.sin(an+w))}" fill="#FF9A3A" opacity="${k%2?.14:.22}"><animate attributeName="opacity" values="${k%2?".08;.2;.08":".14;.3;.14"}" dur="${(1.4+k%4*.35).toFixed(2)}s" repeatCount="indefinite"/></polygon>`}
    back+=`<g filter="url(#dfw${N})"><g filter="url(#dfb${N})">${rays}</g></g><circle cx="150" cy="150" r="230" fill="url(#dfg${N})"><animate attributeName="opacity" values=".7;1;.75;.95;.7" dur="1.1s" repeatCount="indefinite"/></circle>`;
    // the scene: the seabed beside a sunken ship. Light filtering down from far above, a kelp forest swaying, the wreck lying on its side with fire glowing in its portholes, an anchor half-buried in the sand, jellyfish and a shoal of fish, vents trickling bubbles
    {const U=UID;let sc=`<defs><linearGradient id="dsw${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1A6A7A"/><stop offset=".3" stop-color="#0A3A4A"/><stop offset=".62" stop-color="#05202A"/><stop offset="1" stop-color="#020A10"/></linearGradient>
      <linearGradient id="dsr${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#BFF4FF" stop-opacity=".35"/><stop offset="1" stop-color="#BFF4FF" stop-opacity="0"/></linearGradient>
      <linearGradient id="dss${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3A4E46"/><stop offset=".25" stop-color="#1E2C28"/><stop offset="1" stop-color="#070C0B"/></linearGradient>
      <linearGradient id="dsh${U}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3A2A1C"/><stop offset=".12" stop-color="#16100C"/><stop offset="1" stop-color="#050807"/></linearGradient>
      <linearGradient id="dsk${U}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#1E3A1A"/><stop offset="1" stop-color="#4A6A2A"/></linearGradient>
      <radialGradient id="dsj${U}" cx=".5" cy=".4" r=".6"><stop offset="0" stop-color="#FFD8F4" stop-opacity=".8"/><stop offset="1" stop-color="#C87AE0" stop-opacity=".15"/></radialGradient>
      <filter id="dsb${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#dsw${U})"/>`;
    // the surface far above, rippling, and shafts of light coming down through it
    let rip="";for(let k=0;k<7;k++){const y=-104+k*5;rip+=`<path d="M-220 ${y} q20 -3 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0"/>`}
    sc+=`<g stroke="#DFFAFF" stroke-width="1.2" fill="none" opacity=".3">${rip}<animateTransform attributeName="transform" type="translate" values="0 0;-40 0" dur="3s" repeatCount="indefinite"/></g>`;
    [[-150,40],[-40,30],[70,46],[260,36],[380,44]].forEach(([x,w],k)=>{sc+=`<polygon points="${x},-110 ${x+w},-110 ${x+w+60},260 ${x+20},260" fill="url(#dsr${U})" filter="url(#dsb${U})"><animate attributeName="opacity" values=".4;1;.5;.9;.4" dur="${(5+k*1.3).toFixed(1)}s" repeatCount="indefinite"/></polygon>`});
    // the wreck on its side, off to the right: hull, broken mast, rigging, portholes lit by a fire still burning inside
    sc+=`<g transform="rotate(-8 360 150)"><path d="M214 232 Q206 170 236 120 L262 86 Q360 60 470 70 L520 76 L520 236 Z" fill="url(#dsh${U})" stroke="#0A0605" stroke-width="2"/>
      <path d="M214 232 Q206 170 236 120 L262 86" stroke="#FF9A3A" stroke-width="2.4" fill="none" opacity=".6"><animate attributeName="opacity" values=".35;.75;.4;.7;.35" dur="1.1s" repeatCount="indefinite"/></path>
      ${[0,1,2,3,4,5,6].map(k=>`<path d="M${260+k*34} 90 L${254+k*36} 232" stroke="#0A0605" stroke-width="1.4" opacity=".7"/>`).join("")}
      <path d="M262 86 Q360 60 470 70" stroke="#2A1E14" stroke-width="5" fill="none"/>${[0,1,2,3,4,5,6,7,8].map(k=>`<path d="M${270+k*26} ${82-k*1.6} v-10" stroke="#2A1E14" stroke-width="2"/>`).join("")}<path d="M270 72 Q370 50 480 60" stroke="#2A1E14" stroke-width="2" fill="none"/>
      ${[[268,140],[304,132],[340,128],[376,126],[412,126],[448,128],[284,186],[330,180],[376,176]].map(([x,y],k)=>`<circle cx="${x}" cy="${y}" r="7" fill="#1A120C" stroke="#6A5236" stroke-width="2"/><circle cx="${x}" cy="${y}" r="5" fill="#FF8A2A"><animate attributeName="opacity" values="${k%3?".2;.9;.35;.8;.2":".6;.15;.7;.3;.6"}" dur="${(.9+k%4*.3).toFixed(1)}s" repeatCount="indefinite"/></circle>`).join("")}
      <path d="M430 96 L360 -120" stroke="#1A120C" stroke-width="9" stroke-linecap="round"/><path d="M380 -60 L330 -52" stroke="#1A120C" stroke-width="5"/><path d="M360 -120 L262 86 M360 -120 L520 60 M380 -60 L300 84" stroke="#2A2218" stroke-width="1" opacity=".8"/>
      <path d="M338 -54 Q350 -20 342 10 L322 20 Q330 -10 320 -48 Z" fill="#3A3226" opacity=".6"><animate attributeName="d" values="M338 -54 Q350 -20 342 10 L322 20 Q330 -10 320 -48 Z;M338 -54 Q356 -18 350 12 L330 22 Q336 -8 320 -48 Z;M338 -54 Q350 -20 342 10 L322 20 Q330 -10 320 -48 Z" dur="5s" repeatCount="indefinite"/></path></g>`;
    // the seabed: silt, stones, shells, and an anchor half-buried with its chain snaking off
    sc+=`<path d="M-220 222 Q-80 210 40 224 T300 226 T520 220 V690 H-220 Z" fill="url(#dss${U})"/>`;
    for(let k=0;k<16;k++){const x=+rn(-210,510);if(Math.abs(x-150)<56)continue;sc+=`<ellipse cx="${x}" cy="${F(+rn(226,250))}" rx="${rn(4,14)}" ry="${rn(2.5,6)}" fill="${["#2A3632","#3A4640","#1E2825"][k%3]}"/>`}
    sc+=`<g transform="translate(40 238) rotate(-24)"><path d="M0 -40 V10 M-10 -34 H10" stroke="#1A1614" stroke-width="5" stroke-linecap="round"/><circle cy="-46" r="5" fill="none" stroke="#1A1614" stroke-width="3"/><path d="M-22 -2 Q0 22 22 -2" stroke="#1A1614" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M-24 -6 l4 8 M24 -6 l-4 8" stroke="#1A1614" stroke-width="4"/></g>
      <path d="M36 190 Q60 230 20 240 T-60 238 T-160 246" stroke="#1A1614" stroke-width="3" fill="none" stroke-dasharray="5 2"/>`;
    // a kelp forest on the left, swaying in the current
    for(let k=0;k<11;k++){const x=-210+k*24+(R()-.5)*10,top=+rn(-60,90),sw=(R()-.5)*20,d=v=>`M${F(x)} 232 C${F(x+sw+v)} ${F(232-(232-top)*.33)} ${F(x-sw+v*1.6)} ${F(232-(232-top)*.66)} ${F(x+v*2.2)} ${F(top)}`;
      sc+=`<path d="${d(0)}" stroke="url(#dsk${U})" stroke-width="${rn(4,7)}" fill="none" stroke-linecap="round"><animate attributeName="d" values="${d(0)};${d(8)};${d(-5)};${d(0)}" dur="${(4.5+R()*2).toFixed(1)}s" repeatCount="indefinite"/></path>`;
      for(let m=1;m<4;m++){const y=232-(232-top)*m/4.2;sc+=`<ellipse cx="${F(x+(m%2?6:-6))}" cy="${F(y)}" rx="7" ry="2.6" fill="#3A5A22" transform="rotate(${m%2?-30:30} ${F(x)} ${F(y)})" opacity=".85"/>`}}
    // jellyfish drifting up the water column
    [[-120,40,1],[300,-70,.7],[20,-40,.55]].forEach(([x,y,s],k)=>{const d=(9+k*3).toFixed(0);sc+=`<g><g transform="scale(${s})"><path d="M-14 0 Q-14 -16 0 -16 Q14 -16 14 0 Q7 3 0 0 Q-7 3 -14 0 Z" fill="url(#dsj${U})"/>${[-10,-5,0,5,10].map(u=>`<path d="M${u} 1 q3 10 -1 20 q-3 8 1 16" stroke="#F0C8FF" stroke-width=".9" fill="none" opacity=".7"><animate attributeName="d" values="M${u} 1 q3 10 -1 20 q-3 8 1 16;M${u} 1 q-3 10 1 20 q3 8 -1 16;M${u} 1 q3 10 -1 20 q-3 8 1 16" dur="2s" repeatCount="indefinite"/></path>`).join("")}</g>
      <animateMotion dur="${d}s" repeatCount="indefinite" path="M${x} ${y+60} q14 -30 0 -60 q-14 -30 0 -60 q14 -30 0 -60"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.15;.8;1" dur="${d}s" repeatCount="indefinite"/></g>`});
    // a shoal of little fish circling well clear of the fire
    for(let k=0;k<9;k++){const d=(14+k%3).toFixed(0),b=(k*1.1).toFixed(1),ry=24+k%3*6;sc+=`<path d="M0 0 q5 -3 9 0 q-4 3 -9 0 z M0 0 l-3 -2.5 v5 z" fill="#8AB8C0" opacity=".75"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" rotate="auto" path="M-40 ${60+ry} a110 ${ry} 0 1 0 0 1 z"/></path>`}
    // vents in the seabed trickling bubbles
    [[-90,234],[250,234],[330,240]].forEach(([x,y])=>{for(let k=0;k<4;k++){const d=rn(3,5),b=rn(0,5);sc+=`<circle cx="${x}" cy="${y}" r="${rn(1.5,3)}" fill="none" stroke="#CFF4FF" stroke-width=".8" opacity="0"><animate attributeName="cy" values="${y};-110" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="cx" values="${x};${x+8};${x-4}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.8;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}});
    back=sc+back;}
    // marine snow drifting through the light
    for(let k=0;k<26;k++){const x=+rn(-100,400),y=+rn(-40,240),d=rn(6,12),b=rn(0,12);back+=`<circle cx="${x}" cy="${y}" r="${rn(.6,1.6)}" fill="#FFE2B8" opacity="0"><animate attributeName="cy" values="${y};${F(y+40)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.8;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // the steam pocket: a wobbling bubble of boiled-off water wrapped around the whole vial
    const bub=(k)=>{let d="";for(let t=0;t<=24;t++){const an=t/24*Math.PI*2,r=96+Math.sin(an*3+k)*4+Math.cos(an*5-k)*3;d+=(t?"L":"M")+F(150+Math.cos(an)*r*.8)+" "+F(138+Math.sin(an)*r)}return d+"Z"};
    back+=`<path d="${bub(0)}" fill="url(#dfp${N})" stroke="#FFF1DA" stroke-width="1.6" opacity=".95"><animate attributeName="d" values="${bub(0)};${bub(2)};${bub(4)};${bub(0)}" dur="2.4s" repeatCount="indefinite"/></path>
      <path d="M92 70 Q110 44 142 40" stroke="#FFFFFF" stroke-width="3" fill="none" stroke-linecap="round" opacity=".5"/>`;
    // fire roaring up around the glass inside the pocket
    const tongue=(cx,base,w,h,dur,gr)=>{const shp=(dx,hh)=>`M${cx-w} ${base} C${cx-w} ${base-hh*.35} ${cx-w*.55+dx*.3} ${base-hh*.6} ${cx+dx} ${base-hh} C${cx+w*.55+dx*.3} ${base-hh*.6} ${cx+w} ${base-hh*.35} ${cx+w} ${base} Z`;
      return `<path d="${shp(0,h)}" fill="url(#${gr})" filter="url(#dfs${N})"><animate attributeName="d" values="${[shp(0,h),shp(-w*.45,h*.85),shp(w*.35,h*1.1),shp(-w*.1,h*.95),shp(0,h)].join(";")}" dur="${dur}s" repeatCount="indefinite" calcMode="spline" keySplines=".4 0 .6 1;.4 0 .6 1;.4 0 .6 1;.4 0 .6 1"/></path>`};
    back+=tongue(104,226,16,120,1.2,"dff"+N)+tongue(124,228,14,160,1,"dff"+N)+tongue(178,228,14,150,1.1,"dff"+N)+tongue(198,226,16,110,.9,"dff"+N)+tongue(114,228,8,90,.85,"dfi"+N)+tongue(188,228,8,84,.95,"dfi"+N)+tongue(150,232,40,40,1.3,"dff"+N);
    // inside the glass: grains alight in their oil, white-hot where they burn hardest
    f+=`<defs><clipPath id="dfv${N}"><path d="M117 46 L183 46 L183 196 Q183 223 150 223 Q117 223 117 196 Z"/></clipPath></defs><g clip-path="url(#dfv${N})">
      <rect x="117" y="58" width="66" height="166" fill="#7A5A14" opacity=".25"/><path d="M117 60 Q150 54 183 60" stroke="#E0B040" stroke-width="2" fill="none" opacity=".7"/>`;
    for(let k=0;k<12;k++){const x=+rn(122,178),y=+rn(148,218),d=rn(.3,.8);f+=`<circle cx="${x}" cy="${y}" r="${rn(1.4,3)}" fill="#FFFFFF"><animate attributeName="opacity" values=".2;1;.3;1;.2" dur="${d}s" repeatCount="indefinite"/></circle><circle cx="${x}" cy="${y}" r="${rn(5,8)}" fill="#FFD27A" opacity=".3" style="mix-blend-mode:screen"><animate attributeName="opacity" values=".08;.4;.12;.35;.08" dur="${d}s" repeatCount="indefinite"/></circle>`}
    f+=`</g>`;
    // the sea boiling off the top of the pocket in torrents of bubbles
    for(let k=0;k<30;k++){const x=+rn(96,204),d=rn(1.6,3.2),b=rn(0,3.2),r=rn(1.5,5),y0=+(46+Math.abs(x-150)*.55);f+=`<circle cx="${x}" cy="${y0}" r="${r}" fill="rgba(255,240,220,.12)" stroke="#FFF1DA" stroke-width=".9" opacity="0"><animate attributeName="cy" values="${y0};-90" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="cx" values="${x};${F(x+(R()-.5)*34)};${F(x+(R()-.5)*20)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.95;.8;0" keyTimes="0;.08;.8;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // fish fleeing, lit by the blaze
    if(!mini)for(let k=0;k<4;k++){const y=[30,190,-10,110][k],d=(4+k*1.4).toFixed(1),dir=k%2?-1:1;f+=`<g><path d="M0 0 q8 -5 14 0 q-6 5 -14 0 z M0 0 l-5 -4 v8 z" fill="#06202A" stroke="#FF9A3A" stroke-width=".7" transform="scale(${dir} 1)"/><animateMotion dur="${d}s" begin="-${(k*1.9).toFixed(1)}s" repeatCount="indefinite" path="M${150+dir*70} ${y} q${dir*120} ${k%2?-30:30} ${dir*380} ${k%2?-40:20}"/></g>`}}
  if(a.name==="Everburn"){        // its grains are alight: metal chunks with white-hot undersides, glowing seams, soft living flames over the pile
    const vc=svg.querySelector(".vc");if(vc)vc.innerHTML="";
    const N=UID,c=a.color,H=shade(c,.55),D=shade(c,-.55),F=v=>(+v).toFixed(1);
    let g=`<defs>
      <radialGradient id="ebc${N}" cx=".35" cy=".3" r=".8"><stop offset="0" stop-color="${H}"/><stop offset=".45" stop-color="${c}"/><stop offset="1" stop-color="${D}"/></radialGradient>
      <linearGradient id="ebh${N}" x1="0" y1="0" x2="0" y2="1"><stop offset=".45" stop-color="#FF6A00" stop-opacity="0"/><stop offset=".85" stop-color="#FF7A10" stop-opacity=".85"/><stop offset="1" stop-color="#FFD860" stop-opacity="1"/></linearGradient>
      <linearGradient id="ebb${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFB040"/><stop offset=".35" stop-color="#C43A08"/><stop offset=".75" stop-color="#5A1204"/><stop offset="1" stop-color="#2A0802"/></linearGradient>
      <linearGradient id="ebf${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF4A00" stop-opacity=".95"/><stop offset=".45" stop-color="#FF8A1A" stop-opacity=".85"/><stop offset="1" stop-color="#FFD04A" stop-opacity="0"/></linearGradient>
      <linearGradient id="ebi${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FFF6D0"/><stop offset=".6" stop-color="#FFE27A" stop-opacity=".8"/><stop offset="1" stop-color="#FFE27A" stop-opacity="0"/></linearGradient>
      <filter id="ebl${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6"/></filter>
      <filter id="ebg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter></defs>`;
    // the bed of embers under and between the grains
    g+=`<rect x="115" y="150" width="70" height="76" fill="url(#ebb${N})"><animate attributeName="opacity" values=".85;1;.9;1;.85" dur="1.3s" repeatCount="indefinite"/></rect>`;
    g+="<!--FL-->";
    // grains: rounded metal chunks, back rows first, each lit from below
    // a settled pile: grains packed tight from the curved glass floor up to a slightly mounded, uneven top, each one jittered and sized differently so no rows show
    const heap=[],halfW=y=>y<=196?32:32*Math.sqrt(Math.max(0,1-Math.pow((y-196)/27,2))),surf=x=>150+Math.pow((x-150)/33,2)*7;
    for(let y=222,row=0;y>146;y-=3.6,row++){const hw=halfW(y);if(hw<4)continue;
      for(let x=150-hw+(row%2?2.6:0)+R()*1.4;x<=150+hw;x+=4.6+R()*1.4){const yy=y+(R()-.5)*3,xx=x+(R()-.5)*2.4;
        if(yy<surf(xx)+(R()-.5)*3)continue;if(Math.abs(xx-150)>halfW(yy)+1)continue;heap.push([xx,yy,3.4+R()*2.2,2.8+R()*1.8])}}
    let k=0;
    heap.forEach(([x,yy,w,h])=>{{const rot=(R()*70-35).toFixed(0);
      const pts=[];for(let m=0;m<7;m++){const an=m/7*6.283,rr=1+(R()-.5)*.35;pts.push([Math.cos(an)*w*rr,Math.sin(an)*h*rr])}
      let d=`M${pts[0][0].toFixed(1)} ${pts[0][1].toFixed(1)}`;for(let m=1;m<=7;m++){const P=pts[m%7],Q=pts[m-1],mx=(P[0]+Q[0])/2,my=(P[1]+Q[1])/2;d+=` Q${Q[0].toFixed(1)} ${Q[1].toFixed(1)} ${mx.toFixed(1)} ${my.toFixed(1)}`}d+="Z";
      const dur=(.8+R()*1.4).toFixed(2);
      g+=`<g transform="translate(${x.toFixed(1)} ${yy.toFixed(1)}) rotate(${rot})"><path d="${d}" fill="url(#ebc${N})" stroke="${D}" stroke-width=".5"/><path d="${d}" fill="url(#ebh${N})"><animate attributeName="opacity" values=".55;1;.7;.95;.55" dur="${dur}s" repeatCount="indefinite"/></path>`+
        (R()<.35?`<path d="M${(-w*.5).toFixed(1)} 0 l${(w*.4).toFixed(1)} ${(h*.3).toFixed(1)} l${(w*.5).toFixed(1)} ${(-h*.2).toFixed(1)}" stroke="#FFD04A" stroke-width=".9" fill="none"><animate attributeName="opacity" values=".3;1;.3" dur="${dur}s" repeatCount="indefinite"/></path>`:"")+`</g>`;k++}});
    // heat glow across the top of the pile
    g+=`<ellipse cx="150" cy="152" rx="36" ry="9" fill="#FF8A1A" filter="url(#ebg${N})" opacity=".8"><animate attributeName="opacity" values=".55;.9;.6;.85;.55" dur="1.1s" repeatCount="indefinite"/></ellipse>`;
    // soft living flames: smooth tongues whose shape morphs
    const tongue=(cx,base,w,h,dur,grad,blur)=>{const sh=(dx,hh)=>`M${cx-w} ${base} C${cx-w} ${base-hh*.35} ${cx-w*.55+dx*.3} ${base-hh*.6} ${cx+dx} ${base-hh} C${cx+w*.55+dx*.3} ${base-hh*.6} ${cx+w} ${base-hh*.35} ${cx+w} ${base} Z`;
      const vals=[sh(0,h),sh(-w*.45,h*.86),sh(w*.35,h*1.08),sh(-w*.15,h*.94),sh(0,h)].join(";");
      return `<path d="${sh(0,h)}" fill="url(#${grad})"${blur?` filter="url(#ebl${N})"`:""}><animate attributeName="d" values="${vals}" dur="${dur}s" repeatCount="indefinite" calcMode="spline" keySplines=".4 0 .6 1;.4 0 .6 1;.4 0 .6 1;.4 0 .6 1"/></path>`};
    g=g.replace("<!--FL-->",tongue(128,164,8,40,1.3,"ebf"+N,1)+tongue(143,162,11,58,1.1,"ebf"+N,1)+tongue(160,161,12,66,1.25,"ebf"+N,1)+tongue(174,164,8,44,.95,"ebf"+N,1)+tongue(144,162,5,34,.9,"ebi"+N,0)+tongue(160,161,6,40,1.05,"ebi"+N,0));
    // sparks spit up off the burning pile and fall straight back onto it: nothing hangs in the air, everything settles
    for(let i=0;i<10;i++){const x=+rn(126,174),d=rn(.7,1.3),b=rn(0,1.3),h=F(rn(8,26)),dx=F((R()-.5)*16);g+=`<circle r="${rn(.8,1.4)}" fill="#FFE9A0" opacity="0"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${x} 152 q${F(dx/2)} -${h} ${dx} 2"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.85;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    if(vc)vc.insertAdjacentHTML("beforeend",g);
    back+=`<ellipse cx="150" cy="205" rx="62" ry="34" fill="#FF6A10" opacity=".3"><animate attributeName="opacity" values=".2;.42;.25;.38;.2" dur="1.3s" repeatCount="indefinite"/></ellipse>`;
    // the scene: a caldera at night, a volcano erupting on the horizon, lava falls, cracked obsidian glowing underfoot, a ring of fire it can't escape and a whirlwind of cinders around it
    {svg.style.overflow="visible";const F=v=>(+v).toFixed(1),U=UID;
    let sc=`<defs><linearGradient id="evsky${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1A0604"/><stop offset=".6" stop-color="#5A1406"/><stop offset="1" stop-color="#A8300A"/></linearGradient>
      <linearGradient id="evlv${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE27A"/><stop offset=".4" stop-color="#FF7A1A"/><stop offset="1" stop-color="#C02A00"/></linearGradient>
      <radialGradient id="evvg${U}" gradientUnits="userSpaceOnUse" cx="300" cy="60" r="120"><stop offset="0" stop-color="#FFB24A" stop-opacity=".8"/><stop offset="1" stop-color="#FF5A10" stop-opacity="0"/></radialGradient>
      <filter id="evbl${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
      <filter id="evhz${U}" x="-10%" y="-10%" width="120%" height="120%"><feTurbulence type="fractalNoise" baseFrequency=".015 .06" numOctaves="2" seed="2" result="n"><animate attributeName="baseFrequency" values=".015 .06;.02 .08;.015 .06" dur="2.5s" repeatCount="indefinite"/></feTurbulence><feDisplacementMap in="SourceGraphic" in2="n" scale="6"/></filter></defs>`;
    sc+=`<g filter="url(#evhz${U})"><rect x="-200" y="-100" width="700" height="260" fill="url(#evsky${U})"/>`;
    // ash clouds drifting
    for(let k=0;k<4;k++){const y=+rn(-70,10),d=rn(18,30),b=rn(0,30);sc+=`<ellipse cx="0" cy="${y}" rx="${rn(60,110)}" ry="${rn(12,22)}" fill="#2A0C06" opacity=".7"><animate attributeName="cx" values="-220;520" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></ellipse>`}
    // the volcano erupting on the horizon, lava fountaining from its crater
    sc+=`<circle cx="300" cy="60" r="120" fill="url(#evvg${U})"><animate attributeName="opacity" values=".6;1;.7;.95;.6" dur="2.2s" repeatCount="indefinite"/></circle>
      <path d="M180 170 L270 62 L286 58 L300 60 L316 56 L330 62 L440 170 Z" fill="#1A0806"/><path d="M270 62 L286 58 L300 60 L316 56 L330 62" stroke="#FF7A1A" stroke-width="2.4" fill="none"/>
      <path d="M296 62 Q292 100 280 170" stroke="url(#evlv${U})" stroke-width="5" fill="none"/><path d="M306 60 Q314 110 330 170" stroke="url(#evlv${U})" stroke-width="3.5" fill="none"/>`;
    for(let k=0;k<12;k++){const d=rn(1.4,2.6),b=rn(0,2.6),dx=F((R()-.5)*90),h=F(40+R()*60);sc+=`<circle cx="300" cy="58" r="${rn(1.2,2.6)}" fill="#FFC060"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M300 58 q${F(dx/2)} -${h} ${dx} ${F(-h/3)}"/><animate attributeName="opacity" values="1;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // crags on the left with a lava fall pouring down them
    sc+=`<path d="M-200 170 L-140 70 L-110 90 L-70 40 L-30 96 L20 60 L70 170 Z" fill="#140604"/>
      <path d="M-70 44 Q-66 90 -58 170" stroke="url(#evlv${U})" stroke-width="6" fill="none" stroke-dasharray="10 6"><animate attributeName="stroke-dashoffset" from="0" to="-32" dur=".8s" repeatCount="indefinite"/></path></g>`;
    // cracked obsidian ground, veins of lava pulsing out from under the vial
    sc+=`<path d="M-220 160 Q0 150 150 158 T520 160 L520 690 L-220 690 Z" fill="#0E0605"/>`;
    let veins="";for(let k=0;k<10;k++){const an=Math.PI*(.05+k*.1),len=+rn(80,200);let d=`M150 226`,px=150,py=226;for(let t=0;t<5;t++){px+=Math.cos(an)*len/5*(k%2?1:-1)*.9+(R()-.5)*10;py+=Math.sin(an)*len/5*.18+(R()-.5)*4;d+=` L${F(px)} ${F(py)}`}veins+=`<path d="${d}"/>`}
    sc+=`<g stroke="#FF7A1A" stroke-width="2" fill="none" stroke-linecap="round" filter="url(#evbl${U})">${veins}<animate attributeName="opacity" values=".5;1;.6;.9;.5" dur="1.6s" repeatCount="indefinite"/></g><g stroke="#FFE27A" stroke-width=".9" fill="none">${veins}</g>`;
    // the back half of a ring of fire around it
    const tg=(cx,base,w,h,dur,op)=>{const shp=(dx,hh)=>`M${F(cx-w)} ${base} C${F(cx-w)} ${F(base-hh*.35)} ${F(cx-w*.55+dx*.3)} ${F(base-hh*.6)} ${F(cx+dx)} ${F(base-hh)} C${F(cx+w*.55+dx*.3)} ${F(base-hh*.6)} ${F(cx+w)} ${F(base-hh*.35)} ${F(cx+w)} ${base} Z`;
      return `<path d="${shp(0,h)}" fill="url(#evlv${U})" opacity="${op}"><animate attributeName="d" values="${[shp(0,h),shp(-w*.45,h*.85),shp(w*.35,h*1.1),shp(0,h)].join(";")}" dur="${dur}s" repeatCount="indefinite"/></path>`};
    let ringB="",ringF="";for(let k=0;k<18;k++){const an=k/18*Math.PI*2,x=150+Math.cos(an)*96,y=228+Math.sin(an)*14,w=+rn(7,11),h=+rn(26,44);const t=tg(x,F(y),w,h,rn(.7,1.3),Math.sin(an)<0?.75:.95);if(Math.sin(an)<0)ringB+=t;else if(Math.abs(x-150)>52)ringF+=t}   // no flames in front of the glass, so the pile stays visible to the very bottom
    sc+=`<g filter="url(#evbl${U})" opacity=".6">${ringB}</g>${ringB}`;
    back=sc+back;
    // the front half of the ring, and a whirlwind of cinders spiralling up around the glass
    f+=`<g filter="url(#evbl${U})" opacity=".6">${ringF}</g>${ringF}`;
    let whirl="";for(let k=0;k<22;k++){const d=rn(2.2,3.8),b=rn(0,3.8),r0=+rn(72,120),ph=R()*Math.PI*2;let path="";for(let t=0;t<=30;t++){const aa=ph+t/30*Math.PI*4,rr=r0,y=226-t/30*230;path+=(t?" L":"M")+F(150+Math.cos(aa)*rr)+" "+F(y+Math.sin(aa)*rr*.18)}
      whirl+=`<circle r="${rn(1,2.2)}" fill="${k%3?"#FFB24A":"#FFE9A0"}"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="${path}"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.8;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    back+=whirl;}   // the cinders ride the hot air outside the glass, well clear of the sample

    for(let i=0;i<3;i++){const x=rn(135,165),d=rn(2.4,3.4),b=rn(0,3);f+=`<path d="M${x} 14 q-9 -10 0 -20 q9 -10 0 -22" stroke="#4A3F38" stroke-width="7" fill="none" stroke-linecap="round" opacity="0"><animateTransform attributeName="transform" type="translate" values="0 6;0 -10" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.45;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></path>`}}
  if(a.name==="The Unmaker"){     // a clump of grains coming apart along liquid-metal seams, eating through its own vial
    const vc=svg.querySelector(".vc");if(vc)vc.innerHTML="";
    const N=UID,c=a.color,hi=shade(c,.55),lo=shade(c,-.45),F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    {let fr="";const cx=150,cy=150;
      for(let k=0;k<14;k++){const an=k/14*Math.PI*2+R()*.3;let r=40,px=cx+Math.cos(an)*r,py=cy+Math.sin(an)*r,d=`M${F(px)} ${F(py)}`;
        for(let t=0;t<6;t++){r+=28+R()*22;const a2=an+(R()-.5)*.28;px=cx+Math.cos(a2)*r;py=cy+Math.sin(a2)*r;d+=` L${F(px)} ${F(py)}`}fr+=`<path d="${d}"/>`}
      for(const rr of [70,120,180,250]){let d="";const n=18;for(let k=0;k<n;k++){if(R()<.35)continue;const a1=k/n*Math.PI*2,a2=(k+1)/n*Math.PI*2,r1=rr+(R()-.5)*14,r2=rr+(R()-.5)*14;d+=`M${F(cx+Math.cos(a1)*r1)} ${F(cy+Math.sin(a1)*r1)} L${F(cx+Math.cos(a2)*r2)} ${F(cy+Math.sin(a2)*r2)} `}fr+=`<path d="${d}"/>`}
      back+=`<g stroke="#DDE6F0" stroke-width="1" fill="none" opacity=".22">${fr}<animate attributeName="opacity" values=".12;.3;.12" dur="4s" repeatCount="indefinite"/></g>
        <ellipse cx="150" cy="176" rx="46" ry="60" fill="#CFE0F4" opacity=".16"><animate attributeName="opacity" values=".08;.2;.08" dur="3.2s" repeatCount="indefinite"/></ellipse>`}
    // a jittered grid of shared corners: every grain is a quad, every seam is shared, so the seams read as one connected web
    const C=6,Rw=7,x0=116,x1=184,y0=128,y1=224,V=[];
    for(let j=0;j<=Rw;j++){V[j]=[];for(let i=0;i<=C;i++){const ex=i===0||i===C,ey=j===Rw;V[j][i]=[x0+(x1-x0)*i/C+(ex?0:(R()-.5)*7),y0+(y1-y0)*j/Rw+(j===0||ey?(R()-.5)*3:(R()-.5)*6)]}}
    let g=`<defs><linearGradient id="umg${N}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${hi}"/><stop offset=".55" stop-color="${c}"/><stop offset="1" stop-color="${lo}"/></linearGradient>
      <radialGradient id="umb${N}" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".25" stop-color="#E6ECF2"/><stop offset=".7" stop-color="#8E98A6"/><stop offset="1" stop-color="#4A525E"/></radialGradient>
      <linearGradient id="ump${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F4F8FC"/><stop offset=".5" stop-color="#AAB4C0"/><stop offset="1" stop-color="#5A6270"/></linearGradient></defs>`;
    g+=`<rect x="116" y="126" width="68" height="100" fill="#15181D"/>`;   // what shows through the widening seams
    const P=(j,i)=>V[j][i].map(F).join(",");
    for(let j=0;j<Rw;j++)for(let i=0;i<C;i++){const q=[V[j][i],V[j][i+1],V[j+1][i+1],V[j+1][i]],gx=q.reduce((t,p)=>t+p[0],0)/4,gy=q.reduce((t,p)=>t+p[1],0)/4,k=.8+R()*.08;
      const pts=q.map(p=>F(gx+(p[0]-gx)*k)+","+F(gy+(p[1]-gy)*k)).join(" "),tint=[0,.18,-.12,.08,-.2][(i*3+j*5)%5];   // each grain pulled in from its neighbours, leaving a gap for the metal to flow into
      const cell=`<polygon points="${pts}" fill="url(#umg${N})"/><polygon points="${pts}" fill="${tint>0?"#FFFFFF":"#000000"}" opacity="${Math.abs(tint).toFixed(2)}"/><polygon points="${pts}" fill="none" stroke="${shade(c,.8)}" stroke-width=".6" opacity=".8"/>
        <path d="M${F(gx-3)} ${F(gy-2)} L${F(gx+2)} ${F(gy-3.5)}" stroke="#FFFFFF" stroke-width=".8" opacity=".7"/>`;
      if(j===0){const d=(3.2+R()*2).toFixed(1),b=(R()*5).toFixed(1),dx=((R()-.5)*14).toFixed(1),rot=((R()-.5)*120).toFixed(0),cx=V[j][i][0]+(V[j][i+1][0]-V[j][i][0])/2,cy=V[j][i][1]+6;
        g+=`<g>${cell}<animateTransform attributeName="transform" type="translate" values="0 0;0 0;${dx} 26;${dx} 26" keyTimes="0;.55;.9;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;.6;.9;.97;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></g>`}
      else g+=cell}
    // liquid-metal seams: a silver web with bright slugs flowing along it
    let seams="";
    for(let j=1;j<Rw;j++)seams+=`M${P(j,0).replace(","," ")}`+V[j].slice(1).map(p=>` L${F(p[0])} ${F(p[1])}`).join("")+" ";
    for(let i=1;i<C;i++)seams+=`M${F(V[0][i][0])} ${F(V[0][i][1])}`+V.slice(1).map(r=>` L${F(r[i][0])} ${F(r[i][1])}`).join("")+" ";
    g+=`<path d="${seams}" stroke="#9FB0C4" stroke-width="3" fill="none" stroke-linejoin="round" opacity=".55" filter="url(#umglow${N})"/>
      <path d="${seams}" stroke="url(#ump${N})" stroke-width="2" fill="none" stroke-linejoin="round"><animate attributeName="stroke-width" values="1.4;2.6;1.4" dur="3.2s" repeatCount="indefinite"/></path>
      <path d="${seams}" stroke="#FFFFFF" stroke-width="1.6" fill="none" stroke-dasharray="4 14" stroke-linecap="round"><animate attributeName="stroke-dashoffset" from="0" to="-72" dur="1.8s" repeatCount="indefinite"/></path>
      <filter id="umglow${N}" x="-20%" y="-20%" width="140%" height="140%"><feGaussianBlur stdDeviation="1.4"/></filter>`;
    // chrome beads crawling along the seams
    for(let k=0;k<6;k++){const j=1+(k%(Rw-1)),row=V[j],path=`M${F(row[0][0])} ${F(row[0][1])}`+row.slice(1).map(p=>` L${F(p[0])} ${F(p[1])}`).join(""),d=(4+R()*4).toFixed(1),b=(R()*6).toFixed(1),r=(1.6+R()*1.6).toFixed(1);
      g+=`<circle r="${r}" fill="url(#umb${N})"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" ${k%2?'keyPoints="1;0" keyTimes="0;1" calcMode="linear"':""} path="${path}"/></circle>`}
    // loose grains that already broke off, rattling at the bottom
    for(let k=0;k<7;k++){const x=+(120+R()*60),y=+(214+R()*8),s2=(1.4+R()*1.8);g+=`<rect x="${F(x)}" y="${F(y)}" width="${F(s2*2)}" height="${F(s2*1.6)}" fill="${[c,hi,lo][k%3]}" transform="rotate(${F(R()*80-40)} ${F(x)} ${F(y)})"/>`}
    g+=`<defs><clipPath id="umcl${N}"><rect x="116" y="126" width="68" height="100"/></clipPath></defs>`;
    if(vc)vc.insertAdjacentHTML("beforeend",g);
    // the glass: frosted where it's being eaten, cracks that keep spreading, a breach leaking liquid metal onto the floor
    const crack=(d,len,dl)=>`<path d="${d}" stroke="#FFFFFF" stroke-width="1" fill="none" opacity=".85" stroke-dasharray="${len}" stroke-dashoffset="${len}"><animate attributeName="stroke-dashoffset" values="${len};0;0;${len}" keyTimes="0;.45;.9;1" dur="7s" begin="-${dl}s" repeatCount="indefinite"/></path>`;
    f+=`<defs><filter id="umf${N}" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="7"/><feColorMatrix type="matrix" values="0 0 0 0 1 0 0 0 0 1 0 0 0 0 1 0 0 0 1.3 -.55"/></filter>
        <clipPath id="umgl${N}"><path d="M114 44 L114 196 Q114 226 150 226 Q186 226 186 196 L186 44 Z"/></clipPath></defs>
      <g clip-path="url(#umgl${N})"><rect x="110" y="150" width="80" height="80" filter="url(#umf${N})" opacity=".45"/><rect x="110" y="44" width="30" height="60" filter="url(#umf${N})" opacity=".3"/></g>`;
    f+=crack("M120 176 L128 186 L124 198 L136 208 L132 220",70,0)+crack("M180 110 L171 118 L175 130 L164 138 L169 150",70,2.3)+crack("M126 70 L134 76 L131 88 L140 95",45,4.1)+crack("M178 180 L170 186 L176 194",30,1.2);
    f+=`<path d="M124 44 l4 -5 l5 4 l6 -6 l5 5 l7 -5 l5 5 l6 -4 l6 5 l5 -4" stroke="#1A1714" stroke-width="3.5" fill="none"/>`;
    f+=`<path d="M181 196 l5 -4 l3 6 l-2 5 l-6 1 z" fill="#1A1C20" stroke="#DDE3EA" stroke-width=".8"/>`;   // the breach
    f+=`<path d="M186 199 Q194 206 192 222 Q191 232 197 236" stroke="url(#ump${N})" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M186 199 Q194 206 192 222" stroke="#FFFFFF" stroke-width="1" fill="none" opacity=".8" stroke-dasharray="2 9"><animate attributeName="stroke-dashoffset" from="0" to="-22" dur=".9s" repeatCount="indefinite"/></path>`;
    f+=`<ellipse cx="204" cy="236" rx="22" ry="4.5" fill="url(#ump${N})" stroke="#5A6270" stroke-width=".8"><animate attributeName="rx" values="16;26;16" dur="6s" repeatCount="indefinite"/></ellipse><ellipse cx="198" cy="234.8" rx="8" ry="1.2" fill="#FFFFFF" opacity=".85"/><ellipse cx="212" cy="236.5" rx="4" ry=".8" fill="#FFFFFF" opacity=".6"/>`;
    f+=`<circle cx="192" cy="214" r="2.4" fill="url(#umb${N})"><animate attributeName="cy" values="206;234" dur="1.4s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;1;0" keyTimes="0;.9;1" dur="1.4s" repeatCount="indefinite"/></circle>`;
    // metal flakes peeling off and drifting down past the vial
    for(let k=0;k<6;k++){const x=+(100+R()*110),d=(2.6+R()*2).toFixed(1),b=(R()*4).toFixed(1);f+=`<g><polygon points="0,-3 3,1 -1,3" fill="${[hi,c,"#E6ECF2"][k%3]}" stroke="rgba(0,0,0,.3)" stroke-width=".3"><animateTransform attributeName="transform" type="rotate" from="0" to="${k%2?360:-360}" dur="${(1+R()).toFixed(1)}s" repeatCount="indefinite"/></polygon><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${F(x)} 40 q${F((R()-.5)*30)} 90 ${F((R()-.5)*20)} 190"/></g>`}}
  if(a.name==="Widow's Vein"){    // the widow's lair: a dead mine seam, an orb web strung between the timbers, the widow herself waiting in the dark, a dropped lantern, poison fog on the floor
    const N=UID,F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    back+=`<defs>
      <radialGradient id="wvl${N}" gradientUnits="userSpaceOnUse" cx="-40" cy="222" r="150"><stop offset="0" stop-color="#FFD27A" stop-opacity=".55"/><stop offset=".5" stop-color="#FF9A3A" stop-opacity=".12"/><stop offset="1" stop-color="#FF9A3A" stop-opacity="0"/></radialGradient>
      <linearGradient id="wvt${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2A1A0C"/><stop offset=".5" stop-color="#5A3A1C"/><stop offset="1" stop-color="#2A1A0C"/></linearGradient>
      <radialGradient id="wvh${N}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FF4A4A"/><stop offset="1" stop-color="#8A0A10"/></radialGradient>
      <filter id="wvb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter>
      <filter id="wvg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
    // the scene: deep in a dead mine, looking down a shaft that runs off into the dark. Timber sets receding, rails running away under the vial, venom glowing in the rock seams, lanterns strung along the roof, cocoons hanging from the beams, little spiders dropping on threads, a tipped cart
    {const U=UID,VX=150,VY=96;let sc=`<defs><radialGradient id="wmr${U}" gradientUnits="userSpaceOnUse" cx="${VX}" cy="${VY}" r="420"><stop offset="0" stop-color="#030402"/><stop offset=".25" stop-color="#0E120A"/><stop offset=".7" stop-color="#1C2014"/><stop offset="1" stop-color="#262A1C"/></radialGradient>
      <radialGradient id="wme${U}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#9CE06A" stop-opacity=".35"/><stop offset=".5" stop-color="#3A6A22" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>
      <linearGradient id="wmt${U}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2A1A0C"/><stop offset=".5" stop-color="#6A4622"/><stop offset="1" stop-color="#2A1A0C"/></linearGradient>
      <linearGradient id="wmh${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A1A0C"/><stop offset=".5" stop-color="#6A4622"/><stop offset="1" stop-color="#2A1A0C"/></linearGradient>
      <radialGradient id="wml${U}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFD27A" stop-opacity=".7"/><stop offset=".4" stop-color="#FF9A3A" stop-opacity=".18"/><stop offset="1" stop-color="#FF9A3A" stop-opacity="0"/></radialGradient>
      <filter id="wmb${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#wmr${U})"/>`;
    // rough rock, darker the deeper you look
    for(let k=0;k<60;k++){const an=R()*Math.PI*2,d=+rn(60,420),x=VX+Math.cos(an)*d*1.3,y=VY+Math.sin(an)*d,r=d*.12+4;let pts="";for(let m=0;m<6;m++){const a2=m/6*6.283+R()*.5;pts+=`${F(x+Math.cos(a2)*r)},${F(y+Math.sin(a2)*r*.8)} `}
      sc+=`<polygon points="${pts}" fill="${["#2A2E20","#20241A","#34382A","#181C12"][k%4]}" opacity="${F(Math.min(1,d/260))}"/>`}
    // the far end of the shaft, where something faintly glows
    sc+=`<ellipse cx="${VX}" cy="${VY}" rx="40" ry="32" fill="#010201"/><ellipse cx="${VX}" cy="${VY}" rx="80" ry="64" fill="url(#wme${U})"><animate attributeName="opacity" values=".6;1;.6" dur="4s" repeatCount="indefinite"/></ellipse>`;
    // venom glowing in the seams of the rock
    let vein="";for(let k=0;k<9;k++){const an=R()*Math.PI*2;let d=+rn(90,160),x=VX+Math.cos(an)*d*1.3,y=VY+Math.sin(an)*d,p=`M${F(x)} ${F(y)}`;for(let t=0;t<5;t++){d+=18+R()*20;const a2=an+(R()-.5)*.5;x=VX+Math.cos(a2)*d*1.3;y=VY+Math.sin(a2)*d;p+=` L${F(x)} ${F(y)}`}vein+=`<path d="${p}"/>`}
    sc+=`<g stroke="#9CE06A" stroke-width="3" fill="none" filter="url(#wmb${U})" opacity=".6">${vein}<animate attributeName="opacity" values=".3;.75;.3" dur="3.2s" repeatCount="indefinite"/></g><g stroke="#DFFFB0" stroke-width=".9" fill="none" opacity=".7">${vein}</g>`;
    // rails running away down the shaft, sleepers getting closer together
    const lerp=(a,b,t)=>a+(b-a)*t;let rails="";for(let k=0;k<14;k++){const t=1-Math.pow(k/14,1.6),y=lerp(VY+14,300,t),hw=lerp(10,150,t);rails+=`<path d="M${F(VX-hw*1.15)} ${F(y)} H${F(VX+hw*1.15)}" stroke="#2E2014" stroke-width="${F(lerp(1,7,t))}"/>`}
    sc+=rails+`<path d="M${VX-10} ${VY+14} L0 300 M${VX+10} ${VY+14} L300 300" stroke="#6A6E72" stroke-width="3"/><path d="M${VX-10} ${VY+14} L0 300 M${VX+10} ${VY+14} L300 300" stroke="#B8BCC0" stroke-width=".8" transform="translate(0 -1.5)"/>`;
    // timber sets receding into the dark
    for(let k=5;k>=0;k--){const s=1/(1+k*.55),W=300*s,H=250*s,x0=VX-W,x1=VX+W,y0=VY-H*.9,y1=VY+H*1.1,w=Math.max(3,22*s),o=F(Math.min(1,.35+s*.8));
      sc+=`<g opacity="${o}"><rect x="${F(x0-w/2)}" y="${F(y0)}" width="${F(w)}" height="${F(y1-y0)}" fill="url(#wmt${U})"/><rect x="${F(x1-w/2)}" y="${F(y0)}" width="${F(w)}" height="${F(y1-y0)}" fill="url(#wmt${U})"/>
        <rect x="${F(x0-w)}" y="${F(y0-w*.8)}" width="${F(x1-x0+w*2)}" height="${F(w*.8)}" fill="url(#wmh${U})"/><path d="M${F(x0+w/2)} ${F(y0+w*1.4)} L${F(x0+w*2.4)} ${F(y0)} M${F(x1-w/2)} ${F(y0+w*1.4)} L${F(x1-w*2.4)} ${F(y0)}" stroke="#3A2610" stroke-width="${F(w*.35)}"/>
        <path d="M${F(x0+w/2)} ${F(y0)} L${F(x0+w/2+40*s)} ${F(y0)} L${F(x0+w/2)} ${F(y0+40*s)} Z M${F(x1-w/2)} ${F(y0)} L${F(x1-w/2-40*s)} ${F(y0)} L${F(x1-w/2)} ${F(y0+40*s)} Z" fill="none" stroke="#DDE6D4" stroke-width=".6" opacity=".5"/>
        <path d="M${F(x0+w/2)} ${F(y0+20*s)} Q${F(x0+w/2+14*s)} ${F(y0+14*s)} ${F(x0+w/2+20*s)} ${F(y0)} M${F(x1-w/2)} ${F(y0+20*s)} Q${F(x1-w/2-14*s)} ${F(y0+14*s)} ${F(x1-w/2-20*s)} ${F(y0)}" fill="none" stroke="#DDE6D4" stroke-width=".5" opacity=".45"/></g>`}
    // lanterns strung along the roof, flickering, fewer and dimmer deeper in
    let cable=`M-110 ${VY-230}`;const lamps=[];for(let k=0;k<6;k++){const s=1/(1+k*.55),x=VX-300*s*.55,y=VY-250*s*.9+10*s;cable+=` Q${F(x+30*s)} ${F(y+12*s)} ${F(x)} ${F(y+6*s)}`;lamps.push([x,y+6*s,s])}
    sc+=`<path d="${cable}" stroke="#15120C" stroke-width="1.6" fill="none"/>`;
    lamps.forEach(([x,y,s],k)=>{sc+=`<circle cx="${F(x)}" cy="${F(y+8*s)}" r="${F(46*s)}" fill="url(#wml${U})"><animate attributeName="opacity" values="${k===2?"1;.2;1;1;.4;1":".8;1;.85;1;.8"}" dur="${(1.3+k*.4).toFixed(1)}s" repeatCount="indefinite"/></circle><path d="M${F(x)} ${F(y)} v${F(4*s)}" stroke="#15120C" stroke-width="${F(1.4*s)}"/><rect x="${F(x-4*s)}" y="${F(y+4*s)}" width="${F(8*s)}" height="${F(10*s)}" rx="${F(2*s)}" fill="#FFE2A0" stroke="#2A2218" stroke-width="${F(1.2*s)}"/>`});
    // cocoons hanging from the nearest beam, turning slowly
    [[-30,-18,30],[18,-22,24],[268,-20,34],[320,-16,26]].forEach(([x,y,l],k)=>{const d=(4+k*.7).toFixed(1);sc+=`<g><path d="M${x} -40 V${y}" stroke="#DDE6D4" stroke-width=".8" opacity=".7"/><g transform="translate(${x} ${y})"><path d="M0 0 C${l*.45} ${l*.2} ${l*.4} ${l*.9} 0 ${l} C${-l*.4} ${l*.9} ${-l*.45} ${l*.2} 0 0 Z" fill="#D8DCCB" stroke="#9AA090" stroke-width=".8"/>${[.25,.45,.65,.8].map(t=>`<path d="M${F(-l*.38)} ${F(l*t)} Q0 ${F(l*t+4)} ${F(l*.38)} ${F(l*t-2)}" stroke="#9AA090" stroke-width=".7" fill="none"/>`).join("")}</g><animateTransform attributeName="transform" type="rotate" values="-4 ${x} -40;4 ${x} -40;-4 ${x} -40" dur="${d}s" repeatCount="indefinite"/></g>`});
    // egg sacs tucked in a corner web
    [[-60,184],[-48,196],[354,190]].forEach(([x,y])=>sc+=`<circle cx="${x}" cy="${y}" r="7" fill="#E8E4D0" stroke="#A8A490" stroke-width=".8"/><path d="M${x-5} ${y-2} Q${x} ${y+2} ${x+5} ${y-3}" stroke="#A8A490" stroke-width=".6" fill="none"/>`);
    // little spiders dropping on threads and climbing back up
    [[-74,1],[36,2],[282,0],[350,3]].forEach(([x,k])=>{const d=(5+k*1.3).toFixed(1),y1=60+k*30;sc+=`<g><path d="M${x} -40 V${y1}" stroke="#DDE6D4" stroke-width=".5" opacity=".5"/><g><circle r="3" fill="#050605"/><path d="M-5 -2 L5 2 M-5 2 L5 -2 M-6 0 H6" stroke="#050605" stroke-width=".9"/><animateMotion dur="${d}s" repeatCount="indefinite" path="M${x} -30 V${y1} V-30" keyTimes="0;.5;1" keyPoints="0;1;0" calcMode="spline" keySplines=".5 0 .5 1;.5 0 .5 1"/></g></g>`});
    // a mine cart tipped on its side, its load spilled across the rails
    sc+=`<g transform="translate(-58 222) rotate(-16)"><path d="M-34 -30 L34 -30 L28 10 L-28 10 Z" fill="#3A3A34" stroke="#15150F" stroke-width="2"/><path d="M-34 -30 L34 -30" stroke="#6A6A60" stroke-width="2"/><path d="M-30 -18 H30 M-29 -6 H29" stroke="#2A2A24" stroke-width="1.4"/><circle cx="-18" cy="14" r="7" fill="#20201A" stroke="#6A6A60" stroke-width="1.4"/><circle cx="18" cy="14" r="7" fill="#20201A" stroke="#6A6A60" stroke-width="1.4"/></g>`;
    for(let k=0;k<10;k++)sc+=`<ellipse cx="${rn(-20,40)}" cy="${rn(226,244)}" rx="${rn(3,7)}" ry="${rn(2,4)}" fill="${["#4A4A40","#5A5A4E","#3A3A32"][k%3]}"/>`;
    back=sc+back;}
    const cx=232,cy=46;let spokes="",spiral="";
    for(let k=0;k<14;k++){const an=k/14*Math.PI*2;spokes+=`M${cx} ${cy} L${F(cx+Math.cos(an)*190)} ${F(cy+Math.sin(an)*150)} `}
    for(let r=14;r<180;r+=12+r*.06){let d="";for(let k=0;k<=14;k++){const an=k/14*Math.PI*2,rr=r*(1+Math.sin(k*1.7)*.04);d+=(k?" L":"M")+F(cx+Math.cos(an)*rr)+" "+F(cy+Math.sin(an)*rr*.79)}spiral+=d+" "}
    back+=`<g stroke="#DDE6D4" fill="none" opacity=".55"><path d="${spokes}" stroke-width=".9"/><path d="${spiral}" stroke-width=".6"/></g>
      <path d="${spiral}" stroke="#FFFFFF" stroke-width="1" fill="none" stroke-dasharray="3 60" opacity=".8"><animate attributeName="stroke-dashoffset" from="0" to="-126" dur="4s" repeatCount="indefinite"/></path>`;
    for(let k=0;k<22;k++){const an=R()*Math.PI*2,r=+rn(30,170);const x=cx+Math.cos(an)*r,y=cy+Math.sin(an)*r*.79;back+=`<circle cx="${F(x)}" cy="${F(y)}" r="${rn(1,2.2)}" fill="${k%3?"#E6F4FF":"#9CE06A"}" filter="url(#wvg${N})"><animate attributeName="opacity" values=".4;1;.4" dur="${rn(1.5,3.5)}s" repeatCount="indefinite"/></circle>`}
    const leg=(sx,sy,ex,ey,kx,ky,k)=>`<path d="M${sx} ${sy} Q${kx} ${ky} ${ex} ${ey}" stroke="#050605" stroke-width="3.2" fill="none" stroke-linecap="round"><animate attributeName="d" values="M${sx} ${sy} Q${kx} ${ky} ${ex} ${ey};M${sx} ${sy} Q${kx} ${ky-4} ${ex+(k%2?2:-2)} ${ey-2};M${sx} ${sy} Q${kx} ${ky} ${ex} ${ey}" dur="${(3+k*.37).toFixed(2)}s" repeatCount="indefinite"/></path>`;
    let legs="";[[-1,-8,-52,-40,-40,-36],[-1,-4,-64,-6,-44,-18],[-1,2,-60,22,-42,8],[-1,6,-46,48,-30,30]].forEach(([d,sy,ex,ey,kx,ky],k)=>{legs+=leg(-6,sy,ex,ey,kx,ky,k)+leg(6,sy,-ex,ey,-kx,ky,k+4)});
    back+=`<g transform="translate(${cx} ${cy-6})"><g transform="scale(1.6)">${legs}<ellipse cx="0" cy="-12" rx="7" ry="6" fill="#050605"/><ellipse cx="0" cy="10" rx="16" ry="19" fill="#050605"/>
        <path d="M-4 2 L4 2 L0 10 L4 18 L-4 18 L0 10 Z" fill="url(#wvh${N})" filter="url(#wvg${N})"><animate attributeName="opacity" values=".6;1;.6" dur="2.4s" repeatCount="indefinite"/></path>
        ${[-3,-1,1,3].map(x=>`<circle cx="${x}" cy="-15" r=".9" fill="#FFE2A0"><animate attributeName="opacity" values=".3;1;.3" dur="${(2+Math.abs(x)*.3).toFixed(1)}s" repeatCount="indefinite"/></circle>`).join("")}
        <path d="M0 29 L0 60" stroke="#DDE6D4" stroke-width=".8" opacity=".7"/></g>
      <animateTransform attributeName="transform" type="translate" values="${cx} ${cy-6};${cx} ${cy-2};${cx} ${cy-6}" dur="6s" repeatCount="indefinite"/></g>`;
    f+=`<g stroke="#EEF4E8" fill="none" opacity=".6" stroke-linecap="round"><path d="M112 40 Q150 58 188 34 M112 60 Q150 44 188 72 M113 26 Q150 12 187 30 M114 88 Q150 104 186 80" stroke-width="1.1"/>
      <path d="M150 -12 L150 14 M136 -10 L144 14 M166 -8 L158 14" stroke-width=".8"/></g>`;
    for(let k=0;k<3;k++){const x=[120,178,150][k],d=(3.2+k*.7).toFixed(1);f+=`<ellipse cx="${x}" cy="30" rx="2.2" ry="3" fill="#9CE06A" filter="url(#wvg${N})"><animate attributeName="cy" values="${30+k*6};222" dur="${d}s" begin="-${(k*1.3).toFixed(1)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.85;1" dur="${d}s" begin="-${(k*1.3).toFixed(1)}s" repeatCount="indefinite"/></ellipse>`}
    f+=`<rect x="117" y="140" width="66" height="84" fill="#6ABF3A" opacity=".15"><animate attributeName="opacity" values=".05;.22;.05" dur="2.4s" repeatCount="indefinite"/></rect>`;
    f+=`<g filter="url(#wvb${N})"><ellipse cx="120" cy="236" rx="190" ry="18" fill="#9CC46A" opacity=".5"><animate attributeName="cx" values="90;190;90" dur="8s" repeatCount="indefinite"/></ellipse><ellipse cx="220" cy="240" rx="170" ry="14" fill="#B8E070" opacity=".38"><animate attributeName="cx" values="240;110;240" dur="7s" repeatCount="indefinite"/></ellipse></g>`}
  if(a.name==="Hollow Star"){     // a star with nothing at its heart: an eclipse corona flaring behind the glass, a void inside ringed by burning vapor, starlight being dragged in and swallowed
    const N=UID,F=v=>(+v).toFixed(1),CX=150,CY=136;svg.style.overflow="visible";
    back+=`<defs>
      <radialGradient id="hsc${N}" gradientUnits="userSpaceOnUse" cx="${CX}" cy="${CY}" r="150"><stop offset=".2" stop-color="#FFFFFF" stop-opacity="0"/><stop offset=".24" stop-color="#FFFFFF" stop-opacity=".95"/><stop offset=".32" stop-color="#E6D2FF" stop-opacity=".6"/><stop offset=".55" stop-color="#9A6AFF" stop-opacity=".22"/><stop offset="1" stop-color="#6A3AD0" stop-opacity="0"/></radialGradient>
      <linearGradient id="hsp${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#F4ECFF" stop-opacity=".9"/><stop offset="1" stop-color="#9A6AFF" stop-opacity="0"/></linearGradient>
      <filter id="hsb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
      <filter id="hsg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.2"/></filter></defs>`;
    // a field of stars, and some of them being dragged in on spirals and snuffed out
    for(let k=0;k<40;k++){const x=+rn(-120,420),y=+rn(-60,250);back+=`<circle cx="${x}" cy="${y}" r="${rn(.4,1.3)}" fill="#EDE4FF"><animate attributeName="opacity" values=".2;1;.2" dur="${rn(1.5,4)}s" repeatCount="indefinite"/></circle>`}
    for(let k=0;k<9;k++){const r0=+rn(140,230),a0=R()*Math.PI*2,d=rn(3,6),b=rn(0,6);let path=`M${F(CX+Math.cos(a0)*r0)} ${F(CY+Math.sin(a0)*r0*.8)}`;
      for(let t=1;t<=24;t++){const rr=r0*(1-t/24),aa=a0+t/24*Math.PI*1.6;path+=` L${F(CX+Math.cos(aa)*rr)} ${F(CY+Math.sin(aa)*rr*.8)}`}
      back+=`<g><circle r="1.8" fill="#FFFFFF" filter="url(#hsg${N})"><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.85;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" calcMode="spline" keyTimes="0;1" keySplines=".6 0 1 1" path="${path}"/></g>`}
    // the corona: streamers flaring out from behind the void, turning slowly
    let st="";for(let k=0;k<16;k++){const an=k/16*360+(R()-.5)*8,len=+rn(70,150),w=+rn(4,10);st+=`<path d="M0 -${F(w)} C${F(len*.4)} -${F(w*1.2)} ${F(len*.8)} -2 ${F(len)} 0 C${F(len*.8)} 2 ${F(len*.4)} ${F(w*1.2)} 0 ${F(w)} Z" fill="url(#hsp${N})" transform="rotate(${F(an)}) translate(34 0)"><animate attributeName="opacity" values=".45;1;.55;.9;.45" dur="${F(rn(1.8,3.4))}s" repeatCount="indefinite"/></path>`}
    back+=`<g transform="translate(${CX} ${CY})"><g filter="url(#hsb${N})">${st}<animateTransform attributeName="transform" type="rotate" from="0" to="360" dur="80s" repeatCount="indefinite"/></g></g>`;
    back+=`<circle cx="${CX}" cy="${CY}" r="150" fill="url(#hsc${N})"><animate attributeName="opacity" values=".85;1;.85" dur="2.2s" repeatCount="indefinite"/></circle><circle cx="${CX}" cy="${CY}" r="34" fill="#05020C"/>`;
    // polar jets firing out of both ends
    back+=`<g filter="url(#hsg${N})" opacity=".9"><path d="M${CX-3} ${CY} L${CX} -120 L${CX+3} ${CY} Z" fill="#E6D2FF"><animate attributeName="opacity" values=".3;1;.3" dur="1.3s" repeatCount="indefinite"/></path><path d="M${CX-3} ${CY} L${CX} 360 L${CX+3} ${CY} Z" fill="#E6D2FF"><animate attributeName="opacity" values="1;.3;1" dur="1.3s" repeatCount="indefinite"/></path></g>`;
    // inside the glass: the vapor wound into a burning ring around the void, brighter on the side swinging toward you
    f+=`<defs><clipPath id="hsv${N}"><path d="M117 46 L183 46 L183 196 Q183 223 150 223 Q117 223 117 196 Z"/></clipPath>
      <linearGradient id="hsr${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".35" stop-color="#E6D2FF"/><stop offset="1" stop-color="#8A5AE0" stop-opacity=".4"/></linearGradient></defs>
      <g clip-path="url(#hsv${N})"><circle cx="${CX}" cy="${CY}" r="30" fill="#05020C" opacity=".92"/>
      <circle cx="${CX}" cy="${CY}" r="33" fill="none" stroke="#FFFFFF" stroke-width="1.6" opacity=".9" filter="url(#hsg${N})"><animate attributeName="r" values="32;35;32" dur="2.2s" repeatCount="indefinite"/></circle>
      <g transform="rotate(-14 ${CX} ${CY})"><ellipse cx="${CX}" cy="${CY}" rx="32" ry="9" fill="none" stroke="url(#hsr${N})" stroke-width="6" filter="url(#hsg${N})"/>
        <ellipse cx="${CX}" cy="${CY}" rx="32" ry="9" fill="none" stroke="#FFFFFF" stroke-width="1.6" stroke-dasharray="6 14"><animate attributeName="stroke-dashoffset" from="0" to="-80" dur="1.4s" repeatCount="indefinite"/></ellipse>
        <path d="M${CX-32} ${CY} A32 9 0 0 0 ${CX+32} ${CY}" fill="none" stroke="url(#hsr${N})" stroke-width="7" opacity=".95"/></g>`;
    for(let k=0;k<8;k++){const d=rn(1.2,2.4),b=rn(0,2.4),rx=+rn(18,30),ry=+rn(5,9);f+=`<g transform="rotate(-14 ${CX} ${CY})"><circle r="${rn(.8,1.6)}" fill="#FFFFFF"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${CX-rx} ${CY} a${rx} ${ry} 0 1 0 ${2*rx} 0 a${rx} ${ry} 0 1 0 ${-2*rx} 0"/></circle></g>`}
    f+=`<rect x="117" y="46" width="66" height="178" fill="#FFFFFF" opacity="0"><animate attributeName="opacity" values="0;0;.35;0" keyTimes="0;.9;.93;1" dur="6s" repeatCount="indefinite"/></rect></g>`;   // a decay flash now and then
    // fragments of it orbiting outside the glass
    for(let k=0;k<5;k++){const d=rn(2.2,4),b=rn(0,4),ry=rn(18,34);f+=`<circle r="${rn(2,3.5)}" fill="#C8A8FF" filter="url(#hsg${N})"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${CX-70} ${CY} a70 ${ry} 0 1 0 140 0 a70 ${ry} 0 1 0 -140 0"/></circle>`}}
  if(a.name==="Crown of Rays"){   // cursed regalia on display: a velvet-draped vault alcove, a museum spotlight, the rod on its cushion glowing a sickly green in the dark, and the crown it came from hovering over it
    const N=UID,F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    back+=`<defs>
      <linearGradient id="crd${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#2A0A28"/><stop offset=".25" stop-color="#5A1A4A"/><stop offset=".5" stop-color="#34102E"/><stop offset=".75" stop-color="#5A1A4A"/><stop offset="1" stop-color="#2A0A28"/></linearGradient>
      <linearGradient id="crs${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFE8B0" stop-opacity=".55"/><stop offset="1" stop-color="#FFE8B0" stop-opacity="0"/></linearGradient>
      <linearGradient id="crc${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7A2A6A"/><stop offset="1" stop-color="#3A0E34"/></linearGradient>
      <linearGradient id="crg${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF1B0"/><stop offset=".45" stop-color="#E6B83A"/><stop offset="1" stop-color="#8A6010"/></linearGradient>
      <radialGradient id="crr${N}" gradientUnits="userSpaceOnUse" cx="150" cy="120" r="140"><stop offset="0" stop-color="#8CFF9E" stop-opacity=".5"/><stop offset=".4" stop-color="#5AE08A" stop-opacity=".18"/><stop offset="1" stop-color="#5AE08A" stop-opacity="0"/></radialGradient>
      <filter id="crb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4"/></filter>
      <filter id="crb2${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4"/></filter></defs>`;
    // the alcove: a stone arch in darkness, velvet drapes pulled back with gold cords
    back+=`<path d="M40 250 L40 40 Q150 -70 260 40 L260 250" fill="#140816" stroke="#4A2A40" stroke-width="3"/>`;
    const drape=(x0,dir)=>{let folds="";for(let k=0;k<5;k++)folds+=`<path d="M${x0+dir*k*22} -80 Q${x0+dir*(k*22+10)} 90 ${x0+dir*(k*14+30)} 250" stroke="#1A0418" stroke-width="2" fill="none" opacity=".6"/>`;
      return `<path d="M${x0} -80 L${x0+dir*120} -80 Q${x0+dir*70} 60 ${x0+dir*40} 110 Q${x0+dir*80} 170 ${x0+dir*120} 250 L${x0} 250 Z" fill="url(#crd${N})"/>${folds}<path d="M${x0+dir*20} 104 Q${x0+dir*44} 118 ${x0+dir*60} 108" stroke="#E6B83A" stroke-width="3" fill="none"/><circle cx="${x0+dir*60}" cy="110" r="4" fill="#E6B83A"/><path d="M${x0+dir*60} 114 l-3 14 h6 z" fill="#E6B83A"/>`};
    back+=drape(-100,1)+drape(400,-1);
    // a museum spotlight falling on it, dust turning in the beam
    back+=`<polygon points="120,-80 180,-80 250,240 50,240" fill="url(#crs${N})" filter="url(#crb${N})"/>`;
    for(let k=0;k<14;k++){const x=+rn(80,220),y=+rn(-40,220),d=rn(5,9),b=rn(0,9);back+=`<circle cx="${x}" cy="${y}" r="${rn(.5,1.2)}" fill="#FFF1C8"><animate attributeName="cy" values="${y};${F(y-30)};${y}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values=".2;.9;.2" dur="${F(d/2)}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // the curse: a green luminescence soaking into everything around it
    back+=`<circle cx="150" cy="120" r="140" fill="url(#crr${N})"><animate attributeName="opacity" values=".6;1;.6" dur="3.2s" repeatCount="indefinite"/></circle>`;
    // the velvet cushion it rests on, gold piping and tassels
    back+=`<g transform="rotate(-20 150 120)"><rect x="28" y="128" width="244" height="34" rx="16" fill="url(#crc${N})" stroke="#E6B83A" stroke-width="2.4"/><path d="M40 145 Q150 152 260 145" stroke="#2A0A28" stroke-width="1.4" fill="none" opacity=".7"/>
      ${[[30,160],[270,160]].map(([x,y])=>`<g><circle cx="${x}" cy="${y}" r="4" fill="#E6B83A"/><path d="M${x-3} ${y+3} l-2 14 h10 l-2 -14 z" fill="#E6B83A"/><path d="M${x-4} ${y+10} v8 M${x} ${y+10} v9 M${x+4} ${y+10} v8" stroke="#8A6010" stroke-width=".8"/></g>`).join("")}</g>`;
    // the green glow clinging to the rod itself
    back+=`<g transform="rotate(-20 150 120)"><rect x="30" y="86" width="238" height="68" rx="32" fill="#8CFF9E" opacity=".3" filter="url(#crb${N})"><animate attributeName="opacity" values=".15;.4;.15" dur="3.2s" repeatCount="indefinite"/></rect></g>`;
    // the crown hovering above, bobbing slowly, thin green rays leaking from its points
    const pts=[[-38,0],[-38,-18],[-28,-8],[-19,-30],[-10,-8],[0,-38],[10,-8],[19,-30],[28,-8],[38,-18],[38,0]];
    let rays2="";[[-38,-18],[-19,-30],[0,-38],[19,-30],[38,-18]].forEach(([x,y],k)=>{const an=Math.atan2(y+10,x)||-Math.PI/2;rays2+=`<path d="M${x} ${y} L${F(x+Math.cos(an)*70)} ${F(y+Math.sin(an)*70)}" stroke="#AFFFC0" stroke-width="1.4" opacity=".6"><animate attributeName="opacity" values=".1;.8;.1" dur="${(1.6+k*.3).toFixed(1)}s" repeatCount="indefinite"/></path>`});
    f+=`<g><g transform="translate(150 50)">${rays2}
      <polygon points="${pts.map(p=>p.join(",")).join(" ")}" fill="url(#crg${N})" stroke="#6A4608" stroke-width="1.2" stroke-linejoin="round"/>
      <rect x="-40" y="-2" width="80" height="12" rx="3" fill="url(#crg${N})" stroke="#6A4608" stroke-width="1.2"/>
      ${[-26,-9,9,26].map((x,k)=>`<ellipse cx="${x}" cy="4" rx="4" ry="3" fill="${["#C8243A","#2A6AC8","#C8243A","#2A6AC8"][k]}" stroke="#6A4608" stroke-width=".6"/><ellipse cx="${x-1.2}" cy="3" rx="1.2" ry=".8" fill="#fff" opacity=".8"/>`).join("")}
      ${[[-38,-18],[-19,-30],[0,-38],[19,-30],[38,-18]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="#FFF6D0" stroke="#6A4608" stroke-width=".6"/>`).join("")}
      <path d="M-34 -2 L34 -2" stroke="#FFF6D0" stroke-width="1" opacity=".8"/>
      <ellipse cx="0" cy="-10" rx="44" ry="30" fill="#8CFF9E" opacity=".12" filter="url(#crb2${N})"><animate attributeName="opacity" values=".05;.2;.05" dur="3.2s" repeatCount="indefinite"/></ellipse></g>
      <animateTransform attributeName="transform" type="translate" values="0 0;0 -6;0 0" dur="4s" repeatCount="indefinite"/></g>`;
    // the curse rising off it: pale green wisps spiralling up
    for(let k=0;k<6;k++){const x=+rn(70,230),d=rn(3,5),b=rn(0,5);f+=`<path d="M${x} 150 q-10 -20 0 -40 q10 -20 0 -40" stroke="#AFFFC0" stroke-width="${rn(2,4)}" fill="none" stroke-linecap="round" filter="url(#crb2${N})" opacity="0"><animateTransform attributeName="transform" type="translate" values="0 0;0 -50" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.55;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></path>`}
    // glints travelling along the rod
    f+=`<g transform="rotate(-20 150 120)"><rect x="40" y="100" width="18" height="4" rx="2" fill="#FFFFFF" opacity=".9"><animate attributeName="x" values="40;250;250" keyTimes="0;.5;1" dur="3.6s" repeatCount="indefinite"/><animate attributeName="opacity" values=".9;.9;0" keyTimes="0;.5;.51" dur="3.6s" repeatCount="indefinite"/></rect></g>`;}
  if(a.name==="Phoenix Lattice"){  // only a projection: a projector throws a cone of light, and in it a wireframe phoenix beats its wings over the vial, bursts into pixels, and re-forms
    const N=UID,F=v=>(+v).toFixed(1);svg.style.overflow="visible";
    back+=`<defs>
      <linearGradient id="plc${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#78F0FF" stop-opacity=".55"/><stop offset=".6" stop-color="#78F0FF" stop-opacity=".12"/><stop offset="1" stop-color="#FF4AC8" stop-opacity="0"/></linearGradient>
      <linearGradient id="plw${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF4AC8"/><stop offset=".5" stop-color="#B07AFF"/><stop offset="1" stop-color="#78F0FF"/></linearGradient>
      <filter id="plg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <filter id="plb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="5"/></filter></defs>`;
    // the scene: the Institute's lattice simulator. A chamber of glowing grid walls running off to a vanishing point, emitter pylons pulsing either side, a great containment ring turning behind it, data raining down the walls, a control console, scanlines and glitches over everything
    {const U=UID,VX=150,VY=104;let sc=`<defs><radialGradient id="pcv${U}" gradientUnits="userSpaceOnUse" cx="${VX}" cy="${VY}" r="420"><stop offset="0" stop-color="#2A1450"/><stop offset=".35" stop-color="#120A2A"/><stop offset="1" stop-color="#04040C"/></radialGradient>
      <linearGradient id="pcp${U}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#10142A"/><stop offset=".5" stop-color="#2A3050"/><stop offset="1" stop-color="#10142A"/></linearGradient>
      <linearGradient id="pcs${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#78F0FF" stop-opacity="0"/><stop offset=".5" stop-color="#78F0FF" stop-opacity=".9"/><stop offset="1" stop-color="#78F0FF" stop-opacity="0"/></linearGradient>
      <filter id="pcg${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#pcv${U})"/>`;
    // the chamber: grid lines on walls and ceiling converging on the vanishing point, and the back wall's frame
    let g="";const BW=70,BH=52;for(let k=-7;k<=7;k++){const bx=VX+k*BW/7;g+=`M${F(bx)} ${VY-BH} L${F(VX+k*BW/7*9)} ${VY-BH*9} `}
    for(let k=-5;k<=5;k++){const by=VY+k*BH/5;g+=`M${VX-BW} ${F(by)} L${F(VX-BW*9)} ${F(VY+k*BH/5*9)} M${VX+BW} ${F(by)} L${F(VX+BW*9)} ${F(VY+k*BH/5*9)} `}
    for(let d=1;d<9;d+=Math.max(.5,d*.35)){g+=`M${F(VX-BW*d)} ${F(VY-BH*d)} H${F(VX+BW*d)} M${F(VX-BW*d)} ${F(VY-BH*d)} V${F(VY+BH*d)} M${F(VX+BW*d)} ${F(VY-BH*d)} V${F(VY+BH*d)} `}
    sc+=`<path d="${g}" stroke="#B07AFF" stroke-width=".8" fill="none" opacity=".35"/><rect x="${VX-BW}" y="${VY-BH}" width="${BW*2}" height="${BH*2}" fill="#06061A" stroke="#FF4AC8" stroke-width="1.6" filter="url(#pcg${U})"/>`;
    // a pulse of light running down the grid toward you, over and over
    sc+=`<rect x="${VX-BW}" y="${VY-BH}" width="${BW*2}" height="${BH*2}" fill="none" stroke="#78F0FF" stroke-width="2" opacity="0"><animateTransform attributeName="transform" type="translate" values="0 0;${-VX*7} ${-VY*7}" dur="3s" repeatCount="indefinite" additive="sum"/><animateTransform attributeName="transform" type="scale" values="1;8" dur="3s" repeatCount="indefinite" additive="sum"/><animate attributeName="opacity" values="0;.8;0" dur="3s" repeatCount="indefinite"/></rect>`;
    // data raining down the side walls
    for(let k=0;k<16;k++){const side=k%2?1:-1,x=VX+side*(+rn(110,330)),d=rn(1.6,3.4),b=rn(0,3.4),l=+rn(20,60);sc+=`<rect x="${F(x)}" y="-110" width="2" height="${l}" fill="url(#pcs${U})" opacity=".7"><animate attributeName="y" values="-110;260" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></rect>`}
    // the great containment ring turning behind it, marked like a dial
    let ticks="";for(let k=0;k<36;k++){const an=k/36*Math.PI*2;ticks+=`M${F(Math.cos(an)*118)} ${F(Math.sin(an)*118)} L${F(Math.cos(an)*(k%3?124:130))} ${F(Math.sin(an)*(k%3?124:130))} `}
    sc+=`<g transform="translate(${VX} 96) scale(1 .42)"><circle r="120" fill="none" stroke="#78F0FF" stroke-width="3" opacity=".55" filter="url(#pcg${U})"/><g><path d="${ticks}" stroke="#78F0FF" stroke-width="1.4"/><circle r="132" fill="none" stroke="#FF4AC8" stroke-width="1.2" stroke-dasharray="30 14 6 14"/><animateTransform attributeName="transform" type="rotate" from="0" to="360" dur="24s" repeatCount="indefinite"/></g></g>`;
    // emitter pylons either side, lights climbing them
    [[-40,1],[340,-1]].forEach(([x,dir],k)=>{sc+=`<g><path d="M${x-14} 250 L${x-8} -60 L${x+8} -60 L${x+14} 250 Z" fill="url(#pcp${U})" stroke="#3A4070" stroke-width="1.2"/><path d="M${x-8} -60 L${x} -80 L${x+8} -60" fill="#2A3050" stroke="#3A4070"/>`;
      for(let m=0;m<9;m++){const y=230-m*32;sc+=`<rect x="${x-5}" y="${y}" width="10" height="4" rx="2" fill="${m%2?"#FF4AC8":"#78F0FF"}"><animate attributeName="opacity" values=".15;1;.15" dur="1.8s" begin="${(m*.2+k*.1).toFixed(2)}s" repeatCount="indefinite"/></rect>`}
      sc+=`<circle cx="${x}" cy="-72" r="7" fill="#FFFFFF" filter="url(#pcg${U})"><animate attributeName="r" values="5;9;5" dur="1.2s" repeatCount="indefinite"/></circle><path d="M${x} -72 L${VX} 40" stroke="#B8FAFF" stroke-width="1" opacity=".35" stroke-dasharray="4 6"><animate attributeName="stroke-dashoffset" from="0" to="${-20*dir}" dur=".6s" repeatCount="indefinite"/></path></g>`});
    // the operator's console off to the right: screens with a trace, a warning, buttons blinking
    sc+=`<g transform="translate(262 196)"><path d="M0 0 L80 0 L96 44 L-6 44 Z" fill="#141830" stroke="#3A4070" stroke-width="1.2"/><rect x="6" y="-40" width="36" height="30" rx="2" fill="#050A14" stroke="#78F0FF" stroke-width="1"/><rect x="48" y="-40" width="36" height="30" rx="2" fill="#140512" stroke="#FF4AC8" stroke-width="1"/>
      <path d="M9 -24 l4 -6 l4 10 l4 -14 l4 12 l4 -6 l4 4 l4 -2" stroke="#78F0FF" stroke-width="1" fill="none"><animate attributeName="d" values="M9 -24 l4 -6 l4 10 l4 -14 l4 12 l4 -6 l4 4 l4 -2;M9 -24 l4 8 l4 -12 l4 6 l4 -10 l4 12 l4 -8 l4 4;M9 -24 l4 -6 l4 10 l4 -14 l4 12 l4 -6 l4 4 l4 -2" dur="1s" repeatCount="indefinite"/></path>
      <text x="66" y="-21" text-anchor="middle" font-family="Press Start 2P, monospace" font-size="5" fill="#FF4AC8"><animate attributeName="opacity" values="1;0;1" dur=".8s" repeatCount="indefinite"/>UNSTABLE</text>
      ${[0,1,2,3,4,5].map(k=>`<circle cx="${10+k*13}" cy="10" r="2.4" fill="${["#78F0FF","#FF4AC8","#FFE27A"][k%3]}"><animate attributeName="opacity" values="1;.2;1" dur="${(.6+k*.17).toFixed(2)}s" repeatCount="indefinite"/></circle>`).join("")}</g>`;
    // stray holographic fragments drifting up, and scanlines over the whole chamber
    for(let k=0;k<18;k++){const x=+rn(-200,500),d=rn(4,8),b=rn(0,8);sc+=`<rect x="${x}" y="260" width="3" height="3" fill="${k%2?"#78F0FF":"#FF4AC8"}"><animate attributeName="y" values="260;-110" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></rect>`}
    let sl="";for(let y=-110;y<690;y+=6)sl+=`M-220 ${y} H520 `;sc+=`<path d="${sl}" stroke="#000" stroke-width="2" opacity=".18"/>`;
    back=sc+back;}
    // a synthetic floor grid receding into the dark
    let grid="";for(let k=-8;k<=8;k++)grid+=`M${150+k*14} 232 L${150+k*70} 300 `;for(let k=0;k<5;k++){const y=232+k*k*3.4;grid+=`M-200 ${F(y)} L500 ${F(y)} `}
    back+=`<path d="${grid}" stroke="#78F0FF" stroke-width=".8" fill="none" opacity=".35"/>`;
    // the projector and its cone of light
    back+=`<polygon points="120,236 180,236 300,-90 0,-90" fill="url(#plc${N})" filter="url(#plb${N})"><animate attributeName="opacity" values=".7;1;.8;1;.7" dur="1.7s" repeatCount="indefinite"/></polygon>
      <ellipse cx="150" cy="238" rx="44" ry="7" fill="#1A1F2E" stroke="#78F0FF" stroke-width="1.4"/><ellipse cx="150" cy="236" rx="30" ry="4" fill="#78F0FF" opacity=".7"><animate attributeName="opacity" values=".4;.9;.4" dur="1.2s" repeatCount="indefinite"/></ellipse>`;
    // the phoenix: a triangulated wireframe, wings beating, tail streaming down like flame
    const wing=dir=>{const P=[[0,0],[dir*40,-30],[dir*84,-62],[dir*126,-70],[dir*150,-52],[dir*112,-40],[dir*140,-26],[dir*98,-16],[dir*120,4],[dir*72,-2],[dir*40,14]];
      let d="";for(let k=1;k<P.length-1;k++)d+=`M${P[0][0]} ${P[0][1]} L${P[k][0]} ${P[k][1]} L${P[k+1][0]} ${P[k+1][1]} `;
      d+=`M${P.slice(1).map(p=>p.join(" ")).join(" L")}`;
      return d};
    const flap=dir=>`<g><path d="${wing(dir)}" stroke="url(#plw${N})" stroke-width="1.8" fill="rgba(176,122,255,.16)" stroke-linejoin="round"/>
      <path d="${wing(dir)}" stroke="#FF3A6A" stroke-width=".8" fill="none" opacity=".45" transform="translate(-1.6 0)"/><path d="${wing(dir)}" stroke="#3AF0FF" stroke-width=".8" fill="none" opacity=".45" transform="translate(1.6 0)"/>
      <animateTransform attributeName="transform" type="scale" values="1 1;1 .35;1 1" keyTimes="0;.5;1" dur="1.6s" calcMode="spline" keySplines=".5 0 .5 1;.5 0 .5 1" repeatCount="indefinite"/></g>`;
    const tail=[-18,-8,4,14,22].map((x,k)=>{const t=d=>`M${x*.3} 18 C${x} 50 ${x+d} 80 ${x*1.6+d} ${110+k*6}`;return `<path d="${t(0)}" stroke="url(#plw${N})" stroke-width="1.3" fill="none"><animate attributeName="d" values="${t(0)};${t(10)};${t(-8)};${t(0)}" dur="${(1.4+k*.2).toFixed(1)}s" repeatCount="indefinite"/></path>`}).join("");
    const body=`<path d="M0 -40 L6 -26 L4 -8 L0 18 L-4 -8 L-6 -26 Z M0 -40 L-10 -48 L0 -54 L8 -46 Z M0 -54 L-4 -70 M0 -54 L6 -72 M0 -54 L12 -64" stroke="url(#plw${N})" stroke-width="1.3" fill="rgba(120,240,255,.1)"/><circle cx="-3" cy="-48" r="1.4" fill="#FFFFFF"/>`;
    const bird=`<g transform="translate(150 50) scale(1.35)">${flap(-1)}${flap(1)}${body}${tail}</g>`;
    // every few seconds it bursts into pixels and gathers itself back together
    let px="";for(let k=0;k<40;k++){const an=R()*Math.PI*2,r=+rn(40,150),sx=150+(R()-.5)*140,sy=40+R()*70;px+=`<rect x="-1.5" y="-1.5" width="3" height="3" fill="${k%2?"#78F0FF":"#FF4AC8"}" opacity="0"><animate attributeName="opacity" values="0;0;1;0;0" keyTimes="0;.78;.82;.97;1" dur="7s" repeatCount="indefinite"/><animateMotion dur="7s" repeatCount="indefinite" keyTimes="0;.78;.9;1" keyPoints="0;0;1;0" calcMode="linear" path="M${F(sx)} ${F(sy)} L${F(sx+Math.cos(an)*r)} ${F(sy+Math.sin(an)*r)}"/></rect>`}
    back+=`<g filter="url(#plg${N})"><g>${bird}<animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;.78;.8;.96;1" dur="7s" repeatCount="indefinite"/>
      <animateTransform attributeName="transform" type="translate" values="0 0;0 0;4 0;-3 0;0 0;0 0" keyTimes="0;.3;.31;.32;.33;1" dur="7s" repeatCount="indefinite"/></g>${px}</g>`;
    // inside the glass: the lattice lines of the projection, a scanline sweeping, a flicker
    let g="";for(let i=0;i<8;i++){g+=`<path d="M${117+i*9} 46 l40 178 M${183-i*9} 46 l-40 178" stroke="#78F0FF" stroke-width=".8"/>`}
    f+=`<defs><clipPath id="tfxv${UID}"><rect x="117" y="46" width="66" height="178"/></clipPath></defs><g clip-path="url(#tfxv${UID})" opacity=".45">${g}<animate attributeName="opacity" values=".45;.2;.45;.05;.45" dur="1.3s" repeatCount="indefinite"/></g>`;
    f+=`<rect x="110" y="40" width="80" height="3" fill="#B8FAFF" opacity=".6"><animate attributeName="y" values="40;225" dur="1.8s" repeatCount="indefinite"/></rect>`;
    // glitch slices tearing across the whole image now and then
    for(let k=0;k<3;k++){const y=+rn(40,200),h=+rn(3,8);f+=`<rect x="60" y="${y}" width="180" height="${h}" fill="${k%2?"#FF4AC8":"#78F0FF"}" opacity="0"><animate attributeName="opacity" values="0;0;.35;0;0" keyTimes="0;.5;.51;.54;1" dur="${(3+k*1.3).toFixed(1)}s" repeatCount="indefinite"/><animate attributeName="x" values="60;60;${60+(k%2?-14:14)};60;60" keyTimes="0;.5;.51;.54;1" dur="${(3+k*1.3).toFixed(1)}s" repeatCount="indefinite"/></rect>`}
    host.classList.add("holo")}
  if(a.name==="Founder's Folly"){  // a relic the Institute sealed away: held in a riveted brass reliquary above a plinth, lit from within by a slow heartbeat
    const N=UID,hi=shade(a.color,.7);
    back+=`<defs>
      <radialGradient id="ffr${N}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#EAF6FF" stop-opacity=".9"/><stop offset=".35" stop-color="#9FD4FF" stop-opacity=".45"/><stop offset="1" stop-color="#9FD4FF" stop-opacity="0"/></radialGradient>
      <linearGradient id="ffray${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#BFE4FF" stop-opacity="0"/><stop offset=".5" stop-color="#BFE4FF" stop-opacity=".55"/><stop offset="1" stop-color="#BFE4FF" stop-opacity="0"/></linearGradient>
      <filter id="ffb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="3"/></filter>
      <path id="ffc${N}" d="M150 36 a92 92 0 1 1 -0.1 0"/><radialGradient id="ffrg${N}" gradientUnits="userSpaceOnUse" cx="150" cy="128" r="420"><stop offset="0" stop-color="#EAF6FF" stop-opacity=".45"/><stop offset=".45" stop-color="#BFE4FF" stop-opacity=".22"/><stop offset="1" stop-color="#BFE4FF" stop-opacity="0"/></radialGradient></defs>`;
    // god-rays turning slowly behind everything
    svg.style.overflow="visible";let rays="";for(let k=0;k<12;k++)rays+=`<polygon points="150,128 ${(150+420*Math.cos((k*30-4)*Math.PI/180)).toFixed(1)},${(128+420*Math.sin((k*30-4)*Math.PI/180)).toFixed(1)} ${(150+420*Math.cos((k*30+4)*Math.PI/180)).toFixed(1)},${(128+420*Math.sin((k*30+4)*Math.PI/180)).toFixed(1)}" fill="url(#ffrg${N})" opacity="${k%2?.55:.9}"/>`;
    back+=`<g filter="url(#ffb${N})">${rays}<animateTransform attributeName="transform" type="rotate" from="0 150 128" to="360 150 128" dur="40s" repeatCount="indefinite"/></g>`;
    // the Institute's seal, turning the other way
    back+=`<g opacity=".55"><circle cx="150" cy="128" r="100" fill="none" stroke="#C9A64A" stroke-width="1.5"/><circle cx="150" cy="128" r="84" fill="none" stroke="#C9A64A" stroke-width=".8" stroke-dasharray="2 4"/>
      <text font-family="Press Start 2P, monospace" font-size="7" fill="#E9D38A" letter-spacing="2"><textPath href="#ffc${N}">QVILLMOOR INSTITVTE · SEALED BY ORDER OF THE FOVNDER · DO NOT OPEN ·</textPath></text>
      <animateTransform attributeName="transform" type="rotate" from="360 150 128" to="0 150 128" dur="60s" repeatCount="indefinite"/></g>`;
    // the heartbeat halo
    back+=`<circle cx="150" cy="140" r="70" fill="url(#ffr${N})"><animate attributeName="r" values="62;78;66;74;62" keyTimes="0;.12;.24;.36;1" dur="2.4s" repeatCount="indefinite"/><animate attributeName="opacity" values=".55;1;.7;.9;.55" keyTimes="0;.12;.24;.36;1" dur="2.4s" repeatCount="indefinite"/></circle>`;
    // plinth with a lit ring the vial hovers over
    back+=`<path d="M96 240 L106 230 H194 L204 240 L204 250 L196 256 V690 H104 V256 L96 250 Z" fill="#2A2F3E" stroke="#C9A64A" stroke-width="1"/><ellipse cx="150" cy="230" rx="48" ry="6" fill="#39415A" stroke="#C9A64A" stroke-width="1.2"/>
      <ellipse cx="150" cy="229" rx="40" ry="4.5" fill="none" stroke="#BFE4FF" stroke-width="2" filter="url(#ffb${N})"><animate attributeName="opacity" values=".4;1;.4" dur="2.4s" repeatCount="indefinite"/></ellipse>`;
    // inside the glass: the powder hangs in a slow vortex, lit by the heartbeat
    let vort="";for(let k=0;k<26;k++){const rx=+rn(6,26),ry=+rn(3,9),cy=+rn(120,205),d=rn(2.2,5),b=rn(0,5),r0=rn(.7,1.8);
      vort+=`<circle r="${r0}" fill="${k%3?hi:a.color}" opacity=".85"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${150-rx} ${cy} a${rx} ${ry} 0 1 0 ${2*rx} 0 a${rx} ${ry} 0 1 0 ${-2*rx} 0"/></circle>`}
    f+=`<g clip-path="url(#ffv${N})">${vort}<rect x="117" y="46" width="66" height="178" fill="#BFE4FF" opacity=".0" style="mix-blend-mode:screen"><animate attributeName="opacity" values="0;.28;.08;.22;0" keyTimes="0;.12;.24;.36;1" dur="2.4s" repeatCount="indefinite"/></rect>
      <rect x="100" y="40" width="30" height="190" fill="#FFFFFF" opacity=".0" transform="skewX(-20)"><animate attributeName="x" values="60;250;250" keyTimes="0;.35;1" dur="4.5s" repeatCount="indefinite"/><animate attributeName="opacity" values=".35;.35;0" keyTimes="0;.35;.36" dur="4.5s" repeatCount="indefinite"/></rect></g>
      <defs><clipPath id="ffv${N}"><path d="M117 46 L183 46 L183 196 Q183 223 150 223 Q117 223 117 196 Z"/></clipPath>
      <linearGradient id="ffbr${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#6A4A12"/><stop offset=".4" stop-color="#F2D98A"/><stop offset=".6" stop-color="#C9A64A"/><stop offset="1" stop-color="#5A3E0E"/></linearGradient></defs>`;
    // the brass reliquary: two uprights, three bands, rivets, a cap over the cork
    const band=y=>`<rect x="106" y="${y}" width="88" height="7" rx="3" fill="url(#ffbr${N})" stroke="#3A2A08" stroke-width=".8"/>`+[112,130,150,170,188].map(x=>`<circle cx="${x}" cy="${y+3.5}" r="1.4" fill="#FFF1C0" stroke="#5A3E0E" stroke-width=".5"/>`).join("");
    f+=`<rect x="104" y="36" width="7" height="194" rx="3" fill="url(#ffbr${N})" stroke="#3A2A08" stroke-width=".8"/><rect x="189" y="36" width="7" height="194" rx="3" fill="url(#ffbr${N})" stroke="#3A2A08" stroke-width=".8"/>`+band(36)+band(128)+band(216);
    f+=`<path d="M114 16 Q150 3 186 16 L186 22 L114 22 Z" fill="url(#ffbr${N})" stroke="#3A2A08" stroke-width=".8"/><circle cx="150" cy="9" r="3.5" fill="url(#ffbr${N})" stroke="#3A2A08" stroke-width=".8"/>`;
    // wax seal on the cap, stamped with the Institute's Q
    f+=`<g transform="translate(150 24)"><path d="M-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M-3 8 q1 6 -1 9 q3 -2 3 -7 M4 7 q2 5 1 7" fill="#A8161E" stroke="#6A0A10" stroke-width=".8"/><text x="0" y="3.5" text-anchor="middle" font-family="Georgia, serif" font-weight="700" font-size="11" fill="#E8B0A8">Q</text></g>`;
    // redacted pages orbiting the reliquary
    for(let k=0;k<5;k++){const d=(9+k*1.3).toFixed(1),b=(k*2.1).toFixed(1);
      f+=`<g opacity=".9"><g><rect x="-6" y="-7.5" width="12" height="15" fill="#F4F1E6" stroke="#8C8472" stroke-width=".5"/><rect x="-4.5" y="-4" width="9" height="2" fill="#111"/><rect x="-4.5" y="0" width="6" height="2" fill="#111"/><rect x="-4.5" y="4" width="8" height="1.2" fill="#8C8472"/><animateTransform attributeName="transform" type="rotate" values="-15;15;-15" dur="${(2+k*.4).toFixed(1)}s" repeatCount="indefinite"/></g>
        <animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${150-78} 130 a78 26 -12 1 0 156 0 a78 26 -12 1 0 -156 0"/></g>`}
    // sparks rising off the plinth ring
    for(let k=0;k<8;k++){const x=+rn(112,188),d=rn(1.8,3.2),b=rn(0,3);f+=`<circle cx="${x}" cy="228" r="1.1" fill="#DFF2FF" opacity="0"><animate attributeName="cy" values="228;${rn(150,190)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}}
  /* ---- the containers themselves: each threat's vessel has to look dangerous on its own, with no scene behind it (these parts also show on Alloydex cards) ---- */
  {const N=UID,F=v=>(+v).toFixed(1);
  if(a.name==="Cinder Mercury"){   // the stopper frozen over: a thick rime cap with frost feathers and icicles, so the ice is part of the vessel, not just the scene
    let fr="";for(let k=0;k<7;k++){const x=+rn(122,178),y=+rn(20,38),l=+rn(5,9),an=rn(-40,40);fr+=`<g transform="translate(${x} ${y}) rotate(${an})"><path d="M0 0 V${-l} M0 ${F(-l*.4)} l-3 -3 M0 ${F(-l*.4)} l3 -3 M0 ${F(-l*.75)} l-2 -2 M0 ${F(-l*.75)} l2 -2" stroke="#FFFFFF" stroke-width=".8" fill="none" opacity=".85"/></g>`}
    f+=`<path d="M114 20 Q116 8 150 8 Q184 8 186 20 L186 26 Q170 30 150 27 Q130 30 114 26 Z" fill="#E8F8FF" stroke="#A8DDF4" stroke-width="1"/><path d="M118 44 L118 22 L182 22 L182 44 Z" fill="#DFF6FF" opacity=".55"/>${fr}
      <path d="M112 24 L116 34 L119 26 L123 38 L126 27 L131 33 L134 26 M166 26 L170 35 L173 27 L177 40 L180 27 L184 33 L188 24" stroke="#DFF6FF" stroke-width="2.2" fill="none" stroke-linejoin="round"/>
      ${[[124,11],[146,10],[172,12]].map(([x,y],k)=>`<path d="M${x} ${y-3} l1 3 3 1 -3 1 -1 3 -1 -3 -3 -1 3 -1 z" fill="#FFFFFF"><animate attributeName="opacity" values="0;1;0" dur="${(1.6+k*.5).toFixed(1)}s" repeatCount="indefinite"/></path>`).join("")}`;}
  if(a.name==="Drowned Fire"){   // a salvaged deep-sea pressure housing: iron straps, a bolted collar, a hatch wheel that keeps twitching, a gauge pinned in the red, the seal failing
    f+=`<defs><linearGradient id="dcir${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7A8A94"/><stop offset=".45" stop-color="#34414A"/><stop offset="1" stop-color="#141A1F"/></linearGradient>
      <linearGradient id="dcst${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#141A1F"/><stop offset=".45" stop-color="#6A7A84"/><stop offset="1" stop-color="#141A1F"/></linearGradient>
      <radialGradient id="dcgf${N}" cx=".45" cy=".4" r=".7"><stop offset="0" stop-color="#FFFDF2"/><stop offset="1" stop-color="#D8D0B4"/></radialGradient></defs>`;
    // condensation beading and running down the outside of the glass
    for(let k=0;k<16;k++){const x=+rn(118,182),y=+rn(56,190),d=rn(3,7),b=rn(0,7);f+=`<circle cx="${x}" cy="${y}" r="${rn(.8,1.9)}" fill="rgba(225,242,255,.45)" stroke="#FFFFFF" stroke-width=".35"><animate attributeName="cy" values="${y};${F(y+34)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.15;.8;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    // kelp that came up with it, still clinging to the glass and swaying
    const kelp=(x0,s,dl)=>{const d=k=>`M${x0} 226 C${x0+s*(6+k)} 196 ${x0-s*(4-k)} 170 ${x0+s*(8+k)} 146 C${x0+s*(14+k)} 128 ${x0+s*(4-k)} 114 ${x0+s*(10+k)} 96`;return `<path d="${d(0)}" stroke="#3A5A2A" stroke-width="3.2" fill="none" stroke-linecap="round" opacity=".9"><animate attributeName="d" values="${d(0)};${d(4)};${d(-2)};${d(0)}" dur="4.${dl}s" repeatCount="indefinite"/></path>`};
    f+=kelp(120,1,2)+kelp(181,-1,7);
    // iron straps down both sides and a cradle under the foot
    f+=`<rect x="108" y="44" width="7" height="154" rx="2" fill="url(#dcst${N})" stroke="#0A0E11" stroke-width=".8"/><rect x="185" y="44" width="7" height="154" rx="2" fill="url(#dcst${N})" stroke="#0A0E11" stroke-width=".8"/>
      <path d="M111.5 196 Q111.5 232 150 232 Q188.5 232 188.5 196" stroke="#2A343B" stroke-width="7" fill="none"/><path d="M111.5 196 Q111.5 232 150 232 Q188.5 232 188.5 196" stroke="#7A8A94" stroke-width="1.2" fill="none" transform="translate(0 -2)" opacity=".7"/>
      <rect x="104" y="128" width="92" height="10" rx="2" fill="url(#dcir${N})" stroke="#0A0E11" stroke-width=".8"/>`;
    [110,124,138,162,176,190].forEach(x=>f+=`<circle cx="${x}" cy="133" r="2" fill="#9AAAB4" stroke="#1A2024" stroke-width=".6"/>`);
    // rust bleeding from the bolts
    [[112,138,14],[176,138,10],[190,50,18],[110,50,12]].forEach(([x,y,l])=>f+=`<path d="M${x} ${y} q1 ${l/2} -1 ${l}" stroke="#8A4A22" stroke-width="2.2" fill="none" opacity=".7" stroke-linecap="round"/>`);
    // the heavy bolted collar where the rim should be
    f+=`<rect x="98" y="30" width="104" height="20" rx="4" fill="url(#dcir${N})" stroke="#0A0E11" stroke-width="1.2"/><path d="M101 33 H199" stroke="#B8C6CE" stroke-width="1" opacity=".6"/>`;
    [104,117,130,143,157,170,183,196].forEach(x=>f+=`<polygon points="${x-3},40 ${x-1.5},37.4 ${x+1.5},37.4 ${x+3},40 ${x+1.5},42.6 ${x-1.5},42.6" fill="#AAB8C0" stroke="#1A2024" stroke-width=".6"/>`);
    // barnacles crusted on the collar and straps
    [[100,48,3.4],[108,52,2.4],[196,30,3],[188,112,2.6],[112,170,3.2],[190,200,2.4]].forEach(([x,y,r])=>f+=`<path d="M${x-r} ${y} L${x-r*.4} ${y-r*1.3} L${x+r*.4} ${y-r*1.3} L${x+r} ${y} Z" fill="#CFC6B0" stroke="#6A6250" stroke-width=".6"/><ellipse cx="${x}" cy="${y-r*1.3}" rx="${r*.4}" ry="${r*.2}" fill="#3A3428"/>`);
    // an iron dome over the stopper with a hatch wheel on top, jerking as something inside pushes on it
    f+=`<path d="M106 30 Q106 8 150 6 Q194 8 194 30 Z" fill="url(#dcir${N})" stroke="#0A0E11" stroke-width="1.2"/><path d="M114 22 Q150 8 186 22" stroke="#B8C6CE" stroke-width="1" fill="none" opacity=".5"/>
      <g><g transform="translate(150 2)"><circle r="13" fill="none" stroke="#2A343B" stroke-width="4"/><circle r="13" fill="none" stroke="#9AAAB4" stroke-width="1" opacity=".8"/>
        <path d="M-13 0 H13 M0 -13 V13 M-9 -9 L9 9 M-9 9 L9 -9" stroke="#2A343B" stroke-width="2.4"/><circle r="3.4" fill="#9AAAB4" stroke="#1A2024"/></g>
        <animateTransform attributeName="transform" type="rotate" values="0 150 2;0 150 2;14 150 2;-6 150 2;9 150 2;0 150 2;0 150 2" keyTimes="0;.5;.56;.62;.68;.74;1" dur="3.4s" repeatCount="indefinite"/></g>`;
    // a pressure gauge on a pipe, needle shaking hard in the red
    f+=`<path d="M200 40 H212 Q220 40 220 48 V70" stroke="#2A343B" stroke-width="6" fill="none"/><path d="M200 38.6 H212 Q218.6 38.6 218.6 48 V70" stroke="#9AAAB4" stroke-width="1.2" fill="none" opacity=".6"/>
      <rect x="199" y="33" width="6" height="14" rx="1.5" fill="#4A5860" stroke="#0A0E11" stroke-width=".8"/><rect x="214" y="62" width="12" height="6" rx="1.5" fill="#4A5860" stroke="#0A0E11" stroke-width=".8"/><circle cx="220" cy="54" r="3.2" fill="#6A7A84" stroke="#0A0E11" stroke-width=".7"/><path d="M217.6 54 H222.4" stroke="#0A0E11" stroke-width="1"/>
      <g transform="translate(220 86)"><circle r="17" fill="#2A343B" stroke="#0A0E11"/><circle r="14" fill="url(#dcgf${N})"/>
        <path d="M${F(14*Math.cos(-.35))} ${F(14*Math.sin(-.35))} A14 14 0 0 1 ${F(14*Math.cos(.9))} ${F(14*Math.sin(.9))} L0 0 Z" fill="#D8231E" opacity=".85"/>
        ${[-3.6,-3.1,-2.6,-2.1,-1.6,-1.1,-.6,-.1,.4,.9].map(t=>`<path d="M${F(11*Math.cos(t))} ${F(11*Math.sin(t))} L${F(14*Math.cos(t))} ${F(14*Math.sin(t))}" stroke="#1A2024" stroke-width=".8"/>`).join("")}
        <g><path d="M-2 0 L0 -12 L2 0 Z" fill="#111" transform="rotate(90)"/><animateTransform attributeName="transform" type="rotate" values="96;112;101;118;98;110;96" dur=".9s" repeatCount="indefinite"/></g><circle r="2.4" fill="#2A343B"/></g>`;
    // the seal under the collar failing: streams of bubbles escaping
    for(let k=0;k<10;k++){const x=k%2?+rn(96,104):+rn(196,204),d=rn(1,1.8),b=rn(0,1.8);f+=`<circle cx="${x}" cy="40" r="${rn(1,2.4)}" fill="none" stroke="#DDF2FF" stroke-width=".8" opacity="0"><animate attributeName="cy" values="40;-26" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="cx" values="${x};${F(x+(k%2?-8:8))}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}}
  if(a.name==="Everburn"){   // a vessel built for a fire that never goes out: set into a firebrick hearth, the glass cooked into rainbow temper bands and sagging where it's hottest, a ceramic chimney cap with a spark arrestor, a heat strip scorched black
    f+=`<defs><linearGradient id="ecgl${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FFE27A"/><stop offset=".25" stop-color="#FF6A10"/><stop offset=".6" stop-color="#C02A00" stop-opacity=".6"/><stop offset="1" stop-color="#C02A00" stop-opacity="0"/></linearGradient>
      <linearGradient id="ect${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6A8CFF" stop-opacity="0"/><stop offset=".15" stop-color="#6A8CFF" stop-opacity=".35"/><stop offset=".35" stop-color="#B06AE0" stop-opacity=".35"/><stop offset=".55" stop-color="#E0A040" stop-opacity=".4"/><stop offset=".8" stop-color="#FF7A2A" stop-opacity=".35"/><stop offset="1" stop-color="#FF7A2A" stop-opacity="0"/></linearGradient>
      <linearGradient id="ecc${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8A8278"/><stop offset=".35" stop-color="#E8E2D6"/><stop offset=".7" stop-color="#B8B0A2"/><stop offset="1" stop-color="#6A6258"/></linearGradient>
      <linearGradient id="ecbk${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C8683A"/><stop offset="1" stop-color="#7A3418"/></linearGradient>
      <filter id="ecb${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2.2"/></filter>
      <filter id="echz${N}" x="-40%" y="-40%" width="180%" height="180%"><feTurbulence type="fractalNoise" baseFrequency=".04 .12" numOctaves="2" seed="5" result="n"><animate attributeName="baseFrequency" values=".04 .12;.05 .16;.04 .12" dur="1.6s" repeatCount="indefinite"/></feTurbulence><feDisplacementMap in="SourceGraphic" in2="n" scale="6"/></filter></defs>`;
    // the glass cooked into temper bands down its walls
    f+=`<path d="M115 50 V196 M185 50 V196" stroke="url(#ect${N})" stroke-width="5" fill="none"/>`;
    // the lower glass sagging outward and glowing where the pile burns hottest
    const sag=k=>`M114 140 Q${F(110-k)} 186 ${F(116-k*.5)} 208 Q130 ${F(229+k*.4)} 150 ${F(229+k*.4)} Q170 ${F(229+k*.4)} ${F(184+k*.5)} 208 Q${F(190+k)} 186 186 140`;
    f+=`<path d="${sag(0)}" stroke="url(#ecgl${N})" stroke-width="6" fill="none" filter="url(#ecb${N})"><animate attributeName="d" values="${sag(0)};${sag(2)};${sag(0)}" dur="3s" repeatCount="indefinite"/><animate attributeName="opacity" values=".7;1;.7" dur="1.3s" repeatCount="indefinite"/></path>
      <path d="${sag(0)}" stroke="url(#ecgl${N})" stroke-width="2" fill="none"><animate attributeName="d" values="${sag(0)};${sag(2)};${sag(0)}" dur="3s" repeatCount="indefinite"/></path>`;
    // a heat-indicator strip stuck to the glass, every square scorched black but the last, which is still glowing
    f+=`<g transform="translate(174 62)"><rect x="-1" y="-1" width="9" height="62" rx="1.5" fill="#F4EEDC" stroke="#6A5A40" stroke-width=".6"/>${[0,1,2,3,4,5].map(k=>`<rect x="1" y="${1+k*10}" width="5" height="7" fill="${k<5?"#1A1410":"#FF5A10"}">${k===5?`<animate attributeName="opacity" values=".5;1;.5" dur=".8s" repeatCount="indefinite"/>`:""}</rect>`).join("")}<path d="M-1 20 Q4 24 8 18" stroke="#3A2A1A" stroke-width="1" fill="none"/></g>`;
    // the firebrick hearth it stands on: two courses of brick, mortar lines glowing where the heat leaks through
    let br="";[[227,[98,120,142,164,186]],[241,[87,109,131,153,175,197]]].forEach(([y,xs],r)=>xs.forEach(x=>{br+=`<rect x="${x}" y="${y}" width="21" height="13" rx="1.5" fill="url(#ecbk${N})" stroke="#3A1608" stroke-width=".8"/><path d="M${x+2} ${y+2} H${x+19}" stroke="#E89A6A" stroke-width=".8" opacity=".6"/>`}));
    f+=`<path d="M84 254 L216 254 L216 259 L84 259 Z" fill="#2A1208"/>${br}
      <g stroke="#FF8A2A" stroke-width="1.2" fill="none" filter="url(#ecb${N})"><path d="M98 240 H208 M87 254 H218 M119 227 V240 M141 227 V240 M163 227 V240 M185 227 V240 M108 241 V254 M130 241 V254 M152 241 V254 M174 241 V254 M196 241 V254"/><animate attributeName="opacity" values=".35;.9;.45;.8;.35" dur="1.4s" repeatCount="indefinite"/></g>
      <path d="M116 228 Q150 232 184 228" stroke="#FFB040" stroke-width="3" fill="none" filter="url(#ecb${N})"><animate attributeName="opacity" values=".5;1;.5" dur="1.1s" repeatCount="indefinite"/></path>`;
    // a ceramic chimney cap in place of the stopper, with a mesh spark arrestor on its stack
    f+=`<path d="M107 46 L107 30 Q107 11 150 9 Q193 11 193 30 L193 46 Z" fill="url(#ecc${N})" stroke="#4A423A" stroke-width="1.2"/><path d="M114 44 H186" stroke="#FF6A10" stroke-width="1.6"><animate attributeName="opacity" values=".4;1;.4" dur="1.2s" repeatCount="indefinite"/></path>
      <path d="M116 24 Q150 14 184 24" stroke="#FFFFFF" stroke-width="1.2" fill="none" opacity=".6"/>
      <rect x="138" y="-2" width="24" height="13" fill="url(#ecc${N})" stroke="#4A423A" stroke-width="1.2"/><rect x="135" y="-6" width="30" height="5" rx="1.5" fill="#6A6258" stroke="#3A342E"/>
      <g stroke="#2A2420" stroke-width=".7"><path d="M137 -6 V-15 M142 -6 V-15 M147 -6 V-15 M152 -6 V-15 M157 -6 V-15 M162 -6 V-15 M137 -10 H163 M137 -15 H163"/></g><path d="M138 -15 H162 V-6 H138 Z" fill="#FF8A2A" opacity=".25"><animate attributeName="opacity" values=".1;.4;.1" dur=".9s" repeatCount="indefinite"/></path>`;
    // heat shimmering off the stack, and sparks the mesh can't quite catch
    f+=`<g filter="url(#echz${N})"><path d="M140 -16 Q146 -36 140 -56 M150 -16 Q156 -40 150 -62 M160 -16 Q166 -36 160 -56" stroke="#FFD8A0" stroke-width="3" fill="none" opacity=".25"/></g>`;
    for(let k=0;k<7;k++){const d=rn(.9,1.6),b=rn(0,1.6),dx=F((R()-.5)*40),h=F(16+R()*22);f+=`<circle r="${rn(.8,1.4)}" fill="${k%3?"#FFB040":"#FFF0B0"}" opacity="0"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M150 -15 q${F(dx/2)} -${h} ${dx} -${F(h*.4)}"/><animate attributeName="opacity" values="1;1;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}}
  if(a.name==="The Unmaker"){   // a vessel losing the fight: steel containment bands with bites taken out of them, one snapped clean through, a riveted patch over an old breach, warning tape peeling, a clamp lid missing a bolt
    f+=`<defs><linearGradient id="ucst${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#C8D2DC"/><stop offset=".5" stop-color="#6A7482"/><stop offset="1" stop-color="#2E343C"/></linearGradient>
      <pattern id="uchz${N}" width="10" height="10" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="5" height="10" fill="#F2C81E"/><rect x="5" width="5" height="10" fill="#17191C"/></pattern></defs>`;
    const bite=(cx,cy,r)=>{let d="";for(let k=0;k<9;k++){const an=k/9*6.283,rr=r*(.6+R()*.6);d+=(k?"L":"M")+F(cx+Math.cos(an)*rr)+" "+F(cy+Math.sin(an)*rr*.7)}return `<path d="${d}Z" fill="#0B0C0F" stroke="#E6ECF2" stroke-width=".6"/>`};
    // upper band, bitten through in places
    f+=`<rect x="106" y="90" width="88" height="11" rx="2" fill="url(#ucst${N})" stroke="#15181D" stroke-width=".8"/>`+bite(128,95.5,6)+bite(171,96,5)+[110,150,190].map(x=>`<circle cx="${x}" cy="95.5" r="1.8" fill="#DDE6F0" stroke="#2E343C" stroke-width=".5"/>`).join("");
    // lower band snapped clean through, the two ends sprung apart
    f+=`<g transform="rotate(-9 108 172)"><path d="M106 166 H143 L146 169 L142 172 L145 177 H106 Z" fill="url(#ucst${N})" stroke="#15181D" stroke-width=".8"/><circle cx="112" cy="171.5" r="1.8" fill="#DDE6F0" stroke="#2E343C" stroke-width=".5"/></g>
      <g transform="rotate(11 194 172)"><path d="M194 166 H158 L155 170 L159 173 L156 177 H194 Z" fill="url(#ucst${N})" stroke="#15181D" stroke-width=".8"/><circle cx="188" cy="171.5" r="1.8" fill="#DDE6F0" stroke="#2E343C" stroke-width=".5"/></g>`;
    // a riveted patch over an older breach, already being eaten at the edges
    f+=`<g transform="rotate(8 170 132)"><path d="M158 122 L182 120 L184 142 L160 145 Z" fill="url(#ucst${N})" stroke="#15181D" stroke-width=".8"/>${[[161,125],[180,123],[181,140],[163,142]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.4" fill="#DDE6F0"/>`).join("")}${bite(182,132,4)}</g>`;
    // warning tape across the glass, peeling off at one end
    f+=`<g transform="rotate(-16 150 150)"><rect x="104" y="146" width="82" height="11" fill="url(#uchz${N})" stroke="#17191C" stroke-width=".5"/><rect x="118" y="147.6" width="52" height="7.8" fill="#F2C81E"/>
      <text x="144" y="154" text-anchor="middle" font-family="Press Start 2P, monospace" font-size="5" fill="#17191C">DO NOT OPEN</text>
      <path d="M186 146 Q198 150 196 162 L190 160 Q191 152 186 157 Z" fill="#C8A014" stroke="#17191C" stroke-width=".5"><animate attributeName="d" values="M186 146 Q198 150 196 162 L190 160 Q191 152 186 157 Z;M186 146 Q200 146 200 158 L194 158 Q193 150 186 157 Z;M186 146 Q198 150 196 162 L190 160 Q191 152 186 157 Z" dur="3s" repeatCount="indefinite"/></path></g>`;
    // a steel clamp lid over the stopper, one of its four bolts gone and another backing itself out
    f+=`<path d="M110 14 L190 14 L190 30 L110 30 Z" fill="url(#ucst${N})" stroke="#15181D" stroke-width="1"/><path d="M112 17 H188" stroke="#FFFFFF" stroke-width=".8" opacity=".6"/>
      <circle cx="120" cy="22" r="3" fill="#DDE6F0" stroke="#2E343C"/><circle cx="180" cy="22" r="3" fill="#DDE6F0" stroke="#2E343C"/><circle cx="160" cy="22" r="2.6" fill="#0B0C0F" stroke="#E6ECF2" stroke-width=".6"/>
      <g><rect x="137" y="12" width="6" height="12" fill="#DDE6F0" stroke="#2E343C" stroke-width=".6"/><rect x="135" y="10" width="10" height="3" fill="#AAB4C0"/><animateTransform attributeName="transform" type="translate" values="0 0;0 -4;0 -2;0 -5;0 0" dur="2.6s" repeatCount="indefinite"/></g>`;}
  if(a.name==="Widow's Vein"){   // the widow has it: a glossy cap marked with her hourglass, eight legs clamped round the glass, the vial half-cocooned in silk, venom beading on her fangs
    f+=`<defs><radialGradient id="wcap${N}" cx=".38" cy=".3" r=".75"><stop offset="0" stop-color="#4A4E44"/><stop offset=".35" stop-color="#15170F"/><stop offset="1" stop-color="#030402"/></radialGradient>
      <filter id="wcg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
    // silk cocoon wound round the glass, thickest round the middle
    let silk="";for(let k=0;k<26;k++){const y=100+(R()+R()+R()-1.5)*70,dy=(R()-.5)*26,sag=(R()-.5)*14;silk+=`<path d="M110 ${F(y)} Q150 ${F(y+sag+dy/2)} 190 ${F(y+dy)}" stroke-width="${rn(.5,1.6)}" opacity="${rn(.35,.85)}"/>`}
    f+=`<g stroke="#F2F4EC" fill="none" stroke-linecap="round">${silk}</g><g stroke="#F2F4EC" fill="none" opacity=".28" stroke-width="7"><path d="M111 112 Q150 124 189 106"/><path d="M111 150 Q150 138 189 158"/><path d="M111 176 Q150 186 189 170"/></g>`;
    // eight jointed legs gripping the glass, twitching now and then
    const leg=(sx,sy,kx,ky,tx,ty,k)=>{const d=(o)=>`M${sx} ${sy} L${F(kx)} ${F(ky+o)} L${F(tx)} ${F(ty)}`;return `<path d="${d(0)}" stroke="#C8D2B8" stroke-width="5" fill="none" stroke-linejoin="round" stroke-linecap="round" opacity=".35"><animate attributeName="d" values="${d(0)};${d(0)};${d(-4)};${d(1)};${d(0)}" keyTimes="0;.6;.7;.8;1" dur="${(3.4+k*.43).toFixed(2)}s" repeatCount="indefinite"/></path><path d="${d(0)}" stroke="#050605" stroke-width="3.4" fill="none" stroke-linejoin="round" stroke-linecap="round"><animate attributeName="d" values="${d(0)};${d(0)};${d(-4)};${d(1)};${d(0)}" keyTimes="0;.6;.7;.8;1" dur="${(3.4+k*.43).toFixed(2)}s" repeatCount="indefinite"/></path><path d="M${F(kx)} ${F(ky)} L${F(tx)} ${F(ty)}" stroke="#3A3E34" stroke-width=".7" fill="none" opacity=".7"/><path d="M${F(tx)} ${F(ty)} l${sx<150?3:-3} 3" stroke="#050605" stroke-width="1.6" stroke-linecap="round"/>`};
    let legs="";[[24,50,4,70],[28,60,20,108],[32,64,42,148],[36,60,66,188]].forEach(([sy,kxo,kyo,ty],k)=>{legs+=leg(120,sy,150-kxo,kyo,112,ty,k)+leg(180,sy,150+kxo,kyo,188,ty,k+4)});
    f+=legs;
    // her body as the stopper: a glossy dome with the hourglass, a cluster of eyes, fangs over the mouth of the vial
    f+=`<path d="M108 42 Q106 4 150 2 Q194 4 192 42 Z" fill="url(#wcap${N})" stroke="#000" stroke-width="1"/><path d="M122 16 Q134 8 148 8" stroke="#8A9080" stroke-width="1.6" fill="none" opacity=".6" stroke-linecap="round"/>
      <path d="M143 12 L157 12 L150 22 L157 32 L143 32 L150 22 Z" fill="#D81E28" filter="url(#wcg${N})"><animate attributeName="opacity" values=".7;1;.7" dur="2.4s" repeatCount="indefinite"/></path>
      ${[[140,38],[146,36],[154,36],[160,38],[143,41],[157,41]].map(([x,y],k)=>`<circle cx="${x}" cy="${y}" r="${k<4?1.5:1}" fill="#FF3A3A" filter="url(#wcg${N})"><animate attributeName="opacity" values=".4;1;.4" dur="${(1.8+k*.3).toFixed(1)}s" repeatCount="indefinite"/></circle>`).join("")}
      <path d="M144 42 q-2 6 1 10 M156 42 q2 6 -1 10" stroke="#050605" stroke-width="2.4" fill="none" stroke-linecap="round"/>
      <ellipse cx="145.5" cy="53" rx="1.4" ry="2" fill="#9CE06A" filter="url(#wcg${N})"><animate attributeName="cy" values="53;53;70" keyTimes="0;.7;1" dur="2.6s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;1;0" keyTimes="0;.85;1" dur="2.6s" repeatCount="indefinite"/></ellipse>`;}
  if(a.name==="Hollow Star"){   // a vessel being pulled in on itself: gyroscope rings spinning round the void, the glass walls bent inward, fractures running out from the middle, the cap crushed in
    const CX=150,CY=136;
    f+=`<defs><linearGradient id="hcr${N}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3A2A5A"/><stop offset=".5" stop-color="#E6DAFF"/><stop offset="1" stop-color="#3A2A5A"/></linearGradient>
      <filter id="hcg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
    // the glass walls bent in toward the void
    f+=`<path d="M114 80 Q134 ${CY} 114 192" stroke="#E6DAFF" stroke-width="2.4" fill="none" opacity=".75"/><path d="M186 80 Q166 ${CY} 186 192" stroke="#E6DAFF" stroke-width="2.4" fill="none" opacity=".75"/>
      <path d="M114 80 Q134 ${CY} 114 192 L110 192 L110 80 Z M186 80 Q166 ${CY} 186 192 L190 192 L190 80 Z" fill="#05020C" opacity=".35"/>
      ${[40,48,58].map((r,k)=>`<circle cx="${CX}" cy="${CY}" r="${r}" fill="none" stroke="#C8A8FF" stroke-width=".8" stroke-dasharray="3 5" opacity=".35"><animate attributeName="r" values="${r+8};${r}" dur="${(1.6+k*.4).toFixed(1)}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.5" dur="${(1.6+k*.4).toFixed(1)}s" repeatCount="indefinite"/></circle>`).join("")}`;
    // fractures running out from the void through the glass
    for(let k=0;k<9;k++){const an=k/9*Math.PI*2+.3;let r=38,d=`M${F(CX+Math.cos(an)*r)} ${F(CY+Math.sin(an)*r)}`;for(let t=0;t<4;t++){r+=10+R()*14;const a2=an+(R()-.5)*.35;d+=` L${F(Math.max(116,Math.min(184,CX+Math.cos(a2)*r)))} ${F(CY+Math.sin(a2)*r)}`}f+=`<path d="${d}" stroke="#FFFFFF" stroke-width=".8" fill="none" opacity=".7"/>`}
    // two gyroscope rings spinning round the void, each with a beacon
    const ring=(tilt,rx,ry,dur,dir)=>`<g transform="translate(${CX} ${CY}) rotate(${tilt})"><ellipse rx="${rx}" ry="${ry}" fill="none" stroke="#1A1230" stroke-width="5"/><ellipse rx="${rx}" ry="${ry}" fill="none" stroke="url(#hcr${N})" stroke-width="2.6"><animate attributeName="ry" values="${ry};${F(ry*.25)};${ry}" dur="${dur}s" repeatCount="indefinite"/></ellipse>
      <circle r="3" fill="#FFFFFF" filter="url(#hcg${N})"><animateMotion dur="${F(dur/2)}s" repeatCount="indefinite" ${dir<0?'keyPoints="1;0" keyTimes="0;1" calcMode="linear"':""} path="M${-rx} 0 a${rx} ${ry} 0 1 0 ${2*rx} 0 a${rx} ${ry} 0 1 0 ${-2*rx} 0"/></circle></g>`;
    f+=ring(-24,58,16,3.2,1)+ring(34,52,14,2.6,-1);
    // the stopper crushed down into the neck, a steel cap buckled over it
    f+=`<path d="M112 12 L188 12 L186 22 L150 34 L114 22 Z" fill="#2A2238" stroke="#0A0612" stroke-width="1"/><path d="M114 22 L150 34 L186 22" stroke="#E6DAFF" stroke-width="1.2" fill="none" opacity=".7"/><path d="M132 16 L150 26 L168 16" stroke="#8A7AB0" stroke-width=".8" fill="none"/>`;}
  if(a.name==="Crown of Rays"){   // the rod dressed as regalia gone bad: gold bands set with sickly stones, spiked finials at both ends, runes crawling along it glowing green, thorned filigree
    f+=`<defs><linearGradient id="ccg${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF1B0"/><stop offset=".45" stop-color="#E6B83A"/><stop offset="1" stop-color="#6A4608"/></linearGradient>
      <radialGradient id="ccj${N}" cx=".35" cy=".3" r=".7"><stop offset="0" stop-color="#F0FFE8"/><stop offset=".4" stop-color="#6AE07A"/><stop offset="1" stop-color="#0E5A20"/></radialGradient>
      <filter id="ccgl${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><g transform="rotate(-20 150 120)">`;
    // thorned filigree winding the length of it
    let vine="M52 100";for(let i=0,x=52;x<246;x+=16,i++)vine+=` Q${x+8} ${i%2?146:94} ${x+16} ${i%2?100:140}`;
    f+=`<path d="${vine}" stroke="#6A4608" stroke-width="2.6" fill="none"/><path d="${vine}" stroke="#F2D06A" stroke-width="1.2" fill="none"/>`;
    for(let i=0,x=60;x<246;x+=16,i++)f+=`<path d="M${x} ${i%2?128:112} l3 ${i%2?5:-5} l3 ${i%2?-5:5}" fill="#E6B83A" stroke="#6A4608" stroke-width=".4"/>`;
    // runes etched along it, lighting up one after another
    const glyph=["M0 -6 V6 M-4 -2 L4 2","M-4 -6 L4 6 M4 -6 L-4 6","M-4 6 V-6 L4 0 L-4 0","M0 -6 L4 0 L0 6 L-4 0 Z","M-4 -6 H4 M0 -6 V6 M-4 6 H4","M-4 -2 A4 4 0 1 1 4 -2 M0 2 V7"];
    [80,98,116,184,202,220].forEach((x,k)=>f+=`<path d="${glyph[k]}" transform="translate(${x} 120)" stroke="#AFFFC0" stroke-width="1.4" fill="none" filter="url(#ccgl${N})" opacity=".2"><animate attributeName="opacity" values=".15;1;.15" dur="2.4s" begin="${(k*.4).toFixed(1)}s" repeatCount="indefinite"/></path>`);
    // three heavy gold bands, each set with a stone
    [66,150,234].forEach(x=>f+=`<rect x="${x-7}" y="90" width="14" height="60" rx="3" fill="url(#ccg${N})" stroke="#6A4608" stroke-width="1"/><path d="M${x-7} 96 H${x+7} M${x-7} 144 H${x+7}" stroke="#6A4608" stroke-width=".8"/><ellipse cx="${x}" cy="120" rx="5" ry="7" fill="url(#ccj${N})" stroke="#6A4608" stroke-width=".8" filter="url(#ccgl${N})"><animate attributeName="opacity" values=".75;1;.75" dur="3.2s" repeatCount="indefinite"/></ellipse>`);
    // spiked finials: a crown of points at each end
    const fin=(x,dir)=>{const P=[[0,-30],[dir*14,-26],[dir*6,-16],[dir*22,-9],[dir*8,-4],[dir*26,0],[dir*8,4],[dir*22,9],[dir*6,16],[dir*14,26],[0,30]];
      return `<polygon points="${P.map(([u,v])=>`${F(x+u)},${F(120+v)}`).join(" ")}" fill="url(#ccg${N})" stroke="#6A4608" stroke-width="1" stroke-linejoin="round"/>`+[[dir*14,-26],[dir*22,-9],[dir*26,0],[dir*22,9],[dir*14,26]].map(([u,v])=>`<circle cx="${F(x+u)}" cy="${F(120+v)}" r="2" fill="#F0FFE8" filter="url(#ccgl${N})"/>`).join("")+`<rect x="${dir<0?x:x-8}" y="92" width="8" height="56" rx="2" fill="url(#ccg${N})" stroke="#6A4608" stroke-width="1"/>`};
    f+=fin(40,-1)+fin(266,1)+`</g>`;}
  if(a.name==="Phoenix Lattice"){   // a vessel that is itself only light: the glass splitting into color ghosts, its edges shedding pixels, wings of light at its shoulders, projector hardware for a stopper and a foot
    const gl="M114 44 L114 196 Q114 226 150 226 Q186 226 186 196 L186 44";
    f+=`<defs><linearGradient id="pcw${N}" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#FF4AC8"/><stop offset=".5" stop-color="#B07AFF"/><stop offset="1" stop-color="#78F0FF"/></linearGradient>
      <linearGradient id="pch${N}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A3044"/><stop offset="1" stop-color="#0C0F18"/></linearGradient>
      <filter id="pcg${N}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
    // the glass splitting into ghosts
    f+=`<path d="${gl}" stroke="#FF3A9A" stroke-width="1.6" fill="none" opacity=".75"><animateTransform attributeName="transform" type="translate" values="-3 0;-3 0;-7 1;-3 0;-2 0;-3 0" keyTimes="0;.4;.42;.44;.8;1" dur="2.3s" repeatCount="indefinite"/></path>
      <path d="${gl}" stroke="#3AF0FF" stroke-width="1.6" fill="none" opacity=".75"><animateTransform attributeName="transform" type="translate" values="3 0;3 0;7 -1;3 0;2 0;3 0" keyTimes="0;.4;.42;.44;.8;1" dur="2.3s" repeatCount="indefinite"/></path>`;
    // its edges shedding pixels
    for(let k=0;k<18;k++){const side=k%2?1:-1,y=+rn(60,210),x=150+side*36,dx=side*+rn(6,22),d=rn(1.2,2.6),b=rn(0,2.6),s=rn(2,4);f+=`<rect x="${x}" y="${y}" width="${s}" height="${s}" fill="${k%3?"#78F0FF":"#FF4AC8"}"><animate attributeName="x" values="${x};${F(x+dx)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;1;0" keyTimes="0;.5;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></rect>`}
    // wings of light unfolding from the shoulders
    const wing=dir=>{const P=[[0,0],[dir*22,-18],[dir*46,-34],[dir*70,-38],[dir*82,-28],[dir*60,-20],[dir*76,-12],[dir*52,-6],[dir*64,6],[dir*38,2],[dir*20,10]];let d="";for(let k=1;k<P.length-1;k++)d+=`M0 0 L${P[k][0]} ${P[k][1]} L${P[k+1][0]} ${P[k+1][1]} `;return d+"M"+P.slice(1).map(p=>p.join(" ")).join(" L")};
    [[-1,112],[1,188]].forEach(([dir,x])=>f+=`<g transform="translate(${x} 70)"><g><path d="${wing(dir)}" stroke="url(#pcw${N})" stroke-width="1.3" fill="rgba(176,122,255,.14)" stroke-linejoin="round" filter="url(#pcg${N})"/><animateTransform attributeName="transform" type="scale" values="1 1;1 .4;1 1" dur="1.8s" calcMode="spline" keyTimes="0;.5;1" keySplines=".5 0 .5 1;.5 0 .5 1" repeatCount="indefinite"/></g></g>`);
    // projector hardware: an emitter cap for a stopper, a base puck under the foot, lit rings
    f+=`<path d="M110 14 Q110 6 118 6 L182 6 Q190 6 190 14 L190 40 L110 40 Z" fill="url(#pch${N})" stroke="#78F0FF" stroke-width="1.2"/><ellipse cx="150" cy="40" rx="36" ry="3.4" fill="#78F0FF" filter="url(#pcg${N})"><animate attributeName="opacity" values=".5;1;.5" dur="1.2s" repeatCount="indefinite"/></ellipse>
      ${[122,134,146,158,170].map((x,k)=>`<circle cx="${x}" cy="22" r="2" fill="${k%2?"#FF4AC8":"#78F0FF"}"><animate attributeName="opacity" values="1;.2;1" dur="${(.8+k*.2).toFixed(1)}s" repeatCount="indefinite"/></circle>`).join("")}
      <path d="M100 236 Q100 228 110 228 L190 228 Q200 228 200 236 L200 240 L100 240 Z" fill="url(#pch${N})" stroke="#78F0FF" stroke-width="1.2"/><ellipse cx="150" cy="228" rx="40" ry="3" fill="#78F0FF" filter="url(#pcg${N})"><animate attributeName="opacity" values=".5;1;.5" dur="1.2s" begin=".6s" repeatCount="indefinite"/></ellipse>`;}
  }
  /* The Unmaker's surroundings: a containment cell coming apart around it. Wall panels with holes eaten clean through to nothing, pieces of the room drawn in toward the vial and unmade, warning beacons turning, the last cell's broken vessels on the floor */
  if(a.name==="The Unmaker"){const U=UID,F=v=>(+v).toFixed(1);let sc=`<defs><linearGradient id="usw${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#15181D"/><stop offset="1" stop-color="#2A3038"/></linearGradient>
      <radialGradient id="usb${U}" cx=".5" cy="0" r="1"><stop offset="0" stop-color="#FF9A2A" stop-opacity=".6"/><stop offset="1" stop-color="#FF9A2A" stop-opacity="0"/></radialGradient>
      <pattern id="ushz${U}" width="14" height="14" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="7" height="14" fill="#D8B01E"/><rect x="7" width="7" height="14" fill="#15171A"/></pattern>
      <filter id="usbl${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="4"/></filter></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#usw${U})"/>`;
    // wall panels, some eaten clean through: the nearer to it, the more is gone
    const holes=[];
    for(let gy=-104;gy<214;gy+=46)for(let gx=-216;gx<516;gx+=56){const cx=gx+28,cy=gy+23,dd=Math.hypot(cx-150,(cy-130)*1.3),p=dd<150?.6:dd<250?.32:.1;
      sc+=`<rect x="${gx+1}" y="${gy+1}" width="54" height="44" fill="#232830" stroke="#0C0E11" stroke-width="2"/><path d="M${gx+3} ${gy+3} H${gx+53}" stroke="#4A525E" stroke-width="1"/>${[[5,5],[51,5],[5,41],[51,41]].map(([u,v])=>`<circle cx="${gx+u}" cy="${gy+v}" r="1.3" fill="#5A6270"/>`).join("")}`;
      if(R()<p){let d="";const rr=12+R()*12;for(let k=0;k<11;k++){const an=k/11*6.283,r2=rr*(.55+R()*.6);d+=(k?"L":"M")+F(cx+Math.cos(an)*r2*1.2)+" "+F(cy+Math.sin(an)*r2*.95)}
        sc+=`<path d="${d}Z" fill="#030406" stroke="#9AA6B4" stroke-width="1.1"/>`;holes.push([cx,cy])}}
    // a few stars of nothing showing through the holes
    holes.forEach(([x,y])=>{sc+=`<circle cx="${F(x+(R()-.5)*8)}" cy="${F(y+(R()-.5)*6)}" r=".7" fill="#CFE0F4"><animate attributeName="opacity" values=".1;.9;.1" dur="${rn(1.5,3.5)}s" repeatCount="indefinite"/></circle>`});
    // the floor: concrete, a hazard stripe with bites out of it
    sc+=`<path d="M-220 214 H520 V690 H-220 Z" fill="#131519"/><rect x="-220" y="220" width="740" height="10" fill="url(#ushz${U})"/>`;
    for(let k=0;k<6;k++)sc+=`<ellipse cx="${rn(20,280)}" cy="225" rx="${rn(6,14)}" ry="${rn(4,7)}" fill="#131519"/>`;
    // the last cell's vessels, broken on the floor
    sc+=`<g transform="translate(36 222) rotate(-78)"><path d="M-12 -10 L-12 14 Q-12 26 0 26 Q12 26 12 14 L12 -2 L6 -8 L2 0 L-4 -12 Z" fill="rgba(210,225,240,.25)" stroke="#9AA6B4" stroke-width="1.4"/><rect x="-10" y="-30" width="20" height="12" rx="2" fill="#6B4424" transform="translate(-6 -6) rotate(24)"/></g>
      <g transform="translate(262 214)"><path d="M-12 14 L-12 -4 L-6 -12 L-2 -2 L4 -14 L12 -6 L12 14 Q12 22 0 22 Q-12 22 -12 14 Z" fill="rgba(210,225,240,.25)" stroke="#9AA6B4" stroke-width="1.4"/></g>
      ${[[58,226,-20],[70,230,40],[240,229,10],[226,226,-50],[286,230,70]].map(([x,y,r])=>`<polygon points="0,-3 5,1 -2,3" fill="rgba(210,225,240,.5)" stroke="#9AA6B4" stroke-width=".5" transform="translate(${x} ${y}) rotate(${r})"/>`).join("")}`;
    // two warning beacons sweeping orange light across the cell
    [[-44,4,0],[344,4,1.1]].forEach(([x,y,dl])=>{sc+=`<g transform="translate(${x} ${y})"><g><polygon points="0,0 -60,260 60,260" fill="url(#usb${U})" filter="url(#usbl${U})"/><animateTransform attributeName="transform" type="rotate" values="-50;50;-50" dur="2.2s" begin="-${dl}s" repeatCount="indefinite"/></g><rect x="-10" y="-8" width="20" height="10" rx="3" fill="#2A3038"/><circle r="7" fill="#FF8A1A"><animate attributeName="opacity" values="1;.35;1" dur=".55s" repeatCount="indefinite"/></circle></g>`});
    // pieces of the room pulled in toward it and unmade on the way
    for(let k=0;k<18;k++){const h=holes[k%Math.max(1,holes.length)]||[R()*300,R()*200],d=rn(2.4,4.4),b=rn(0,4.4),s=rn(2,5);sc+=`<polygon points="0,${-s} ${s},${F(s*.4)} ${F(-s*.6)},${s}" fill="${k%2?"#6A7482":"#AAB4C0"}"><animateMotion dur="${d}s" begin="-${b}s" repeatCount="indefinite" path="M${F(h[0])} ${F(h[1])} Q${F((h[0]+150)/2+(R()-.5)*60)} ${F((h[1]+140)/2-30)} 150 140"/><animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.1;.6;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="scale" values="1;.2" dur="${d}s" begin="-${b}s" repeatCount="indefinite" additive="sum"/></polygon>`}
    back=sc+back;}
  /* Cinder Mercury's surroundings: deep inside a glacier. An ice cavern with icicles hanging from the roof, faceted blue walls, a frozen lake floor cracked by the heat, cold mist and drifting ice */
  if(a.name==="Cinder Mercury"){const U=UID,F=v=>(+v).toFixed(1);let sc=`<defs><linearGradient id="icv${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#030A16"/><stop offset=".55" stop-color="#0A2444"/><stop offset="1" stop-color="#15406E"/></linearGradient>
      <linearGradient id="ici${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1C4E7E"/><stop offset=".7" stop-color="#6AB4E4"/><stop offset="1" stop-color="#DDF6FF"/></linearGradient>
      <linearGradient id="icl${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#A8DDF6"/><stop offset="1" stop-color="#2A6A9E"/></linearGradient>
      <filter id="icb${U}" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="6"/></filter></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#icv${U})"/>`;
    // faceted ice walls closing in on both sides, catching a little light on their edges
    for(let k=0;k<26;k++){const side=k%2?1:-1,cx=150+side*(+rn(150,340)),cy=+rn(-100,220),r=+rn(30,70);let pts="";for(let m=0;m<5;m++){const an=m/5*6.283+R();pts+=`${F(cx+Math.cos(an)*r)},${F(cy+Math.sin(an)*r*.9)} `}
      sc+=`<polygon points="${pts}" fill="${["#0E3258","#143E6A","#0A2848","#1A4C7C"][k%4]}" stroke="#7FC8F0" stroke-width=".8" stroke-opacity=".35"/>`}
    // icicles hanging from the cavern roof
    for(let x=-214;x<520;x+=14+R()*14){const l=+rn(100,190),w=+rn(5,11);sc+=`<path d="M${F(x-w)} -110 L${F(x)} ${F(-110+l)} L${F(x+w)} -110 Z" fill="url(#ici${U})" stroke="#CFF4FF" stroke-width=".6" stroke-opacity=".6"/><path d="M${F(x-w*.3)} -110 L${F(x)} ${F(-110+l*.95)}" stroke="#FFFFFF" stroke-width=".6" opacity=".45"/>`;
      if(R()<.3){const d=rn(2.5,5),b=rn(0,5);sc+=`<circle cx="${F(x)}" cy="${F(-110+l)}" r="1.3" fill="#DFF6FF"><animate attributeName="cy" values="${F(-110+l)};${F(-110+l)};236" keyTimes="0;.7;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="1;1;0" keyTimes="0;.95;1" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}}
    // the frozen lake it sits on, cracked in rings around the heat
    sc+=`<path d="M-220 214 Q150 204 520 214 V690 H-220 Z" fill="url(#icl${U})"/>`;
    for(let k=0;k<12;k++)sc+=`<path d="M${rn(-200,500)} ${rn(218,250)} h${rn(30,90)}" stroke="#FFFFFF" stroke-width="1" opacity=".35"/>`;
    let cr="";for(let k=0;k<10;k++){const an=Math.PI*(k/10)+.15,side=k%2?1:-1;let px=150,py=230,d=`M150 230`;for(let t=0;t<4;t++){px+=side*(30+R()*40);py+=(R()-.5)*8;d+=` L${F(px)} ${F(py)}`}cr+=`<path d="${d}"/>`}
    sc+=`<g stroke="#FFFFFF" stroke-width="1" fill="none" opacity=".6">${cr}</g>`;
    // cold mist rolling over the ice, and ice crystals drifting in the air
    for(let k=0;k<5;k++){const d=rn(14,24),b=rn(0,24);sc+=`<ellipse cx="0" cy="${rn(214,236)}" rx="${rn(60,110)}" ry="${rn(8,14)}" fill="#CFEFFF" opacity=".22" filter="url(#icb${U})"><animate attributeName="cx" values="-240;540" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></ellipse>`}
    for(let k=0;k<24;k++){const x=+rn(-200,500),y=+rn(-100,200),d=rn(6,12),b=rn(0,12);sc+=`<circle cx="${x}" cy="${y}" r="${rn(.6,1.5)}" fill="#EAF8FF"><animate attributeName="cy" values="${y};${F(y+50)}" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animate attributeName="opacity" values="0;.9;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></circle>`}
    back=sc+back;}
  /* Founder's Folly's surroundings: the Institute's first basement lab, sealed ever since. Old brick, the doorway bricked up, a blackboard of redacted working, shelves of the founder's old bottles, a bare bulb that won't stop flickering, a hazard sign, papers on the floor */
  if(a.name==="Founder's Folly"){const U=UID,F=v=>(+v).toFixed(1);let sc=`<defs><pattern id="fbr${U}" width="28" height="14" patternUnits="userSpaceOnUse"><rect width="28" height="14" fill="#2A2019"/><rect x="1" y="1" width="26" height="5.5" rx="1" fill="#4A3426"/><rect x="-13" y="8" width="26" height="5.5" rx="1" fill="#44301F"/><rect x="15" y="8" width="26" height="5.5" rx="1" fill="#4E3828"/></pattern>
      <pattern id="fbn${U}" width="20" height="10" patternUnits="userSpaceOnUse"><rect width="20" height="10" fill="#3A342C"/><rect x="1" y="1" width="18" height="3.6" fill="#6A6254"/><rect x="-9" y="6" width="18" height="3.6" fill="#5E5648"/><rect x="11" y="6" width="18" height="3.6" fill="#645C4E"/></pattern>
      <radialGradient id="fbl${U}" gradientUnits="userSpaceOnUse" cx="60" cy="-30" r="260"><stop offset="0" stop-color="#FFE2A0" stop-opacity=".5"/><stop offset=".4" stop-color="#FFC060" stop-opacity=".14"/><stop offset="1" stop-color="#FFC060" stop-opacity="0"/></radialGradient>
      <linearGradient id="fbw${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#6A4A2A"/><stop offset="1" stop-color="#3A2614"/></linearGradient></defs>`;
    sc+=`<rect x="-220" y="-110" width="740" height="800" fill="url(#fbr${U})"/><rect x="-220" y="-110" width="740" height="800" fill="#0A0806" opacity=".35"/>`;
    // damp stains running down the brick
    for(let k=0;k<6;k++)sc+=`<path d="M${rn(-200,500)} -110 q${rn(-10,10)} 80 ${rn(-6,6)} ${rn(120,220)}" stroke="#120C08" stroke-width="${rn(10,22)}" opacity=".35" stroke-linecap="round"/>`;
    // the old doorway, bricked up in newer, paler brick, with a crack that keeps coming back
    sc+=`<path d="M-160 214 V-10 Q-100 -70 -40 -10 V214 Z" fill="url(#fbn${U})" stroke="#1A120C" stroke-width="4"/><path d="M-120 -20 L-104 20 L-114 52 L-96 96 L-104 140" stroke="#0A0806" stroke-width="2" fill="none"/>
      <text x="-100" y="90" text-anchor="middle" font-family="Press Start 2P, monospace" font-size="9" fill="#B8201A" opacity=".8" transform="rotate(-6 -100 90)">SEALED</text>`;
    // a blackboard of the founder's working, half of it blacked out
    sc+=`<rect x="-30" y="-2" width="112" height="70" fill="#1A2420" stroke="#5A3E22" stroke-width="5"/>`;
    for(let k=0;k<6;k++){const y=10+k*10;sc+=`<path d="M-22 ${y} h${rn(20,40)} m6 0 h${rn(10,30)}" stroke="#D8DCD0" stroke-width="1.2" opacity=".6"/><rect x="${rn(10,40)}" y="${y-4}" width="${rn(18,36)}" height="7" fill="#000"/>`}
    // shelves of the founder's old bottles
    [40,98,156].forEach(y=>{sc+=`<rect x="228" y="${y}" width="200" height="6" fill="url(#fbw${U})"/><path d="M236 ${y+6} l6 12 M420 ${y+6} l-6 12" stroke="#3A2614" stroke-width="3"/>`;
      for(let x=238;x<420;x+=+rn(14,24)){const h=+rn(14,34),w=+rn(6,12),col=["#3A4A3A","#4A3A2A","#2E3A4A","#5A5040"][R()*4|0];sc+=`<path d="M${F(x)} ${y} V${F(y-h*.7)} Q${F(x)} ${F(y-h*.8)} ${F(x+w*.3)} ${F(y-h*.85)} V${F(y-h)} H${F(x+w*.7)} V${F(y-h*.85)} Q${F(x+w)} ${F(y-h*.8)} ${F(x+w)} ${F(y-h*.7)} V${y} Z" fill="${col}" stroke="#0A0806" stroke-width=".6"/><rect x="${F(x+1.5)}" y="${F(y-h*.5)}" width="${F(w-3)}" height="${F(h*.2)}" fill="#D8CCA8" opacity=".7"/>`}});
    // a hazard sign bolted to the brick
    sc+=`<g transform="translate(206 -30)"><polygon points="0,-18 18,14 -18,14" fill="#F2D12C" stroke="#111" stroke-width="2"/><circle cy="4" r="2.2" fill="#111"/>${[0,120,240].map(r=>`<path d="M0 4 L${F(8*Math.cos((r-90-25)*Math.PI/180))} ${F(4+8*Math.sin((r-90-25)*Math.PI/180))} A8 8 0 0 1 ${F(8*Math.cos((r-90+25)*Math.PI/180))} ${F(4+8*Math.sin((r-90+25)*Math.PI/180))} Z" fill="#111"/>`).join("")}</g>`;
    // a bare bulb on its cord, flickering
    sc+=`<circle cx="60" cy="-30" r="260" fill="url(#fbl${U})"><animate attributeName="opacity" values="1;1;.3;1;.5;1;1" keyTimes="0;.6;.62;.64;.66;.7;1" dur="4.3s" repeatCount="indefinite"/></circle>
      <path d="M60 -110 V-40" stroke="#111" stroke-width="1.5"/><rect x="55" y="-42" width="10" height="7" fill="#3A3A3A"/><ellipse cx="60" cy="-28" rx="7" ry="9" fill="#FFF1C0"><animate attributeName="opacity" values="1;1;.3;1;.5;1;1" keyTimes="0;.6;.62;.64;.66;.7;1" dur="4.3s" repeatCount="indefinite"/></ellipse>`;
    // the floor: bare concrete, papers everywhere
    sc+=`<path d="M-220 214 H520 V690 H-220 Z" fill="#1E1C1A"/><path d="M-220 214 H520" stroke="#3A3630" stroke-width="2"/>`;
    for(let k=0;k<14;k++){const x=+rn(-200,500);if(Math.abs(x-150)<60)continue;sc+=`<g transform="translate(${F(x)} ${rn(218,238)}) rotate(${rn(-40,40)}) scale(1 .45)"><rect x="-8" y="-10" width="16" height="20" fill="#E8E2D0"/><rect x="-6" y="-6" width="11" height="2.4" fill="#111"/><rect x="-6" y="-1" width="7" height="2.4" fill="#111"/><rect x="-6" y="4" width="10" height="2.4" fill="#111"/></g>`}
    back=sc+back;}
  if(box)svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${box}</g>`);
  // the scene lives on its own layer behind the sample, filling the whole screen, so the sample can hop, slosh or be picked up without dragging the background along
  if(back&&!mini){const cont=host.closest("#stage,.ddscreen");
    if(cont){cont.querySelectorAll(":scope>.tscene").forEach(e=>e.remove());const lay=document.createElementNS("http://www.w3.org/2000/svg","svg");lay.setAttribute("class","tscene");lay.setAttribute("aria-hidden","true");
      lay.innerHTML=`<g pointer-events="none">${back}</g>`;lay._spec=svg;cont.prepend(lay);fitScene(lay)}
    else svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${back}</g>`)}
  svg.insertAdjacentHTML("beforeend",`<g class="tfx" pointer-events="none">${f}</g>`);if(mini){svg.style.overflow="hidden";const dd=(back.match(/<defs>[\s\S]*?<\/defs>/g)||[]).join("");if(dd)svg.insertAdjacentHTML("afterbegin",dd)}}
/* line a scene layer up with its sample: same coordinates, centred on the sample, scaled up if needed so the scene always covers the whole screen */
function fitScene(lay){const cont=lay.parentNode,svg=lay._spec;if(!cont||!svg||!svg.isConnected)return;const C=cont.getBoundingClientRect(),S0=svg.getBoundingClientRect();if(!C.width||!S0.width)return;
  const s0=S0.width/300,cx=(S0.left-C.left)+150*s0,cy=(S0.top-C.top)+130*s0,s=Math.max(s0,cy/236,cx/366,(C.width-cx)/366);   // scenes run from -110 to 260 vertically and -220 to 520 across, around a centre of (150,130)
  lay.setAttribute("viewBox",`${(150-cx/s).toFixed(2)} ${(130-cy/s).toFixed(2)} ${(C.width/s).toFixed(2)} ${(C.height/s).toFixed(2)}`)}
addEventListener("resize",()=>document.querySelectorAll(".tscene").forEach(fitScene));
{const _rs=renderStage;renderStage=function(){const old=$("#stage>.tscene");if(old&&!(S.r&&S.r.a&&S.r.a.threat))old.remove();_rs();const a=S.r&&S.r.a;$("#specimen").classList.remove("holo");threatSkin($("#stage"),a);if(a&&a.threat)threatFx($("#specimen"),a)}}
{const _od=openDex;openDex=function(no){_od(no);const a=ALLOYS[no-1];if(a&&a.threat&&statusOf(a)!=="unseen"){const sc=$("#ddscreen"),L=TLOOK[a.name];if(sc&&L){sc.style.background=`repeating-conic-gradient(from 0deg at 50% 45%,${L.a} 0 9deg,${L.b} 9deg 18deg)`;threatFx(sc.querySelector(".ddspec"),a)}}}}

TRACKS.threat={bpm:144,lv:.1,bv:.26,
  lead:"D5 - A4 D5 F5 - E5 D5 A5 - - G5 F5 - E5 - D5 - F5 - Bb5 - A5 G5 G5 - E5 - C5 - E5 G5 D5 - A4 D5 F5 - A5 - D6 - C6 A5 F5 - A5 - Bb5 - A5 G5 F5 - D5 - E5 - C#5 - A4 - - - G4 Bb4 D5 G5 - F5 D5 - Bb5 - A5 G5 D5 - Bb4 - A4 D5 F5 A5 - G5 F5 - D6 - - - A5 - F5 - F5 - D5 F5 Bb5 - F5 - G5 - E5 G5 C6 - G5 - A5 - E5 - C#6 - A5 - E5 - - - C#5 - E5 - D6 - A5 - F5 - D5 - F5 - D5 - Bb4 - D5 F5 A5 - F5 - C6 - A5 - G5 - E5 - C5 E5 G5 C6 Bb5 - G5 - D5 - G5 Bb5 A5 - E5 - C#5 E5 A5 C#6 D6 - A5 F5 D5 - A4 - D5 - - - . . . .",
  bass:"D2 D3 D2 D2 D3 D2 D3 D2 D2 D3 D2 D2 D3 D2 D3 D2 Bb2 Bb3 Bb2 Bb2 Bb3 Bb2 Bb3 Bb2 C2 C3 C2 C2 C3 C2 C3 C2 D2 D3 D2 D2 D3 D2 D3 D2 D2 D3 D2 D2 D3 D2 D3 D2 Bb2 Bb3 Bb2 Bb2 Bb3 Bb2 Bb3 Bb2 A2 A3 A2 A2 A3 A2 A3 A2 G2 G3 G2 G2 G3 G2 G3 G2 G2 G3 G2 G2 G3 G2 G3 G2 D2 D3 D2 D2 D3 D2 D3 D2 D2 D3 D2 D2 D3 D2 D3 D2 Bb2 Bb3 Bb2 Bb2 Bb3 Bb2 Bb3 Bb2 C2 C3 C2 C2 C3 C2 C3 C2 A2 A3 A2 A2 A3 A2 A3 A2 A2 A3 A2 A2 A3 A2 A3 A2 D2 D3 D2 D2 D3 D2 D3 D2 Bb2 Bb3 Bb2 Bb2 Bb3 Bb2 Bb3 Bb2 F2 F3 F2 F2 F3 F2 F3 F2 C2 C3 C2 C2 C3 C2 C3 C2 G2 G3 G2 G2 G3 G2 G3 G2 A2 A3 A2 A2 A3 A2 A3 A2 D2 D3 D2 D2 D3 D2 D3 D2 D2 D3 D2 D2 D3 D2 D3 D2",
  drum:"k h s h k k s h",fill:"k s k s s s c c"};
CHORDS.threat="Dm Dm Bb C Dm Dm Bb A Gm Gm Dm Dm Bb C A A Dm Bb F C Gm A Dm Dm".split(" ");
/* One remix per threat, all built from the same boss theme: same key, same melody, start from bar 1, no echo. */
Object.assign(TRACKS,{
  "threat_cinder":{base:"threat",bpm:152,lead:{type:"square",vol:.1,stac:true},parts:[{k:"arp",type:"pulse",vol:.028,oct:5},{k:"stab",type:"triangle",vol:.05,oct:4}],bass:{s:"root8",vol:.28},drum:"k h s h k h s k",fill:"k k s s k s c c",hat16:true},
  "threat_drowned":{base:"threat",bpm:126,swing:.25,lead:{type:"triangle",vol:.22},parts:[{k:"third",type:"square",vol:.035},{k:"broken",type:"triangle",vol:.07,oct:3}],bass:{s:"oompah",vol:.3},drum:"k . . s . k s .",fill:"k . s . k s s s",waves:true},
  "threat_everburn":{base:"threat",bpm:150,lead:{type:"sawtooth",vol:.08,stac:true},parts:[{k:"power",type:"sawtooth",vol:.045,oct:3}],bass:{s:"root8",type:"sawtooth",vol:.11},drum:"k k s k k k s k",fill:"s s s s k k c c"},
  "threat_unmaker":{base:"threat",bpm:138,lead:{type:"pulse",vol:.12,stac:true},parts:[{k:"chug",type:"square",vol:.03,oct:3},{k:"stab",type:"square",vol:.025,oct:5}],bass:{s:"walk",vol:.28},drum:"k c s h k c s h",fill:"k c k c s s c c"},
  "threat_widow":{base:"threat",bpm:108,lead:{type:"sine",vol:.24,half:true},parts:[{k:"pad",type:"triangle",vol:.05,oct:3},{k:"broken",type:"sine",vol:.08,oct:4}],bass:{s:"half",vol:.24},drum:"k . . . s . . h",fill:"k . . k s . s ."},
  "threat_hollow":{base:"threat",bpm:140,lead:{type:"pulse",vol:.11},parts:[{k:"ostinato",type:"square",vol:.024,oct:5},{k:"pad",type:"sine",vol:.04,oct:4}],bass:{s:"octave",vol:.25},drum:"k h h s k h h s",fill:"k h s h k s c c",hat16:true},
  "threat_crown":{base:"threat",bpm:118,lead:{type:"triangle",vol:.22},parts:[{k:"counter",type:"square",vol:.045,oct:5},{k:"pad",type:"square",vol:.02,oct:4}],bass:{s:"half",vol:.26},drum:"k . s s k . s .",fill:"k s s s k s c c",chime:true},
  "threat_quill":{base:"threat",bpm:136,lead:{type:"square",vol:.1},parts:[{k:"third",type:"triangle",vol:.08},{k:"stab",type:"pulse",vol:.024,oct:4}],bass:{s:"walk",type:"sawtooth",vol:.1},drum:"k . s . k s s .",fill:"k s s s k s c c",hat16:true,chime:true},
  "threat_phoenix":{base:"threat",bpm:132,intro:2,lead:{type:"sawtooth",vol:.075},parts:[{k:"arp",type:"triangle",vol:.04,oct:5},{k:"counter",type:"pulse",vol:.035,oct:5}],bass:{s:"walk",vol:.26},drum:"k h s k . k s h",fill:"k k s k s s c c",hat16:true}
});


/* Clear any tutorial overlay left on screen by an older version of the page (live updates can carry old elements over) */
document.querySelectorAll(".tut-offer,#tut").forEach(e=>e.remove());
