/* =============== DR. MARLOW'S FIELD ORDERS: one field season, told in orders. You start as a recruit and finish as field staff. =============== */
const FO_RANKS=["Recruit","Field Assistant","Field Scientist","Field Staff","Deputy Surveyor"];
const FIELD_ORDERS=[
 {id:"test",title:"First Steps",rank:0,goal:"Register 2 alloys, anywhere in the field.",need:2,count:()=>1,reward:["charm"],
  brief:["There you are! Come in, come in. Mind the maps on the floor, they're in a very particular order. I think.","The tutorial alloy was the easy bit. I held your hand the whole way. Now let's see you do it on your own.","Register two alloys out in the field. Any two. Take your time, and come and tell me how it went."],
  report:["Two already! And not a single singed eyebrow. I'm impressed. I singed both of mine my first week.","Here, a little something for luck. Everyone should have one."]},
 {id:"ride",title:"Out in the Field",rank:0,reward:["lure"],
  steps:[{kind:"enter",zone:"z-mine",scene:"ride",goal:"Meet Dr. Marlow at Rustvein Mine."},{kind:"win",zone:"z-mine",goal:"Register an alloy at Rustvein Mine while Dr. Marlow watches."}],
  brief:["You know, I haven't been out in the field in weeks. The paperwork on my desk has grown a crust.","Meet me at Rustvein Mine. I'd like to show you how I read rubble, and then I'd like to watch you do it.","Wear sensible boots. I never do, and I always regret it."],
  report:["Lovely work in the mine. Truly. You walked it slowly, which is more than most recruits manage.","Everything in that mine was put there by somebody, or by something. The rubble remembers. You'll see.","Here. A rubble lure. For the days the ground's being shy."]},
 {id:"range",title:"Range Survey",rank:0,goal:"Register alloys on 3 different maps.",need:3,count:()=>{const z=EXP.zone&&EXP.zone.cls,m=store.get("wta_fo_maps",[]);if(!z||m.includes(z))return 0;m.push(z);store.set("wta_fo_maps",m);return 1},reward:["survey"],
  brief:["Right, a proper job. Every season I rewrite the field guide for next year's recruits, and my range maps are shamefully out of date.","Register alloys on three different maps for me. I want to know what's turning up where, this year.","Different rubble, different habits. You'll see."],
  report:["Three maps! Oh, this is wonderful. Look, that one's never been recorded that far east before.","Here, have a survey map. It'll save your boots next time."]},
 {id:"cold",title:"Name It Cold",rank:0,rankUp:1,goal:"Name a nameless alloy with no letter hints and no field guide page.",need:1,count:()=>0,byName:1,reward:["guide","guide"],
  brief:["Your range notes are lovely, by the way. Going straight in the guide.","Now, the Mystery samples. No name on the plate, just you and the bench.","Next time you get one, name it yourself. No letter hints, no field guide page. Trust your tests. You know more than you think."],
  report:["You named it cold! Do you know how many recruits manage that in their first season? Not many. Not many at all.","That's a promotion, I think. Field Assistant. It comes with a better badge and exactly the same pay.","And a couple of field guide pages, for the days your head's full of fog. Everyone has those."]},
 {id:"clean",title:"One Clean Scan",rank:1,goal:"Register an alloy's elements with one clean scan and no scanner hint.",need:1,count:r=>r.kind!=="who"||r.nameKnown?(r.tries>=r.maxTries&&!r.hints?1:0):0,reward:["cell","cell"],
  brief:["Field Assistant! Still has a nice ring to it.","Here's a fun one. The accounts office has asked me, very politely, to stop using so many scanner charges. So let's show off.","Register an alloy with one clean scan. Every element right, first go, no scanner hint. Your bench tests will get you there."],
  report:["First go! I'm going to frame that scan and hang it outside accounts.","Spare cells, for the days it takes three. It happens to all of us."]},
 {id:"real",title:"Textbook Metals",rank:1,goal:"Register 3 textbook alloys (the ones marked Real-world alloy in your Alloydex).",need:3,count:r=>r.a&&r.a.real?1:0,reward:["patch"],
  brief:["I'm putting together a teaching collection for next year's recruits, and I'd like you to help build it.","The textbook standards. The old, well-known ones every handbook lists, the ones that built bridges and bells and teapots. Register three of them.","Everybody wants to find the strange ones. The ordinary ones are where you learn."],
  report:["Three textbook metals, logged and labelled. Next year's recruits will be learning from your samples. How about that?","A containment patch, just in case. I hope you never need it.","If you do, Quartermaster Hobbs keeps more in his cage. He'll want a slip for every one. He wants a slip for everything."]},
 {id:"slag",title:"Syndicate Trouble",rank:1,rankUp:2,goal:"Beat 2 Slag Syndicate grunts in duels.",need:2,count:(r,st)=>st.duel?1:0,reward:["decoy","timer"],
  brief:["I don't like saying this, but a couple of our recruits have had samples snatched out of their hands this month. The Slag Syndicate.","They're watching the maps, and they're getting bolder. I'd rather they learned to be a bit less bold.","If a grunt challenges you, name their sample before they can fence it. Beat two of them. And be careful out there. I mean that."],
  report:["Two of them! Word's already going round the Institute. The other recruits are calling you 'the one the Syndicate complain about'.","That's worth another promotion, I'd say. Field Scientist. You've earned it twice over.","A decoy and a timer. Keep them handy. I don't think the Syndicate are finished with us."]},
 {id:"ledger",title:"The Fence's Ledger",rank:2,reward:["decoy","cell"],
  steps:[{kind:"enter",zone:"z-scrap",scene:"ledger",goal:"Keep watch at Tinker's Scrapyard. The Syndicate have been coming and going there at all hours."},{kind:"obj",zone:"z-scrap",what:"satchel",goal:"Pick up whatever that grunt dropped at the Scrapyard."}],
  brief:["Here's something I've been chewing on. Syndicate grunts don't keep the samples they snatch. They sell them on. So somebody's buying.","Grunts have been seen at Tinker's Scrapyard at all hours. Go and keep watch for me.","Don't pick a fight. Just watch. You'd be amazed what people drop when they're in a hurry."],
  report:["You brought me their ledger? Their actual ledger?","(He turns the pages slowly, and doesn't say anything for a while. His thumb stops on the line that's underlined twice.)","'Anything that doesn't age.' Hm.","Somebody out there is paying the Syndicate to hunt for one very particular kind of metal. And the Syndicate have got very good at hunting.","I'll keep this, if you don't mind. You did exactly what I asked. You watched.","A decoy and a spare cell. Watch a bit longer, everywhere you go."]},
 {id:"streak",title:"Hot Streak",rank:2,goal:"Register 3 alloys in a row without one getting away.",need:3,count:()=>1,resetOnLoss:1,reward:["sieve","sieve"],
  brief:["Field Scientist. Look at you.","Here's the thing about the field: anybody gets lucky once. What I'd love to see is you getting it right, again and again.","Register three alloys in a row. If one slips away or you run, don't worry, just start the count again."],
  report:["Three in a row! That's not luck any more. That's you.","Sieves. For when you want to be sure."]},
 {id:"deep",title:"Behind the Gates",rank:2,goal:"Register an alloy from rubble behind a tool gate: unlit tunnels, deep shallows, crates or cracked rock.",need:1,count:r=>r.gated?1:0,reward:["stasis"],
  brief:["The Syndicate have been picking over the open rubble all season. Anything easy to reach, they've had a go at.","So let's go where they can't. Unlit tunnels, flooded pools, split boulders, the places you need a proper tool for.","Register an alloy from behind one of those. Borrow what you need. The people out there are kinder than they look.","Bolt at the Scrapyard lends crowbars, if you do him a good turn. Foreman Dray at the mine keeps pit lamps. And the station at Frostbite Cavern had an ice pick once, if nobody's lost it."],
  report:["From behind a gate! That's the good rubble. That's why I keep sending people into dark holes.","A stasis pack. Things behind gates occasionally bite. Better safe.","Don't tell Hobbs I gave you that without a slip. He'll have us both filling in forms till spring."]},
 {id:"stones",title:"The Old Stones",rank:2,reward:["guide","glint"],
  steps:[{kind:"obj",zone:"z-reactor",what:"stone",goal:"Take a rubbing of the old survey stone at the Old Reactor Hall."},{kind:"obj",zone:"z-vault",what:"stone",goal:"Take a rubbing of the old survey stone at the Gilded Vault."},{kind:"obj",zone:"z-scrap",what:"stone",goal:"Take a rubbing of the last survey stone, at Tinker's Scrapyard."}],
  brief:["Next year's field guide wants a proper history page. Archivist Wren has informed me that mine is 'a paragraph and a drawing of a teapot'.","When the Institute was new, the first survey set marker stones at the edges of the maps it walked. Three are still standing, as far as anyone knows.","Take a rubbing of each for me: one at the Old Reactor Hall, one at the Gilded Vault, one at Tinker's Scrapyard. Paper and charcoal are in the tray."],
  report:["Three rubbings! Oh, Wren is going to be unbearable about this.","(He holds the last one up to the window for a long moment.)","O.G. The first surveyor. She walked the whole moor on foot before anybody had drawn a map of it. Every line in your survey map started with her chain.","'Still counting.' Hm. That wasn't there before.","Anyway! History page, done. Here, for your trouble."]},
 {id:"dex",title:"The Long Count",rank:2,rankUp:3,goal:"Have 30 different alloys registered in your Alloydex.",need:30,absolute:()=>S.caught.size,reward:["charm","survey","guide"],
  brief:["Last order of the season, and the one I've been saving.","Thirty different alloys in your Alloydex. When you get there, come and see me. There's something I'd like to say properly."],
  report:["Thirty. Thirty different alloys, found and tested and named by you.","I've been head of this field team for a very long time, and I don't say this often: you're field staff now. Not a recruit. Not an assistant. One of us.","The new field guide is going to the printers next week. I've put your name in the front.","Take these. And keep going. There's always another one in the rubble. There always has been."]},
 /* ---- after the founder's secret is out: the other line on the roster ---- */
 {id:"other",title:"The Other Line",rank:3,season:2,reward:["charm","survey"],briefScene:"other",
  steps:[{kind:"talk",n:"Archivist Wren",goal:"Ask Archivist Wren about the second scratched-out line on the Institute's first staff roster."},{kind:"talk",n:"Projectionist Tamsin",goal:"Ask Projectionist Tamsin at Starfall Crater about the old forwarding address."}],
  brief:["Ask Wren about the second line on the roster. She's been itching to tell somebody for months."],
  report:["'Still counting.' She always did count everything. Stones, steps, grudges.","And she wants me to come myself. Of course she does.","Before I go, I'd like to know what the Syndicate are carrying for her these days. Grunts carry notes."]},
 {id:"fence",title:"Messages in Orange",rank:3,season:2,goal:"Beat 2 Slag Syndicate grunts in duels. One of them will be carrying a message.",need:2,count:(r,st)=>st.duel?1:0,reward:["timer","decoy"],
  brief:["Beat a couple of grunts for me. One of them will have a note in a pocket. They always do. Nobody in the Syndicate can remember anything."],
  report:["(He unfolds a scrap of paper taken from a grunt's pocket. The pencil is shaky, and very neat.)","'The grunts don't answer to me any more, Aldous. Varrow runs them now, and Varrow wants what's under your floor. Come to the crater at dusk. Both of you. O.'","Both of you. She means you too.","Well. I suppose I'd better find a clean collar."]},
 {id:"meet",title:"Dusk at Starfall",rank:3,rankUp:4,season:2,reward:["charm","guide","patch"],
  steps:[{kind:"enter",zone:"z-crater",scene:"meet",goal:"Go to Starfall Crater at dusk. Dr. Marlow will meet you there."}],
  brief:["Starfall Crater, then. I'll meet you on the rim. Don't wait for me. I'll be late. I'm always late for her."],
  report:["I put her name back on the roster this morning. In ink. Wren cried, and then said it was the dust.","Varrow is coming for the basement, sooner or later. When he does, I'd like you standing in the door with me.","Odile gave you her badge. That makes you a deputy of something, whether I like it or not. And I do like it."]}];
FIELD_ORDERS.forEach(o=>{if(o.steps)o.need=o.steps.length});
function foDoneSet(){return new Set([...FIELD_ORDERS.slice(0,foIdx()).map(o=>o.id),...store.get("wta_fo_skip",[])])}
function foDone(id){return foDoneSet().has(id)}
function foRank(){let r=0;const d=foDoneSet();FIELD_ORDERS.forEach(o=>{if(o.rankUp&&d.has(o.id))r=Math.max(r,o.rankUp)});return FO_RANKS[r]}
function foGoal(o){return o.steps?(o.steps[Math.min(o.steps.length-1,store.get("wta_fo_n",0))]||o.steps[0]).goal:o.goal}
{if(!store.get("wta_fo_mig2",0)){const old=["test","cold","range","clean","slag","streak","real","deep","dex"],i=store.get("wta_fo",0),done=new Set(old.slice(0,i));
  let n=0;while(n<FIELD_ORDERS.length&&done.has(FIELD_ORDERS[n].id))n++;store.set("wta_fo_skip",[...done].filter(id=>FIELD_ORDERS.findIndex(o=>o.id===id)>n));
  if(n!==i){store.set("wta_fo",n);if(store.get("wta_fo_on",0)===1&&done.has(FIELD_ORDERS[n]&&FIELD_ORDERS[n].id))store.set("wta_fo_on",0)}
  if(store.get("wta_fo_on",0)===1&&old[i]!==(FIELD_ORDERS[n]&&FIELD_ORDERS[n].id)){store.set("wta_fo_on",0);store.set("wta_fo_n",0)}
  store.set("wta_fo_mig2",1);store.set("wta_fo_mig3",1)}}
function foIdx(){return store.get("wta_fo",0)}
{if(!store.get("wta_fo_mig3",0)){const old=["test","range","cold","clean","real","slag","streak","deep","dex"],i=store.get("wta_fo",0),done=new Set([...old.slice(0,i),...store.get("wta_fo_skip",[])]);
  let n=0;while(n<FIELD_ORDERS.length&&done.has(FIELD_ORDERS[n].id))n++;
  if(store.get("wta_fo_on",0)===1&&old[i]!==(FIELD_ORDERS[n]&&FIELD_ORDERS[n].id)){store.set("wta_fo_on",0);store.set("wta_fo_n",0)}
  store.set("wta_fo",n);store.set("wta_fo_skip",[...done].filter(id=>FIELD_ORDERS.findIndex(o=>o.id===id)>n));store.set("wta_fo_mig3",1)}}
function foActive(){return store.get("wta_fo_on",0)===1||foIdx()>0}
function foCertified(){return foIdx()>=1}
function foFounderOpen(){return foDone("dex")||store.get("wta_q",0)>=1}
function foCur(){const o=FIELD_ORDERS[foIdx()]||null;if(o&&o.season===2&&store.get("wta_q",0)<15)return null;return o}
function foProg(){const o=foCur();if(!o||store.get("wta_fo_on",0)!==1)return 0;return o.absolute?Math.min(o.need,o.absolute()):Math.min(o.need,store.get("wta_fo_n",0))}
function foReady(){const o=foCur();return !!o&&store.get("wta_fo_on",0)===1&&foProg()>=o.need}
if(!store.get("wta_fo_mig",0)){if(store.get("wta_q",0)>=1&&foIdx()<1){store.set("wta_fo",1);store.set("wta_fo_on",0)}store.set("wta_fo_mig",1)}
function foAccept(){store.set("wta_fo_on",1);store.set("wta_fo_n",0);store.set("wta_fo_maps",[]);store.set("wta_qf_seenJ",0);journalDot()}
function foTurnIn(done){const o=foCur();o.reward.forEach(k=>giveItem(k));const names=o.reward.map(k=>ITEMS[k].name.toUpperCase());{let n=foIdx()+1;const sk=store.get("wta_fo_skip",[]);while(FIELD_ORDERS[n]&&sk.includes(FIELD_ORDERS[n].id))n++;store.set("wta_fo",n)}store.set("wta_fo_on",0);store.set("wta_qf_seenJ",0);journalDot();
  sfx("fanfare");say0(`Field order complete: ${o.title.toUpperCase()}.${o.rankUp?` New rank: ${FO_RANKS[o.rankUp].toUpperCase()}.`:""} You got ${[...new Set(names)].map(n=>`${names.filter(x=>x===n).length>1?names.filter(x=>x===n).length+" × ":""}${n}`).join(", ")}.`);if(done)done()}
{const _w=win;win=function(){const r=S.r,D=r&&r.duel;_w();const o=foCur();if(!o||o.steps||store.get("wta_fo_on",0)!==1||!r||r.tut||r.quest||foReady())return;
  if(o.absolute){if(foReady())setTimeout(()=>say("Field order complete! Report to Dr. Marlow."),5200);return}
  const add=o.count(r,{duel:!!D});if(add>0){store.set("wta_fo_n",store.get("wta_fo_n",0)+add);if(foReady())setTimeout(()=>say(`Field order "${o.title}" complete! Report to Dr. Marlow.`),D?6800:3200)}}}
{const _l=lose;lose=function(ran){_l(ran);const o=foCur();if(o&&o.resetOnLoss&&store.get("wta_fo_on",0)===1&&!foReady()&&store.get("wta_fo_n",0)>0){store.set("wta_fo_n",0);setTimeout(()=>say(`That breaks your streak for "${o.title}". Back to nought.`),2600)}}}
{const _gn=guessName;guessName=function(v){const r=S.r,was=r&&r.stage;_gn(v);const o=foCur();
  if(r&&was==="name"&&r.stage!=="name"&&r.nameKnown&&o&&o.byName&&store.get("wta_fo_on",0)===1&&!foReady()&&!r.tut&&!r.letters&&!r.usedGuide){store.set("wta_fo_n",1);setTimeout(()=>say(`Named it cold! Field order "${o.title}" complete. Report to Dr. Marlow.`),2600)}}}
{const _sr=startRound;startRound=function(){const g=!!EXP.fromGated;_sr();if(S.r)S.r.gated=g}}
{const _ug=useItem;useItem=function(k){if(k==="guide"&&S.r)S.r.usedGuide=true;_ug(k)}}

/* talking to him, in his office */
function foNext(){let ni=foIdx()+1;const sk=store.get("wta_fo_skip",[]);while(FIELD_ORDERS[ni]&&sk.includes(FIELD_ORDERS[ni].id))ni++;const nx=FIELD_ORDERS[ni];return nx&&!(nx.season===2&&store.get("wta_q",0)<15)?nx:null}
function foBrief(o,who,via,after){const go=()=>{foAccept();say0(`New field order: ${o.title.toUpperCase()}. It's in your JOURNAL.`);after&&after()};
  if(via){talk("",["A fresh field order is pinned to the tray, in tidy brown ink."].concat(o.brief.slice(-1)),go);return}
  if(o.briefScene&&typeof SCENES!=="undefined"&&SCENES[o.briefScene]){playScene(o.briefScene,()=>talk(who,o.brief,go));return}
  talk(who,o.brief,go)}
function marlowOrders(m,via){const o=foCur(),on=store.get("wta_fo_on",0)===1,who=via?"":m.n;
  if(!o){talk(who,via?["The tray is empty. There are no more field orders waiting."]:["No more orders, I'm afraid. You don't need me handing you lists any more.","Go and find something nobody's named. Then come and tell me about it. I'd like that."]);return}
  if(on&&foReady()){const nx=foNext();
    if(o.rankUp&&!via&&typeof SCENES!=="undefined"){talk(who,o.report,()=>{foTurnIn();playScene("promo"+o.rankUp,()=>{if(foCur())foBrief(foCur(),who,false)})});return}
    const lines=via?["You leave your field report in the tray. Beneath it is an envelope with your name on it, already waiting.",...o.report.slice(-1),...(nx?["Inside the envelope, a new field order in tidy brown ink:",...nx.brief.slice(-2)]:[])]:[...o.report,...(nx&&!nx.briefScene?nx.brief:[])];
    talk(who,lines,()=>{foTurnIn();const c=foCur();if(!c)return;if(c.briefScene&&!via){foBrief(c,who,false);return}foAccept();setTimeout(()=>say0(`Field order complete: ${o.title.toUpperCase()}. New field order: ${c.title.toUpperCase()}. It's in your JOURNAL.`),50)});return}
  if(on){talk(who,via?["Nothing to report yet. The tray waits."]:o.steps?[`How's ${o.title} coming along?`,foGoal(o).replace(/\.$/,"")+". No rush."]:[`How's ${o.title} coming along? ${foProg()} of ${o.need} so far.`,"No rush. The rubble isn't going anywhere, and neither am I."]);return}
  if(foIdx()===0&&!via&&typeof SCENES!=="undefined"&&!csSeen("welcome")){playScene("welcome",()=>foBrief(o,who,false));return}
  foBrief(o,who,via)}
function marlowOffice(){const m={n:"Dr. Marlow",look:marlowNPC(false).look,talks:[["..."]]};
  m.quest=()=>{if(Q.s===15&&!Q.flag("mPost")){Q.set("mPost");talk(m.n,["Hello again.","You know what I am now. I'm still glad you came in. The field still needs doing, and I'd still rather do it with you.","Shall we?"],()=>marlowOrders(m));return}
    marlowOrders(m)};return m}
function marlowLabScene(){const m={n:"Dr. Marlow",look:marlowNPC(false).look,talks:[["..."]]};
  m.quest=()=>{talk(m.n,["So that's it. The Sealbreaker.","May I?","(He turns the casting over in his hands for a long moment. His thumb finds the edge, and stays there.)","Lighter than I expected.","(He hands it back.)","Go on. The wall at the head of the hall. I'll be in my office."],()=>{Q.set("mSeal");const me=EXP.npcs.find(p=>p.n==="Dr. Marlow");npcTravel(me,SPOTS["z-quill"].marlow,false,()=>{if(me)me.quest=marlowOffice().quest;say0("Dr. Marlow went back to his office.")})})};return m}
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(z.cls!=="z-quill"||z.special||(typeof TUT!=="undefined"&&TUT.on))return;const sp=SPOTS["z-quill"],s=Q.s,W=EXP.W,H=EXP.H;
  const addEl=(cls,x,y,html)=>{const d=document.createElement("div");d.className=cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));return d};
  let m=null,at=null;
  if(s===7&&!Q.flag("mSeal")){m=marlowLabScene();at=sp.marlowLab}
  else if((s<=7||s>=15)&&!(typeof marlowAway==="function"&&marlowAway())){m=marlowOffice();at=sp.marlow}
  if(m)EXP.npcs.push({...m,x:at[0],y:at[1],el:addEl("npc",at[0],at[1],`<span class="talkmark">...</span>`+npcSVG(m.look)),said:0});
  const[dx,dy]=sp.mdesk;const d=addEl("mapobj mdesk",dx,dy,`<svg viewBox="0 0 40 40"><rect x="3" y="16" width="34" height="5" fill="#5A3A24" stroke="#2A1A0C" stroke-width="1.2"/><rect x="5" y="21" width="4" height="15" fill="#4A2E1C"/><rect x="31" y="21" width="4" height="15" fill="#4A2E1C"/><rect x="8" y="10" width="11" height="7" fill="#E8E2D0" transform="rotate(-6 13 13)"/><rect x="23" y="11" width="5" height="6" rx="1" fill="#3A2414"/><path d="M26 11 L30 4" stroke="#2A2420" stroke-width="1"/></svg>`);
  EXP.objs.push({x:dx,y:dy,el:d,use:()=>{
    if(typeof marlowAway==="function"&&marlowAway()){const o=foCur();talk("",["Dr. Marlow's desk. The chair is pushed back and his coat is gone from the stand.",o.id==="ride"?"A note in brown ink: 'Gone to Rustvein Mine to look at rubble. Meet me there! M.'":"A note in brown ink, the letters very neat, as if he wrote it three times: 'Starfall Crater. Back late. M.'"]);return}
    if(s>=8&&s<15){talk("",["Dr. Marlow's desk. A note is weighted down with a pot of brown ink.","'Called away. Field reports in the tray. Orders in the envelopes. — M.'","The chair is pushed in. The ink is still wet."],()=>marlowOrders(null,true));return}
    talk("",["Dr. Marlow's desk. Field reports stacked square, a wire tray marked IN, and a pot of brown ink.","Nothing personal on it at all."])}});
  nearMarks()}}
/* the journal shows your field order */
function foSummary(){const i=foIdx(),o=foCur(),on=store.get("wta_fo_on",0)===1;let h="";
  if(!o)h="Every field order is done.";
  else if(!on)h=i===0?"Report to Dr. Marlow, head of the field team. His office is on the east side of the Quillmoor Institute's hall.":"Dr. Marlow has your next field order. His office is on the east side of the Quillmoor Institute's hall"+(Q.s>=8&&Q.s<15?" (while he's away, check the tray on his desk).":".");
  else h=(foReady()?"":foGoal(o)+(o.steps?"":` (${foProg()}/${o.need})`))+(foReady()?"<b>Complete!</b> Report to Dr. Marlow.":"");
  return h}
/* the journal lists EVERY live objective as its own entry: nothing gets squeezed into one slot */
function journalObjectives(){const s=Q.s,o=foCur(),on=store.get("wta_fo_on",0)===1,J=[],card=(h,p,cls)=>J.push(`<div class="bag-item key obj${cls?" "+cls:""}"><b>${h}</b><p>${p}</p></div>`),ul=L=>L.length?`<span class="obj-list">${L.map(t=>`<span>${t}</span>`).join("")}</span>`:"";
  const FQ="THE FOUNDER'S QUEST",fin=typeof FIN==="function"?FIN():0;
  if(s===0&&foFounderOpen())card(FQ,"Archivist Wren at the Institute's reading room has asked to see you. She says it's about something the founder left behind.");
  else if((s===1||s===2)&&typeof pageObjective==="function"){
    if(!Q.flag("register"))card(FQ,pageObjective());
    else{const L=[];Object.keys(PAGE_STEPS).forEach(id=>{const p=PQ(id);if(p>=PAGE_DONE[id])return;const t=PAGE_STEPS[id][Math.min(p,PAGE_STEPS[id].length-1)],z=ZONES.find(q=>q.cls===PAGE_ZONE[id]);L.push(`<b>${z?z.name:id.toUpperCase()}:</b> ${typeof t==="function"?t():t}`)});
      if(Q.flag("needBar")&&!hasTool("crowbar")&&PQ("bolt")===0)L.push("<b>TOOL:</b> You need a crowbar. Tinker's Scrapyard will have one, if you ask nicely.");
      if(Q.flag("needLamp")&&!hasTool("lamp")&&PQ("mine")<1)L.push("<b>TOOL:</b> You need a lamp. The foreman at Rustvein Mine will have lamps.");
      if(Q.flag("needBoots")&&!hasTool("boots"))L.push("<b>TOOL:</b> You need waders. The harbour office at Sunken Galleon Cove keeps a spare pair.");
      if(Q.flag("needPick")&&!hasTool("pick")&&PQ("glacier")<2)L.push("<b>TOOL:</b> You need an ice pick. The Institute's only one went out to the Frostbite Cavern station.");
      card(FQ,`Recover the founder's five pages (${pagesGot().length}/5).`+ul(L))}}
  else if(s===14){const leads=Object.keys(LEADS).filter(k=>!Q.flag(k)).map(k=>"<b>LEAD:</b> "+LEADS[k]);
    card(FQ,`Dr. Marlow is waiting for you in the hidden study. Don't go in with a hunch. He'll want ${NEED_EVIDENCE} pieces of proof that point at him, not just at the founder. You have ${EVIDENCE.filter(e=>Q.flag(e.f)).length} things in your journal. Decide for yourself which ones hold up.`+ul(leads.length?leads:["You've followed every lead."]))}
  else if(s>0&&!(s>=15&&fin>=4))card(FQ,questObjective());
  if(o)card(on?"FIELD ORDER: "+o.title.toUpperCase():"FIELD ORDERS",foSummary()+`<small class="fo-rank">RANK: ${foRank().toUpperCase()}</small>`,"fo");
  {const reg=S.caught.size,tot=ALLOYS.length,th=ALLOYS.filter(a=>a.threat),tc=th.filter(a=>S.caught.has(a.name)).length,nxt=typeof REQ_EVERY!=="undefined"?REQ_EVERY-reg%REQ_EVERY:0;
   card("FIELD WORK",`Keep registering alloys out in the field. Every map has its own, and some only turn up behind tool gates or in the dark.`+ul([`<b>ALLOYDEX:</b> ${reg} of ${tot} registered.`,`<b>THREATS CONTAINED:</b> ${tc} of ${th.length}.`,...(nxt?[`<b>REQUISITION:</b> ${nxt} more new registration${nxt>1?"s":""} until Quartermaster Hobbs owes you another slip.`]:[])]),"fw")}
  return J}
{const _oj=openJournal;openJournal=function(){_oj();const m=$("#journal");if(!m)return;const list=m.querySelector(".bag-list"),first=list.querySelector(".bag-item.key");if(first)first.remove();
  const J=journalObjectives();list.insertAdjacentHTML("afterbegin",`<h5 class="bag-h obj-h">OBJECTIVES</h5>`+J.join(""))}}
{const _qp=questPull;questPull=function(){if(Q.s===0&&(foReady()||store.get("wta_fo_on",0)!==1)&&Math.random()<.45)return ZONES.find(z=>z.cls==="z-quill");return _qp()}}


/* =============== THE BIGGER INSTITUTE: offices, a proper office for Marlow, the old lab left to rot, and a locker room with a wardrobe =============== */
SIGNS["z-quill"]={
 "1,14":["RECORDS. STAFF ONLY.","Staff files are kept by badge number.","Each cabinet opens to its owner's badge number, followed by the year they joined."],
 "40,10":["FIELD TEAM OFFICE.","Dr. Marlow, Head of Field Team.","Underneath, in several different hands over many years: 'knock', 'he won't answer', 'knock anyway'."],
 "41,22":["OLD LAB.","Out of use since before anybody can remember. Crucible key held off site.","Somebody has written 'CLEAN ME' in the dust on the sign. Somebody else has written 'NO'."],
 "13,17":["METALLURGY. Dr. I. Parr.","Knock first. Do not touch the left-hand bench. The left-hand bench knows what it did."],
 "9,31":["LOCKER ROOM.","Coats on hooks, not on floors. New coats come with promotions and a great deal of paperwork.","Try them on at the wardrobe."],
 "37,25":["SUPPLIES. Quartermaster Hobbs.","Sign for everything. Yes, everything. Yes, that too."],
 "50,32":["STAFF LOUNGE.","Mugs are not specimens. Specimens are not mugs. Label everything."]};
AMBIENT["z-quill"].push(
 {n:"Dr. Ines Parr",look:{coat:"#E8E4DA",hair:"#3A2414",hs:"bun",acc:["goggles","book"],skin:"#C88A64"},talks:[
   ["Dr. Parr, metallurgy. I study grain boundaries. They're the lines where the little crystals in a metal meet and argue.","Most people's eyes glaze over at this point. Yours are only slightly glazed. I like you."],
   ["I've had the same kettle in this office for nineteen years. It's never once boiled evenly. I've written three papers about why.","None of them were about the kettle, officially."],
   ["The old lab across the hall? Nobody's worked in it since I was a student. The dust in there has seniority over most of the staff."]]},
 {n:"Quartermaster Hobbs",look:{coat:"#5A6A4A",hair:"#8A8A8A",hs:"bald",acc:["glasses","mustache"],beard:"#8A8A8A",skin:"#E8B894"},talks:[
   ["Quartermaster Hobbs. Supplies. If it's been issued, I issued it. If it's been lost, I've written it down.","Coats come through me too. New one every time Dr. Marlow promotes somebody. He promotes people a lot less than he thinks he does."],
   ["You want to change your coat? Wardrobe in the locker room, west side. Try it on, see if it fits. It won't. None of them do. Roll the sleeves."],
   ["Somebody signed out a pair of waders in 1971 and never brought them back. I think about it most days."]]});

/* ---- the new tiles ---- */
const QPROPS={
 k:{tall:1,svg:`<rect x="9" y="2" width="22" height="33" rx="1.5" fill="#6E86A2" stroke="#2E3E54" stroke-width="1.3"/><path d="M20 3 V34" stroke="#2E3E54" stroke-width="1"/>${[6,9,12].map(y=>`<path d="M12 ${y} H18 M22 ${y} H28" stroke="#3E5068" stroke-width="1.1"/>`).join("")}<rect x="16.5" y="18" width="1.6" height="5" rx=".6" fill="#D8DEE6"/><rect x="21.9" y="18" width="1.6" height="5" rx=".6" fill="#D8DEE6"/><rect x="11" y="27" width="7" height="3" rx=".5" fill="#E8E2D0"/>`},
 b:{svg:`<rect x="3" y="17" width="34" height="6" rx="1.5" fill="#9A6A3C" stroke="#4A2E18" stroke-width="1.2"/><path d="M3 20 H37" stroke="#B88A5A" stroke-width=".8"/><rect x="6" y="23" width="3" height="11" fill="#6B4A2E"/><rect x="31" y="23" width="3" height="11" fill="#6B4A2E"/>`},
 M:{tall:1,svg:`<rect x="6" y="1" width="28" height="34" rx="2" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.4"/><ellipse cx="20" cy="15" rx="8.5" ry="11" fill="#CFE6F4" stroke="#C8A060" stroke-width="1.6"/><path d="M15 8 Q17 6 19 7" stroke="#FFFFFF" stroke-width="1.4" fill="none"/><rect x="9" y="28" width="22" height="5" fill="#5A3A24" stroke="#3A2414" stroke-width=".8"/><circle cx="20" cy="30.5" r="1" fill="#C8A060"/>`},
 F:{tall:1,svg:`<rect x="3" y="4" width="34" height="31" fill="#8A7E72" stroke="#3A342E" stroke-width="1.3"/>${[[3,4],[20,4],[3,12],[29,12],[3,20],[29,20]].map(([x,y])=>`<rect x="${x}" y="${y}" width="${x===3||x===29?8:17}" height="8" fill="none" stroke="#6A625A" stroke-width=".8"/>`).join("")}<rect x="1" y="2" width="38" height="4" fill="#5A3A24" stroke="#3A2414"/><path d="M11 35 V18 Q20 10 29 18 V35 Z" fill="#1A1210"/><path d="M14 35 Q15 27 18 30 Q19 23 22 29 Q25 24 26 35 Z" fill="#FF8A2A"/><path d="M17 35 Q18 30 20 32 Q22 29 23 35 Z" fill="#FFD66B"/><circle cx="20" cy="30" r="9" fill="#FF8A2A" opacity=".18"/>`},
 A:{svg:`<path d="M8 34 V18 Q8 11 20 11 Q32 11 32 18 V34 Z" fill="#7A2E2A" stroke="#3A1210" stroke-width="1.3"/><rect x="5" y="20" width="7" height="13" rx="3" fill="#8A3A34" stroke="#3A1210" stroke-width="1.1"/><rect x="28" y="20" width="7" height="13" rx="3" fill="#8A3A34" stroke="#3A1210" stroke-width="1.1"/><rect x="11" y="24" width="18" height="7" rx="2" fill="#9A4A40"/>${[[14,15],[20,15],[26,15]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".8" fill="#3A1210"/>`).join("")}`},
 G:{svg:`<path d="M20 26 V33 M13 34 H27" stroke="#5A3A24" stroke-width="2.4"/><path d="M8 15 A12 12 0 0 1 32 15" fill="none" stroke="#C8A060" stroke-width="1.6"/><circle cx="20" cy="15" r="9.5" fill="#6AA8D8" stroke="#2E4A6A" stroke-width="1.1"/><path d="M15 9 Q19 12 16 16 Q13 19 16 22 M23 8 Q26 11 24 14 Q27 17 25 21" fill="none" stroke="#6A9A4A" stroke-width="2.4" stroke-linecap="round"/><path d="M11 15 H29" stroke="#2E4A6A" stroke-width=".5" opacity=".6"/>`}};
const inWorn=(x,y)=>x>=37&&x<=54&&y>=13&&y<=22,inPlush=(x,y)=>x>=37&&x<=54&&y>=1&&y<=11;
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){if(EXP.zone.cls!=="z-quill"||EXP.zone.special)return _tl(c,x,y,seed,M);
  if(c==="W")return["w win",""];
  if(QPROPS[c])return[(QPROPS[c].tall?"f tl":"f pr")+(inPlush(x,y)?" fd plush":""),PS(QPROPS[c].svg)];
  if(inWorn(x,y)){if(c==="."||c==="P")return[(seed*3+y)%5===0?"f worn crk":"f worn",""];if(c===":")return["f worn wd v"+((seed+x)%3),""];
    if(c==="o"||c==="x"||c==="y")return["f pr worn",PS(BPROPS[c])];if(c==="T")return["f tl worn",PS(BPROPS.T)]}
  if(inPlush(x,y)&&c===":")return["f fd plush",""];
  const r=_tl(c,x,y,seed,M);if(inPlush(x,y)&&/\bfd\b/.test(r[0]))r[0]+=" plush";return r}}

/* ---- lab coats: each one is cut differently, not just dyed differently ---- */
const INK="#121B40";
const CUT={lab:"M12 22 Q20 19 28 22 L29.5 34 L10.5 34 Z",long:"M12 22 Q20 19 28 22 L30.4 36 L9.6 36 Z",jacket:"M12 22 Q20 19 28 22 L29 31.6 L11 31.6 Z",puff:"M11 21.6 Q20 18 29 21.6 L30.4 33.8 L9.6 33.8 Z"};
const chev=(n,col,x=10.4,y=24.6)=>Array.from({length:n},(_,i)=>`<path d="M${x-1.2} ${y+i*1.5} L${x} ${y+1.1+i*1.5} L${x+1.2} ${y+i*1.5}" stroke="${col}" stroke-width=".9" fill="none" stroke-linecap="round"/>`).join("");
const btns=(x,ys,col,r=.75)=>ys.map(y=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${col}" stroke="${INK}" stroke-width=".35"/>`).join("");
const PENS=`<rect x="13.2" y="26.5" width="4" height="3.6" rx=".6" fill="#EEF2FA" stroke="#9AA6C2" stroke-width=".7"/><path d="M14.2 26.8 V25 M16.4 26.8 V25.2" stroke-linecap="round" stroke-width="1" stroke="#E8412C"/><path d="M15.4 26.8 V24.6" stroke="#3B7BF0" stroke-width="1" stroke-linecap="round"/>`;
const COATS=[
 {id:"standard",name:"Standard Issue",desc:"White, pressed, one pocket already stained. Every recruit gets one.",how:"",cut:"lab",body:"#FFFFFF",sleeve:"#FFFFFF",cuff:"#FFFFFF",open:()=>true,
  detail:`<path d="M17 21 L20 27 L23 21" fill="#7FB6E8" stroke="${INK}" stroke-width="1.1" stroke-linejoin="round"/><path d="M20 27 L20 34" stroke="#C9D2E6" stroke-width="1"/>${PENS}<rect x="22.6" y="27" width="3.4" height="2.4" rx=".5" fill="#FFD23F" stroke="${INK}" stroke-width=".6"/>`},
 {id:"assistant",name:"Field Assistant's Coat",desc:"Blue lapels, a proper tie, sleeves rolled for work, and one chevron to prove it.",how:"Earned with your first field promotion from Dr. Marlow.",cut:"lab",body:"#F2F7FF",sleeve:"#F2F7FF",cuff:"#3B7BF0",open:()=>FO_RANKS.indexOf(foRank())>=1,
  detail:`<path d="M17 21 L20 27 L23 21" fill="#FFFFFF" stroke="${INK}" stroke-width="1" stroke-linejoin="round"/><path d="M20 21.6 L20 25.8" stroke="#1E4E9E" stroke-width="1.5" stroke-linecap="round"/><path d="M17 21 L20 27 L15.4 23.4 Z M23 21 L20 27 L24.6 23.4 Z" fill="#3B7BF0" stroke="${INK}" stroke-width=".7" stroke-linejoin="round"/><path d="M20 27 L20 34" stroke="#BFD4F4" stroke-width="1"/>${PENS}<rect x="22.6" y="27" width="3.4" height="2.6" rx=".6" fill="#3B7BF0" stroke="${INK}" stroke-width=".6"/><path d="M24.3 27.5 l.35 .75 .8 .1 -.6 .55 .15 .8 -.7 -.4 -.7 .4 .15 -.8 -.6 -.55 .8 -.1z" fill="#FFFFFF"/><path d="M10.7 33.1 L29.3 33.1" stroke="#BFD4F4" stroke-width="1"/>`,
  arms:chev(1,"#3B7BF0")},
 {id:"scientist",name:"Field Scientist's Coat",desc:"Knee-length, green lapels, elbow patches, and a belt with loops for sample vials. Two chevrons.",how:"Earned with your second field promotion.",cut:"long",body:"#EEF5EC",sleeve:"#EEF5EC",cuff:"#2E8A4A",open:()=>FO_RANKS.indexOf(foRank())>=2,
  detail:`<path d="M17 21 L20 27.4 L23 21" fill="#FFFFFF" stroke="${INK}" stroke-width="1" stroke-linejoin="round"/><path d="M17 21 L20 27.4 L14.8 24.2 L15.4 21.8 Z M23 21 L20 27.4 L25.2 24.2 L24.6 21.8 Z" fill="#2E8A4A" stroke="${INK}" stroke-width=".7" stroke-linejoin="round"/><path d="M20 27.4 L20 36" stroke="#9CCBA8" stroke-width="1"/><rect x="10.9" y="29.2" width="18.2" height="1.9" fill="#6B4424" stroke="${INK}" stroke-width=".5"/><rect x="19.1" y="29" width="1.8" height="2.3" rx=".3" fill="#C8A060" stroke="${INK}" stroke-width=".4"/>${[[13.4,"#6BE08A"],[15.2,"#7FB6E8"],[24.8,"#E8412C"]].map(([x,c])=>`<rect x="${x}" y="27.4" width="1.2" height="3" rx=".5" fill="${c}" stroke="${INK}" stroke-width=".35"/>`).join("")}<rect x="22.6" y="24.6" width="3.2" height="2.4" rx=".5" fill="#2E8A4A" stroke="${INK}" stroke-width=".6"/><path d="M10 35.2 L30 35.2" stroke="#2E8A4A" stroke-width=".9"/>`,
  arms:chev(2,"#2E8A4A")+`<ellipse cx="9.8" cy="28.4" rx="1" ry="1.5" fill="#2E8A4A" opacity=".85"/>`},
 {id:"staff",name:"Field Staff Lab Coat",desc:"A long white lab coat with a navy stand collar and knitted navy cuffs, hidden snaps down the front, a pen pocket with three navy rank bars stitched under it, and a staff ID card clipped at the chest.",how:"Earned when Dr. Marlow makes you field staff.",cut:"long",body:"#F4F7FB",sleeve:"#F4F7FB",cuff:"#22335A",open:()=>FO_RANKS.indexOf(foRank())>=3,
  detail:`<path d="M15.6 20.4 Q20 22.2 24.4 20.4 L24.6 22.6 Q20 24.2 15.4 22.6 Z" fill="#22335A" stroke="${INK}" stroke-width=".7" stroke-linejoin="round"/><path d="M16.2 21.6 Q20 23 23.8 21.6" stroke="#4A5E8A" stroke-width=".4" fill="none"/>
   <path d="M20.4 24 L20.4 36" stroke="#C9D3E6" stroke-width="1.1"/><path d="M21.2 24 L21.2 36" stroke="#22335A" stroke-width=".5"/>${btns(20.4,[25.8,28.6,31.4,34.2],"#E8EEF8",.5)}
   ${PENS}<path d="M13.4 30.8 h3.8 M13.4 31.7 h3.8 M13.4 32.6 h3.8" stroke="#22335A" stroke-width=".55" stroke-linecap="round"/>
   <path d="M24.4 23.4 L24.8 26.2" stroke="#22335A" stroke-width=".6"/><rect x="23.1" y="26.2" width="3.6" height="4.6" rx=".5" fill="#FFFFFF" stroke="${INK}" stroke-width=".5"/><rect x="23.6" y="26.7" width="1.5" height="1.7" fill="#7FB6E8"/><path d="M23.6 29.3 h2.5 M23.6 30.1 h1.8" stroke="#22335A" stroke-width=".35"/><circle cx="25.9" cy="27.4" r=".6" fill="#22335A"/>
   <path d="M11.8 33.4 h4.2 M24.2 33.4 h4.2" stroke="#C9D3E6" stroke-width=".9"/><path d="M9.8 35.5 L30.2 35.5" stroke="#22335A" stroke-width=".6"/>`,
  arms:`<path d="M9.7 25.9 L11.6 26.3" stroke="#22335A" stroke-width="1.5"/><circle cx="10.6" cy="26.1" r=".45" fill="#F4F7FB"/>`},
 {id:"duster",name:"Grunt-Proof Duster",desc:"A long charcoal duster with a shoulder cape, a popped collar, a buckled belt and an orange hem the Syndicate have learned to dread.",how:"Earned by finishing Dr. Marlow's Syndicate Trouble order.",cut:"long",body:"#3A3A42",sleeve:"#3A3A42",cuff:"#FF7A1A",open:()=>foDone("slag"),
  detail:`<path d="M20 23 L20 36" stroke="#FF7A1A" stroke-width=".6" stroke-dasharray="1 1"/><rect x="10.9" y="28.6" width="18.2" height="1.8" fill="#1E1E24" stroke="${INK}" stroke-width=".5"/><rect x="18.8" y="28.3" width="2.4" height="2.4" rx=".3" fill="none" stroke="#C8CCD2" stroke-width=".7"/><path d="M9.8 34.6 L30.2 34.6" stroke="#FF7A1A" stroke-width="1.6"/>`,
  over:`<path d="M11 21.8 Q20 17.8 29 21.8 L30 25.8 Q20 23.8 10 25.8 Z" fill="#2E2E34" stroke="${INK}" stroke-width="1" stroke-linejoin="round"/><path d="M15.4 21.2 L14.4 18.2 L17.8 20.2 Z M24.6 21.2 L25.6 18.2 L22.2 20.2 Z" fill="#2E2E34" stroke="${INK}" stroke-width=".7" stroke-linejoin="round"/><path d="M10.4 25.4 Q20 23.4 29.6 25.4" stroke="#FF7A1A" stroke-width=".6" fill="none"/>`},
 {id:"pit",name:"Pit Jacket",desc:"A short canvas work jacket with a hood, reflective bands, a zip that sticks, and a clip-on lamp.",how:"A gift from Rustvein Mine, once Nettie's lamps are lit.",cut:"jacket",body:"#6A4A2A",sleeve:"#6A4A2A",cuff:"#FFD23F",open:()=>PQ("mine")>=6,
  back:`<path d="M13.2 21 Q20 25 26.8 21 Q25.6 16.6 20 16.6 Q14.4 16.6 13.2 21 Z" fill="#5A3A1E" stroke="${INK}" stroke-width=".9"/>`,
  detail:`<path d="M20 21.6 V31.6" stroke="#C8A060" stroke-width=".9"/>${[25.2,29.2].map(y=>`<path d="M11.4 ${y} L28.6 ${y}" stroke="#FFD23F" stroke-width="1.8"/><path d="M11.4 ${y} L28.6 ${y}" stroke="#F4F4F4" stroke-width=".4"/>`).join("")}<circle cx="24.8" cy="23.4" r="1.3" fill="#FFE27A" stroke="${INK}" stroke-width=".5"/><circle cx="24.8" cy="23.4" r="2.6" fill="#FFE27A" opacity=".25"/>`},
 {id:"oilskin",name:"Harbour Oilskin",desc:"Long yellow oilskin with toggle buttons, a corduroy collar, and the sou'wester hat that goes with it.",how:"A gift from Sunken Galleon Cove, once the sea chest is open.",cut:"long",body:"#F2C230",sleeve:"#F2C230",cuff:"#1E2E4A",open:()=>PQ("wreck")>=4,
  detail:`<path d="M16 21 L20 24.4 L24 21 L24.6 22.6 L20 25.6 L15.4 22.6 Z" fill="#6A4A2A" stroke="${INK}" stroke-width=".6"/><path d="M20.8 25.6 V36" stroke="#B8901A" stroke-width=".8"/>${[27,30,33].map(y=>`<rect x="20" y="${y}" width="2.2" height=".9" rx=".45" fill="#6A4A2A" stroke="${INK}" stroke-width=".3"/><path d="M19.2 ${y+.45} h.8" stroke="${INK}" stroke-width=".4"/>`).join("")}<path d="M12.6 27.5 L16.4 27.5 M23.6 30.5 L27.4 30.5" stroke="#B8901A" stroke-width=".7"/>`,
  hat:`<path d="M13.2 11.6 Q13.4 5 20 5 Q26.6 5 26.8 11.6 Z" fill="#F2C230" stroke="${INK}" stroke-width="1.1"/><path d="M10.6 12.6 Q20 9.4 29.4 12.6 L30.8 14.4 Q20 11.6 9.2 14.4 Z" fill="#E0B020" stroke="${INK}" stroke-width="1"/><path d="M26.8 12.8 Q30.4 15 30.6 18.4 Q28.4 16.4 27 15.6 Z" fill="#E0B020" stroke="${INK}" stroke-width=".7"/>`},
 {id:"parka",name:"Frost Parka",desc:"Quilted and puffed up like a loaf, with a fur-lined hood that frames your whole face.",how:"A gift from Frostbite Cavern, once Dr. Holm is free.",cut:"puff",body:"#EAF4FC",sleeve:"#EAF4FC",cuff:"#CFB88A",open:()=>PQ("glacier")>=5,
  back:`<circle cx="20" cy="13.6" r="9.6" fill="#CFB88A" stroke="${INK}" stroke-width="1"/>${Array.from({length:14},(_,i)=>{const a=i/14*Math.PI*2;return `<circle cx="${(20+9.4*Math.cos(a)).toFixed(1)}" cy="${(13.6+9.4*Math.sin(a)).toFixed(1)}" r="1" fill="#E4D2AA"/>`}).join("")}<circle cx="20" cy="13.6" r="8" fill="#8AA2B6"/>`,
  detail:`<path d="M20 21 V33.8" stroke="#8AA2B6" stroke-width="1"/>${[24.6,27.8,31].map(y=>`<path d="M10.4 ${y} Q20 ${y+1} 29.6 ${y}" stroke="#B8CCD8" stroke-width=".8" fill="none"/>`).join("")}<path d="M9.8 33.2 Q20 35 30.2 33.2 L30.4 34.4 Q20 36.2 9.6 34.4 Z" fill="#CFB88A" stroke="${INK}" stroke-width=".6"/><rect x="22.4" y="25.4" width="3.2" height="2.2" rx=".5" fill="#3B7BF0" stroke="${INK}" stroke-width=".5"/>`},
 {id:"ember",name:"Forge Coat",desc:"Scorch-proof coat under a heavy leather apron, with gauntlet cuffs and soot that never quite washes out.",how:"A gift from Emberforge Caldera, once Brother Ashlin has his light.",cut:"lab",body:"#7A3422",sleeve:"#7A3422",cuff:"#4A2E18",open:()=>PQ("volcano")>=4,
  detail:`<path d="M16.4 22.6 L17 20.4 M23.6 22.6 L23 20.4" stroke="#3A2414" stroke-width="1.1"/><path d="M14.4 22.8 L25.6 22.8 L27 34 L13 34 Z" fill="#5A3A24" stroke="${INK}" stroke-width=".9" stroke-linejoin="round"/><rect x="18.6" y="23.6" width="2.8" height="2" rx=".3" fill="none" stroke="#C8A060" stroke-width=".7"/>${[[14.8,23.6],[25.2,23.6],[14.2,33],[25.8,33]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".5" fill="#C8A060"/>`).join("")}<ellipse cx="17" cy="29" rx="1.8" ry="1" fill="#1A1210" opacity=".35"/><ellipse cx="23.4" cy="31.4" rx="1.4" ry=".8" fill="#1A1210" opacity=".35"/><path d="M15.4 27 L24.6 27" stroke="#6E4A30" stroke-width=".6"/>`,
  arms:`<path d="M9.8 29.4 L10.2 32.4" stroke="#4A2E18" stroke-width="3.2" stroke-linecap="round"/><path d="M30.9 25.6 L32 28" stroke="#4A2E18" stroke-width="3.2" stroke-linecap="round"/>`},
 {id:"founder",name:"The Founder's Cut",desc:"A cream frock coat of a very old pattern: brown lapels, a burgundy waistcoat, brass buttons, a watch chain and a cravat. Somebody had it made for you, and won't say who.",how:"???",cut:"long",body:"#E8DCC0",sleeve:"#E8DCC0",cuff:"#6B4424",open:()=>Q.s>=15,
  detail:`<path d="M17 21 L20 29 L23 21 Z" fill="#6A1E2A" stroke="${INK}" stroke-width=".7"/>${btns(20,[25.4,27.2],"#C8A060",.5)}<path d="M17 21 L20 29 L14.6 25 L15.2 21.8 Z M23 21 L20 29 L25.4 25 L24.8 21.8 Z" fill="#6B4424" stroke="${INK}" stroke-width=".7" stroke-linejoin="round"/><path d="M18.2 20.8 Q20 24.4 21.8 20.8 Q21 23 20 25 Q19 23 18.2 20.8 Z" fill="#FFFFFF" stroke="${INK}" stroke-width=".5"/><path d="M17.8 26.6 Q19.4 28.4 21.4 26.8" stroke="#C8A060" stroke-width=".6" fill="none"/>${btns(23.4,[29.6,32.2],"#C8A060",.65)}<path d="M20 29 L20 36 M18.4 36 L20 33.6 L21.6 36" stroke="#B8A888" stroke-width=".8" fill="none"/>`}];
function coatNow(){const c=COATS.find(c=>c.id===store.get("wta_coat","standard"));return c&&c.open()?c:COATS[0]}
function playerSVG(c){c=c||coatNow();const L=MINER.split("\n");const arm=(d,col)=>`<path d="${d}" stroke="${INK}" stroke-width="3.6" stroke-linecap="round" fill="none"/><path d="${d}" stroke="${col}" stroke-width="2" stroke-linecap="round" fill="none"/>`;
  const la="M11.5 23 Q9 28 10 32",ra="M28.5 23 Q31.5 25 32 28",K=KIT[c.id]||KIT.standard,held=HELD[K[0]],ew=Array.isArray(K[1])?EYEWEAR.up(K[1][1],K[1][2]):EYEWEAR[K[1]];
  return [L[0],L[1],L[2],c.back||"",`<path d="${CUT[c.cut]}" fill="${c.body}" stroke="${INK}" stroke-width="1.6" stroke-linejoin="round"/>`,c.detail||"",c.over||"",
    arm(la,c.sleeve),`<path d="M10.05 30.6 L10.05 31.8" stroke="${c.cuff}" stroke-width="2" stroke-linecap="round"/>`,L[9],
    arm(ra,c.sleeve),`<path d="M31.5 26.6 L31.9 27.7" stroke="${c.cuff}" stroke-width="2" stroke-linecap="round"/>`,c.arms||"",held==null?L[11]+"\n"+L[12]:held,L[13],L[14],c.hat||L[15],ew==null?L[16]+"\n"+L[17]+"\n"+L[18]:ew,K[2]?MOUTH[K[2]]:L[19]].join("\n")}
/* ---- Dr. Marlow: an old tweed field coat over a waistcoat, a scarf that has seen things, a satchel, and those spectacles ---- */
function marlowSVG(){const lc="#F5F2EA",ls="#D6CFBF",tw="#98938A",tw2="#7A766E",tw3="#6A665E",hair="#231812",hl="#443024",sk="#F0C8A4",sk2="#D9A884";
 const hb=(x0,y0,w,h)=>{let o="";for(let yy=y0;yy<y0+h;yy+=1.2)for(let xx=x0;xx<x0+w;xx+=1.2)o+=`<path d="M${xx} ${yy} l.6 .6 l.6 -.6" stroke="${tw3}" stroke-width=".22" fill="none" opacity=".38"/>`;return o};
 return `<svg viewBox="0 0 40 40" aria-hidden="true"><defs><clipPath id="mjk"><path d="M15.2 20.6 L24.8 20.6 L23.8 35 L16.2 35 Z"/></clipPath></defs><ellipse cx="20" cy="37.6" rx="10" ry="2.2" fill="#000" opacity=".3"/>
<rect x="15.2" y="31" width="4.2" height="5" fill="${tw2}" stroke="${INK}" stroke-width=".6"/><rect x="20.6" y="31" width="4.2" height="5" fill="${tw2}" stroke="${INK}" stroke-width=".6"/>
<path d="M13.8 35.4 H19.6 Q19.8 37.8 18.6 37.8 H14.2 Q13.2 37.8 13.8 35.4Z M20.4 35.4 H26.2 Q26.8 37.8 25.8 37.8 H21.4 Q20.2 37.8 20.4 35.4Z" fill="#2A1A10" stroke="${INK}" stroke-width=".6"/><path d="M15 36.2 H16.8 M21.6 36.2 H23.4" stroke="#7A5A3A" stroke-width=".5"/>
<path d="M12 21.4 Q20 18.8 28 21.4 L30.4 35.2 L9.6 35.2 Z" fill="${lc}" stroke="${INK}" stroke-width="1.5" stroke-linejoin="round"/>
<path d="M15.2 20.6 L24.8 20.6 L23.8 35 L16.2 35 Z" fill="${tw}" stroke="${INK}" stroke-width=".6"/>
<g clip-path="url(#mjk)">${hb(15,20,10,15)}</g>
<path d="M16.8 20.6 L20 29.4 L23.2 20.6 Z" fill="#FFFFFF" stroke="${INK}" stroke-width=".55"/>
<path d="M17.4 20.4 L20 23 L16.6 23.6 Z M22.6 20.4 L20 23 L23.4 23.6 Z" fill="#FFFFFF" stroke="${INK}" stroke-width=".5" stroke-linejoin="round"/>
<path d="M19.1 22.6 L20.9 22.6 L21.5 28.2 L20 29.6 L18.5 28.2 Z" fill="#241F28" stroke="${INK}" stroke-width=".45"/><path d="M18.8 21.8 H21.2 L20.8 23.2 H19.2 Z" fill="#241F28" stroke="${INK}" stroke-width=".4"/>${[[19.5,24.4],[20.5,25.5],[19.5,26.6],[20.5,27.6]].map(([x,y])=>`<path d="M${x-.3} ${y} h.6" stroke="#8A8298" stroke-width=".35"/>`).join("")}
<path d="M16.8 20.6 L20 29.4 L17.2 28 L16 23.2 Z M23.2 20.6 L20 29.4 L22.8 28 L24 23.2 Z" fill="${tw2}" stroke="${INK}" stroke-width=".5" stroke-linejoin="round"/>
${[30.6,32.8].map(y=>`<circle cx="20" cy="${y}" r=".45" fill="#3A3028" stroke="${INK}" stroke-width=".25"/>`).join("")}
<path d="M15.2 20.6 L16.4 30.6 L13.4 27.2 L12.8 23 Z M24.8 20.6 L23.6 30.6 L26.6 27.2 L27.2 23 Z" fill="${lc}" stroke="${INK}" stroke-width=".75" stroke-linejoin="round"/><path d="M13.6 23.6 L14.8 24.6 M26.4 23.6 L25.2 24.6" stroke="${ls}" stroke-width=".55"/>
<path d="M16.2 35 L16.4 30.6 M23.8 35 L23.6 30.6" stroke="${INK}" stroke-width=".7"/>
<rect x="25.2" y="28.2" width="3.2" height="3" rx=".5" fill="${lc}" stroke="${ls}" stroke-width=".7"/><path d="M25.9 28.4 V26.8 M27 28.4 V26.5" stroke="#2E3548" stroke-width=".75" stroke-linecap="round"/><path d="M27.8 28.4 V27.1" stroke="#B8242A" stroke-width=".75" stroke-linecap="round"/>
<path d="M11.6 31.6 H15.2" stroke="${ls}" stroke-width=".7"/>
<path d="M12 23 Q9.4 27.6 10.4 32" stroke="${INK}" stroke-width="3.8" stroke-linecap="round" fill="none"/><path d="M12 23 Q9.4 27.6 10.4 32" stroke="${lc}" stroke-width="2.2" stroke-linecap="round" fill="none"/><path d="M9.4 31.2 L11.6 31.6" stroke="${tw}" stroke-width=".9"/>
<rect x="8.2" y="30.6" width="3.8" height="4.6" rx=".5" fill="#5A3420" stroke="${INK}" stroke-width=".6" transform="rotate(-8 10 33)"/><circle cx="10.6" cy="32.5" r="1.6" fill="${sk}" stroke="${INK}" stroke-width=".8"/>
<path d="M28 23 Q30.6 27 29.8 31.2" stroke="${INK}" stroke-width="3.8" stroke-linecap="round" fill="none"/><path d="M28 23 Q30.6 27 29.8 31.2" stroke="${lc}" stroke-width="2.2" stroke-linecap="round" fill="none"/><path d="M28.8 30.8 L30.8 30.6" stroke="${tw}" stroke-width=".9"/><circle cx="29.8" cy="32" r="1.6" fill="${sk}" stroke="${INK}" stroke-width=".8"/>
<rect x="18.3" y="18.4" width="3.4" height="2.8" fill="${sk2}" stroke="${INK}" stroke-width=".6"/>
<ellipse cx="13.1" cy="13.6" rx="1.1" ry="1.5" fill="${sk}" stroke="#121B40" stroke-width=".7"/><ellipse cx="26.9" cy="13.6" rx="1.1" ry="1.5" fill="${sk}" stroke="#121B40" stroke-width=".7"/>
<circle cx="20" cy="13" r="7" fill="${sk}" stroke="#121B40" stroke-width="1.5"/>
<ellipse cx="15.7" cy="15.8" rx="1" ry=".6" fill="#E0928A" opacity=".3"/><ellipse cx="24.3" cy="15.8" rx="1" ry=".6" fill="#E0928A" opacity=".3"/>
<path d="M12.8 12.4 Q12.4 5.4 19.4 5.2 Q26.6 5 27.2 12 Q25.6 8.8 21.6 8.6 Q18.2 8.4 16.6 7.2 Q15.4 9.8 12.8 12.4 Z" fill="${hair}" stroke="#121B40" stroke-width="1.15" stroke-linejoin="round"/><path d="M19.6 6.2 Q22.6 5.6 25 7.2" stroke="${hl}" stroke-width=".55" fill="none" stroke-linecap="round"/><path d="M13.4 11.2 Q13.6 10 14.2 9.6 M26.6 11.2 Q26.4 10 25.8 9.4" stroke="#B8B0A8" stroke-width=".7" fill="none" stroke-linecap="round"/>
<path d="M15.8 10.8 Q17.3 10.1 18.8 10.7 M21.2 10.7 Q22.7 10.1 24.2 10.8" stroke="${hair}" stroke-width=".9" fill="none" stroke-linecap="round"/>
<circle cx="17.3" cy="13.5" r=".8" fill="#121B40"/><circle cx="22.7" cy="13.5" r=".8" fill="#121B40"/><circle cx="17.65" cy="13.1" r=".32" fill="#FFFFFF"/><circle cx="23.05" cy="13.1" r=".32" fill="#FFFFFF"/>
<circle cx="17.2" cy="13.4" r="2.3" fill="rgba(200,230,255,.4)" stroke="#5A4416" stroke-width=".95"/><circle cx="22.8" cy="13.4" r="2.3" fill="rgba(200,230,255,.4)" stroke="#5A4416" stroke-width=".95"/><path d="M19.4 13.4 H20.6" stroke="#5A4416" stroke-width=".8"/><path d="M15.8 12.2 l.7 -.5" stroke="#FFFFFF" stroke-width=".4" stroke-linecap="round"/>
<path d="M24.4 11.5 L23.6 12.5 M23.95 12 L24.5 12.5" stroke="#FFFFFF" stroke-width=".4" stroke-linecap="round"/>
<path d="M20.2 14.4 Q19.5 15.6 20 16 Q20.5 16.2 21 15.9" stroke="${sk2}" stroke-width=".65" fill="none" stroke-linecap="round"/>
<path d="M18 17.3 Q20 18.5 22 17.3" stroke="#121B40" stroke-width=".9" fill="none" stroke-linecap="round"/></svg>`}
{const _n=npcSVG;npcSVG=function(L){return L&&L.marlow?marlowSVG():_n(L)}}

function coatRefresh(){const p=$("#player");if(p&&S.phase==="explore"){const b=p.querySelector(".bang");p.innerHTML=(b?b.outerHTML:`<span class="bang">!</span>`)+playerSVG()}}
function coatCheck(){const seen=store.get("wta_coats_seen",["standard"]),fresh=COATS.filter(c=>c.open()&&!seen.includes(c.id));if(!fresh.length)return;
  store.set("wta_coats_seen",[...seen,...fresh.map(c=>c.id)]);setTimeout(()=>say0(`New lab coat unlocked: ${fresh.map(c=>c.name.toUpperCase()).join(", ")}. Try it on at the wardrobe in the Institute's locker room.`),1100)}
function openWardrobe(){const m=modal("wardrobe","WARDROBE"),cur=coatNow();
  m.querySelector(".bag-list").innerHTML=`<p class="bag-empty">Coats on hooks, in a row. Pick one and try it on.</p>`+COATS.map(c=>c.open()
    ?`<div class="bag-item coat${c.id===cur.id?" on":""}"><div class="coatpv">${playerSVG(c)}</div><div><b>${c.name}</b><p>${c.desc}</p></div><button class="btn${c.id===cur.id?"":" go"}" data-coat="${c.id}" ${c.id===cur.id?"disabled":""}>${c.id===cur.id?"WEARING":"WEAR"}</button></div>`
    :`<div class="bag-item coat locked"><div class="coatpv"><svg viewBox="0 0 40 40"><path d="M12 22 Q20 19 28 22 L29.5 34 L10.5 34 Z" fill="#8A94A8" opacity=".5"/><circle cx="20" cy="13.5" r="7" fill="#8A94A8" opacity=".5"/></svg></div><div><b>Locked coat</b><p>${c.how}</p></div><span class="always">LOCKED</span></div>`).join("");
  m.querySelectorAll("[data-coat]").forEach(b=>b.onclick=()=>{store.set("wta_coat",b.dataset.coat);sfx("sel");coatRefresh();openWardrobe();say0(`You put on the ${coatNow().name.toUpperCase()}. It fits. Mostly.`)})}
{const _se=startExplore;startExplore=function(){_se();coatRefresh();coatCheck()}}
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(z.cls!=="z-quill"||z.special)return;const sp=SPOTS["z-quill"];if(!sp.wardrobe)return;const[x,y]=sp.wardrobe;
  EXP.objs.push({x,y,tile:1,use:()=>talk("",["A tall wardrobe with a mirror in the door. Every coat you've earned is hanging inside."],()=>openWardrobe())})}}


/* =============== ROOMS WITH A HISTORY: an old lab that time forgot (but nobody wrecked), a working office for the head of the field team, and the room behind the portrait =============== */
const RPROPS={
 /* the old lab: dated, not ruined */
 old_o:{svg:`<rect x="3" y="18" width="34" height="5" fill="#8A5A30" stroke="#3A2414" stroke-width="1.2"/><rect x="5" y="23" width="3" height="12" fill="#6B4424"/><rect x="32" y="23" width="3" height="12" fill="#6B4424"/><rect x="6" y="26" width="28" height="2" fill="#6B4424"/><path d="M10 18 V9 M10 11 H16" stroke="#B8863A" stroke-width="1.4"/><circle cx="16" cy="13" r="3" fill="rgba(200,230,210,.6)" stroke="#8A6A2A" stroke-width=".9"/><rect x="22" y="12" width="2.4" height="6" rx="1" fill="rgba(200,220,240,.7)" stroke="#6A7A8A" stroke-width=".6"/><rect x="26" y="13" width="2.4" height="5" rx="1" fill="rgba(230,210,160,.7)" stroke="#6A7A8A" stroke-width=".6"/><rect x="30" y="14.5" width="3" height="3.5" rx=".6" fill="#C8A060" stroke="#6A4A12" stroke-width=".6"/>`},
 old_T:{tall:1,svg:`<rect x="7" y="2" width="26" height="33" rx="1" fill="#6B4424" stroke="#3A2414" stroke-width="1.3"/><rect x="9" y="4" width="22" height="20" fill="rgba(210,230,240,.45)" stroke="#8A6A48" stroke-width=".9"/><path d="M20 4 V24 M9 14 H31" stroke="#8A6A48" stroke-width=".9"/>${[[10.5,7,"#8A3A34"],[13.5,8,"#2E6A4A"],[16.5,6.5,"#C8A060"],[21.5,7,"#3A4A7A"],[25,8,"#8A6A2A"],[28,7,"#6A3A5A"],[11,17,"#3A6A7A"],[14.5,16.5,"#9A7A3A"],[22,17,"#5A2E2A"],[26,16,"#4A6A3A"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="2.2" height="${14-y%10}" rx=".8" fill="${c}" opacity=".85"/><rect x="${x+.3}" y="${y-1}" width="1.6" height="1.2" fill="#E8E2D0"/>`).join("")}<rect x="9" y="26" width="10.5" height="7" fill="#5A3A24" stroke="#3A2414" stroke-width=".6"/><rect x="20.5" y="26" width="10.5" height="7" fill="#5A3A24" stroke="#3A2414" stroke-width=".6"/><circle cx="14" cy="29.5" r=".7" fill="#C8A060"/><circle cx="26" cy="29.5" r=".7" fill="#C8A060"/>`},
 old_x:{svg:`<path d="M6 34 Q5 20 10 14 Q20 7 30 14 Q35 20 34 34 Z" fill="#E8E2D2" stroke="#8A8272" stroke-width="1.2"/><path d="M12 16 Q14 26 11 34 M20 11 Q22 24 19 34 M28 16 Q26 26 29 34" stroke="#C8C0AE" stroke-width="1" fill="none"/><path d="M8 33 Q20 36 32 33" stroke="#B8B09E" stroke-width="1" fill="none"/>`},
 old_y:{svg:`<ellipse cx="20" cy="33.5" rx="9" ry="2" fill="#6B4424"/><path d="M20 33 V14" stroke="#8A6A2A" stroke-width="1.4"/><circle cx="20" cy="25" r="6.5" fill="#C87A3A" stroke="#6A3A14" stroke-width="1.2"/><path d="M15 23 Q20 20 25 23" stroke="#E8A868" stroke-width="1" fill="none"/><path d="M20 18.5 Q27 12 33 16 L33 20" stroke="#B8863A" stroke-width="1.6" fill="none"/><rect x="31" y="20" width="4" height="5" rx="1" fill="rgba(200,230,240,.6)" stroke="#6A7A8A" stroke-width=".6"/><path d="M14 30 Q20 34 26 30" stroke="#1A1210" stroke-width="1" fill="none" opacity=".4"/>`},
 q:{tall:1,svg:`<path d="M10 35 L13 20 M30 35 L27 20" stroke="#6B4424" stroke-width="2"/><rect x="5" y="3" width="30" height="20" rx="1" fill="#2E3A32" stroke="#6B4424" stroke-width="2"/><path d="M9 8 H19 M9 11.5 H24 M9 15 H16 M21 15 L24 18 L27 12" stroke="#E8E4D8" stroke-width=".8" opacity=".8" fill="none"/><circle cx="29" cy="8" r="2.4" fill="none" stroke="#E8E4D8" stroke-width=".7" opacity=".8"/><rect x="8" y="23" width="6" height="1.4" fill="#F4F0E4"/>`},
 v:{svg:`<rect x="10" y="12" width="20" height="22" rx="3" fill="#2E2A28" stroke="#121010" stroke-width="1.3"/><rect x="13" y="20" width="14" height="9" rx="1.5" fill="#1A1210"/><path d="M15 29 Q17 24 20 27 Q23 23 25 29 Z" fill="#FF8A2A" opacity=".85"/><path d="M18 12 V4" stroke="#3A3432" stroke-width="3"/><path d="M22 12 Q26 8 26 12" fill="#8A8278"/><ellipse cx="25" cy="11.5" rx="3.6" ry="2" fill="#8A8278" stroke="#3A3432" stroke-width=".8"/><path d="M28 10 L30.5 8.5" stroke="#8A8278" stroke-width="1"/>`},
 /* the field team office */
 f:{tall:1,svg:`<rect x="9" y="3" width="22" height="32" rx="1" fill="#7A847E" stroke="#3A4440" stroke-width="1.3"/>${[4,14,24].map(y=>`<rect x="11" y="${y+1}" width="18" height="8" fill="#8A948E" stroke="#3A4440" stroke-width=".8"/><rect x="17" y="${y+3.5}" width="6" height="1.8" rx=".8" fill="#3A4440"/><rect x="18" y="${y+6}" width="4" height="1.6" fill="#F4F0E4"/>`).join("")}`},
 e:{tall:1,svg:`<rect x="7" y="4" width="26" height="31" fill="#5A3A24" stroke="#2A1A0C" stroke-width="1.3"/><rect x="9" y="6" width="22" height="18" fill="rgba(215,235,245,.5)" stroke="#C8A060" stroke-width=".9"/><path d="M9 15 H31" stroke="#C8A060" stroke-width=".8"/>${[[11,9.5,"#9AA0A8"],[17,10,"#C8A060"],[23,9.5,"#8A5A3A"],[27,10.5,"#6AB4E0"],[12,19,"#B87333"],[18,19.5,"#D8D8D8"],[24,18.5,"#6A7A8A"]].map(([x,y,c])=>`<path d="M${x} ${y+3} L${x+1.5} ${y} L${x+3.2} ${y+1.4} L${x+2.6} ${y+3.4} Z" fill="${c}" stroke="#2A2420" stroke-width=".4"/>`).join("")}<rect x="9" y="26" width="22" height="7" fill="#4A2E1C"/><rect x="17" y="28.5" width="6" height="1.6" rx=".7" fill="#C8A060"/>`},
 r:{svg:`<ellipse cx="20" cy="18" rx="12" ry="5" fill="#7A5232" stroke="#3A2414" stroke-width="1.2"/><path d="M20 23 V33 M14 34 H26" stroke="#5A3A24" stroke-width="2.4"/><path d="M17 16 h4 v-4 h-4 z" fill="#F4F0E4" stroke="#8A8272" stroke-width=".5"/><path d="M24 17 q2 -3 3 0 z" fill="#E8E2D0" stroke="#8A8272" stroke-width=".5"/>`},
 m:{svg:`<rect x="1" y="14" width="38" height="8" fill="#6B4424" stroke="#3A2414" stroke-width="1.2"/><rect x="4" y="22" width="3" height="13" fill="#5A3A24"/><rect x="33" y="22" width="3" height="13" fill="#5A3A24"/><path d="M0 10 L40 10 L38 15 L2 15 Z" fill="#E8DCB8" stroke="#8A7A5A" stroke-width=".8"/><path d="M5 12 Q12 10 18 12.5 T32 12 M9 13.6 Q16 12.6 24 13.8" stroke="#6A8A5A" stroke-width=".9" fill="none"/><circle cx="14" cy="12" r=".8" fill="#C8242A"/><circle cx="27" cy="12.6" r=".8" fill="#C8242A"/><path d="M14 12 L27 12.6" stroke="#C8242A" stroke-width=".4" stroke-dasharray=".8 .6"/>`},
 h:{tall:1,svg:`<path d="M20 5 V34 M13 35 H27" stroke="#5A3A24" stroke-width="2.2"/><path d="M14 8 L20 6 L26 8" stroke="#5A3A24" stroke-width="1.6" fill="none"/><path d="M13 9 Q12 20 14 28 L26 28 Q28 20 27 9 Q20 7 13 9 Z" fill="#F2EEE2" stroke="#8A8272" stroke-width="1"/><path d="M17 9 L20 16 L23 9" fill="none" stroke="#C8C0AE" stroke-width=".8"/><ellipse cx="20" cy="4.5" rx="6" ry="1.6" fill="#4A3A2A"/><rect x="16.5" y="1" width="7" height="4" rx="1.4" fill="#4A3A2A"/>`},
 u:{svg:`<rect x="3" y="20" width="34" height="4" fill="#7A847E" stroke="#3A4440" stroke-width="1"/><rect x="5" y="24" width="3" height="11" fill="#5A6460"/><rect x="32" y="24" width="3" height="11" fill="#5A6460"/><path d="M14 20 V17 H22" stroke="#2E3440" stroke-width="2" fill="none"/><path d="M19 17 L16 7" stroke="#2E3440" stroke-width="3" stroke-linecap="round"/><rect x="14" y="4.5" width="4" height="3" rx=".6" fill="#2E3440"/><rect x="12" y="16" width="10" height="1.4" fill="#9AA6B4"/><rect x="26" y="15" width="7" height="5" fill="#F4F0E4" stroke="#8A8272" stroke-width=".5"/>`},
 n:{svg:`<rect x="3" y="18" width="34" height="5" fill="#8A6A48" stroke="#3E2A18" stroke-width="1"/><rect x="5" y="23" width="3" height="12" fill="#6B4A2E"/><rect x="32" y="23" width="3" height="12" fill="#6B4A2E"/>${[[7,12,"#9AA0A8"],[13,13,"#B87333"],[19,11.5,"#6A7A8A"],[26,12.5,"#C8A060"]].map(([x,y,c])=>`<path d="M${x} ${y+6} L${x+2} ${y} L${x+4.5} ${y+2} L${x+4} ${y+6} Z" fill="${c}" stroke="#2A2420" stroke-width=".5"/>`).join("")}<path d="M5 18 L35 18" stroke="#F4F0E4" stroke-width=".6"/>`},
 /* the room behind the portrait */
 N:{tall:1,svg:`<rect x="4" y="3" width="32" height="24" fill="#B8905A" stroke="#5A3A1E" stroke-width="1.5"/>${[[7,6,-6],[16,5,4],[25,7,-3],[8,15,5],[18,15,-4],[27,16,6]].map(([x,y,r])=>`<rect x="${x}" y="${y}" width="7" height="8" fill="#F4F0E4" stroke="#8A8272" stroke-width=".4" transform="rotate(${r} ${x+3.5} ${y+4})"/><circle cx="${x+3.5}" cy="${y+1}" r=".7" fill="#C8242A"/><path d="M${x+1} ${y+4} h5 M${x+1} ${y+6} h4" stroke="#8A8272" stroke-width=".4"/>`).join("")}<path d="M10.5 7 L19.5 6 L28.5 8 M11.5 16 L21.5 16 L30.5 17" stroke="#C8242A" stroke-width=".4"/>`},
 B:{svg:`<rect x="3" y="14" width="34" height="14" rx="1.5" fill="#5A3A24" stroke="#2A1A0C" stroke-width="1.2"/><rect x="5" y="12" width="30" height="12" rx="2" fill="#8A7A6A" stroke="#3A2E24" stroke-width="1"/><rect x="6" y="12.6" width="8" height="10.6" rx="2" fill="#F4F0E4" stroke="#8A8272" stroke-width=".7"/><path d="M15 13 Q25 11 34 14 L34 23.4 L15 23.4 Z" fill="#6A2E3A" stroke="#3A1420" stroke-width=".8"/><path d="M16 16 H33 M16 19.6 H33" stroke="#8A4A56" stroke-width=".7"/><rect x="4" y="28" width="3" height="6" fill="#4A2E1C"/><rect x="33" y="28" width="3" height="6" fill="#4A2E1C"/>`},
 t:{svg:`<rect x="6" y="17" width="28" height="16" rx="2" fill="#6A4A2A" stroke="#2A1A0C" stroke-width="1.2"/><path d="M6 21 Q20 13 34 21" fill="#7A5634" stroke="#2A1A0C" stroke-width="1.2"/><path d="M6 24 H34 M13 17 V33 M27 17 V33" stroke="#4A5058" stroke-width="1.2"/><rect x="18" y="22" width="4" height="4" rx=".8" fill="#C8A060" stroke="#6A4A12" stroke-width=".6"/><path d="M8 29 L14 26 M26 30 L32 27" stroke="#E8E2D0" stroke-width=".7" opacity=".5"/>`},
 j:{svg:`<ellipse cx="20" cy="34" rx="7" ry="1.6" fill="#3A2414"/><path d="M20 33 V20" stroke="#8A6A2A" stroke-width="1.6"/><path d="M13 20 H27" stroke="#8A6A2A" stroke-width="1.4"/>${[14,20,26].map(x=>`<rect x="${x-1}" y="14" width="2" height="6" fill="#F4ECD8" stroke="#B8A888" stroke-width=".4"/><path d="M${x} 14 Q${x-1} 11.5 ${x} 10 Q${x+1} 11.5 ${x} 14 Z" fill="#FFB84A"/><circle cx="${x}" cy="12" r="3" fill="#FFD66B" opacity=".25"/>`).join("")}<path d="M15 20 Q14 23 14.6 24.6" stroke="#F4ECD8" stroke-width=".8" fill="none"/>`}};
const inOffice=(x,y)=>x>=37&&x<=54&&y>=1&&y<=11,inOldLab=(x,y)=>x>=37&&x<=54&&y>=13&&y<=22;
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const z=EXP.zone;
  if(z.special==="study"){if(RPROPS[c])return[(RPROPS[c].tall?"f tl":"f pr")+" oak",PS(RPROPS[c].svg)];if(c==="x")return["f tl oak",PS(ZPROPS["z-quill"].x.svg)];if(c==="A")return["f pr oak",PS(QPROPS.A.svg)];if(c==="r")return["f pr oak",PS(RPROPS.r.svg)];
    if(c===":")return["f fd plush",""];if(c==="."||c==="P")return["f oak",""];return _tl(c,x,y,seed,M)}
  if(z.cls!=="z-quill"||z.special)return _tl(c,x,y,seed,M);
  if(inOldLab(x,y)){const k=RPROPS["old_"+c]||(c==="q"||c==="v"?RPROPS[c]:null);if(k)return[(k.tall?"f tl":"f pr")+" dated",PS(k.svg)];if(c==="S")return["f pr dated",PS(SIGNPOST)];if(c==="."||c==="P"||c===":")return["f dated"+((seed+y)%7===0?" stain":""),""]}
  if(inOffice(x,y)){const rug=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>(M[y+dy]||"")[x+dx]===":").length>=2,under=rug?" fd plush":" oak";
    const src=RPROPS[c]||QPROPS[c]||(c==="x"?{tall:1,svg:ZPROPS["z-quill"].x.svg}:c==="y"?{svg:ZPROPS["z-quill"].y.svg}:c==="S"?{svg:SIGNPOST}:null);
    if(src)return[(src.tall?"f tl":"f pr")+under,PS(src.svg)];if(c==="."||c==="P")return["f oak",""]}
  return _tl(c,x,y,seed,M)}}
/* the study, rebuilt: somebody has lived here for a very long time */
Object.assign(STUDY,{sub:"Behind the portrait. A narrow bed, a stove, a pinboard of names. Somebody has lived here for a very long time.",cls:"z-quill",map:["####################", "#xxx..N...N..xxxv..#", "#................jB#", "#.A.r.......e......#", "#......:::::::.....#", "#.t....:::::::...t.#", "#x.....:::::::.....#", "#x..............j..#", "#........P.........#", "####################"]});
/* Dr. Marlow: an old-fashioned lab coat, worn over a waistcoat, with the scarf and satchel he never takes off */
/* (marlowSVG: superseded; the version in use is further up) */
/* the journal lists every favour you've taken on, including the ones that hand out tools, whether or not the founder's quest has started */
{const _oj=openJournal;openJournal=function(){_oj();const m=$("#journal");if(!m)return;const list=m.querySelector(".bag-list"),L=[],hunting=Q.s===1||Q.s===2,step=(id,p)=>{const t=PAGE_STEPS[id][p];return typeof t==="function"?t():t};
  const b=PQ("bolt");if(b===1)L.push(["Favour: Bolt",Q.flag("boltWin")?"Tell Bolt the Syndicate grunt has been seen off. He owes you a crowbar.":"See off the Syndicate grunt prowling Tinker's Scrapyard, then go back to Bolt for a crowbar."]);
  if(!hunting){const mn=PQ("mine");if(mn>=1&&mn<=2)L.push(["Favour: Foreman Dray",step("mine",mn)]);if(mn>=3&&mn<=5)L.push(["Favour: Nettie Crane",step("mine",mn)]);
    const g=PQ("glacier");if(g===2)L.push(["Favour: Ole",step("glacier",2)]);if(g===3)L.push(["Favour: Ole",step("glacier",3)]);if(g===4&&Q.s<1)L.push(["Dr. Holm","Dr. Holm is free and back in her research hut."])}
  const addHead=()=>{const f=list.querySelector(".bag-item.side");if(f&&!list.querySelector(".sq-h")){const h=document.createElement("h5");h.className="bag-h sq-h";h.textContent="SIDE QUESTS";list.insertBefore(h,f)}};
  if(!L.length){addHead();return}const html=L.map(([t,x])=>`<div class="bag-item clue side"><b>${t}</b><p>${x}</p></div>`).join("");
  const firstSide=list.querySelector(".bag-item.side"),anchor=firstSide||list.querySelector(".bag-h")||null;const tmp=document.createElement("div");tmp.innerHTML=html;[...tmp.children].forEach(el=>list.insertBefore(el,anchor));addHead()}}


/* =============== THE PAGE TRIALS: each page now costs something. Oil in the dark, a turning tide, a flame that won't travel, and tests with no safety net. =============== */
const OIL=55,TIDE=18,FLAME=34;
const darkAt=(x,y)=>{const c=tileAt(x,y);return c==="d"||(EXP.zone.cls==="z-mine"&&!EXP.zone.special&&c===","&&x<=17&&y<=15)};
/* ---- the unlit workings drink your lamp oil ---- */
{const _st=step;step=function(dx,dy){const px=EXP.x,py=EXP.y,wasDark=darkAt(px,py),r=_st(dx,dy);if(EXP.x===px&&EXP.y===py||S.phase!=="explore")return r;
  const now=tileAt(EXP.x,EXP.y);
  /* oil */
  if(darkAt(EXP.x,EXP.y)){if(!wasDark){EXP.oil=OIL;EXP.lit=[px,py];say0(`Your pit lamp flares up. Oil for about ${OIL} steps in the dark.`)}else{EXP.oil--;
      if(EXP.oil===20||EXP.oil===10||EXP.oil===5)say0(`Your lamp is burning low: about ${EXP.oil} steps of oil left.`);
      if(EXP.oil<=0){const[lx,ly]=EXP.lit||[EXP.x,EXP.y];EXP.x=lx;EXP.y=ly;placePlayer(true);sfx("bump");say0("Your lamp gutters and dies. You feel your way along the wall until you're back in the light. The oil can in the lamp room is always full.");EXP.oil=OIL}}}
  /* tide */
  if(EXP.zone.cls==="z-wreck"&&PQ("wreck")===2){const inLagoon=now==="w"&&EXP.x>=10&&EXP.x<=19&&EXP.y>=7&&EXP.y<=13;
    if(inLagoon){EXP.tide=(EXP.tide||0)+1;if(EXP.tide===TIDE-6)say0("The water's rising round your knees. Not long now.");
      if(EXP.tide>=TIDE){EXP.tide=0;EXP.x=9;EXP.y=13;placePlayer(true);sfx("splash");tideMoveKey();say0("The tide turns and a wave knocks you flat. You crawl back up the beach. Somewhere out there, the key has shifted.")}}
    else EXP.tide=0}
  /* the eternal flame */
  if(PQ("volcano")===3){if(!EXP.flameOn){EXP.flameOn=true;EXP.flameSteps=0}EXP.flameSteps++;
    if(now===","){flameOut("Your boot scuffs the rubble and a breath of grit puts the flame out.")}
    else if(EXP.flameSteps>FLAME)flameOut("The flame shrinks to a blue bead and goes out. It won't live long away from the stones.");
    else if(EXP.flameSteps===FLAME-8)say0("The flame in your lamp is shrinking.")}
  return r}}
function flameOut(msg){EXP.flameOn=false;setPQ("volcano",2);say0(msg+" Back to the ring of stones.")}
{const _se=startExplore;startExplore=function(){if(PQ("volcano")===3){EXP.flameOn=false;setPQ("volcano",2);setTimeout(()=>say0("The flame in your lamp didn't survive the journey. Brother Ashlin's light will have to be carried by a shorter road."),1200)}EXP.tide=0;_se()}}
/* ---- the tide moves Fenn's key about ---- */
function tideSpots(){const M=MAPS["z-wreck"],L=[];for(let y=7;y<=13;y++)for(let x=10;x<=19;x++)if(M[y][x]==="w"&&Math.max(Math.abs(x-13),Math.abs(y-10))<=4)L.push([x,y]);return L}
function tideKeySpot(){const L=tideSpots();let i=store.get("wta_tidekey",-1);if(i<0||i>=L.length){i=Math.random()*L.length|0;store.set("wta_tidekey",i)}return L[i]}
function tideMoveKey(){const L=tideSpots();let i=store.get("wta_tidekey",0),j=i;while(L.length>1&&j===i)j=Math.random()*L.length|0;store.set("wta_tidekey",j);EXP.hidden=(EXP.hidden||[]).filter(h=>h.q!=="lagoonKey");questSeed()}
/* salt water: the dowsing meter can't feel anything in the lagoon */
{const _d=dowse;dowse=function(){const all=EXP.hidden||[],keep=all.filter(h=>!h.nodowse);EXP.hidden=keep;try{_d()}finally{EXP.hidden=all}}}

/* ---- trials: a sample with no safety net ---- */
function startTrial(T){EXP.trial=T;encounter()}
{const _pa=pickAlloy;pickAlloy=function(kind,used){if(EXP.trial){for(let i=0;i<40;i++){const a=_pa(kind,used);if(!a.threat&&!a.quest)return a}}return _pa(kind,used)}}
{const _sr=startRound;startRound=function(){const T=EXP.trial,m=S.mode;if(T)S.mode="who";_sr();S.mode=m;
  if(T&&S.r){EXP.trial=null;const r=S.r;r.trial=T;r.tries=r.maxTries=T.scans||3;if(r.duel){r.duel.T=T.clock||60;if(typeof duelHud==="function")duelHud()}renderAll();setTimeout(()=>say(T.intro),400)}}}
{const _h=hint;hint=function(){if(S.r&&S.r.trial){say("No hints in a trial. Trust your tests.");return}_h()}}
{const _lh=letterHint;letterHint=function(){if(S.r&&S.r.trial){say("No hints in a trial. Trust your tests.");return}_lh()}}
{const _iu=itemUsable;itemUsable=function(k){if(S.r&&S.r.trial&&S.phase==="round")return false;return _iu(k)}}
{const _w=win;win=function(){const r=S.r;_w();if(r&&r.trial&&r.trial.onWin)r.trial.onWin()}}
{const _l=lose;lose=function(ran){const r=S.r;_l(ran);if(r&&r.trial&&r.trial.onLose)r.trial.onLose()}}
/* Foreman Grist doesn't play fair */
{const _sc=slagChallenge;slagChallenge=function(g){if(g.page&&!g.done)EXP.trial={intro:"FOREMAN GRIST'S RULES: a nameless sample, no hints, no items, three scans, and a short clock. Name it and find what's in it before he fences it!",clock:60,scans:3};_sc(g)}}


/* =============== SUPPLY: fewer things lying about, and threat gear only comes signed out from Quartermaster Hobbs =============== */
const THREAT_KIT={patch:{rank:0,cap:3},cloth:{rank:1,cap:2},stasis:{rank:2,cap:2}};
/* what can turn up on the ground, in duels, or from a boss grunt */
const FIND_W={cell:6,guide:4,sieve:4,charm:2,quiet:6,lure:6,glint:4,decoy:3};
const DUEL_W={cell:4,guide:3,sieve:3,quiet:3,lure:3,glint:2,decoy:4,timer:5};
function rollFrom(W){const ks=Object.keys(W);let t=ks.reduce((s,k)=>s+W[k],0),r=Math.random()*t;for(const k of ks){r-=W[k];if(r<=0)return k}return ks[0]}
/* (rollItem: superseded; the version in use is further up) */

/* ---- requisition slips: earned by containing threats and by filling the Alloydex ---- */
const REQ_EVERY=8;
function rankNum(){const r=FO_RANKS.indexOf(foRank());return store.get("wta_q",0)>=1?Math.max(r,2):r}
function reqEarned(){return store.get("wta_req_tw",0)+Math.floor(S.caught.size/REQ_EVERY)}
function reqLeft(){return Math.max(0,reqEarned()-store.get("wta_req_sp",0))}
{const _w=win;win=function(){const r=S.r,before=reqEarned();_w();if(r&&r.a&&r.a.threat&&!r.duel&&!r.trial&&!(typeof TUT!=="undefined"&&TUT.on))store.set("wta_req_tw",store.get("wta_req_tw",0)+1);
  if(reqEarned()>before)setTimeout(()=>say("That's worth a requisition slip. Quartermaster Hobbs will sign something out for it."),5200)}}

function hobbsDesk(p){
  const rank=rankNum(),first=!store.get("wta_req_first",0);
  if(first){talk(p.n,["You're the new recruit. Right. Standard issue: one containment patch. One.","Anything else for the threat cases, you sign for. And you don't sign for anything unless you've earned a slip.",
      "One slip for every threat you bring in contained. One for every "+REQ_EVERY+" new entries in your Alloydex. Paperwork is how I know you're still alive."],
    ()=>{store.set("wta_req_first",1);giveItem("patch");say0("You got a CONTAINMENT PATCH!")});return}
  if(!reqLeft()){talk(p.n,[["No slip, no kit. I don't make the rules. I did write them down, though.","Contain a threat or fill some more of your Alloydex, then come and see me.","The cage is locked. The cage stays locked. Come back with a slip."][Math.random()*3|0]]);return}
  talk(p.n,["A slip. Signed and everything. Let's see what I can let you have."],()=>hobbsCage(p,rank))}
function hobbsCage(p,rank){const m=modal("hobbs","SUPPLY CAGE");const list=m.querySelector(".bag-list");
  const row=k=>{const K=THREAT_KIT[k],have=BAG[k]||0,locked=rank<K.rank,full=have>=K.cap;
    const why=locked?"Not cleared for this yet. Hobbs wants a higher field rank on your badge.":full?"You're carrying as many as Hobbs will let you.":"";
    return`<div class="bag-item">${itemIcon(k,34)}<div><b>${ITEMS[k].name} <span>×${have}</span></b><p>${why||ITEMS[k].desc}</p></div><button class="btn" data-sign="${k}" ${locked||full?"disabled":""}>SIGN</button></div>`};
  list.innerHTML=`<p class="bag-empty">One item per slip. Hobbs is watching the pen.</p>`+Object.keys(THREAT_KIT).map(row).join("");
  list.querySelectorAll("[data-sign]").forEach(b=>b.onclick=()=>{const k=b.dataset.sign;m.hidden=true;store.set("wta_req_sp",store.get("wta_req_sp",0)+1);giveItem(k);sfx("pickup");
    talk(p.n,[["Signed, dated, initialled. Bring back the wrapper.","Mind you don't waste it. I'll know. I always know.","There. Now I've got to reorder that. Thank you so much."][Math.random()*3|0],`(You got a ${ITEMS[k].name.toUpperCase()}!)`])});
  const back=()=>{m.hidden=true};m.querySelector(".bag-top .btn").onclick=back;m.onclick=e=>{if(e.target===m)back()}}
{const h=AMBIENT["z-quill"].find(p=>p.n==="Quartermaster Hobbs");if(h)h.quest=function(){hobbsDesk(this);return true}}

/* the bag says where threat gear comes from */
{const _rb=renderBag;renderBag=function(){_rb();const m=$("#bag");if(!m||m.hidden)return;if(THREAT_KEYS_HELD())return;const l=m.querySelector(".bag-list");
  const p=document.createElement("p");p.className="bag-empty";p.textContent="No threat gear. Quartermaster Hobbs keeps it locked in the supply cage at the Institute, and he only signs it out against a requisition slip.";l.appendChild(p)}}
function THREAT_KEYS_HELD(){return Object.keys(THREAT_KIT).some(k=>BAG[k])}


