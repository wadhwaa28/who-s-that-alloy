/* =============== HAND-LAID MAPS: what each tile is, what you can read, and what your tools can open =============== */
/* legend: # wall  . floor  : laid floor (planks, rugs, snow...)  , rubble  = path/rails/bridge  ~ deep liquid
   o T x y  things that belong to that place  L wall lamp  S sign  c nailed crate  K cracked rock or old ice
   w shallow water (waders)  d unlit tunnel (lamp) */
const SIGNS={
 "z-mine":{"36,6":["THE WIDOW'S SEAM.","Closed by order of the Quillmoor Institute. The rope is there for a reason. The reason is not a nice one."],
   "11,14":["STORES.","Crates to be opened by the foreman only.","Underneath, in pencil: 'the foreman has lost the crowbar again'."],
   "6,17":["FOREMAN'S OFFICE.","Knock. If nobody answers, knock louder. Then give up and go and find him."]},
 "z-scrap":{"31,15":["EAST HEAPS CLOSED.","Do not climb the fence. Do not move the crate. Do not ask why. I mean it. — Bolt"],
   "25,20":["WEIGHBRIDGE.","All loads weighed. All weights final. Arguing with the scale is not permitted and has never once worked."]},
 "z-wreck":{"7,11":["HARBOUR OFFICE.","A note is nailed under the sign: 'GONE OUT TO THE WRECK AT LOW WATER. BACK WHEN THE TIDE TURNS. — CAPT. Y. FENN'","Underneath, smaller: 'Spare waders are in the crate. The crate is nailed shut because SOME PEOPLE borrow things.'"]},
 "z-volcano":{"7,9":["EMBERFORGE.","Once the finest forge in three counties. Now mostly a roof, and not much of one."],"22,8":["A slate propped against the standing stones, chalked in a careful hand:","'GONE INTO RETREAT IN THE LAVA TUBE, BEYOND THE EAST RIVER. I WILL RETURN WHEN THE RIVERS GO DIM.'","'The boulder is there so that visitors take the hint. — Brother A.'"]},
 "z-vault":{"5,17":["READING ROOM.","Visitors must sign the book. The book must not be eaten.","(There was an incident. We do not discuss the incident.)"]},
 "z-reactor":{"4,3":["CONTROL ROOM.","Every switch in this room is off. Please do not check."]},
 "z-glacier":{"5,7":["RESEARCH HUT No. 1.","Institute property since the first winter. Wipe your boots. Shut the door. The cold gets in and then it won't leave.","Pinned inside the door, where something else was pinned for a very long time: 'Took the founder's page into the deep grotto with me, for luck. Back by supper. — P.H.'"]},
 "z-quill":{"8,12":["RECORDS. STAFF ONLY.","Staff files are kept by badge number.","Each cabinet opens to its owner's badge number, followed by the year they joined."],
   "34,6":["OLD LAB.","Crucible out of use. Key held off site. Please stop asking the archivist."],
   "34,12":["FIELD TEAM OFFICE.","Dr. Marlow, Head of Field Team.","Underneath, in several different hands over many years: 'knock', 'he won\'t answer', 'knock anyway'."]},
 "z-crater":{"30,4":["OBSERVATORY.","Viewing by projector only. Never look at the crater directly.","The film vault door caved in the winter of the big frost. Mind the rubble."]}};

/* ---- tools: you keep these forever, and each one opens a different kind of place ---- */
const TOOLS={
 lamp:{name:"Miner's Lamp",desc:"Nettie's spare, trimmed for forty years out of habit. Unlit tunnels are walkable while you carry it.",icon:`<path d="M9 8 H15 L16 11 H8 Z" fill="#6A4A12"/><rect x="8" y="11" width="8" height="9" rx="1.5" fill="rgba(255,230,150,.8)" stroke="#6A4A12" stroke-width="1.2"/><path d="M12 13 Q10.5 15.5 12 17.5 Q13.5 15.5 12 13Z" fill="#FF9A2A"/><path d="M9.5 8 Q12 3 14.5 8" fill="none" stroke="#6A4A12" stroke-width="1.2"/><rect x="7.5" y="20" width="9" height="2" rx=".6" fill="#6A4A12"/>`},
 crowbar:{name:"Crowbar",desc:"Bolt's second-best. His best one has a name. Pries open any crate that's been nailed shut.",icon:`<path d="M6 20 L16 6 Q17.5 4 19 5 Q20 6 18.5 7.2" fill="none" stroke="#B8242A" stroke-width="2.6" stroke-linecap="round"/><path d="M6 20 L4.5 18.6" stroke="#B8242A" stroke-width="2.6" stroke-linecap="round"/>`},
 boots:{name:"Wading Boots",desc:"Captain Fenn's old waders, dry to the hip. Shallow water is walkable while you wear them.",icon:`<path d="M8 3 H14 V15 Q14 16.5 15.5 17 L19 18 Q20.5 18.5 20.5 20 V21 H7 V15 Z" fill="#3A6A4A" stroke="#1E3A28" stroke-width="1.2" stroke-linejoin="round"/><path d="M7 21 H20.5" stroke="#1E3A28" stroke-width="2"/><path d="M8 6 H14" stroke="#6A9A7A" stroke-width="1"/><path d="M3 20 Q5 18.5 7 20 M21 20 Q22 19 23 20" stroke="#6AB4E0" stroke-width="1" fill="none"/>`},
 pick:{name:"Ice Pick",desc:"Institute issue, older than Dr. Holm. Splits old ice and rotten rock alike.",icon:`<path d="M12 7 V21" stroke="#8A5A34" stroke-width="2.2" stroke-linecap="round"/><path d="M4 8 Q12 3 20 8 L18 8.6 Q12 5.5 6 8.6 Z" fill="#AAB6C2" stroke="#4A5664" stroke-width="1"/><path d="M4 8 L3 10" stroke="#4A5664" stroke-width="1.3"/>`}};
const KEEPER_TOOL={};
function toolList(){return store.get("wta_tools",[])}
function hasTool(k){return toolList().includes(k)}
function giveTool(k){const l=toolList();if(!l.includes(k)){l.push(k);store.set("wta_tools",l)}litUpdate();sfx("pickup")}
function litUpdate(){const m=$("#mapwrap");if(m)m.classList.toggle("lit",hasTool("lamp"))}
const KEEPER_TOOL_OLD={"z-mine":["lamp",["Hold up. You're not going anywhere off the rails without a light.","The north tunnels haven't seen a lamp since I retired. Here. My spare. Keep it trimmed.","(You got the MINER'S LAMP. Unlit tunnels are walkable now.)"]],
 "z-scrap":["crowbar",["You're gonna want to open crates. Everybody does. At least do it with the right tool.","Second-best crowbar. My best crowbar is called Doreen and you can't have her.","(You got the CROWBAR. Nailed-shut crates can be opened now.)"]],
 "z-wreck":["boots",["You'll want to get out to that hull. Everybody does, once.","Take my old waders. The shallows are kind if you know where to put your feet, and these know.","(You got the WADING BOOTS. Shallow water is walkable now.)"]],
 "z-glacier":["pick",["If you're going to poke about in my caverns, don't use your hands. Or your face.","Institute ice pick. Splits old ice and rotten rock alike. It's older than I am, so be nice to it.","(You got the ICE PICK. Cracked rock and ice blocks can be broken now.)"]]};

/* ---- the map as it is now: crates you've opened and rocks you've split stay that way ---- */
function openedList(){return store.get("wta_opened",[])}
function openedMap(cls){const M=MAPS[cls].slice();openedList().filter(k=>k.startsWith(cls+":")).forEach(k=>{const[x,y]=k.split(":")[1].split(",").map(Number);M[y]=M[y].slice(0,x)+"."+M[y].slice(x+1)});return M}
function markOpened(x,y){const cls=EXP.zone.cls,l=openedList(),k=cls+":"+x+","+y;if(!l.includes(k)){l.push(k);store.set("wta_opened",l)}
  const row=EXP.zone.map[y];EXP.zone.map[y]=row.slice(0,x)+"."+row.slice(x+1);const t=document.querySelector(`#map .tile[data-x="${x}"][data-y="${y}"]`);if(t){t.className="tile f";t.innerHTML=""}
  EXP.objs=(EXP.objs||[]).filter(o=>!(o.tile&&o.x===x&&o.y===y));gatedCompute()}
function canWalk(c){return c==="."||c===","||c==="="||c==="P"||c===":"||(c==="w"&&hasTool("boots"))||(c==="d"&&hasTool("lamp"))}

/* ---- how each tile looks ---- */
const PSH=`<ellipse cx="20" cy="35" rx="14" ry="3.5" fill="#000" opacity=".3"/>`;
const PS=b=>`<svg viewBox="0 0 40 40" preserveAspectRatio="xMidYMid meet" aria-hidden="true">${PSH}${b}</svg>`;
const CRATE=`<rect x="7" y="11" width="26" height="23" fill="#A8743E" stroke="#4A2E18" stroke-width="1.5"/><rect x="9.5" y="13.5" width="21" height="18" fill="none" stroke="#7A4E26" stroke-width="1.2"/><path d="M10 14 L30 31" stroke="#7A4E26" stroke-width="2.4"/>${[[9,13],[31,13],[9,32],[31,32]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".9" fill="#2A1A0C"/>`).join("")}<path d="M7 17 H33" stroke="#C8945E" stroke-width=".8"/>`;
const BOULDER=`<path d="M6 33 Q4 20 13 13 Q21 7 30 13 Q37 19 34 33 Z" fill="#8A8278" stroke="#3A342C" stroke-width="1.4"/><path d="M12 16 Q18 12 24 14" stroke="#B0A89E" stroke-width="1.4" fill="none"/><path d="M21 10 L19 17 L23 21 L18 27 L21 33" stroke="#2A2420" stroke-width="1.6" fill="none" stroke-linejoin="round"/><path d="M23 21 L28 23" stroke="#2A2420" stroke-width="1.1"/>`;
const ICEBLOCK=`<rect x="6" y="9" width="28" height="25" rx="3" fill="#BFE4F8" stroke="#5A9AC8" stroke-width="1.4"/><path d="M9 12 H22" stroke="#FFFFFF" stroke-width="2" opacity=".8"/><path d="M20 9 L18 16 L23 21 L17 28 L20 34" stroke="#3A7AA8" stroke-width="1.5" fill="none" stroke-linejoin="round"/><path d="M23 21 L29 24" stroke="#3A7AA8" stroke-width="1"/>`;
const SIGNPOST=`<rect x="18.5" y="16" width="3" height="19" fill="#6B4A2E" stroke="#3A2414" stroke-width=".8"/><rect x="5" y="6" width="30" height="13" rx="1.5" fill="#D8C090" stroke="#5A3A1E" stroke-width="1.4"/><path d="M9 10.5 H31 M9 14.5 H25" stroke="#5A3A1E" stroke-width="1.4" stroke-linecap="round"/>`;
const ZPROPS={
 "z-mine":{x:{svg:`<path d="M7 34 Q5 22 11 18 Q15 16 18 19 Q20 23 19 34 Z" fill="#B89A6A" stroke="#5A4424" stroke-width="1.2"/><path d="M20 34 Q19 21 26 17 Q31 15 34 20 Q35 27 33 34 Z" fill="#A88A5A" stroke="#5A4424" stroke-width="1.2"/><path d="M9 19 Q13 16 17 19 M22 18 Q27 14 32 19" stroke="#5A4424" stroke-width="1.4" fill="none"/><circle cx="13" cy="18" r="2" fill="#D07A3A"/><circle cx="27" cy="17" r="2.2" fill="#E9B949"/><circle cx="30" cy="18.5" r="1.4" fill="#9AA0A8"/>`},
   y:{svg:`<rect x="5" y="8" width="30" height="4" fill="#7A5230" stroke="#3A2414"/><rect x="6" y="12" width="3" height="23" fill="#6B4A2E"/><rect x="31" y="12" width="3" height="23" fill="#6B4A2E"/><path d="M13 12 V31 M21 12 V31 M28 12 V31" stroke="#8A5A34" stroke-width="1.8"/><path d="M9 16 Q13 13 17 16" stroke="#9AA6B4" stroke-width="2.2" fill="none"/><path d="M17 20 Q21 17 25 20" stroke="#9AA6B4" stroke-width="2.2" fill="none"/><path d="M25 18 L31 18 L31 21 L25 21 Z" fill="#9AA6B4"/>`}},
 "z-scrap":{x:{svg:`${[30,23,16].map(y=>`<ellipse cx="20" cy="${y}" rx="12" ry="4.5" fill="#26262A" stroke="#0E0E10" stroke-width="1"/><ellipse cx="20" cy="${y}" rx="5.5" ry="1.8" fill="#4A4A52"/>`).join("")}`},
   y:{tall:1,svg:`<rect x="15" y="14" width="10" height="21" fill="#E0B820" stroke="#5A4A08" stroke-width="1.2"/><path d="M15 14 L25 21 M25 14 L15 21 M15 21 L25 28 M25 21 L15 28" stroke="#5A4A08" stroke-width="1"/><path d="M20 14 L38 3" stroke="#E0B820" stroke-width="4"/><path d="M20 14 L38 3" stroke="#5A4A08" stroke-width="1" stroke-dasharray="2 2"/><path d="M36 4 V14" stroke="#2A2A2E" stroke-width=".8"/><path d="M34 14 H38 L37 17 H35 Z" fill="#6E757D"/><rect x="12" y="33" width="16" height="3" fill="#3A3A42"/>`}},
 "z-wreck":{x:{svg:`<path d="M3 24 Q20 36 37 24 L35 20 Q20 28 5 20 Z" fill="#8A4A2E" stroke="#3A1E10" stroke-width="1.3"/><path d="M5 20 Q20 14 35 20" fill="#6E3A22" stroke="#3A1E10" stroke-width="1.2"/><path d="M12 19 V26 M20 17 V29 M28 19 V26" stroke="#B87A54" stroke-width="1"/>`},
   y:{svg:`<ellipse cx="14" cy="28" rx="10" ry="5" fill="none" stroke="#C8A868" stroke-width="2.4"/><ellipse cx="14" cy="28" rx="6" ry="3" fill="none" stroke="#B89858" stroke-width="2"/><path d="M28 8 V30 M23 13 H33" stroke="#4A5058" stroke-width="2.6" stroke-linecap="round"/><path d="M21 26 Q28 35 35 26" stroke="#4A5058" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="28" cy="7" r="2" fill="none" stroke="#4A5058" stroke-width="1.5"/>`}},
 "z-volcano":{x:{svg:`<path d="M5 15 H33 Q36 15 36 18 L28 20 V25 H12 V20 L7 19 Q4 18 5 15 Z" fill="#3A3A42" stroke="#121216" stroke-width="1.3"/><path d="M13 25 L10 34 H30 L27 25" fill="#2A2A30" stroke="#121216" stroke-width="1.2"/><path d="M8 16 H32" stroke="#6A6A74" stroke-width="1"/><circle cx="18" cy="17" r="1" fill="#FF8A2A"/>`},
   y:{tall:1,svg:`<path d="M12 36 L10 10 Q11 3 20 2 Q29 3 30 10 L28 36 Z" fill="#6A625E" stroke="#2A2422" stroke-width="1.4"/><path d="M20 12 m-5 0 a5 5 0 1 0 10 0 a3.5 3.5 0 1 0 -7 0 a2 2 0 1 0 4 0" fill="none" stroke="#FF8A2A" stroke-width="1.2" opacity=".85"/><path d="M14 24 H26 M15 29 H25" stroke="#4A4240" stroke-width="1.2"/>`}},
 "z-vault":{x:{svg:`<rect x="10" y="24" width="20" height="11" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/><rect x="9" y="7" width="22" height="17" fill="rgba(210,235,250,.45)" stroke="#8C7A5E" stroke-width="1.4"/><path d="M11 9 L15 9 L11 14" fill="#FFFFFF" opacity=".6"/><polygon points="20,11 24,15 20,21 16,15" fill="#3AA0E2" stroke="#1A5A8A" stroke-width=".8"/><rect x="15" y="21" width="10" height="3" fill="#D9A92A"/>`},
   y:{tall:1,svg:`<rect x="11" y="24" width="18" height="12" fill="#EDE6D2" stroke="#8C7A5E" stroke-width="1.2"/><rect x="9" y="22" width="22" height="3" fill="#D9A92A"/><path d="M13 22 Q12 13 20 12 Q28 13 27 22 Z" fill="#D8D0BC" stroke="#8C7A5E" stroke-width="1.2"/><circle cx="20" cy="8" r="5.5" fill="#D8D0BC" stroke="#8C7A5E" stroke-width="1.2"/><path d="M16 4 Q20 1 24 4" stroke="#B8AE96" stroke-width="1.4" fill="none"/>`}},
 "z-reactor":{x:{svg:`<path d="M5 22 H35 L33 35 H7 Z" fill="#7A847E" stroke="#2E3430" stroke-width="1.2"/><rect x="9" y="6" width="22" height="15" rx="1.5" fill="#2E3430" stroke="#1A1E1C" stroke-width="1.2"/><rect x="11" y="8" width="18" height="11" fill="#1A2E22"/><path d="M13 16 L16 12 L19 14 L23 10 L27 13" stroke="#9CFF4A" stroke-width="1" fill="none"/>${[10,15,20,25,30].map((x,i)=>`<circle cx="${x}" cy="27" r="1.5" fill="${["#E23A3A","#E0B820","#9CFF4A","#E0B820","#3AA0E2"][i]}"/>`).join("")}`},
   y:{svg:`<rect x="3" y="20" width="34" height="8" fill="#8A9692" stroke="#3A4440" stroke-width="1.2"/><rect x="17" y="12" width="6" height="10" fill="#8A9692" stroke="#3A4440" stroke-width="1.2"/><circle cx="20" cy="10" r="7" fill="none" stroke="#C8242A" stroke-width="2.4"/><path d="M13 10 H27 M20 3 V17" stroke="#C8242A" stroke-width="1.6"/><circle cx="20" cy="10" r="1.6" fill="#6A1216"/><path d="M8 20 V28 M32 20 V28" stroke="#5A6662" stroke-width="1.4"/>`}},
 "z-glacier":{x:{svg:`<path d="M3 34 L20 7 L37 34 Z" fill="#FF7A2A" stroke="#8A3A0E" stroke-width="1.4" stroke-linejoin="round"/><path d="M20 7 L16 34 H24 Z" fill="#C8541A"/><path d="M20 7 L20 3" stroke="#6A4A2A" stroke-width="1.4"/><path d="M3 34 H37" stroke="#8A3A0E" stroke-width="1.5"/>`},
   y:{svg:`<ellipse cx="20" cy="27" rx="13" ry="6" fill="#DDF2FF" stroke="#8AC0E0" stroke-width="1.2"/><ellipse cx="20" cy="27" rx="8" ry="3.4" fill="#1E3E58"/><path d="M26 27 L34 6" stroke="#6A4A2A" stroke-width="1.4"/><path d="M34 6 Q35 18 22 27" stroke="#E8E8E8" stroke-width=".6" fill="none"/><rect x="30" y="29" width="7" height="5" fill="#8A5A34" stroke="#3A2414" stroke-width=".8"/>`}},
 "z-quill":{x:{tall:1,svg:`<rect x="6" y="2" width="28" height="33" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/>${[4,15,26].map(y=>`<rect x="8" y="${y}" width="24" height="8" fill="#2A1C12"/>`).join("")}${[[9,5,"#8A3A34"],[12,4,"#2E4A7A"],[15,6,"#3A6A4A"],[19,5,"#6A4A2A"],[23,4,"#4A3A6A"],[27,6,"#8A6A2A"],[9,16,"#2E4A7A"],[13,17,"#6A4A2A"],[17,16,"#8A3A34"],[25,17,"#3A6A4A"],[10,27,"#4A3A6A"],[15,27,"#8A6A2A"],[21,28,"#2E4A7A"],[26,27,"#8A3A34"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="2.8" height="${12-(y%11)}" fill="${c}"/>`).join("")}`},
   y:{svg:`<path d="M12 24 H28 L26 35 H14 Z" fill="#C8643A" stroke="#6A2E14" stroke-width="1.2"/><rect x="11" y="22" width="18" height="3" fill="#D8744A" stroke="#6A2E14" stroke-width="1"/><path d="M20 22 Q18 12 10 8 M20 22 Q22 10 30 6 M20 22 Q20 14 20 4 M20 22 Q14 17 7 17 M20 22 Q27 17 33 16" stroke="#2E7A3A" stroke-width="2.2" fill="none" stroke-linecap="round"/>`}},
 "z-crater":{x:{tall:1,svg:`<path d="M20 22 L12 36 M20 22 L28 36 M20 22 V36" stroke="#3A3448" stroke-width="1.6"/><rect x="8" y="9" width="24" height="8" rx="2" fill="#C8CED8" stroke="#3A3448" stroke-width="1.3" transform="rotate(-28 20 13)"/><rect x="28" y="2" width="6" height="10" rx="1" fill="#8A92A0" stroke="#3A3448" stroke-width="1" transform="rotate(-28 20 13)"/><circle cx="20" cy="20" r="2.4" fill="#3A3448"/>`},
   y:{svg:`<path d="M6 33 Q3 22 11 16 Q19 10 28 14 Q37 19 34 33 Z" fill="#2A2436" stroke="#120E1A" stroke-width="1.3"/>${[[13,22,2.4],[22,19,1.8],[27,27,2.6],[16,29,1.6]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#1A1624"/>`).join("")}<path d="M10 20 Q18 14 27 16" stroke="#B08CFF" stroke-width="1" fill="none" opacity=".7"/><circle cx="24" cy="24" r="1.2" fill="#BFE3FF"/>`}}};
function tileLook(c,x,y,seed,M){const z=EXP.zone.cls;
  if(c==="#")return["w",""];if(c==="L")return["l",""];if(c===",")return["r",rubbleSVG(z,seed)];if(c==="=")return["pa",""];if(c==="~")return["lq",""];
  if(c===":")return["f fd",""];if(c==="w")return["sh",""];if(c==="d")return["dk",""];
  const under=()=>{let a=0,b=0;[[1,0],[-1,0],[0,1],[0,-1]].forEach(([dx,dy])=>{const n=(M[y+dy]||"")[x+dx];if(n===":")a++;if(n==="."||n===",")b++});return a>b?" fd":""};
  if(c==="o")return["f pr"+under(),propSVG(z,"o",seed)];if(c==="T")return["f tl"+under(),propSVG(z,"T",seed)];
  if(c==="x"||c==="y"){const p=(ZPROPS[z]||{})[c];return[(p&&p.tall?"f tl":"f pr")+under(),p?PS(p.svg):""]}
  if(c==="c")return["f pr"+under(),PS(CRATE)];if(c==="K")return["f pr"+under(),PS(z==="z-glacier"?ICEBLOCK:BOULDER)];if(c==="S")return["f pr"+under(),PS(SIGNPOST)];
  return["f",""]}

/* ---- signs, crates and cracked rock are things you INTERACT with ---- */
const CRATE_LOOT=["cell","guide","sieve","quiet","lure","glint","survey","charm","decoy","timer"];
function tileObjs(){if(EXP.zone.special)return;const M=EXP.zone.map,z=EXP.zone.cls;
  M.forEach((row,y)=>row.split("").forEach((c,x)=>{
    if(c==="S"){const t=(SIGNS[z]||{})[x+","+y]||["The paint has flaked off past reading."],hk=(typeof SIGN_HOOKS!=="undefined"&&SIGN_HOOKS[z+":"+x+","+y]);EXP.objs.push({x,y,tile:1,use:()=>talk("",t,hk||null)})}
    if(c==="c")EXP.objs.push({x,y,tile:1,use:()=>{if(!hasTool("crowbar")){Q.set("needBar");talk("",["A crate, nailed shut. The lid won't move for fingers.","A crowbar would do it."]);return}
      const sc=typeof SPECIAL_CRATES!=="undefined"&&SPECIAL_CRATES[z+":"+x+","+y];if(sc){sfx("pickup");markOpened(x,y);sc();return}
      const k=CRATE_LOOT[(x*7+y*13+z.length)%CRATE_LOOT.length];sfx("pickup");markOpened(x,y);giveItem(k);talk("",["You work the crowbar under the lid. The nails shriek, and it comes away.",`Inside, packed in straw: a ${ITEMS[k].name.toUpperCase()}. It went into your BAG.`])}});
    if(c==="K")EXP.objs.push({x,y,tile:1,use:()=>{const ice=z==="z-glacier";if(!hasTool("pick")){Q.set("needPick");talk("",[ice?"A block of old blue ice, clouded right through. Something is on the other side.":"A boulder with a crack running right through it. It sounds hollow when you knock.","An ice pick would split it."]);return}
      sfx("clunk");markOpened(x,y);talk("",[ice?"You set the pick in the cloudy seam and lean on it. The block splits with a sound like a gunshot.":"One good swing into the crack and the boulder falls apart like a loaf.","The way is open."])}})}))}

/* ---- rubble behind a gate hasn't been picked over. Alloys there come quicker, and shine more often. ---- */
function gatedCompute(){const M=EXP.zone.map,W=EXP.W,H=EXP.H,seen=new Set,q=[];if(!M)return;
  let s=null;M.forEach((r,y)=>{const x=r.indexOf("P");if(x>=0)s=[x,y]});if(!s)s=[EXP.x,EXP.y];
  const ok=c=>c==="."||c===","||c==="="||c==="P"||c===":";seen.add(s+"");q.push(s);
  while(q.length){const[x,y]=q.shift();for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=nx+","+ny;if(nx<0||ny<0||nx>=W||ny>=H||seen.has(k)||!ok(M[ny][nx]))continue;seen.add(k);q.push([nx,ny])}}
  EXP.open=seen}
function inGated(x,y){return EXP.open&&!EXP.zone.special&&!EXP.open.has(x+","+y)}
{const _en=encounter;encounter=function(){EXP.fromGated=inGated(EXP.x,EXP.y);_en()}}
{const _sr=startRound;startRound=function(){EXP.fromGated=false;_sr()}}   /* the behind-the-gates radiant bonus is rolled in encounter(), before the opener plays */
{const _st=step;step=function(dx,dy){if(!DLG.open&&!EXP.busy&&S.phase==="explore"){const c=tileAt(EXP.x+dx,EXP.y+dy);
    if(c==="w"&&!hasTool("boots")&&gate("wadeMsg",1500)){Q.set("needBoots");say0("Too deep for ordinary shoes. A pair of waders would get you through.")}
    if(c==="d"&&!hasTool("lamp")&&gate("darkMsg",1500)){Q.set("needLamp");say0("Pitch black in there. You'd need a lamp.")}
    if((c==="c"||c==="K"||c==="S")&&gate("bumpMsg",1500))say0(c==="c"?"A nailed-shut crate. Try INTERACT.":c==="K"?"Cracked rock blocks the way. Try INTERACT.":"A sign. Press INTERACT to read it.")}
  const px=EXP.x,py=EXP.y,r=_st(dx,dy);if((EXP.x!==px||EXP.y!==py)&&inGated(EXP.x,EXP.y)&&tileAt(EXP.x,EXP.y)===","&&EXP.quiet<=0)EXP.since=(EXP.since||0)+1;return r}}


/* =============== ITEMS: every one does a different kind of thing, not a bigger or smaller number of the same thing =============== */
if(BAG.token){BAG.guide=(BAG.guide||0)+BAG.token;delete BAG.token;saveBag()}
delete ITEMS.token;
Object.assign(ITEMS,{
  cell:{name:"Spare Scanner Cell",cat:"lab",desc:"Clicks into the scanner. Gives you one more scan on the alloy in front of you.",when:"elements",w:9},
  guide:{name:"Field Guide Page",cat:"lab",desc:"A torn page of the Institute field guide. Narrows a nameless alloy down to three names. One of them is right.",when:"name",w:10},
  sieve:{name:"Sorting Sieve",cat:"lab",desc:"Shake the sample through it and eight elements that aren't in there fall away from the scanner. Costs no charge.",when:"elements",w:9},
  charm:{name:"Lucky Charm",cat:"lab",desc:"A four-leaf clover pressed in resin. Carry it and the next alloy you register is worth 20% more.",when:"any",w:7},
  patch:{name:"Containment Patch",cat:"threat",desc:"A riveted plate with sealant. Mends one leak at once: +8% containment in a threat fight.",when:"boss",w:9},
  stasis:{name:"Stasis Pack",cat:"threat",desc:"A frosty canister. Crack it and nothing can pull containment down for 5 seconds. It doesn't mend anything.",when:"boss",w:7},
  cloth:{name:"Lens Cloth",cat:"threat",desc:"Soft and lint-free. Wipes a dazzled scanner back into order in one pass.",when:"dazzled",w:6},
  quiet:{name:"Muffled Boots",cat:"field",desc:"Felt overshoes. Nothing jumps out of the rubble at you for 25 steps. For walking somewhere in peace.",when:"explore",w:9},
  lure:{name:"Rubble Lure",cat:"field",desc:"A jar of glittering filings. The very next rubble you step into will have an alloy in it.",when:"explore",w:9},
  glint:{name:"Glint Lens",cat:"field",desc:"A jeweller's loupe. Look through it and everything dropped on this map is marked with a sparkle.",when:"explore",w:7},
  decoy:{name:"Syndicate Decoy",cat:"field",desc:"A cardboard grunt with a stolen orange badge. Stand it up in front of you and the grunts on this map stare at it instead.",when:"explore",w:6},
  survey:{name:"Survey Map",cat:"field",desc:"An Institute survey sheet, folded small. Unfold it and walk straight to any map you choose.",when:"explore",w:5},
  timer:{name:"Pocket Timer",cat:"duel",desc:"Ticks very loudly. Lob it at a grunt mid-duel and they lose count: +12 seconds on the clock.",when:"duel",w:6}});
Object.assign(ICONS,{
  guide:`<path d="M5 4 H16 L19 7 V21 H5 Z" fill="#F2EAD2" stroke="#6A5A3A" stroke-width="1.2"/><path d="M16 4 V7 H19" fill="#D8CCA8" stroke="#6A5A3A" stroke-width="1"/><path d="M7.5 10 H16 M7.5 13.5 H16 M7.5 17 H13" stroke="#8A7A5A" stroke-width="1.2"/><circle cx="17" cy="17" r="1.4" fill="#C8242A"/><path d="M5 21 L7 19 L9 21 L11 19 L13 21" fill="none" stroke="#6A5A3A" stroke-width=".8"/>`,
  sieve:`<ellipse cx="12" cy="9" rx="9" ry="3.2" fill="#C8A060" stroke="#6A4A12" stroke-width="1.2"/><path d="M3 9 Q4 18 12 19 Q20 18 21 9" fill="#E8D8A8" stroke="#6A4A12" stroke-width="1.2"/><path d="M6 12 H18 M7 15 H17 M9 9.5 V17.5 M12 9.5 V18.5 M15 9.5 V17.5" stroke="#8A6A2A" stroke-width=".7"/><circle cx="9" cy="22" r=".9" fill="#9AA0A8"/><circle cx="13" cy="21.5" r=".8" fill="#9AA0A8"/><circle cx="15.5" cy="22.4" r=".7" fill="#9AA0A8"/>`,
  survey:`<path d="M3 6 L9 4 L15 6 L21 4 V19 L15 21 L9 19 L3 21 Z" fill="#E8F0D8" stroke="#4A6A3A" stroke-width="1.2" stroke-linejoin="round"/><path d="M9 4 V19 M15 6 V21" stroke="#9AB08A" stroke-width=".8"/><path d="M5 15 Q8 11 11 13 T18 9" stroke="#C8242A" stroke-width="1.2" fill="none" stroke-dasharray="1.6 1.2"/><path d="M17 7.5 l2.2 2.2 M19.2 7.5 l-2.2 2.2" stroke="#C8242A" stroke-width="1.2"/>`});
/* (rollItem: superseded; the version in use is further up) */
/* (itemUsable: superseded; the version in use is further up) */
function sieveable(){const r=S.r,ans=new Set(r.a.comp.map(x=>x[0]));return EL.map(e=>e.s).filter(s=>!ans.has(s)&&!r.miss.has(s)&&!r.hit.has(s))}
function guideChoices(a){const pool=ALLOYS.filter(x=>x!==a&&!x.threat&&!x.quest&&x.name!==a.name),same=pool.filter(x=>x.hab===a.hab),src=same.length>=6?same:pool,out=new Set;
  while(out.size<2&&src.length){out.add(src[Math.random()*src.length|0].name)}const L=[a.name,...out];for(let i=L.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[L[i],L[j]]=[L[j],L[i]]}return L}
/* (useItem: superseded; the version in use is further up) */
function closeBag(){const b=$("#bag");if(b)b.hidden=true}
{const _ra=renderActions;renderActions=function(){_ra();const r=S.r;if(!r||r.stage!=="name"||!r.choices||!r.choices.length)return;
  const d=document.createElement("div");d.className="choices";d.innerHTML=`<span>FIELD GUIDE:</span>`+r.choices.map(n=>`<button class="btn choice">${n}</button>`).join("");$("#actions").appendChild(d);
  d.querySelectorAll(".choice").forEach(b=>b.onclick=()=>{const n=b.textContent;if(!nameMatches(n,r.a))r.choices=r.choices.filter(x=>x!==n);guessName(n);if(S.r===r&&r.stage==="name")renderActions()})}}
/* (keyItems: superseded; the version in use is further up) */
const BAGCATS=[["lab","FOR THE LAB"],["threat","FOR THREAT FIGHTS"],["field","FOR THE FIELD"],["duel","FOR SYNDICATE DUELS"]];
/* (renderBag: superseded; the version in use is further up) */


/* =============== THE FOUNDER'S QUEST, longer: the diary needs a translator, the case needs proof from all over the map =============== */
if(store.get("wta_qv",1)<2){const s=store.get("wta_q",0);if(s>=12)store.set("wta_q",s+1);store.set("wta_qv",2)}
{const E=k=>EVIDENCE.find(e=>e.f===k);
 E("vellYoung").x="The founder taught her as a girl. A chip in his left lens he never got round to fixing. She passed him in the hall last spring, not a day older.";
 E("lampbook").x="'A.M., badge 001, Quillmoor' signs out a lamp sixty-one years ago, and again last month, in the same hand.";
 E("nightlog").x="'Badge 001. Basement.' Every night at two in the morning, for forty years, in handwriting that never changes.";
 E("manifest").x="The galleon salvage, sixty years ago: 'Scientist aboard: A.M., Institute badge 001. Would not stop asking about the fire.'";
 E("photo").x="Opening day, May '64: 'A. M., with my first student, little V.'";
 E("coat").x="Yellowed with age. The name tape is torn away down to '...LOW'. In the pocket, field badge number 001.";
 E("diary").t="The study diary";
 E("diary").x="Translated by Vell: 'Every night I go down to tend the cell. The recruit is close now.'";
 EVIDENCE.splice(6,0,{f:"film",t:"The opening-day film",x:"The founder cutting the ribbon, sixty years ago. His face is turned from the camera, but his left spectacle lens has a little star-shaped chip in it.",good:1},
   {f:"stafffile",t:"Marlow's staff file",x:"Badge 001. Joined on opening day. Birth date left blank, photograph removed, next of kin 'the Institute'.",good:1})}
const NEED_EVIDENCE=6;
const LEADS={lampbook:"Nettie's old lamp book, on its hook in the unlit lamp room north of Rustvein Mine's top tunnel.",manifest:"Captain Fenn's grandmother's sea chest, out in the galleon's hull at Sunken Galleon Cove.",nightlog:"The old Institute sign-in books, crated up in the Old Reactor Hall's storage bay.",film:"The opening-day film reel, in Starfall Crater's caved-in film vault.",stafffile:"The staff files in the Institute's records room. Cabinets open to a badge number and a joining year.",vellYoung:"Whatever Chronicler Vell remembers about the founder's face.",coat:"The lab coat in the founder's basement.",letters:"The papers on the study desk."};
/* (questObjective: superseded; the version in use is further up) */

/* (pageGive: superseded; the version in use is further up) */
function hintOnce(k,who,lines){if(Q.flag("hint_"+k)||Q.flag(k))return false;talk(who,lines,()=>{Q.set("hint_"+k);say0("A new lead is in your JOURNAL.")});return true}
/* (questHooks: superseded; the version in use is further up) */

/* the proof out in the world */
function questObjs2(){const z=EXP.zone,sp=SPOTS[z.cls]||{},W=EXP.W,H=EXP.H;if(z.special)return;
  const add=(at,cls,svg,use)=>{if(!at)return;const[x,y]=at,d=document.createElement("div");d.className="mapobj "+cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=svg;$("#world").insertBefore(d,$("#player"));EXP.objs.push({x,y,el:d,use})};
  const got=(k,lines)=>{Q.set(k);sfx("pickup");talk("",lines,()=>say0("New evidence in your JOURNAL."))};
  if(z.cls==="z-mine")add(sp.book,"book",`<svg viewBox="0 0 40 40"><path d="M20 3 V9" stroke="#6A6254" stroke-width="1.6"/><rect x="9" y="9" width="22" height="26" rx="1.5" fill="#6A3A24" stroke="#2A140A" stroke-width="1.4"/><rect x="12" y="12" width="16" height="20" fill="#E8DCC0"/><path d="M14 16 H26 M14 20 H26 M14 24 H22" stroke="#8A7A5A" stroke-width="1"/></svg>`,
    ()=>{if(Q.flag("lampbook")){talk("",["The lamp book. First page and last page, the same hand, sixty-one years apart."]);return}
      if(Q.s<13){talk("",["An old lamp book, hanging on its hook. Sixty years of signatures, in and out.","Whatever you'd be looking for in here, you don't know it yet."]);return}
      got("lampbook",["You open the lamp book at the first page. The ink is brown with age.","'A.M., badge 001, Quillmoor.' Signed out: one lamp. Signed back in the same evening.","You turn to the last page. Last month's date. The ink is still black.","'A.M., badge 001, Quillmoor.' The same loops. The same hook on the 'Q'. The same hand."])});
  if(z.cls==="z-wreck")add(sp.chest,"chest",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="35" rx="15" ry="3" fill="#000" opacity=".3"/><rect x="6" y="17" width="28" height="17" rx="2" fill="#6A4A2E" stroke="#2A1A0C" stroke-width="1.4"/><path d="M6 17 Q20 5 34 17 Z" fill="#7A5634" stroke="#2A1A0C" stroke-width="1.4"/><rect x="6" y="20" width="28" height="3" fill="#4A5058"/><rect x="18" y="19" width="4" height="6" rx="1" fill="#C8A060" stroke="#6A4A12"/></svg>`,
    ()=>{if(Q.flag("manifest")){talk("",["Fenn's grandmother's sea chest. String, tide tables, and one salvage manifest you've already read."]);return}
      if(Q.s<13){talk("",["An old sea chest, lashed down in the hold. Full of string, tide tables and old papers.","You leave it be. It's somebody's grandmother's."]);return}
      got("manifest",["The sea chest is exactly as Fenn said: string, tide tables, grudges written on the backs of envelopes.","Underneath them all, the salvage manifest from sixty years ago.","'Scientist aboard: A.M., Institute badge 001. Remarks: would not stop asking about the fire.'"])});
  if(z.cls==="z-reactor")add(sp.logs,"logcrate",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="35" rx="15" ry="3" fill="#000" opacity=".3"/>${CRATE}<rect x="11" y="19" width="18" height="7" fill="#E8E2D0" stroke="#5A4A2A" stroke-width=".8"/><text x="20" y="24.6" text-anchor="middle" font-size="5" font-weight="900" fill="#3A2A12" font-family="sans-serif">NIGHTS</text></svg>`,
    ()=>{if(Q.flag("nightlog")){talk("",["The crate of night books. Badge 001, every night at two, for forty years."]);return}
      if(!hasTool("crowbar")){talk("",["A crate stencilled SIGN-IN BOOKS: NIGHTS. Nailed shut by somebody who really meant it.","A crowbar would do it."]);return}
      if(Q.s<13){talk("",["You lever the lid up an inch. Forty years of night sign-in books, stacked to the top.","You don't know what you'd be looking for. You let the lid back down."]);return}
      got("nightlog",["You lever the lid off. Forty years of the Institute's night sign-in books.","You flick through them at random. Every night, at two in the morning, the same line.","'Badge 001. Basement.' Forty years. The handwriting never changes. Not even a little shake."])});
  if(z.cls==="z-crater")add(sp.film,"reel",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="35" rx="13" ry="3" fill="#000" opacity=".3"/><circle cx="20" cy="21" r="12" fill="#4A4E58" stroke="#1A1C22" stroke-width="1.4"/><circle cx="20" cy="21" r="3" fill="#1A1C22"/>${[0,72,144,216,288].map(a=>`<circle cx="${20+7*Math.cos(a*Math.PI/180)}" cy="${21+7*Math.sin(a*Math.PI/180)}" r="2.4" fill="#1A1C22"/>`).join("")}<path d="M31 24 Q37 28 35 34" stroke="#3A2A1A" stroke-width="2" fill="none"/></svg>`,
    ()=>{if(Q.flag("film")){talk("",["The opening-day reel. The founder's left lens, chipped in a little star."]);return}
      if(Q.s<13){talk("",["A film can, labelled OPENING DAY in faded pencil.","It's Tamsin's. You leave it where it is for now."]);return}
      got("film",["A film can labelled OPENING DAY. You unspool the first few frames and hold them against the light.","A young man in a lab coat cuts a ribbon across the Institute's doors. His face is turned away from the camera.","But his spectacles catch the sun, frame after frame. The left lens has a little star-shaped chip in it."])});
  if(z.cls==="z-quill")add(sp.cabinet,"cabinet",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="36" rx="13" ry="2.5" fill="#000" opacity=".3"/><rect x="9" y="3" width="22" height="32" rx="1.5" fill="#6E7A86" stroke="#2E3640" stroke-width="1.4"/>${[5,15,25].map(y=>`<rect x="11" y="${y}" width="18" height="8" fill="#8A96A2" stroke="#2E3640" stroke-width=".8"/><rect x="17" y="${y+3}" width="6" height="2" rx="1" fill="#2E3640"/>`).join("")}<circle cx="27" cy="9" r="1.6" fill="#C8A060"/></svg>`,
    ()=>{if(Q.flag("stafffile")){talk("",["Marlow's staff file. Badge 001. No birthday. No photograph. Next of kin: the Institute."]);return}
      talk("",["A staff cabinet in the records room. The label says 'MARLOW, A.'","A brass combination dial underneath, five digits wide."],null,v=>{const d=v.replace(/\D/g,"");
        if(d==="00164"||d==="0011964")got("stafffile",["The dial clicks round to 0-0-1-6-4 and the drawer rolls open.","One thin file. 'MARLOW, A. Badge 001. Joined: opening day.'","Date of birth: left blank. Photograph: removed. Next of kin: 'the Institute'.","Under 'previous employment', in the same neat hand: 'this one'."]);
        else talk("",[`You set the dial to ${d||"nothing much"}. The drawer doesn't budge.`,"Badge number first, then the year he joined. Two digits for the year."])})});}

/* (marlowNPC: superseded; the version in use is further up) */
/* (evidencePick: superseded; the version in use is further up) */

{const _tt=talkTo;talkTo=function(p){const T=p.keeper&&!EXP.zone.special&&KEEPER_TOOL[EXP.zone.cls];
  if(T&&!hasTool(T[0])){talk(p.n,T[1],()=>{giveTool(T[0]);say0(`The ${TOOLS[T[0]].name.toUpperCase()} is in your BAG, under TOOLS.`)});return}_tt(p)}}

/* (openJournal: superseded; the version in use is further up) */

/* ---- placing everything on the map ---- */
/* (worldPlace: superseded; the version in use is further up) */


/* =============== THE FIVE PAGES: one questline each. The Expedition Register says where they went; the people holding them are somewhere you have to earn your way into. =============== */
const PQ=id=>store.get("wta_pq_"+id,0);
function setPQ(id,v){store.set("wta_pq_"+id,v);store.set("wta_qf_seenJ",0);journalDot()}
function pqMax(id,v){if(PQ(id)<v)setPQ(id,v)}
const PAGE_DONE={mine:6,wreck:4,volcano:4,glacier:5,crater:3};
const PAGE_ZONE={mine:"z-mine",wreck:"z-wreck",volcano:"z-volcano",glacier:"z-glacier",crater:"z-crater"};
if(store.get("wta_qv",2)<3){const g=store.get("wta_pages",[]),s=store.get("wta_q",0);
  Object.entries(PAGE_ZONE).forEach(([id,z])=>{if(g.includes(z))store.set("wta_pq_"+id,PAGE_DONE[id])});
  if(s===2){store.set("wta_q",1);store.set("wta_pq_crater",2)}
  if(s>=1)store.set("wta_qf_register",1);
  if(g.length>=5&&s<=2)store.set("wta_q",3);
  store.set("wta_qv",3)}
{const d=(AMBIENT["z-mine"]||[]).find(p=>p.n==="Foreman Dray");if(d){delete d.side;d.talks=[["Foreman Dray. I run the shifts down here. Somebody has to, and the rails won't run themselves. I've asked.","If you're going off the lit tunnels, don't. The north-west workings haven't been safe since the roof came in."],["My dad worked this mine forty years. Left me his brass lamp and a very firm opinion about canaries."]]}}
/* page questlines only open once the founder's quest is under way and you know who to look for */
const pageTime=()=>Q.s>=1&&Q.flag("register");
function pageTake(id){const z=PAGE_ZONE[id],g=pagesGot();if(!g.includes(z)){g.push(z);store.set("wta_pages",g)}setPQ(id,PAGE_DONE[id]);sfx("pickup");pagesCheck()}
function pagesCheck(){if(Q.s<=2&&Q.s>=1&&pagesGot().length>=5){Q.s=3;say0("All five of the founder's pages! Take them back to Archivist Wren.")}}
function pageNote(id){return `(You got the founder's ${PAGES[PAGE_ZONE[id]].t.toLowerCase()}!)`}
function litCount(){return [1,2,3].filter(i=>Q.flag("mlamp"+i)).length}
function keeperPos(z){const S0=SPOTS[z]||{};
  if(z==="z-wreck"&&PQ("wreck")>=4)return S0.home;if(z==="z-volcano"&&PQ("volcano")>=4)return S0.home;if(z==="z-glacier"&&PQ("glacier")>=4)return S0.home;return S0.keeper}
/* (questPull: superseded; the version in use is further up) */

/* signs and crates that move a questline on */
const SIGN_HOOKS={"z-wreck:7,11":()=>pqMax("wreck",1),"z-volcano:22,8":()=>pqMax("volcano",1),"z-glacier:5,7":()=>pqMax("glacier",1)};
const SPECIAL_CRATES={"z-wreck:6,10":()=>{giveTool("boots");pqMax("wreck",1);talk("",["The crowbar bites and the lid comes up with a shriek of nails.","Inside, wrapped in oilcloth: a pair of waders, and a note in capitals.","'IF YOU ARE READING THIS, YOU HAVE BROKEN INTO MY CRATE. KEEP THEM, THEN. — Y.F.'","(You got the WADING BOOTS. Shallow water is walkable now.)"])}};

/* things you have to dig out of the ground for somebody */
const QFIND={
  draylamp:{z:"z-mine",when:()=>PQ("mine")===1,done:()=>{setPQ("mine",2);say0("You found Foreman Dray's brass lamp! Take it back to him at the mine entrance.")}},
  nlamp1:{z:"z-mine",when:()=>PQ("mine")===4&&!Q.flag("mlampF1"),done:()=>{Q.set("mlampF1");say0("You found one of Nettie's old lamps, wrapped in a rotten sack. Hang it back in the lamp room.")}},
  nlamp2:{z:"z-mine",when:()=>PQ("mine")===4&&!Q.flag("mlampF2"),done:()=>{Q.set("mlampF2");say0("You found another of Nettie's lamps, jammed behind a fallen prop. Hang it back in the lamp room.")}},
  nlamp3:{z:"z-mine",when:()=>PQ("mine")===4&&!Q.flag("mlampF3"),done:()=>{Q.set("mlampF3");say0("The last of Nettie's lamps, at the very bottom of the workings. Hang it back in the lamp room.")}},
  lagoonKey:{z:"z-wreck",nodowse:1,when:()=>PQ("wreck")===2,done:()=>{setPQ("wreck",3);say0("You found a small brass key, green with sixty years of seawater. Captain Fenn will want it.")}},
  pick:{z:"z-glacier",when:()=>PQ("glacier")===2&&!hasTool("pick"),done:()=>{giveTool("pick");setPQ("glacier",3);say0("You found the INSTITUTE ICE PICK at the bottom of the pool. Cracked rock and ice blocks can be broken now.")}}};
function questSeed(){const z=EXP.zone.cls;if(EXP.zone.special)return;Object.entries(QFIND).forEach(([k,q])=>{if(q.z===z&&q.when()&&!(EXP.hidden||[]).some(h=>h.q===k)){const[x,y]=k==="lagoonKey"?tideKeySpot():SPOTS[z][k];EXP.hidden.push({x,y,q:k,nodowse:q.nodowse})}});dowse()}
/* (searchHere: superseded; the version in use is further up) */

/* the people on each page's trail */
function pageHooks(z){const N=n=>(EXP.npcs||[]).find(p=>p.n===n),K=(EXP.npcs||[]).find(p=>p.keeper),wrapK=f=>{if(!K)return;const old=K.quest;K.quest=()=>{const r=f();return r===false?(old?old():false):r}};
  if(z==="z-mine"){const d=N("Foreman Dray");if(d)d.quest=()=>{const p=PQ("mine");
      if(p===0){talk(d.n,["New face. Institute? You lot always want to go poking about in the north tunnels.","Nettie Crane's up there now, the old lamp keeper. She goes up to the old lamp room every week to sit with the lamps. Went up three days ago and hasn't come back down. She does that.","Trouble is, the north tunnels haven't been lit in years, and I'm not sending anyone up there without a light. I lost my dad's brass lamp somewhere along the top tunnel. East end, I think.","Find it for me and I'll kit you out with a proper pit lamp. Then you can go and fetch her yourself."],()=>{setPQ("mine",1);questSeed();say0("Find Foreman Dray's brass lamp, out at the east end of the top tunnel. Watch the dowsing meter.")});return}
      if(p===1){talk(d.n,["Top tunnel, east end. It'll be on the floor somewhere, sulking. The dowsing meter will twitch when you're close."]);return}
      if(p===2){talk(d.n,["That's it! That's my dad's lamp! Not a scratch. Well. Several scratches. All his.","Right. Fair's fair. Here's a pit lamp, full of oil. Brighter than the brass one. Don't tell my dad.","Nettie's up in the old lamp room. North of the top tunnel, past where the lights stop."],()=>{giveTool("lamp");setPQ("mine",3);say0("You got the MINER'S LAMP. Unlit tunnels are walkable now.")});return}
      talk(d.n,[p>=6?"Nettie came down for her tea. Says you lit her lamps. She's in a very good mood. It's unsettling.":"Nettie's up in the old lamp room, north of the top tunnel. Don't let her talk you into trimming wicks."])};
    wrapK(()=>{const p=PQ("mine");if(p<=3&&!pageTime())return false;
      if(p<=3){talk(K.n,["Oh! A light. Somebody's finally brought a light up here.","Sit down, love. I come up to sit with my lamps. Three hundred and six I kept, and my first three hung on those hooks for fifty years.","Then the roof in the old workings came down, the year I retired, and the lads carried everything out in a hurry. My three got left behind somewhere in there.","Bring them back and hang them on their hooks, and you can have anything you like.","Mind yourself in the workings. They're a warren, and they drink lamp oil. Your pit lamp won't last long in the dark. If it gutters, you'll have to feel your way back to the light and try again."],()=>{setPQ("mine",4);questSeed();say0("Find Nettie's three lost lamps in the unlit workings and hang them back on their hooks. Watch your oil.")});return}
      if(p===4){const f=[1,2,3].filter(i=>Q.flag("mlampF"+i)).length;talk(K.n,[`${litCount()} of three back on their hooks.`,f>litCount()?"You've one in your hand, love. Hang it up.":"The workings go further west than you'd think. The deepest bits flood with dark like water in a well. Take the long way round with your eyes open."]);return}
      if(p===5){if(!pageTime()){talk(K.n,["There. All three, burning like the old days. Thank you, love.","If the Institute ever sends somebody asking about a notebook page, you tell them Nettie Crane has it."]);return}
        talk(K.n,["There. All three, burning like the old days.","Now then. You're from the Institute. You've come about the page, haven't you.","A young scientist left it with me sixty-odd years back. Folded it into my lamp book between two Tuesdays. Said somebody would come for it one day, and to make them wait.","You waited. And you lit my lamps. Here.",pageNote("mine")],()=>{pageTake("mine");say0("A founder's page was added to your JOURNAL.")});return}
      return false})}
  if(z==="z-wreck")wrapK(()=>{const p=PQ("wreck");if(p>=4)return false;
      if(!pageTime()){talk(K.n,["Ahoy. You waded all the way out here? Good on you.","I come out at low water to sit with my grandmother's things. She asked to have them put aboard. Sentimental old baggage. I miss her terribly."]);return}
      if(p<=1){talk(K.n,["Ahoy. You waded all the way out here? Good on you. Nobody's done that in years.","A page from the Institute's founder? Grandmother had it. It's in her sea chest, right here in the hold. Locked.","The key went into the lagoon when I was nine. A gull took it off the rail and dropped it right where the old barrel sank. I watched it go.","Here's the trouble. Salt water fizzes those dowsing meters of yours, so you'll be feeling for it by hand. And the lagoon floods fast when the tide turns. Stay in too long and it'll knock you flat and move the key about.","In, search, out. Don't dawdle."],()=>{setPQ("wreck",2);questSeed();say0("Search the lagoon near the sunken barrel for the key. The dowsing meter won't help, and the tide gives you about 18 steps in the water.")});return}
      if(p===2){talk(K.n,["The lagoon, inland. The shallow bit round the edge. Small brass key, green as a bottle."]);return}
      talk(K.n,["That's the one! Sixty years in the lagoon and it still fits. Look at that.","There. Grandmother's sea chest. String, tide tables, grudges on the backs of envelopes, and...","One page, folded in four. He pressed it on her from the salvage boat and said somebody would come.","I told her nobody ever would. I owe her an apology.",pageNote("wreck")],()=>{pageTake("wreck");say0("A founder's page was added to your JOURNAL.")})});
  if(z==="z-volcano")wrapK(()=>{const p=PQ("volcano");if(p>=4)return false;
      if(!pageTime()){talk(K.n,["You broke my boulder. It was there so that visitors would take the hint.","I am on retreat. I will return when the rivers go dim. Please go away politely."]);return}
      if(p<=1){talk(K.n,["You broke my boulder to find me. That is the most effort anybody has made to see me in eleven years.","You have come for the young man's page. It is yours, if you will do one thing.","Bring me a light from the fire in the ring of stones, in your lamp. I have vowed not to leave this tube until the rivers go dim, and I would very much like to read something.","But understand: that flame is not like other flames. Carried away from the stones it lives only a short while, and the slightest disturbance in the rubble will put it out.","Choose your path before you light it."],()=>{setPQ("volcano",2);say0("Carry a flame from the eternal fire to Brother Ashlin. It lasts about 34 steps, and stepping on any rubble puts it out.")});return}
      if(p===2){talk(K.n,["A light from the fire, please. In something that will hold it. Your hands will not."]);return}
      talk(K.n,["Ah. The fire. You carried it all the way here without it going out. It never goes out. But still.","Thank you. Here is his page. He sat by the fire an hour to write it and gave it to me because he did not trust himself with it.","I have kept it and I have not read it. Both were difficult.",pageNote("volcano")],()=>{pageTake("volcano");say0("A founder's page was added to your JOURNAL.")})});
  if(z==="z-glacier"){const o=N("Ole");if(o)o.quest=()=>{const p=PQ("glacier");
      if(p<=1){talk(o.n,["You're from the Institute? Then you'd better hear this. Dr. Holm? She went into the deep grotto yesterday to measure something. Then the ice shifted and sealed the way in behind her.","She's been knocking on it all night. Very politely. In what I think is Morse.","I'd dig her out, but I borrowed the Institute ice pick for my fishing holes and dropped it through the ice. It'll have gone down the melt stream into the meltwater pool on the west side.","The pool's too deep for boots. You'd want waders."],()=>{setPQ("glacier",2);questSeed();say0("Find the Institute ice pick in Frostbite Cavern's meltwater pool, on the west side.")});return}
      if(p===2){talk(o.n,["Meltwater pool, west side. The pick'll be at the bottom somewhere. Mind your toes. The water's colder than my ex-wife."]);return}
      talk(o.n,[p>=4?"The doctor's back in the hut, pretending none of it happened. Still no bites for me.":"Go on, then. Get her out. She'll be wanting her supper."])};
    wrapK(()=>{const p=PQ("glacier");if(p>=5)return false;
      if(p<4){talk(K.n,["Oh, thank goodness. I have taken eleven hundred measurements of this ice and I would very much like to stop.","I'll be in the hut. Come and see me there. I owe you a cup of something hot."],()=>{setPQ("glacier",4);const hm=EXP.npcs.find(q=>q.n===K.n),home=SPOTS["z-glacier"].home;npcTravel(hm,home,false,()=>say0("Dr. Holm is free. She's gone back to the research hut."))});return}
      if(p===4&&pageTime()){talk(K.n,["The founder's page? It's in my coat. I took it into the grotto for luck.","I'll give it to the Institute, gladly, but not to just anyone they send. The founder's page has been this station's good-luck charm for sixty years.","Prove you're the real thing. I'll hand you a sample from our store: no name, no hints, three scans, and nobody holding your hand.","Name it and tell me what's in it, and the page is yours. Ready?"],()=>startTrial({who:K.n,intro:"DR. HOLM'S TEST: name this sample and find its elements. No hints, no items, three scans.",onWin:()=>setTimeout(()=>{pageTake("glacier");say("Dr. Holm hands over the founder's page. \"Well. The station will have to find a new good-luck charm.\" (Page four is in your JOURNAL.)")},3200),onLose:()=>setTimeout(()=>say("Dr. Holm: \"Not this time. Come back and try again whenever you like.\""),2600)}));return}
      return false})}
  if(z==="z-crater")wrapK(()=>{const p=PQ("crater");if(!pageTime()||p>=3)return false;
      if(p===0){talk(K.n,["The founder's page? You're about a fortnight too late.","It was in the film vault, in a tin, where he left it. Somebody broke in through the rubble two weeks ago. The roof came down even worse behind them.","They took the page. Only the page. Not one reel. Philistines.","They dropped this on the way out: an orange badge. Slag Syndicate.","Grunts always know who's holding what. Beat a couple of them and one will crack."],()=>{setPQ("crater",1);store.set("wta_pq_crater_base",slagWins());say0("The fifth page was STOLEN by the Slag Syndicate. Beat grunts until one of them talks.")});return}
      if(p===1){talk(K.n,["Beat Syndicate grunts until one of them talks. They're out on every map these days, like damp."]);return}
      talk(K.n,["Grist? In Bolt's east heaps? Of course he is. Nobody sensible goes in there.","Bring it back and I'll run you a double feature."])});
  if(z==="z-scrap")wrapK(()=>{const p=PQ("bolt");if(p>=2)return false;
      if(p===0){talk(K.n,["A crowbar? Everybody wants my crowbars. Doreen's not for lending. Her little sister might be.","Tell you what. The Syndicate have been nicking from my yard, and one of 'em's skulking round right now.","See him off and she's yours. Well. Borrowed. Forever."],()=>{setPQ("bolt",1);say0("See off the Syndicate grunt in the scrapyard, then go back to Bolt.");if(!(EXP.grunts||[]).some(g=>!g.done))goZone(EXP.zone)});return}
      if(!Q.flag("boltWin")){talk(K.n,["Still out there somewhere. Dark coat, orange badge, terrible attitude. Walk into his line of sight and he'll come to you."]);return}
      talk(K.n,["Saw him legging it over the fence! Lovely.","Here. Doreen's little sister. She's called Maureen. Be nice to her.","(You got the CROWBAR. Nailed-shut crates can be opened now.)"],()=>{giveTool("crowbar");setPQ("bolt",2);say0("You got the CROWBAR.")})})}

/* things on the maps that belong to a questline */
function questObjs3(){const z=EXP.zone,sp=SPOTS[z.cls]||{},W=EXP.W,H=EXP.H;if(z.special)return;
  const add=(at,cls,svg,use)=>{if(!at)return null;const[x,y]=at,d=document.createElement("div");d.className="mapobj "+cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=svg;$("#world").insertBefore(d,$("#player"));const o={x,y,el:d,use};EXP.objs.push(o);return o};
  const LAMP=lit=>`<svg viewBox="0 0 40 40"><path d="M20 2 V8" stroke="#6A6254" stroke-width="1.6"/>${lit?`<circle cx="20" cy="22" r="14" fill="#FFD66B" opacity=".3"/>`:""}<path d="M14 8 H26 L28 13 H12 Z" fill="#6A4A12"/><rect x="13" y="13" width="14" height="16" rx="2" fill="${lit?"rgba(255,230,150,.9)":"rgba(90,80,70,.7)"}" stroke="#6A4A12" stroke-width="1.6"/>${lit?`<path d="M20 16 Q17 21 20 25 Q23 21 20 16Z" fill="#FF9A2A"/>`:`<path d="M20 22 V26" stroke="#2A2420" stroke-width="1.4"/>`}<rect x="12" y="29" width="16" height="3" rx="1" fill="#6A4A12"/></svg>`;
  if(z.cls==="z-mine")[1,2,3].forEach(i=>{const o=add(sp["lamp"+i],"deadlamp",Q.flag("mlamp"+i)?LAMP(true):`<svg viewBox="0 0 40 40"><path d="M20 3 V12 M16 12 Q20 16 24 12" stroke="#C8A060" stroke-width="1.8" fill="none"/></svg>`,()=>{
      if(Q.flag("mlamp"+i)){talk("",["Burning steadily. Nettie keeps glancing at it, pleased."]);return}
      if(PQ("mine")<4){talk("",["An empty lamp hook, its brass polished bright. Something used to hang here."]);return}
      if([1,2,3].filter(k=>Q.flag("mlampF"+k)).length<=litCount()){talk("",["An empty hook. One of Nettie's lost lamps belongs here.","They're somewhere out in the unlit workings."]);return}
      Q.set("mlamp"+i);o.el.innerHTML=LAMP(true);sfx("pickup");
      if(litCount()>=3){setPQ("mine",5);talk("",["You hang the old lamp on its hook and tip your own flame to the wick. It catches, gutters, and settles into a steady glow.","That's all three. The lamp room is lit for the first time in years."],()=>say0("All three lamps are lit. Talk to Nettie."))}
      else talk("",["You hang the old lamp on its hook and tip your own flame to the wick. It catches and settles into a steady glow.",`(${litCount()} of 3 back on their hooks.)`])})});
  if(z.cls==="z-volcano")add(sp.fire,"eternalfire",`<svg viewBox="0 0 40 40"></svg>`,()=>{const p=PQ("volcano");
      if(!hasTool("lamp")){Q.set("needLamp");talk("",["The eternal fire. It burns on bare stone with no fuel at all, and it doesn't flicker, even in the wind.","You'd need a lamp to carry any of it away."]);return}
      if(p===2){setPQ("volcano",3);sfx("whoomph");talk("",["You hold your lamp out over the fire. The wick catches at once.","It burns with a steady white flame that doesn't flicker, even when you breathe on it.","Better get it to Brother Ashlin before you think too hard about that."],()=>say0("Carry the flame to Brother Ashlin in the lava tube."));return}
      talk("",["The eternal fire. It has burned here since before the standing stones. It doesn't flicker, even in the wind."])});
  if(z.cls==="z-quill")add(sp.register,"register",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="36" rx="11" ry="2.5" fill="#000" opacity=".3"/><rect x="17" y="18" width="6" height="17" fill="#6B4A2E" stroke="#3A2414"/><path d="M6 12 L34 12 L30 20 L10 20 Z" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/><path d="M9 8 Q15 6 20 10 Q25 6 31 8 L31 13 Q25 11 20 14 Q15 11 9 13 Z" fill="#F2EAD2" stroke="#6A5A3A"/><path d="M20 10 V14" stroke="#6A5A3A"/></svg>`,
    ()=>{Q.set("register");talk("",["THE EXPEDITION REGISTER. The first five field teams, entered in the founder's own tidy hand. Beside each one, a later note in the same hand: where he left a page.",
      "1. The Rustvein Mine survey. 'Page left with the mine's lamp-keeper, Nettie Crane.'",
      "2. The galleon salvage at Sunken Galleon Cove. 'Page left with the harbour master's family, the Fenns.'",
      "3. The Emberforge ascent. 'Page left with the hermit who keeps the fire.'",
      "4. The first winter at Frostbite Cavern. 'Page pinned inside Research Hut No. 1.'",
      "5. The Starfall observatory survey. 'Page sealed in the observatory's film vault.'",
      "At the bottom of the list, underlined twice: 'Never all five in one place. Not even here. Not even with me.'"],()=>{if(Q.s>=1)say0("The five expeditions are in your JOURNAL.")})})}
{const _q2=questObjs2;questObjs2=function(){_q2();questObjs3()}}

/* the Syndicate talks, eventually; Bolt hears about it */
{const _w=win;win=function(){const r=S.r,D=r&&r.duel,z=EXP.zone&&EXP.zone.cls;_w();if(!D)return;
  if(D.page){setPQ("crater",3);pagesCheck();return}
  if(z==="z-scrap"&&PQ("bolt")===1&&!Q.flag("boltWin")){Q.set("boltWin");setTimeout(()=>say("That'll be the grunt Bolt wanted seen off. He'll want to hear about it."),4800)}
  else if(PQ("crater")===1&&Q.s>=1){const n=slagWins()-store.get("wta_pq_crater_base",0);
    setTimeout(()=>{if(n>=2){setPQ("crater",2);say(`${D.n.toUpperCase()} cracks: "Fine! FINE! Foreman Grist has your precious page. He's holed up in the east heaps at Tinker's Scrapyard. Happy?"`)}
      else say(`${D.n.toUpperCase()} sneers: "A page? Never heard of it. Ask the foreman. No, I'm not saying which foreman."`)},4800)}}}

/* what the journal says while you're chasing pages */
const PAGE_STEPS={
  mine:["Rustvein Mine survey: the page went to the lamp-keeper, Nettie Crane. Ask around at the mine.","Find Foreman Dray's brass lamp, out at the east end of the mine's top tunnel.","Take the brass lamp back to Foreman Dray at the mine entrance.","Find Nettie Crane in the old lamp room, through the unlit tunnels north of the mine's top tunnel.",()=>`Find Nettie's three lost lamps in the unlit workings and hang them back on their hooks (${litCount()}/3 hung). Your lamp only holds so much oil in the dark.`,"Nettie's lamps are all back on their hooks. Talk to her."],
  wreck:["Galleon salvage: the page went to the harbour master's family, the Fenns. Try the harbour office at Sunken Galleon Cove.",()=>hasTool("boots")?"Wade out across the shallows to Captain Fenn, on the wreck.":"Captain Fenn is out on the wreck, across the shallows. Her spare waders are nailed in a crate inside the harbour office.","The key to the sea chest went in where the old barrel sank, in the lagoon. Salt water fizzes the dowsing meter, and the tide won't let you wade for long.","Take the brass key back to Captain Fenn on the wreck."],
  volcano:["The Emberforge ascent: the page went to 'the hermit who keeps the fire'. Try the ring of stones at Emberforge Caldera.","Brother Ashlin is on retreat in the lava tube beyond the east river, behind a cracked boulder.","Brother Ashlin wants a light from the eternal fire, carried in your lamp.","Carry the flame to Brother Ashlin before it dies: it won't survive long, and any disturbed rubble will snuff it out."],
  glacier:["The first winter: the page was pinned inside Research Hut No. 1 at Frostbite Cavern.","Dr. Holm took the page into the deep grotto. Somebody out on the lake might know where she's got to.","Find the Institute ice pick in the meltwater pool on Frostbite Cavern's west side.","Break through the ice into the deep grotto and find Dr. Holm.","Dr. Holm will trade the page for a proper identification: one sample, no hints, three scans. She's in the research hut."],
  crater:["The Starfall observatory survey: the page was sealed in the observatory's film vault. Ask Projectionist Tamsin.",()=>`The page was STOLEN by the Slag Syndicate. Beat grunts until one of them talks (${Math.min(2,Math.max(0,slagWins()-store.get("wta_pq_crater_base",0)))}/2).`,"Foreman Grist has the page, holed up in the fenced-off east heaps at Tinker's Scrapyard. He won't play fair: expect a nameless sample, no hints and a short clock."]};
function pageObjective(){if(!Q.flag("register"))return "Archivist Wren says the first five expeditions, and who they left the founder's pages with, are listed in the Expedition Register. It's on the lectern in the Institute's records room, west side of the hall.";
  const L=[`Recover the founder's five pages (${pagesGot().length}/5).`];
  Object.keys(PAGE_STEPS).forEach(id=>{const p=PQ(id);if(p>=PAGE_DONE[id])return;const t=PAGE_STEPS[id][Math.min(p,PAGE_STEPS[id].length-1)];L.push("– "+(typeof t==="function"?t():t))});
  const need=[];if(PQ("bolt")===1)need.push(Q.flag("boltWin")?"Tell Bolt the Syndicate grunt has been seen off.":"Bolt will lend you a crowbar if you see off the Syndicate grunt in his scrapyard.");
  if(Q.flag("needBar")&&!hasTool("crowbar")&&PQ("bolt")===0)need.push("You need a crowbar. Tinker's Scrapyard will have one, if you ask nicely.");
  if(Q.flag("needLamp")&&!hasTool("lamp")&&PQ("mine")<1)need.push("You need a lamp. The foreman at Rustvein Mine will have lamps.");
  if(Q.flag("needBoots")&&!hasTool("boots"))need.push("You need waders. The harbour office at Sunken Galleon Cove keeps a spare pair.");
  if(Q.flag("needPick")&&!hasTool("pick")&&PQ("glacier")<2)need.push("You need an ice pick. The Institute's only one went out to the Frostbite Cavern station.");
  return L.join("<br>")+(need.length?"<br><br>"+need.map(t=>"– "+t).join("<br>"):"")}
{const _qo=questObjective;questObjective=function(){const s=Q.s;if(s===1||s===2)return pageObjective();return _qo()}}
/* INTERACT: whatever you're facing first, then whoever's standing next to you, then what's under your feet */
/* (interact: superseded; the version in use is further up) */


/* =============== STAYING PUT: after a round you come back to exactly where you were. Wandering somewhere random is now a choice. =============== */
{const _en=encounter;encounter=function(){if(S.phase==="explore"&&EXP.zone&&!EXP.zone.special)EXP.stash={zone:EXP.zone,x:EXP.x,y:EXP.y,face:EXP.face,dir:EXP.dir,
    items:(EXP.items||[]).map(i=>({x:i.x,y:i.y,k:i.k})),hidden:(EXP.hidden||[]).filter(h=>!h.q&&!h.side).map(h=>({x:h.x,y:h.y,k:h.k})),
    grunts:(EXP.grunts||[]).filter(g=>!g.done).map(g=>({n:g.n,boss:g.boss,page:g.page,grunt:true,x:g.x,y:g.y,face:g.face})),
    quiet:EXP.quiet,lure:EXP.lure,glint:EXP.glint,decoy:EXP.decoy,decoyAt:EXP.decoyAt};_en()}}
function wanderZone(){const q=questPull();if(q&&q!==EXP.zone)return q;const o=ZONES.filter(z=>z!==EXP.zone&&z.cls!=="z-slag");return o[Math.random()*o.length|0]}
/* (next: superseded; the version in use is further up) */
function wander(){S.run.idx++;if(S.run.idx>=ROUNDS)return endRun();EXP.stash=null;EXP.resume=null;EXP.forceZone=wanderZone();startExplore()}
{const _wp=worldPlace;worldPlace=function(){EXP.decoyAt=null;_wp();const st=EXP.resume;EXP.resume=null;
  if(st&&st.zone===EXP.zone&&!EXP.zone.special){const W=EXP.W,H=EXP.H;
    const addEl=(cls,x,y,html)=>{const d=document.createElement("div");d.className=cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));return d};
    document.querySelectorAll("#world .mapitem,#world .grunt,#world .glintmark").forEach(e=>e.remove());
    EXP.items=st.items.map(i=>({...i,el:addEl("mapitem",i.x,i.y,itemIcon(i.k,40))}));
    EXP.hidden=[...(EXP.hidden||[]).filter(h=>h.q||h.side),...st.hidden];
    EXP.grunts=st.grunts.map(g=>{const o={...g,el:addEl("npc grunt",g.x,g.y,`<span class="bang">!</span>`+gruntSVG(g.boss))};slagFace(o);return o});
    Object.assign(EXP,{quiet:st.quiet||0,lure:!!st.lure,glint:!!st.glint,decoy:!!st.decoy,decoyAt:st.decoyAt,face:st.face,dir:st.dir});
    if(EXP.glint)glintShow();
    if(st.decoyAt){const[x,y]=st.decoyAt;addEl("mapobj decoyfig",x,y,`<svg viewBox="0 0 24 24">${ICONS.decoy}</svg>`)}
    placePlayer(true);dowse();nearMarks();
    say0(S.run.idx===0?"Walk through the glittering rubble to find a wild alloy.":"Right where you left off. More alloys hide in the rubble.")}
  placeTrail()}}
/* every map has a trail marker by the way in. Follow it to wander somewhere new without spending a round. */
function placeTrail(){if(EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;const M=EXP.zone.map;let P=null;M.forEach((r,y)=>{const x=r.indexOf("P");if(x>=0)P=[x,y]});if(!P)return;
  const ok=(x,y)=>{const c=(M[y]||"")[x];return (c==="."||c===":"||c==="=")&&!thingsAt(x,y).length&&!(EXP.items||[]).some(i=>i.x===x&&i.y===y)};
  const at=[[P[0]-1,P[1]],[P[0]+1,P[1]],[P[0],P[1]+1],[P[0],P[1]-1],[P[0]-2,P[1]],[P[0]+2,P[1]]].find(([x,y])=>ok(x,y));if(!at)return;
  const[x,y]=at,W=EXP.W,H=EXP.H,d=document.createElement("div");d.className="mapobj trail";d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";
  d.innerHTML=`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="36" rx="10" ry="2.5" fill="#000" opacity=".3"/><rect x="18.5" y="12" width="3" height="24" fill="#6B4A2E" stroke="#3A2414" stroke-width=".8"/><path d="M8 7 H28 L34 12 L28 17 H8 Z" fill="#E8C878" stroke="#5A3A1E" stroke-width="1.3"/><path d="M12 12 H26" stroke="#5A3A1E" stroke-width="1.6" stroke-dasharray="2 2"/></svg>`;
  $("#world").insertBefore(d,$("#player"));
  EXP.objs.push({x,y,el:d,use:()=>talk("",["A trail marker. The path beyond it winds off toward somewhere else entirely.","You follow it."],()=>{EXP.stash=null;goZone(wanderZone())})})}
{const _ra=renderActions;renderActions=function(){_ra();const r=S.r;if(!r||r.stage!=="done"||S.run.idx+1>=ROUNDS)return;const b=$("#btn-next");if(!b||$("#btn-wander"))return;
  b.textContent="KEEP EXPLORING";b.title="Go back to exactly where you were on this map.";
  const w=document.createElement("button");w.className="btn";w.id="btn-wander";w.textContent="WANDER ON ▶";w.title="Head off to a different map.";w.onclick=()=>{if(gate("btn-wander",800))wander()};b.after(w)}}


/* =============== THE FOUNDER'S BASEMENT: sixty years shut. The founder's first lab, left exactly as it was the night he sealed it. =============== */
MAPS["z-basement"]=["################################", "#HHH..HHH#jj.CCCCC..jjj#k.....k#", "#........#.............#.......#", "#........#.BBB....BBB..#.......#", "#a..............F..............#", "#........#.BBB....BBB..#.......#", "#........#.............#.......#", "#l.......#X...........X#k.....k#", "#H......H#XX.........XX#m.....m#", "####.###########.###############", "#cX..Xc.X#.............#NN...j.#", "#X......c#D...........D#.......#", "#........#.............#.....S.#", "#c..~~..X#..D.......D..#t......#", "#..~~~...#.............K.......#", "#X..~..................#......l#", "#c......X#j...........j#.......#", "#XX...cXX#.............#X.....X#", "#XXX..XXX#X.....P.....X#XX...XX#", "################################"];
Object.assign(BASEMENT,{cls:"z-basement",sub:"The Institute's first lab. Sixty years of dust, and nobody has breathed this air since.",map:MAPS["z-basement"].slice()});
if(TRACKS["explore_z-crater"]&&!TRACKS["explore_z-basement"])TRACKS["explore_z-basement"]=TRACKS["explore_z-crater"];
SIGNS["z-basement"]={"29,12":["Scratched into the plaster, low down, as if by somebody sitting on the floor: rows and rows of tally marks.","Beside the last row, smaller: 'Day 212. It is still growing. I cannot stop it. I can only keep it in.'"]};
{const _se=startExplore;startExplore=function(){if(EXP.forceZone===BASEMENT)BASEMENT.map=openedMap("z-basement");_se()}}
const BPROPS={
  o:`<g transform="rotate(-14 20 24)"><rect x="4" y="15" width="32" height="5" fill="#5A4632" stroke="#2A1E12" stroke-width="1.2"/><path d="M8 20 L6 34 M32 20 L35 33" stroke="#4A3A28" stroke-width="3"/><path d="M14 20 L16 26" stroke="#4A3A28" stroke-width="3"/></g><path d="M24 30 l3 -2 l2 3 l-3 1z M10 33 l2 -1 l1 2z" fill="#A8C8C8" opacity=".7"/><path d="M5 14 Q12 11 20 14" stroke="#B8B0A0" stroke-width=".6" fill="none" opacity=".6"/>`,
  T:`<g transform="rotate(12 20 34)"><rect x="9" y="2" width="22" height="32" fill="#4E3A26" stroke="#23180C" stroke-width="1.3"/><rect x="11" y="5" width="18" height="7" fill="#1E1409"/><rect x="11" y="15" width="18" height="7" fill="#1E1409"/><rect x="11" y="25" width="18" height="7" fill="#1E1409"/><path d="M12 12 L16 7 L17 12 M20 12 L21 6" stroke="#6A4A3A" stroke-width="2"/></g><rect x="3" y="30" width="7" height="4" fill="#6A3A34" transform="rotate(-20 6 32)"/><rect x="28" y="31" width="8" height="3" fill="#3A4A6A" transform="rotate(15 32 32)"/><path d="M4 2 L12 10 M4 6 L9 2" stroke="#D8D4C8" stroke-width=".5" opacity=".6"/>`,
  x:`<rect x="7" y="13" width="26" height="21" fill="#6E5A40" stroke="#2E2214" stroke-width="1.3"/><path d="M7 20 H33 M7 27 H33" stroke="#4E3E2A" stroke-width="1"/><path d="M7 13 L14 9 L40 9 L33 13" fill="#7E6A4E" stroke="#2E2214" stroke-width="1"/><path d="M7 13 Q12 8 18 13 M7 13 Q9 10 12 13 M7 13 L10 9" stroke="#E8E4D8" stroke-width=".5" fill="none" opacity=".75"/><ellipse cx="22" cy="12" rx="8" ry="1.4" fill="#A8A090" opacity=".45"/>`,
  y:`<path d="M9 33 L13 26 L16 33 Z M18 34 L22 24 L26 34 Z M27 33 L30 28 L33 33 Z" fill="#B8D4D0" stroke="#5A7874" stroke-width=".7" opacity=".85"/><path d="M12 22 Q12 16 16 15 L16 10 L20 10 L20 15 Q24 16 24 22 L22 26 L14 26 Z" fill="rgba(170,200,190,.55)" stroke="#5A7874" stroke-width="1" transform="rotate(70 18 20)"/><circle cx="30" cy="22" r="1" fill="#C8E0DC"/><path d="M8 35 H34" stroke="#3A342C" stroke-width="1" opacity=".5"/>`,
  K:`<path d="M3 34 L5 22 L12 20 L14 12 L24 11 L28 18 L36 20 L37 34 Z" fill="#6A625A" stroke="#2A2420" stroke-width="1.3"/>${[[6,24,8,5],[15,14,8,5],[24,20,9,5],[10,28,10,5],[22,27,9,5]].map(([x,y,w,h])=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#7E766C" stroke="#3A342E" stroke-width=".8"/>`).join("")}<path d="M18 11 L20 6 L23 10" fill="#8A827A" stroke="#2A2420"/>`,
  S:`<rect x="4" y="6" width="32" height="26" fill="#8A8278" stroke="#4A443C" stroke-width="1"/>${[0,1,2,3].map(r=>`<path d="M${8} ${11+r*5} ${Array.from({length:6},(_,i)=>`M${8+i*3.4} ${11+r*5} v4`).join(" ")} M7 ${13+r*5} L27 ${12+r*5}" stroke="#3A342C" stroke-width=".9"/>`).join("")}`};
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){if(EXP.zone.cls!=="z-basement")return _tl(c,x,y,seed,M);
  if(c==="o"||c==="T"||c==="x"||c==="y"||c==="K"||c==="S")return[c==="T"?"f tl":"f pr",PS(BPROPS[c])];
  if(c==="c")return["f pr",PS(CRATE+`<path d="M7 11 Q13 6 19 11 M7 11 L10 7" stroke="#E8E4D8" stroke-width=".5" fill="none" opacity=".75"/>`)];
  if(c===":")return["f fd v"+((seed*7+x)%4),""];if(c==="."&&((seed*3+y)%6===0))return["f crk",""];return _tl(c,x,y,seed,M)}}
{const _to=tileObjs;tileObjs=function(){if(EXP.zone.special==="basement"){const s=EXP.zone.special;EXP.zone.special=null;try{_to()}finally{EXP.zone.special=s}return}_to()}}


