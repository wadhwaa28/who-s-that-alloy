/* =============== FIELD TRAINING (tutorial) ===============
   A guided first encounter with spotlighted coach marks. Offered once after PRESS START; replay any time from "? HOW TO PLAY".
   Steps with `wait` advance on their own when the player does the thing. Radiants are deliberately never mentioned. */
const TUT={on:false,i:0,raf:0};
/* The tutorial's practice alloy. */
const TUT_ALLOY="Brass";
const TUT_STEPS=[
 {t:"WELCOME, RECRUIT!",x:"I'm Dr. Marlow, head of the Quillmoor field team. Out there, wild alloys hide in the rubble. Your job: find them, test them in the lab, and work out what they're made of. Let's do your first one together.<br><br><b>Heads up: the tutorial round earns NO points.</b> It's just practice, so your score only starts counting on real encounters."},
 {sel:".modes",t:"GAME MODES",x:"<b>Name → Elements</b>: you're told the alloy's name; you find its elements.<br><b>Mystery</b>: no name given. Type it yourself (no multiple choice!), then find its elements.<br><b>Mixed</b>: a bit of both. Your practice alloy will be a Name → Elements one."},
 {sel:"#mapwrap",t:"THE FIELD",x:"Move with the <b>arrow keys / WASD</b>, <b>tap a spot</b> on the map, or use the <b>pad</b>. Wild alloys hide in the glittering <b>rubble</b> tiles.<br><br>▶ Walk into some rubble now.",wait:()=>S.phase==="round"&&S.r,enter:()=>{EXP.since=RUBBLE_PITY}},
 {sel:"#stage",t:"A WILD ALLOY APPEARED!",x:"This is your sample. It always comes as a <b>rod</b> or a <b>vial</b> (vials can hold liquid, granules, beads, powder or shavings). Its name is on the plate. What you <i>see</i> is a clue: look at its color and shine.",delay:1400},
 {sel:"#dexcard",t:"FIELD NOTES",x:"Its entry: a description, what it's used for and how it's made. Every test you run is written into the <b>LAB NOTEBOOK</b> at the bottom. Nothing here tells you a property directly. You measure everything yourself."},
 {sel:".kit",t:"FIELD KIT: MAGNET",x:"Drag a tool onto the sample (or tap the tool, then tap the sample).<br><br>▶ Try the <b>magnet</b>: does it stick, tug, or do nothing?",wait:()=>S.r&&S.r.notes.magnet},
 {sel:".kit",t:"FIELD KIT: SCRATCH TEST",x:"Each scratch tool has a <b>Mohs hardness</b>. If a tool leaves a <b>groove</b>, it's harder than the sample. If it just skids, the sample is harder.<br><br>▶ Scratch the sample with any tool.",wait:()=>S.r&&Object.keys(S.r.scratchLog).length>0},
 {sel:"#st-scale",t:"LAB STATIONS: SET UP FIRST",x:"Lab gear works like the real thing. The scale: press <b>POWER</b>, wait for it to boot, press <b>TARE</b>, then put the sample on it: drag it, or <b>tap the sample, then tap the scale</b> (easier when the station is far down the page).<br>While I'm teaching one station, the others stay locked.<br><br>▶ Weigh your sample.",wait:()=>S.r&&S.r.notes.mass,scroll:"center"},
 {sel:"#st-cyl",t:"GRADUATED CYLINDER: VOLUME",x:"Turn the <b>FAUCET</b> on, let it fill to somewhere around 40–60 mL, then turn it <b>OFF</b>. Drag the sample in and read how far the water rises: that rise is the sample's <b>volume</b>. Mass ÷ volume = <b>density</b>. Fill past the rim and it overflows! (Dropped it into a dry cylinder? Press EMPTY and try again.)<br><br>▶ Measure its volume.",wait:()=>S.r&&S.r.notes.vol&&!/dry/.test(S.r.notes.vol),scroll:"center"},
 {sel:"#st-cyl",t:"GRADUATED CYLINDER: RUST TEST",x:"While the sample is soaking, press <b>SOAK 1 WEEK</b>. Some metals rust into a flaky crust, some grow a thin film, some don't change at all.<br><br>▶ Run the rust test.",wait:()=>S.r&&S.r.notes.rust,scroll:"center"},
 {sel:"#st-circuit",t:"CONDUCTIVITY TESTER",x:"Drag the sample between the clips, then flip the <b>SWITCH</b>. The brighter the bulb, the better it carries electricity.<br><br>▶ Test its conductivity.",wait:()=>S.r&&S.r.notes.cond,scroll:"center"},
 {sel:"#st-flame",t:"BUNSEN BURNER",x:"Open the <b>GAS</b>, open the <b>AIR</b>, then press <b>IGNITE</b>. Drag the sample into the flame and watch what color it turns and whether it throws sparks.<br><br>▶ Do a flame test.",wait:()=>S.r&&S.r.notes.flame,scroll:"center"},
 {sel:"#st-geiger",t:"GEIGER COUNTER",x:"Turn on <b>POWER</b> (and <b>SOUND</b> if you want to hear the clicks), then drag the sample under the probe. More clicks and a higher needle mean more radioactive. Way too much can burn the tube out!<br><br>▶ Check its radiation.",wait:()=>S.r&&S.r.notes.rad,scroll:"center"},
 {sel:"#st-furnace",t:"FURNACE",x:"Press <b>POWER</b>, drag the sample into the crucible, then <b>HOLD HEAT</b> and watch the temperature. Whatever happens (it melts, smokes, sparks or bursts into flame) gets logged with the temperature. HOLD CHILL cools it down.<br>Cooling never undoes a melt or a reaction on the piece in the crucible. To try again, press <b>TAKE OUT</b> to empty the crucible and put a fresh piece in.<br><br>▶ Heat it until something happens.",wait:()=>S.r&&(S.r.notes.melt||S.r.notes.react),scroll:"center"},
 {sel:"#tab-table",t:"THE PERIODIC TABLE",x:"Compare your readings with real element data in the <b>Periodic Table</b> tab: density, melting point, hardness, magnetism, flame color and more. You can also hover elements on the scanner."},
 {sel:"#picker",t:"THE ELEMENT SCANNER",x:"Pick up to <b>5 elements</b> you think are inside, then press <b>ANALYZE</b>.<br>"+(TUT_ALLOY==="Brass"?"Tip for this one: think of what trumpets are made of: a reddish metal plus the one that coats rust-proof nails.<br>":"")+"<br>▶ Pick some elements, then press <b>ANALYZE</b> just above the scanner.",dock:1,wait:()=>S.r&&(S.r.hit.size>0||S.r.miss.size>0||S.r.stage==="done"),scroll:"start"},
 {sel:".dialog",t:"READING THE RESULT",x:"<b>Super effective</b>: everything you picked is in it (maybe not all yet).<br><b>Not very effective</b>: some right, some wrong.<br><b>It missed</b>: none right.<br>Each scan that doesn't finish the job costs a <b>SCANNER CHARGE</b>. Run out and the alloy flees. HINT helps but costs points.<br>(Reminder: this practice round earns <b>no points</b>, even if you nail it.)<br><br>▶ Finish identifying it.",dock:1,wait:()=>S.r&&S.r.stage==="done",scroll:"start"},
 {sel:"#tab-dex",t:"THE ALLOYDEX",x:()=>S.r&&S.r.won?"Registered! Every alloy you identify goes into your <b>Alloydex</b>: stats, its cry, a research log and related alloys. There are over a thousand to find across 8 habitats.":"It got away this time. No worries, alloys come back. Every one you identify goes into your <b>Alloydex</b>: stats, its cry, a research log and related alloys. There are over a thousand to find across 8 habitats."},
 {t:"ONE LAST THING…",x:"If an alarm ever sounds and a <b>THREAT</b> appears, stay calm. It's a containment emergency: a meter drains while you work, and each threat fights back in its own way. The screen will tell you what to do. They're rare.<br><br>That's everything. Press <b>KEEP EXPLORING</b> when you're ready. Good luck, recruit!",end:true}
];
function tutEl(){let o=$("#tut");if(o)return o;o=document.createElement("div");o.id="tut";o.innerHTML=`<div class="tut-spot" id="tut-spot"></div><div class="tut-bub" id="tut-bub" role="dialog" aria-live="polite"><div class="tut-face">${marlowSVG()}</div><div class="tut-body"><small id="tut-n"></small><b id="tut-t"></b><p id="tut-x"></p><div class="tut-btns"><button class="btn" id="tut-skip">SKIP TUTORIAL</button><button class="btn go" id="tut-next">NEXT ▶</button></div></div></div>`;
  document.body.appendChild(o);$("#tut-skip").onclick=()=>tutEnd(true);$("#tut-next").onclick=()=>tutNext();return o}
function tutStart(){if(S.phase!=="explore"){if(S.r&&S.r.stage!=="done"){say("Finish or run from this alloy first, then start the tutorial.");return}startExplore()}
  setView&&setView("play");TUT.on=true;TUT.i=0;tutEl().hidden=false;tutShow();cancelAnimationFrame(TUT.raf);TUT.raf=requestAnimationFrame(tutLoop)}
function tutEnd(skipped){TUT.on=false;cancelAnimationFrame(TUT.raf);const o=$("#tut");if(o)o.hidden=true;store.set("wta_tut",1);if(skipped)say&&S.r&&say("Tutorial skipped. You can replay it from ? HOW TO PLAY.")}
function tutNext(){const st=TUT_STEPS[TUT.i];if(st&&st.end)return tutEnd(false);TUT.i++;if(TUT.i>=TUT_STEPS.length)return tutEnd(false);tutShow()}
function tutShow(){const st=TUT_STEPS[TUT.i];if(st.enter)st.enter();TUT.shownAt=performance.now();
  $("#tut-n").textContent=`TRAINING ${TUT.i+1}/${TUT_STEPS.length}`;$("#tut-t").textContent=st.t;$("#tut-x").innerHTML=typeof st.x==="function"?st.x():st.x;
  TUT.pre=!!(st.wait&&st.wait());if(TUT.pre)$("#tut-x").innerHTML+='<br><span class="tut-ok">✓ You already did this one!</span>';
  const nx=$("#tut-next");nx.hidden=!!st.wait&&!TUT.pre;nx.textContent=st.end?"LET'S GO! ▶":"NEXT ▶";
  const el=st.sel&&document.querySelector(st.sel);if(el)el.scrollIntoView({behavior:"smooth",block:st.scroll||"nearest"});sfx("sel")}
function tutLoop(){if(!TUT.on)return;TUT.raf=requestAnimationFrame(tutLoop);const st=TUT_STEPS[TUT.i],spot=$("#tut-spot"),bub=$("#tut-bub");
  if(st.wait&&!TUT.pre&&st.wait()&&performance.now()-TUT.shownAt>400){TUT.i++;if(TUT.i>=TUT_STEPS.length)return tutEnd(false);sfx("right");
    const nxt=TUT_STEPS[TUT.i];if(nxt.delay){TUT.hold=performance.now()+nxt.delay;bub.style.visibility="hidden";spot.style.visibility="hidden"}tutShow();return}
  if(TUT.hold&&performance.now()<TUT.hold)return;if(TUT.hold){TUT.hold=0;bub.style.visibility="";spot.style.visibility=""}
  const el=st.sel&&document.querySelector(st.sel),vw=innerWidth,vh=innerHeight;
  if(!el||el.offsetParent===null){spot.style.cssText="left:50%;top:50%;width:0;height:0";bub.className="tut-bub mid";bub.style.left=bub.style.top="";return}
  const r=el.getBoundingClientRect(),pad=6;spot.style.cssText=`left:${r.left-pad}px;top:${r.top-pad}px;width:${r.width+pad*2}px;height:${r.height+pad*2}px`;
  const bw=Math.min(420,vw-24),bh=bub.offsetHeight;let top,left=clamp(r.left+r.width/2-bw/2,12,vw-bw-12);
  if(st.dock){top=vh-bh-12;left=vw-bw-12}
  else if(r.bottom+pad+12+bh<vh)top=r.bottom+pad+12;else if(r.top-pad-12-bh>0)top=r.top-pad-12-bh;
  else if(r.right+bw+24<vw){left=r.right+12;top=clamp(r.top,12,vh-bh-12)}else if(r.left-bw-24>0){left=r.left-bw-12;top=clamp(r.top,12,vh-bh-12)}
  else{top=vh-bh-12;left=vw-bw-12}
  bub.className="tut-bub";bub.style.left=left+"px";bub.style.top=Math.max(12,top)+"px"}
/* practice encounter: a friendly Name → Elements alloy, never a threat */
{const _pa=pickAlloy;pickAlloy=function(kind,used){if(TUT.on&&TUT.i<=3){const a=ALLOYS.find(x=>x.name===TUT_ALLOY);if(a)return a}return _pa(kind,used)}}
{const _sr2=startRound;startRound=function(){if(TUT.on&&TUT.i<=3){const m=S.mode;S.mode="recipe";EXP.nextRadiant=false;_sr2();S.mode=m;if(S.r)S.r.tut=true}else _sr2()}}
/* header button + first-time offer */
{const b=document.createElement("button");b.className="aubtn tutbtn";b.id="tut-open";b.textContent="? HOW TO PLAY";b.onclick=()=>tutStart();$(".audio").prepend(b)}
{const sb=$("#startbtn"),old=sb.onclick;sb.onclick=e=>{old&&old(e);if(!store.get("wta_tut",0)&&!TUT.offered){TUT.offered=true;setTimeout(()=>{const o=document.createElement("div");o.className="tut-offer";
  o.innerHTML=`<div class="tut-bub mid"><div class="tut-face">${marlowSVG()}</div><div class="tut-body"><b>FIRST TIME HERE?</b><p>Dr. Marlow can walk you through your first alloy. It takes about three minutes.</p><div class="tut-btns"><button class="btn" id="tut-no">NO THANKS</button><button class="btn go" id="tut-yes">TEACH ME ▶</button></div></div></div>`;
  document.body.appendChild(o);$("#tut-yes").onclick=()=>{o.remove();tutStart()};$("#tut-no").onclick=()=>{o.remove();store.set("wta_tut",1)}},500)}}}

/* ---- Tutorial lock: only the thing being taught can be used. Everything else is blocked until the step is done. ---- */
const TUT_RULES={
 "THE FIELD":{allow:"#mapwrap,.dpad",keys:true},
 "FIELD KIT: MAGNET":{allow:'.tool[data-id="magnet"],#specimen',drops:["magnet>sample"]},
 "FIELD KIT: SCRATCH TEST":{allow:'.tool:not([data-id="magnet"]),#specimen',drops:["scratch>sample"]},
 "LAB STATIONS: SET UP FIRST":{allow:"#st-scale,#specimen",drops:["sample>scale"]},
 "GRADUATED CYLINDER: VOLUME":{allow:"#st-cyl,#specimen",drops:["sample>cyl"]},
 "GRADUATED CYLINDER: RUST TEST":{allow:"#st-cyl"},
 "CONDUCTIVITY TESTER":{allow:"#st-circuit,#specimen",drops:["sample>circuit"]},
 "BUNSEN BURNER":{allow:"#st-flame,#specimen",drops:["sample>flame"]},
 "GEIGER COUNTER":{allow:"#st-geiger,#specimen",drops:["sample>geiger"]},
 "FURNACE":{allow:"#st-furnace,#specimen",drops:["sample>furnace"]},
 "THE ELEMENT SCANNER":{allow:"#picker,#btn-analyze",deny:"#btn-flee,#btn-hint"},
 "READING THE RESULT":{allow:"#picker,#btn-analyze",deny:"#btn-flee,#btn-hint"}};
const tutRule=()=>TUT.on?(TUT_RULES[TUT_STEPS[TUT.i].t]||{}):null;
function tutNudge(){if(!gate("tutnudge",700))return;const b=$("#tut-bub");if(b){b.classList.remove("nudge");void b.offsetWidth;b.classList.add("nudge")}sfx("bump")}
function tutAllowed(el){const R=tutRule();if(!R)return true;if(!el||!el.closest)return false;
  if(el.closest("#tut-bub,#au-mus,#au-sfx,#bossbar,.exting,.phx-ember,#phx-sync,.h2bub,.rot,#crown-drape,#glare"))return true;   // threat controls always work, even mid-lesson
  if(TUT.hold&&performance.now()<TUT.hold)return false;
  if(R.deny&&el.closest(R.deny))return false;return !!(R.allow&&el.closest(R.allow))}
["pointerdown","mousedown","touchstart","click","dblclick","contextmenu"].forEach(ev=>window.addEventListener(ev,e=>{
  if(!TUT.on||tutAllowed(e.target))return;e.stopImmediatePropagation();e.preventDefault();if(ev==="pointerdown"||ev==="touchstart")tutNudge()},{capture:true,passive:false}));
window.addEventListener("keydown",e=>{if(!TUT.on||e.key==="Tab")return;const R=tutRule();
  if(R.keys&&KEYS[e.key])return;if(e.target&&e.target.closest&&e.target!==document.body&&tutAllowed(e.target))return;
  if(e.target&&e.target.closest&&e.target.closest("#tut-bub"))return;e.stopImmediatePropagation();e.preventDefault()},true);
{const _dd2=doDrop;doDrop=function(p,key){const R=tutRule();if(R){const what=p.kind==="sample"?"sample":p.id==="magnet"?"magnet":"scratch";
    if(!(R.drops||[]).includes(what+">"+key)){tutNudge();setHeld(null);return}}_dd2(p,key)}}
{const _sh=setHeld;setHeld=function(p){const R=tutRule();if(R&&p){const what=p.kind==="sample"?"sample":p.id==="magnet"?"magnet":"scratch";if(!(R.drops||[]).some(d=>d.startsWith(what+">"))){tutNudge();return _sh(null)}}_sh(p)}}

/* ---- Victory theme: an original song that plays after an alloy is profiled, until you keep exploring ---- */
TRACKS.victory={bpm:132,lv:.11,bv:.28,
  lead:"G5 - B5 - D6 - B5 G5 A5 - F#5 - D5 - F#5 A5 B5 - G5 E5 G5 - B5 - C6 - B5 A5 G5 - E5 - D5 G5 B5 D6 - B5 G5 B5 A5 - - F#5 A5 - D6 - E6 - D6 C6 B5 - A5 - F#5 - A5 - D6 - - - E5 G5 B5 E6 - D6 B5 - C6 - G5 - E5 - G5 C6 B5 - D6 - G6 - D6 B5 A5 - F#5 - A5 B5 C6 - E6 - C6 - G5 - C6 E6 D6 - A5 - F#5 - A5 D6 G6 - D6 B5 G5 - B5 D6 G5 - - - . . D5 F#5",
  bass:"G2 . D3 . G3 . D3 . D2 . A2 . D3 . A2 . E2 . B2 . E3 . B2 . C2 . G2 . C3 . G2 . G2 . D3 . G3 . D3 . D2 . A2 . D3 . A2 . C2 . G2 . C3 . G2 . D2 . A2 . D3 . A2 . E2 . B2 . E3 . B2 . C2 . G2 . C3 . G2 . G2 . D3 . G3 . D3 . D2 . A2 . D3 . A2 . C2 . G2 . C3 . G2 . D2 . A2 . D3 . A2 . G2 . D3 . G3 . D3 . G2 . D3 . G3 . D3 .",
  drum:"k . s h k k s h",fill:"k s k s s s c c",parts:[{k:"arp",type:"triangle",vol:.035,oct:5},{k:"stab",type:"pulse",vol:.022,oct:4}],chime:true};
CHORDS.victory="G D Em C G D C D Em C G D C D G G".split(" ");
{const _wv=win;win=function(){_wv();const r=S.r;setTimeout(()=>{if(S.r===r&&r.stage==="done"&&r.won&&S.phase==="round")startTrack("victory")},1500)}}

/* ---- Tutorial rounds never award points (no practice-alloy farming) ---- */
{const _wt=win;win=function(){const r=S.r,R=S.run;if(!r||!r.tut)return _wt();
  const best=S.best,streak=R.streak,d=S.dex[r.a.name],db=d&&d.b;_wt();
  R.score-=r.pts;r.pts=0;R.streak=streak;const lg=R.log[R.log.length-1];if(lg)lg.pts=0;
  S.best=best;store.set("wta_best2",best);const d2=S.dex[r.a.name];if(d2){if(db==null)delete d2.b;else d2.b=db;saveDex()}
  renderAll();say(`Gotcha! ${r.a.name.toUpperCase()} is in your Alloydex. This was a TUTORIAL round, so it earns no points.`)}}
{const _ra2=renderActions;renderActions=function(){_ra2();const r=S.r;if(r&&r.tut){const sp=document.querySelector("#actions .btn-next, #btn-next");const lab=sp&&sp.nextElementSibling;if(lab&&r.stage==="done")lab.textContent="Tutorial round: no points"}}}

/* ---- "It got away" theme: an original, wistful song for when an alloy escapes or you run, until you keep exploring ---- */
TRACKS.escape={bpm:92,lv:.1,bv:.22,
  lead:"E5 - - G5 B5 - A5 G5 E5 - - - C5 - D5 E5 D5 - B4 - G4 - B4 D5 F#5 - - E5 D5 - A4 - G5 - - F#5 E5 - B4 - C5 - E5 - A5 - G5 E5 F#5 - D#5 - B4 - D#5 F#5 B5 - - - A5 - F#5 - G5 - - E5 C5 - E5 G5 B5 - - A5 G5 - D5 - C6 - B5 A5 E5 - A5 C6 B5 - - - G5 - E5 - E5 - G5 - C6 - B5 A5 A5 - F#5 - D5 - A5 - G5 - F#5 - E5 - D#5 - E5 - - - . . . .",
  bass:"E2 - - - B2 - - - C2 - - - G2 - - - G2 - - - D3 - - - D2 - - - A2 - - - E2 - - - B2 - - - A2 - - - E3 - - - B1 - - - F#2 - - - B1 - - - F#2 - - - C2 - - - G2 - - - G2 - - - D3 - - - A2 - - - E3 - - - E2 - - - B2 - - - C2 - - - G2 - - - D2 - - - A2 - - - E2 - - - B2 - - - E2 - - - B2 - - -",
  drum:"k . . h s . . h",fill:"k . . h s . c .",parts:[{k:"pad",type:"sine",vol:.045,oct:4},{k:"broken",type:"triangle",vol:.05,oct:4}]};
CHORDS.escape="Em C G D Em Am B B C G Am Em C D Em Em".split(" ");
{const _ls=lose;lose=function(ran){_ls(ran);const r=S.r;setTimeout(()=>{if(S.r===r&&r&&r.stage==="done"&&!r.won&&S.phase==="round")startTrack("escape")},1400)}}

/* ---- Lab bench samples: rods are drawn as real rods, standing upright on every station except the conductivity clips
   (which keep the original clamped block). Vials (liquids, powders, granules...) keep the original colored block everywhere. ---- */
const SKINS=["sc-chunk","cy-chunk","gm-chunk","fz-solid"];
let skinN=0;
function rodDims(x,y,w,h,id){if(id==="fz-solid"){const f=FZ.melted?1:(FZ.mprog||0),rw=14*(1+.8*f),rh=Math.max(0,36*(1-f));return{cx:x+w/2,rw,rh,top:y+h-rh,bot:y+h,f}}
  if(id==="cy-chunk")return{cx:x+w/2,rw:16,rh:74,top:y+h-74,bot:y+h};   // a full-size rod standing in the cylinder
  const rw=Math.max(6,Math.min(w*.42,14)),rh=Math.max(h,Math.min(rw*2.8,40));return{cx:x+w/2,rw,rh,top:y+h-rh,bot:y+h}}
function rodSVG(a,x,y,w,h,id){const u="sk"+(skinN++),c=a.color,hi=shade(c,.6),lo=shade(c,-.5),face=shade(c,.25),F=v=>(+v).toFixed(1),{cx,rw,rh,top,bot,f=0}=rodDims(x,y,w,h,id),ry=Math.min(rh/2,rw*(.22+.4*f));
  return `<defs><linearGradient id="${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${lo}"/><stop offset=".28" stop-color="${hi}"/><stop offset=".5" stop-color="${c}"/><stop offset="1" stop-color="${shade(c,-.6)}"/></linearGradient></defs>
    <ellipse cx="${F(cx)}" cy="${F(bot)}" rx="${F(rw/2)}" ry="${F(ry)}" fill="${lo}"/>
    <rect x="${F(cx-rw/2)}" y="${F(top)}" width="${F(rw)}" height="${F(rh)}" fill="url(#${u})"/>
    <rect x="${F(cx-rw*.28)}" y="${F(top+ry+1)}" width="${F(Math.max(.8,rw*.12))}" height="${F(Math.max(0,rh-ry*2-2))}" fill="#fff" opacity=".55"/>
    <ellipse cx="${F(cx)}" cy="${F(top)}" rx="${F(rw/2)}" ry="${F(ry)}" fill="${face}" stroke="rgba(0,0,0,.3)" stroke-width=".6"/>`}
function syncSkins(){requestAnimationFrame(syncSkins);const a=S.r&&S.r.a;if(!a)return;const rod=a.form!=="vial";
  for(const id of SKINS){const el=document.getElementById(id);if(!el)continue;const rect=el.tagName==="g"?el.querySelector("rect"):el;if(!rect)continue;
    let sk=document.getElementById("skin-"+id);if(!sk){sk=document.createElementNS("http://www.w3.org/2000/svg","g");sk.id="skin-"+id;sk.setAttribute("pointer-events","none");rect.parentNode.insertBefore(sk,rect.nextSibling)}
    rect.style.fillOpacity=rod?"0":"";rect.style.strokeOpacity=rod?"0":"";
    const g=k=>+rect.getAttribute(k)||0,sig=[a.no,rod,g("x"),g("y"),g("width"),g("height"),id==="fz-solid"?Math.round((FZ.mprog||0)*40):0].join("|");
    const vis=el.tagName==="g"?el.getAttribute("opacity"):rect.getAttribute("opacity");sk.setAttribute("opacity",vis==null?1:vis);
    if(sk.dataset.sig!==sig){sk.dataset.sig=sig;sk.innerHTML=rod&&g("width")>0&&g("height")>0?rodSVG(a,g("x"),g("y"),g("width"),g("height"),id):""}}
  // furnace glow/crust/frost and the soak film sit on the rod itself, not on the old block
  const fs=document.getElementById("fz-solid");
  if(fs){const x=+fs.getAttribute("x"),y=+fs.getAttribute("y"),w=+fs.getAttribute("width"),h=+fs.getAttribute("height");
    ["fz-solidglow","fz-solidcrust","fz-frost"].forEach(id=>{const e=document.getElementById(id);if(!e)return;
      if(rod&&h>0){const d=rodDims(x,y,w,h,"fz-solid");e.setAttribute("x",d.cx-d.rw/2);e.setAttribute("width",d.rw);e.setAttribute("y",d.top);e.setAttribute("height",d.rh);e.setAttribute("rx",1)}
      else{e.setAttribute("x",x);e.setAttribute("width",w);e.setAttribute("rx",3)}})}
  // runs of molten metal down the sides while it melts
  if(fs){let dr=document.getElementById("fz-drips");if(!dr){dr=document.createElementNS("http://www.w3.org/2000/svg","g");dr.id="fz-drips";fs.parentNode.appendChild(dr)}
    const f=FZ.melted?1:(FZ.mprog||0),x=+fs.getAttribute("x"),y=+fs.getAttribute("y"),w=+fs.getAttribute("width"),h=+fs.getAttribute("height");
    const box=rod?rodDims(x,y,w,h,"fz-solid"):{cx:x+w/2,rw:w,rh:h,top:y,bot:y+h},sig=[a.no,Math.round(f*40),Math.round(box.rw),Math.round(box.rh)].join("|");
    if(dr.dataset.sig!==sig){dr.dataset.sig=sig;
      if(f<=0||f>=1||box.rh<2){dr.innerHTML=""}
      else{const c=a.color,hi=shade(c,.6),L=box.rh*.9*Math.min(1,f*1.6),xs=[box.cx-box.rw*.46,box.cx+box.rw*.1,box.cx+box.rw*.44],sd=[.35,.15,.55];
        dr.innerHTML=xs.map((px,k)=>{const y0=box.top+box.rh*sd[k]*(1-f),y1=Math.min(box.bot,y0+L*(.6+.2*k)),r=1.4+1.4*f;
          return `<path d="M${px.toFixed(1)} ${y0.toFixed(1)} L${px.toFixed(1)} ${y1.toFixed(1)}" stroke="${c}" stroke-width="${(2+2*f).toFixed(1)}" stroke-linecap="round"/><circle cx="${px.toFixed(1)}" cy="${y1.toFixed(1)}" r="${r.toFixed(1)}" fill="${c}"/><circle cx="${(px-.6).toFixed(1)}" cy="${(y1-.8).toFixed(1)}" r="${(r*.35).toFixed(1)}" fill="${hi}" opacity=".8"/>`}).join("")+
          `<ellipse cx="${box.cx.toFixed(1)}" cy="${box.bot.toFixed(1)}" rx="${(box.rw*.5+8*f).toFixed(1)}" ry="${(2+3*f).toFixed(1)}" fill="${c}"/>`}}}
  const cc=document.getElementById("cy-chunk"),cr=document.getElementById("cy-rust");
  if(cc&&cr){const x=+cc.getAttribute("x"),y=+cc.getAttribute("y"),w=+cc.getAttribute("width"),h=+cc.getAttribute("height");
    if(rod){const d=rodDims(x,y,w,h,"cy-chunk");cr.setAttribute("x",d.cx-d.rw/2);cr.setAttribute("width",d.rw);cr.setAttribute("y",d.top);cr.setAttribute("height",d.rh);cr.setAttribute("rx",1)}
    else{cr.setAttribute("x",x);cr.setAttribute("width",w);cr.setAttribute("y",y);cr.setAttribute("height",h);cr.setAttribute("rx",3)}}}
requestAnimationFrame(syncSkins);


const RUBBLE_PITY=26,RUBBLE_P=.05;   // wild alloys are scarce now: about 1 in 20 rubble steps, and a sure thing after 26 without one
/* =============== THE WIDER WORLD: hand-laid maps with a scrolling camera, an INTERACT button, proper dialogue, the people who live out there, items, the Slag Syndicate, and the founder's quest =============== */

/* ---- the maps: every one laid out by hand. The view is 17 by 11 tiles and follows you around. ---- */
const VIEW={w:17,h:11};
const MAPS={"z-mine": ["########################################", "#y:y:y:y#ddd#ddddd###,,,x,,,,,##,,,,,,##", "#:::::::#d###d#d#d###,,,,,,,,,##,,,x,,##", "#:::::::dddddd#d#d###,,x,,,T,,##,,,,,,##", "#########d#d#d#d######,,,,,,,####,,,,###", "#ddd#ddddd#ddd#ddd######,,,######,,,,###", "#d###d###########d#######K########o.S###", "#ddddd#d#########d#######.####L###...###", "#d#####d###.............=..............#", "#d#ddd#,dd#.............=...........T..#", "#d#ddd###d#############.=###############", "#,#d#ddddd#cxx.x..c####.=#.,,......#####", "#,#d#####d#........####.=#....wwwwww####", "#,#d#ddd#d#.............=.....w~~~~w,,,#", "#d#d#dd##d#S.....y.####.=#,...w~~~~w,x,#", "#dd,#,dddd#cc..xx..####.=#....w~~~~w,,,#", "#######################.=#.T..w~~~~w,,,#", "##y:::S:::y############.=#....w~~~~w,,,#", "##:::::::::############.=#....wwwwww####", "##:::::::::###..........=###############", "##::x::::::...,,,,......=......#########", "##:::::::::...,,,.......=...o..#,,,,,,,#", "##::::::x::...,,........=.......,,x,,,,#", "##:::::::::#........,...P......#,,,,,,,#", "############..................##,,,,,,,#", "######################L.....L###########"], "z-scrap": ["########################################", "#.x..x..x..x................o~~~~~o....#", "#.T,,T..T,,T...............o~~~~~~~o.,.#", "#.T,,T,,T,,T.,..............~~~~~~..,,.#", "#.T..T,,T..T,,..............o~~~~o..,x.#", "#.T,,T,,T,.T,,.........................#", "#.T,.T..T,,T....:::::::::::.......T..T.#", "#.T,,T.,T,,T.,,.:o:::::::o:.x.x..,,,,,.#", "#.T,,T,,T..T,,..::::y::::::.,,,..,,x,,.#", "#.T..T,,T,,T....:::::::::::.,,,..,,,,,.#", "#.x..x..x..x....:o:::::::o:.x.x...T..T.#", "#...............:::::::=:::.....########", "#.xx..,,,..x...........=........#,,,,,,#", "#.x,,,,,,,.xx.....o....=....,,,.#,,T,,,#", "#..,,,xx,,,............=...,,,,.#,x,,,,#", "#.,,,,xx,,,,....x......=....,,.S#,,,,T,#", "#.,,x,,,,,x,,..........=........c,,,,,,#", "#..,,,,,,,,,......o....=....x...#,,x,,,#", "#.x.,,,..,,..x.........=........#,,,.,T#", "#......................=..#######,,,,,,#", "#..~~~....T.T..........=..S::::##T,,x,,#", "#.~~~~~..TTT...........=...::o:##,,,,,,#", "#..~~~o...T............=..#:o::##,,T,,,#", "#.o...................P=..#######,,,,,,#", "#.x.x................L.=.L##############", "#######################=################"], "z-wreck": ["~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "~~~~~~~T..T~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "~~~~~T.,,.,..T~~~~~~~~~~~~~~~~wwww~~~~~~", "~~~~.,,T,,.,,,.T~~~~~~~~~~~~wwwyyww~~~~~", "~~~T..,,,..T.,,,..~~~~~~~~~wwww##www~~~~", "~~~..,,.T...,,..T..~~~~~~~~ww##,,##ww~~~", "~~.T.........::....:~~~~~~~ww#,,.,,#ww~~", "~~..x......:::::::::w~~~~~~ww#,,,x,#ww~~", "~~.....::::wwwwwwww:w~~~~~~ww#,,,,,#ww~~", "~~.#####.::w~~~~~~w::www~~~ww#,,,.,#ww~~", "~~.#::c#.::w~o~~~~w:::wwwwwww##,,,##www~", "~~.#:y:S..:www~~~ww::::::::www#,,,#www~~", "~~.#:::#...::wwwww::,,,,::::www#.##ww~~~", "~~.##.##....::::::::,,,,,:::wwwwwwww~~~~", "~~...........,,,......,,,,:::::::ww~~~~~", "~~.x......,,,,,,..............:::~~~~~~~", "~~..o....,,,,,,,......o.........====~~~~", "~~.......,,,T,,.......o.........====~~~~", "~~T...........................:::~~~~~~~", "~~~...o......,,,,,.......,,,,::::~~~~~~~", "~~~~.........,,,,,,.....,,,,,,::~~~~~~~~", "~~~~~..x...P...........,,,,,:::~~~~~~~~~", "~~~~~~:::::::::::::::::::::::~~~~~~~~~~~", "~~~~~~~~wwwwwwwwwwwwwwwwwwww~~~~~~~~~~~~", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"], "z-volcano": ["########################################", "#####...T..######~~~##..y..y..##~~~#####", "###..,,,..,,..###~~~#.y.::::.y.#~~~#####", "##..,,T,,..,,..##~~~..::::::::..~~~#..##", "##.,,,,,,,,,,,..#~~~y.:::~~:::.y~~~,,,.#", "#..,,,T,,..,,,...===.::::~~::::.===.,,.#", "#..##.##.,,,,...#~~~y.::::::::.y~~~,,,,#", "#..#::x#..,,,T..#~~~#.y.::::.y.#~~~,T,,#", "#..#:::::.,,,,..#~~~##S.......##~~~,,,.#", "#..#x::S#...,,..#~~~###..T...###~~~..,.#", "#..###.##.......#~~~#....,,....#~~~...##", "#......T........#~~~#..,,,,,,..#~~~#..##", "#..,,,,.....T...#~~~#.,,,,,,,,.#~~~#..##", "#..,,,,,,........===..,,,T,,,,..===....#", "#.T,,,,,,,..T...#~~~#.,,,,,,,,.#~~~.,,##", "#..,,,,,......,,#~~~#..,,,,,,..#~~~.,,##", "#.....T...,,,,,,#~~~#....,,....#~~~..T##", "##.....,,,,,,T,,#~~~##..x..x..##~~~#K###", "##..T..,,,,,,,,.#~~~#.T......T.#~~~,.,,#", "###..............===............~~~,.,,#", "###..,,,.....T..#~~~#....T.....#~~~,..,#", "####.,,,,,...P..#~~~#..........#~~~,,T,#", "#####.,,........#~~~##..,,,,..##~~~,,,,#", "######.........##~~~###.,,,,.###~~~#####", "#################~~~############~~~#####", "########################################"], "z-vault": ["########################################", "#####c,,,c##########o==o#########,,,,###", "#####,,,,,##########====########,,x,,###", "#####c,,,c######T##y====y##T####,,,,,###", "#######.#######..#..====..#..###K#######", "#,,,,#...#,,,,#..x..====..x..#...#,,,,,#", "#,oo,#...#,,o,#.....====.....#.x.#,,o,,#", "#,,,,c...c,,,,#..T..====..T..#...c,,,,,#", "###.##...##.###.....====.....###.##.####", "#...................====..............##", "#..x..y..x..T.......====.......T..x..y.#", "#...................====...............#", "#..T....T....T..x...====...x..T....T...#", "#...................====...............#", "##########.#####T...====...T#####.######", "#yyy.....#.#........====........#......#", "#y:::::::#.#..x..T..====..T..x..#.,,,,.#", "#y:::S:::..#........====........#.,,,,.#", "#y:::::::#.###.####.====.####.###.,,,,.#", "#yyy.....#...#.#....====....#.#...,,,,.#", "######.###...#.#..x.====.x..#.#........#", "#............#.#....====....#.#...o..o.#", "#..T....T....#.#....====....#.#........#", "#............#.##L..====..L##.#........#", "#............#......====.......#.......#", "####################=P==################"], "z-reactor": ["########################################", "#yx:x:xy#......T..T..T......#c.c.c.c.c.#", "#:::::::#...................#..........#", "#:::S:::#..,,,,..........,,,#c.c.c...c.#", "#:::::::.....,,,,,,.....,,,,...........#", "#::y::::#..,,,,,,,.......,,,#c.c.c.c.c.#", "####.####...................############", "#..........====================........#", "#..T...o...=::::::::::::::::::=....o...#", "#..........=:~~~~~~~~~~~~~~~~:=........#", "#y.,,,,....=:~~~~~~~~~~~~~~~~:=....,,,.#", "#..,,,,,...=:~~~~~~oooo~~~~~~:=...,,,,.#", "#..,,,,....=:~~~~~~oooo~~~~~~:=...,,,,y#", "#..,,,.....=:~~~~~~~~~~~~~~~~:=....,,,.#", "#y.........=:~~~~~~~~~~~~~~~~:=........#", "#..T.......=::::::::::::::::::=....T...#", "#..........====================........#", "#......o...........................o...#", "####.#######...,,,,.......,,,,...#######", "#wwwwwww##.....,,,,,.....,,,,,...#yTTTy#", "#w,,,,,w##..T..,,,..........T....#:::::#", "#w,,,,,w......................o..#::::.#", "#wwwwwww##......y........y.......#:y:::#", "##########........................:::::#", "#y...........o...P....o...........:::::#", "########################################"], "z-glacier": ["########################################", "###::::::::::::::####::::::::::::::#####", "##::T:::,,,,:::T:::##::::,,,,::::T:::###", "#:::::,,,,,,,,:::::::::::,,,,,,::::::::#", "#::#####::,,,,,,:::::::::::,,,,:::T:::##", "#::#:::#:::::::::.........::::::::::::##", "#::#:y:.::::::......~~~~.......:::::::##", "#::#:S:#::::....~~~~~~~~~~~~....::::T::#", "#::##.##:::...~~~~~~~~~~~~~~~~...::::::#", "#:::::::::...~~~~~~~~~~~~~~~~~~..::::::#", "#::T::::=========================::::::#", "#:::::::::...~~~~~~~~~~~~~~~~~~..::x:::#", "#::::::::::...~~~~~~~~~~~~~~~~..y.:::::#", "##:::T::::::...~~~~~~~~~~~~~~...x:::T::#", "##::::::::::::....~~~~~~~~.....:::::::##", "###wwww:::::::::.............::::::::::#", "#wwT,,w::::::::::::::::::::::::::::::::#", "#w,,,,w::::::,,,,,:::::T:::::,,,,,:::::#", "#w,,T,w::T:::,,,,,,:::::::::,,,,,,:::::#", "#ww,,ww::::::,,,,,::::::::::::,,,,:::::#", "####KK####::::::::::::T:::::::::::::::##", "#,,,,,,,,#:::::::::::::::::::::::####T##", "#,T,.,,T,#::::::P::::::::::::::::#,,,,,#", "#,,,,x,,,K::::::::::::::::::::::::,,T,,#", "#,,T,,,,,#:::::::::::::::::::::::#,,,,,#", "########################################"], "z-quill": ["#########################################W####W####W####", "#xx.xxx.xxxx.xxx.xx#.......==.......#xxx.fff..F..xxxxxx#", "#::::::::::::::::::#..T..T.==.T..T..#..................#", "#::o:::o::::o:::o::#.......==.......#..A.:::::::::.ee..#", "#::::::::::::::::::#..T..T.==.T..T..#..r.:mm::::::.....#", "#y:o:::o::::o:::o::........==.......#..A.:mm::::::..h..#", "#::::::::::::::::::#..T..T.==.T..T.......:::::::::.....#", "#x::::::::::::::::y#.......==.......#G...:::::::::.un..#", "#xx::::::::::::::xx#..T..T.==.T..T..#..................#", "####################.......==.......#yy............yy..#", "#x.x.x.x.x.x.x.x.x.#..T..T.==.T..T..#...S..........x...#", "#..................#.......==.......#xx..............xx#", "#x.x.x..........x.....T..T.==.T..T..####################", "#........x.x.x.....#.......==.......#T.T.T..q.q..T.T.TT#", "#S.................#.......==.......#..................#", "#x.x.x.x.x.x.x.x.x.#.o..y..==..y..o.#.oo..oo.....oo..oo#", "####################.......==.......#..................#", "#xx..y.......S...xx#.,,,,..==..,,,,.#..y............y..#", "#::::::::::........#.,,,,..==..,,,,....................#", "#:o:::o::::....o.....,,,,..==..,,,,.#.oo..oo.....oo..oo#", "#::::::::::....y...#.......==.......#..................#", "#xx..............xx#.......==.......#x..x.........v...x#", "####################y......==......y#T...S........x...T#", "#kkkkkkkk..kkkkkkkk#.......==.......####################", "#..................#..T..T.==.T..T..#xxxxxxxx#y.......y#", "#..bbbb......bbbb..#.......==.......#S.......#..b...b..#", "#..................#..T..T.==.T..T..#.o....o.#.........#", "#kkkk....M.....kkk.........==.......#........#..o...o..#", "#..................#.......==................#.........#", "#..bbbb......bbbb..#.o.....==.....o.#.................y#", "#..................#....ooo==ooo....#xx....xx#..b...b..#", "#kk......S.......kk#.......==.......#x......x#.........#", "#kkkkkkkk..kkkkkkkk#.......=P.......#xxxxxxxx#y...S...y#", "#########################L#..L##########################"], "z-crater": ["########################################", "#::::::::::::::::::::::::###############", "#::,,,,:::T::::::::,,,,::#x...x....y#.,#", "#:,,,,,,:::::::::::,,,,,:#..........K..#", "#::,,,,:::::::T::::::,,::#....S.....#,,#", "#::::::::::::::::::::::::#..........####", "#:::T:::=================#...x..x...#::#", "#:::::::=:::::::::::::::=#####.######::#", "#::y::::=::::,,,,,,,::::=::::::::::::::#", "#:::::::=:::,,,~~~~,,,::=::::::T:::::::#", "#:::::::=:::,,~~~~~~~~,,=::::::::::::::#", "#:::T:::=::,,~~~~~~~~~~,=:::::y::::::::#", "#:::::::=::,~~~~yy~~~~~~=::::::::::::::#", "#:::::::=::,,~~~~~~~~~~,=:::::::::::T::#", "#:::::::=:::,,~~~~~~~~,,=::::::::::::::#", "#::T::::=::::,,,~~~~,,,:=::::,,,,::::::#", "#:::::::=:::::,,,,,,,:::=:::,,,,,,:::::#", "#:::::::=:::::::::::::::=::::,,,,::::::#", "#:,,,:::=================::::::::::y:::#", "#,,,,,:::::::::::::::::::::::::::::::::#", "#,,T,,::::::y:::::::T:::::::::::::,,,::#", "#:,,,::::::::::::::::::::::::::::,,,,,:#", "#::::::::::P:::::::::::::::::::::,,T,,:#", "#::::T::::::::::::::::T:::::::::::,,,::#", "#::::::::::::::::::::::::::::::::::::::#", "########################################"]};
const SPOTS={"z-mine": {"keeper": [4, 2], "disc": [4, 21], "amb1": [28, 13], "amb2": [21, 23], "side": [37, 9], "book": [4, 3], "lamp1": [2, 3], "lamp2": [6, 3], "lamp3": [4, 1], "draylamp": [37, 9], "nlamp1": [3, 5], "nlamp2": [7, 7], "nlamp3": [7, 13]}, "z-scrap": {"keeper": [18, 8], "disc": [15, 21], "amb1": [22, 10], "amb2": [13, 11], "side": [1, 18], "grist": [36, 18]}, "z-wreck": {"keeper": [33, 9], "disc": [17, 18], "amb1": [10, 6], "amb2": [20, 21], "side": [4, 5], "chest": [32, 6], "home": [5, 14], "lagoonKey": [15, 12], "waders": [6, 10]}, "z-volcano": {"keeper": [37, 20], "disc": [9, 11], "amb1": [3, 16], "amb2": [26, 19], "side": [9, 10], "home": [25, 8], "fire": [25, 5]}, "z-vault": {"keeper": [6, 17], "disc": [6, 22], "amb1": [21, 12], "amb2": [27, 13]}, "z-reactor": {"keeper": [5, 7], "disc": [5, 2], "amb1": [22, 17], "amb2": [36, 21], "logs": [35, 3]}, "z-glacier": {"keeper": [4, 22], "disc": [20, 16], "amb1": [34, 12], "amb2": [36, 20], "side": [35, 22], "home": [6, 9], "pick": [4, 17]}, "z-quill": {"keeper": [8, 4], "disc": [24, 31], "amb1": [22, 14], "amb2": [50, 27], "amb3": [7, 19], "amb4": [40, 28], "register": [4, 11], "cabinet": [6, 13], "seal": [28, 0], "portrait": [31, 0], "crucible": [46, 17], "motto": [26, 33], "marlow": [48, 4], "mdesk": [47, 4], "marlowLab": [48, 18], "wardrobe": [9, 27]}, "z-crater": {"keeper": [28, 5], "disc": [4, 10], "amb1": [29, 12], "amb2": [10, 18], "film": [38, 3]}};
/* fixed landmarks in the Institute's hall */
const HALL={seal:SPOTS["z-quill"].seal,portrait:SPOTS["z-quill"].portrait,crucible:SPOTS["z-quill"].crucible,motto:SPOTS["z-quill"].motto};
const BASEMENT={name:"THE FOUNDER'S BASEMENT",sub:"The first lab the Institute ever had. Nobody has breathed this air in decades.",cls:"z-quill",special:"basement",map:["#################","#.......#.......#","#.......#.......#","#...............#","#.......#.......#","####.####.......#","#.......#.......#","#...............#","#.......#.......#","#.......P.......#","#################"]};
const STUDY={name:"A HIDDEN STUDY",sub:"Behind the portrait. Somebody has been living here.",cls:"z-quill",special:"study",map:["#############","#...........#","#...........#","#...........#","#.....P.....#","#############"]};
{const _se=startExplore;startExplore=function(){ZONES.forEach(z=>{z.map=openedMap(z.cls)});if(!EXP.forceZone&&questPull())EXP.forceZone=questPull();_se();camSetup()}}
function camSetup(){const mw=$("#mapwrap");mw.style.aspectRatio=`${VIEW.w}/${VIEW.h}`;let w=$("#world");if(!w){w=document.createElement("div");w.id="world";mw.insertBefore(w,mw.firstChild);w.appendChild($("#map"));w.appendChild($("#player"))}
  w.style.width=(EXP.W/VIEW.w*100)+"%";w.style.height=(EXP.H/VIEW.h*100)+"%";cam(true)}
function cam(instant){const w=$("#world");if(!w||!EXP.W)return;const ax=(v,W,V)=>W<=V?-(V-W)/2:Math.max(0,Math.min(W-V,v-(V-1)/2)),cx=ax(EXP.x,EXP.W,VIEW.w),cy=ax(EXP.y,EXP.H,VIEW.h);
  if(instant)w.style.transition="none";w.style.transform=`translate(${-cx/EXP.W*100}%,${-cy/EXP.H*100}%)`;if(instant){void w.offsetWidth;w.style.transition=""}}
{const _pp=placePlayer;placePlayer=function(instant){_pp(instant);cam(instant);nearMarks()}}
addEventListener("resize",()=>cam(true));

/* ---- quest state ---- */
const Q={get s(){return store.get("wta_q",0)},set s(v){store.set("wta_q",v);store.set("wta_qf_seenJ",0);journalDot()},flag(k){return !!store.get("wta_qf_"+k,0)},set(k){if(k!=="seenJ")store.set("wta_qf_seenJ",0);store.set("wta_qf_"+k,1);journalDot()}};
const PAGE_MAPS=["z-mine","z-wreck","z-volcano","z-glacier"];
const PAGES={
 "z-mine":{t:"Page one",x:"...the first ingredient is the stubborn one. It will not melt for any furnace we have; they spin it into the threads that glow inside lamps. Heaviest-hearted of the lot. — A.M."},
 "z-wreck":{t:"Page two",x:"...the second hid inside another metal for a century before anyone noticed it. They named it for the old name of a harbour city in the north, Hafnia. — A.M."},
 "z-volcano":{t:"Page three",x:"...the third is named for the king in the old story, punished to stand forever in water he could never drink. It shrugs off acid like he shrugged off everything else. — A.M."},
 "z-glacier":{t:"Page four",x:"...the fourth was the last stable one anyone ever found. Named for a great river. A little goes a long way. — A.M."},
 "z-crater":{t:"Page five",x:"...the last is the densest thing a hand can hold, named for its smell. Cast all five together in the old crucible and it will cut my seal. I could never bring myself to do it. — A.M."}};
function pagesGot(){return store.get("wta_pages",[])}
function questPull(){const s=Q.s;if(s<=0)return null;let want=[];
  if(s===1||s===2){Object.keys(PAGE_ZONE).forEach(id=>{if(PQ(id)<PAGE_DONE[id])want.push(PAGE_ZONE[id])});if(PQ("crater")===2||PQ("bolt")===1)want.push("z-scrap");if(!Q.flag("register"))want=["z-quill"]}
  else want=[3,6,7,8,11,13].includes(s)?["z-quill"]:s===4||s===9||s===12?["z-vault"]:s===5?["z-reactor"]:[];
  if(!want.length||Math.random()>.45)return null;const c=want[Math.random()*want.length|0];return ZONES.find(z=>z.cls===c)}
function vaultCaught(){return [...S.caught].filter(n=>{const a=ALLOYS.find(x=>x.name===n);return a&&a.hab==="z-vault"&&!a.threat}).length}
function evidenceCount(){return EVIDENCE.filter(e=>e.good&&Q.flag(e.f)).length}
function questObjective(){const s=Q.s,p=pagesGot().length;
  const leads=Object.keys(LEADS).filter(k=>!Q.flag(k)).map(k=>LEADS[k]);
  return [
  foFounderOpen()?"Archivist Wren at the Institute's reading room has asked to see you. She says it's about something the founder left behind.":foSummary(),
  `Find the founder's lost notebook pages (${p}/4). They went out with the first field teams: Rustvein Mine, Sunken Galleon Cove, Emberforge Caldera and Frostbite Cavern. Ask whoever has lived there longest.`,
  "The fifth page was stolen. Rumour says a Syndicate foreman has it, out at Starfall Crater.",
  "You have all five pages. Take them back to Archivist Wren at the Institute.",
  Q.flag("vellPages")?`Chronicler Vell at the Gilded Vault can read the founder's shorthand, but wants proof you know your stuff: register 3 different alloys from the vault (${Math.min(3,vaultCaught())}/3).`:"The amounts and the order are in the margins of the pages, in the founder's private shorthand. Nobody at the Institute can read it. He must have taught it to someone, and they'd be very old by now. Find them.",
  Q.flag("orrinAsk")?"Night Watchman Orrin at the Old Reactor Hall holds the crucible key. He wants you to beat a Slag Syndicate grunt first.":"The recipe needs the Institute's old crucible. Its key is with Night Watchman Orrin at the Old Reactor Hall.",
  "You have the crucible key and the recipe. Cast the Sealbreaker in the crucible in the Institute's old lab.",
  "You have the Sealbreaker. Use it on the sealed wall at the head of the Institute's hall.",
  "The basement is open. Search it. The founder's desk drawer is locked with two letter dials: his initials.",
  "The founder's letter is torn in half. The rest, it says, is with 'the one I trusted first'. Who was that?",
  "The second half of the letter speaks of the founder's 'oldest face', his ring, and 'the words I carved over the front door'.",
  "You're in the founder's hidden study, and somebody has been living in it. Search the desks.",
  "The diary in the study is written in the founder's private shorthand. Chronicler Vell at the Gilded Vault is the only person who can still read it.",
  "Vell read the diary: whoever writes it goes down to the basement cell every night. Go down there and see who comes.",
  `Dr. Marlow is waiting for you in the hidden study. Don't go in with a hunch. He'll want ${NEED_EVIDENCE} pieces of proof that point at him, not just at the founder. You have ${EVIDENCE.filter(e=>Q.flag(e.f)).length} things in your journal. Decide for yourself which ones hold up.`+(leads.length?` Leads you haven't followed: ${leads.join(" ")}`:" You've followed every lead."),
  "You know who the founder is."][Math.min(s,15)]}
/* the evidence you can present at the end. Only some of it proves anything about Marlow. */
const EVIDENCE=[
 {f:"coat",t:"The lab coat",x:"Name tape torn to '...LOW'. Field badge number 001, the same number Marlow wore.",good:1},
 {f:"vellYoung",t:"Vell's memory",x:"The founder taught her as a girl. She saw him in the hall last spring, not a day older.",good:1},
 {f:"nightlog",t:"Orrin's night log",x:"Badge 001 signs in every night at two in the morning, to a room that isn't on any floor plan.",good:1},
 {f:"lampbook",t:"Nettie's lamp book",x:"Sixty years ago a young scientist signed out a lamp: 'A.M., badge 001, Quillmoor'.",good:1},
 {f:"manifest",t:"The salvage manifest",x:"The galleon salvage, sixty years ago: 'Scientist aboard: A.M., Institute badge 001'.",good:1},
 {f:"letters",t:"The recruitment letters",x:"Hundreds of letters in the study, every one signed 'A.M., Head of Field Team'.",good:1},
 {f:"photo",t:"The photograph",x:"Opening day: 'A. M., with my first student, little V.'",good:0},
 {f:"ledger",t:"The ledger",x:"'Sample 1. Do not name it.' Someone else later called it Founder's Folly.",good:0},
 {f:"recipe",t:"The Sealbreaker recipe",x:"Tungsten, hafnium, tantalum, rhenium and osmium, cast together in the old crucible.",good:0},
 {f:"diary",t:"Marlow's diary",x:"'Every night I go down to tend the cell. The recruit is close now.'",good:0},
 {f:"motto",t:"The motto over the door",x:"QVAERE POST MVRVM: 'seek behind the wall'.",good:0}];
/* ---- interacting: one button to talk, examine, use doors, or search the ground ---- */
const DLG={open:false,lines:[],i:0,who:"",done:null,prompt:null};
function dlgEl(){let d=$("#dlg");if(!d){d=document.createElement("div");d.id="dlg";d.innerHTML=`<b id="dlg-who"></b><p id="dlg-txt"></p><form id="dlg-form" hidden><input id="dlg-in" autocomplete="off" maxlength="24"><button class="btn" type="submit">OK</button></form><i id="dlg-more">▼</i>`;$("#mapwrap").appendChild(d);
    d.onclick=e=>{if(e.target.closest("form"))return;dlgNext()};$("#dlg-form").onsubmit=e=>{e.preventDefault();const v=$("#dlg-in").value.trim();const p=DLG.prompt;DLG.prompt=null;$("#dlg-form").hidden=true;dlgClose();p&&p(v)}}return d}
function talk(who,lines,done,prompt){const d=dlgEl();Object.assign(DLG,{open:true,lines:[].concat(lines),i:0,who,done,prompt});EXP.busy=true;EXP.path=null;clearInterval(EXP.timer);d.hidden=false;dlgShow()}
let dlgTyper=null;
function dlgShow(){const t=DLG.lines[DLG.i]||"";$("#dlg-who").textContent=DLG.who?DLG.who.toUpperCase():"";$("#dlg-who").hidden=!DLG.who;const el=$("#dlg-txt");clearInterval(dlgTyper);let k=0;el.textContent="";
  dlgTyper=setInterval(()=>{k+=2;el.textContent=t.slice(0,k);if(k>=t.length){clearInterval(dlgTyper);dlgTyper=null;const last=DLG.i>=DLG.lines.length-1;$("#dlg-more").hidden=last&&!!DLG.prompt;if(last&&DLG.prompt){$("#dlg-form").hidden=false;$("#dlg-in").value="";$("#dlg-in").focus()}}},16);sfx("sel")}
function dlgNext(){if(!DLG.open)return;if(dlgTyper){clearInterval(dlgTyper);dlgTyper=null;$("#dlg-txt").textContent=DLG.lines[DLG.i];if(DLG.i>=DLG.lines.length-1&&DLG.prompt){$("#dlg-form").hidden=false;$("#dlg-in").focus()}return}
  if(DLG.prompt&&DLG.i>=DLG.lines.length-1)return;DLG.i++;if(DLG.i>=DLG.lines.length){dlgClose();const f=DLG.done;DLG.done=null;f&&f()}else dlgShow()}
function dlgClose(){DLG.open=false;const d=$("#dlg");if(d)d.hidden=true;EXP.busy=false}
function frontOf(){const d=EXP.dir||[EXP.face||1,0];return[EXP.x+d[0],EXP.y+d[1]]}
function thingsAt(x,y){return[...(EXP.grunts||[]).filter(g=>!g.done&&g.x===x&&g.y===y),...(EXP.npcs||[]).filter(p=>p.x===x&&p.y===y),...(EXP.objs||[]).filter(o=>o.x===x&&o.y===y)]}
function interact(){if(DLG.open){dlgNext();return}if(S.phase!=="explore"||EXP.busy)return;if(!gate("interact",250))return;
  const[fx,fy]=frontOf(),adj=[[1,0],[-1,0],[0,1],[0,-1]].flatMap(([dx,dy])=>thingsAt(EXP.x+dx,EXP.y+dy));
  const t=thingsAt(fx,fy)[0]||adj.find(q=>q.grunt||q.talks)||thingsAt(EXP.x,EXP.y)[0]||adj[0];
  if(t){if(t.grunt)slagChallenge(t);else if(t.use)t.use();else talkTo(t);return}
  searchHere()}
function nearMarks(){const all=[...(EXP.npcs||[]),...(EXP.objs||[])];all.forEach(p=>{if(!p.el)return;const n=Math.abs(p.x-EXP.x)+Math.abs(p.y-EXP.y)<=1;p.el.classList.toggle("near",n)})}


/* ---- the look of the people ---- */
function npcSVG(L){const skin=L.skin||"#F2C7A5",ink="#121B40",wide=L.stout?3:0,hair=L.hair||"#3A2414";let hairSvg="";
  switch(L.hs){case"bald":hairSvg=`<path d="M13.4 11 Q14 7.5 16 7" stroke="${hair}" stroke-width="1.6" fill="none"/><path d="M26.6 11 Q26 7.5 24 7" stroke="${hair}" stroke-width="1.6" fill="none"/>`;break;
    case"long":hairSvg=`<path d="M12.5 13 Q12 5 20 5 Q28 5 27.5 13 L28.5 22 Q26 20 26 16 Q24 9 20 9 Q16 9 14 16 Q14 20 11.5 22 Z" fill="${hair}" stroke="${ink}" stroke-width="1.1"/>`;break;
    case"bun":hairSvg=`<circle cx="20" cy="4.5" r="3.4" fill="${hair}" stroke="${ink}" stroke-width="1.1"/><path d="M13 12 Q13 5.5 20 5.5 Q27 5.5 27 12 Q24 8 20 8.6 Q16 8 13 12 Z" fill="${hair}" stroke="${ink}" stroke-width="1.1"/>`;break;
    case"spiky":hairSvg=`<path d="M13 11 L14 5 L16.5 8 L18 3.5 L20.5 7.5 L22.5 3.5 L24 8 L26.5 5 L27 11 Q24 8.5 20 9 Q16 8.5 13 11 Z" fill="${hair}" stroke="${ink}" stroke-width="1.1"/>`;break;
    case"curly":hairSvg=[[14,9],[17,6.5],[20.5,5.8],[24,6.8],[26.4,9.4],[13,12]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${hair}" stroke="${ink}" stroke-width=".9"/>`).join("");break;
    default:hairSvg=`<path d="M13 12 Q13 5.5 20 5.5 Q27 5.5 27 12 Q24 8.5 20 9 Q16 8.5 13 12 Z" fill="${hair}" stroke="${ink}" stroke-width="1.2"/>`}
  const acc=L.acc||[],has=a=>acc.includes(a);
  return `<svg viewBox="0 0 40 40" aria-hidden="true"><ellipse cx="20" cy="37.5" rx="${10+wide}" ry="2.2" fill="#000" opacity=".3"/>
  <rect x="${14.5-wide/2}" y="30" width="4.5" height="6.5" rx="1" fill="${L.legs||"#2E3548"}"/><rect x="${21+wide/2}" y="30" width="4.5" height="6.5" rx="1" fill="${L.legs||"#2E3548"}"/>
  <path d="M${12-wide} 21 Q20 18 ${28+wide} 21 L${29+wide} 32 L${11-wide} 32 Z" fill="${L.coat}" stroke="${ink}" stroke-width="1.5" stroke-linejoin="round"/>
  ${has("apron")?`<path d="M15 22 H25 V32 H15 Z" fill="${L.apron||"#E8E4DA"}" stroke="${ink}" stroke-width=".9"/>`:""}
  ${has("scarf")?`<path d="M14 20 Q20 23 26 20 L25 23 Q20 25 15 23 Z M22 22 L24 29 L21 28 Z" fill="${L.scarf||"#C8243A"}" stroke="${ink}" stroke-width=".8"/>`:""}
  ${has("badge")?`<rect x="22.5" y="24" width="3.4" height="2.4" rx=".5" fill="#FFD23F" stroke="${ink}" stroke-width=".6"/>`:""}
  <path d="M${12-wide} 22 Q${9.5-wide} 27 ${10.5-wide} 31" stroke="${ink}" stroke-width="3.4" stroke-linecap="round" fill="none"/><path d="M${12-wide} 22 Q${9.5-wide} 27 ${10.5-wide} 31" stroke="${L.coat}" stroke-width="1.9" stroke-linecap="round" fill="none"/>
  <path d="M${28+wide} 22 Q${30.5+wide} 27 ${29.5+wide} 31" stroke="${ink}" stroke-width="3.4" stroke-linecap="round" fill="none"/><path d="M${28+wide} 22 Q${30.5+wide} 27 ${29.5+wide} 31" stroke="${L.coat}" stroke-width="1.9" stroke-linecap="round" fill="none"/>
  ${has("cane")?`<path d="M${31+wide} 24 V37 M${31+wide} 24 Q${33+wide} 22 ${34+wide} 24" stroke="#6A4A2A" stroke-width="1.6" fill="none" stroke-linecap="round"/>`:""}
  ${has("book")?`<rect x="${7-wide}" y="26" width="6" height="7" rx=".6" fill="#8A3A34" stroke="${ink}" stroke-width=".8"/>`:""}
  ${has("lamp")?`<path d="M${31+wide} 26 v3" stroke="${ink}" stroke-width=".8"/><rect x="${29.5+wide}" y="29" width="3.4" height="4.4" rx=".8" fill="#FFE2A0" stroke="${ink}" stroke-width=".8"/>`:""}
  <circle cx="20" cy="13" r="7" fill="${skin}" stroke="${ink}" stroke-width="1.5"/>${hairSvg}
  ${has("helmet")?`<path d="M12 11 Q12 4 20 4 Q28 4 28 11 Z" fill="${L.hat||"#E0B820"}" stroke="${ink}" stroke-width="1.2"/><rect x="18" y="5.5" width="4" height="3" rx=".8" fill="#FFF1C0" stroke="${ink}" stroke-width=".7"/>`:""}
  ${has("cap")?`<path d="M12.5 10 Q20 3.5 27.5 10 Z" fill="${L.hat||"#2E3548"}" stroke="${ink}" stroke-width="1.1"/><path d="M26 10 H31" stroke="${L.hat||"#2E3548"}" stroke-width="2" stroke-linecap="round"/>`:""}
  ${has("brim")?`<path d="M13.5 9.5 Q20 1.5 26.5 9.5 Z" fill="${L.hat||"#3A2A1A"}" stroke="${ink}" stroke-width="1.1"/><rect x="9.5" y="8.8" width="21" height="2.2" rx="1" fill="${L.hat||"#3A2A1A"}" stroke="${ink}" stroke-width=".9"/>`:""}
  ${has("glasses")?`<circle cx="17.2" cy="13.4" r="2.3" fill="rgba(200,230,255,.5)" stroke="${ink}" stroke-width="1"/><circle cx="22.8" cy="13.4" r="2.3" fill="rgba(200,230,255,.5)" stroke="${ink}" stroke-width="1"/><path d="M19.5 13.4 H20.5" stroke="${ink}" stroke-width=".8"/>`:`<circle cx="17.4" cy="13.6" r="1.1" fill="${ink}"/><circle cx="22.6" cy="13.6" r="1.1" fill="${ink}"/>`}
  ${has("goggles")?`<path d="M12.6 11.2 H27.4" stroke="#3A3A3A" stroke-width="1.6"/><rect x="14" y="9.6" width="5" height="3.2" rx="1.4" fill="#8FE3FF" stroke="${ink}" stroke-width=".8"/><rect x="21" y="9.6" width="5" height="3.2" rx="1.4" fill="#8FE3FF" stroke="${ink}" stroke-width=".8"/>`:""}
  ${has("beard")?`<path d="M14 15 Q14 22 20 22.5 Q26 22 26 15 Q24 18.5 20 18.5 Q16 18.5 14 15 Z" fill="${L.beard||hair}" stroke="${ink}" stroke-width=".9"/>`:`<path d="M18 17 Q20 18.2 22 17" stroke="${ink}" stroke-width=".9" fill="none" stroke-linecap="round"/>`}
  ${has("mustache")?`<path d="M16.8 16.4 Q20 14.8 23.2 16.4 Q20 17.4 16.8 16.4 Z" fill="${L.beard||hair}"/>`:""}</svg>`}

/* ---- the people. Keepers remember their map's legend; a few locals named an alloy once; most are just getting on with their day. ---- */
const KEEPERS={
 "z-mine":{n:"Nettie Crane",look:{coat:"#6A4A2A",hair:"#D8D8D8",hs:"bun",acc:["helmet","lamp","cane"],skin:"#E8B894"},talks:[
   ["Forty-one years I kept the lamps in this mine. Three hundred and six of them. I could tell you which one was coming round the corner by the sound of its wick.","Lamps hate being shouted near. The lads never believed me. Their lamps always went out first."],
   ["The seam up north-east with the rope across it? The widow's seam, the crews called it. A widow's husband was the only man whose lamp ever came back out of there.","Just the lamp, mind. She kept it lit on her windowsill for twenty years. I trimmed the wick for her every Sunday."],
   ["Mind the sump by the rails. Looks like a puddle. It's deeper than the church spire is tall. I measured it once with a lot of string."]],
  page:["A notebook page? Oh, that. It's been folded into my lamp book for sixty-odd years, between two Tuesdays.","A young scientist from the Institute left it there. Said somebody would come asking. Said to make them wait.","You waited. Here."]},
 "z-scrap":{n:"Bolt",look:{coat:"#B06A3E",hair:"#E8A060",hs:"spiky",acc:["goggles","apron"],apron:"#6A4A2A",skin:"#C88A64"},talks:[
   ["See that crane? I built her out of four other cranes. So she's got four birthdays. I celebrate every one. There's cake.","Bring me anything broken. If I can't fix it, I'll take it apart very neatly and put it in a labelled tin."],
   ["The east heaps are fenced off because of one jar. One! Somebody dropped it and the car underneath went soft, like a biscuit in tea.","I kept what was left of the car. It's in a bucket in the gatehouse. It's called Keith."],
   ["Syndicate lot came by trying to buy scrap by the kilo. I sold 'em a kilo of bolts. Just bolts. They didn't know what to do. I'm still laughing."]]},
 "z-wreck":{n:"Captain Ysolde Fenn",look:{coat:"#1E2E4A",hair:"#FFFFFF",hs:"long",acc:["cap"],hat:"#1E2E4A",skin:"#D8A07A"},talks:[
   ["Captain Ysolde Fenn, harbour master. Retired. The harbour retired first. I'm keeping it company.","The tide tables on the office wall have been wrong since 1958. Wrong very consistently, mind you. So they're still useful."],
   ["That galleon went down on fire and kept burning under the water. My grandmother watched from this beach. The sea went orange and smelled of matches.","The salvage divers brought up a drum of whatever was doing the burning. First thing in history to make a diver come up faster than he went down."],
   ["Want to read the weather? Watch the gulls. If they're sitting down, so should you."]],
  page:["Something of the founder's? My grandmother kept a page of his. She kept everything. Tide tables, string, grudges.","He was out on the salvage boat, writing about the fire while everybody else wrote about the gold. Tore out a page and pressed it on her.","She told me somebody would come for it. I told her nobody ever would. I owe her an apology."]},
 "z-volcano":{n:"Brother Ashlin",gift:"quiet",look:{coat:"#5A2A14",hair:"#1A1A1A",hs:"bald",acc:["beard","scarf"],scarf:"#E0B820",beard:"#8A8A8A",skin:"#B87A54"},talks:[
   ["I keep the fire company. It does not need company. But I think it likes being looked at.","We are an order of one. I was elected unanimously."],
   ["The fire in the ring of stones burned before the stones were put there. We placed them so that people would stop tripping into it.","The Institute took a spark of it away in a jar. I am told it still burns in the jar. I pray for the jar."],
   ["When the rivers glow brighter, it will rain. When they glow dimmer, it will rain. It rains a great deal up here."]],
  page:["A young man from the Institute climbed up here once. He asked me for nothing. That is rare.","He sat by the fire for an hour, wrote one page, and gave it to me to keep. He said he did not trust himself with it.","I have kept it. I have not read it. Both were difficult."]},
 "z-vault":{n:"Chronicler Vell",gift:"guide",look:{coat:"#4A2A5A",hair:"#E8D8A8",hs:"long",acc:["glasses","book"],skin:"#F2C7A5"},talks:[
   ["Chronicler Vell. I record what enters the vault, what leaves it, and what the tour guides claim is in it. That last list is much the longest.","Kindly do not lean on the display cases. They are older than your family."],
   ["The crown in the sealed chamber was made for a coronation that never happened. The jeweller fell ill. His apprentice finished it, and fell ill too.","Its inventory card says 'condition: warm'. Nobody has had the nerve to correct it in a hundred years."],
   ["I read six dead shorthands and one living one. The living one belongs to someone I have not spoken to in a very long time."]]},
 "z-reactor":{n:"Night Watchman Orrin",gift:"sieve",look:{coat:"#3A4440",hair:"#6A6A6A",hs:"short",acc:["cap","mustache","badge"],hat:"#E0B820",skin:"#8A5A3A"},talks:[
   ["Night Watchman Orrin. Nights only. Days are for people who enjoy questions.","Rounds every hour. Door, door, pool, door, tea. Two hundred thousand times, give or take. The tea is the best bit."],
   ["The pool in the middle never gets cold. Forty years. I warm my tea on the rail in winter.","One of the old experiments boiled off in here and put itself back together three floors down. I don't do three floors down."],
   ["Before this posting I did nights at the Institute itself. Forty years of sign-in books. You learn who comes and goes when they think nobody's looking."]]},
 "z-glacier":{n:"Dr. Pia Holm",look:{coat:"#E8E4DA",hair:"#8A6A4A",hs:"short",acc:["goggles","scarf"],scarf:"#3B7BF0",skin:"#F2D2B8"},talks:[
   ["Dr. Pia Holm, glaciologist. I study ice, which is mostly waiting for ice to do something.","The hut was built the Institute's first winter. Two-foot walls, and it's still colder inside than out. Nobody knows why. I've stopped asking."],
   ["We keep one of the Institute's worst samples out here, under argon, behind two walls of glass. Cold slows it down. Cold slows everything down. That's my whole career in a sentence.","The lake froze solid the week it arrived and hasn't thawed since. I'd call it a coincidence if I believed in them."],
   ["If you ever go through the ice, don't panic. Panicking wastes heat. Swear instead. Swearing is free and surprisingly warm."]],
  page:["The founder's page? It's pinned inside the hut door. Every station chief since the first winter has read it and understood nothing.","It's become a tradition. We toast it at midwinter.","Take it. Tell whoever ends up with it that we'll need a new toast."]},
 "z-crater":{n:"Projectionist Tamsin",gift:"glint",look:{coat:"#3A2A5A",hair:"#E8A060",hs:"curly",acc:["glasses"],skin:"#6A4A34"},talks:[
   ["Projectionist Tamsin. The observatory's the only cinema for a hundred miles, and it only shows one film: the sky.","Plus whatever's in the film vault. Which I'd love to show you, except the vault door caved in the year of the big frost."],
   ["Whatever lives in the crater comes apart and puts itself back together in a flash that would blind you. So we watch it through the projector. Delayed, darkened, safe.","Best show I've ever run. The audience is mostly me. I bring snacks for both of us."],
   ["A Syndicate foreman came through with a torn page, laughing like the villain in a matinee. Grist, they call him. Tips like one too."]]},
 "z-quill":{n:"Archivist Wren",gift:"survey",look:{coat:"#4A3A2A",hair:"#1A1A1A",hs:"bun",acc:["glasses","book"],skin:"#C88A64"},talks:[
   ["Archivist Wren. If it's written down and in this building, I know where it is. If it isn't written down, I'm quietly worried about it.","The reading room's the one with the chairs. They all have books. People ask."],
   ["The wall at the head of the hall with the red seal is newer than the rest of the building. The founder's basement is behind it. It was sealed the year the Containment Division began.","I've asked for the key eleven times. Eleven times I've been told there isn't one."],
   ["Dr. Marlow? Head of the field team since before I was hired. Before anybody was hired, as far as I can tell.","He hires people and forgets to tell us. His post never piles up. It just... goes somewhere."]]}};
/* a few locals did name something once, and each of them tells it differently */
const DISCOVERERS={
 "z-mine":{a:"Tappite",n:"Oswin Tapp",look:{coat:"#3B7BF0",hair:"#E8A060",hs:"spiky",acc:[],skin:"#F2C7A5"},talks:[["I'm Oswin and I'm eight and three quarters and I play the triangle.","I found Tappite in the percussion cupboard. It was behind the tambourines. Nobody else looked behind the tambourines.","I'm its guardian now. That's official. I made a badge."],["Do you want to hear the triangle? I don't have it with me. But imagine it. Ting."]]},
 "z-scrap":{a:"Milk Round Mix",n:"Alf Dimmock",look:{coat:"#E8E4DA",hair:"#8A8A8A",hs:"bald",acc:["cap"],hat:"#FFFFFF",skin:"#E8B894"},talks:[["Forty years on the milk round, me. Tadmore estate, five in the morning, rain or shine.","One morning in '79 I left a crate of the wrong stuff on a doorstep instead of two pints. They didn't complain. They named it after my round.","I come down here to see if any of the old float turned up. Never has."],["You want to know the secret of a good milk round? Quiet boots and a whistle nobody can hear."]]},
 "z-wreck":{a:"Lusk's Lake Metal",n:"Postmaster Edwin Lusk",look:{coat:"#8A3A34",hair:"#FFFFFF",hs:"short",acc:["glasses","mustache"],beard:"#FFFFFF",skin:"#F2D2B8"},talks:[["1910. A parcel addressed to number four, Lake Road. There was no number four. There was only the lake.","I sent it back with a note. A strongly worded note. They named the stuff inside after me anyway.","I have never been so insulted in my life. I keep the note framed."],["Do you know how many parcels I've delivered? Neither do I. I stopped counting at the lake."]]},
 "z-volcano":{a:"Mott's No. 9",n:"Cyril Mott",look:{coat:"#3A4A5A",hair:"#3A2414",hs:"short",acc:["cap","badge"],hat:"#3A4A5A",skin:"#8A5A3A"},talks:[["Night watchman, Gantry Wharf, thirty years. Warehouse number nine was the only building on the docks with no rats.","I put it down to the crate in the corner. The rats never said otherwise.","I've retired up here now. Fewer rats. More lava. Swings and roundabouts."],["If you ever find a warehouse with no rats, check the corners."]]},
 "z-vault":{a:"Hettie's Soup Metal",n:"Hettie Marsh",look:{coat:"#C8243A",hair:"#6B4424",hs:"curly",acc:["apron"],apron:"#FFFFFF",skin:"#C88A64"},talks:[["I was the cook on a dig. I was burying the potato peelings and hit something that went clunk.","They named the trench after my soup, and the metal after the trench. I'll take it.","The soup was leek and potato. It was very good soup."],["Are you eating properly? Field scientists never eat properly."]]},
 "z-reactor":{a:"Coincidium",n:"Forecaster Ada Crill",look:{coat:"#5A6A4A",hair:"#1A1A1A",hs:"long",acc:["scarf"],scarf:"#E0B820",skin:"#6A4A34"},talks:[["The barometer dropped like a stone the very hour that batch was finished. I wrote down one word. 'Coincidence?'","Now it's called Coincidium. I didn't mean it as a name. I meant it as a question.","I still don't know the answer. I check the barometer every day."],["It's going to rain on Thursday. Or it isn't. Write that down."]]},
 "z-glacier":{a:"Brandtium",n:"Coach Hester Brandt",look:{coat:"#E0B820",hair:"#3A2414",hs:"short",acc:["cap"],hat:"#1E2E4A",skin:"#F2C7A5"},talks:[["Volleyball. Eleven losses in a row. And there was that crate, in the corner of the gym, the whole time.","I had it moved out. We won the next day. Then we lost it, and we lost again, so I asked for it back.","Is that science? I don't care. We won the regional final."],["Keep your eye on the ball. Also on any suspicious crates."]]},
 "z-crater":{a:"Thursday Metal",n:"Grandmother Nell Crumley",look:{coat:"#4A2A5A",hair:"#FFFFFF",hs:"bun",acc:["glasses","cane"],skin:"#E8B894"},talks:[["The tea leaves said, clear as day: something new from something old, found on a Wednesday.","It was found on a Thursday. I maintain that's close enough.","Would you like me to read yours? No? Suit yourself. They say you'll find something behind a wall."],["The leaves are never wrong. They're just occasionally a day out."]]},
 "z-quill":{a:"Sandpit Special",n:"Pim Harrow",look:{coat:"#FF8A7A",hair:"#1A1A1A",hs:"bun",acc:[],skin:"#8A5A3A"},talks:[["I invented Sandpit Special. In the sandpit. When I was six.","The Institute says they can't prove I didn't. So I did.","I'm seven now. I'm going to invent something even better. Probably in the bath."],["Do you work here? Can I see the basement? Everyone says there's a basement."]]}};
/* everybody else: just living their lives. Some of them have lost something. */
const AMBIENT={
 "z-mine":[{n:"Gerta",look:{coat:"#3B7BF0",hair:"#E8A060",hs:"long",acc:["helmet"],hat:"#FF8A3A",skin:"#F2D2B8"},talks:[["Caving holiday! Well, a caving afternoon. I brought a flask of tea and I'm not leaving till it's gone.","It's so quiet down here. You can hear yourself think. I'm thinking about biscuits."]]},
   {n:"Foreman Dray",look:{coat:"#5A4A3A",hair:"#1A1A1A",hs:"short",acc:["helmet","beard"],hat:"#E0B820",skin:"#C88A64"},side:{id:"lamp",thing:"Dray's brass lamp",reward:"lure",ask:["Lost my good brass lamp along the top tunnel, right out at the east end. Put it down to tie a boot and never saw it again.","If you come across it, I'd be grateful. It was my dad's."],thanks:["That's it! That's the one! Look at that, not a scratch.","Here, take this for your trouble. My dad would've wanted you to have something."],done:["Lamp's back where it belongs. Thanks again."]}}],
 "z-scrap":[{n:"Dotty Pruitt",look:{coat:"#FF9AD5",hair:"#D8D8D8",hs:"curly",acc:["glasses"],skin:"#F2C7A5"},talks:[["Picnic on the crane pad. Best view in the yard, if you like rust. I do.","My husband proposed to me in a scrapyard. Not this one. A nicer one. Still, it brings it all back."]]},
   {n:"Kez",look:{coat:"#2E6F9E",hair:"#E8A060",hs:"spiky",acc:["cap"],hat:"#C8243A",skin:"#C88A64"},side:{id:"cap",thing:"the gold-rimmed bottle cap",reward:"charm",ask:["I collect bottle caps. I've got four hundred and twelve.","There's a gold-rimmed one in this yard. I saw it glint once, right down the west side of the yard by the car bodies, and then I lost it. It's the rarest one ever made."],thanks:["NO WAY. That's it! Four hundred and thirteen!","You can have my lucky charm. I don't need luck anymore. I have THIS."],done:["Four hundred and thirteen. I polish it every night."]}}],
 "z-wreck":[{n:"Albrecht Voss",look:{coat:"#6A4A2A",hair:"#FFFFFF",hs:"bald",acc:["glasses","beard","cane"],beard:"#FFFFFF",skin:"#F2D2B8"},side:{id:"watch",thing:"Albrecht's pocket watch",reward:"timer",ask:["Fifty years a clockmaker, and I lose my own pocket watch in the dunes. The irony is not lost on me.","Somewhere up by the palms, I think. I sat down to watch the tide and when I stood up it was gone."],thanks:["You found it! Still ticking. Of course it's still ticking. I made it.","Take this little timer. It's not as good as my watch, but it's better than anybody else's."],done:["Twelve minutes past. It's always twelve minutes past something."]}},
   {n:"The Moss twins",look:{coat:"#E0B820",hair:"#6B4424",hs:"curly",acc:[],skin:"#8A5A3A"},talks:[["We're building a sandcastle! It's going to be the biggest one ever built!","It keeps falling down. We think the sea is jealous."]]}],
 "z-volcano":[{n:"Juno",look:{coat:"#5A6A4A",hair:"#1A1A1A",hs:"long",acc:["cap","scarf"],hat:"#8A5A34",scarf:"#FF8A3A",skin:"#6A4A34"},talks:[["Hiking the caldera rim! My friend Beck went ahead to get a photo of the fire. I stayed to eat his sandwich.","Isn't it amazing up here? The ground's warm. My boots are warm. Everything's warm. I love it."]]},
   {n:"Ranger Okafor",look:{coat:"#3A5A3A",hair:"#1A1A1A",hs:"short",acc:["brim","badge"],hat:"#6A5A2A",skin:"#6A4A34"},side:{id:"radio",thing:"the ranger's radio",reward:"patch",ask:["Stay on the stone bridges, please. The rivers aren't water.","And if you see a radio lying around, it's mine. Dropped it near the old forge when a boulder shifted."],thanks:["My radio! Oh, that's a relief. Headquarters thought I'd fallen in.","Have this patch kit. You're more likely to need it than I am."],done:["Radio's working. Headquarters says hello."]}}],
 "z-vault":[{n:"Tour Guide Henrietta",look:{coat:"#1E2E4A",hair:"#B8683A",hs:"bun",acc:["badge","glasses"],skin:"#F2C7A5"},talks:[["And on your left, ladies and gentlemen, the grand aisle! Laid in the year the vault was built, and walked on by six monarchs and one very lost goose.","Please don't touch the display cases. Please don't touch the crown chamber. Please don't touch the goose. He's still here somewhere."]]},
   {n:"Kit",look:{coat:"#26262C",hair:"#3A2414",hs:"long",acc:[],skin:"#C88A64"},talks:[["School trip. Everyone else is doing the worksheet. I'm doing the wall.","Someone dared me to touch the crown case. I'm not going to. I'm just going to stand near it. Menacingly."]]}],
 "z-reactor":[{n:"Janitor Lu",look:{coat:"#5A6A7A",hair:"#1A1A1A",hs:"short",acc:["apron"],apron:"#8FD0FF",skin:"#E8B894"},talks:[["Mopping a decommissioned reactor hall. Somebody's got to. The floor doesn't know it's decommissioned.","Some nights the lights in the control room flicker on by themselves. I just say good evening and carry on mopping."]],deliver:"toby"},
   {n:"Inspector Pratt",look:{coat:"#E8E4DA",hair:"#8A6A4A",hs:"short",acc:["glasses","book"],skin:"#F2D2B8"},talks:[["Safety inspection. I've found forty-one violations and it's not even lunch.","Violation forty-two: that barrel is facing the wrong way. I don't know which way is right. But that isn't it."]]}],
 "z-glacier":[{n:"Ole",look:{coat:"#C8243A",hair:"#E8D8A8",hs:"short",acc:["cap","beard"],hat:"#3B7BF0",beard:"#E8D8A8",skin:"#F2D2B8"},talks:[["Ice fishing. Three days now. Not a single bite.","Best three days of my life. Nobody asks me anything out here. Well. Until you."]]},
   {n:"Sunniva",look:{coat:"#E8E4DA",hair:"#E8A060",hs:"long",acc:["scarf"],scarf:"#FF9AD5",skin:"#F2D2B8"},side:{id:"lens",thing:"Sunniva's lens cap",reward:"cloth",ask:["I'm photographing the crevasse grotto. Or I was, until I dropped my lens cap somewhere down there.","Without it the lens frosts over in seconds. If you're passing the grotto, keep an eye out?"],thanks:["My lens cap! You're a star.","Take this cloth. It's the good one. It gets the frost off anything."],done:["Look at this shot of the lake. Look at it!"]}}],
 "z-crater":[{n:"Marisol",look:{coat:"#4A2A5A",hair:"#1A1A1A",hs:"long",acc:["book","scarf"],scarf:"#FFD23F",skin:"#C88A64"},talks:[["I'm writing a poem about the meteor. So far I have: 'Oh, rock.' It's a work in progress.","Do you know a word that rhymes with crater? Later. Greater. Potato, if you say it wrong. I say it wrong."]]},
   {n:"Mr. Pennyworth",look:{coat:"#3B7BF0",hair:"#FFFFFF",hs:"bald",acc:[],skin:"#E8B894"},talks:[["Morning! Forty laps of the crater rim, every day, rain or shine. Doctor's orders.","Well, my doctor said 'get some exercise'. The forty laps were my idea."]]}],
 "z-quill":[{n:"Intern Toby",look:{coat:"#FFFFFF",hair:"#6B4424",hs:"spiky",acc:["badge","glasses"],skin:"#F2D2B8"},side:{id:"toby",thing:"Toby's note",deliver:"Janitor Lu",reward:"cell",ask:["First week! I've been lost in this hall for two hours. Is the reading room the one with the books? They all have books.","Could you do me a favour? My aunt Lu works nights at the Old Reactor Hall. Can you give her this note? It just says I'm alive. She worries."],thanks:["You gave it to Aunt Lu? She sent a note back? It says 'eat a vegetable'. Classic Aunt Lu.","Here, have this spare cell from the supply cupboard. I don't think anyone counts them. I hope."],done:["I found the reading room! It was the one with the books."]}},
   {n:"Mrs. Gale",look:{coat:"#8A6AB0",hair:"#FFFFFF",hs:"curly",acc:["glasses","cane"],skin:"#E8B894"},talks:[["I come every Tuesday to look at the specimens. They never change, and neither do I. It's very restful.","My late husband worked here, you know. In the old days. He always said the founder was a lovely young man. Terribly sad eyes."]]}]};
function sideState(id){return store.get("wta_sq_"+id,0)}
function setSide(id,v){store.set("wta_sq_"+id,v)}

/* ---- talking ---- */
function talkTo(p){if(p.quest&&p.quest()!==false)return;
  if(p.side){const sd=p.side,st=sideState(sd.id);
    if(sd.deliver){if(st===0){talk(p.n,sd.ask,()=>{setSide(sd.id,1);say0(`You're carrying ${sd.thing}. Deliver it to ${sd.deliver}.`)});return}if(st===1){talk(p.n,["Did you find my aunt yet? Old Reactor Hall. She'll be the one mopping."]);return}if(st===2){talk(p.n,sd.thanks,()=>{setSide(sd.id,3);giveItem(sd.reward);say0(`You got a ${ITEMS[sd.reward].name.toUpperCase()}!`)});return}talk(p.n,sd.done);return}
    if(st===0){talk(p.n,sd.ask,()=>{setSide(sd.id,1);sideSeed();say0(`Keep an eye out for ${sd.thing}. The dowsing meter will pick it up.`)});return}
    if(st===1){talk(p.n,[sd.ask[1]]);return}if(st===2){talk(p.n,sd.thanks,()=>{setSide(sd.id,3);giveItem(sd.reward);say0(`You got a ${ITEMS[sd.reward].name.toUpperCase()}!`)});return}talk(p.n,sd.done);return}
  if(p.deliver&&sideState(p.deliver)===1){talk(p.n,["A note? From Toby?","'Dear Aunt Lu, I am alive. Love, Toby.' Oh, that boy.","Hang on. Take this back to him."],()=>{setSide(p.deliver,2);say0("Janitor Lu wrote a reply. Take it back to Intern Toby at the Institute.")});return}
  const t=p.talks[(p.said||0)%p.talks.length];p.said=(p.said||0)+1;const key="wta_gift_"+p.n.replace(/\W/g,""),first=!!p.gift&&!store.get(key,0);
  talk(p.n,t,first?()=>{store.set(key,1);giveItem(p.gift);talk(p.n,[`You're with the Institute, aren't you? Here. You'll get more use out of this than I will.`,`(You got a ${ITEMS[p.gift].name.toUpperCase()}!)`])}:null)}
function sideSeed(){(EXP.npcs||[]).forEach(p=>{if(p.side&&!p.side.deliver&&sideState(p.side.id)===1&&!(EXP.hidden||[]).some(h=>h.side===p.side.id)){const[x,y]=SPOTS[EXP.zone.cls].side;EXP.hidden.push({x,y,side:p.side.id,thing:p.side.thing})}});dowse()}

/* ---- the quest, told through the people and the places ---- */
function questHooks(z){const K=(EXP.npcs||[]).find(p=>p.keeper);if(!K)return;
  if(z==="z-quill")K.quest=()=>{const s=Q.s;
    if(s===0){if(!foFounderOpen()){talk(K.n,["You're one of Dr. Marlow's recruits? Welcome. The reading room is the one with the chairs.","I do have something I've been meaning to look into. Something old. But it needs somebody who really knows the field, every map of it, and you're still new.","Come back once you're field staff. Dr. Marlow will tell you when. He loves telling people when."]);return}
      talk(K.n,["Field staff now, I hear. Good. Sit down. I need somebody who travels, and somebody who's allowed in the records room.","When the Institute was young, the founder sent a page of his notebook out with each of the first five field teams. Nobody knows why, and nobody ever went to fetch them back.","I'd like them back. All five. For the archive, and because it's been bothering me for eleven years.","Which teams, and who they left the pages with, will be in the Expedition Register. It's on the lectern in the records room, just across the hall.","I'm archive staff. Records is field staff only. Don't ask. There was a memo."],()=>{Q.s=1;say0("New objective in your JOURNAL: read the Expedition Register in the records room.")});return}
    if(s===1||s===2){const n=pagesGot().length;talk(K.n,Q.flag("register")?[`You've got ${n} of the five pages.`,n>=3?"Nearly there. I've cleared a shelf for them. Well, I've cleared a bit of a shelf.":"Whoever he left them with, they've had sixty years to hide them. Be patient. And be nosy."]:["Have you read the Expedition Register yet? Lectern, records room, across the hall. It's the big book nobody dusts."]);return}
    if(s===3){talk(K.n,["All five. You actually found all five.","Look at them side by side. Each page names one metal. Five metals, five teams, five places as far apart as he could send them.","He split it on purpose, so that no single team, and no single person, could ever make the Sealbreaker.","And it's still not complete. There are no amounts, and no order to cast them in. Those are in the margins, in his private shorthand.","I can't read a word of it. I've tried for eleven years, on the scraps we keep here. Nobody in this building can.","But nobody writes in a code only they can read and then posts it to five corners of the moor. He meant somebody to read it. He must have taught it to someone.","Whoever that was, they'd be very old now. I don't know who. If you find them, they'll know the hand at a glance."],()=>{Q.s=4;say0("New objective in your JOURNAL.")});return}
    if(s>=8&&s<15&&!Q.flag("wrenAM")){talk(K.n,["You got into the basement? Then you've seen more of the founder than anybody alive.","A.M.? I went through the old staff roster for you. The founder's line has been scratched out with a knife.","So has one other line, further down. Same knife, by the look of it. Same hand.","Whoever did it didn't want either of them found. I'd like to know why."]);Q.set("wrenAM");return}
    if(s>=13&&hintOnce("stafffile",K.n,["Staff files? They're in the records room, by badge number. Each cabinet opens to its owner's badge number and then the year they joined. Two digits for the year.","Dr. Marlow's never told anyone his birthday. Ask him when he joined and he just says 'the day the doors first opened'. Very mysterious. Very annoying.","I'm not saying you should open it. I'm saying I didn't see you."]))return;
    return false};
  if(z==="z-vault")K.quest=()=>{const s=Q.s;
    if(s===4){if(vaultCaught()<3){talk(K.n,["The founder's pages? I'd know that hand in the dark.","But I don't read his shorthand for just anyone. Show me you're a real field scientist.",`Register three different alloys from this vault. You have ${vaultCaught()} so far.`],()=>{if(!Q.flag("vellPages")){Q.set("vellPages");say0("New objective in your JOURNAL.")}});return}
      talk(K.n,["Three vault alloys. Acceptable. Let me see the pages.","Tungsten. Hafnium. Tantalum. Rhenium. Osmium. Five of the most stubborn metals there are.","Cast together in the old crucible, they'd cut through anything he could have sealed.","The crucible is locked. Night Watchman Orrin at the reactor hall keeps the old Institute keys."],()=>{Q.s=5;Q.set("recipe");say0("The Sealbreaker recipe is in your JOURNAL.")});return}
    if(s===9){talk(K.n,["That ring. Where did you get that ring?","...His desk. Of course. He always said someone would come.","He gave me something, the day he sealed the basement. Half a letter. He said, 'Give this to whoever comes with my ring, little V.'","Nobody has called me little V in sixty years.","I didn't keep it here. The Syndicate have been through my shelves twice this year, looking for anything in his handwriting.","It's in the founder's deposit box, in the vault's west hall. Box 001. It only opens for his ring. I never read it. I promised."],()=>{Q.set("vellBox");say0("New objective in your JOURNAL: open deposit box 001 in the Gilded Vault's west hall.")});return}
    if(s===12){talk(K.n,["His diary. You found his diary.","Give it here. My hands are shaking, not my eyes.","'The recruit found the ring. I knew they would.'","'Every night I go down to tend the cell. I will go tonight as always. If they are clever, they will know where to find me.'","...This entry is dated yesterday.","Go. Go to the basement tonight, and see who comes down the stairs."],()=>{Q.s=13;Q.set("diary");say0("New objective in your JOURNAL.")});return}
    if(s>=9&&s<15&&!Q.flag("vellYoung")){talk(K.n,["He taught me his shorthand when I was a girl. He was a young man then. Always a notebook. A little star-shaped chip in his left lens that he never got round to fixing.","It's strange. I've grown old. But I'd swear I passed him in the Institute's hall last spring, looking exactly the same.","I told myself it was his grandson. I've been telling myself that for a year."],()=>{Q.set("vellYoung");say0("New evidence in your JOURNAL.")});return}
    return false};
  if(z==="z-reactor")K.quest=()=>{const s=Q.s;
    if(s===5){if(!Q.flag("orrinAsk")){store.set("wta_q_slag0",slagWins());Q.set("orrinAsk");talk(K.n,["The crucible key? Institute property. Nobody's asked for it in forty years.","The Syndicate would love to get their hands on it. How do I know you're not one of them?","Beat one of their grunts in a fair challenge. Then come back and we'll talk."]);return}
      if(slagWins()<=store.get("wta_q_slag0",0)){talk(K.n,["Still waiting on that Syndicate grunt. They stand watch out on the maps. Walk into their line of sight and they'll come to you."]);return}
      talk(K.n,["Word travels fast. You beat one of the Syndicate's grunts.","Here. The crucible key. I've been holding it for the founder since before you were born.","He told me someone would come for it. He was very particular about that."],()=>{Q.s=6;Q.set("key");say0("You got the CRUCIBLE KEY.")});return}
    if(s>=13&&hintOnce("nightlog",K.n,["The old Institute sign-in books? When they shut the Institute's night desk, the inspectors crated the lot and sent it here.","They're in the storage bay, nailed shut. Crate says NIGHTS on the side.","There's one entry in those books I never could explain. Look for yourself. You'll know it when you see it."]))return;
    return false};
  if(z==="z-mine")K.quest=()=>{const s=Q.s;
    if(s>=13&&hintOnce("lampbook",K.n,["The lamp book from those years? Still on its hook in the old lamp room. North tunnels, past the top level. Nobody's lit them since me.","You've got my spare lamp. Go and read the first page, and then the last one."]))return;
    return false};
  if(z==="z-wreck")K.quest=()=>{const s=Q.s;
    if(s>=13&&hintOnce("manifest",K.n,["The salvage manifest? That went out to the hull with my grandmother's sea chest. She asked to have her things put aboard the old galleon. Sentimental.","Wade out at low water and you'll find it in the hold. Mind the barnacles."]))return;
    return false};
  if(z==="z-crater")K.quest=()=>{const s=Q.s;
    if(s>=13&&hintOnce("film",K.n,["Opening day at the Institute? There's a reel of it. The founder cutting the ribbon. My predecessor filmed it.","It's in the film vault. The one that caved in. If you can get through the rubble, run the first few frames against the light.","Tell me if he's handsome. Nobody's seen that reel in forty years."]))return;
    return false};
}
function pageGive(K,z){talk(K.n,[...(K.page||["He left a page of his notes with me. Said somebody from the Institute would come for it one day."]),`(You got the founder's ${PAGES[z].t.toLowerCase()}!)`],()=>{const g=pagesGot();if(!g.includes(z))g.push(z);store.set("wta_pages",g);if(Q.s===1&&PAGE_MAPS.every(m=>g.includes(m)))Q.s=2;say0("A founder's page was added to your JOURNAL.")})}
function say0(t){$("#expmsg").textContent=t}
function questObjs(){const z=EXP.zone,W=EXP.W,H=EXP.H;EXP.objs=[];
  const add=(x,y,cls,html,use)=>{const d=document.createElement("div");d.className="mapobj "+cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));const o={x,y,el:d,use};EXP.objs.push(o);return o};
  const STAIRS=`<svg viewBox="0 0 40 40"><path d="M6 36 H34 V30 H28 V24 H22 V18 H16 V12 H10 V6 H6 Z" fill="#6A6254" stroke="#3A342C" stroke-width="1.5"/></svg>`;
  if(z.cls==="z-quill"&&!z.special){
    const[sx,sy]=HALL.seal,open=Q.s>=8;add(sx,sy,"seal"+(open?" open":""),open?`<svg viewBox="0 0 40 40"><rect x="6" y="4" width="28" height="36" fill="#0A0806"/><path d="M6 4 L10 0 L30 0 L34 4" fill="#3A342C"/><path d="M12 14 H28 M14 22 H26 M16 30 H24" stroke="#2A2420" stroke-width="2"/></svg>`:`<svg viewBox="0 0 40 40"><rect x="2" y="2" width="36" height="36" fill="#6A6254" stroke="#3A342C" stroke-width="2"/><path d="M2 12 H38 M2 22 H38 M2 32 H38 M12 2 V12 M26 12 V22 M12 22 V32 M26 32 V38" stroke="#4A443A" stroke-width="1.2"/><circle cx="20" cy="20" r="8" fill="#A8161E" stroke="#6A0A10" stroke-width="1.5"/><text x="20" y="24" text-anchor="middle" font-family="Georgia,serif" font-size="11" font-weight="700" fill="#F2D0C0">Q</text></svg>`,
      ()=>{const s=Q.s;if(s>=8){talk("",["Stone steps lead down into the dark. The air smells of dust and something faintly sweet.","You go down."],()=>goZone(BASEMENT));return}
        if(s===7){talk("",["You set the Sealbreaker against the wax seal. It bites into the stone like a hot knife into butter.","The wall that isn't a wall comes down in a rush of dust. Behind it, stone steps go down."],()=>{Q.s=8;goZone(BASEMENT)});return}
        talk("",["A section of wall newer than the rest of the hall, stamped with the Institute's seal in dark wax.",Q.flag("recipe")?"Nothing you have could cut through it. Not yet.":"Something behind it hums, very faintly. No tool you own would so much as scratch it."])});
    const[cx,cy]=HALL.crucible;add(cx,cy,"crucible",`<svg viewBox="0 0 40 40"><ellipse cx="20" cy="35" rx="15" ry="3.5" fill="#000" opacity=".3"/><path d="M8 14 L32 14 L29 33 L11 33 Z" fill="#5A4A3A" stroke="#2A2018" stroke-width="1.6"/><ellipse cx="20" cy="14" rx="12" ry="3.5" fill="#3A2E24" stroke="#2A2018" stroke-width="1.4"/><rect x="17" y="21" width="6" height="6" rx="1" fill="#C8A060" stroke="#2A2018"/><circle cx="20" cy="24" r="1.2" fill="#2A2018"/></svg>`,
      ()=>{const s=Q.s;if(s<6){talk("",["The Institute's old crucible. Blackened with use, and padlocked shut.",Q.flag("recipe")?"Night Watchman Orrin has the key.":"Whoever used it last left a long time ago."]);return}
        if(s===6){talk("",["The crucible key turns stiffly in the lock.","You load it with the five metals from the founder's recipe and light the burner underneath.","Something is taking shape in there. It has to be identified before it will set. Get ready!"],()=>{EXP.questAlloy="Sealbreaker";encounter()});return}
        /* the recipe still works: you can cast it again (every casting has the usual chance of coming out Radiant) */
        if(!EXP.recastReady){EXP.recastReady=1;talk("",["The old crucible, cold now. You've cast the Sealbreaker before, and the recipe still works.","Every casting comes out a little different. If you want to cast another, use the crucible again."]);return}
        EXP.recastReady=0;talk("",["You load the crucible with the five metals from the founder's recipe and light the burner again.","Something is taking shape in there. Identify it before it sets!"],()=>{EXP.questAlloy="Sealbreaker";encounter()})});
    const[mx,my]=HALL.motto;add(mx,my,"motto",`<svg viewBox="0 0 40 40"><rect x="3" y="10" width="34" height="20" rx="2" fill="#C8A060" stroke="#6A4A12" stroke-width="2"/><path d="M8 17 H32 M10 23 H30" stroke="#6A4A12" stroke-width="2"/></svg>`,
      ()=>{Q.set("motto");talk("",["A brass plaque over the front doors, so old most people have stopped seeing it.","QVAERE POST MVRVM.","Someone has scratched a translation underneath, very small: 'seek behind the wall'."])});
    const[px,py]=HALL.portrait;add(px,py,"portrait",`<svg viewBox="0 0 40 40"><rect x="4" y="3" width="32" height="34" fill="#6B4A2E" stroke="#3A2414" stroke-width="2"/><rect x="8" y="7" width="24" height="26" fill="#2A2420"/><circle cx="20" cy="17" r="5" fill="#8A7A6A"/><path d="M12 33 Q20 22 28 33 Z" fill="#6A5A4A"/><circle cx="18.2" cy="16.8" r="1.6" fill="none" stroke="#EEE" stroke-width=".6"/><circle cx="21.8" cy="16.8" r="1.6" fill="none" stroke="#EEE" stroke-width=".6"/><rect x="11" y="29" width="18" height="3" fill="#C8A060"/></svg>`,
      ()=>{const s=Q.s;if(s>=11){talk("",["The founder's portrait. It swings aside on its hinge. The study is behind it."],()=>goZone(STUDY));return}
        if(s===10){talk("",["The founder's portrait, the nameplate scratched away. There's a small recess in the frame, just the size of a signet ring.","You press the ring into it. Nothing moves. Then, faintly, a brass dial clicks out beside it, lettered like a lock.","The letter said it would open for his ring and for 'the words I carved over the front door'."],null,v=>{const x=v.toLowerCase().replace(/[^a-z ]/g,"").replace(/\s+/g," ").trim();
          if(x==="quaere post murum"||x==="qvaere post mvrvm"||x==="seek behind the wall"){talk("",["You spell out the words on the dial. Something heavy clicks behind the wall.","The whole portrait swings open like a door."],()=>{Q.s=11;goZone(STUDY)})}else talk("",[`You spell out '${v||"nothing"}'. The dial spins back to blank.`,"Words carved over the front door. Maybe take a closer look at the front doors."])});return}
        talk("",["A portrait of the Institute's founder as a young man. Round spectacles. The nameplate has been scratched off.",Q.flag("vellYoung")?"You've seen that face somewhere. You're sure of it.":"He looks like he's about to say something."])})}
  if(z.special==="basement"){
    add(16,18,"stairs",STAIRS,()=>talk("",["Go back up to the hall?"],()=>{EXP.forceZone=ZONES.find(q=>q.cls==="z-quill");EXP.spawn=[HALL.seal[0],HALL.seal[1]+1];startExplore()}));
    add(3,2,"desk",`<svg viewBox="0 0 40 40"><rect x="3" y="16" width="34" height="5" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/><rect x="5" y="21" width="4" height="15" fill="#5A3A24"/><rect x="31" y="21" width="4" height="15" fill="#5A3A24"/><rect x="12" y="21" width="16" height="7" fill="#5A3A24" stroke="#3A2414"/><circle cx="20" cy="24.5" r="1.3" fill="#C8A060"/><rect x="10" y="10" width="10" height="6" fill="#E8E2D0" transform="rotate(-8 15 13)"/></svg>`,
      ()=>{if(Q.s>=9){talk("",["The founder's desk. The drawer stands open and empty."]);return}
        talk("",["The founder's desk. Papers everywhere, all of them blacked out except one line, repeated over and over: 'I should never have mixed it.'","The drawer has a small brass lock with two letter dials. His initials, probably."],null,v=>{const x=v.toUpperCase().replace(/[^A-Z]/g,"");if(x==="AM"){talk("",["The dials click into place. A.M. The drawer slides open.","Inside: a heavy signet ring stamped with a Q, and a letter torn clean in half.","'If you are reading this, you have my ring, and I have failed to undo what I made. The rest of this letter I left with the one I trusted first.'","(You got the FOUNDER'S SIGNET RING and half a letter.)"],()=>{Q.s=9;Q.set("ring");say0("New objective in your JOURNAL.")})}else talk("",[`You set the dials to '${x||"??"}'. The lock doesn't budge.`,"Surely there's something else down here with his name on it."])})});
    add(6,2,"photo",`<svg viewBox="0 0 40 40"><rect x="7" y="8" width="26" height="22" fill="#E8E2D0" stroke="#6B4A2E" stroke-width="2"/><rect x="10" y="11" width="20" height="13" fill="#8A8278"/><circle cx="16" cy="16" r="2.4" fill="#5A544A"/><circle cx="24" cy="16" r="2.4" fill="#5A544A"/><path d="M11 24 Q16 18 21 24 M19 24 Q24 18 29 24" fill="#5A544A"/></svg>`,
      ()=>{Q.set("photo");talk("",["A faded photograph: two people in front of the Institute on its opening day. A young man with round spectacles, and a girl holding a book.","Written underneath: 'Opening day, May \'64. A. M., with my first student, little V.'"])});
    add(8,6,"coat",`<svg viewBox="0 0 40 40"><path d="M20 4 V9" stroke="#6A6254" stroke-width="2"/><path d="M12 10 L28 10 L31 36 L9 36 Z" fill="#CFC4A0" stroke="#8A8478" stroke-width="1.4"/><path d="M20 10 V36" stroke="#C8C4B8"/><rect x="22" y="15" width="6" height="2.4" fill="#FFFFFF" stroke="#8A8478" stroke-width=".6"/></svg>`,
      ()=>{Q.set("coat");talk("",["A lab coat hangs on a hook, yellowed with age. The name tape has been torn off, all but the last few letters: '...LOW'.","In the pocket, a field badge, the enamel worn through at the edges. The number on it is 001."])});
    add(13,8,"ledger",`<svg viewBox="0 0 40 40"><rect x="4" y="8" width="32" height="28" fill="#5A3A24" stroke="#2A1A0C" stroke-width="1.4"/>${[10,17,24,31].map(y=>`<rect x="6" y="${y}" width="28" height="5" fill="#3A2414"/>`).join("")}<rect x="8" y="11" width="5" height="4" fill="#8A3A34"/><rect x="15" y="18" width="4" height="4" fill="#2E4A7A"/></svg>`,
      ()=>{Q.set("ledger");talk("",["A ledger of every sample the founder ever mixed. The last entry is circled so hard the nib tore the page.","'Sample 1. Do not name it. Do not sell it. Do not let anyone else near it.'","Beside it, in a later, shakier hand: 'Founder's Folly. He hated that name.'"])});
    const mh=Q.s===13;add(27,4,"cell",`<svg viewBox="0 0 40 40"><rect x="8" y="4" width="24" height="32" rx="3" fill="#2A2E36" stroke="#1A1C22" stroke-width="2"/><rect x="12" y="8" width="16" height="20" fill="#0A0C10"/><circle cx="20" cy="18" r="3" fill="#BFE4FF" opacity=".7"><animate attributeName="opacity" values=".3;.9;.3" dur="2.4s" repeatCount="indefinite"/></circle><path d="M12 8 L28 28 M28 8 L12 28" stroke="#6A7482" stroke-width="1"/></svg>`,
      ()=>talk("",["A containment cell, its door cracked down the middle. Something inside still glows with a slow heartbeat.","So that's why it only ever turns up in Quillmoor. It's been leaking out of here, a little at a time, for years."]));
    if(mh){const m=marlowNPC(true);m.x=27;m.y=5;EXP.npcs.push(m)}}
  if(z.special==="study"){
    add(9,8,"stairs",STAIRS,()=>talk("",["Go back out to the hall?"],()=>{EXP.forceZone=ZONES.find(q=>q.cls==="z-quill");EXP.spawn=[HALL.portrait[0],HALL.portrait[1]+1];startExplore()}));
    add(4,2,"desk",`<svg viewBox="0 0 40 40"><rect x="3" y="16" width="34" height="5" fill="#6B4A2E" stroke="#3A2414" stroke-width="1.2"/><rect x="5" y="21" width="4" height="15" fill="#5A3A24"/><rect x="31" y="21" width="4" height="15" fill="#5A3A24"/><rect x="11" y="9" width="8" height="7" fill="#E8E2D0"/><rect x="21" y="10" width="7" height="6" fill="#8A3A34"/></svg>`,
      ()=>{Q.set("letters");talk("",["A desk piled with recruitment letters. Hundreds of them, going back decades, every one signed 'A.M., Head of Field Team'.","One of them has your name on it."])});
    add(10,2,"diary",`<svg viewBox="0 0 40 40"><rect x="8" y="16" width="24" height="5" fill="#6B4A2E"/><rect x="12" y="9" width="16" height="8" fill="#2E3A5A" stroke="#1A2034"/><path d="M20 9 V17" stroke="#C8A060"/></svg>`,
      ()=>{if(Q.s===11){talk("",["A diary, open at yesterday's date. Every line is in a cramped private shorthand: loops, hooks and dots. You can't read a word of it.","Only the inside cover is in plain writing: 'For little V's eyes, if ever she wants them.'","(You took the DIARY.)"],()=>{Q.s=12;say0("New objective in your JOURNAL.")});return}
        if(Q.s===12){talk("",["The desk where the diary was. You have it. Chronicler Vell can read it."]);return}
        if(Q.flag("diary")){talk("",["The diary, and Vell's translation of the last entry: 'Every night I go down to tend the cell.'"]);return}
        talk("",["A shelf of old diaries in the same shorthand, going back decades."])})}}
function marlowNPC(inBasement){const m={n:"Dr. Marlow",look:{marlow:1,coat:"#FFFFFF",hair:"#6B4424",hs:"short",acc:["glasses","badge","book"],skin:"#F2C7A5"},talks:[["..."]]};
  m.quest=()=>{const s=Q.s;
    if(inBasement){talk(m.n,["Hello, recruit. You found me.","(He takes his spectacles off and polishes them on his sleeve while he talks. There is a little star-shaped chip in the left lens.)","No. Not here. Not with it listening.","The study. Come and find me there when you can prove whatever it is you think you know. Be certain of it. I will be."],()=>{Q.s=14;const me=EXP.npcs.find(p=>p.n==="Dr. Marlow");npcTravel(me,[16,18],true,()=>say0("Marlow went back up the stairs to the study. Build your case first."))});return}
    if(s>=15){talk(m.n,["You found me out, recruit. I'm still proud of you for it.","Go on. The field needs you more than it needs me. And Quillmoor needs somebody who isn't afraid to look behind walls."]);return}
    if(s<14){talk(m.n,["Not now, recruit. Not yet."]);return}
    const no=()=>talk(m.n,["No.","Go back through what you've found. Then come and try again. I have time. I have, as it turns out, a great deal of time."]);
    talk(m.n,["So. The recruit. Sit, if you like.","You've come a long way to find an old man hiding behind his own portrait.","Before you tell me what you think, let's see what you know. Answer me three things.","The founder mixed one sample, and only one, that he never let anyone name. What does everyone call it now?"],null,a1=>{
      if(!/folly|sample ?(1|one)\b/i.test(a1))return no();
      talk(m.n,["Yes. He hated that name.","His field badge. What number was on it?"],null,a2=>{
        if(!/^\s*(0*1|one|number one|no\.? ?0*1)\s*$/i.test(a2))return no();
        talk(m.n,["Yes.","Who was his first student?"],null,a3=>{
          if(!/vell|little ?v\b/i.test(a3))return no();
          talk(m.n,["...Yes. She kept her promise, then.","Now. Who founded this Institute, and made the thing in that basement?"],null,v=>{
            if(!/marlow|aldous|\byou\b|^\s*a\.?\s?m\.?\s*$/i.test(v)){talk(m.n,[`'${v||"..."}'? No. That isn't it.`,"Go back through what you've found. Then ask me again."]);return}
            talk(m.n,["...Bold. Very bold.",`Anyone can say a name. Show me why. ${NEED_EVIDENCE} things. Things that prove it about me, not just about the founder.`],()=>evidencePick(picks=>{
              const good=picks.filter(f=>EVIDENCE.find(e=>e.f===f).good).length;
              if(good<NEED_EVIDENCE){talk(m.n,[good===0?"None of that says a thing about me, recruit.":`${good} of those hold up. ${NEED_EVIDENCE-good} ${NEED_EVIDENCE-good===1?"doesn't":"don't"}. Something that proves the founder existed isn't proof that he's me.`,"Find more. People who knew him long ago might remember things now they'd never have said before."]);return}
              Q.s=15;talk(m.n,["...Yes.","Aldous Marlow. Founder of the Quillmoor Institute. Mixer of sample number one, and the only person who ever called it a mistake to its face.","I made it down there when I was younger than you. I wanted to make something that would last forever. It does. It keeps me going too, I think. That's why I haven't aged a day since.","I sealed the basement, scratched my name off every record, and started again as plain Dr. Marlow, head of the field team.","I couldn't cut my own seal. So I scattered the recipe, and I trained people like you, and I waited for somebody who would look.","You did it, recruit. Not the metal. The looking.","...There's one more thing. Something I have never once managed on my own.","Quartermaster Hobbs keeps a crate of control rods signed out to 'nobody'. Fetch it for me, and meet me in the basement. Tonight."],()=>{store.set("wta_fin",1);store.set("wta_qf_seenJ",0);journalDot();say0("New objective in your JOURNAL: fetch the control rods from Quartermaster Hobbs, then meet Dr. Marlow in the basement.")})},NEED_EVIDENCE))})})})})};return m}
function evidencePick(done,need=4){const have=EVIDENCE.filter(e=>Q.flag(e.f));const d=dlgEl();DLG.open=true;EXP.busy=true;d.hidden=false;$("#dlg-who").textContent="PRESENT EVIDENCE";$("#dlg-who").hidden=false;$("#dlg-more").hidden=true;
  const sel=new Set;$("#dlg-txt").innerHTML=`<span>Choose ${need} pieces of evidence, then press PRESENT.</span><span class="evlist">${have.map(e=>`<button class="ev" data-f="${e.f}" title="${e.x}">${e.t}</button>`).join("")}</span><button class="btn go evgo" disabled>PRESENT</button>`;
  d.querySelectorAll(".ev").forEach(b=>b.onclick=e=>{e.stopPropagation();const f=b.dataset.f;if(sel.has(f))sel.delete(f);else if(sel.size<need)sel.add(f);b.classList.toggle("on",sel.has(f));d.querySelector(".evgo").disabled=sel.size!==need;sfx("sel")});
  d.querySelector(".evgo").onclick=e=>{e.stopPropagation();dlgClose();done([...sel])}}

/* ---- items: each one its own thing, drawn as itself. Effects stay small on purpose. ---- */
const ITEMS={
  cell:{name:"Spare Scanner Cell",desc:"A fat little battery that clicks into the scanner. One more scan on the alloy you're facing.",when:"round",w:9},
  token:{name:"Field Hint Token",desc:"A brass token the Institute hands out for good fieldwork. Trade it for a hint and keep your points.",when:"round",w:13},
  charm:{name:"Lucky Charm",desc:"A four-leaf clover pressed in resin. The next alloy you identify is worth 20% more.",when:"any",w:9},
  patch:{name:"Containment Patch",desc:"A riveted plate with sealant. Slaps over a leak for +8% containment in a threat fight.",when:"boss",w:12},
  stasis:{name:"Stasis Pack",desc:"A frosty canister. Crack it and containment can't drop for 5 seconds.",when:"boss",w:8},
  cloth:{name:"Lens Cloth",desc:"Soft, lint-free, faintly lavender. Wipes a dazzled scanner back into order.",when:"dazzled",w:7},
  quiet:{name:"Muffled Boots",desc:"Felt-soled overshoes. Nothing jumps out of the rubble for your next 25 steps.",when:"explore",w:11},
  lure:{name:"Rubble Lure",desc:"A jar of glittering filings that alloys can't resist. The next rubble you step into will hold one.",when:"explore",w:12},
  glint:{name:"Glint Lens",desc:"A jeweller's loupe. Look through it and anything dropped on this map sparkles.",when:"explore",w:7},
  decoy:{name:"Syndicate Decoy",desc:"A cardboard cut-out wearing a stolen orange badge. Grunts on this map will watch it instead of you.",when:"explore",w:6},
  timer:{name:"Pocket Timer",desc:"A wind-up timer that ticks very loudly. Throw it at a grunt and their fencing takes 12 seconds longer.",when:"duel",w:6}};
const ICONS={
  cell:`<rect x="6" y="5" width="12" height="16" rx="2" fill="#2E3A5A" stroke="#0B1330" stroke-width="1.3"/><rect x="9.5" y="2.8" width="5" height="2.4" rx=".6" fill="#9AA6C2" stroke="#0B1330" stroke-width=".8"/><rect x="8" y="14" width="8" height="5" rx="1" fill="#6BE08A"/><rect x="8" y="9.5" width="8" height="3.5" rx="1" fill="#6BE08A" opacity=".5"/><path d="M12 6.5 v3 M10.5 8 h3" stroke="#fff" stroke-width="1"/>`,
  token:`<circle cx="12" cy="12" r="9" fill="#E6B83A" stroke="#6A4608" stroke-width="1.3"/><circle cx="12" cy="12" r="6.5" fill="none" stroke="#FFF1B0" stroke-width=".8"/><path d="M9.8 9.6 Q10 7.4 12.2 7.4 Q14.4 7.4 14.4 9.4 Q14.4 10.8 12.4 11.8 V13.2" stroke="#6A4608" stroke-width="1.6" fill="none" stroke-linecap="round"/><circle cx="12.4" cy="15.8" r="1" fill="#6A4608"/>`,
  charm:`<circle cx="12" cy="13" r="8.5" fill="rgba(200,240,210,.5)" stroke="#6A8A6A" stroke-width="1"/>${[[0,-3.2],[3.2,0],[0,3.2],[-3.2,0]].map(([x,y])=>`<circle cx="${12+x}" cy="${13+y}" r="2.8" fill="#3AA05A" stroke="#1E5A2A" stroke-width=".6"/>`).join("")}<path d="M12 13 Q14 18 13 20.5" stroke="#1E5A2A" stroke-width="1.1" fill="none"/><path d="M12 4.5 V2.5" stroke="#9AA6C2" stroke-width="1.4"/>`,
  patch:`<rect x="4" y="5" width="16" height="14" rx="2" fill="#9AA6B4" stroke="#3A4450" stroke-width="1.3" transform="rotate(-8 12 12)"/>${[[6.5,7.5],[17,6],[7.5,17.5],[18,16]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1" fill="#E6ECF2" stroke="#3A4450" stroke-width=".5"/>`).join("")}<path d="M12 8.5 V15.5 M8.5 12 H15.5" stroke="#E8412C" stroke-width="2.4" stroke-linecap="round"/>`,
  stasis:`<rect x="6.5" y="4" width="11" height="17" rx="3" fill="#CFF0FF" stroke="#2E6F9E" stroke-width="1.3"/><rect x="8.5" y="2.4" width="7" height="2.4" rx=".8" fill="#2E6F9E"/><path d="M12 8 V17 M8.2 10.3 L15.8 14.7 M15.8 10.3 L8.2 14.7" stroke="#2E6F9E" stroke-width="1.2" stroke-linecap="round"/>`,
  cloth:`<path d="M4 8 L16 4 L20 14 L8 19 Z" fill="#E6DCF4" stroke="#8A7AB0" stroke-width="1.2"/><path d="M8 19 L7 21.5 L19 17 L20 14" fill="#CFC2E8" stroke="#8A7AB0" stroke-width="1"/><path d="M8 10 L15 7.5 M9.5 13.5 L17 10.5" stroke="#B8A8D8" stroke-width=".8"/><path d="M18.5 3.5 l.6 1.6 1.6.6 -1.6.6 -.6 1.6 -.6-1.6 -1.6-.6 1.6-.6z" fill="#fff"/>`,
  quiet:`<path d="M6 4 H12 V13 Q12 15 14 15.5 L19 16.5 Q21 17 21 19 V20 H5 V13 Z" fill="#8A7AB0" stroke="#3A2E5A" stroke-width="1.3" stroke-linejoin="round"/><path d="M5 20 H21" stroke="#3A2E5A" stroke-width="2.4"/><path d="M6.5 7 H11.5 M6.5 10 H11.5" stroke="#B8A8D8" stroke-width="1"/>`,
  lure:`<path d="M8 8 H16 V19 Q16 21 14 21 H10 Q8 21 8 19 Z" fill="rgba(220,240,255,.6)" stroke="#4A6A8A" stroke-width="1.2"/><rect x="7.2" y="5" width="9.6" height="3.4" rx="1" fill="#C8A060" stroke="#6A4A12" stroke-width=".9"/>${[[10,13],[13,15],[11,18],[14,11.5],[12,16.5]].map(([x,y],k)=>`<circle cx="${x}" cy="${y}" r="${k%2?.9:1.3}" fill="${["#FFE27A","#8FE3FF","#FF9AD5"][k%3]}"/>`).join("")}<path d="M18 5 l.5 1.3 1.3.5 -1.3.5 -.5 1.3 -.5-1.3 -1.3-.5 1.3-.5z" fill="#FFE27A"/>`,
  glint:`<circle cx="10" cy="10" r="6" fill="rgba(200,230,255,.55)" stroke="#6A4A12" stroke-width="2"/><path d="M14.5 14.5 L20.5 20.5" stroke="#6A4A12" stroke-width="3" stroke-linecap="round"/><path d="M7.4 8 Q8.4 6.4 10 6.2" stroke="#fff" stroke-width="1.2" fill="none"/><path d="M10 9 l.5 1.2 1.2.5 -1.2.5 -.5 1.2 -.5-1.2 -1.2-.5 1.2-.5z" fill="#FFE27A"/>`,
  decoy:`<path d="M8 22 V13 Q8 10 12 10 Q16 10 16 13 V22 Z" fill="#C8A878" stroke="#6A5A3A" stroke-width="1.2"/><circle cx="12" cy="6.5" r="3.2" fill="#C8A878" stroke="#6A5A3A" stroke-width="1.2"/><path d="M9 5 Q12 1.5 15 5 Z" fill="#26262C"/><circle cx="12" cy="15" r="2" fill="#FF7A1A" stroke="#26262C" stroke-width=".7"/><path d="M6 22 H18" stroke="#6A5A3A" stroke-width="1.6"/>`,
  timer:`<circle cx="12" cy="13.5" r="7.5" fill="#E8E2D0" stroke="#8A6A2A" stroke-width="1.6"/><rect x="10.5" y="3" width="3" height="3" rx=".8" fill="#8A6A2A"/><path d="M12 13.5 V9 M12 13.5 L15 15.5" stroke="#2A2018" stroke-width="1.3" stroke-linecap="round"/><path d="M5.5 6.5 L7.4 8.2 M18.5 6.5 L16.6 8.2" stroke="#8A6A2A" stroke-width="1.4" stroke-linecap="round"/>`};
function itemIcon(k,s=22){return `<svg viewBox="0 0 24 24" width="${s}" height="${s}" aria-hidden="true">${ICONS[k]||ICONS.token}</svg>`}
const BAG=store.get("wta_bag",{});for(const k in BAG)if(!ITEMS[k])delete BAG[k];
const saveBag=()=>store.set("wta_bag",BAG);
function rollItem(kind){if(kind==="boss")return Math.random()<.5?"patch":rollFrom(DUEL_W);return rollFrom(kind==="duel"?DUEL_W:FIND_W)}
function giveItem(k,n=1){BAG[k]=(BAG[k]||0)+n;saveBag();bagCount()}
function takeItem(k){if(!BAG[k])return false;BAG[k]--;if(!BAG[k])delete BAG[k];saveBag();bagCount();return true}
function bagCount(){const b=$("#bagbtn");if(b){const n=Object.values(BAG).reduce((s,v)=>s+v,0);b.innerHTML=`BAG <b>${n}</b>`}}
function itemUsable(k){const w=ITEMS[k].when,r=S.r,boss=typeof bossActive==="function"&&bossActive();
  if(w==="explore")return S.phase==="explore"&&!EXP.busy&&!DLG.open&&!EXP.zone.special&&!(k==="glint"&&EXP.glint)&&!(k==="decoy"&&EXP.decoy)&&!(k==="quiet"&&EXP.quiet>0)&&!(k==="lure"&&EXP.lure)&&!(typeof TUT!=="undefined"&&TUT.on);
  if(w==="boss")return boss&&!(k==="stasis"&&TB.stasis>0)&&!(k==="patch"&&TB.hp>=100);
  if(w==="dazzled")return boss&&!!TB.orig;
  if(w==="any")return !S.charm;
  const live=S.phase==="round"&&r;if(!live)return false;
  if(w==="duel")return (r.stage==="elements"||r.stage==="name")&&!!r.duel;
  if(w==="name")return r.stage==="name"&&!r.a.threat&&!r.a.quest&&!r.choices;
  if(w==="elements"){if(r.stage!=="elements")return false;if(k==="sieve")return !r.sieved&&sieveable().length>0;return true}
  return false}
function useItem(k){if(!itemUsable(k)||!takeItem(k))return;const r=S.r;sfx("pickup");
  if(k==="cell"){r.tries++;r.maxTries++;renderActions();say("Click. The spare cell slots in. One more scan.")}
  if(k==="guide"){r.choices=guideChoices(r.a);renderActions();say("You smooth out the field guide page. Three names, one of them right. Pick carefully: a wrong pick still counts.")}
  if(k==="sieve"){const L=sieveable();for(let i=L.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[L[i],L[j]]=[L[j],L[i]]}const out=L.slice(0,8);out.forEach(s=>{r.miss.add(s);r.sel.delete(s)});r.sieved=true;renderActions();renderPicker();say(`You shake the sample through the sieve. ${out.join(", ")} fall away. None of them are in there.`)}
  if(k==="charm"){S.charm=true;const m="You tuck the clover charm in your pocket. The next alloy you register is worth 20% more.";S.phase==="explore"?say0(m):say(m)}
  if(k==="patch"){TB.hp=Math.min(100,TB.hp+8);bossHud();say("You slap the plate over the worst leak and rivet it down. +8% containment.")}
  if(k==="stasis"){TB.stasis=5;say("You crack the canister. Frost races over everything. For five seconds, nothing gets worse.")}
  if(k==="cloth"){TB.orig.forEach(([e,rr,c])=>{e.style.gridRow=rr;e.style.gridColumn=c});TB.orig=null;say("A quick wipe, and the glare's gone. The scanner is back in order.")}
  if(k==="quiet"){EXP.quiet=25;say0("You pull the felt overshoes on. Nothing will jump out at you for the next 25 steps.")}
  if(k==="lure"){EXP.lure=true;say0("You scatter the glittering filings ahead of you. The next rubble you step into will hold something.")}
  if(k==="glint"){EXP.glint=true;glintShow();say0("Through the loupe, dropped things sparkle. They're marked on the map now.")}
  if(k==="decoy"){const[fx,fy]=frontOf(),ok=canWalk(tileAt(fx,fy))&&!thingsAt(fx,fy).length,[x,y]=ok?[fx,fy]:[EXP.x,EXP.y];EXP.decoy=true;EXP.decoyAt=[x,y];
    const d=document.createElement("div");d.className="mapobj decoyfig";d.style.width=(100/EXP.W)+"%";d.style.height=(100/EXP.H)+"%";d.style.left=(x/EXP.W*100)+"%";d.style.top=(y/EXP.H*100)+"%";d.innerHTML=`<svg viewBox="0 0 24 24">${ICONS.decoy}</svg>`;$("#world").insertBefore(d,$("#player"));
    (EXP.grunts||[]).forEach(g=>{if(g.done)return;g.face=Math.abs(x-g.x)>=Math.abs(y-g.y)?[Math.sign(x-g.x)||1,0]:[0,Math.sign(y-g.y)||1];slagFace(g)});
    say0("You stand the cardboard grunt up. Every Syndicate grunt on this map turns to stare at it.")}
  if(k==="survey"){const m=modal("survey","SURVEY MAP");closeBag();m.querySelector(".bag-list").innerHTML=`<p class="bag-empty">Where to? You'll walk straight there.</p>`+ZONES.map((z,i)=>z.cls==="z-slag"?"":`<button class="bag-item go-zone" data-i="${i}"><b>${z.name}</b><p>${z.sub}</p></button>`).join("");
    m.querySelectorAll(".go-zone").forEach(b=>b.onclick=()=>{m.hidden=true;goZone(ZONES[+b.dataset.i])});const back=()=>{m.hidden=true;giveItem("survey");say0("You fold the survey map back up.")};m.querySelector(".bag-top .btn").onclick=back;m.onclick=e=>{if(e.target===m)back()}}
  if(k==="timer"){r.duel.T+=12;say("You wind the timer and lob it. It ticks so loudly the grunt loses count. +12 seconds.")}
  renderBag()}
{const _bt=bossTick;bossTick=function(){const hp=TB.hp;_bt();if(TB.on&&TB.stasis>0){TB.stasis-=.1;if(TB.hp<hp)TB.hp=hp;if(typeof bossHud==="function")bossHud()}}}
function keyItems(){const s=Q.s,L=[];if(Q.flag("key")&&s<7)L.push(["CRUCIBLE KEY","A heavy iron key from Orrin's ring. Opens the old crucible."]);if(s===7)L.push(["SEALBREAKER","A casting made for one job: cutting the founder's seal."]);
  if(Q.flag("ring")&&s<15)L.push(["FOUNDER'S SIGNET RING","Heavy, stamped with a Q. It fits something."]);if(s===12)L.push(["THE STUDY DIARY","Written in a private shorthand you can't read. Chronicler Vell can."]);
  if(sideState("toby")===1)L.push(["TOBY'S NOTE","For Janitor Lu, at the Old Reactor Hall."]);if(sideState("toby")===2)L.push(["LU'S REPLY","'Eat a vegetable.' For Intern Toby."]);return L}
function renderBag(){const m=$("#bag");if(!m||m.hidden)return;const tl=toolList();
  let h=keyItems().map(([t,x])=>`<div class="bag-item key"><b>${t}</b><p>${x}</p></div>`).join("");
  h+=`<h5 class="bag-h">TOOLS</h5>`+(tl.length?tl.map(k=>`<div class="bag-item toolrow"><svg viewBox="0 0 24 24" width="34" height="34" aria-hidden="true">${TOOLS[k].icon}</svg><div><b>${TOOLS[k].name}</b><p>${TOOLS[k].desc}</p></div><span class="always">ALWAYS ON</span></div>`).join(""):`<p class="bag-empty">No tools yet. Some of the locals lend them out if you do them a favour: try Bolt at the Scrapyard, Foreman Dray at Rustvein Mine, and Ole out on the ice at Frostbite Cavern.</p>`);
  const any=Object.keys(ITEMS).some(k=>BAG[k]);
  if(!any)h+=`<p class="bag-empty">No supplies. Search the maps for things people have dropped, and crates people have nailed shut.</p>`;
  BAGCATS.forEach(([c,t])=>{const ks=Object.keys(ITEMS).filter(k=>ITEMS[k].cat===c&&BAG[k]);if(!ks.length)return;
    h+=`<h5 class="bag-h">${t}</h5>`+ks.map(k=>`<div class="bag-item">${itemIcon(k,34)}<div><b>${ITEMS[k].name} <span>×${BAG[k]}</span></b><p>${ITEMS[k].desc}</p></div><button class="btn" data-use="${k}" ${itemUsable(k)?"":"disabled"}>USE</button></div>`).join("")});
  m.querySelector(".bag-list").innerHTML=h;m.querySelectorAll("[data-use]").forEach(b=>b.onclick=()=>useItem(b.dataset.use))}
function modal(id,title){let m=$("#"+id);if(!m){m=document.createElement("div");m.id=id;m.className="modal";m.innerHTML=`<div class="bag-card"><div class="bag-top"><b>${title}</b><button class="btn">CLOSE</button></div><div class="bag-list"></div></div>`;document.body.appendChild(m);
    m.onclick=e=>{if(e.target===m)m.hidden=true};m.querySelector(".bag-top .btn").onclick=()=>{m.hidden=true}}m.hidden=false;sfx("sel");return m}
function openBag(){modal("bag","BAG");renderBag()}
function openJournal(){const m=modal("journal","JOURNAL"),s=Q.s,g=pagesGot();store.set("wta_qf_seenJ",1);journalDot();const C=[];
  if(Q.flag("recipe"))C.push(["The Sealbreaker recipe","Tungsten, hafnium, tantalum, rhenium and osmium, cast together in the Institute's old crucible."]);
  [...PAGE_MAPS,"z-crater"].forEach(z=>{if(g.includes(z))C.push([`The founder's notes: ${PAGES[z].t.toLowerCase()}`,PAGES[z].x])});
  if(Q.flag("ring"))C.push(["The founder's letter, first half","'If you are reading this, you have my ring, and I have failed to undo what I made. The rest of this letter I left with the one I trusted first.'"]);
  if(Q.flag("half2"))C.push(["The founder's letter, second half","'...My study lies behind my oldest face. It will open for my ring, and for the words I carved over the front door. — A.M.'"]);
  if(Q.flag("wrenAM"))C.push(["The staff roster","Two lines on the Institute's first staff roster have been scratched out with the same knife. One of them was the founder's."]);
  const ev=EVIDENCE.filter(e=>Q.flag(e.f));
  const sq=[...Object.values(AMBIENT).flat().filter(p=>p.side)].filter(p=>sideState(p.side.id)>0&&sideState(p.side.id)<3).map(p=>[`Favour: ${p.n}`,p.side.deliver?`Deliver ${p.side.thing} to ${p.side.deliver}.`:sideState(p.side.id)===1?`Find ${p.side.thing}.`:`Take ${p.side.thing} back to ${p.n}.`]);
  m.querySelector(".bag-list").innerHTML=(s>0||foActive()?`<div class="bag-item key"><b>${s>=15?"COMPLETE":"CURRENT OBJECTIVE"}</b><p>${questObjective()}</p></div>`:`<div class="bag-item key"><b>NO ACTIVE QUEST</b><p>Dr. Marlow, head of the field team, wants to see you. His office is at the Quillmoor Institute.</p></div>`)
    +sq.map(([t,x])=>`<div class="bag-item clue side"><b>${t}</b><p>${x}</p></div>`).join("")
    +(ev.length?`<h5 class="bag-h">EVIDENCE</h5>`+ev.map(e=>`<div class="bag-item clue"><b>${e.t}</b><p>${e.x}</p></div>`).join(""):"")
    +(C.length?`<h5 class="bag-h">NOTES</h5>`+C.map(([t,x])=>`<div class="bag-item clue"><b>${t}</b><p>${x}</p></div>`).join(""):"")}
function journalDot(){const b=$("#jbtn");if(b)b.classList.toggle("new",!store.get("wta_qf_seenJ",0))}
{const a=$(".audio"),b=document.createElement("button");b.className="aubtn";b.id="bagbtn";b.onclick=openBag;a.prepend(b);const j=document.createElement("button");j.className="aubtn";j.id="jbtn";j.textContent="JOURNAL";j.onclick=openJournal;a.prepend(j);bagCount()}
/* ---- the Slag Syndicate ---- */
const SLAG_NAMES=["Grunt Rikket","Grunt Vosk","Grunt Pella","Grunt Durn","Grunt Mabry","Grunt Skoll","Grunt Tamsk","Grunt Brack"];
const SLAG_INTRO=["Hold it right there! This rubble is Slag Syndicate territory!","Well, well. A little Institute scientist, all alone.","You've got a sharp eye. Let's see if it's sharper than mine!"];
const SLAG_MOTTO="Melt it down, sell it off, leave no trace! That's the Syndicate way!";
const SLAG_DEFEAT=["No way! You named it before I could fence it?!","The boss is not going to like this...","Fine! Keep your rock. There's plenty more where it came from!"];
const SLAG_WIN=["Too slow! This one's going straight to the smelter. And I'll take a little something for my trouble!","Ha! Sold before you even figured it out. Thanks for the tip money!"];
function slagWins(){return store.get("wta_slag",0)}
function gruntLook(boss){return{coat:"#26262C",hair:"#1A1A1E",hs:boss?"bald":"short",acc:boss?["cap","beard","badge"]:["cap"],hat:"#1A1A1E",legs:"#1A1A1E",beard:"#3A3A3A",skin:boss?"#C88A64":"#F2C7A5"}}
function gruntSVG(boss){return npcSVG(gruntLook(boss)).replace("</svg>",`<circle cx="20" cy="26" r="3.4" fill="#FF7A1A" stroke="#121B40" stroke-width="1"/><path d="M18.5 24.7 Q20 23.6 21.5 24.7 Q20 26 18.5 27.3 Q20 28.4 21.5 27.3" stroke="#121B40" stroke-width="1" fill="none"/></svg>`)}


/* ---- placing everything on the map ---- */
function worldPlace(){const M=EXP.zone.map,z=EXP.zone.cls,W=EXP.W,H=EXP.H,sp=EXP.zone.special;
  document.querySelectorAll("#world .npc,#world .mapitem,#world .glintmark,#world .mapobj").forEach(e=>e.remove());
  Object.assign(EXP,{npcs:[],items:[],hidden:[],grunts:[],objs:[],glint:false,decoy:false,lure:false,quiet:0,dir:[1,0]});
  gatedCompute();litUpdate();
  const inTut=typeof TUT!=="undefined"&&TUT.on,S0=SPOTS[z]||{},taken=new Set(Object.values(S0).map(([x,y])=>x+","+y)),floor=[];
  M.forEach((row,y)=>row.split("").forEach((c,x)=>{if((c==="."||c===":")&&Math.abs(x-EXP.x)+Math.abs(y-EXP.y)>=4&&!taken.has(x+","+y)&&!(z==="z-quill"&&!sp&&y<=1))floor.push([x,y])}));
  for(let i=floor.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[floor[i],floor[j]]=[floor[j],floor[i]]}
  const used=new Set,spot=open=>{for(let i=floor.length-1;i>=0;i--){const[x,y]=floor[i],k=x+","+y;if(used.has(k)||(open&&inGated(x,y)))continue;floor.splice(i,1);used.add(k);return[x,y]}return null};
  const addEl=(cls,x,y,html)=>{const d=document.createElement("div");d.className=cls;d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));return d};
  const person=(p,at)=>{EXP.npcs.push({...p,x:at[0],y:at[1],el:addEl("npc",at[0],at[1],`<span class="talkmark">...</span>`+npcSVG(p.look)),said:0})};
  questObjs();tileObjs();questObjs2();
  if(sp==="study"&&Q.s>=14)person(marlowNPC(false),[9,5]);
  if(sp==="basement")EXP.npcs.filter(p=>p.n==="Dr. Marlow").forEach(p=>{p.el=addEl("npc",p.x,p.y,`<span class="talkmark">...</span>`+npcSVG(p.look))});
  if(!inTut&&!sp){
    if(KEEPERS[z]&&S0.keeper)person({...KEEPERS[z],keeper:true},keeperPos(z));
    const D=DISCOVERERS[z];if(D&&S0.disc&&ALLOYS.some(a=>a.name===D.a))person(D,S0.disc);
    (AMBIENT[z]||[]).forEach((p,i)=>{const at=S0["amb"+(i+1)];if(at)person(p,at)});
    questHooks(z);pageHooks(z);sideSeed();questSeed();
    const mk=(at,boss,page,face)=>{const g={n:boss?"Foreman Grist":SLAG_NAMES[Math.random()*SLAG_NAMES.length|0],boss,page,grunt:true,x:at[0],y:at[1],face:face||[[1,0],[-1,0],[0,1],[0,-1]][Math.random()*4|0]};g.el=addEl("npc grunt",g.x,g.y,`<span class="bang">!</span>`+gruntSVG(boss));EXP.grunts.push(g);slagFace(g)};
    if(z==="z-scrap"&&Q.s>=1&&PQ("crater")===2&&S0.grist)mk(S0.grist,true,true,[-1,0]);
    let n=z==="z-quill"?0:Math.random()<.7?(Math.random()<.35?2:1):0;
    if(z==="z-scrap"&&PQ("bolt")===1&&!Q.flag("boltWin"))n=Math.max(n,1);
    if(PQ("crater")===1&&z!=="z-quill")n=Math.max(n,1);
    for(let i=0;i<n;i++){const at=spot(true);if(!at)break;mk(at,i===0&&slagWins()>=3&&Math.random()<.25,false)}
    for(let i=0;i<1;i++){if(Math.random()<.4){const at=spot();if(at){const k=rollItem();EXP.items.push({x:at[0],y:at[1],k,el:addEl("mapitem",at[0],at[1],itemIcon(k,40))})}}}
    const spots=[];M.forEach((row,y)=>row.split("").forEach((c,x)=>{if((c==="."||c===","||c===":")&&!used.has(x+","+y)&&!taken.has(x+","+y)&&Math.abs(x-EXP.x)+Math.abs(y-EXP.y)>=4)spots.push([x,y])}));
    for(let i=0;i<2&&spots.length;i++){const[x,y]=spots.splice(Math.random()*spots.length|0,1)[0];EXP.hidden.push({x,y,k:rollItem()})}}
  dowse();nearMarks()}
function glintShow(){const W=EXP.W,H=EXP.H;(EXP.hidden||[]).forEach(h=>{if(h.mark)return;const d=document.createElement("div");d.className="glintmark";d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(h.x/W*100)+"%";d.style.top=(h.y/H*100)+"%";$("#world").insertBefore(d,$("#player"));h.mark=d})}
function slagFace(g){if(!g||!g.el)return;g.el.style.setProperty("--face",g.face[0]<0?-1:1)}
function goZone(z){EXP.forceZone=z;EXP.spawn=null;startExplore()}
{const _se=startExplore;startExplore=function(){const sp=EXP.spawn;_se();if(sp){EXP.x=sp[0];EXP.y=sp[1];EXP.spawn=null;placePlayer(true)}}}

/* ---- walking ---- */
{const _step=step;step=function(dx,dy){if(DLG.open)return false;if(EXP.busy||S.phase!=="explore")return _step(dx,dy);EXP.dir=[dx,dy];const nx=EXP.x+dx,ny=EXP.y+dy;
  const c=tileAt(nx,ny);if(c===","&&EXP.quiet<=0&&EXP.lure){EXP.since=RUBBLE_PITY;EXP.lure=false}
  const px=EXP.x,py=EXP.y,ok=_step(dx,dy);nearMarks();if(EXP.x===px&&EXP.y===py)return ok;
  if(EXP.quiet>0){EXP.quiet--;if(!EXP.quiet)say0("Your muffled boots have worn thin. Alloys can find you again.")}
  const it=(EXP.items||[]).find(i=>i.x===EXP.x&&i.y===EXP.y);
  if(it){EXP.items=EXP.items.filter(i=>i!==it);it.el.remove();giveItem(it.k);sfx("pickup");say0(`You found a ${ITEMS[it.k].name.toUpperCase()}! It went into your BAG.`)}
  const g=(EXP.grunts||[]).find(p=>!p.done&&p.x===EXP.x&&p.y===EXP.y);if(g&&!EXP.busy)slagChallenge(g);
  dowse();slagSight();return ok}}
function dowse(){const d=$("#dowse");if(!d)return;const hs=EXP.hidden||[];if(!hs.length){d.innerHTML=`<span>DOWSING</span><i></i><i></i><i></i><em>nothing left here</em>`;d.dataset.lv=0;return}
  const dist=Math.min(...hs.map(h=>Math.abs(h.x-EXP.x)+Math.abs(h.y-EXP.y))),lv=dist===0?4:dist<=1?3:dist<=3?2:dist<=7?1:0;
  d.innerHTML=`<span>DOWSING</span>${[1,2,3].map(i=>`<i class="${lv>=i?"on":""}"></i>`).join("")}<em>${["no signal","faint signal","getting warmer","very close!","right here!"][lv]}</em>`;d.dataset.lv=lv}
function searchHere(){if(S.phase!=="explore"||EXP.busy)return;if(!gate("search",600))return;const hs=EXP.hidden||[],near=q=>Math.abs(q.x-EXP.x)+Math.abs(q.y-EXP.y),h=hs.find(q=>near(q)===0)||hs.find(q=>near(q)===1);
  if(h){EXP.hidden=hs.filter(q=>q!==h);if(h.mark)h.mark.remove();sfx("pickup");if(h.q)QFIND[h.q].done();else if(h.side){setSide(h.side,2);say0(`You found ${h.thing}! Take it back to its owner.`)}else{giveItem(h.k);say0(`You searched the ground and turned up a ${ITEMS[h.k].name.toUpperCase()}! It went into your BAG.`)}}
  else{sfx("beep");say0("Nobody to talk to and nothing to examine here. You search the ground... nothing. Watch the dowsing meter.")}dowse()}
function slagSight(){if(EXP.busy||DLG.open||S.phase!=="explore"||EXP.decoy||(typeof TUT!=="undefined"&&TUT.on))return;
  for(const g of EXP.grunts||[]){if(g.done)continue;const[fx,fy]=g.face;
    for(let d=1;d<=4;d++){const x=g.x+fx*d,y=g.y+fy*d;if(x===EXP.x&&y===EXP.y){slagSpot(g,d);return}if(!passable(tileAt(x,y)))break}}}
function slagSpot(g,d){EXP.busy=true;EXP.path=null;clearInterval(EXP.timer);clearInterval(EXP.hold);g.el.classList.add("alert");sfx("alert");
  let n=d-1;const walk=()=>{if(n<=0){g.el.classList.remove("alert");slagChallenge(g);return}g.x+=g.face[0];g.y+=g.face[1];g.el.style.left=(g.x/EXP.W*100)+"%";g.el.style.top=(g.y/EXP.H*100)+"%";n--;setTimeout(walk,220)};setTimeout(walk,700)}
function slagChallenge(g){if(g.done)return;g.done=true;
  const lines=[g.boss?"Foreman Grist of the Slag Syndicate. You've been embarrassing my grunts.":SLAG_INTRO[Math.random()*SLAG_INTRO.length|0],SLAG_MOTTO,g.page?"Looking for this? A page from the Institute's founder. Collectors pay a fortune. Name my sample before I fence it, and maybe I'll hand it over.":g.boss?"Let's see you name this one before I have it smelted!":"I've got a sample right here. Figure out what's in it before I can fence it. Deal?"];
  talk(g.n,lines,()=>{EXP.duel={n:g.n,boss:g.boss,page:g.page,T:g.boss?75:95};encounter()})}
setInterval(()=>{if(EXP.busy||DLG.open||S.phase!=="explore")return;(EXP.grunts||[]).forEach(g=>{if(!g.done&&Math.random()<.5){g.face=[[1,0],[-1,0],[0,1],[0,-1]][Math.random()*4|0];slagFace(g)}});slagSight()},1800);

/* ---- the duel, and the quest's special casting ---- */
{const _en=encounter;encounter=function(){if(EXP.quiet>0&&!EXP.duel&&!EXP.questAlloy&&!EXP.trial&&S.phase==="explore")return;_en()}}
{const _pa=pickAlloy;pickAlloy=function(kind,used){if(EXP.questAlloy){const a=ALLOYS.find(x=>x.name===EXP.questAlloy);if(a)return a}if(EXP.duel){for(let i=0;i<30;i++){const a=_pa(kind,used);if(!a.threat)return a}}return _pa(kind,used)}}
{const _sr=startRound;startRound=function(){const D=EXP.duel,QA=EXP.questAlloy;EXP.duel=null;let m=S.mode;if(QA)S.mode="recipe";_sr();S.mode=m;EXP.questAlloy=null;if(QA&&S.r)S.r.quest=true;if(D&&S.r&&!S.r.a.threat){S.r.duel={...D,t:0};duelStart()}}}
function duelBar(){let b=$("#duelbar");if(!b){b=document.createElement("div");b.id="duelbar";b.innerHTML=`<div class="db-top"><b id="db-name"></b><span>SLAG SYNDICATE CHALLENGE</span></div><div class="db-meter"><i id="db-fill"></i><span id="db-txt"></span></div>`;const ar=document.querySelector(".arena");ar.parentNode.insertBefore(b,ar)}return b}
function duelStart(){const D=S.r.duel,b=duelBar();b.hidden=false;b.classList.toggle("boss",!!D.boss);$("#db-name").textContent=D.n.toUpperCase();duelHud();clearInterval(D.iv);D.last=performance.now();D.iv=setInterval(duelTick,100);
  setTimeout(()=>{if(S.r&&S.r.duel===D)say(`${D.n.toUpperCase()} wants to fence this sample! Identify it before their bar fills up.`)},300)}
function duelHud(){const D=S.r&&S.r.duel;if(!D)return;const p=Math.min(100,D.t/D.T*100);$("#db-fill").style.width=p+"%";$("#db-txt").textContent=`FENCING THE SAMPLE · ${Math.max(0,Math.ceil(D.T-D.t))}s`}
function duelTick(){const r=S.r,D=r&&r.duel;if(!D||r.stage==="done"){duelEnd();return}const now=performance.now(),dt=Math.min(.25,(now-D.last)/1000);D.last=now;
  if(document.hidden||$("#stage").offsetParent===null)return;D.t+=dt;duelHud();if(D.t>=D.T){D.lost=true;lose(false)}}
function duelEnd(){const b=$("#duelbar");if(b)b.hidden=true;const D=S.r&&S.r.duel;if(D)clearInterval(D.iv)}
{const _w=win;win=function(){const r=S.r,D=r&&r.duel,charm=S.charm;_w();
  if(r.quest&&r.a.quest){if(Q.s===6){Q.s=7;setTimeout(()=>say("The SEALBREAKER has set! It went into your BAG. Now for that sealed wall..."),2400)}else setTimeout(()=>say(r.radiant?"Another SEALBREAKER sets, and this one SHINES.":"Another SEALBREAKER sets. The crucible will take another load whenever you like."),2400)}
  if(charm){S.charm=false;const x=Math.round(r.pts*.2);r.pts+=x;S.run.score+=x;renderHud();setTimeout(()=>say(`Your lucky charm paid off: +${x} points.`),D?4200:2400)}
  if(!D){if(S.run.score>S.best){S.best=S.run.score;store.set("wta_best2",S.best)}return}
  clearInterval(D.iv);duelEnd();const extra=r.pts;r.pts+=extra;S.run.score+=extra;if(S.run.score>S.best){S.best=S.run.score;store.set("wta_best2",S.best)}
  store.set("wta_slag",slagWins()+1);const k1=rollItem("duel");giveItem(k1);let got=ITEMS[k1].name.toUpperCase();if(D.boss){const k2=rollItem("boss");giveItem(k2);got+=" and a "+ITEMS[k2].name.toUpperCase()}renderHud();
  if(D.page&&!pagesGot().includes("z-crater")){const g=pagesGot();g.push("z-crater");store.set("wta_pages",g);if(Q.s===2)Q.s=3;got+=", and the founder's FIFTH PAGE"}
  setTimeout(()=>say(`${D.n.toUpperCase()}: "${SLAG_DEFEAT[Math.random()*SLAG_DEFEAT.length|0]}" You beat the Syndicate! Points doubled, and they dropped a ${got}.`),1800)}}
{const _l=lose;lose=function(ran){const r=S.r,D=r&&r.duel;_l(ran);if(r&&r.quest)setTimeout(()=>say("The casting cracked before it could set. The crucible can be fired again."),1800);if(!D)return;clearInterval(D.iv);duelEnd();
  const ks=Object.keys(BAG).filter(k=>BAG[k]);let what;if(ks.length){const k=ks[Math.random()*ks.length|0];takeItem(k);what=`They swiped a ${ITEMS[k].name.toUpperCase()} from your bag!`}else{const n=Math.min(S.run.score,40);S.run.score-=n;renderHud();what=n?`They took ${n} points' worth of your field notes!`:"Your bag was empty, so they just laughed at you."}
  say(`${D.n.toUpperCase()}: "${SLAG_WIN[Math.random()*SLAG_WIN.length|0]}" ${what}`)}}

/* ---- wiring: INTERACT (A), the dowsing meter, BAG and JOURNAL ---- */
{const bar=document.querySelector(".expbar");const box=document.createElement("div");box.className="expctl";box.innerHTML=`<div class="dowse" id="dowse"></div><div class="expbtns"><button class="btn go" id="btn-act">A · INTERACT</button><button class="btn" id="btn-bag2">BAG</button></div>`;bar.insertBefore(box,bar.querySelector(".dpad"));
  $("#btn-act").onclick=interact;$("#btn-bag2").onclick=openBag}
document.addEventListener("keydown",e=>{if(S.phase!=="explore"||$("#view-play").hidden)return;if(e.target.closest&&e.target.closest("input,textarea"))return;
  if(e.key==="e"||e.key==="E"||e.key===" "||e.key==="Enter"){e.preventDefault();interact()}else if(e.key==="b"||e.key==="B"){openBag()}else if(e.key==="j"||e.key==="J"){openJournal()}},true);
{const _se=startExplore;startExplore=function(){if(DLG.open)dlgClose();_se();worldPlace();if(!EXP.zone.special){$("#zone-name").textContent=EXP.zone.name}if(EXP.grunts&&EXP.grunts.length)setTimeout(()=>{if(!EXP.busy)say0("Someone in a dark coat is standing watch out here. Stay out of their line of sight, or be ready for a challenge.")},900)}}
journalDot();


