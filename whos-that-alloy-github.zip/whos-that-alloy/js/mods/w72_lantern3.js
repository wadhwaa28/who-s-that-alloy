/* =============== LANTERN NIGHT, ROUND FOUR ===============
   - The nerve meter is gone. Hollowmere's dangers act on you now.
   - THE STALKER: since you went down the hole, something tall and dark has been following you. It hides behind whatever is nearest and only
     shows itself when you stand still: a hand round the edge of a crate, a head over a wall. Keep still and it comes out. Turn on it while it's
     peeking and it bolts. Everywhere else it only frightens you. In Hollowmere it snatches what you're carrying and runs off into the dark
     with it, or, if you've nothing to take, throws you aside and drinks the nearest lantern. It won't come near a good light.
   - Every map is properly dressed now: garlands on the walls and something lit on every other bit of furniture, each map in its own style. */

/* ---------------- Hollowmere's old nerve system, retired ---------------- */
hmNerveUI=function(){const n=$("#hm-nerve");if(n)n.remove()};
hmHit=function(n,msg){hmShake();if(gate("hmhit",900))sfx("alert");if(msg)say0(msg)};
hmFlee=function(){};hmStalkStart=function(){};
{const _s=hmScaryStart;hmScaryStart=function(){_s();if(EXP.hmWatch&&EXP.hmWatch.el)EXP.hmWatch.el.remove();EXP.hmWatch=null}}
/* the graves hold you still, and holding still is the one thing you mustn't do */
hmGraveCheck=function(){const g=(EXP.hmGraves||[]).find(q=>!q.done&&q.x===EXP.x&&q.y===EXP.y);if(!g)return;g.done=1;g.el.classList.add("grab");EXP.busy=true;STK.held=1;clearInterval(EXP.timer);EXP.path=null;
  hmHit(0,"The turned earth gives under your foot, and something underneath takes hold of your ankle. You can't move. And standing still is the worst thing you can do round here.");
  setTimeout(()=>{EXP.busy=false;STK.held=0;g.el.classList.add("still");if(!STK.stage)say0("It lets go. The earth settles back down, as if nothing was ever there.")},2600)};
/* the tattie bogle, once it reaches the stile, doesn't let anyone past it in the dark */
hmTick=function(){if(!inHollow()){clearInterval(HMN.iv);HMN.iv=null;return}if(S.phase!=="explore"||DLG.open||(typeof CS!=="undefined"&&CS.on)||document.hidden||$("#lnt-mg"))return;HMN.cool=Math.max(0,HMN.cool-.25);
  const bog=(EXP.bogles||[])[0];if(!bog||HMN.cool||store.get("wta_lnt_bog",0)<HM_BOG_PATH.length-1||hmLightAt(EXP.x,EXP.y))return;
  if(Math.abs(bog.x-EXP.x)+Math.abs(bog.y-EXP.y)<=1){HMN.cool=5;const dx=Math.sign(EXP.x-bog.x),dy=Math.sign(EXP.y-bog.y)||1;let to=null;for(let k=3;k>=1&&!to;k--){const x=EXP.x+dx*k,y=EXP.y+dy*k;if(canWalk(tileAt(x,y))&&!thingsAt(x,y).length)to=[x,y]}
    if(bog.el)lntFlash(bog.el,"creak",1200);hmShake();if(gate("bogswipe",1500))sfx("clunk");if(to){EXP.x=to[0];EXP.y=to[1];placePlayer();cam()}
    say0("The tattie bogle's arm comes round like a gate swinging shut, and sweeps you off your feet. It is not letting anybody past it tonight. Not in the dark.")}};
HMN.v=100;
/* the journal now says what's actually out there */
{const _oj=openJournal;openJournal=function(){_oj();document.querySelectorAll("#journal .lnt-obj b").forEach(b=>{if(/STAY IN THE LIGHT/.test(b.textContent)){b.textContent="LANTERN NIGHT · DON'T STAND STILL";b.nextElementSibling.textContent="Something tall and dark has been following you since you went down the hole. It hides behind things, and it only shows itself when you stand still. Stand still too long in Hollowmere and it will take whatever you're carrying. Catch it peeking and it runs. It won't come near a good light. Some of the kirkyard graves don't stay still, and the tattie bogle doesn't like visitors."}})}}

/* ---------------- THE STALKER ---------------- */
const STK={stage:0,still:0,cool:4,iv:null,el:null,cover:null,obj:null,side:1,wall:false,held:0,last:0,seen:false};
const stkLive=()=>lntOn()&&EXP.zone&&!EXP.zone.special&&!(typeof TUT!=="undefined"&&TUT.on)&&(inHollow()||lntF("hm"));
const STK_SVG=`<svg viewBox="0 0 40 80" aria-hidden="true" style="overflow:visible;width:100%;height:100%"><defs><filter id="stkb" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation=".9"/></filter></defs>
  <g filter="url(#stkb)"><path d="M9 80 Q7 56 11 40 Q8 30 12 22 Q12 10 20 8 Q28 10 28 22 Q32 30 29 40 Q33 56 31 80 Z" fill="#06050C" opacity=".94"/>
  <path class="stk-armL" d="M11 34 Q2 42 0 54 Q-2 60 1 66" stroke="#06050C" stroke-width="3.4" fill="none" stroke-linecap="round"/><path class="stk-armR" d="M29 34 Q38 42 40 54 Q42 60 39 66" stroke="#06050C" stroke-width="3.4" fill="none" stroke-linecap="round"/>
  <path d="M-1 66 l-2 4 M1 66 l0 5 M3 66 l2 4 M37 66 l-2 4 M39 66 l0 5 M41 66 l2 4" stroke="#06050C" stroke-width="1.4" stroke-linecap="round"/>
  <path d="M10 80 l-3 0 M30 80 l3 0 M14 72 Q10 76 8 80 M26 72 Q30 76 32 80" stroke="#06050C" stroke-width="2" opacity=".7"/></g>
  <g class="stk-eyes"><ellipse cx="16.6" cy="17" rx="1.7" ry="1.1" fill="#E8E4F4"/><ellipse cx="23.4" cy="17" rx="1.7" ry="1.1" fill="#E8E4F4"/><circle cx="16.8" cy="17.1" r=".55" fill="#06050C"/><circle cx="23.2" cy="17.1" r=".55" fill="#06050C"/></g>
  <path class="stk-mouth" d="M16 23 Q20 25 24 23" stroke="#E8E4F4" stroke-width=".7" fill="none" opacity=".0"/></svg>`;
const STK_BLOCK=new Set(["#","~","w","d","L","P",".",",","=",":","¥","V"]);
function stkCovers(){const out=[],M=EXP.zone.map,walk=c=>".,=:P".includes(c);
  for(let y=Math.max(1,EXP.y-4);y<=Math.min(EXP.H-2,EXP.y+4);y++)for(let x=Math.max(1,EXP.x-6);x<=Math.min(EXP.W-2,EXP.x+6);x++){const d=Math.abs(x-EXP.x)+Math.abs(y-EXP.y);if(d<2||d>6)continue;const c=(M[y]||"")[x];if(!c)continue;
    if(inHollow()&&hmLightAt(x,y))continue;if(thingsAt(x,y).some(t=>t.talks||t.grunt))continue;
    const below=(M[y+1]||"")[x];
    if(!STK_BLOCK.has(c)&&[[1,0],[-1,0],[0,1]].some(([dx,dy])=>walk((M[y+dy]||"")[x+dx])))out.push({x,y,wall:false,w:d});
    else if((c==="#"||c==="B")&&walk(below)&&walk((M[y-1]||"")[x]))out.push({x,y,wall:true,w:d+1})}
  return out}
function stkEl(){if(STK.el&&STK.el.isConnected)return STK.el;const d=document.createElement("div");d.className="lnt-stalker";d.innerHTML=`<div class="stk-in">${STK_SVG}</div>`;$("#world").appendChild(d);STK.el=d;return d}
function stkPlace(c){const d=stkEl(),W=EXP.W,H=EXP.H;STK.cover=c;STK.side=EXP.x<c.x?-1:1;STK.wall=c.wall;
  d.style.width=(100/W)+"%";d.style.height=(200/H)+"%";d.style.left=(c.x/W*100)+"%";d.style.top=((c.y-1)/H*100)+"%";d.style.zIndex=c.wall?"200":String(9+2*c.y);
  d.className="lnt-stalker "+(c.wall?"wall":"prop")+(STK.side<0?" left":" right");d.style.setProperty("--jx","0");d.style.setProperty("--jy","0")}
function stkHide(duck){const d=STK.el;if(d){d.classList.remove("p1","p2","jump");if(duck&&STK.stage){d.classList.add("duck");setTimeout(()=>d&&d.classList.remove("duck"),400)}}
  if(STK.obj){EXP.objs=EXP.objs.filter(o=>o!==STK.obj);STK.obj=null}STK.stage=0;STK.cover=null}
function stkPeek(n){const d=stkEl();d.classList.add(n===1?"p1":"p2");if(n===2)d.classList.remove("p1");STK.stage=n;
  if(!STK.obj&&STK.cover){STK.obj={x:STK.cover.x,y:STK.cover.y,use:stkConfront,stalker:1};EXP.objs.unshift(STK.obj)}
  if(n===1&&!STK.seen&&!inHollow()){STK.seen=true;lntSet("stkSeen",1);setTimeout(()=>{if(STK.stage&&!DLG.open)say0("Something tall and dark is watching you from behind cover. It came up out of the hole after you. It only dares to show itself while you're standing still.")},300)}}
function stkConfront(){if(!STK.stage)return;const d=STK.el,c=STK.cover;if(d){d.classList.remove("p1","p2");d.classList.add("bolt")}setTimeout(()=>d&&d.classList.remove("bolt"),900);
  if(STK.obj){EXP.objs=EXP.objs.filter(o=>o!==STK.obj);STK.obj=null}STK.stage=0;STK.still=0;STK.cool=inHollow()?18:40;if(gate("stkbolt",800))sfx("swirl");
  let prize="";if(inHollow()&&c&&Math.random()<.4){const spot=[[0,1],[1,0],[-1,0],[0,-1]].map(([dx,dy])=>[c.x+dx,c.y+dy]).find(([x,y])=>canWalk(tileAt(x,y))&&!(EXP.items||[]).some(i=>i.x===x&&i.y===y));
    if(spot){const k=rollItem();EXP.items=EXP.items||[];EXP.items.push({x:spot[0],y:spot[1],k,el:lntEl("mapitem",spot[0],spot[1],itemIcon(k,40))});prize=" It dropped something as it went."}}
  say0("You turn on it. It folds itself up into the dark behind cover with a hiss like a wick going out, and it's gone."+prize)}
function stkJump(){const d=stkEl(),c=STK.cover;if(!c){stkHide();return}const dx=EXP.x-c.x,dy=EXP.y-c.y;d.style.setProperty("--jx",dx*100+"%");d.style.setProperty("--jy",dy*50+"%");d.classList.remove("p1","p2");d.classList.add("jump");d.style.zIndex="400";
  if(STK.obj){EXP.objs=EXP.objs.filter(o=>o!==STK.obj);STK.obj=null}STK.stage=3;hmShake();if(gate("stkjump",1500))sfx("breach");
  setTimeout(()=>{d.classList.remove("jump");d.classList.add("gone");setTimeout(()=>d&&d.classList.remove("gone"),900);STK.stage=0;STK.still=0;STK.cover=null;if(inHollow()){STK.cool=22;stkSnatch()}else{STK.cool=60;say0("It comes out from behind cover all at once, long and dark and silent, and stops an inch from your nose... and then there's nothing there at all. It only ever does that to frighten you. Out here.")}},650)}
function stkSnatch(){const keys=Object.keys(BAG||{}).filter(k=>BAG[k]>0),W=EXP.W,H=EXP.H;
  const far=[];for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const d=Math.abs(x-EXP.x)+Math.abs(y-EXP.y);if(d>=10&&canWalk(tileAt(x,y))&&!hmLightAt(x,y)&&!thingsAt(x,y).length&&!(EXP.items||[]).some(i=>i.x===x&&i.y===y))far.push([x,y])}
  if(keys.length&&far.length){const k=keys[Math.random()*keys.length|0];if(takeItem(k)){const[x,y]=far[Math.random()*far.length|0];EXP.items=EXP.items||[];EXP.items.push({x,y,k,el:lntEl("mapitem stk-drop",x,y,itemIcon(k,40))});
      const dir=(y<EXP.y-2?"north":y>EXP.y+2?"south":"")+(x<EXP.x-2?(y<EXP.y-2||y>EXP.y+2?"-west":"west"):x>EXP.x+2?(y<EXP.y-2||y>EXP.y+2?"-east":"east"):"");
      say0(`It snatched your ${ITEMS[k].name.toUpperCase()} out of your bag and ran off into the dark to the ${dir||"far side of the village"} with it. It'll have dropped it out there somewhere. Go and get it back, and don't stop moving.`);return}}
  /* nothing to take: it throws you aside, and drinks the nearest lantern */
  const sx=Math.sign(EXP.x-(STK.lastCover?STK.lastCover.x:EXP.x))||1;let to=null;for(let k=3;k>=1&&!to;k--){const x=EXP.x+sx*k,y=EXP.y;if(canWalk(tileAt(x,y))&&!thingsAt(x,y).length)to=[x,y]}
  if(to){EXP.x=to[0];EXP.y=to[1];placePlayer();cam()}EXP.busy=true;setTimeout(()=>EXP.busy=false,1200);
  let best=null,bd=1e9;(LNT_DECOR["z-hollow"]||[]).forEach(([k,x,y])=>{const key="z-hollow:"+x+","+y;if(k==="neep"&&lntLit().has(key)&&!lntSnuffed(key)){const d=Math.abs(x-EXP.x)+Math.abs(y-EXP.y);if(d<bd){bd=d;best=key}}});
  if(best){EXP.gwSnuff=EXP.gwSnuff||new Set;EXP.gwSnuff.add(best);if(!EXP.gwPath)EXP.gwPath=[];const o=EXP.objs.find(q=>q.lnt==="neep"&&("z-hollow:"+q.x+","+q.y)===best);if(o&&o.el){o.el.classList.remove("lit");o.el.innerHTML=lntSvg(LNT_SVG.neep(false,(o.x*7+o.y*13+8)%5))}lntNight()}
  say0("There's nothing in your bag for it to take, so it takes you instead: it throws you aside like a sack of leaves."+(best?" Then it bends over the nearest lit neep, and drinks the light right out of it.":""))}
function stkTick(){if(!stkLive()||S.phase!=="explore"){if(STK.stage)stkHide();return}const dt=.2;
  const paused=(DLG.open&&!STK.held)||(typeof CS!=="undefined"&&CS.on)||document.hidden||$("#lnt-mg")||document.querySelector(".modal:not([hidden])")||(EXP.busy&&!STK.held);
  if(paused){if(DLG.open&&STK.stage)stkHide();return}
  STK.cool=Math.max(0,STK.cool-dt);if(STK.cool)return;if(inHollow()&&hmLightAt(EXP.x,EXP.y)>=1&&!STK.held){if(STK.stage)stkHide(true);STK.still=0;return}
  STK.still+=dt;const H=inHollow(),T=H?[1.6,3.4,5.4]:[3.5,6.5,9.5];
  if(STK.stage===0&&STK.still>=T[0]){const C=stkCovers();if(!C.length){STK.still=0;return}C.sort((a,b)=>a.w-b.w);const c=C[Math.min(C.length-1,Math.random()*Math.min(5,C.length)|0)];stkPlace(c);STK.lastCover=c;stkPeek(1)}
  else if(STK.stage===1&&STK.still>=T[1])stkPeek(2);
  else if(STK.stage===2&&STK.still>=T[2]){if(!H&&Math.random()<.45){stkHide(true);STK.cool=25;STK.still=0}else stkJump()}}
{const _pp=placePlayer;placePlayer=function(i){_pp(i);if(STK.stage&&STK.stage<3&&!STK.held){stkHide(true);STK.cool=Math.max(STK.cool,1.2)}STK.still=0}}
{const _wp=worldPlace;worldPlace=function(){_wp();STK.el=null;STK.stage=0;STK.cover=null;STK.obj=null;STK.still=0;STK.cool=Math.max(STK.cool,inHollow()?3:8);clearInterval(STK.iv);if(stkLive())STK.iv=setInterval(stkTick,200)}}
STK.seen=!!lntF("stkSeen");

/* ---------------- DRESSING EVERY MAP PROPERLY ----------------
   Each map's walls get its own garlands, swagged tile to tile and lit; and its furniture gets something lit on top. Different on every map. */
const dsw=(n,f)=>{let s="";for(let i=0;i<n;i++)s+=f(i*40,i);return s};   // one swag per tile
const dtw=(i,k)=>`style="animation-delay:-${((i*7+k*3)%11)*.23}s"`;
const LDRESS={
 "z-mine":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 4 Q${x+20} 16 ${x+40} 4" stroke="#6A4A2A" stroke-width="1.6" fill="none"/><path d="M${x+20} 10 V14" stroke="#3A3A40" stroke-width=".8"/><path d="M${x+16} 14 H${x+24} L${x+25} 22 Q${x+20} 24 ${x+15} 22 Z" fill="#7A7A82" stroke="#1E1E24" stroke-width=".8"/><circle cx="${x+18}" cy="17.6" r=".8" fill="#FFD27A"/><circle cx="${x+22}" cy="17.6" r=".8" fill="#FFD27A"/><path d="M${x+18} 20.4 Q${x+20} 21.6 ${x+22} 20.4" stroke="#FFD27A" stroke-width=".7" fill="none"/><circle class="dr-glow" ${dtw(i,1)} cx="${x+20}" cy="18" r="7" fill="#FFC870" opacity=".22"/>`)+`<path d="M0 0 L12 0 M0 0 L0 12 M0 0 L9 9 M3 0 Q3 3 0 3 M7 0 Q7 6 0 7" stroke="#D8D4CC" stroke-width=".5" fill="none" opacity=".75"/>`,
  t:(v)=>v?`<path d="M14 -2 H26 L27 10 Q20 12 13 10 Z" fill="#7A7A82" stroke="#1E1E24" stroke-width=".9"/><circle cx="17.6" cy="3" r="1" fill="#FFD27A"/><circle cx="22.4" cy="3" r="1" fill="#FFD27A"/><path d="M17 6.6 Q20 8.4 23 6.6" stroke="#FFD27A" stroke-width=".8" fill="none"/><path d="M15 -2 Q20 -6 25 -2" stroke="#5A5A62" stroke-width="1" fill="none"/>`
   :`<path d="M12 8 Q12 -2 20 -2 Q28 -2 28 8 Z" fill="#F2C94C" stroke="#5A4012" stroke-width=".9"/><path d="M11 8 H29" stroke="#5A4012" stroke-width="1.4"/><rect x="18" y="-1" width="4" height="3" fill="#FFF2B0"/><path d="M20 -6 V-2" stroke="#FFF2B0" stroke-width="1.6"/>`},
 "z-scrap":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 4 Q${x+20} 14 ${x+40} 4" stroke="#1E1E24" stroke-width="1" fill="none"/>`+[8,16,24,32].map((o,k)=>{const yy=4+10*4*(o/40)*(1-o/40)*1;return`<path d="M${x+o} ${yy} v2" stroke="#1E1E24" stroke-width=".8"/><ellipse class="dr-bulb" ${dtw(i,k)} cx="${x+o}" cy="${yy+4.6}" rx="1.9" ry="2.8" fill="${["#FF5A3A","#F2C94C","#5AE86A","#5AA8FF"][(i+k)%4]}"/>`}).join("")+`<circle cx="${x+20}" cy="11" r="2.6" fill="#C8C8D0" stroke="#5A5A62" stroke-width=".6"/><path d="M${x+18.6} 10.6 l.8 -.6 l.4 .9 M${x+20.4} 10.6 l.8 -.6 l.4 .9 M${x+18.8} 12 q1.2 .8 2.4 0" stroke="#3A3A40" stroke-width=".5" fill="none"/>`),
  t:(v)=>v?`<rect x="14" y="-2" width="12" height="13" rx="1" fill="#B8B8C0" stroke="#3A3A42" stroke-width=".9"/><path d="M14 1 H26 M14 8 H26" stroke="#8A8A92" stroke-width=".6"/><g fill="#FFB43A"><path d="M16 3 l1.6 -1.2 l.6 2 Z M22 3.8 l.6 -2 l1.6 1.2 Z M16.4 6 q3.6 2.6 7.2 0 q-3.6 1.2 -7.2 0 Z"/></g><circle class="dr-glow" cx="20" cy="4" r="8" fill="#FFB43A" opacity=".2"/>`
   :`<circle cx="20" cy="4" r="8" fill="#C8C8D0" stroke="#3A3A42" stroke-width="1"/><circle cx="20" cy="4" r="5" fill="none" stroke="#8A8A92" stroke-width=".8"/><circle cx="17.6" cy="2.6" r="1.2" fill="#E8412C"/><circle cx="22.4" cy="2.6" r="1.2" fill="#E8412C"/><path d="M17 6.4 Q20 8.6 23 6.4" stroke="#3A3A42" stroke-width="1" fill="none"/>`},
 "z-wreck":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 3 Q${x+20} 18 ${x+40} 3" stroke="#8A7A5A" stroke-width="1.2" fill="none"/>${[0,1,2,3].map(k=>`<path d="M${x+k*10} ${3+k*2.4} L${x+k*10+10} ${3+(k+1)*2.4+3} M${x+k*10+10} ${3+k*2.4} L${x+k*10} ${3+(k+1)*2.4+3}" stroke="#8A7A5A" stroke-width=".5" opacity=".7"/>`).join("")}<circle class="dr-bulb" ${dtw(i,2)} cx="${x+20}" cy="15" r="3.4" fill="${i%2?"#5AC8A8":"#5A8AE8"}" opacity=".85" stroke="#2A3A4A" stroke-width=".6"/><circle cx="${x+19}" cy="14" r="1" fill="#E8FFFF" opacity=".8"/>${i%3===1?`<path d="M${x+8} 9 l2 -2 l2 2 l-2 1.4 Z" fill="#F4E8D8" stroke="#8A7A6A" stroke-width=".4"/>`:""}`),
  t:(v)=>v?`<circle cx="20" cy="4" r="6.4" fill="#5AC8A8" opacity=".75" stroke="#2A4A3A" stroke-width=".8"/><path d="M16 1 Q20 -1 24 1" stroke="#E8FFFF" stroke-width="1" fill="none" opacity=".8"/><rect x="18.6" y="-1" width="2.8" height="4" fill="#F2EAD4"/><path class="lnt-flame" d="M20 -6 Q21.6 -3.6 20 -1 Q18.4 -3.6 20 -6 Z" fill="#FFB43A"/>`
   :`<path d="M12 10 Q12 -2 20 -4 Q28 -2 28 10 Z" fill="#F4E8D8" stroke="#8A7A6A" stroke-width=".8"/>${[14,17,20,23,26].map(xx=>`<path d="M20 -3 L${xx} 10" stroke="#C8B8A0" stroke-width=".6"/>`).join("")}<circle cx="17.4" cy="4" r="1.2" fill="#3A2A1A"/><circle cx="22.6" cy="4" r="1.2" fill="#3A2A1A"/>`},
 "z-volcano":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 3 Q${x+20} 15 ${x+40} 3" stroke="#3A3A42" stroke-width="1.6" stroke-dasharray="2 1" fill="none"/>`+[10,20,30].map((o,k)=>{const yy=3+12*4*(o/40)*(1-o/40);return`<path d="M${x+o} ${yy} v${3+k%2*3}" stroke="#3A3A42" stroke-width=".6"/><path class="dr-bulb" ${dtw(i,k)} d="M${x+o-2} ${yy+3+k%2*3} L${x+o} ${yy+10+k%2*3} L${x+o+2} ${yy+3+k%2*3} Z" fill="#FF7A2A" stroke="#3A0A04" stroke-width=".5"/>`}).join("")+`<path d="M${x+2} 4 q2 6 -1 10 M${x+38} 4 q-2 6 1 10" stroke="#C83A2A" stroke-width="1.2" fill="none"/>`),
  t:(v)=>`<path d="M14 10 L15 -2 L20 -6 L25 -2 L26 10 Z" fill="#1A1418" stroke="#08060A" stroke-width=".9"/><path d="M17 2 l2 3 l-2 3 M23 2 l-2 3 l2 3" stroke="#FF8A2A" stroke-width="1.1" fill="none"/>${v?`<rect x="18.6" y="-10" width="2.8" height="4" fill="#E8DCC0"/><path class="lnt-flame" d="M20 -15 Q21.6 -12.6 20 -10 Q18.4 -12.6 20 -15 Z" fill="#FFB43A"/>`:""}`},
 "z-glacier":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 3 Q${x+20} 11 ${x+40} 3" stroke="#E8F4FF" stroke-width="1" fill="none"/>`+[5,12,19,26,33].map((o,k)=>{const yy=3+8*4*(o/40)*(1-o/40),l=5+((i*3+k*5)%4)*2.4;return`<path class="dr-bulb" ${dtw(i,k)} d="M${x+o-1.4} ${yy} L${x+o} ${yy+l} L${x+o+1.4} ${yy} Z" fill="#BFE8FF" stroke="#8AB8D8" stroke-width=".3"/>`}).join("")),
  t:(v)=>`<path d="M13 10 L14 0 Q20 -2 26 0 L27 10 Z" fill="#D8F4FF" opacity=".8" stroke="#5A8AA8" stroke-width=".8"/>${v?`<circle class="dr-glow" cx="20" cy="4" r="8" fill="#BFE8FF" opacity=".3"/><path class="lnt-flame" d="M20 0 Q21.6 2.4 20 5 Q18.4 2.4 20 0 Z" fill="#FFC870"/>`:`<path d="M16 3 l3 -2 M22 6 l3 -2" stroke="#FFFFFF" stroke-width=".8"/>`}`},
 "z-vault":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 2 Q${x+20} 22 ${x+40} 2 L${x+40} 0 L${x} 0 Z" fill="#2A1A3A" stroke="#14081E" stroke-width=".8"/><path d="M${x} 2 Q${x+20} 22 ${x+40} 2" stroke="#C8A040" stroke-width="1.4" fill="none"/><path d="M${x+6} 4 Q${x+20} 16 ${x+34} 4" stroke="#3A2A4A" stroke-width=".8" fill="none"/>`+`<g class="dr-tassel" ${dtw(i,0)}><path d="M${x+40} 0 V6" stroke="#C8A040" stroke-width="1"/><circle cx="${x+40}" cy="7" r="1.6" fill="#C8A040"/><path d="M${x+38.6} 8 L${x+38} 15 H${x+42} L${x+41.4} 8 Z" fill="#C8A040"/></g>`),
  t:(v)=>`<path d="M15 10 H25 L24 7 H16 Z" fill="#C8A040" stroke="#5A4012" stroke-width=".7"/><rect x="18.4" y="-3" width="3.2" height="10" fill="#F2EAD4" stroke="#8A7A5A" stroke-width=".4"/><path d="M14 4 Q17 1 20 4 Q23 1 26 4 Q23 6 20 4 Q17 6 14 4 Z" fill="#14081E"/>${v?`<path class="lnt-flame" d="M20 -9 Q21.6 -6 20 -3 Q18.4 -6 20 -9 Z" fill="#FFB43A"/><circle class="dr-glow" cx="20" cy="-5" r="6" fill="#FFE08A" opacity=".3"/>`:""}`},
 "z-reactor":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 4 Q${x+20} 14 ${x+40} 4" stroke="#F2C94C" stroke-width="3" fill="none"/><path d="M${x} 4 Q${x+20} 14 ${x+40} 4" stroke="#1E1E24" stroke-width="3" stroke-dasharray="3 3" fill="none"/><g class="dr-bulb" ${dtw(i,1)}><path d="M${x+18} 9 L${x+17} 19 M${x+20} 9 L${x+20} 20 M${x+22} 9 L${x+23} 19" stroke="#9AFF6A" stroke-width="1.8" stroke-linecap="round"/></g><circle class="dr-glow" ${dtw(i,2)} cx="${x+20}" cy="15" r="6" fill="#9AFF6A" opacity=".22"/>`),
  t:(v)=>`<path d="M15 -4 H25 V0 L28 10 H12 L15 0 Z" fill="#E0F4F0" fill-opacity=".5" stroke="#4A5A6A" stroke-width=".8"/><path d="M13 7 H27 L28 10 H12 Z" fill="#9AFF6A" opacity=".75"/>${v?`<circle class="dr-glow" cx="20" cy="5" r="8" fill="#9AFF6A" opacity=".25"/>`:""}<path d="M18 -1 V8 M21 0 V8" stroke="#B8FF8A" stroke-width="1.2"/>`},
 "z-crater":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 3 Q${x+20} 13 ${x+40} 3" stroke="#C8C0A0" stroke-width=".6" fill="none"/><g class="dr-bulb" ${dtw(i,0)}><path transform="translate(${x+20} 12) scale(.36)" d="M0 -10 L3 -3 L10 -3 L4.4 1.6 L6.4 9 L0 4.6 L-6.4 9 L-4.4 1.6 L-10 -3 L-3 -3 Z" fill="#FFE8A0" stroke="#8A7A4A" stroke-width="1.4"/></g><circle cx="${x+8}" cy="7" r="1.6" fill="#F4E8B0" opacity=".9"/><circle cx="${x+32}" cy="7" r="1.6" fill="#F4E8B0" opacity=".9"/>`),
  t:(v)=>`<path d="M20 -6 L22.6 -1 L28 -0.6 L24 3 L25.4 8.6 L20 5.6 L14.6 8.6 L16 3 L12 -0.6 L17.4 -1 Z" fill="${v?"#FFE8A0":"#8A7A5A"}" stroke="#4A3A1A" stroke-width=".8"/>${v?`<circle class="dr-glow" cx="20" cy="1" r="9" fill="#FFE8A0" opacity=".25"/>`:""}`},
 "z-quill":{g:n=>dsw(n,(x,i)=>[0,1,2,3,4].map(k=>{const xx=x+4+k*8,yy=3+12*4*((xx-x)/40)*(1-(xx-x)/40);return`<ellipse cx="${xx}" cy="${yy}" rx="4.4" ry="2.2" fill="none" stroke="${k%2?"#1E1E24":"#E8762A"}" stroke-width="1.6"/>`}).join("")+`<g class="dr-bat" ${dtw(i,3)}><path transform="translate(${x+20} 18) scale(.55)" d="M-8 0 Q-6 -4 -2 -1 L0 -4 L2 -1 Q6 -4 8 0 Q6 1 5 4 Q2 2 0 4 Q-2 2 -5 4 Q-6 1 -8 0 Z" fill="#14121A"/></g>`),
  t:(v)=>v?`<rect x="12" y="6" width="16" height="4" fill="#8A2A2A" stroke="#2A0A0A" stroke-width=".5"/><rect x="13" y="2" width="14" height="4" fill="#2A4A6A" stroke="#0A1A2A" stroke-width=".5"/><rect x="18.6" y="-4" width="2.8" height="6" fill="#F2EAD4"/><path class="lnt-flame" d="M20 -9 Q21.6 -6.6 20 -4 Q18.4 -6.6 20 -9 Z" fill="#FFB43A"/>`
   :`<path d="M13 8 Q12 -1 20 -2 Q28 -1 27 8 Q26 12 20 12 Q14 12 13 8 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width=".8"/><g fill="#FFB43A"><path d="M16 3 l1.6 -1.6 l.6 2 Z M22.4 3.4 l.6 -2 l1.6 1.6 Z M16 7 q4 3 8 0 q-4 1.4 -8 0 Z"/></g>`},
 "z-slag":{g:n=>dsw(n,(x,i)=>`<path d="M${x} 3 Q${x+20} 14 ${x+40} 3" stroke="#4A4A50" stroke-width="2.4" stroke-dasharray="3 1.6" fill="none"/><path class="dr-bulb" ${dtw(i,0)} d="M${x+18} 12 L${x+20} 18 L${x+22} 12 L${x+20} 10 Z" fill="#6A8AD8" stroke="#1A1A1E" stroke-width=".5"/>`),
  t:(v)=>`<path d="M13 8 Q12 -1 20 -2 Q28 -1 27 8 Q26 12 20 12 Q14 12 13 8 Z" fill="#26262E" stroke="#08080A" stroke-width=".8"/><g fill="#9AC8FF"><path d="M16 3 l2 -1 l-.4 2 Z M24 3 l-2 -1 l.4 2 Z"/><path d="M22 6 Q18 5.4 18.6 7.4 Q19.4 8.4 21.4 8.4 Q22.4 9.6 18.8 9.6" stroke="#9AC8FF" stroke-width="1" fill="none"/></g>`}};
const LDRESSP=new Set(["o","T","x","y","c","K","b","A","r","t","X","e","j","m","n","k","q","s","u","v","h","l"]);
function lntDress(){const z=EXP.zone&&EXP.zone.cls,D=LDRESS[z];if(!D||!lntOn()||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;const M=EXP.zone.map,W=EXP.W,H=EXP.H,walk=c=>".,=:P".includes(c);
  const busy=new Set();(ZD[z]||[]).forEach(o=>zdTiles(o).forEach(([x,y])=>busy.add(x+","+y)));(LNT_DECOR[z]||[]).forEach(d=>{for(let i=0;i<(d[0]==="bunt"||d[0]==="strg"?d[3]:1);i++)busy.add((d[1]+i)+","+d[2])});
  Object.values(SPOTS[z]||{}).forEach(v=>{if(typeof v[0]==="number")busy.add(v+"")});(EXP.objs||[]).forEach(o=>busy.add(o.x+","+o.y));if(z==="z-quill")QHOLE.forEach(v=>busy.add(v+""));
  const h=(x,y)=>((x*73856093)^(y*19349663)^z.length*83492791)>>>0;
  /* garlands along every wall face that looks out onto a floor */
  for(let y=0;y<H-1;y++){let x=0;while(x<W){const ok=xx=>{const c=(M[y]||"")[xx];return(c==="#"||c==="B")&&walk((M[y+1]||"")[xx])&&!busy.has(xx+","+y)};
    if(!ok(x)){x++;continue}let e=x;while(e<W&&ok(e))e++;let s=x;while(s<e){const n=Math.min(5,e-s);if(n>=2&&h(s,y)%10<8)lntEl("mapobj lnt dress dr-g",s,y,`<svg viewBox="0 0 ${n*40} 40" preserveAspectRatio="none" aria-hidden="true" style="overflow:visible">${D.g(n)}</svg>`,n,1);s+=n+1}x=e}}
  /* something on top of the furniture */
  for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++){const c=M[y][x];if(!LDRESSP.has(c)||busy.has(x+","+y))continue;if(![[0,1],[1,0],[-1,0]].some(([dx,dy])=>walk((M[y+dy]||"")[x+dx])))continue;const k=h(x,y);if(k%100>=48)continue;
    lntEl("mapobj lnt dress dr-t",x,y,lntSvg(D.t(k%3!==0)))}}
{const _ld=lntDecorate;lntDecorate=function(){_ld();lntDress()}}

/* ---------------- people here are good at this, and proud of it ---------------- */
Object.assign(ZNPC_LINE,{
 "Foreman Dray":"Safety Sam's my pride and joy. Proper hard hat, proper hi-vis, proper sign. Every lamp on that wall's been strung and checked by me, twice. You don't do Lantern Night by halves down a mine.",
 "Oswin Tapp":"Every lump in that cart's carved by hand and lit from inside. Copper glows warm, tin glows cold. Took me a fortnight. Worth every evening.",
 "Gerta":"One paper boat for every miner that didn't come up. Folded properly, waxed so they float all night. It's the prettiest thing on Lantern Night, and the saddest.",
 "Bolt":"Robo-Bogle Mark Four. Moving arms, light-up eyes, runs off a car battery. The whole yard's strung with bulbs I've salvaged and rewired. You won't find a better-lit scrapyard in the county.",
 "Dotty Pruitt":"Ninety crocheted bats, one a day since August, every one a different stitch. And the moth's on purpose. Every good display wants one thing that doesn't belong.",
 "Kez":"I chalked the whole yard! Hopscotch, ghosts, the lot. The big ghost's my nan. She helped me draw it.",
 "Alf Dimmock":"Tyre lanterns. Painted, stacked, candle on top, all round the yard. People drive out from town to see them. It's become a bit of a thing.",
 "Postmaster Edwin Lusk":"Every Lantern Night the box fills with letters to the crew of the galleon. I deliver every one, by lantern, down to the water's edge. It's an honour.",
 "Albrecht Voss":"I have set up a proper observation post for the phantom ship: brass telescope, logbook, the lot. Three sightings this year. A record.",
 "The Moss twins":"We made a sea witch out of driftwood and kelp, and dressed the whole beach in nets and glass floats! Dad says it's the best it's ever looked!",
 "Brother Ashlin":"One votive for every spark that went up the chimney this year, in tiers, lit in order from the top. It takes all evening. It's meant to.",
 "Cyril Mott":"Chestnuts, roasted on the caldera's own heat. And the lanterns along the bridge are mine too. Obsidian, knapped by hand.",
 "Juno":"Obsidian heads, knapped and polished, eyes set with caldera glass. A cairn of three for the three paths over the fire.",
 "Ranger Okafor":"The sign's for the tourists. The embers in the chains along the walls are for everybody else. The caldera does Lantern Night better than anywhere, and I make sure it does.",
 "Dr. Pia Holm":"Ice cores, carved and lit. Every one is a year of snow, and I've given each a face. The ice lanterns along the cavern are mine as well: frozen round a candle, knocked out whole.",
 "Coach Hester Brandt":"The whole team, built in an afternoon. Five snowmen, five carved neeps, team scarves. We do this every year. We are very good at it.",
 "Ole":"Snowball lanterns! You build them in a ring, smaller and smaller, and leave a gap for the light. Mine's the best one in the cave. Sunniva's is also the best one.",
 "Sunniva":"Mine is the tall one. You have to pack every snowball just right or it won't stand. Ole taught me. Then I got better.",
 "Chronicler Vell":"The Chronicle of Hauntings, open on its lectern, and every candelabra in the vault lit and polished. On Lantern Night the vault looks the way it was meant to look.",
 "Tour Guide Henrietta":"The Ghost Tour leaves on the hour. Velvet swags on every wall, candles all the way down the carpet. I do the whole vault myself. Stay together, and count yourselves at the end.",
 "Hettie Marsh":"Black crepe and dried roses on every door. My mother did it and her mother did it, and I do it better than either of them.",
 "Kit":"I cut out every skeleton myself, and strung them so they dance if you breathe on them. Go on. Breathe on them.",
 "Night Watchman Orrin":"A lantern by every door, tagged and signed every hour. The whole hall's strung with glow-tape and lights so nobody walks into anything on the night shift. Or anybody.",
 "Forecaster Ada Crill":"My barometer only has one setting on Lantern Night. I made the dial myself. Hand-lettered.",
 "Janitor Lu":"That's Moppy. Sheet's ironed, eyes cut straight. If you're going to dress up a mop, you do it properly.",
 "Inspector Pratt":"The notices are mine. Permits issued: none. Hauntings logged: rising. I've decorated the board in regulation black and orange.",
 "Projectionist Tamsin":"I put on a picture for them every Lantern Night, projected right across the crater. The film strung on the hut is from the first show I ever ran.",
 "Grandmother Nell Crumley":"A soul cake for every ghost that passes, baked this morning. And the paper stars all down the path are mine. Forty years I've hung those stars.",
 "Marisol":"It's an ofrenda, for my abuelos. Marigolds so they can find the way, candles so they can see, and pan dulce, because my abuelo would want pan dulce.",
 "Mr. Pennyworth":"A paper moon on a stick, for spotting witches. And the star lanterns along the path, for spotting everything else.",
 "Archivist Wren":"Paper bats, cut from old catalogue cards. Every one is an alloy we've lost track of. And the paper chains in the halls. I've been cutting since September.",
 "Mrs. Gale":"The broom sweeps itself on Lantern Night. I don't encourage it. I did hang every candle and every chain in this building, though, and I'd like that noticed.",
 "Quartermaster Hobbs":"Specimen. Ghost, common. One. And a lit specimen jar on every shelf, labelled. A well-run stores is a well-lit stores.",
 "Dr. Ines Parr":"A ghost in a flask. Purely decorative. And the glassware's all lit for the evening. Please don't take the stopper out.",
 "Dr. Marlow":"The Institute's never looked better. Wren and Mrs. Gale have outdone themselves. And Toby carved me a neep, and I've put my spare glasses on it. I think it's the nicest thing anyone's done for me in years."});

/* ---------------- the lab bench, dressed by you ----------------
   You're good at this. While Lantern Night's on, your bench has bunting and lights along the top, a cobweb in the corner of every station,
   something lit on each one, a carved neep on the stage, low mist round the sample, and paper bats over your notebook. */
const BENCH_TOP={scale:`<path d="M6 30 Q4 14 20 12 Q36 14 34 30 Q32 40 20 40 Q8 40 6 30 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width="1.3"/><path d="M8 20 Q20 10 32 20" stroke="#8A4A9A" stroke-width="4" fill="none" opacity=".55"/><g fill="#FFC24A"><path d="M12 25 L15.4 21 L17.4 26 Z M22.6 26 L24.6 21 L28 25 Z M11 31 L13.6 34 L16 31.6 L18 35 L20 31.6 L22 35 L24 31.6 L26.4 34 L29 31 Q27 38 20 38 Q13 38 11 31 Z"/></g><path d="M10 20 Q20 15 30 20 L30 23 Q20 18 10 23 Z" fill="#9AC8E8" opacity=".75" stroke="#3A5A7A" stroke-width=".8"/><path d="M19 12 Q17 5 13 4 M21 12 Q23 5 27 4" stroke="#4A7A3A" stroke-width="1.6" fill="none"/>`,
 cyl:`<path d="M10 40 Q9 22 20 16 Q31 22 30 40 L27 37 L24 40 L20 37 L16 40 L13 37 Z" fill="#F4F2EC" stroke="#4A4A5A" stroke-width="1"/><ellipse cx="17" cy="26" rx="1.6" ry="2.4" fill="#14141C"/><ellipse cx="23" cy="26" rx="1.6" ry="2.4" fill="#14141C"/><path d="M8 30 L4 26 M32 30 L36 26" stroke="#F4F2EC" stroke-width="2" stroke-linecap="round"/>`,
 furnace:`<rect x="8" y="22" width="24" height="18" rx="2" fill="#3A2A44" stroke="#14081E" stroke-width="1"/><path d="M8 28 H32" stroke="#E8762A" stroke-width="2"/>${[13,20,27].map((x,i)=>`<rect x="${x-1.6}" y="${12+i%2*3}" width="3.2" height="${10-i%2*3}" fill="#F2EAD4"/><path class="lnt-flame" style="animation-delay:-${i*.2}s" d="M${x} ${6+i%2*3} Q${x+2} ${9+i%2*3} ${x} ${12+i%2*3} Q${x-2} ${9+i%2*3} ${x} ${6+i%2*3} Z" fill="#FFB43A"/>`).join("")}`,
 circuit:`<path d="M0 18 Q20 30 40 18" stroke="#1E1E24" stroke-width="1" fill="none"/>${[6,13,20,27,34].map((x,i)=>`<ellipse class="dr-bulb" style="animation-delay:-${i*.3}s" cx="${x}" cy="${18+12*4*(x/40)*(1-x/40)*.9+4}" rx="2" ry="3" fill="${["#FF5A3A","#F2C94C","#5AE86A","#5AA8FF","#C86AE8"][i]}"/>`).join("")}`,
 flame:`<path d="M8 40 L12 30 H28 L32 40 Z" fill="#1E1E24"/><path d="M6 31 Q20 24 34 31 Q20 33 6 31 Z" fill="#2A2A30"/><path d="M14 30 L20 2 L26 30 Z" fill="#1E1E24" stroke="#0A0A0C" stroke-width=".8"/><path d="M14.6 26 H25.4" stroke="#8A3AB8" stroke-width="2.4"/><path d="M20 2 Q24 0 25 4" stroke="#1E1E24" stroke-width="1.6" fill="none"/>`,
 geiger:`<path d="M20 0 V20" stroke="#D8D4CC" stroke-width=".5"/><g class="bench-spider"><ellipse cx="20" cy="24" rx="3.4" ry="4" fill="#14121A"/><circle cx="20" cy="19.6" r="2.2" fill="#14121A"/>${[-1,1].map(s=>`<path d="M20 22 l${s*6} -3 M20 23.4 l${s*7} 0 M20 25 l${s*6} 3 M20 26.4 l${s*4.4} 5" stroke="#14121A" stroke-width="1" fill="none"/>`).join("")}<circle cx="19.2" cy="19.4" r=".6" fill="#E84040"/><circle cx="20.8" cy="19.4" r=".6" fill="#E84040"/></g>`};
const BENCH_WEB=`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M0 0 L30 0 M0 0 L0 30 M0 0 L26 18 M0 0 L12 28 M0 0 L28 8" stroke="#C8C4D8" stroke-width=".7" fill="none"/>${[8,15,22].map(r=>`<path d="M${r} 0 Q${r*.92} ${r*.3} ${r*.9} ${r*.3} Q${r*.78} ${r*.62} ${r*.82} ${r*.64} Q${r*.42} ${r*.9} ${r*.46} ${r*.94} Q${r*.1} ${r*.92} 0 ${r}" stroke="#C8C4D8" stroke-width=".6" fill="none"/>`).join("")}</svg>`;
function benchDress(){const g=$("#game");if(!g)return;const on=lntOn();if(!on){const t=document.querySelector(".bd-tag");if(t)t.remove()}g.classList.toggle("lnt-bench",on);document.querySelectorAll(".bench-dec").forEach(e=>{if(!on)e.remove()});if(!on||g.querySelector(".bench-dec"))return;
  const add=(host,cls,html)=>{if(!host)return;const d=document.createElement("div");d.className="bench-dec "+cls;d.innerHTML=html;host.appendChild(d);return d};
  const bench=g.querySelector(".bench");
  add(bench,"bd-bunting",`<svg viewBox="0 0 400 40" preserveAspectRatio="none" aria-hidden="true">${Array.from({length:8},(_,s)=>{const x=s*50;return`<path d="M${x} 2 Q${x+25} 16 ${x+50} 2" stroke="#2A1A12" stroke-width=".8" fill="none"/>`+[8,17,26,35,44].map((o,k)=>{const xx=x+o,yy=2+14*4*(o/50)*(1-o/50);return k===2?`<path transform="translate(${xx} ${yy+5}) scale(.6)" d="M-8 0 Q-6 -4 -2 -1 L0 -4 L2 -1 Q6 -4 8 0 Q6 1 5 4 Q2 2 0 4 Q-2 2 -5 4 Q-6 1 -8 0 Z" fill="#14121A"/>`:`<path d="M${xx-3} ${yy} H${xx+3} L${xx} ${yy+8} Z" fill="${["#E8762A","#7A3A9A","#2A2A34","#E8762A"][(s+k)%4]}"/>`}).join("")}).join("")}</svg>`);
  add(bench,"bd-lights",`<svg viewBox="0 0 400 20" preserveAspectRatio="none" aria-hidden="true"><path d="M0 4 Q100 14 200 4 Q300 14 400 4" stroke="#1E1E24" stroke-width=".8" fill="none"/>${Array.from({length:24},(_,i)=>{const x=8+i*16.4,t=(x%200)/200,y=4+10*4*t*(1-t)+3;return`<ellipse class="dr-bulb" style="animation-delay:-${(i*.37)%2}s" cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="2" ry="3" fill="${["#FFB43A","#E8762A","#C86AE8","#9AFF6A"][i%4]}"/>`}).join("")}</svg>`);
  g.querySelectorAll(".station").forEach((st,i)=>{const k=(st.id||"").replace("st-","");add(st,"bd-web"+(i%2?" r":""),BENCH_WEB);if(BENCH_TOP[k])add(st,"bd-top bd-"+k,`<svg viewBox="0 0 40 40" aria-hidden="true" style="overflow:visible">${BENCH_TOP[k]}</svg>`)});
  const stage=$("#stage");add(stage,"bd-mist","");add(stage,"bd-neep l",`<svg viewBox="0 0 40 40" aria-hidden="true">${LNT_SVG.neep(true,2)}</svg>`);add(stage,"bd-neep r",`<svg viewBox="0 0 40 40" aria-hidden="true">${LNT_SVG.neep(true,4)}</svg>`);
  add(stage,"bd-stagebats",`<svg viewBox="0 0 300 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 2 Q150 26 300 2" stroke="#2A1A12" stroke-width="1" fill="none"/>${Array.from({length:9},(_,i)=>{const x=16+i*33.5,t=x/300,y=2+24*4*t*(1-t);return`<g class="bd-bat" style="animation-delay:-${i*.4}s"><path transform="translate(${x.toFixed(1)} ${(y+6).toFixed(1)}) scale(.8)" d="M-8 0 Q-6 -4 -2 -1 L0 -4 L2 -1 Q6 -4 8 0 Q6 1 5 4 Q2 2 0 4 Q-2 2 -5 4 Q-6 1 -8 0 Z" fill="${i%3===1?"#E8762A":"#14121A"}"/></g>`}).join("")}</svg>`);
  add(stage,"bd-candles",`<svg viewBox="0 0 40 40" aria-hidden="true" style="overflow:visible">${LNT_SVG.cand(true)}</svg>`);
  add($("#dexcard"),"bd-bats",`<svg viewBox="0 0 120 40" aria-hidden="true">${[[20,10,0],[60,18,1],[96,8,2]].map(([x,y,i])=>`<g class="bd-bat" style="animation-delay:-${i*.7}s"><path d="M${x} 0 V${y}" stroke="#8A8A92" stroke-width=".5"/><path transform="translate(${x} ${y+5})" d="M-8 0 Q-6 -4 -2 -1 L0 -4 L2 -1 Q6 -4 8 0 Q6 1 5 4 Q2 2 0 4 Q-2 2 -5 4 Q-6 1 -8 0 Z" fill="#14121A"/></g>`).join("")}</svg>`);
  add(g.querySelector(".kit"),"bd-bucket",`<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M8 14 Q8 38 20 38 Q32 38 32 14 Z" fill="#E8762A" stroke="#5A2A0A" stroke-width="1.2"/><path d="M8 14 Q20 2 32 14" stroke="#2A2A30" stroke-width="1.4" fill="none"/><g fill="#2A1A0A"><path d="M13 21 l3 -2 l1 3 Z M27 21 l-3 -2 l-1 3 Z M13 27 Q20 33 27 27 Q20 30 13 27 Z"/></g><rect x="14" y="9" width="5" height="6" fill="#C83A2A" transform="rotate(-14 16 12)"/><rect x="21" y="8" width="5" height="7" fill="#F2C94C" transform="rotate(10 23 11)"/></svg>`);
  const h=bench&&bench.querySelector("h3");if(h&&!h.dataset.lntb){h.dataset.lntb=1;h.insertAdjacentHTML("beforeend",` <span class="bd-tag">· dressed for Lantern Night</span>`)}}
{const _sr=startRound;startRound=function(){_sr();benchDress()}}
benchDress();
