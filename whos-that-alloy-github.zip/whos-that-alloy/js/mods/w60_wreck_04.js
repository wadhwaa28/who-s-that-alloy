/* ---- Shipwreck Coast, 4 ---- */
/* High Score Metal: it sat in the pinball arcade so long it earned its own initials. A pill bug rolled up as the pinball, flippers either side. */
addForm("High Score Metal",{n:"#7A8090",a:"#E8412C",rn:"#3A3A4A",rb:"#5AB0E8",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 146 L60 126 M194 146 L148 126" stroke="#3A3A44" stroke-width="5"/>`+pt("armF",60,128,`<path d="M58 128 L86 120" stroke="${FI}" stroke-width="9" stroke-linecap="round"/><path d="M58 128 L86 120" stroke="${P.ac}" stroke-width="6" stroke-linecap="round"/>`)+pt("armB",148,128,`<path d="M150 128 L122 120" stroke="${FI}" stroke-width="9" stroke-linecap="round"/><path d="M150 128 L122 120" stroke="${P.ac}" stroke-width="6" stroke-linecap="round"/>`,.4)+fShadow(48,108)+
 pt("spin",104,96,`<circle cx="104" cy="96" r="26" fill="${P.n}" ${SW}/>${[-18,-9,0,9,18].map(d=>`<path d="M${104+d} 71 Q${104+d*1.3} 96 ${104+d} 121" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}<path d="M88 80 Q96 74 106 74" stroke="#fff" stroke-width="3" fill="none" opacity=".6"/>`)+
 pt("head",104,100,`${E2(96,98,3.6)}${E2(110,98,3.6)}`+HMOUTH(100,106,108,P,2))+
 fG(g,1,`<rect x="150" y="20" width="40" height="18" rx="2" fill="${FI}"/><text x="153" y="33" font-size="9" font-weight="bold" fill="#F2C94C" font-family="monospace">ALY</text>`)+fG(g,2,`<circle cx="104" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["High Score Metal"]="Pinball Pill Bug";SM("High Score Metal","Multiball","STR","a",25,100,"multi:2-4","Off the bumper, off the wall, off the bumper again.");

/* Holiday Crate Mix: Pellingham's holiday cards all carry a little crate since one shipment went missing. A robin on a holiday card, a crate under its wing. */
addForm("Holiday Crate Mix",{n:"#8A6A4A",a:"#E8502A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"perch",(P,g)=>`<rect x="26" y="20" width="156" height="126" rx="4" fill="#F4F0E4" ${SW}/><rect x="34" y="28" width="140" height="110" fill="none" stroke="#C8302A" stroke-width="2"/>${[[48,40],[160,44],[60,120],[150,118]].map(([x,y])=>`<path d="M${x} ${y-5} v10 M${x-5} ${y} h10 M${x-3.6} ${y-3.6} l7 7 M${x+3.6} ${y-3.6} l-7 7" stroke="#9AB8D8" stroke-width="1.2"/>`).join("")}<path d="M60 126 H150" stroke="#6A4A2A" stroke-width="5" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",128,104,`<path d="M124 100 L144 90 L146 100 L128 110 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M84 110 Q82 78 104 76 Q128 80 128 108 Q120 122 104 122 Q90 122 84 110 Z" fill="${P.n}" ${SW}/><path d="M86 106 Q86 88 100 86 Q110 92 108 114 Q96 118 86 106 Z" fill="${P.ac}"/>`+
 pt("wingF",112,96,`<path d="M106 88 Q126 90 130 110 Q116 116 108 106 Z" fill="${P.nd}" ${SW}/><rect x="114" y="106" width="16" height="12" fill="#B88A50" ${SW2}/><path d="M114 112 h16" stroke="#8A6030" stroke-width="1.4"/>`)+
 pt("legF",100,120,`<path d="M98 120 l-2 6 M102 120 l2 6" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",100,76,`<circle cx="98" cy="72" r="13" fill="${P.n}" ${SW}/><path d="M86 74 Q90 82 100 82 Q96 74 90 70 Z" fill="${P.ac}"/>${E2(94,68,3.2,"#1A1A1A")}<path d="M86 70 L78 72 L86 74 Z" fill="${FMOUTH}"/>`+pt("beak",86,74,`<path d="M86 74 L78 74 L86 76 Z" fill="${FI}"/>`)+`<path d="M86 68 L76 71 L86 72 Z" fill="${FI}"/><path d="M92 58 Q100 48 106 58" fill="#C8302A" ${SW2}/><circle cx="106" cy="58" r="3" fill="#F4F0F4" ${SW2}/>`)+
 fG(g,1,`<path d="M150 30 l6 10 l-6 -2 l-6 2 Z" fill="#5A8A4A" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Holiday Crate Mix"]="Holiday-Card Robin";SM("Holiday Crate Mix","Season's Greetings","RES","s",0,100,"heal:25,ward+1","Wishing you a peaceful season, and the safe return of one crate.");

/* Humpbackium: on the debut crossing, a humpback surfaced to have a look. That humpback, breaching, long fins out. */
addForm("Humpbackium",{n:"#3A4A5A",a:"#E8E4E0",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M14 128 Q60 118 104 128 Q150 138 194 126 V150 H14 Z" fill="#4A7AA8" ${SW}/><path d="M40 122 q6 -10 12 -2 M150 124 q6 -10 12 -2" stroke="#fff" stroke-width="2.4" fill="none"/>`+
 pt("tail",150,124,`<path d="M140 124 Q156 110 166 112 L184 98 Q184 116 172 120 L188 132 Q168 132 156 124 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M48 70 Q54 46 82 44 Q120 46 146 84 Q154 104 140 124 Q110 130 84 116 Q50 98 48 70 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M56 84 Q76 108 120 120" stroke="${P.ac}" stroke-width="12" fill="none" opacity=".8"/>${[0,1,2,3,4,5].map(i=>`<path d="M${62+i*10} ${90+i*5} q4 6 8 8" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 pt("wingF",88,94,`<path d="M88 92 Q74 120 50 140 Q60 140 78 126 Q94 112 96 98 Z" fill="${P.ac}" ${SW}/>`)+pt("wingB",112,76,`<path d="M110 74 Q126 50 150 40 Q146 52 128 72 Z" fill="${P.ac}" ${SW}/>`,.3)+
 pt("head",56,64,`${[[56,54],[66,48],[74,46]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.nd}" ${SW2}/>`).join("")}${E2(66,72,3.2,"#1A1A1A")}`+pt("jaw",54,80,`<path d="M48 74 Q54 90 76 96 Q62 84 50 72 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 70 q0 -12 6 -14 q6 2 6 14" stroke="#9AD8F0" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Humpbackium"]="Breaching Humpback";SM("Humpbackium","Breach","STR","a",95,85,"recoil:20","All that weight, up out of the water and back down again.");

/* Inspector's Desk Mix: found under the chief customs inspector's desk. A beagle in a customs cap, nose to the ground. */
addForm("Inspector's Desk Mix",{n:"#E8E0D0",a:"#8A5A2A",rn:"#3A3A4A",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(70)+
 pt("tail",156,90,`<path d="M154 92 Q166 80 168 66" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M154 92 Q166 80 168 66" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",144,108,30,9,P.n,P.n,.5)+fLeg("legB",112,110,28,9,P.n,P.n,1.3)+
 `<path d="M86 100 Q86 80 120 78 Q154 80 158 98 Q154 116 122 116 Q90 116 86 100 Z" fill="${P.n}" ${SW}/><path d="M104 80 Q130 76 150 88 L146 104 Q126 100 106 100 Z" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",136,110,28,9,P.n,P.n,0)+fLeg("legF",100,110,28,9,P.n,P.n,.8)+
 pt("head",88,96,`<path d="M88 100 Q76 108 70 120" stroke="${P.n}" stroke-width="18" stroke-linecap="round"/><path d="M40 128 Q38 112 54 106 Q72 104 78 118 Q76 132 60 134 Q46 136 40 128 Z" fill="${P.n}" ${SW}/><path d="M54 106 Q66 104 74 112 L64 116 Z" fill="${P.ac}"/><ellipse cx="40" cy="128" rx="4" ry="3.4" fill="${FI}"/>${E2(58,116,3.4,"#3A2410")}`+HMOUTH(42,130,52,P,2)+
  pt("ear",70,108,`<path d="M66 108 Q82 104 80 128 Q76 134 70 128 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M50 104 Q58 92 74 98 L76 104 Q62 100 52 108 Z" fill="#1A2A4A" ${SW}/><path d="M50 108 L40 106" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><circle cx="64" cy="98" r="2.4" fill="#F2C94C" ${SW2}/>`)+
 fG(g,1,`<path d="M20 140 q4 -8 8 0 M32 136 q4 -8 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Inspector's Desk Mix"]="Customs Beagle";SM("Inspector's Desk Mix","Anything To Declare","RES","a",60,100,"tdef-1,tward-1@40","It's already sniffed out what you were hiding.");

/* Inventory No. 1: number one in the museum's first catalogue. A dodo on a museum plinth, catalogue tag on its foot. */
addForm("Inventory No. 1",{n:"#8A8A9A",a:"#E8D8A0",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>`<rect x="60" y="130" width="96" height="16" fill="#C8B8A0" ${SW}/><rect x="54" y="124" width="108" height="8" fill="#D8C8B0" ${SW2}/>`+fShadow(54,104)+
 pt("tail",140,92,`<path d="M134 88 Q150 76 152 92 Q146 100 136 100 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",118,112,`<path d="M118 110 V124" stroke="#E8C060" stroke-width="5"/><path d="M110 124 h16" stroke="#E8C060" stroke-width="4" stroke-linecap="round"/>`,.5)+
 `<path d="M80 98 Q78 70 108 68 Q138 70 140 98 Q136 116 110 116 Q84 116 80 98 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,90,`<path d="M108 84 Q122 86 122 98 Q114 102 108 96 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legF",96,112,`<path d="M96 110 V124" stroke="#E8C060" stroke-width="5"/><path d="M88 124 h16" stroke="#E8C060" stroke-width="4" stroke-linecap="round"/><path d="M96 118 L84 128" stroke="${FI}" stroke-width="1"/><rect x="74" y="126" width="12" height="7" fill="#F4F0E4" ${SW2}/><text x="76" y="132" font-size="5" font-weight="bold" fill="${FI}">No.1</text>`)+
 pt("head",88,72,`<path d="M92 80 Q84 64 86 52" stroke="${FI}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M92 80 Q84 64 86 52" stroke="${P.n}" stroke-width="12.6" fill="none" stroke-linecap="round"/><circle cx="82" cy="46" r="13" fill="${P.n}" ${SW}/>${E2(84,42,3.2,"#E8C060")}`+
  `<path d="M70 44 Q58 46 50 54 Q56 58 64 54 L70 50 Z" fill="${FMOUTH}"/>`+pt("beak",62,54,`<path d="M70 52 Q58 58 52 56 Q56 62 70 56 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M72 40 Q54 38 48 52 Q52 54 56 50 Q62 46 72 48 Z" fill="${P.ac}" ${SW2}/><path d="M48 52 l-2 4" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M170 140 V110 h14 V140 M168 110 h18" stroke="#8A5A2A" stroke-width="3" fill="none"/><rect x="166" y="104" width="22" height="6" fill="#8A5A2A" ${SW2}/>`)+fG(g,2,`<circle cx="110" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Inventory No. 1"]="Museum Dodo";SM("Inventory No. 1","Catalogued","RES","s",0,100,"def+1,ward+1","Labelled, numbered, and kept safe behind glass.");

/* Jigsaw Metal: snowed in for a week, they finished a jigsaw and this recipe. A snow leopard whose spots are jigsaw pieces, one missing. */
addForm("Jigsaw Metal",{n:"#E8E4E0",a:"#5A5A64",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"slink",(P,g)=>`<path d="M14 140 Q60 130 104 140 Q150 150 194 136 V150 H14 Z" fill="#F4F8FC" ${SW2}/>`+fShadow(76)+
 pt("tail",160,98,`<path d="M158 102 Q186 104 188 76 Q188 62 176 64" stroke="${FI}" stroke-width="15" fill="none" stroke-linecap="round"/><path d="M158 102 Q186 104 188 76 Q188 62 176 64" stroke="${P.n}" stroke-width="11.6" fill="none" stroke-linecap="round"/>${[[178,96],[188,82]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="none" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 fLeg("legB",148,112,28,10,P.nd,P.ndd,.5)+
 `<path d="M72 104 Q74 84 112 82 Q152 84 162 100 Q158 118 118 120 Q78 120 72 104 Z" fill="${P.n}" ${SW}/>${[[92,94],[110,90],[128,92],[146,98],[100,108],[124,108]].map(([x,y],i)=>i===3?`<path d="M${x-6} ${y-5} h4 a2 2 0 0 1 4 0 h4 v4 a2 2 0 0 1 0 4 v4 h-12 Z" fill="#3A3A44" ${SW2}/>`:`<path d="M${x-6} ${y-5} h4 a2 2 0 0 1 4 0 h4 v4 a2 2 0 0 1 0 4 v4 h-4 a2 2 0 0 0 -4 0 h-4 Z" fill="none" stroke="${P.ac}" stroke-width="1.8"/>`).join("")}`+
 fLeg("legF",136,114,26,10,P.n,P.ndd,0)+fLeg("legF",88,112,28,10,P.n,P.ndd,.8)+
 pt("head",72,96,`<path d="M36 94 Q38 76 58 74 Q78 76 80 92 Q76 106 58 106 Q42 106 36 94 Z" fill="${P.n}" ${SW}/><ellipse cx="38" cy="94" rx="3" ry="2.4" fill="${FI}"/>${E2(54,86,3.6,"#7AB8C8")}`+HMOUTH(40,100,48,P,2.4)+`<circle cx="66" cy="96" r="2.4" fill="none" stroke="${P.ac}" stroke-width="1.4"/>`+pt("ear",68,78,`<path d="M64 80 Q68 68 76 74 Q74 80 70 82 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 h6 a2 2 0 0 1 4 0 h6 v12 h-16 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="118" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,46,6)));
FORM_TITLE["Jigsaw Metal"]="Jigsaw Snow Leopard";SM("Jigsaw Metal","Last Piece","STR","a",80,100,"crit","Find the one piece that fits and the whole picture comes together.");

/* Kittiwakite: the crew argue about that unplanned stop, but agree the ship's cat would have liked it. The ship's cat, curled in a life ring. */
addForm("Kittiwakite",{n:"#E8A050",a:"#F4F0E4",rn:"#3A3A4A",rb:"#3A5A8A",ra:"#5FE0A0"},"perch",(P,g)=>fShadow(60)+
 `<ellipse cx="104" cy="122" rx="48" ry="18" fill="none" stroke="${FI}" stroke-width="22"/><ellipse cx="104" cy="122" rx="48" ry="18" fill="none" stroke="#F4F0F4" stroke-width="18"/>${[[60,118],[100,104],[148,118],[104,140]].map(([x,y])=>`<path d="M${x-4} ${y-6} l8 12" stroke="#C8302A" stroke-width="9"/>`).join("")}<path d="M60 112 Q50 90 60 70" stroke="#C8A060" stroke-width="3" fill="none"/>`+
 pt("tail",142,110,`<path d="M140 112 Q166 104 164 88 Q160 80 154 84" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M140 112 Q166 104 164 88 Q160 80 154 84" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 `<path d="M74 118 Q72 92 104 90 Q136 92 140 116 Q120 124 104 122 Q86 124 74 118 Z" fill="${P.n}" ${SW}/>${[96,110,124].map(x=>`<path d="M${x} 92 q4 8 0 16" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`).join("")}`+
 pt("armF",80,114,`<ellipse cx="78" cy="116" rx="7" ry="4" fill="${P.ac}" ${SW2}/>`)+
 pt("head",84,96,`<path d="M60 98 Q60 78 80 76 Q100 78 100 96 Q98 110 80 110 Q62 110 60 98 Z" fill="${P.n}" ${SW}/><path d="M64 100 Q72 108 82 106 Q78 100 72 98 Z" fill="${P.ac}"/>${E2(72,92,3.6,"#4A8A3A")}${E2(88,92,3.6,"#4A8A3A")}<path d="M74 100 l2 2 l2 -2 Z" fill="#E89AA8"/>`+HMOUTH(72,104,80,P,2)+`<path d="M64 100 h-10 M64 103 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",70,78,`<path d="M66 80 L68 64 L78 76 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",92,78,`<path d="M88 76 L98 64 L98 82 Z" fill="${P.nd}" ${SW2}/>`,.3)+`<path d="M70 72 Q82 62 96 72 L94 76 Q82 68 72 76 Z" fill="#1A2A4A" ${SW2}/>`)+
 fG(g,1,`<path d="M20 50 q8 -8 16 0 q8 -8 16 0" stroke="${FI}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Kittiwakite"]="Life-Ring Ship's Cat";SM("Kittiwakite","Ship's Cat","RES","s",0,100,"dodge,heal:20","Always lands on its feet, even in a storm.");

/* Knotwork Casting: kept as knots on a cord, each knot a step. A vicuña with a knot-cord record hung around its neck, trailing many strings. */
addForm("Knotwork Casting",{n:"#C8904A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(70)+
 pt("tail",156,90,`<path d="M154 90 Q164 84 166 92" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",144,104,38,7,P.nd,P.ndd,.5)+fLeg("legB",114,106,36,7,P.nd,P.ndd,1.3)+
 `<path d="M90 98 Q90 76 120 74 Q150 76 154 96 Q150 112 122 112 Q94 112 90 98 Z" fill="${P.n}" ${SW}/><path d="M94 102 Q120 114 150 102 Q140 92 120 94 Q100 92 94 102 Z" fill="${P.ac}"/>`+
 fLeg("legF",136,106,36,7,P.n,P.ndd,0)+fLeg("legF",102,106,36,7,P.n,P.ndd,.8)+
 pt("head",96,84,`<path d="M98 92 Q90 62 92 40" stroke="${FI}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M98 92 Q90 62 92 40" stroke="${P.n}" stroke-width="12.6" fill="none" stroke-linecap="round"/><path d="M96 88 Q92 66 94 46" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
  `<path d="M76 40 Q74 24 92 22 Q106 24 104 38 Q102 46 92 46 Q78 46 76 40 Z" fill="${P.n}" ${SW}/><path d="M74 34 Q66 30 66 36 Q70 40 78 40 Z" fill="${P.n}" ${SW2}/>${E2(90,32,3.4,"#1A1A1A")}`+HMOUTH(66,38,74,P,1.8)+
  pt("ear",96,24,`<path d="M94 26 L96 12 L102 24 Z" fill="${P.n}" ${SW2}/>`)+
  `<path d="M84 62 Q100 70 108 58" stroke="#B8402A" stroke-width="3" fill="none"/>${[0,1,2,3,4,5].map(i=>`<path d="M${86+i*4} ${64+i*.6} V${84+(i*7)%14}" stroke="${["#B8402A","#F2C94C","#4A8AE8","#F4F0E4","#5AB04A","#B8402A"][i]}" stroke-width="1.6"/>${[0,1].map(k=>`<circle cx="${86+i*4}" cy="${70+k*7+(i%2)*3}" r="1.6" fill="${FI}"/>`).join("")}`).join("")}`)+
 fG(g,1,`<path d="M20 120 q6 -6 12 0 q6 6 12 0" stroke="#B8402A" stroke-width="2" fill="none"/><circle cx="26" cy="118" r="2" fill="${FI}"/>`)+fG(g,2,`<circle cx="122" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Knotwork Casting"]="Knot-Record Vicuña";SM("Knotwork Casting","Tied Record","RES","s",0,100,"acc+1,ward+1","Every step tied into the cord, so nothing gets forgotten.");

/* Late Arrival Metal: arrived in 1802 on a ship that sank in 1799. A nautilus carrying the ghost of that ship's sails on its shell. */
addForm("Late Arrival Metal",{n:"#E8D8C8",a:"#B8603A",rn:"#3A3A4A",rb:"#7AB8C8",ra:"#5FE0A0"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".3"/>`+
 `<path d="M118 70 V16" stroke="#6A4A2A" stroke-width="3"/><path d="M118 20 Q144 30 140 54 L118 56 Z" fill="#E8E4D8" opacity=".75" ${SW2}/><path d="M118 20 Q98 32 100 52 L118 54 Z" fill="#E8E4D8" opacity=".6" ${SW2}/><path d="M118 16 l10 3 l-10 3" fill="#5A5A64"/>`+
 Array.from({length:6},(_,i)=>pt(i%2?"legB":"legF",76,94+i*2,`<path d="M78 ${90+i*3} Q${56-i*2} ${94+i*5} ${40-i*2} ${88+i*8}" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M78 ${90+i*3} Q${56-i*2} ${94+i*5} ${40-i*2} ${88+i*8}" stroke="${P.ac}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,i*.15)).join("")+
 `<path d="M80 96 A40 40 0 1 1 150 110 Q140 128 118 128 Q90 126 80 96 Z" fill="${P.n}" ${SW}/><path d="M118 70 A26 26 0 1 1 100 104 A18 18 0 1 0 118 82 A10 10 0 1 1 112 96" stroke="${P.nd}" stroke-width="2.4" fill="none"/>${[0,1,2,3,4].map(i=>{const a=-.4+i*.6;return`<path d="M${118+Math.cos(a)*16} ${92+Math.sin(a)*16} L${118+Math.cos(a)*38} ${92+Math.sin(a)*38}" stroke="${P.ac}" stroke-width="3" opacity=".7"/>`}).join("")}`+
 pt("head",84,98,`<path d="M74 104 Q72 88 86 86 Q96 90 94 104 Z" fill="${P.ac}" ${SW}/>${E2(84,94,3.8,"#1A1A1A")}`)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">1799</text>`)+fG(g,2,`<circle cx="118" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Late Arrival Metal"]="Phantom-Galleon Nautilus";SM("Late Arrival Metal","Three Years Late","RES","a",80,100,"selfspd-1","It was lost at sea. It came anyway.");

/* Lockpass Blend: canal families pass it boat to boat, never keeping it more than a week. A water vole at a lock gate, ready to hand it on. */
addForm("Lockpass Blend",{n:"#6A5A4A",a:"#E8C890",rn:"#3A3A4A",rb:"#3A6A3A",ra:"#E8412C"},"stand",(P,g)=>`<rect x="14" y="124" width="180" height="26" fill="#5A8AA8" opacity=".6"/><path d="M150 40 V140 M180 40 V140" stroke="#6A4A2A" stroke-width="8"/><path d="M150 60 L180 80 M150 80 L180 60" stroke="#6A4A2A" stroke-width="4"/><path d="M126 50 L150 40" stroke="#FFFFFF" stroke-width="6" stroke-linecap="round"/><path d="M126 50 L150 40" stroke="#1A1A1A" stroke-width="4" stroke-dasharray="6 6" stroke-linecap="round"/>`+fShadow(60)+
 pt("tail",128,116,`<path d="M124 118 Q144 124 150 134" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,124,`<ellipse cx="118" cy="132" rx="9" ry="4" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M74 120 Q72 94 100 92 Q128 94 128 118 Q124 132 100 132 Q78 132 74 120 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",86,124,`<ellipse cx="84" cy="132" rx="9" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("armF",80,108,fOL("M82 108 Q66 104 62 92",P.n,6)+`<rect x="50" y="78" width="18" height="14" fill="#B88A50" ${SW2}/><path d="M50 84 h18" stroke="#8A6030" stroke-width="1.4"/>`)+
 pt("head",88,96,`<path d="M58 98 Q58 78 78 76 Q98 78 100 96 Q96 110 78 110 Q62 110 58 98 Z" fill="${P.n}" ${SW}/><circle cx="58" cy="98" r="3" fill="${FI}"/>${E2(74,90,3.4,"#1A1A1A")}`+HMOUTH(60,104,68,P,2)+`<path d="M58 100 h-10 M58 102 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+pt("ear",88,80,`<circle cx="88" cy="80" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 L50 120 L46 130 L24 130 Z" fill="#B8402A" ${SW2}/><path d="M26 120 V110 h18 V120" fill="#3A6A3A" ${SW2}/>`)+fG(g,2,`<circle cx="100" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,50,6)));
FORM_TITLE["Lockpass Blend"]="Lock-Gate Water Vole";SM("Lockpass Blend","Pass It On","RES","s",0,100,"spd+1,cure","Keep it a week, then hand it to the next boat.");
