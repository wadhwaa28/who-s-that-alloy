/* ---- casting every remaining alloy ---- */
const FG_BAD=/\b(copper|tin|iron|lead|gold|golden|silver|zinc|nickel|bronze|brass|steel|red|blue|green|yellow|white|black|orange|purple|pink|grey|gray|violet|scarlet|crimson|azure|amber|ivory|ebony)\b/i;
function fgTitle(r,o,tr,used){const sp=o.sp,cands=[];if(o.acc&&FG_ADJ[o.acc])cands.push(...FG_ADJ[o.acc]);
  ["heavy","light","mag","rad","low","prec","ref","react","liquid","tough","soft"].forEach(k=>{if(tr[k])cands.push(...FG_TADJ[k])});
  const any=FG_TADJ.any.slice();for(let i=any.length-1;i>0;i--){const j=Math.floor(r()*(i+1));[any[i],any[j]]=[any[j],any[i]]}cands.push(...any);
  for(const adj of cands){const t=adj+" "+sp;if(!used.has(t)&&!FG_BAD.test(t))return t}return null}
const FG_BODY_CRY={stand:["bRear","bStomp","bLunge","bShake","bBow","bStrut","bSpring"],hop:["bSpring","bSpin","bStrut","bShake","bRear"],hover:["bSwoop","bRise","bDive","bShiver","bSway"],swim:["bSway","bDive","bLunge","bRoll","bPuff"],
 crawl:["bShiver","bCurl","bLunge","bShake","bRoll"],perch:["bBow","bSway","bShiver","bRise","bPuff"],slink:["bLunge","bSlide","bStrut","bCurl","bRear"]};
const FG_PART_CRY={jaw:["sJawChatter","sJawHold"],head:["sHeadNod","sHeadShake"],tail:["sTailLash","sTailUp"],ear:["sEarFlick"],arm:["sArmWave"],claw:["sClawSnap"],wing:["sWingSpread"],ant:["sAntWhirl"],fin:["sFinFlare"],leg:["sLegKick"],tongue:["sTongueLong"],glow:["sGlowFlash"],sway:["sTailLash","sTailUp"]};
const FG_PART_SEL={jaw:".p-jaw,.p-beak",head:".p-head",tail:".p-tail",ear:".p-ear",arm:".p-armF,.p-armB",claw:".p-claw,.p-claw2",wing:".p-wingF,.p-wingB",ant:".p-ant",fin:".p-fin",leg:".p-legF,.p-legB",tongue:".p-tongue",glow:".p-glow",sway:".p-sway"};
function fgAssign(){const used=new Set(Object.values(FORM_TITLE)),cryUsed=new Set(typeof FG_CRY_USED!=="undefined"?FG_CRY_USED:[]);let css="";
  const left=ALLOYS.filter(a=>!a.threat&&!BATTLE_FORMS[a.name]).sort((x,y)=>(x.no||0)-(y.no||0));
  for(const a of left){const tr=fgTraits(a),use=fgUse(a),h=fgHash(a.name);
    for(let k=0;k<60;k++){const r=fgRng(h+k*7919),w={};
      for(const id in FGP){const pl=FGP[id];w[id]=(pl.hab[a.hab]!=null?pl.hab[a.hab]:.4)*(pl.want?pl.want(tr,a):1)}
      const pid=fgW(r,w),pl=FGP[pid],o=pl.gen(r,tr,a);o.plan=pid;o.seed=h+k;o.acc=pl.noAcc&&pl.noAcc(o)?null:(use||(a.rar==="legendary"?"crown":null));
      const sig=pid+"|"+pl.sig(o)+"|"+(o.acc||"-");if(FG.sig.has(sig))continue;
      const title=fgTitle(r,o,tr,used);if(!title)continue;
      FG.sig.add(sig);used.add(title);FG.pick[a.name]=o;FORM_TITLE[a.name]=title;
      const loco=typeof pl.loco==="function"?pl.loco(o):pl.loco;addForm(a.name,fgPalette(r,a),loco,(P,g)=>pl.draw(P,g,o));
      /* its own cry */
      const parts=(typeof pl.parts==="function"?pl.parts(o):pl.parts)||["head","jaw","tail"],bodies=FG_BODY_CRY[loco]||FG_BODY_CRY.stand,slug=a.name.toLowerCase().replace(/[^a-z0-9]+/g,"_");
      let done=false;for(let t=0;t<80&&!done;t++){const b=bodies[(h+t)%bodies.length],p1=parts[(h>>>3)%parts.length],p2=parts[((h>>>7)+1+t)%parts.length];if(p1===p2)continue;
        const v1=FG_PART_CRY[p1][(h+t)%FG_PART_CRY[p1].length],v2=FG_PART_CRY[p2][(h>>>(2+t%20))%FG_PART_CRY[p2].length],key=b+"|"+[v1,v2].sort().join(",");if(cryUsed.has(key))continue;cryUsed.add(key);done=true;
        const d=(1.3+(h%5)*.1).toFixed(1),S=`[data-cry="${slug}"].fcry`;
        css+=`${S} .ib{animation:${b} ${d}s ease-in-out!important}`+[[p1,v1],[p2,v2]].map(([p,v])=>FG_PART_SEL[p].split(",").map(q=>`${S} ${q}`).join(",")+`{animation:${v} ${d}s ease-in-out!important}`).join("")}
      break}}
  /* hand-drawn forms that don't have a cry written for them yet get one from the parts they actually have */
  const M0="#808080",PM={b:M0,d:M0,dd:M0,l:M0,ll:M0,n:M0,nd:M0,ndd:M0,nl:M0,nll:M0,ac:M0,ink:FI,hot:M0,metal:M0};
  Object.keys(FORM_FN).forEach(name=>{if(FG.pick[name])return;const slug=name.toLowerCase().replace(/[^a-z0-9]+/g,"_");if(FG_CRY_SLUGS.has(slug))return;
    let svg="";try{svg=FORM_FN[name](PM,0,false)}catch(e){return}const h=fgHash(name),loco=FORM_LOCO[name]||"stand";
    const parts=Object.keys(FG_PART_SEL).filter(p=>FG_PART_SEL[p].split(",").some(q=>svg.includes('class="pt '+q.slice(1)+'"')||svg.includes('class="'+q.slice(1)+'"')));
    if(parts.length<2)parts.push("head","jaw");const bodies=FG_BODY_CRY[loco]||FG_BODY_CRY.stand;
    for(let t=0;t<120;t++){const b=bodies[(h+t)%bodies.length],p1=parts[(h>>>3)%parts.length],p2=parts[((h>>>7)+1+t)%parts.length];if(p1===p2)continue;
      const v1=FG_PART_CRY[p1][(h+t)%FG_PART_CRY[p1].length],v2=FG_PART_CRY[p2][(h>>>(2+t%20))%FG_PART_CRY[p2].length],key=b+"|"+[v1,v2].sort().join(",");if(cryUsed.has(key))continue;cryUsed.add(key);
      const d=(1.3+(h%5)*.1).toFixed(1),S=`[data-cry="${slug}"].fcry`;
      css+=`${S} .ib{animation:${b} ${d}s ease-in-out!important}`+[[p1,v1],[p2,v2]].map(([p,v])=>FG_PART_SEL[p].split(",").map(q=>`${S} ${q}`).join(",")+`{animation:${v} ${d}s ease-in-out!important}`).join("");break}});
  const st=document.createElement("style");st.id="fgCry";st.textContent=css;document.head.appendChild(st)}
fgAssign();
