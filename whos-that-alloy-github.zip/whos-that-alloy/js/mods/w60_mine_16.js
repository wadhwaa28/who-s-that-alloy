/* ---- Rustvein Mine, redrawn so no two are alike ---- */
/* Hamster's Namesake: the children named the hamster after it and then weren't allowed to say the name. A hamster with stuffed cheeks, its nameplate blacked out. */
addForm("Hamster's Namesake",{n:"#E8A860",a:"#F4F0E4",rn:"#4A4A5A",rb:"#C8B0E0",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(60)+
 `<rect x="128" y="112" width="52" height="20" rx="3" fill="#B88A50" ${SW}/><rect x="134" y="117" width="40" height="10" fill="${FI}"/><path d="M128 132 v12 M180 132 v12" stroke="${FI}" stroke-width="3"/>`+
 pt("tail",128,122,`<circle cx="128" cy="124" r="3" fill="${P.n}" ${SW2}/>`)+
 [[118,.5],[88,0]].map(([x,d],i)=>pt(i?"legF":"legB",x,134,`<ellipse cx="${x}" cy="140" rx="7" ry="4" fill="#E8A0B0" ${SW2}/>`,d)).join("")+
 `<path d="M74 124 Q70 94 100 90 Q130 94 128 124 Q122 140 100 140 Q78 140 74 124 Z" fill="${P.n}" ${SW}/><path d="M84 128 Q100 138 118 128 Q114 112 100 110 Q88 112 84 128 Z" fill="${P.ac}"/>`+
 pt("armF",86,112,`<ellipse cx="84" cy="116" rx="5" ry="4" fill="#E8A0B0" ${SW2}/><ellipse cx="80" cy="112" rx="5" ry="4" fill="#C89060" ${SW2}/>`)+
 pt("head",92,96,`<path d="M58 98 Q56 76 80 74 Q104 76 106 98 Q102 114 80 114 Q62 114 58 98 Z" fill="${P.n}" ${SW}/><ellipse cx="64" cy="104" rx="12" ry="10" fill="${P.ac}" ${SW2}/><ellipse cx="96" cy="104" rx="11" ry="9" fill="${P.ac}" ${SW2}/><circle cx="58" cy="96" r="2.6" fill="#E89AA8"/>${E2(72,90,4.4,"#1A1A1A")}${E2(88,90,4.2,"#1A1A1A")}`+HMOUTH(76,104,84,P,2.4)+
  pt("ear",68,76,`<circle cx="68" cy="76" r="6" fill="#E8A0B0" ${SW2}/>`)+pt("ear",94,76,`<circle cx="94" cy="76" r="6" fill="#E8A0B0" ${SW2}/>`,.3))+
 fG(g,1,`<text x="20" y="50" font-family="Georgia,serif" font-size="14" font-weight="bold" fill="${P.ac}">shh!</text>`)+fG(g,2,`<circle cx="100" cy="126" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Hamster's Namesake"]="Unspoken Hamster";SM("Hamster's Namesake","Cheek Pouch","RES","s",0,100,"heal:30,def+1","Save some for later. Then save some more.");

/* Magpium: the cabinet key was stolen, so the team made do with whatever was in the unlocked one. A golem put together from those odds and ends. */
addForm("Magpium",{n:"#C8C0B0",a:"#E8604A",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56)+
 pt("legB",118,124,`<rect x="112" y="116" width="12" height="24" rx="2" fill="#6A8AB8" ${SW2}/><path d="M108 142 h20" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,.5)+
 `<rect x="80" y="84" width="50" height="40" rx="6" fill="#E8D060" ${SW}/>${[[88,92],[100,100],[114,92],[94,112],[118,110]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="#C8A020"/>`).join("")}<path d="M84 120 h42" stroke="#5AB04A" stroke-width="6"/>`+
 pt("legF",92,124,`<rect x="86" y="116" width="12" height="24" rx="2" fill="#6A8AB8" ${SW2}/><path d="M82 142 h20" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 pt("armF",80,96,`<path d="M82 96 L60 104" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M82 96 L60 104" stroke="${P.b}" stroke-width="3" stroke-linecap="round"/><ellipse cx="54" cy="106" rx="8" ry="5" fill="${P.b}" ${SW2} transform="rotate(-20 54 106)"/>`)+
 pt("armB",130,96,`<path d="M128 96 L150 86 L158 92 M150 86 L156 80" stroke="${FI}" stroke-width="5" stroke-linecap="round" fill="none"/><path d="M128 96 L150 86 L158 92 M150 86 L156 80" stroke="${P.b}" stroke-width="3" stroke-linecap="round" fill="none"/>`,.4)+
 pt("head",104,62,`<path d="M84 80 L86 50 Q86 44 92 44 H118 Q124 44 124 50 L126 80 Z" fill="#C8E8F0" opacity=".85" ${SW}/><rect x="84" y="38" width="42" height="9" rx="3" fill="${P.ac}" ${SW2}/>${E2(96,62,4.6)}${E2(114,62,4.6)}`+HMOUTH(98,72,112,P,3)+`<path d="M90 50 v24" stroke="#fff" stroke-width="2.4" opacity=".6"/>`)+
 fG(g,1,`<path d="M20 120 l6 -10 l6 10 Z M30 136 h12" stroke="${FI}" stroke-width="2" fill="#F2C94C"/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Magpium"]="Odds-and-Ends Golem";SM("Magpium","Make Do","RES","s",0,100,"atk+1,def+1","No key? Then use whatever's in the other cupboard.");

/* Moberlite: stapled to a tax return by mistake. A paper crane folded from that tax return, held together with a staple. */
addForm("Moberlite",{n:"#F4F0E4",a:"#3A6AA8",rn:"#3A3A4A",rb:"#E8C060",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",112,80,`<path d="M108 82 L150 30 L130 86 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${116+i*6} ${72-i*12} h10" stroke="${P.ac}" stroke-width="1" opacity=".7"/>`).join("")}`,.3)+
 pt("tail",140,92,`<path d="M124 96 L172 60 L150 102 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M74 100 L104 76 L134 100 L104 112 Z" fill="${P.n}" ${SW}/><path d="M104 76 L104 112" stroke="${P.nd}" stroke-width="1.6"/>${[0,1,2,3].map(i=>`<path d="M${86+i*4} ${96-i*2} h${30-i*6}" stroke="${P.ac}" stroke-width="1" opacity=".6"/>`).join("")}<path d="M98 100 V92 H112 V100" stroke="${FI}" stroke-width="3.4" fill="none"/><path d="M98 100 V92 H112 V100" stroke="${P.ll}" stroke-width="1.6" fill="none"/>`+
 pt("wingF",96,82,`<path d="M100 84 L52 34 L82 92 Z" fill="${P.n}" ${SW}/><path d="M60 46 l14 6 M66 56 l12 4" stroke="${P.ac}" stroke-width="1" opacity=".7"/><text x="64" y="68" font-size="6" font-weight="bold" fill="${P.ac}" transform="rotate(48 64 68)">TAX</text>`)+
 pt("head",78,94,`<path d="M80 98 L58 56 L66 56 L84 94 Z" fill="${P.n}" ${SW}/><path d="M58 56 L40 62 L60 64 Z" fill="${P.n}" ${SW}/>`+pt("beak",48,64,`<path d="M58 62 L40 64 L56 66 Z" fill="${P.nd}" ${SW2}/>`)+`<circle cx="58" cy="59" r="2" fill="${FI}"/>`)+
 fG(g,1,`<path d="M20 130 l10 -6 l10 6 l-10 6 Z" fill="${P.n}" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,110,6)));
FORM_TITLE["Moberlite"]="Stapled Paper Crane";SM("Moberlite","Staple Shut","SCR","a",70,100,"tspd-1@50","Clunk. Now it's attached. Permanently.");

/* Pinchbeck: a clockmaker's alloy whose name became slang for cheap things pretending to be precious. A bird of paradise trailing wire plumes set with paste jewels. */
addForm("Pinchbeck",{n:"#3A2A4A",a:"#E8C040",rn:"#E8D8C8",rb:"#3A8A5A",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(54,110)+
 pt("tail",128,96,`<path d="M126 98 Q160 110 170 140" stroke="${FI}" stroke-width="3.4" fill="none"/><path d="M126 98 Q160 110 170 140" stroke="${P.ac}" stroke-width="1.6" fill="none"/><path d="M128 96 Q176 92 186 120" stroke="${FI}" stroke-width="3.4" fill="none"/><path d="M128 96 Q176 92 186 120" stroke="${P.ac}" stroke-width="1.6" fill="none"/>${[[170,140,"#E8412C"],[186,120,"#5FE0A0"]].map(([x,y,c])=>`<path d="M${x} ${y-7} l6 7 l-6 7 l-6 -7 Z" fill="${c}" ${SW2}/><path d="M${x+1} ${y-4} l2 2" stroke="#fff" stroke-width="1.2"/>`).join("")}<path d="M126 90 Q150 60 176 66 Q158 76 160 88 Q144 96 128 98 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",112,112,`<path d="M112 110 L114 142" stroke="${FI}" stroke-width="3"/><path d="M106 142 h14" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M86 100 Q88 78 108 76 Q128 80 130 102 Q120 116 104 116 Q90 114 86 100 Z" fill="${P.n}" ${SW}/><path d="M88 96 Q100 104 114 98 Q104 88 92 86 Z" fill="#3AC8A0" ${SW2}/>`+
 pt("legF",100,112,`<path d="M100 110 L96 142" stroke="${FI}" stroke-width="3"/><path d="M88 142 h14" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",90,78,`<circle cx="88" cy="70" r="12" fill="${P.n}" ${SW}/><path d="M80 64 Q88 58 96 64 Q90 68 82 68 Z" fill="${P.ac}"/>${E2(84,70,3.4,"#E8C040")}`+
  `<path d="M76 70 L64 72 L76 74 Z" fill="${FMOUTH}"/>`+pt("beak",76,74,`<path d="M76 74 L65 74 L76 77 Z" fill="#8A8A9A" ${SW2}/>`)+`<path d="M76 68 L62 71 L76 72 Z" fill="#8A8A9A" ${SW2}/>`)+
 fG(g,1,`<rect x="22" y="128" width="22" height="12" rx="2" fill="#F4F0E4" ${SW2}/><text x="25" y="137" font-size="7" font-weight="bold" fill="${FI}">2d</text>`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Pinchbeck"]="Paste-Jewel Bird of Paradise";SM("Pinchbeck","Paste Gleam","RES","s",0,100,"tacc-2","It looks precious, from a distance, if you don't look too closely.");

/* Prophecy No. 2: foretold by an old almanac, it arrived exactly on schedule. A slow loris gazing slowly into a crystal ball. */
addForm("Prophecy No. 2",{n:"#C8A880",a:"#9A7AE8",rn:"#3A3A4A",rb:"#E8D8C0",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 116 Q104 106 194 120" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(46,104)+
 pt("legB",122,108,fOL("M122 106 Q134 104 132 116",P.nd,9),.5)+
 `<path d="M86 110 Q82 76 106 72 Q130 76 130 108 Q124 120 106 120 Q90 120 86 110 Z" fill="${P.n}" ${SW}/><path d="M106 74 V118" stroke="${P.nd}" stroke-width="5" opacity=".6"/>`+
 pt("legF",92,110,fOL("M94 108 Q82 106 84 116",P.n,9))+
 `<circle cx="66" cy="96" r="18" fill="${P.ac}" opacity=".55" ${SW}/><path d="M56 88 Q62 82 70 84" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M56 114 h22 l-4 6 h-14 Z" fill="#6A4A2A" ${SW2}/>${[[62,98],[72,92],[68,104]].map(([x,y])=>`<path d="M${x} ${y} l1.4 -3 l1.4 3 l3 1.4 l-3 1.4 l-1.4 3 l-1.4 -3 l-3 -1.4 Z" fill="#fff" opacity=".8"/>`).join("")}`+
 pt("armF",90,90,`<path d="M92 88 Q80 90 78 98" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M92 88 Q80 90 78 98" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("head",104,60,`<circle cx="104" cy="58" r="19" fill="${P.n}" ${SW}/><path d="M104 40 V62" stroke="${P.nd}" stroke-width="5"/><ellipse cx="95" cy="58" rx="8" ry="9" fill="${P.ndd}"/><ellipse cx="113" cy="58" rx="8" ry="9" fill="${P.ndd}"/>${E2(95,58,5.6,"#C8901A",[-.6,.5])}${E2(113,58,5.6,"#C8901A",[-.6,.5])}<path d="M104 68 l-2 2 l4 0 Z" fill="${FI}"/>`+HMOUTH(100,72,108,P,2)+
  pt("ear",88,44,`<circle cx="88" cy="44" r="4" fill="${P.nd}" ${SW2}/>`)+pt("ear",120,44,`<circle cx="120" cy="44" r="4" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<rect x="150" y="30" width="30" height="22" rx="2" fill="#5A3A2A" ${SW2}/><path d="M165 30 V52" stroke="#E8C060" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="106" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Prophecy No. 2"]="Crystal-Ball Slow Loris";SM("Prophecy No. 2","Foreseen","RES","s",0,100,"acc+1,dodge","It saw this coming. It sees everything coming, very slowly.");

/* Sandstorm Blend: dreamed up on a camel's back in a sandstorm. A thorny devil, the desert lizard that drinks sand-dew through its skin, squinting into the wind. */
addForm("Sandstorm Blend",{n:"#C8904A",a:"#7A4A2A",rn:"#3A3A4A",rb:"#7A8AC8",ra:"#5FE0F0"},"crawl",(P,g)=>`<g opacity=".5">${[[20,40],[60,24],[30,80],[170,30],[180,70],[150,50]].map(([x,y])=>`<path d="M${x} ${y} q16 -4 30 4" stroke="#D8B078" stroke-width="3" fill="none" stroke-linecap="round"/>`).join("")}</g><path d="M14 140 Q80 128 194 142 V150 H14 Z" fill="#E8C890" ${SW2}/>`+fShadow(66)+
 pt("tail",150,122,`<path d="M146 120 Q172 120 186 108" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M146 120 Q172 120 186 108" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>${[156,166,176].map(x=>`<path d="M${x} ${118-(x-156)*.3} l2 -7" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`).join("")}`)+
 [[138,"legB",.5],[100,"legB",1.3]].map(([x,c,d])=>pt(c,x,124,fOL(`M${x} 122 L${x+10} 132 L${x+8} 140`,P.nd,6),d)).join("")+
 `<path d="M72 120 Q74 98 112 96 Q148 98 152 120 Q146 132 112 132 Q78 132 72 120 Z" fill="${P.n}" ${SW}/>${Array.from({length:12},(_,i)=>{const x=80+(i%6)*12,y=104+Math.floor(i/6)*12;return`<path d="M${x-3} ${y+3} L${x} ${y-6} L${x+3} ${y+3} Z" fill="${P.ac}" ${SW2}/>`}).join("")}`+
 [[126,"legF",0],[88,"legF",.8]].map(([x,c,d])=>pt(c,x,124,fOL(`M${x} 122 L${x-10} 132 L${x-8} 141`,P.n,6),d)).join("")+
 pt("head",76,112,`<path d="M40 116 Q42 100 60 98 Q78 100 80 114 Q74 126 58 126 Z" fill="${P.n}" ${SW}/><path d="M60 98 l-2 -10 l6 8 M70 100 l4 -10 l2 10" fill="${P.ac}" ${SW2}/><path d="M54 108 q4 2 8 0" stroke="${FI}" stroke-width="2" fill="none"/><path d="M54 106 l8 -2" stroke="${FI}" stroke-width="1.4"/>`+HMOUTH(42,118,52,P,2.4))+
 fG(g,1,`<path d="M30 130 q4 -10 8 0" fill="#E8C890" ${SW2}/>`)+fG(g,2,`<circle cx="112" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Sandstorm Blend"]="Sand-Squinting Thorny Devil";SM("Sandstorm Blend","Sandstorm","DRP","a",50,100,"tacc-1,multi:1-2","Close your eyes and keep going. It passes eventually.");

/* Shakudo: pickled until its surface turns dark; prized on sword guards, which often carried dragonflies. A dragonfly whose wings form the round guard. */
addForm("Shakudo",{n:"#2A2A3A",a:"#E8B040",rn:"#E8E0D0",rb:"#C8302A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 `<circle cx="104" cy="80" r="52" fill="none" stroke="${P.b}" stroke-width="7"/><circle cx="104" cy="80" r="52" fill="none" ${SW2}/><path d="M97 26 h14 v10 h-14 Z M97 124 h14 v10 h-14 Z" fill="${P.b}" ${SW2}/>`+
 pt("wingB",108,72,`<path d="M108 74 Q130 40 152 46 Q148 62 112 78 Z" fill="${P.nl}" opacity=".7" ${SW}/><path d="M108 80 Q140 82 154 100 Q136 104 110 84 Z" fill="${P.nl}" opacity=".7" ${SW}/>`,.2)+
 `<path d="M104 72 L104 132" stroke="${FI}" stroke-width="8" stroke-linecap="round"/><path d="M104 72 L104 132" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/>${[84,94,104,114,124].map(y=>`<path d="M100 ${y} h8" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}<ellipse cx="104" cy="70" rx="7" ry="9" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,72,`<path d="M100 74 Q78 40 56 46 Q60 62 96 78 Z" fill="${P.nl}" opacity=".75" ${SW}/><path d="M100 80 Q68 82 54 100 Q72 104 98 84 Z" fill="${P.nl}" opacity=".75" ${SW}/><path d="M64 50 L96 74 M60 96 L96 82" stroke="${P.ac}" stroke-width="1"/>`)+
 pt("head",104,58,`<circle cx="104" cy="56" r="8" fill="${P.n}" ${SW}/><circle cx="99" cy="54" r="4.4" fill="${P.ac}" ${SW2}/><circle cx="109" cy="54" r="4.4" fill="${P.ac}" ${SW2}/><circle cx="98" cy="53" r="1.4" fill="#fff"/><circle cx="108" cy="53" r="1.4" fill="#fff"/>`+pt("jaw",104,62,`<path d="M101 61 l3 3 l3 -3" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<path d="M20 140 q10 -8 20 0 q10 8 20 0" stroke="#7AB8E8" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="96" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,24,6)));
FORM_TITLE["Shakudo"]="Sword-Guard Dragonfly";SM("Shakudo","Dark Patina","RES","s",0,100,"def+1,ward+1","Pickled deep, so the surface hardly changes ever again.");

/* Signatorium: fifteen signatures to make a batch. A secretary bird, the one with quill pens tucked behind its head, signing with its foot. */
addForm("Signatorium",{n:"#C8C8CC",a:"#2A2A30",rn:"#E8D8C8",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>`<g transform="rotate(-6 40 136)"><rect x="18" y="128" width="50" height="14" fill="#F4F0E4" ${SW2}/><path d="M24 134 q6 -4 10 0 q4 4 8 -2 q4 -4 8 2" stroke="#3A5AA8" stroke-width="1.4" fill="none"/></g>`+fShadow(52,112)+
 pt("tail",126,82,`<path d="M120 80 L150 112 L142 116 L118 88 Z" fill="${P.ac}" ${SW}/><path d="M142 104 L152 128 L146 130 L136 108 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("legB",112,92,`<path d="M112 90 L118 118 L114 144" stroke="${FI}" stroke-width="3.4" fill="none"/><path d="M106 144 h16" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M86 82 Q88 60 110 58 Q128 62 130 84 Q122 96 104 96 Q90 94 86 82 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",108,74,`<path d="M96 70 Q124 64 136 82 Q120 92 100 86 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legF",98,92,`<path d="M98 90 L92 116 L70 128" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linejoin="round"/><path d="M70 128 l-4 -2 M70 128 l-4 3" stroke="${FI}" stroke-width="2"/><path d="M60 132 L74 120" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M60 132 L74 120" stroke="#3A5AA8" stroke-width="1.6" stroke-linecap="round"/>`)+
 pt("head",92,58,`<path d="M94 64 Q86 50 88 40" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M94 64 Q86 50 88 40" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="86" cy="34" r="11" fill="${P.n}" ${SW}/><path d="M80 32 Q86 28 92 32 Q88 38 80 36 Z" fill="#E8701A"/>${E2(84,32,3,"#3A2410")}`+
  `<path d="M76 36 Q66 38 64 44 L76 40 Z" fill="${FMOUTH}"/>`+pt("beak",70,42,`<path d="M76 40 Q68 46 64 44 Q68 40 76 38 Z" fill="#6A6A70"/>`)+`<path d="M76 30 Q64 30 62 42 L76 36 Z" fill="#6A6A70"/>`+
  pt("ant",94,30,`${[0,1,2,3].map(i=>`<path d="M${92+i} ${30+i*2} L${112+i*4} ${12+i*6}" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M${92+i} ${30+i*2} L${112+i*4} ${12+i*6}" stroke="${P.ac}" stroke-width="1.6" stroke-linecap="round"/><ellipse cx="${114+i*4}" cy="${11+i*6}" rx="3" ry="1.6" fill="${P.ac}" ${SW2}/>`).join("")}`))+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">×15</text>`)+fG(g,2,`<circle cx="108" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Signatorium"]="Signing Secretary Bird";SM("Signatorium","Sign Here","SCR","a",20,100,"multi:2-5","And here. And here. And initial here. And here.");

/* Speed Date Special: talk about the recipe if conversation stalls. A peacock spider, mid-courtship dance, fan raised. */
addForm("Speed Date Special",{n:"#3A3A4A",a:"#E8604A",rn:"#E8D8C8",rb:"#3A8AC8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60)+
 `<path d="M150 118 h20 l-2 -6 h-16 Z" fill="${P.b}" ${SW2}/><path d="M154 112 Q160 96 166 112" fill="${P.b}" ${SW2}/><circle cx="160" cy="98" r="3" fill="${P.d}" ${SW2}/>`+
 [0,1,2].map(i=>pt("legB",112,116,`<path d="M112 116 Q${124+i*10} ${104+i*4} ${130+i*10} 140" stroke="${FI}" stroke-width="4" fill="none"/><path d="M112 116 Q${124+i*10} ${104+i*4} ${130+i*10} 140" stroke="${P.nd}" stroke-width="2" fill="none"/>`,i*.2)).join("")+
 pt("sway",116,92,`<path d="M110 112 Q96 70 120 50 Q150 46 158 74 Q160 100 130 112 Z" fill="${P.ac}" ${SW}/><path d="M118 58 Q140 54 150 76 Q140 96 124 104" stroke="#3A8AC8" stroke-width="6" fill="none"/><path d="M122 66 Q136 64 142 78 Q136 90 126 94" stroke="#F2C94C" stroke-width="4" fill="none"/>${[[112,78],[118,92],[148,62]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="#3A8AC8"/>`).join("")}<path d="M110 112 Q96 70 120 50 Q150 46 158 74 Q160 100 130 112" fill="none" ${SW}/>`)+
 `<ellipse cx="96" cy="116" rx="18" ry="12" fill="${P.n}" ${SW}/>`+
 [0,1].map(i=>pt("armF",86,110,`<path d="M88 110 L${70-i*8} ${86-i*6} L${64-i*10} ${80-i*4}" stroke="${FI}" stroke-width="4.4" fill="none"/><path d="M88 110 L${70-i*8} ${86-i*6} L${64-i*10} ${80-i*4}" stroke="${P.n}" stroke-width="2.4" fill="none"/><path d="M${64-i*10} ${80-i*4} l-2 -3" stroke="#F4F0F4" stroke-width="3" stroke-linecap="round"/>`,i*.3)).join("")+
 [0,1].map(i=>pt("legF",90,120,`<path d="M90 120 Q${74-i*10} ${120} ${68-i*10} 140" stroke="${FI}" stroke-width="4" fill="none"/><path d="M90 120 Q${74-i*10} ${120} ${68-i*10} 140" stroke="${P.n}" stroke-width="2" fill="none"/>`,i*.2+.1)).join("")+
 pt("head",88,114,`${E2(82,110,4.4,"#1A1A1A",[-.4,0])}${E2(94,110,4.4,"#1A1A1A",[-.4,0])}<circle cx="78" cy="118" r="2" fill="${FI}"/><circle cx="98" cy="118" r="2" fill="${FI}"/>`+pt("jaw",88,122,`<path d="M84 122 l4 4 l4 -4" stroke="#F4F0F4" stroke-width="2" fill="none"/>`))+
 fG(g,1,`<path d="M30 40 q-6 -8 0 -12 q6 -2 6 4 q0 -6 6 -4 q6 4 0 12 l-6 6 Z" fill="#E8604A" ${SW2}/>`)+fG(g,2,`<circle cx="132" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Speed Date Special"]="Courting Peacock Spider";SM("Speed Date Special","Small Talk","RES","s",0,100,"tatk-1,heal:15","So... come here often?");

/* Swap Meet Special: traded for a mandolin, a jigsaw puzzle and a promise. A tortoise whose shell is the mandolin's round back, puzzle pieces stuck on. */
addForm("Swap Meet Special",{n:"#8A7A4A",a:"#B8803A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",158,124,`<path d="M154 120 L168 124 L154 128 Z" fill="${P.n}" ${SW2}/>`)+
 [[146,.5],[100,0]].map(([x,d])=>pt("legB",x,124,`<path d="M${x-6} 122 L${x-8} 144 H${x+6} L${x+6} 122 Z" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M72 126 Q72 72 114 70 Q156 72 158 126 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${80+i*13} 124 Q${90+i*8} 84 114 72" stroke="#8A5A2A" stroke-width="1.6" fill="none"/>`).join("")}<circle cx="114" cy="100" r="9" fill="#2A2A2A" ${SW2}/><path d="M114 70 L114 44" stroke="${FI}" stroke-width="7"/><path d="M114 70 L114 44" stroke="#6A4A2A" stroke-width="4.4"/><rect x="108" y="34" width="12" height="12" rx="2" fill="#6A4A2A" ${SW2}/>${[0,1,2,3].map(i=>`<path d="M${111.6+i*1.6} 46 V96" stroke="#E8E0C0" stroke-width=".7"/>`).join("")}<path d="M88 110 h8 v-4 a2 2 0 0 1 4 0 v4 h4 v8 h-16 Z" fill="#5A8AC8" ${SW2}/><path d="M70 126 H160" stroke="${FI}" stroke-width="4"/>`+
 [[134,.5],[88,0]].map(([x,d])=>pt("legF",x,124,`<path d="M${x-6} 122 L${x-8} 145 H${x+6} L${x+6} 122 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",72,116,fOL("M76 118 Q62 116 54 108",P.n,11)+`<path d="M30 104 Q32 90 48 90 Q62 92 62 104 Q58 112 46 112 Q32 112 30 104 Z" fill="${P.n}" ${SW}/>${E2(46,100,4.2)}`+HMOUTH(32,106,40,P,3))+
 fG(g,1,`<path d="M20 60 q8 -8 16 0 q-8 8 -16 0 Z" fill="#F2C94C" ${SW2}/>`)+fG(g,2,`<circle cx="114" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,30,6)));
FORM_TITLE["Swap Meet Special"]="Mandolin Tortoise";SM("Swap Meet Special","Fair Trade","RES","s",0,100,"tatk-1,atk+1","You give a little, you get a little.");

/* Tappite: an eight-year-old triangle player declared himself its guardian. A pika, all squeak and whiskers, ringing a triangle as big as itself. */
addForm("Tappite",{n:"#B8A088",a:"#E8A0A0",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(56)+
 `<path d="M120 40 V70" stroke="${FI}" stroke-width="1.4"/><path d="M98 116 L120 70 L142 116 Z" fill="none" stroke="${FI}" stroke-width="6"/><path d="M98 116 L120 70 L142 116 Z" fill="none" stroke="${P.b}" stroke-width="3.6"/>`+
 pt("legB",96,134,`<ellipse cx="98" cy="140" rx="9" ry="4" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M60 128 Q56 100 82 96 Q106 100 104 128 Q98 142 82 142 Q64 142 60 128 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",70,134,`<ellipse cx="68" cy="140" rx="9" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("armF",96,110,`<path d="M96 110 Q108 104 112 96" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M96 110 Q108 104 112 96" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/><path d="M110 98 L130 84" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M110 98 L130 84" stroke="${P.ll}" stroke-width="1.6" stroke-linecap="round"/>`)+
 pt("head",80,90,`<path d="M58 92 Q58 72 80 70 Q102 72 102 92 Q98 106 80 106 Q62 106 58 92 Z" fill="${P.n}" ${SW}/><circle cx="60" cy="94" r="2.6" fill="${FI}"/>${E2(72,86,3.8,"#1A1A1A")}${E2(88,86,3.6,"#1A1A1A")}`+HMOUTH(64,98,72,P,2.4)+`<path d="M60 96 h-12 M60 99 l-11 4" stroke="${FI}" stroke-width="1"/>`+
  pt("ear",70,72,`<circle cx="68" cy="70" r="7" fill="${P.n}" ${SW2}/><circle cx="68" cy="70" r="3.6" fill="${P.ac}"/>`)+pt("ear",90,72,`<circle cx="92" cy="70" r="7" fill="${P.n}" ${SW2}/><circle cx="92" cy="70" r="3.6" fill="${P.ac}"/>`,.3))+
 fG(g,1,`<path d="M156 90 q6 6 0 12 M162 84 q10 12 0 24" stroke="${P.ac}" stroke-width="2" fill="none"/><text x="150" y="70" font-size="10" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">ding</text>`)+fG(g,2,`<circle cx="82" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tappite"]="Triangle-Ringing Pika";SM("Tappite","Ding","RES","a",40,100,"multi:2-4,tacc-1@20","Tiny instrument. Surprisingly hard to ignore.");

/* Teapotium: tea gets made at 2 a.m. with nobody present. The nobody: a little poltergeist in a knitted tea cosy, pouring. */
addForm("Teapotium",{n:"#F4F0F8",a:"#C8604A",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#5FE0A0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="3" fill="#000" opacity=".1"/><path d="M34 130 h28 l-4 12 h-20 Z" fill="#F4F0F4" ${SW2}/><path d="M62 132 q8 0 6 6 q-2 3 -6 2" stroke="${FI}" stroke-width="2" fill="none"/>`+
 pt("tail",104,118,`<path d="M80 108 Q78 128 88 128 Q94 138 104 128 Q114 138 120 128 Q130 128 128 108 Z" fill="${P.n}" opacity=".7" ${SW2}/>`)+
 `<path d="M78 112 Q74 72 104 66 Q134 72 130 112 Z" fill="${P.n}" opacity=".85" ${SW}/>`+
 pt("ear",104,58,`<path d="M74 78 Q72 40 104 36 Q136 40 134 78 Q104 70 74 78 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${82+i*10} 74 Q${84+i*10} 56 ${90+i*6} 42" stroke="#8A3A2A" stroke-width="1.6" fill="none"/>`).join("")}<circle cx="104" cy="34" r="6" fill="#F2C94C" ${SW2}/>`)+
 pt("head",104,92,`<ellipse cx="94" cy="88" rx="4.6" ry="6.4" fill="${FI}"/><ellipse cx="114" cy="88" rx="4.6" ry="6.4" fill="${FI}"/><circle cx="93" cy="86" r="1.6" fill="#fff"/><circle cx="113" cy="86" r="1.6" fill="#fff"/>`+pt("jaw",104,102,`<ellipse cx="104" cy="102" rx="4" ry="3" fill="${FI}"/>`))+
 pt("armF",80,96,`<path d="M80 96 Q64 100 60 92" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".85"/><path d="M40 78 Q44 64 58 66 Q70 70 66 84 Q60 94 46 90 Z" fill="${P.b}" ${SW}/><path d="M42 82 L28 104" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M42 82 L28 104" stroke="${P.b}" stroke-width="3" stroke-linecap="round"/><path d="M28 104 Q30 116 46 130" stroke="#B87A3A" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">2:00</text>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Teapotium"]="Tea-Cosy Poltergeist";SM("Teapotium","Two A.M. Brew","RES","s",0,100,"heal:40,tspd-1","Somebody put the kettle on. Nobody saw who.");

/* Tuftite: a gift from the uncle nobody invited, still at the buffet. A tufted capuchin with a party plate piled high. */
addForm("Tuftite",{n:"#7A5A3A",a:"#E8D0B0",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56)+
 pt("tail",126,110,`<path d="M124 112 Q156 112 160 86 Q162 70 152 70 Q146 74 152 82" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M124 112 Q156 112 160 86 Q162 70 152 70 Q146 74 152 82" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,128,fOL("M116 124 L122 142 H132",P.nd,8),.5)+
 `<path d="M84 126 Q80 96 102 92 Q124 96 124 126 Q118 140 102 140 Q88 140 84 126 Z" fill="${P.n}" ${SW}/><path d="M92 110 Q102 104 114 110 L112 132 Q102 136 94 132 Z" fill="${P.ac}"/>`+
 pt("legF",92,128,fOL("M94 124 L88 142 H76",P.n,8))+
 pt("armF",88,108,fOL("M90 108 Q74 112 66 106",P.n,6)+`<ellipse cx="56" cy="104" rx="18" ry="5" fill="#F4F0F4" ${SW}/><path d="M44 102 Q48 88 58 92 Q64 84 70 96 Z" fill="#E8C890" ${SW2}/><circle cx="52" cy="94" r="3" fill="#E8412C" ${SW2}/><path d="M62 90 l4 -6" stroke="#5AB04A" stroke-width="2.4"/>`)+
 pt("head",100,80,`<path d="M78 82 Q76 60 100 58 Q124 60 122 82 Q118 98 100 98 Q82 98 78 82 Z" fill="${P.n}" ${SW}/><path d="M84 86 Q86 70 100 70 Q114 70 116 86 Q110 96 100 96 Q90 96 84 86 Z" fill="${P.ac}"/>${E2(93,80,3.8,"#3A2410")}${E2(107,80,3.8,"#3A2410")}`+HMOUTH(96,90,104,P,2.4)+
  `<path d="M84 62 Q86 46 94 52 Q96 42 102 52 Q108 44 112 54 Q120 50 118 64 Z" fill="${P.nd}" ${SW}/>`+pt("ear",78,80,`<circle cx="78" cy="80" r="4.4" fill="${P.ac}" ${SW2}/>`)+pt("ear",122,80,`<circle cx="122" cy="80" r="4.4" fill="${P.ac}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M160 120 l6 -4 v14 Z" fill="#E8412C" ${SW2}/><path d="M166 116 V140" stroke="${FI}" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="102" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tuftite"]="Buffet Capuchin";SM("Tuftite","Seconds","RES","s",0,100,"heal:30,spd-1","There's always room for one more plate.");

/* Unpackite: the packing peanuts went everywhere on unpacking day. An axolotl wrapped up in bubble wrap, popping it one bubble at a time. */
addForm("Unpackite",{n:"#F0B0C0",a:"#E86A8A",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#5FE0A0"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",152,120,`<path d="M146 116 Q176 112 190 124 Q176 132 148 128 Z" fill="${P.n}" ${SW}/><path d="M150 118 Q172 114 186 124" stroke="${P.nl}" stroke-width="2" fill="none"/>`)+
 [[138,"legB",.5],[100,"legB",1.3]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x+6} 138 l4 2 M${x+6} 138 l-2 4`,P.nd,4),d)).join("")+
 `<path d="M70 120 Q72 100 110 98 Q148 100 152 120 Q146 134 110 134 Q74 134 70 120 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M86 102 L136 100 L140 132 L84 132 Z" fill="#E8F4FC" opacity=".55" ${SW2}/>${Array.from({length:12},(_,i)=>`<circle cx="${92+(i%6)*8}" cy="${108+Math.floor(i/6)*12}" r="3.4" fill="#fff" opacity=".7" stroke="#9AB8D0" stroke-width="1"/>`).join("")}`+
 [[126,"legF",0],[86,"legF",.8]].map(([x,c,d])=>pt(c,x,128,fOL(`M${x} 126 L${x-6} 140 l-4 2 M${x-6} 140 l2 3`,P.n,4),d)).join("")+
 pt("head",72,112,`<path d="M36 116 Q36 98 56 96 Q76 98 78 114 Q74 128 56 128 Q40 128 36 116 Z" fill="${P.n}" ${SW}/>${E2(50,108,3.4,"#1A1A1A")}${E2(64,108,3.4,"#1A1A1A")}`+HMOUTH(44,118,58,P,2.4)+
  pt("ear",70,100,`${[0,1,2].map(i=>`<path d="M68 ${100+i*5} Q${80+i*3} ${88+i*8} ${86} ${94+i*8}" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join("")}`))+
 fG(g,1,`<text x="20" y="50" font-size="11" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">pop</text>`)+fG(g,2,`<circle cx="110" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Unpackite"]="Bubble-Wrapped Axolotl";SM("Unpackite","Pop","STR","a",15,100,"multi:2-5","One bubble. Then another. Then you can't stop.");
