/* =============== ASSAY HALLS: one on every map but Quillmoor ===============
   Each map grows to the east to make room for an Assay Hall. Nothing already on a map moves. Inside: a rest rack by the door,
   two hall hands who will test you on the way through, and the hall's Assayer at the far end, who awards that hall's Seal. */
const GYM_X=40,GYM_W=14;
const GYM_T=[
 "##############",
 "#B.#y.......y#",
 "#..#...:::...#",
 "#..#x..:::..x#",
 "#..#...:::...#",
 "#..#.T.....T.#",
 "#..#.........#",
 "#..#y.......y#",
 "#..##.########",
 "#..#.........#",
 "#..#.o...o...#",
 "#..#.........#",
 "#..#..x...x..#",
 "#..#.........#",
 "#..#.........#",
 "#..#######.###",
 "#..#.........#",
 "#..#..T...T..#",
 "#..#.........#",
 "#..#.........#",
 "#..#y.......y#",
 "#..#.........#",
 "#............#",
 "##############"];
const GYMS={
 "z-mine":{door:[8],seal:"Pithead Seal",hall:"PITHEAD ASSAY HALL",theme:a=>a.d>=8||hasT(a,"Structural")||hasT(a,"Heavy"),
  leader:{n:"Captain Hesketh Rook",title:"Assayer",look:{coat:"#5A4A3A",hair:"#8A8A8A",hs:"short",acc:["helmet","beard","headlamp"],hat:"#E0B820",beard:"#8A8A8A",skin:"#E8B894",style:"jacket",mouth:"flat",brows:"bushy"},
   hi:["Captain Rook. I ran this pit for thirty years before they made me sit in a hall and judge samples.","Down here we test things the old way: weight, and whether it holds. Show me yours."],
   win:["Hm. It held.","Take the Pithead Seal. You've earned the right to carry more than you used to."],lose:["Not today. Go and rest your samples. Come back heavier."],again:["Back for another go? Good. A sample only gets tougher by being tested."]},
  hands:[{n:"Hall Hand Dilly",look:{coat:"#5A4A3A",hair:"#3A2414",hs:"ponytail",acc:["helmet"],hat:"#E0B820",skin:"#F2C7A5",mouth:"grin"},hi:["Nobody gets to the Captain without going through me first. That's the rule. I made it."],beat:["Fair enough. Go on, then."]},
         {n:"Hall Hand Mort",look:{coat:"#4A3A2E",hair:"#1A1A1A",hs:"buzz",acc:["helmet","mustache"],hat:"#E0B820",skin:"#C88A64",mouth:"flat"},hi:["Sixty years down the pit, my family. Let's see what you've got in that case."],beat:["Well. The Captain's through there."]}]},
 "z-scrap":{door:[5],seal:"Scrapheap Seal",hall:"SCRAPHEAP ASSAY HALL",theme:a=>a.mag>0||(a.cond||0)>=20,
  leader:{n:"Yardmaster Fenwick Dace",title:"Assayer",look:{coat:"#2E6F9E",hair:"#E8A060",hs:"spiky",acc:["goggles","gloves"],skin:"#F2D2B8",style:"overalls",mouth:"grin",brows:"raised"},
   hi:["Fenwick Dace. I sort scrap with a crane magnet the size of a bus, and I can tell you what anything's made of by what it does when the magnet comes down.","Let's find out what yours do."],
   win:["Ha! Didn't stick. Nothing sticks to you.","Scrapheap Seal. Wear it with grease on it."],lose:["Into the skip! Go on, rest up and come back."],again:["Another round? The crane's warm."]},
  hands:[{n:"Hall Hand Pip",look:{coat:"#2E6F9E",hair:"#6B4424",hs:"curly",acc:["cap"],hat:"#C8243A",skin:"#8A5A3C",mouth:"grin"},hi:["I found everything in my case on the heaps. Every single one!"],beat:["Back to the heaps for me."]},
         {n:"Hall Hand Ostrander",look:{coat:"#3A4A5A",hair:"#D8D8D8",hs:"bald",acc:["glasses","apron"],skin:"#F2D2B8",mouth:"flat"},hi:["Wire, motors, magnets. That's what the yard is. Let's see if you know it."],beat:["You know it."]}]},
 "z-wreck":{door:[16,17],pier:1,seal:"Tideline Seal",hall:"TIDELINE ASSAY HALL",theme:a=>aNoble(a)>=.3||hasT(a,"Reactive")||hasT(a,"Lightweight"),
  leader:{n:"Bosun Ada Quarrie",title:"Assayer",look:{coat:"#1E3E58",hair:"#E8E8E8",hs:"bun",acc:["scarf","earrings"],scarf:"#C8243A",skin:"#8A5A3C",style:"double",mouth:"smile",brows:"raised"},
   hi:["Bosun Quarrie. This hulk's been moored here longer than I've been alive, and the sea's had a go at every bit of metal in her.","What the sea can't eat, I respect. Let's see if the sea could eat yours."],
   win:["Salt can't touch it. Neither can I.","The Tideline Seal is yours."],lose:["Gone to the bottom. Dry off and come back."],again:["Tide's in. Fancy another?"]},
  hands:[{n:"Hall Hand Rennick",look:{coat:"#2E4A6A",hair:"#1A1A1A",hs:"short",acc:["beanie"],hat:"#2E4A6A",skin:"#C88A64",style:"sweater",knit:"#FFFFFF"},hi:["Walk the plank. Well. The pier. Then fight me."],beat:["Fair winds."]},
         {n:"Hall Hand Moira",look:{coat:"#2E4A6A",hair:"#E8A060",hs:"braids",acc:["freckles"],skin:"#F2D2B8",mouth:"grin"},hi:["Everything in my case has been underwater at least once."],beat:["Sunk."]}]},
 "z-volcano":{door:[13],seal:"Forge Seal",hall:"FORGE ASSAY HALL",theme:a=>a.mp>=1400||hasT(a,"Heat-proof"),
  leader:{n:"Forgewright Ilse Tamar",title:"Assayer",look:{coat:"#5A2A1A",hair:"#1A1A1A",hs:"ponytail",acc:["apron","gloves","goggles"],skin:"#C88A64",style:"jacket",mouth:"flat",brows:"stern"},
   hi:["Tamar. I forge at the caldera's edge because nothing else gets hot enough.","If your samples can't take the heat, we'll know quickly."],
   win:["It came out of the fire whole. That's all I ask.","The Forge Seal."],lose:["Melted. Cool off, then come back."],again:["The forge never goes out. Again."]},
  hands:[{n:"Hall Hand Bram",look:{coat:"#5A2A1A",hair:"#8A3A1A",hs:"short",acc:["apron","beard"],beard:"#8A3A1A",skin:"#F2C7A5"},hi:["I pump the bellows. All day. Let me have this."],beat:["Back to the bellows."]},
         {n:"Hall Hand Sefa",look:{coat:"#6A3A2A",hair:"#1A1A1A",hs:"bun",acc:["goggles"],skin:"#8A5A3C",mouth:"smile"},hi:["Tamar says I'm ready to test people. Let's see if she's right."],beat:["She was half right."]}]},
 "z-vault":{door:[11],seal:"Hallmark Seal",hall:"HALLMARK ASSAY HALL",theme:a=>hasT(a,"Precious")||aNoble(a)>=.5,
  leader:{n:"Curator Pell Wexley",title:"Assayer",look:{coat:"#3A2A4A",hair:"#E8E8E8",hs:"sidepart",acc:["monocle","tie"],skin:"#F2D2B8",style:"waistcoat",mouth:"flat",brows:"raised"},
   hi:["Pell Wexley. I put the hallmarks on everything that passes through the Vault.","A hallmark says a thing is what it claims to be. Let's see if yours are."],
   win:["Genuine. How refreshing.","The Hallmark Seal, stamped and true."],lose:["Counterfeit, I'm afraid. Do come back."],again:["Another appraisal? Certainly."]},
  hands:[{n:"Hall Hand Florian",look:{coat:"#3A2A4A",hair:"#E8D8A8",hs:"wavy",acc:["glasses"],skin:"#F2D2B8",style:"waistcoat"},hi:["Gloves on. We don't touch the samples with bare hands in here."],beat:["How vulgar. Well done."]},
         {n:"Hall Hand Odile",look:{coat:"#4A3A5A",hair:"#1A1A1A",hs:"long",acc:["earrings","brooch"],skin:"#C88A64",mouth:"smile"},hi:["Everything in my case is worth more than this building."],beat:["Worth less than I thought."]}]},
 "z-reactor":{door:[9],seal:"Containment Seal",hall:"CONTAINMENT ASSAY HALL",theme:a=>hasT(a,"Radioactive"),
  leader:{n:"Shift Lead Oyelaran",title:"Assayer",look:{coat:"#E8E4DA",hair:"#1A1A1A",hs:"buzz",acc:["badge","lanyard","glasses"],skin:"#6A4A34",style:"coat",mouth:"flat",brows:"stern"},
   hi:["Oyelaran. Last shift lead this hall ever had.","Everything I carry is counted, logged and contained. Including how badly you're about to lose."],
   win:["Logged: one loss. Mine.","The Containment Seal. Don't lose it, I'll have to fill in a form."],lose:["Readings normal. Come back when they aren't."],again:["New shift. Same test."]},
  hands:[{n:"Hall Hand Petr",look:{coat:"#E0B820",hair:"#3A2414",hs:"short",acc:["helmet","badge"],hat:"#E8E4DA",skin:"#F2C7A5"},hi:["Badge check. Then an Assay. In that order."],beat:["Badge checks out."]},
         {n:"Hall Hand Junie",look:{coat:"#E0B820",hair:"#6B4424",hs:"pigtails",acc:["glasses"],skin:"#F2D2B8",mouth:"grin"},hi:["My counter's been clicking all morning. Fun!"],beat:["Click."]}]},
 "z-glacier":{door:[9],seal:"Frostline Seal",hall:"FROSTLINE ASSAY HALL",theme:a=>(a.hard||0)>=5||hasT(a,"Tough"),
  leader:{n:"Ranger Sigrun Hale",title:"Assayer",look:{coat:"#3A5A6A",hair:"#E8D8A8",hs:"braids",acc:["beanie","scarf"],hat:"#C8243A",scarf:"#E8E4DA",skin:"#F2D2B8",style:"puffer",mouth:"flat",brows:"raised"},
   hi:["Hale. I keep the ropes and the picks on this ice.","Cold makes good metal tough and bad metal snap. Let's find out which yours is."],
   win:["Didn't snap.","Frostline Seal. Keep it close, it's cold out."],lose:["Snapped. Warm up by the stove and try again."],again:["The ice is still here. So am I."]},
  hands:[{n:"Hall Hand Edda",look:{coat:"#3A5A6A",hair:"#FFFFFF",hs:"long",acc:["earmuffs"],muff:"#C8243A",skin:"#F2D2B8"},hi:["My fingers are numb but my case is ready."],beat:["Brr. Go on."]},
         {n:"Hall Hand Torvin",look:{coat:"#2E4A5A",hair:"#8A5A2A",hs:"short",acc:["beard","beanie"],beard:"#8A5A2A",hat:"#2E4A5A",skin:"#F2C7A5"},hi:["Ice axe. Crampons. Sample case. All checked."],beat:["Well climbed."]}]},
 "z-crater":{door:[12],seal:"Starfall Seal",hall:"STARFALL ASSAY HALL",theme:a=>a.mag>0||hasT(a,"Lightweight")||hasT(a,"Heat-proof"),
  leader:{n:"Observer Kit Mallory",title:"Assayer",look:{coat:"#2A2436",hair:"#B08CFF",hs:"wavy",acc:["glasses","pen"],skin:"#C88A64",style:"robe",mouth:"smile",brows:"raised"},
   hi:["Kit Mallory. I watch the sky over this crater every night for the next one to come down.","Everything that falls from space has been tested by the trip. Has yours?"],
   win:["Came through the atmosphere in one piece. Well done.","The Starfall Seal. The last of the eight halls, or one of them."],lose:["Burned up on the way in. Come back."],again:["Clear skies tonight. Assay?"]},
  hands:[{n:"Hall Hand Quill",look:{coat:"#2A2436",hair:"#1A1A1A",hs:"mohawk",acc:["goggles"],skin:"#F2D2B8",mouth:"grin"},hi:["I've got a sample from a meteorite. Probably. Allegedly."],beat:["Allegedly beaten."]},
         {n:"Hall Hand Neve",look:{coat:"#3A3448",hair:"#E8A060",hs:"pigtails",acc:["freckles"],skin:"#F2D2B8"},hi:["I count shooting stars. You're number one thousand and four."],beat:["One thousand and five."]}]}};

/* ---- the halls are buildings now ----
   East of each area, where the hall used to be built straight into the map, there's an open forecourt with the hall standing in it:
   a proper building with a front door. Walk in through the door and you're inside the hall, its own room; walk out and you're
   back on its step. Nothing already on a map moves. */
const HB={x:43,y:3,w:9,h:5,door:[47,7],step:[47,8]};
/* the forecourt: a paved way from the gap in the old east wall round to the hall's front step */
function gymYard(z,map){const G=GYMS[z];if(!G||!map||map[0].length!==40)return map;const sea=!!G.pier,H=map.length,dy=G.door,last=Math.max(12,Math.max(...dy)+1);
  const g=[];for(let y=0;y<H;y++){const r=[];for(let x=0;x<14;x++){const X=40+x;let c;
      if(y===0||y===H-1||X===53)c=sea?"~":"#";else if(y>last)c=sea?"~":"#";else c=sea?"~":".";r.push(c)}g.push(r)}
  const put=(X,y,c)=>{if(y>0&&y<H-1&&X>=40&&X<53)g[y][X-40]=c};
  if(sea){/* the Cove's hall stands on its own rock out in the water, reached by the pier */
    for(let y=2;y<=10;y++)for(let X=42;X<=52;X++)if(!((y===2||y===10)&&(X===42||X===52)))put(X,y,".");
    for(let y=Math.min(...dy);y>=10;y--){put(40,y,"=");put(41,y,"=")}dy.forEach(y=>{put(40,y,"=");put(41,y,"=")});
    put(42,10,"=");put(43,9,".");}
  else{const top=Math.min(...dy);dy.forEach(y=>put(40,y,":"));for(let y=Math.min(top,9);y<=Math.max(top,9);y++)put(41,y,":");for(let X=41;X<=47;X++)put(X,9,":");
    /* everything else in the forecourt is placed on purpose: lamps either side of the step, the area's own furniture round the edges */
    [[42,1],[52,1],[52,last],[42,last]].forEach(([X,y])=>put(X,y,"T"));put(52,5,"x");put(42,5,"o");put(52,9,"y");put(44,last-1,"o");put(50,last-1,"o");}
  for(let y=HB.y;y<HB.y+HB.h;y++)for(let X=HB.x;X<HB.x+HB.w;X++)put(X,y,"H");
  for(let X=45;X<=49;X++)put(X,8,":");put(44,8,"S");put(50,8,sea?".":"o");
  return map.map((r,y)=>{if(dy.includes(y))r=sea?r.slice(0,36)+"====":r.slice(0,39)+":";return r+g[y].join("")})}
Object.keys(GYMS).forEach(z=>{if(MAPS[z])MAPS[z]=gymYard(z,MAPS[z]);const Z=ZONES.find(q=>q.cls===z);if(Z&&Z.map)Z.map=gymYard(z,Z.map)});
/* the inside of each hall: the same three rooms as ever. You come in at the bottom of the long hall-way; the rest rack is right by the door. */
const HALL_IN=["##############","#S.#y.......y#","#..#...:::...#","#..#x..:::..x#","#..#...:::...#","#..#.T.....T.#","#..#.........#","#..#y.......y#","#..##.########","#..#.........#","#..#.o...o...#","#..#.........#","#..#..x...x..#","#..#.........#","#..#.........#","#..#######.###","#..#.........#","#..#..T...T..#","#..#.........#","#B.#.........#","#..#y.......y#","#..#.........#","#............#","#D############"];
const HALLZ={};Object.keys(GYMS).forEach(z=>{const G=GYMS[z],t=G.hall.toLowerCase().replace(/(^|\s)\S/g,m=>m.toUpperCase());HALLZ[z]={name:G.hall,sub:`Assayer: ${G.leader.n}. Hall hands first, the Assayer last.`,cls:z,special:"hall",hallOf:z,map:HALL_IN.slice()}});
const inHallZone=()=>!!(EXP.zone&&EXP.zone.special==="hall");
const inGym=(x,y)=>inHallZone();
const GYM_POS={leader:[8,2,[0,1]],hands:[[7,19,[0,1]],[8,11,[0,1]]],bench:[1,19],spawn:[2,20],door:[1,22]};const GYMST={inG:false};
function hallEnter(z){const H=HALLZ[z];if(!H)return;sfx("clunk");EXP.path=null;EXP.forceZone=H;EXP.spawn=GYM_POS.door.slice();EXP.stash=null;EXP.resume=null;startExplore()}
function hallLeave(){const z=EXP.zone&&EXP.zone.hallOf;if(!z)return;sfx("clunk");EXP.path=null;EXP.forceZone=ZONES.find(q=>q.cls===z);EXP.spawn=HB.step.slice();EXP.stash=null;EXP.resume=null;startExplore()}
Object.keys(GYMS).forEach(z=>{const G=GYMS[z];SIGNS[z]=SIGNS[z]||{};SIGNS[z]["44,8"]=[G.hall+".",`Assayer: ${G.leader.n}.`,"Bring a Sample Case. There's a rest rack just inside the door. Hall hands first, the Assayer last."]});
/* the rest rack */
const RACK_SVG=`<rect x="5" y="14" width="30" height="20" rx="2" fill="#6A7280" stroke="#2A2E34" stroke-width="1.3"/><rect x="8" y="17" width="24" height="9" rx="1" fill="#2A2E34"/>${[10.5,15,19.5,24,28.5].map(x=>`<rect x="${x}" y="18" width="2" height="7" rx=".8" fill="#C9CED4"/>`).join("")}<path d="M10 9 H30 L27 14 H13 Z" fill="#E8A040" stroke="#6A3A10" stroke-width="1"/><path d="M14 12 H26" stroke="#FFE0A0" stroke-width="1.2"/><rect x="8" y="28" width="24" height="3" fill="#4A5058"/>`;
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){if(inHallZone()){if(c==="B")return["f pr",PS(RACK_SVG)];if(c==="S")return["f pr",PS(SIGNPOST)];if(c==="D")return["f hdoor",HALL_MAT]}return _tl(c,x,y,seed,M)}}
/* ---- who's in the hall, and what they carry ---- */
function gymTeam(z,who,s){const G=GYMS[z],seed=[...(z+who)].reduce((a,ch)=>a*31+ch.charCodeAt(0)|0,7),R=mulberry(seed);
  let pool=ALLOYS.filter(a=>!a.threat&&!a.event&&a.hab===z&&G.theme(a));if(pool.length<8)pool=pool.concat(ALLOYS.filter(a=>!a.threat&&!a.event&&G.theme(a)&&!pool.includes(a)&&a.rar!=="legendary"));
  pool=pool.slice().sort((a,b)=>a.name<b.name?-1:1);for(let i=pool.length-1;i>0;i--){const j=R()*(i+1)|0;[pool[i],pool[j]]=[pool[j],pool[i]]}
  const leader=who==="leader",n=leader?Math.min(6,3+Math.floor(s/2)):2+(s>=4?1:0),g=leader?Math.min(3,Math.floor(s/2)):Math.max(0,Math.floor(s/2)-1);
  const pick=pool.filter(a=>leader?a.rar!=="common":true).slice(0,n);while(pick.length<n&&pool.length>pick.length)pick.push(pool.find(a=>!pick.includes(a)));
  return pick.map((a,i)=>[a.name,leader&&i===pick.length-1?Math.min(3,g+1):g])}
function gymKey(z,n){return z+":"+n}
function gymPerson(p,x,y,face){const W=EXP.W,H=EXP.H,d=document.createElement("div");d.className="npc";d.style.width=(100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(x/W*100)+"%";d.style.top=(y/H*100)+"%";
  d.innerHTML=`<span class="talkmark">...</span>`+npcSVG(p.look);$("#world").insertBefore(d,$("#player"));const o={...p,x,y,el:d,said:0,face,talks:[[""]]};EXP.npcs.push(o);return o}
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z||(typeof TUT!=="undefined"&&TUT.on))return;
  if(GYMS[z.cls]&&!z.special){hallOutside(z.cls);return}
  if(z.special!=="hall")return;const G=GYMS[z.cls];
  const[bx,by]=GYM_POS.bench;EXP.objs.push({x:bx,y:by,tile:1,use:()=>{asHealAll();sfx("pickup");talk("",["You set your samples on the rest rack. Warm air from the annealing lamp works the stress out of them.","Your Sample Case is fully rested."])}});
  EXP.objs.push({x:1,y:1,tile:1,use:()=>talk("",[G.hall+".",`Assayer: ${G.leader.n}. Seal of this hall: the ${G.seal}.`,"Hall hands first, the Assayer last. Rest your samples at the rack by the door whenever you like."])});
  EXP.objs.push({x:1,y:23,tile:1,use:()=>hallLeave()});
  G.hands.forEach((h,i)=>{const[x,y,f]=GYM_POS.hands[i];const o=gymPerson(h,x,y,f);o.gymHand=1;o.quest=function(){gymChallenge(z.cls,o,false);return true}});
  {const[x,y,f]=GYM_POS.leader;const o=gymPerson({n:G.leader.n,look:G.leader.look},x,y,f);o.gymLeader=1;o.quest=function(){gymLeaderTalk(z.cls,o);return true}}
  nearMarks()}}
function gymChallenge(z,o,spotted){const d=asData(),k=gymKey(z,o.n),h=GYMS[z].hands.find(q=>q.n===o.n);
  if(d.beat[k]){talk(o.n,h.beat);return}
  const go=()=>asStart({n:o.n,team:gymTeam(z,o.n,d.seals.length)},won=>{if(won==null)return;if(won){const D=asData();D.beat[k]=1;asSave(D);talk(o.n,h.beat)}else gymLost(z)});
  if(spotted){o.el.classList.add("spotted");sfx("alert")}
  talk(o.n,h.hi,go)}
function gymLeaderTalk(z,o){const G=GYMS[z],L=G.leader,d=asData(),won=d.seals.includes(z);
  if(!won&&G.hands.some(h=>!d.beat[gymKey(z,h.n)])){talk(L.n,[L.hi[0],"My hall hands test you first. Both of them. Then come and see me."]);return}
  talk(L.n,won?L.again:L.hi,()=>asStart({n:L.n,title:L.title,leader:1,smart:1,team:gymTeam(z,"leader",won?Math.max(6,d.seals.length):d.seals.length)},res=>{if(res==null)return;
    if(res){const D=asData();if(!D.seals.includes(z)){D.seals.push(z);asSave(D);sfx("fanfare");talk(L.n,L.win,()=>talk("",[`You received the ${G.seal.toUpperCase()}.`,`Seals: ${D.seals.length} of ${Object.keys(GYMS).length}. Your Sample Case holds ${caseSlots()} samples, and samples up to ${GRADES[obeyGrade()]} will take your orders.`]))}else talk(L.n,["Good. Again some time."])}
    else{talk(L.n,L.lose,()=>gymLost(z))}}))}
function gymLost(z){asHealAll();if(!inHallZone()){say0("Your samples are rested.");return}const[x,y]=GYM_POS.spawn;EXP.x=x;EXP.y=y;placePlayer(true);if(typeof cam==="function")cam(true);say0("You were helped back to the rest rack by the door. Your samples are rested.")}
/* hall hands spot you if you walk into their line of sight */
/* walking into a hall's front door takes you in; walking down onto the mat inside takes you out */
{const _st=step;step=function(dx,dy){if(!EXP.busy&&S.phase==="explore"&&EXP.zone&&!AS.on&&!DLG.open){const nx=EXP.x+dx,ny=EXP.y+dy;
    if(GYMS[EXP.zone.cls]&&!EXP.zone.special&&nx===HB.door[0]&&ny===HB.door[1]){hallEnter(EXP.zone.cls);return false}
    if(inHallZone()&&nx===1&&ny===23){hallLeave();return false}}
  const r=_st(dx,dy);if(AS.on||DLG.open||!EXP.zone||!GYMS[EXP.zone.cls])return r;
  const was=GYMST.inG,now=inGym(EXP.x,EXP.y);GYMST.inG=now;if(was!==now&&AU.want!==zoneTrack())startTrack(zoneTrack());
  if(!now||EXP.busy)return r;const d=asData();
  for(const o of EXP.npcs||[]){if(!o.gymHand||d.beat[gymKey(EXP.zone.cls,o.n)])continue;const[fx,fy]=o.face;
    for(let k=1;k<=3;k++){const x=o.x+fx*k,y=o.y+fy*k;if(!passable(tileAt(x,y)))break;if(x===EXP.x&&y===EXP.y){EXP.path=null;gymChallenge(EXP.zone.cls,o,true);return r}}}
  return r}}
{const _zt=zoneTrack;zoneTrack=function(){if(EXP.zone&&GYMS[EXP.zone.cls]&&inGym(EXP.x,EXP.y))return"gym_"+EXP.zone.cls;return _zt()}}
{const _se=startExplore;startExplore=function(){GYMST.inG=false;_se()}}
/* each hall has its own take on the theme */
Object.assign(TRACKS,{
 "gym_z-mine":{base:"explore",bpm:104,swing:.15,lead:{type:"square",vol:.08,stac:true},parts:[{k:"oompah",type:"triangle",vol:.04,oct:3},{k:"stab",type:"pulse",vol:.022,oct:4}],bass:{s:"oompah",vol:.28},drum:"k . h . k s h .",fill:"k k s . k s c ."},
 "gym_z-scrap":{base:"explore",bpm:124,lead:{type:"pulse",vol:.09,stac:true},parts:[{k:"chug",type:"square",vol:.026,oct:3},{k:"arp",type:"triangle",vol:.04,oct:5}],bass:{s:"walk",vol:.28},drum:"k h s h k h s c",fill:"k s k s c c c c"},
 "gym_z-wreck":{base:"explore",bpm:96,swing:.22,lead:{type:"triangle",vol:.16,stac:false},parts:[{k:"broken",type:"sine",vol:.05,oct:4},{k:"pad",type:"sine",vol:.03,oct:3}],bass:{s:"half",vol:.3},drum:"k . . h s . . h",fill:"k . s . s . c .",waves:true},
 "gym_z-volcano":{base:"explore",bpm:132,lead:{type:"sawtooth",vol:.07,stac:true},parts:[{k:"power",type:"square",vol:.035,oct:3},{k:"ostinato",type:"pulse",vol:.02,oct:5}],bass:{s:"root8",type:"square",vol:.12},drum:"k . s k k . s .",fill:"k k s s k k c c"},
 "gym_z-vault":{base:"explore",bpm:100,lead:{type:"triangle",vol:.15,stac:false},parts:[{k:"counter",type:"sine",vol:.05,oct:5},{k:"pad",type:"triangle",vol:.03,oct:4}],bass:{s:"walk",vol:.26},drum:"k . h . s . h .",fill:"k . s . s s c .",chime:true},
 "gym_z-reactor":{base:"explore",bpm:118,lead:{type:"pulse",vol:.08,stac:true},parts:[{k:"ostinato",type:"square",vol:.022,oct:5},{k:"pad",type:"sawtooth",vol:.018,oct:3}],bass:{s:"octave",vol:.26},drum:"k h h h s h h h",fill:"k s s s s s c c",hat16:true},
 "gym_z-glacier":{base:"explore",bpm:90,lead:{type:"sine",vol:.2,oct:1,stac:true},parts:[{k:"arp",type:"triangle",vol:.04,oct:5},{k:"pad",type:"sine",vol:.03,oct:4}],bass:{s:"half",vol:.28},drum:"k . . . s . . .",fill:"k . s . s . c c",chime:true},
 "gym_z-crater":{base:"explore",bpm:110,swing:.1,lead:{type:"triangle",vol:.14,stac:true},parts:[{k:"arp",type:"pulse",vol:.026,oct:5},{k:"third",type:"sine",vol:.05}],bass:{s:"walk",vol:.26},drum:"k . h s . k h s",fill:"k k s . s s c c"}});
/* ---- the journal ---- */
{const _jo=journalObjectives;journalObjectives=function(){const J=_jo(),d=asData(),Z=Object.keys(GYMS),left=Z.filter(z=>!d.seals.includes(z));
  const nm=z=>(ZONES.find(q=>q.cls===z)||{}).name||z;
  J.push(`<div class="bag-item key obj"><b>ASSAY SEALS: ${d.seals.length} OF ${Z.length}</b><p>${d.case.length?`Carry your Sample Case into the Assay Halls, one in every area but Quillmoor, and earn their Seals.`:`Open the CASE and choose which registered samples to carry, then take them to the Assay Halls, one in every area but Quillmoor.`}<span class="obj-list">${left.map(z=>`<span><b>${GYMS[z].hall}:</b> ${nm(z)}.</span>`).join("")}${d.seals.length?`<span><b>EARNED:</b> ${d.seals.map(z=>GYMS[z].seal).join(", ")}.</span>`:""}</span></p></div>`);return J}}
