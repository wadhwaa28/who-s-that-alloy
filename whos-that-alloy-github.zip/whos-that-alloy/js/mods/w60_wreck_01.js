/* ---- Shipwreck Coast, 1 ---- */
/* Aich's Metal: a 19th-century brass tougher than ordinary brass. A crayfish in a brass-knuckle claw, spoiling for a fight. */
addForm("Aich's Metal",{n:"#B8503A",a:"#E8C060",rn:"#3A3A4A",rb:"#5A8A6A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",150,118,`${[0,1,2,3].map(i=>`<path d="M${140+i*10} ${110+i*2} q6 -4 10 2 v14 q-6 2 -10 -2 Z" fill="${P.n}" ${SW2}/>`).join("")}<path d="M180 116 L194 106 L192 126 Z" fill="${P.nd}" ${SW2}/>`)+
 [0,1,2].map(i=>pt("legB",120+i*8,126,`<path d="M${120+i*8} 126 L${126+i*10} 142" stroke="${FI}" stroke-width="3"/>`,i*.2)).join("")+
 `<path d="M84 118 Q86 102 114 100 Q140 102 144 118 Q140 132 114 132 Q88 132 84 118 Z" fill="${P.n}" ${SW}/><path d="M96 104 Q114 98 136 106" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/>`+
 [0,1].map(i=>pt("legF",100+i*8,128,`<path d="M${100+i*8} 128 L${94+i*8} 144" stroke="${FI}" stroke-width="3"/>`,i*.2+.1)).join("")+
 pt("claw",86,108,fOL("M90 110 Q70 100 62 86",P.n,7)+`<path d="M40 70 Q44 58 60 62 Q70 70 64 84 Q52 92 42 84 Z" fill="${P.n}" ${SW}/><rect x="42" y="64" width="20" height="8" rx="3" fill="${P.ac}" ${SW2}/>${[46,52,58].map(x=>`<circle cx="${x}" cy="68" r="2.4" fill="none" stroke="${P.dd}" stroke-width="1.2"/>`).join("")}`+pt("claw2",44,80,`<path d="M44 80 Q32 82 30 92 Q42 92 48 86 Z" fill="${P.nd}" ${SW2}/>`))+
 pt("head",84,112,`<path d="M66 116 Q68 104 82 104 Q92 106 92 116 Z" fill="${P.n}" ${SW}/><path d="M74 104 L72 92 M82 104 L84 92" stroke="${FI}" stroke-width="2.4"/>${E2(72,90,3.6)}${E2(84,90,3.6)}`+pt("ant",70,108,`<path d="M70 110 Q40 110 24 96 M72 112 Q46 120 26 116" stroke="${FI}" stroke-width="1.4" fill="none"/>`)+HMOUTH(64,116,72,P,2))+
 fG(g,1,`<path d="M20 140 q6 -6 12 0" stroke="#7AB8E8" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="114" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,60,6)));
FORM_TITLE["Aich's Metal"]="Brass-Knuckle Crayfish";SM("Aich's Metal","Knuckle Down","STR","a",80,100,"","Tougher than it looks, and it looks pretty tough.");

/* Apologium: forty-one apology letters for one delivery, including one from a horse. A basset hound, ears drooping, offering its own apology letter. */
addForm("Apologium",{n:"#C8904A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#7A4A8A",ra:"#E8412C"},"stand",(P,g)=>fShadow(72)+
 pt("tail",160,104,`<path d="M158 104 Q172 96 176 82" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M158 104 Q172 96 176 82" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M174 86 l2 -6" stroke="${P.ac}" stroke-width="5" stroke-linecap="round"/>`)+
 fLeg("legB",148,120,20,9,P.nd,P.ac,.5)+fLeg("legB",114,122,18,9,P.nd,P.ac,1.3)+
 `<path d="M84 114 Q84 94 120 92 Q156 94 162 112 Q158 128 122 128 Q88 128 84 114 Z" fill="${P.n}" ${SW}/><path d="M110 94 Q130 92 146 100 L144 116 Q126 112 110 112 Z" fill="#6A3A1A" opacity=".7"/><path d="M92 120 Q120 130 150 120" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 fLeg("legF",138,122,18,9,P.n,P.ac,0)+fLeg("legF",98,122,18,9,P.n,P.ac,.8)+
 pt("head",88,104,`<path d="M48 112 Q46 92 66 90 Q88 92 90 108 Q86 122 68 124 Q52 124 48 112 Z" fill="${P.n}" ${SW}/><path d="M48 114 Q50 108 58 110 Q58 120 50 120 Z" fill="${P.ac}"/><ellipse cx="48" cy="112" rx="3.6" ry="3" fill="${FI}"/><path d="M60 98 q4 3 8 0 M60 96 l8 -2" stroke="${FI}" stroke-width="1.6" fill="none"/><circle cx="64" cy="100" r="1.6" fill="${FI}"/>`+
  `<path d="M50 118 L64 120 L62 124 L52 122 Z" fill="${FMOUTH}"/>`+pt("jaw",62,123,`<path d="M64 122 Q56 128 50 122 Q56 125 64 125 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(10 48 128)"><rect x="34" y="122" width="20" height="14" fill="#F4F0E4" ${SW2}/><path d="M38 127 h12 M38 131 h8" stroke="#3A5AA8" stroke-width="1"/><text x="38" y="134" font-size="4" fill="${FI}">sorry</text></g>`)+
  pt("ear",72,94,`<path d="M70 92 Q90 90 88 124 Q86 140 76 136 Q78 114 70 102 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`${[0,1,2].map(i=>`<rect x="${18+i*6}" y="${120-i*8}" width="18" height="12" fill="#F4F0E4" ${SW2} transform="rotate(${i*8-8} ${27+i*6} ${126-i*8})"/>`).join("")}`)+fG(g,2,`<circle cx="122" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Apologium"]="Apologetic Basset";SM("Apologium","Forty-One Apologies","RES","s",0,100,"tatk-1,tatk-1@50","It's so very, very sorry. You can't stay cross with it.");

/* Approved Eleven: the folder on top was stamped APPROVED. A hammerhead shark whose hammer is a rubber stamp. */
addForm("Approved Eleven",{n:"#7A8A9A",a:"#C8302A",rn:"#E8E0D0",rb:"#3A5A8A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",156,84,`<path d="M150 84 L178 56 L174 84 L184 106 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",124,72,`<path d="M118 76 L130 48 L140 76 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M70 86 Q76 66 112 64 Q146 66 156 84 Q146 100 112 102 Q80 102 70 86 Z" fill="${P.n}" ${SW}/><path d="M80 92 Q110 104 146 90" stroke="${P.nl}" stroke-width="5" fill="none" opacity=".7"/>${[100,106,112].map(x=>`<path d="M${x} 78 q-2 6 0 12" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("wingF",108,94,`<path d="M108 96 L94 120 L118 100 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",70,84,`<rect x="60" y="72" width="16" height="22" rx="4" fill="#6A4A2A" ${SW}/><rect x="36" y="58" width="16" height="48" rx="3" fill="${P.n}" ${SW}/><rect x="32" y="58" width="6" height="48" rx="2" fill="${P.ac}" ${SW2}/><path d="M52 78 H62" stroke="${FI}" stroke-width="8"/><path d="M52 78 H62" stroke="${P.n}" stroke-width="5"/>`+
  `${E2(44,62,3.4)}${E2(44,100,3.4)}`+pt("jaw",54,92,`<path d="M52 88 L62 92 L52 96 Z" fill="${FMOUTH}" ${SW2}/>`))+
 fG(g,1,`<g transform="rotate(-10 30 132)"><rect x="12" y="124" width="40" height="14" fill="none" stroke="${P.ac}" stroke-width="2"/><text x="14" y="135" font-size="9" font-weight="bold" fill="${P.ac}">APPROVED</text></g>`)+fG(g,2,`<circle cx="112" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Approved Eleven"]="Rubber-Stamp Hammerhead";SM("Approved Eleven","Stamp Of Approval","STR","a",75,100,"atk+1@30","Thunk. Approved. No further questions.");

/* Badge Metal: scouts could earn a badge for guessing its makeup; nobody has. A pine marten in a scout sash covered with badges, one blank. */
addForm("Badge Metal",{n:"#7A4A2A",a:"#E8C890",rn:"#3A3A4A",rb:"#4A7A4A",ra:"#E8412C"},"slink",(P,g)=>fShadow(70)+
 pt("tail",158,98,`<path d="M156 100 Q184 96 188 74" stroke="${FI}" stroke-width="15" fill="none" stroke-linecap="round"/><path d="M156 100 Q184 96 188 74" stroke="${P.n}" stroke-width="11.6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",146,112,28,8,P.nd,P.ndd,.5)+
 `<path d="M70 102 Q72 84 108 82 Q148 84 158 100 Q154 116 116 116 Q78 116 70 102 Z" fill="${P.n}" ${SW}/><path d="M92 84 L122 116" stroke="#4A7A4A" stroke-width="10"/>${[[98,92,"#E8412C"],[106,100,"#F2C94C"],[114,108,"#4A8AE8"]].map(([x,y,c])=>`<circle cx="${x}" cy="${y}" r="3.6" fill="${c}" ${SW2}/>`).join("")}<circle cx="121" cy="115" r="3.6" fill="#F4F0E4" ${SW2}/>`+
 fLeg("legF",136,114,26,8,P.n,P.ndd,0)+fLeg("legF",84,110,30,8,P.n,P.ndd,.8)+
 pt("head",70,94,`<path d="M32 90 Q36 74 54 72 Q72 74 74 90 Q70 102 54 102 Q38 102 32 90 Z" fill="${P.n}" ${SW}/><path d="M40 94 Q52 104 66 96 Q60 108 46 106 Z" fill="${P.ac}"/><ellipse cx="32" cy="89" rx="3" ry="2.6" fill="${FI}"/>${E2(52,84,3.6,"#1A1A1A")}`+HMOUTH(34,94,42,P,2.4)+
  pt("ear",62,74,`<circle cx="62" cy="72" r="6" fill="${P.n}" ${SW2}/><circle cx="62" cy="72" r="2.6" fill="${P.ac}"/>`)+`<path d="M44 74 Q56 62 70 72 L66 76 Q56 70 48 78 Z" fill="#4A7A4A" ${SW2}/>`)+
 fG(g,1,`<circle cx="30" cy="130" r="8" fill="#F4F0E4" ${SW2}/><text x="27" y="134" font-size="10" font-weight="bold" fill="${FI}">?</text>`)+fG(g,2,`<circle cx="140" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,50,6)));
FORM_TITLE["Badge Metal"]="Merit-Badge Marten";SM("Badge Metal","Be Prepared","RES","s",0,100,"def+1,acc+1","Ready for anything. Except, apparently, guessing what this is.");

/* Badgerine: badgers dug in, and politely dug back out. A naked mole-rat, the great tunneller, popping out of its own neat tunnel. */
addForm("Badgerine",{n:"#E8B0A0",a:"#F4F0E4",rn:"#3A3A4A",rb:"#8A6A4A",ra:"#5FE0A0"},"perch",(P,g)=>`<path d="M14 110 H194 V150 H14 Z" fill="#8A6A4A"/><path d="M14 110 H194" stroke="#5A9A3A" stroke-width="6"/><path d="M14 150 Q60 120 104 128 Q150 136 194 120" stroke="#6A4A2A" stroke-width="18" fill="none" opacity=".6"/><ellipse cx="104" cy="112" rx="30" ry="8" fill="#3A2A1A"/>`+
 pt("armF",86,108,`<path d="M88 108 Q76 104 72 112" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M88 108 Q76 104 72 112" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+pt("armB",122,108,`<path d="M120 108 Q132 104 136 112" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M120 108 Q132 104 136 112" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`,.4)+
 pt("head",104,84,`<path d="M82 112 Q78 70 104 60 Q130 70 126 112 Z" fill="${P.n}" ${SW}/>${[76,84,92,100].map(y=>`<path d="M86 ${y} q18 4 36 0" stroke="${P.nd}" stroke-width="1.2" fill="none" opacity=".7"/>`).join("")}<circle cx="96" cy="72" r="1.6" fill="${FI}"/><circle cx="112" cy="72" r="1.6" fill="${FI}"/>`+
  `<path d="M96 86 L112 86 L110 92 L98 92 Z" fill="${FMOUTH}"/><rect x="98" y="76" width="5" height="10" rx="1" fill="${P.ac}" ${SW2}/><rect x="104" y="76" width="5" height="10" rx="1" fill="${P.ac}" ${SW2}/>`+pt("jaw",104,92,`<rect x="99" y="90" width="4" height="7" rx="1" fill="${P.ac}" ${SW2}/><rect x="104" y="90" width="4" height="7" rx="1" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 120 q6 -10 12 0 Z M160 124 q6 -10 12 0 Z" fill="#6A4A2A" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Badgerine"]="Tunnelling Mole-Rat";SM("Badgerine","Back The Way You Came","RES","s",0,100,"dodge,spd+1","Dig in, take nothing, dig out again. Very politely.");

/* Balloonium: eleven crates of party balloons, and then this. A balloon dog, twisted out of long balloons, squeaking. */
addForm("Balloonium",{n:"#E8604A",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5AB0E8",ra:"#F2C94C"},"hop",(P,g)=>fShadow(66)+
 `<path d="M150 74 Q160 60 168 54" stroke="#9A9AA0" stroke-width="1.4" fill="none"/>`+
 pt("tail",150,76,`<ellipse cx="160" cy="64" rx="6" ry="14" fill="${P.n}" ${SW} transform="rotate(40 160 64)"/><path d="M156 58 Q158 56 162 58" stroke="#fff" stroke-width="2" fill="none" opacity=".7"/>`)+
 [[146,"legB",.5],[124,"legB",1.3]].map(([x,c,d])=>pt(c,x,104,`<ellipse cx="${x}" cy="118" rx="7" ry="20" fill="${P.n}" ${SW}/><path d="M${x-3} 104 v14" stroke="#fff" stroke-width="2" opacity=".6"/>`,d)).join("")+
 `<ellipse cx="130" cy="88" rx="30" ry="10" fill="${P.n}" ${SW}/><path d="M110 84 Q130 80 150 84" stroke="#fff" stroke-width="2.4" fill="none" opacity=".6"/>`+
 [[136,"legF",0],[112,"legF",.8]].map(([x,c,d])=>pt(c,x,106,`<ellipse cx="${x}" cy="120" rx="7" ry="20" fill="${P.n}" ${SW}/><path d="M${x-3} 106 v14" stroke="#fff" stroke-width="2" opacity=".6"/>`,d)).join("")+
 pt("head",96,80,`<ellipse cx="96" cy="70" rx="8" ry="16" fill="${P.n}" ${SW}/><ellipse cx="80" cy="56" rx="18" ry="9" fill="${P.n}" ${SW}/><path d="M66 52 Q74 48 82 50" stroke="#fff" stroke-width="2.4" fill="none" opacity=".7"/>${E2(80,52,3.4)}<circle cx="62" cy="56" r="3" fill="${P.n}" ${SW2}/>`+HMOUTH(66,60,74,P,2)+
  pt("ear",92,48,`<ellipse cx="94" cy="38" rx="6" ry="12" fill="${P.n}" ${SW} transform="rotate(-10 94 38)"/>`)+pt("ear",100,48,`<ellipse cx="104" cy="40" rx="5" ry="11" fill="${P.n}" ${SW} transform="rotate(20 104 40)"/>`,.3))+
 fG(g,1,`${[[30,40,"#5AB0E8"],[44,30,"#F2C94C"]].map(([x,y,c])=>`<ellipse cx="${x}" cy="${y}" rx="8" ry="10" fill="${c}" ${SW2}/><path d="M${x} ${y+10} q-2 10 2 20" stroke="#9A9AA0" stroke-width="1" fill="none"/>`).join("")}`)+fG(g,2,`<circle cx="130" cy="88" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,110,6)));
FORM_TITLE["Balloonium"]="Balloon Dog";SM("Balloonium","Squeak","RES","a",40,100,"tacc-1,multi:1-2","Squeak, squeak, twist, and... a dog! Sort of.");

/* Bonsai Blend: a retired ferry pilot swears his bonsai grow straighter over it. A small deer whose antlers are two bonsai trees. */
addForm("Bonsai Blend",{n:"#B8804A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#E8604A"},"stand",(P,g)=>`<rect x="140" y="128" width="48" height="16" rx="2" fill="#4A5A8A" ${SW}/>`+fShadow(66)+
 pt("tail",150,94,`<path d="M148 92 Q158 86 158 96 Q154 100 148 98 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",140,106,36,6,P.nd,P.ndd,.5)+fLeg("legB",112,108,34,6,P.nd,P.ndd,1.3)+
 `<path d="M88 100 Q90 80 120 78 Q148 80 152 98 Q148 114 122 114 Q94 114 88 100 Z" fill="${P.n}" ${SW}/>${[[104,90],[116,86],[128,92],[138,86],[120,100]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.ac}"/>`).join("")}`+
 fLeg("legF",132,108,34,6,P.n,P.ndd,0)+fLeg("legF",100,108,34,6,P.n,P.ndd,.8)+
 pt("head",92,86,`<path d="M96 92 Q86 76 82 66" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M96 92 Q86 76 82 66" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M56 64 Q58 50 74 50 Q88 52 88 64 Q84 74 72 74 L58 72 Z" fill="${P.n}" ${SW}/><ellipse cx="57" cy="66" rx="3" ry="2.6" fill="${FI}"/>${E2(72,60,3.6,"#1A1A1A")}`+HMOUTH(58,70,66,P,2)+
  pt("ear",84,56,`<path d="M82 56 Q94 50 96 56 Q90 62 84 60 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ant",76,48,`<path d="M76 50 Q70 40 74 32 Q80 26 76 18" stroke="#6A4A2A" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M74 32 Q66 30 62 34" stroke="#6A4A2A" stroke-width="2.4" fill="none"/>${[[62,30,9],[76,16,10],[86,26,7]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.6}" fill="#5A9A4A" ${SW2}/>`).join("")}<path d="M84 50 Q92 40 96 30" stroke="#6A4A2A" stroke-width="3.4" fill="none" stroke-linecap="round"/>${[[98,26,8],[104,36,6]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.6}" fill="#5A9A4A" ${SW2}/>`).join("")}`))+
 fG(g,1,`<path d="M30 140 h20 l-2 -8 h-16 Z" fill="#4A5A8A" ${SW2}/><path d="M40 132 Q36 120 42 112" stroke="#6A4A2A" stroke-width="3" fill="none"/><ellipse cx="42" cy="110" rx="8" ry="4" fill="#5A9A4A" ${SW2}/>`)+fG(g,2,`<circle cx="120" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Bonsai Blend"]="Bonsai-Antlered Deer";SM("Bonsai Blend","Patient Pruning","RES","s",0,100,"def+1,heal:25","A snip here, a snip there. Grows straighter every year.");

/* Butterfly Wharf Mix: thousands of butterflies settled on the loading dock. A mooring bollard that has come alive under a coat of butterflies. */
addForm("Butterfly Wharf Mix",{n:"#3A3A44",a:"#E8901A",rn:"#E8D8C8",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 136 H194 V150 H14 Z" fill="#8A6A4A" ${SW2}/>${[30,60,90,120,150,180].map(x=>`<path d="M${x} 136 V150" stroke="#6A4A2A" stroke-width="2"/>`).join("")}`+fShadow(54)+
 `<path d="M150 90 Q180 80 194 92" stroke="#C8A060" stroke-width="5" fill="none"/>`+
 pt("legB",118,130,`<rect x="112" y="124" width="12" height="12" rx="3" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M80 130 L84 76 Q104 66 124 76 L128 130 Z" fill="${P.n}" ${SW}/><ellipse cx="104" cy="76" rx="26" ry="8" fill="${P.nd}" ${SW}/><path d="M78 100 Q104 108 130 100" stroke="${FI}" stroke-width="4" fill="none"/><path d="M128 92 L150 90" stroke="#C8A060" stroke-width="5"/>`+
 pt("legF",90,130,`<rect x="84" y="124" width="12" height="12" rx="3" fill="${P.n}" ${SW2}/>`)+
 pt("head",104,92,`${E2(94,90,4.4)}${E2(114,90,4.4)}`+HMOUTH(98,112,110,P,3))+
 pt("sway",104,80,`${[[86,80,0],[118,72,20],[96,120,-20],[124,114,10],[100,64,-10],[78,108,30]].map(([x,y,r])=>`<g transform="rotate(${r} ${x} ${y})"><path d="M${x} ${y} Q${x-10} ${y-10} ${x-8} ${y+2} Q${x-6} ${y+8} ${x} ${y} Q${x+10} ${y-10} ${x+8} ${y+2} Q${x+6} ${y+8} ${x} ${y} Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.2"/><path d="M${x} ${y-4} v8" stroke="${FI}" stroke-width="1.6"/></g>`).join("")}`)+
 pt("wingF",60,50,`${[[48,40],[160,36],[40,70]].map(([x,y])=>`<path d="M${x} ${y} Q${x-12} ${y-12} ${x-10} ${y+2} Q${x-8} ${y+10} ${x} ${y} Q${x+12} ${y-12} ${x+10} ${y+2} Q${x+8} ${y+10} ${x} ${y} Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.4"/>`).join("")}`)+
 fG(g,1,`<path d="M170 120 q6 -4 12 0" stroke="#7AB8E8" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,70,6)));
FORM_TITLE["Butterfly Wharf Mix"]="Butterfly-Coated Bollard";SM("Butterfly Wharf Mix","Migration","RES","s",0,100,"spd+1,ward+1","Thousands settle at once, and nothing moves until they're ready.");

/* Captain's Hat Metal: listed twice, once in the hold and once in the captain's hat. A parrot wearing the captain's hat, a sample peeking out from under it. */
addForm("Captain's Hat Metal",{n:"#3AA85A",a:"#E8412C",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M40 126 H170" stroke="#8A6A4A" stroke-width="8" stroke-linecap="round"/>`+fShadow(46,110)+
 pt("tail",120,118,`<path d="M114 116 L128 150 L118 150 L108 120 Z" fill="${P.ac}" ${SW}/><path d="M120 118 L140 146 L132 148 L114 120 Z" fill="#4A8AE8" ${SW2}/>`)+
 `<path d="M84 112 Q82 80 104 76 Q126 80 126 112 Q120 126 104 126 Q90 126 84 112 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,98,`<path d="M106 88 Q128 90 130 118 Q118 120 108 110 Z" fill="${P.nd}" ${SW}/><path d="M116 108 l10 6 M114 114 l12 4" stroke="#4A8AE8" stroke-width="3"/>`)+
 pt("legF",98,124,`<path d="M96 122 l-2 6 M100 122 l2 6" stroke="#8A8A9A" stroke-width="3"/>`)+
 pt("head",100,74,`<circle cx="100" cy="66" r="15" fill="${P.n}" ${SW}/><circle cx="94" cy="64" r="6" fill="#F4F0E4" ${SW2}/>${E2(94,64,3.2,"#E8C040")}<path d="M86 66 Q74 68 76 82 Q84 80 88 74 Z" fill="#3A3A44" ${SW}/>`+pt("beak",82,80,`<path d="M88 74 Q82 84 78 82 Q84 78 86 72 Z" fill="#6A6A70" ${SW2}/>`)+
  `<path d="M80 54 Q100 34 120 54 Z" fill="#1A2A4A" ${SW}/><path d="M76 54 H124" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M76 54 H124" stroke="#1A2A4A" stroke-width="3" stroke-linecap="round"/><circle cx="100" cy="46" r="4" fill="#F2C94C" ${SW2}/><path d="M78 54 q0 6 6 6" stroke="#F2C94C" stroke-width="2" fill="none"/><rect x="108" y="54" width="10" height="5" fill="${P.b}" ${SW2}/>`)+
 fG(g,1,`<path d="M30 40 l20 0 l-4 6 h-12 Z" fill="#8A5A3A" ${SW2}/><path d="M40 40 V20 l12 8 l-12 6" stroke="${FI}" stroke-width="1.4" fill="#F4F0E4"/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Captain's Hat Metal"]="Captain's-Hat Parrot";SM("Captain's Hat Metal","Squawk Orders","RES","s",0,100,"atk+1,tdef-1","All hands on deck! Squawk!");

/* Checkmate Metal: sent with the chess trophy, and returned unopened every year. A chess rook, a walking castle tower, battlements for a crown. */
addForm("Checkmate Metal",{n:"#E8E0D0",a:"#2A2A30",rn:"#3A3A4A",rb:"#C8A040",ra:"#E8412C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",118,132,`<rect x="112" y="128" width="12" height="14" rx="3" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M74 132 H134 L130 120 H78 Z" fill="${P.n}" ${SW}/><path d="M82 120 L86 66 H122 L126 120 Z" fill="${P.n}" ${SW}/><path d="M78 66 H130 V48 H120 V56 H110 V48 H98 V56 H88 V48 H78 Z" fill="${P.n}" ${SW}/><path d="M86 70 h36" stroke="${P.nd}" stroke-width="2"/><rect x="99" y="96" width="10" height="16" rx="5" fill="${P.ac}" ${SW2}/>`+
 pt("legF",90,132,`<rect x="84" y="128" width="12" height="14" rx="3" fill="${P.n}" ${SW2}/>`)+
 pt("head",104,82,`${E2(96,80,4)}${E2(112,80,4)}`+HMOUTH(98,90,110,P,2.6))+
 pt("armF",84,90,fOL("M84 90 Q70 94 66 104",P.n,6))+pt("armB",124,90,fOL("M124 90 Q140 88 142 76",P.n,6)+`<path d="M138 74 L148 54 L156 74 Z" fill="#C8A040" ${SW2}/><rect x="140" y="74" width="14" height="6" fill="#C8A040" ${SW2}/>`,.4)+
 fG(g,1,`<g transform="translate(20 122)">${[0,1,2].map(r=>[0,1,2].map(c=>`<rect x="${c*8}" y="${r*6}" width="8" height="6" fill="${(r+c)%2?FI:"#F4F0E4"}"/>`).join("")).join("")}</g>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Checkmate Metal"]="Walking Rook";SM("Checkmate Metal","Castle","RES","s",0,100,"def+1,spd+1","Swap places in one move and suddenly everything's safe.");
