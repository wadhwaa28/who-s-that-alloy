/* =============== BATTLE FORMS, batch 6: every alloy of Quillmoor and of the Slag Works ===============
   Quillmoor's are the Institute's odd batches; the Slag Works' are the Syndicate's and the Union's. Each creature comes from the metal's
   job, and sometimes from the story stuck to it. */

/* 146. Complainium (platinum-palladium: commemorative medals, and the subject of a complaint letter from 1899) — a goose, honking its
   grievance with neck stretched out low, wings half raised, a medal on a ribbon round its neck. */
addForm("Complainium",{n:"#F4F0E4",a:"#F28A30",rn:"#5A5A6A",rb:"#3A8AC8",ra:"#E8412C"},"stand",(P,g)=>fShadow(50,110)+
 pt("tail",146,94,`<path d="M142 88 L166 84 L160 100 Z" fill="${P.n}" ${SW2}/>`)+
 fLeg("legB",126,112,28,4,P.ac,null,.5,2)+
 `<path d="M92 102 Q94 78 124 78 Q152 82 154 102 Q146 118 124 118 Q96 118 92 102 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",124,90,`<path d="M108 86 Q140 70 162 82 Q150 102 114 102 Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${130+i*8} ${82+i*2} l6 8" stroke="${P.n}" stroke-width="1.6"/>`).join("")}`)+
 pt("legF",112,114,fOL("M112 114 L108 140",P.ac,4)+`<path d="M100 142 L114 142 L108 138 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("head",96,94,fOL("M98 96 Q76 98 60 94",P.n,10)+`<path d="M78 96 L82 112" stroke="${P.ac}" stroke-width="1.6"/><circle cx="82" cy="116" r="5" fill="${P.b}" ${SW2}/><path d="M80 114 l4 4" stroke="${P.dd}" stroke-width="1"/>`+
  `<path d="M40 88 Q42 78 54 78 Q66 80 66 92 Q62 100 52 100 Q42 98 40 88 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M42 88 L22 90 L42 94 Z" fill="${FMOUTH}"/>`+pt("beak",42,94,`<path d="M42 94 L22 92 Q24 98 42 98 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M44 84 L20 88 Q20 92 24 90 L44 90 Z" fill="${P.ac}" ${SW2}/>${fE(52,86,3.4,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M48 80 l8 2" stroke="${FI}" stroke-width="2"/>`)+
 fG(g,1,`<path d="M10 70 l8 4 M12 80 l8 0 M10 90 l8 -4" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="124" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,58,6)));
FORM_TITLE["Complainium"]="Grievance Goose";

/* 147. Tea Trolley Metal (lead-bismuth: fusible safety plugs that melt to save the boiler) — an opossum that gives way like a safety plug:
   hanging by its tail from the tea trolley's rail, it flops limp, then snaps back to hiss. */
addForm("Tea Trolley Metal",{n:"#C8C4C0",a:"#F0A0A8",rn:"#3A3A4A",rb:"#B07A3A",ra:"#5FE0F0"},"perch",(P,g)=>`<rect x="20" y="20" width="164" height="8" rx="3" fill="${P.b}" ${SW}/>${[[60,10],[150,10]].map(([x,y])=>`<path d="M${x-10} ${y+10} Q${x} ${y-4} ${x+10} ${y+10}" fill="#F4F0E4" ${SW2}/>`).join("")}<ellipse class="shd" cx="104" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",116,28,fOL("M116 28 Q126 40 120 54 Q114 64 118 74",P.ac,4))+
 fLeg("legB",124,82,20,6,P.nd,null,.4,-4)+
 `<path d="M98 120 Q90 92 106 74 Q126 74 130 96 Q128 122 112 128 Z" fill="${P.n}" ${SW}/><path d="M104 118 Q100 98 110 88" stroke="${P.nll}" stroke-width="5" fill="none"/>`+
 pt("armF",104,108,fOL("M104 108 Q92 110 88 98",P.nd,6)+`<path d="M86 96 l-3 -3 M88 94 l-1 -4" stroke="${P.ac}" stroke-width="1.6"/>`)+
 pt("head",106,126,`<path d="M90 128 Q88 146 104 150 Q120 146 118 128 Z" fill="${P.ac}" ${SW}/><path d="M92 132 Q104 128 116 132 Q116 122 104 120 Q92 122 92 132 Z" fill="#F4F0E4" ${SW2}/>`+
  `${fE(98,134,3.4,{iris:"#2A1A0A",look:[0,.3],lid:.3,lidC:"#F4F0E4"})}${fE(110,134,3.4,{iris:"#2A1A0A",look:[0,.3],lid:.3,lidC:"#F4F0E4"})}<ellipse cx="104" cy="150" rx="3" ry="2.4" fill="${FI}"/>`+
  `<path d="M98 142 L110 142 L108 146 L100 146 Z" fill="${FMOUTH}"/>`+pt("jaw",110,144,`<path d="M110 144 Q104 150 98 144 Q104 148 110 146 Z" fill="#F4F0E4" ${SW2}/>`)+
  pt("ear",92,124,`<circle cx="90" cy="122" r="5" fill="${FI}"/>`)+pt("ear",118,124,`<circle cx="120" cy="122" r="5" fill="${FI}"/>`,.4))+
 fG(g,1,`<rect x="34" y="120" width="14" height="10" rx="2" fill="${P.b}" ${SW2}/><path d="M48 124 q6 2 0 6" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="114" cy="102" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(150,60,6)));
FORM_TITLE["Tea Trolley Metal"]="Safety-Plug Opossum";

/* 148. Heronex (platinum-ruthenium: jewellery) — a satin bowerbird that decorates its bower with stolen jewellery, dancing in front of it,
   wings flicking, violet eyes, bill clicking. */
addForm("Heronex",{n:"#2A2E6A",a:"#9FD0FF",rn:"#E8C8A0",rb:"#3A8A5A",ra:"#E8412C"},"hop",(P,g)=>`<path d="M140 146 Q144 100 156 80 M150 146 Q156 104 170 86 M160 146 Q170 110 184 96" stroke="#8A6A3A" stroke-width="3" fill="none"/>${[[130,142],[120,146],[176,140],[168,146]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${i%2?P.b:P.ac}" ${SW2}/>`).join("")}<circle cx="152" cy="138" r="5" fill="none" stroke="${FI}" stroke-width="3.4"/><circle cx="152" cy="138" r="5" fill="none" stroke="${P.b}" stroke-width="2"/>`+fShadow(36,96)+
 pt("tail",116,108,`<path d="M112 104 L140 116 L134 124 L110 112 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M70 104 Q72 82 96 80 Q118 84 120 104 Q114 120 96 120 Q74 120 70 104 Z" fill="${P.n}" ${SW}/><path d="M76 96 Q96 86 116 96" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".6"/>`+
 pt("wingF",98,94,`<path d="M88 90 Q116 86 124 104 Q106 112 92 104 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legF",90,118,24,3,"#E8D890",null,0)+fLeg("legB",100,118,24,3,"#E8D890",null,.4)+
 pt("head",80,86,`<circle cx="74" cy="76" r="13" fill="${P.n}" ${SW}/>`+
  `<path d="M62 74 L50 76 L62 78 Z" fill="${FMOUTH}"/>`+pt("beak",62,78,`<path d="M62 78 L50 77 L62 81 Z" fill="#E8D890" ${SW2}/>`)+`<path d="M62 71 L48 75 L62 75 Z" fill="#E8D890" ${SW2}/>${fE(72,72,4,{iris:"#8A4AE8",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 60 l4 6 l4 -6 Z" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="96" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(98,54,6)));
FORM_TITLE["Heronex"]="Jewel Bowerbird";

/* 149. Sandpit Special (iron-copper-chromium-titanium: magnets, "invented in a sandpit") — an antlion larva lying in wait at the bottom of
   its sand funnel, flicking sand with its head, huge sickle jaws snapping shut. */
addForm("Sandpit Special",{n:"#9A7A5A",a:"#E8C878",rn:"#C8D8F0",rb:"#B04A3A",ra:"#3A3A6A"},"crawl",(P,g)=>`<path d="M6 120 Q60 150 100 150 Q140 150 196 120 L196 160 L6 160 Z" fill="#E8C878" ${SW2}/>${[[40,134],[70,144],[130,144],[162,132]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.4" fill="${P.d}"/>`).join("")}`+
 [[118,130],[130,128],[142,126]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+8} ${y+10}`,P.nd,3),i*.2)).join("")+
 `<path d="M96 126 Q96 98 128 96 Q160 98 162 124 Q156 140 128 140 Q100 140 96 126 Z" fill="${P.n}" ${SW}/>${[110,122,134,146].map(x=>`<path d="M${x} 100 Q${x+4} 120 ${x} 140" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}${Array.from({length:10},(_,i)=>`<path d="M${104+i*6} ${100-Math.sin(i/9*Math.PI)*4} l-1 -5" stroke="${FI}" stroke-width="1.4"/>`).join("")}`+
 pt("head",96,122,`<path d="M66 124 Q66 108 84 106 Q100 108 102 122 Q98 134 84 134 Q68 134 66 124 Z" fill="${P.n}" ${SW}/>${fE(82,114,3,{iris:"#2A1A0A",look:[-.4,0]})}${fE(90,112,2.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("claw",70,116,`<path d="M70 116 Q50 100 34 108 Q30 114 36 114 Q50 110 66 122 Z" fill="${P.b}" ${SW2}/><path d="M44 106 l2 5 M52 106 l1 5" stroke="${FI}" stroke-width="1.4"/>`)+
  pt("claw2",70,128,`<path d="M70 128 Q50 142 34 136 Q30 130 36 130 Q50 134 66 122 Z" fill="${P.d}" ${SW2}/>`)+
  `<g class="p-glow">${[[46,92],[56,86],[38,98]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.ac}" ${SW2}/>`).join("")}</g>`)+
 fG(g,1,`<path d="M20 112 l-6 -4 M24 108 l-4 -6" stroke="${P.b}" stroke-width="2"/><circle cx="18" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="128" cy="118" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,74,6)));
FORM_TITLE["Sandpit Special"]="Sandpit Antlion";

/* 150. Quillmoor Extra (gold-nickel-silver: ceremonial keys; the extra crate in every headcount) — a pack rat that hoards keys, sitting up on
   a crate it shouldn't have, a key in its paws, whiskers twitching, cheeks working. */
addForm("Quillmoor Extra",{n:"#8A7A6A",a:"#F0E0C8",rn:"#C8D8E8",rb:"#7A3A8A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="84" y="118" width="70" height="30" rx="2" fill="#B88A50" ${SW}/><path d="M84 128 h70 M84 138 h70 M96 118 v30 M142 118 v30" stroke="#8A6030" stroke-width="2"/>`+fShadow(40,120)+
 pt("tail",136,110,fOL("M136 110 Q170 112 178 96 Q184 84 176 80",P.nd,5))+
 fLeg("legB",130,108,10,8,P.nd,P.nd,.4)+
 `<path d="M96 112 Q90 82 112 72 Q134 76 138 104 Q136 120 118 120 Q100 120 96 112 Z" fill="${P.n}" ${SW}/><path d="M104 112 Q100 94 110 86 Q120 94 120 116 Z" fill="${P.ac}"/>`+
 pt("armF",106,90,fOL("M106 90 Q94 96 92 106",P.n,5)+`<g transform="rotate(-30 90 106)"><circle cx="90" cy="106" r="5" fill="none" stroke="${FI}" stroke-width="3.6"/><circle cx="90" cy="106" r="5" fill="none" stroke="${P.b}" stroke-width="2"/><path d="M84 106 L66 106 M70 106 v5 M74 106 v4" stroke="${FI}" stroke-width="3.6"/><path d="M84 106 L66 106 M70 106 v5 M74 106 v4" stroke="${P.b}" stroke-width="2"/></g>`)+
 pt("head",112,74,`<path d="M80 72 Q82 54 102 52 Q120 54 122 70 Q118 82 102 82 Q86 82 80 72 Z" fill="${P.n}" ${SW}/><ellipse cx="80" cy="70" rx="3.4" ry="2.6" fill="#F0A0A8" ${SW2}/>`+
  `<path d="M82 74 L92 76 L90 78 Z" fill="${FMOUTH}"/>`+pt("jaw",92,77,`<path d="M92 77 L82 76 L86 80 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M86 70 l-14 -6 M86 72 l-14 0 M86 74 l-14 6" stroke="${FI}" stroke-width="1"/>${fE(98,64,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",112,56,`<circle cx="114" cy="52" r="9" fill="${P.n}" ${SW2}/><circle cx="114" cy="52" r="5" fill="#F0A0A8"/>`))+
 fG(g,1,`<path d="M30 130 l8 0 l0 -4 l4 0" stroke="${P.b}" stroke-width="3" fill="none"/><circle cx="26" cy="130" r="4" fill="none" stroke="${P.b}" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="118" cy="132" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(140,48,6)));
FORM_TITLE["Quillmoor Extra"]="Key-Hoarding Pack Rat";

/* 151. Grandma's Jam (aluminium-manganese-scandium: laptop shells; shipped in a crate marked as jam) — a red squirrel that has got into the
   jam, sitting up on a branch, tufted ears flicking, bushy tail flagging, chewing. */
addForm("Grandma's Jam",{n:"#C85A2A",a:"#F4E8D8",rn:"#8A8AA0",rb:"#3A8A6A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M20 132 Q100 124 190 136" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("tail",120,118,`<path d="M118 120 Q154 116 156 80 Q156 50 132 44 Q146 66 136 84 Q126 100 112 108 Z" fill="${P.n}" ${SW}/><path d="M124 106 Q144 92 142 66" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".6"/>`)+
 fLeg("legB",112,120,10,8,P.nd,P.nd,.4)+
 `<path d="M84 120 Q80 92 100 84 Q120 88 122 114 Q118 130 102 130 Q88 130 84 120 Z" fill="${P.n}" ${SW}/><path d="M90 120 Q88 100 98 96 Q108 104 106 126 Z" fill="${P.ac}"/>`+
 `<rect x="74" y="98" width="16" height="18" rx="3" fill="${P.b}" opacity=".85" ${SW2}/><rect x="74" y="94" width="16" height="5" rx="1" fill="#F4F0E4" ${SW2}/><path d="M76 104 Q82 100 88 104 L88 114 L76 114 Z" fill="#B0204A" opacity=".8"/>`+
 pt("armF",94,98,fOL("M94 98 L84 102",P.n,5))+
 pt("head",100,84,`<path d="M70 76 Q72 58 92 56 Q112 58 112 76 Q108 90 92 90 Q74 90 70 76 Z" fill="${P.n}" ${SW}/><path d="M72 78 Q80 72 88 80 Q82 88 74 84 Z" fill="${P.ac}"/>`+
  `<path d="M70 80 L80 80 L78 83 Z" fill="${FMOUTH}"/>`+pt("jaw",80,82,`<path d="M80 82 L70 81 L74 86 Z" fill="${P.ac}" ${SW2}/>`)+`<ellipse cx="70" cy="76" rx="2.6" ry="2" fill="${FI}"/><path d="M74 82 q2 4 4 2" stroke="#B0204A" stroke-width="2" fill="none"/>`+
  `${fE(86,70,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",98,58,`<path d="M94 60 L96 42 L104 58 Z" fill="${P.n}" ${SW2}/><path d="M96 42 l-2 -6 M96 42 l3 -6" stroke="${P.n}" stroke-width="2"/>`))+
 fG(g,1,`<path d="M40 112 q4 -6 8 0 q-4 6 -8 0" fill="#B0204A" ${SW2}/>`)+
 fG(g,2,`<circle cx="102" cy="116" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(80,40,6)));
FORM_TITLE["Grandma's Jam"]="Jam-Thief Squirrel";

/* 152. Explain Later No. 1 (tin-zinc-antimony: blocks for grinding lenses; its file is labelled "Explain Later") — a question-mark butterfly,
   the little silver hook on its wing a question nobody has answered, wings opening and closing, proboscis uncurling. */
addForm("Explain Later No. 1",{n:"#D8782A",a:"#F4F0E4",rn:"#9AC8F0",rb:"#3A3A6A",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",104,84,`<path d="M104 84 Q132 30 170 40 Q172 70 140 80 Q160 92 150 116 Q124 118 106 94 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M92 92 Q96 80 106 80 Q114 84 114 96 L122 124 Q118 128 112 124 L100 100 Q92 100 92 92 Z" fill="${P.ndd}" ${SW}/>`+
 [92,100].map((x,i)=>fLeg("legF",x,96,10,1.6,FI,null,i*.3,-3)).join("")+
 pt("wingF",100,86,`<path d="M100 86 Q80 26 34 30 Q24 64 64 80 Q34 92 44 122 Q76 126 98 96 Z" fill="${P.n}" ${SW}/>${[[60,52],[76,48],[54,98],[70,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4" fill="${P.ndd}"/>`).join("")}<path d="M56 108 Q50 100 56 96 Q62 96 60 102 L58 104 M58 110 l0 .1" stroke="${P.b}" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M38 34 Q30 60 62 80" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".6"/>`)+
 pt("head",92,88,`<circle cx="86" cy="86" r="8" fill="${P.ndd}" ${SW2}/>${fE(84,84,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",86,78,`<path d="M86 78 Q80 60 68 54" stroke="${FI}" stroke-width="1.6" fill="none"/><circle cx="68" cy="54" r="2" fill="${FI}"/>`)+pt("ant",90,78,`<path d="M90 78 Q90 60 82 50" stroke="${FI}" stroke-width="1.6" fill="none"/><circle cx="82" cy="50" r="2" fill="${FI}"/>`,.4)+
  pt("tongue",80,92,`<path d="M80 92 Q70 96 70 104 Q72 108 76 106" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<circle cx="160" cy="130" r="8" fill="none" stroke="${P.b}" stroke-width="3"/><path d="M154 124 l4 4" stroke="#FFFFFF" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,24,6)));
FORM_TITLE["Explain Later No. 1"]="Question Mark Butterfly";

/* 153. Juice Box Blend (bismuth-cadmium-tin: patching organ pipes) — a mud-dauber wasp that builds its nest as a row of organ pipes,
   carrying a ball of mud, wings buzzing, slender waist, mandibles shaping. */
addForm("Juice Box Blend",{n:"#1E1E28",a:"#F2C94C",rn:"#E8E0F0",rb:"#C04A6A",ra:"#3AC0A0"},"hover",(P,g)=>`<g>${[0,1,2,3,4].map(i=>`<rect x="${136+i*10}" y="${92-[10,26,40,22,8][i]}" width="9" height="${54+[10,26,40,22,8][i]}" rx="4" fill="${P.b}" ${SW2}/><ellipse cx="${140.5+i*10}" cy="${94-[10,26,40,22,8][i]}" rx="3" ry="1.6" fill="${FI}"/>`).join("")}</g><ellipse class="shd" cx="96" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",100,78,`<path d="M100 78 Q124 50 150 54 Q138 74 104 84 Z" fill="#E8F4FC" opacity=".6" ${SW2}/>`)+
 pt("tail",112,92,`<path d="M110 90 L116 92" stroke="${FI}" stroke-width="3"/><path d="M114 86 Q136 82 140 98 Q134 112 116 104 Z" fill="${P.n}" ${SW}/><path d="M126 86 q4 10 0 20" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 `<path d="M84 90 Q86 78 98 78 Q110 80 112 92 Q108 100 98 100 Q86 100 84 90 Z" fill="${P.n}" ${SW}/>`+
 [[88,98],[96,100],[104,98]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-4} ${y+14} L${x-8} ${y+22}`,P.ac,2),i*.2)).join("")+
 `<circle cx="84" cy="126" r="7" fill="#8A6A4A" ${SW2}/>`+
 pt("wingF",96,80,`<path d="M96 80 Q86 40 56 34 Q52 60 92 86 Z" fill="#E8F4FC" opacity=".75" ${SW2}/><path d="M92 80 Q80 56 60 40" stroke="${P.nd}" stroke-width="1" fill="none"/>`)+
 pt("head",84,88,`<circle cx="74" cy="86" r="10" fill="${P.n}" ${SW}/>${fE(72,82,4,{iris:P.ac,look:[-.4,0]})}`+
  pt("ant",72,78,`<path d="M72 78 Q62 62 54 64" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+
  `<path d="M62 90 L68 90 L66 94 Z" fill="${FMOUTH}"/>`+pt("jaw",66,92,`<path d="M66 92 L58 94 L62 98 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 90 q6 -4 12 0 q6 4 12 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="98" cy="90" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(100,48,6)));
FORM_TITLE["Juice Box Blend"]="Organ-Pipe Wasp";

/* 154. Quillmoor Vanite (silver-palladium-zinc-tin: jewellery; the morning every weather vane swung west) — a kestrel hanging motionless on
   the wind like a weather vane, wings working, tail fanned, head locked on its target. */
addForm("Quillmoor Vanite",{n:"#B8683A",a:"#5A7AB0",rn:"#E8E0D0",rb:"#3A3A4A",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/><path d="M100 150 V128 M90 128 h20" stroke="${P.b}" stroke-width="3"/><path d="M92 124 L108 124 L100 116 Z" fill="${P.b}" ${SW2}/>`+
 pt("tail",116,102,`<path d="M112 98 L144 118 Q140 128 130 128 L108 108 Z" fill="${P.n}" ${SW}/><path d="M132 120 L140 124" stroke="${FI}" stroke-width="3"/>`)+
 pt("wingB",108,78,`<path d="M108 78 Q130 30 172 22 Q160 52 120 86 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${126+i*10} ${56-i*10} l8 4" stroke="${FI}" stroke-width="1.6"/>`).join("")}`)+
 `<path d="M80 92 Q82 72 104 72 Q124 76 124 96 Q118 110 102 110 Q84 110 80 92 Z" fill="${P.n}" ${SW}/>${[[92,90],[104,96],[110,86]].map(([x,y])=>`<path d="M${x} ${y} l2 4" stroke="${FI}" stroke-width="2"/>`).join("")}`+
 `<path d="M96 108 l-4 8 M104 108 l2 8" stroke="#F2C94C" stroke-width="2.6"/>`+
 pt("wingF",100,80,`<path d="M100 80 Q70 30 24 30 Q44 62 92 90 Z" fill="${P.n}" ${SW}/><path d="M40 38 L30 34 M48 44 L36 40" stroke="${FI}" stroke-width="3"/>`)+
 pt("head",88,80,`<circle cx="80" cy="72" r="12" fill="${P.ac}" ${SW}/><path d="M74 78 Q76 86 80 84" stroke="${FI}" stroke-width="2.4" fill="none"/>`+
  `<path d="M68 70 L60 74 L68 76 Z" fill="${FMOUTH}"/>`+pt("beak",68,76,`<path d="M68 76 L62 75 L68 78 Z" fill="#E8C878" ${SW2}/>`)+`<path d="M70 68 Q60 70 60 76 L68 73 Z" fill="#E8C878" ${SW2}/>${fE(78,70,4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 90 h20 M34 98 h16" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="102" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(140,60,6)));
FORM_TITLE["Quillmoor Vanite"]="Weathervane Kestrel";

/* 155. First Prize Metal (copper-beryllium-silver-chromium: bicycle chains; a science-fair winner) — a prize pig with a rosette, trotting
   round the show ring, curly tail spinning, snout snuffling, grunting. */
addForm("First Prize Metal",{n:"#F0A8A8",a:"#3A6AD8",rn:"#5A4A4A",rb:"#E8C060",ra:"#E8412C"},"stand",(P,g)=>fShadow(60)+
 pt("tail",150,98,`<path d="M150 98 q8 -6 4 -12 q-6 -2 -4 4" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M150 98 q8 -6 4 -12 q-6 -2 -4 4" stroke="${P.n}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",138,114,24,9,P.nd,"#5A3A2A",.5)+fLeg("legB",98,114,24,9,P.nd,"#5A3A2A",1.3)+
 `<path d="M70 104 Q70 74 110 72 Q150 74 156 102 Q150 124 112 124 Q74 124 70 104 Z" fill="${P.n}" ${SW}/><path d="M80 116 Q112 128 146 116" stroke="${P.nl}" stroke-width="5" fill="none"/>`+
 `<circle cx="96" cy="96" r="8" fill="${P.ac}" ${SW2}/>${Array.from({length:8},(_,i)=>`<circle cx="${96+Math.cos(i*.785)*8}" cy="${96+Math.sin(i*.785)*8}" r="2.6" fill="${P.ac}" ${SW2}/>`).join("")}<circle cx="96" cy="96" r="4.6" fill="${P.b}" ${SW2}/><path d="M94 104 l-3 12 l4 -3 l3 3 l-1 -12" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",128,116,22,9,P.n,"#5A3A2A",0)+fLeg("legF",86,116,22,9,P.n,"#5A3A2A",.8)+
 pt("head",76,94,`<path d="M42 98 Q42 74 62 72 Q82 74 84 96 Q80 110 62 110 Q44 110 42 98 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M34 96 Q34 88 42 88 Q48 92 46 102 Q40 106 34 102 Z" fill="${P.nl}" ${SW2}/><circle cx="37" cy="94" r="1.4" fill="${FI}"/><circle cx="37" cy="99" r="1.4" fill="${FI}"/>`+
  `<path d="M44 104 L56 106 L54 109 Z" fill="${FMOUTH}"/>`+pt("jaw",56,108,`<path d="M56 108 Q50 114 44 108 Q50 111 56 110 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(58,88,4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",68,76,`<path d="M64 78 Q62 62 76 64 Q76 74 70 80 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M168 134 q6 -6 12 0 q6 6 12 0" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,54,6)));
FORM_TITLE["First Prize Metal"]="Rosette Pig";

/* 156. Wager Pie Metal (copper-nickel-aluminium-silver: boat cleats) — a gannet plunge-diving, wings folding back into an arrow, then
   bobbing up with its long bill clattering. */
addForm("Wager Pie Metal",{n:"#F4F0E4",a:"#F2D890",rn:"#2E3A5A",rb:"#B04A3A",ra:"#5FE0F0"},"hover",(P,g)=>`<path d="M10 140 Q60 134 100 140 Q150 146 190 138" stroke="#8AB4D8" stroke-width="3" fill="none"/><ellipse class="shd" cx="100" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 `<path d="M150 138 l8 -10 h12 l8 10 Z" fill="${P.b}" ${SW2}/><path d="M154 128 h20" stroke="${P.d}" stroke-width="4" stroke-linecap="round"/>`+
 pt("tail",122,84,`<path d="M118 80 L150 70 L146 84 L120 90 Z" fill="${P.n}" ${SW2}/>`)+
 pt("wingB",108,80,`<path d="M108 80 Q140 40 176 44 Q160 66 116 88 Z" fill="${P.n}" ${SW}/><path d="M150 50 L176 44 L164 60 Z" fill="${FI}"/>`)+
 `<path d="M78 92 Q82 76 104 76 Q124 78 126 90 Q118 102 100 102 Q82 102 78 92 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,88,`<path d="M100 88 Q66 110 30 104 Q58 86 94 82 Z" fill="${P.n}" ${SW}/><path d="M30 104 L48 100 L42 108 Z" fill="${FI}"/>`)+
 pt("head",82,88,`<circle cx="74" cy="82" r="11" fill="${P.ac}" ${SW}/>`+
  `<path d="M64 82 L36 92 L64 88 Z" fill="${FMOUTH}"/>`+pt("beak",64,88,`<path d="M64 88 L38 93 L64 91 Z" fill="#A8B0C0" ${SW2}/>`)+`<path d="M64 78 L34 90 L64 84 Z" fill="#A8B0C0" ${SW2}/><path d="M60 80 L68 84" stroke="${FI}" stroke-width="2"/>${fE(72,78,3.4,{iris:"#8AC8F0",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M40 128 l4 -6 l4 6" stroke="#8AB4D8" stroke-width="2" fill="none"/><circle cx="58" cy="124" r="2.4" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="90" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,56,6)));
FORM_TITLE["Wager Pie Metal"]="Plunging Gannet";

/* 157. Fourth Floor Metal (copper-aluminium-nickel: valve bodies and door hinges) — a scallop, the original hinged valve: it swims by
   clapping its two shells, a fringe of bright blue eyes along the lip. */
addForm("Fourth Floor Metal",{n:"#E8A070",a:"#3A8AE8",rn:"#C8E0D0",rb:"#7A3A8A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/><g class="p-glow">${[[150,50],[160,64],[146,36]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`).join("")}</g>`+
 `<path d="M66 104 Q60 72 100 62 Q140 72 134 104 Z" fill="${P.nd}" ${SW}/>`+
 `<path d="M68 104 Q100 110 132 104 L130 112 Q100 116 70 112 Z" fill="${FMOUTH}"/>`+[0,1,2,3,4,5,6].map(i=>fE(74+i*8.6,106+Math.sin(i/6*Math.PI)*2,2.6,{iris:P.ac,look:[0,.2]})).join("")+
 pt("jaw",134,110,`<path d="M66 112 Q60 140 100 142 Q140 140 134 112 Q100 120 66 112 Z" fill="${P.n}" ${SW}/>${[78,90,100,110,122].map(x=>`<path d="M100 140 L${x} ${116}" stroke="${P.nd}" stroke-width="2"/>`).join("")}<path d="M90 140 h20 v6 h-20 Z" fill="${P.b}" ${SW2}/>`)+
 pt("head",134,104,`<path d="M66 104 Q60 72 100 62 Q140 72 134 104 Q100 96 66 104 Z" fill="${P.n}" ${SW}/>${[74,86,100,114,126].map(x=>`<path d="M100 64 L${x} 100" stroke="${P.nl}" stroke-width="3"/>`).join("")}<path d="M90 56 h20 v8 h-20 Z" fill="${P.b}" ${SW2}/><circle cx="94" cy="60" r="1.4" fill="${P.dd}"/><circle cx="106" cy="60" r="1.4" fill="${P.dd}"/>`)+
 fG(g,1,`<path d="M30 80 q6 -4 12 0 M26 92 q8 -4 16 0" stroke="#8AB4D8" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="100" cy="80" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,40,6)));
FORM_TITLE["Fourth Floor Metal"]="Clapping Scallop";

/* 158. Closetium (iron-copper-chromium-niobium: strain gauges; traced back to the supply closet) — a house cat squeezed into a box in the
   supply closet, ears swivelling, tail flicking over the edge, a yawn wide enough to see every tooth. */
addForm("Closetium",{n:"#E8A858",a:"#F4F0E4",rn:"#5A5A6A",rb:"#3A8A8A",ra:"#E8604A"},"stand",(P,g)=>`<path d="M60 108 L140 108 L144 148 L56 148 Z" fill="#C89A60" ${SW}/><path d="M60 108 L44 92 L64 96 Z M140 108 L156 92 L136 96 Z" fill="#A87A40" ${SW2}/><path d="M80 120 h40" stroke="#8A6030" stroke-width="2"/>`+fShadow(46)+
 pt("tail",136,108,fOL("M136 108 Q160 100 162 120 Q164 132 154 136",P.n,7)+`<path d="M158 112 l6 2 M160 122 l6 0" stroke="${P.nd}" stroke-width="2"/>`)+
 `<path d="M74 110 Q74 90 100 88 Q126 90 126 110 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",82,108,`<path d="M74 108 Q72 116 82 116 Q90 116 88 108 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("head",100,92,`<path d="M74 82 Q74 58 100 56 Q126 58 126 82 Q122 98 100 100 Q78 98 74 82 Z" fill="${P.n}" ${SW}/>${[88,96,104,112].map(x=>`<path d="M${x} 58 l2 8" stroke="${P.nd}" stroke-width="2.4"/>`).join("")}`+
  `<path d="M86 84 Q100 92 114 84 Q112 98 100 98 Q88 98 86 84 Z" fill="${P.ac}"/><path d="M98 82 L102 82 L100 85 Z" fill="#F0A0A8" ${SW2}/>`+
  `<path d="M92 88 L108 88 L106 92 L94 92 Z" fill="${FMOUTH}"/><path d="M94 88 l1.4 3 l1.4 -3 M104 88 l1.4 3 l1.4 -3" fill="#FFFFFF"/>`+pt("jaw",108,90,`<path d="M108 90 Q100 98 92 90 Q100 94 108 92 Z" fill="${P.ac}" ${SW2}/>`)+
  `${fE(90,74,4.4,{iris:"#7AC040",look:[-.3,0]})}${fE(110,74,4.4,{iris:"#7AC040",look:[-.3,0]})}<path d="M90 82 l-14 -2 M90 84 l-14 2 M110 82 l14 -2 M110 84 l14 2" stroke="${FI}" stroke-width="1"/>`+
  pt("ear",80,62,`<path d="M76 66 L76 44 L90 58 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",120,62,`<path d="M124 66 L124 44 L110 58 Z" fill="${P.n}" ${SW2}/>`,.5))+
 fG(g,1,`<rect x="20" y="126" width="22" height="22" rx="2" fill="#C89A60" ${SW2}/><path d="M24 132 h14" stroke="#8A6030" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="100" cy="128" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(144,60,6)));
FORM_TITLE["Closetium"]="Supply-Closet Cat";

/* 159. Favorite Cloud Mix (nickel-aluminium-molybdenum-tungsten: glass-furnace stirrers; page 19 of the form asks your favourite cloud) — a
   sulphur-crested cockatoo, cloud-white, crest flaring up like a cumulus, bobbing and screeching. */
addForm("Favorite Cloud Mix",{n:"#F4F4F8",a:"#F2D040",rn:"#E8A8C0",rb:"#3A6AB0",ra:"#E8412C"},"perch",(P,g)=>`<path d="M20 126 Q100 118 186 130" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/>${[[160,40,14],[176,48,10],[146,46,10]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#FFFFFF" opacity=".8" ${SW2}/>`).join("")}`+
 pt("tail",120,112,`<path d="M116 106 L150 136 L140 142 L112 116 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M84 108 Q82 80 106 76 Q128 80 128 108 Q122 124 106 124 Q88 124 84 108 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,92,`<path d="M104 88 Q130 86 134 110 Q118 116 106 106 Z" fill="${P.n}" ${SW2}/><path d="M118 104 q6 4 12 4" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".6"/>`)+
 `<path d="M96 122 l-4 6 M104 122 l2 6" stroke="#5A5A62" stroke-width="3"/>`+
 pt("head",100,80,`<circle cx="92" cy="70" r="15" fill="${P.n}" ${SW}/>`+
  pt("ear",100,58,`<path d="M100 60 Q90 30 96 18 Q104 34 106 54 Q108 30 120 22 Q118 44 108 62 Z" fill="${P.ac}" ${SW2}/><path d="M98 58 Q84 40 80 30 Q92 40 100 56 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M78 70 Q70 70 70 78 L78 78 Z" fill="${FMOUTH}"/>`+pt("beak",80,78,`<path d="M80 78 L72 78 Q72 84 80 84 Z" fill="#3A3A44" ${SW2}/>`)+`<path d="M80 64 Q66 66 66 76 Q70 80 72 76 Q72 70 80 72 Z" fill="#3A3A44" ${SW2}/>${fE(90,66,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 70 l6 -4 M30 80 l8 0" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="106" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(60,40,6)));
FORM_TITLE["Favorite Cloud Mix"]="Cumulus Cockatoo";

/* 160. Robot No. 4 Special (magnesium-nickel with neon: a robot invented it and tried to name it) — a lobster with neon-lit joints and a
   faceplate, one crusher claw and one cutter claw that snap independently, antennae sweeping. */
addForm("Robot No. 4 Special",{n:"#3A4A6A",a:"#FF5AC8",rn:"#E8D8B0",rb:"#C04A3A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",150,112,`${[0,1,2,3].map(i=>`<rect x="${144+i*10}" y="${104+i*2}" width="12" height="${18-i*2}" rx="3" fill="${P.n}" ${SW2}/>`).join("")}<path d="M184 108 L196 100 L194 124 L184 118 Z" fill="${P.nd}" ${SW2}/>`)+
 [[118,124],[128,126],[138,124]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+6} ${y+10} L${x+2} 140`,P.nd,2.4),i*.2)).join("")+
 `<path d="M90 114 Q92 98 120 96 Q146 98 148 114 Q144 128 120 128 Q94 128 90 114 Z" fill="${P.n}" ${SW}/><path d="M100 104 L140 106" stroke="${P.b}" stroke-width="3"/>${[104,118,132].map(x=>`<circle cx="${x}" cy="116" r="2.4" fill="${P.ac}" class="p-glow"/>`).join("")}`+
 pt("claw",92,108,fOL("M92 108 L70 92",P.nd,5)+`<circle cx="70" cy="92" r="3" fill="${P.ac}"/><path d="M70 92 Q52 72 34 76 Q40 86 56 88 L40 92 Q56 102 70 96 Z" fill="${P.n}" ${SW}/>`)+
 pt("claw2",94,120,fOL("M94 120 L72 130",P.nd,4)+`<path d="M72 130 Q56 128 46 136 L72 136 Z" fill="${P.n}" ${SW2}/><path d="M72 132 Q60 140 48 140" stroke="${FI}" stroke-width="2.4" fill="none"/>`,.6)+
 pt("head",96,108,`<path d="M74 108 Q76 96 92 96 L98 112 Q86 118 74 108 Z" fill="${P.n}" ${SW}/><rect x="78" y="100" width="14" height="7" rx="2" fill="#1E2238" ${SW2}/><rect x="80" y="102" width="4" height="3" fill="${P.ac}" class="p-glow"/><rect x="86" y="102" width="4" height="3" fill="${P.ac}" class="p-glow"/>`+
  pt("ant",80,98,`<path d="M80 98 Q60 66 30 60 M84 98 Q72 70 52 54" stroke="${P.ac}" stroke-width="1.6" fill="none"/>`)+
  `<path d="M74 110 L82 112 L80 114 Z" fill="${FMOUTH}"/>`+pt("jaw",82,113,`<path d="M82 113 L74 114 L78 117 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 l6 -6 M20 128 l8 0" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(120,76,6)));
FORM_TITLE["Robot No. 4 Special"]="Neon-Joint Lobster";

/* 161. Rafterine (copper-ytterbium: sensor prototypes; the swallows that come back to the same rafter every April) — a barn swallow on a
   rafter, long forked tail streamers, wings flicking, beak opening wide in a twitter. */
addForm("Rafterine",{n:"#2A3A7A",a:"#E8603A",rn:"#E8E0D0",rb:"#3A8A6A",ra:"#E8412C"},"perch",(P,g)=>`<rect x="10" y="114" width="180" height="12" fill="#7A5A3A" ${SW}/><path d="M10 120 h180" stroke="#5A3A20" stroke-width="1.6"/><path d="M140 114 q8 -14 20 -14 q12 0 16 14 Z" fill="#9A7A5A" ${SW2}/>`+
 pt("tail",116,104,`<path d="M112 100 L164 128 L150 112 L170 132 L110 108 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 100 Q80 82 100 80 Q120 84 120 100 Q114 112 100 112 Q84 112 80 100 Z" fill="${P.n}" ${SW}/><path d="M84 104 Q90 96 104 98 Q112 106 104 112 Q90 112 84 104 Z" fill="#F4E8D8"/>`+
 pt("wingF",104,90,`<path d="M96 88 Q130 84 150 100 Q124 104 100 100 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M94 110 l-2 4 M102 110 l0 4" stroke="${FI}" stroke-width="2"/>`+
 pt("head",88,86,`<circle cx="84" cy="80" r="11" fill="${P.n}" ${SW}/><path d="M74 84 Q80 92 88 88 Q86 82 76 80 Z" fill="${P.ac}"/>`+
  `<path d="M74 78 L64 80 L74 82 Z" fill="${FMOUTH}"/>`+pt("beak",74,82,`<path d="M74 82 L64 81 L74 84 Z" fill="${FI}" ${SW2}/>`)+`<path d="M74 76 L62 80 L74 79 Z" fill="${FI}" ${SW2}/>${fE(82,76,3.2,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 60 q6 -6 12 0 q6 -6 12 0 M60 40 q4 -4 8 0 q4 -4 8 0" stroke="${P.n}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="100" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,56,6)));
FORM_TITLE["Rafterine"]="Rafter Swallow";

/* 162. Corridor Blend (nickel with tennessine: legendary, only ever simulated; the night guards' ghost who still walks the corridors) — an
   aye-aye with a lantern, haunting the halls, enormous ears turning, one long bony finger tapping on the walls. */
addForm("Corridor Blend",{n:"#3A3A44",a:"#E8F0A0",rn:"#E8E4F4",rb:"#7A4AA8",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M14 136 Q100 128 190 140" stroke="#5A4A3A" stroke-width="8" fill="none" stroke-linecap="round"/><circle class="p-glow" cx="52" cy="104" r="24" fill="${P.ac}" opacity=".25"/>`+
 pt("tail",126,120,`<path d="M124 118 Q160 110 172 76 Q178 56 166 48 Q164 72 150 90 Q138 106 120 110 Z" fill="${P.n}" ${SW}/>${[[150,92],[160,76],[166,62]].map(([x,y])=>`<path d="M${x} ${y} l6 -2" stroke="${P.nl}" stroke-width="2"/>`).join("")}`)+
 fLeg("legB",118,124,10,7,P.nd,P.nd,.4)+
 `<path d="M86 124 Q82 94 104 88 Q126 92 126 120 Q122 134 106 134 Q90 134 86 124 Z" fill="${P.n}" ${SW}/>${[[96,104],[110,100],[104,116]].map(([x,y])=>`<path d="M${x} ${y} l2 -6" stroke="${P.nl}" stroke-width="1.6"/>`).join("")}`+
 pt("armF",92,104,fOL("M92 104 L70 104",P.n,5)+`<path d="M70 104 L54 98" stroke="${FI}" stroke-width="2.4"/><path d="M54 98 L50 104" stroke="${FI}" stroke-width="1.4"/><path d="M60 96 L60 112" stroke="${P.b}" stroke-width="2"/><rect x="52" y="112" width="16" height="16" rx="3" fill="${P.ac}" opacity=".85" ${SW2}/><path d="M52 112 h16 M54 110 h12" stroke="${P.b}" stroke-width="2.4"/>`)+
 pt("head",104,88,`<path d="M80 82 Q80 62 102 60 Q122 62 122 82 Q118 96 102 96 Q84 96 80 82 Z" fill="${P.n}" ${SW}/><path d="M84 84 Q92 78 100 86 Q94 94 86 92 Z" fill="${P.nll}"/>`+
  `${fE(94,76,6,{iris:P.ac,look:[-.4,0]})}${fE(110,76,5.4,{iris:P.ac,look:[-.4,0]})}<ellipse cx="82" cy="86" rx="3" ry="2.4" fill="#F0A0A8" ${SW2}/>`+
  `<path d="M82 90 L92 92 L90 94 Z" fill="${FMOUTH}"/>`+pt("jaw",92,93,`<path d="M92 93 L82 92 L86 96 Z" fill="${P.nll}" ${SW2}/>`)+
  pt("ear",92,62,`<path d="M92 64 Q72 40 84 26 Q100 34 98 62 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",116,64,`<path d="M114 64 Q128 38 144 44 Q140 62 120 70 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M20 40 q6 -8 12 0 q6 8 12 0" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,2,`<circle cx="106" cy="118" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(150,30,6)));
FORM_TITLE["Corridor Blend"]="Night-Watch Aye-Aye";

/* 163. Sealbreaker (tungsten-hafnium-tantalum-rhenium-osmium: cast for one job, cutting the founder's seal) — a musk ox, the heaviest head
   in the Institute's book: a boss of horn like a battering ram, lowered to charge, shaggy skirt swinging. */
addForm("Sealbreaker",{n:"#4A3A2E",a:"#E8E0C8",rn:"#C8D0E0",rb:"#8A3A2A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(70)+
 pt("tail",160,94,`<path d="M158 92 Q166 94 164 104 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",146,112,32,10,P.nd,P.ac,.5)+fLeg("legB",104,112,32,10,P.nd,P.ac,1.3)+
 `<path d="M76 104 Q72 64 118 62 Q160 66 164 100 Q160 120 120 122 Q82 122 76 104 Z" fill="${P.n}" ${SW}/><path d="M96 66 Q118 56 140 66 Q130 72 110 72 Z" fill="${P.ac}" opacity=".7"/>`+
 pt("sway",120,114,`<path d="M78 108 Q80 132 92 128 Q96 136 106 130 Q114 138 124 130 Q134 138 142 130 Q152 134 160 112 Q120 124 78 108 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legF",134,116,28,10,P.n,P.ac,0)+fLeg("legF",92,116,28,10,P.n,P.ac,.8)+
 pt("head",84,90,`<path d="M40 104 L58 106 L56 110 L44 108 Z" fill="${FMOUTH}"/>`+pt("jaw",58,109,`<path d="M58 109 Q50 116 42 108 Q50 112 58 112 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M38 100 Q38 80 58 78 Q80 80 84 98 Q80 112 60 112 Q42 112 38 100 Z" fill="${P.n}" ${SW}/><path d="M38 102 Q40 96 46 98 Q46 106 40 106 Z" fill="${P.ac}"/>`+
  `<path d="M46 76 Q60 64 80 72 Q90 80 86 96 Q80 86 72 86 Q64 78 52 84 Z" fill="${P.b}" ${SW}/><path d="M52 80 Q64 72 78 78" stroke="${P.ll}" stroke-width="2" fill="none"/><path d="M50 84 Q40 92 44 104" stroke="${P.b}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M50 84 Q40 92 44 104" stroke="${FI}" stroke-width="1.4" fill="none" opacity=".6"/>`+
  `${fE(60,92,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M14 120 l10 -4 l-4 10 l10 -2" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="94" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(120,44,6)));
FORM_TITLE["Sealbreaker"]="Battering Musk Ox";

/* 164. Jestiphonatacicis (sodium-uranium-iodine-francium: sealed in its vial; "Do not open. Do not shake. Do not ask.") — a bombardier
   beetle, which answers being shaken with a boiling blast from its rear: hunched, tail aimed, jaws working, steam leaking out. */
addForm("Jestiphonatacicis",{n:"#2A3A4A",a:"#FFB040",rn:"#E8E0C8",rb:"#9BE05A",ra:"#E8412C"},"crawl",(P,g)=>fShadow(58)+
 `<g class="p-glow">${[[166,92,6],[178,84,4],[184,98,5],[172,74,3]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.ac}" opacity=".6"/>`).join("")}</g>`+
 pt("tail",150,110,`<path d="M146 104 L162 98 L164 112 L148 116 Z" fill="${P.b}" ${SW2}/>`)+
 [[110,120],[124,122],[138,120]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+8} ${y+10} L${x+6} 140`,P.nd,3),i*.2)).join("")+
 `<path d="M92 112 Q92 82 124 80 Q154 82 156 110 Q152 124 124 124 Q96 124 92 112 Z" fill="${P.n}" ${SW}/><path d="M124 80 V124" stroke="${P.ndd}" stroke-width="2"/><path d="M100 96 Q124 84 150 96" stroke="${P.b}" stroke-width="3" fill="none"/><path d="M108 108 L118 104 M130 104 L140 108" stroke="${P.ac}" stroke-width="2.4"/>`+
 [[96,120],[106,122]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-10} ${y+10} L${x-8} 140`,P.n,3),i*.2)).join("")+
 pt("head",94,106,`<path d="M66 108 Q66 94 80 92 Q96 94 98 108 Q94 118 82 118 Q68 118 66 108 Z" fill="${P.b}" ${SW}/>${fE(78,102,3.8,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",76,94,`<path d="M76 94 Q62 76 46 74" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+
  pt("claw",68,108,`<path d="M68 106 Q56 100 52 104 Q58 106 66 110 Z" fill="${P.d}" ${SW2}/>`)+pt("claw2",68,112,`<path d="M68 114 Q56 120 52 116 Q58 114 66 110 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<rect x="20" y="104" width="14" height="30" rx="5" fill="#E8F4FC" opacity=".7" ${SW2}/><rect x="20" y="100" width="14" height="6" rx="1" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="124" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(124,62,6)));
FORM_TITLE["Jestiphonatacicis"]="Do-Not-Shake Beetle";

/* ---------------- the Slag Works ---------------- */

/* 165. Tipheap (Friday's leftovers from the tip hopper: ore-tub ballast and bunkhouse doorstops) — a squat warty toad that sits like a
   doorstop and will not be moved, throat pulsing, eyes bulging, mouth cracking wide to swallow. */
addForm("Tipheap",{n:"#8A7A4A",a:"#E8C878",rn:"#C8B8D8",rb:"#3A6A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(60)+
 fLeg("legB",138,122,18,10,P.nd,P.nd,.5,6)+
 `<path d="M58 126 Q56 88 100 84 Q146 86 150 124 Q144 140 102 140 Q62 140 58 126 Z" fill="${P.n}" ${SW}/>${[[80,98],[96,92],[114,94],[130,102],[88,112],[108,108],[126,116],[140,112]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="${3+i%3}" fill="${P.nd}" ${SW2}/>`).join("")}<path d="M64 128 Q100 140 144 128" stroke="${P.ac}" stroke-width="6" fill="none" opacity=".8"/>`+
 pt("legF",78,128,fOL("M78 126 L70 142",P.n,9)+`<path d="M64 144 h14" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("head",70,110,`<path d="M30 108 Q32 86 58 86 Q80 88 82 108 Q78 124 56 124 Q34 124 30 108 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M30 112 Q56 118 80 112 L80 116 Q56 122 32 116 Z" fill="${FMOUTH}"/>`+pt("jaw",80,116,`<path d="M80 116 Q56 132 30 114 Q56 124 80 120 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M30 110 Q56 116 82 108" stroke="${FI}" stroke-width="2.4" fill="none"/>${fE(48,88,6,{iris:"#C8A040",look:[-.4,0],lid:.3,lidC:P.n})}${fE(68,86,5.4,{iris:"#C8A040",look:[-.4,0],lid:.3,lidC:P.n})}`)+
 fG(g,1,`<path d="M164 146 l8 -16 l14 0 l4 16 Z" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,66,6)));
FORM_TITLE["Tipheap"]="Doorstop Toad";

/* 166. Benchgrit (manganese-silicon iron: the scraper blades the first-bench crew cast for themselves) — a sturgeon, armour scutes along
   its back like scraper edges, shovel snout dredging the bottom, a mouth that drops down to hoover. */
addForm("Benchgrit",{n:"#6A6A5A",a:"#E8E4DA",rn:"#E8C8A0",rb:"#3A7AA8",ra:"#E8412C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="66" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",164,96,`<path d="M160 92 L190 66 L184 98 L188 110 L160 104 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M40 102 Q46 82 100 80 Q150 82 166 98 Q150 116 100 118 Q50 116 40 102 Z" fill="${P.n}" ${SW}/><path d="M50 108 Q100 120 156 106" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".6"/>`+
 [64,80,96,112,128,144].map(x=>`<path d="M${x-6} ${84-(x>140?-2:0)} L${x} ${74} L${x+6} ${84} Z" fill="${P.b}" ${SW2}/>`).join("")+[70,90,110,130].map(x=>`<path d="M${x-4} 100 L${x} 96 L${x+4} 100 L${x} 104 Z" fill="${P.b}" ${SW2}/>`).join("")+
 pt("fin",88,110,`<path d="M86 108 Q80 126 66 130 Q70 116 78 108 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",46,98,`<path d="M46 92 L10 96 Q6 100 12 102 L46 104 Z" fill="${P.b}" ${SW}/><path d="M24 102 l0 6 M30 102 l0 6" stroke="${FI}" stroke-width="1.4"/>`+
  `<path d="M34 104 L46 104 L44 108 L36 108 Z" fill="${FMOUTH}"/>`+pt("jaw",46,107,`<path d="M46 107 Q40 116 34 108 Q40 112 46 110 Z" fill="${P.nl}" ${SW2}/>`)+`${fE(54,92,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M10 130 l10 -4 l4 6 l10 -4" stroke="#8A8A8A" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,54,6)));
FORM_TITLE["Benchgrit"]="Scraper Sturgeon";

/* 167. Tallyrod (lead-antimony-tin: Nan Briggs keeps the market's debts in tally marks with it) — a zebra whose stripes are rows of
   tally marks, kicking up its heels, mane bristling, braying. */
addForm("Tallyrod",{n:"#F4F0E4",a:"#2A2A34",rn:"#2A2A34",rb:"#C04A3A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(58,112)+
 pt("tail",158,92,fOL("M158 92 Q166 108 162 122",P.n,3)+`<path d="M158 118 l4 12 l4 -12 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",146,108,34,8,P.n,P.ac,.5)+fLeg("legB",106,108,34,8,P.n,P.ac,1.3)+
 `<path d="M90 100 Q90 76 122 76 Q156 78 160 100 Q156 116 124 116 Q94 116 90 100 Z" fill="${P.n}" ${SW}/>`+
 [[100,80],[126,78],[146,84]].map(([x,y])=>`${[0,1,2,3].map(i=>`<path d="M${x+i*4} ${y} l0 ${18-i}" stroke="${P.ac}" stroke-width="2.2"/>`).join("")}<path d="M${x-2} ${y+12} L${x+16} ${y+4}" stroke="${P.b}" stroke-width="2.2"/>`).join("")+
 fLeg("legF",136,112,30,8,P.n,P.ac,0)+fLeg("legF",98,112,30,8,P.n,P.ac,.8)+
 pt("head",96,88,fOL("M98 92 Q86 74 84 56",P.n,13)+`${[0,1,2].map(i=>`<path d="M${80+i*3} ${84-i*10} l10 -2" stroke="${P.ac}" stroke-width="2.4"/>`).join("")}`+
  pt("ear",86,52,`<path d="M88 52 Q92 44 100 48 L96 74 Q90 70 88 60 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M50 56 L66 58 L64 62 L54 60 Z" fill="${FMOUTH}"/>`+pt("jaw",66,62,`<path d="M66 62 Q58 70 50 62 Q58 66 66 66 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M48 54 Q50 40 68 38 Q86 40 88 54 Q84 64 68 62 Q52 62 48 54 Z" fill="${P.n}" ${SW}/><path d="M48 54 Q52 48 58 52 Q56 60 50 60 Z" fill="${P.ac}"/>${[60,68,76].map(x=>`<path d="M${x} 42 l0 8" stroke="${P.ac}" stroke-width="2"/>`).join("")}${fE(72,48,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",80,40,`<path d="M78 42 L80 26 L88 40 Z" fill="${P.n}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M20 120 l0 14 M26 120 l0 14 M32 120 l0 14 M38 120 l0 14 M16 132 L42 122" stroke="${P.b}" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,56,6)));
FORM_TITLE["Tallyrod"]="Tally Zebra";

/* 168. Hopper's Due (zinc-aluminium: a crate of stolen toy cars, melted down; the wheels didn't melt) — a wheel bug, the beetle-like
   assassin bug with a cogwheel crest on its back, stalking on long legs, its stabbing beak swinging down. */
addForm("Hopper's Due",{n:"#5A5A4A",a:"#E8604A",rn:"#C8E0F0",rb:"#C08A3A",ra:"#3A3A6A"},"crawl",(P,g)=>fShadow(60)+
 [[118,112],[132,112],[146,110]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+10} ${y+14} L${x+8} 140`,P.nd,2.6),i*.2)).join("")+
 `<path d="M90 108 Q92 86 128 84 Q160 86 164 106 Q156 120 128 120 Q96 120 90 108 Z" fill="${P.n}" ${SW}/><path d="M100 106 L160 104" stroke="${P.nd}" stroke-width="2"/>`+
 pt("slow",112,80,`<circle cx="112" cy="80" r="14" fill="${P.b}" ${SW}/>${Array.from({length:10},(_,i)=>`<rect x="109" y="62" width="6" height="7" rx="1" fill="${P.b}" ${SW2} transform="rotate(${i*36} 112 80)"/>`).join("")}<circle cx="112" cy="80" r="14" fill="${P.b}"/><circle cx="112" cy="80" r="5" fill="${FI}"/><circle cx="112" cy="80" r="2" fill="${P.ll}"/>`)+
 [[98,116],[108,118]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-10} ${y+12} L${x-10} 140`,P.n,2.6),i*.2)).join("")+
 pt("head",92,104,`<path d="M66 104 Q68 92 84 92 Q98 94 98 106 Q94 116 82 116 Q68 114 66 104 Z" fill="${P.n}" ${SW}/>${fE(76,98,3.6,{iris:P.ac,look:[-.4,0]})}`+
  pt("ant",76,92,`<path d="M76 92 Q66 72 52 70" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+
  pt("beak",70,108,`<path d="M70 106 L46 126 L50 128 L72 110 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="140" r="6" fill="${FI}"/><circle cx="30" cy="140" r="3" fill="${P.b}"/><circle cx="46" cy="140" r="6" fill="${FI}"/><circle cx="46" cy="140" r="3" fill="${P.b}"/>`)+
 fG(g,2,`<circle cx="134" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(140,56,6)));
FORM_TITLE["Hopper's Due"]="Cogcrest Wheel Bug";

/* 169. Kettlebone (aluminium alloy: Cook Mags's kettle lids and one very dented ladle) — a roseate spoonbill wading, sweeping its ladle of a
   bill side to side through the water, then lifting it to clap. */
addForm("Kettlebone",{n:"#F0A0B8",a:"#E8412C",rn:"#C8E0D8",rb:"#7A3A8A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M10 140 Q60 134 100 140 Q150 146 190 138" stroke="#8AB4D8" stroke-width="3" fill="none"/>`+fShadow(36,118)+
 fLeg("legB",126,108,36,3,"#C84A6A",null,0,6)+fLeg("legF",114,108,36,3,"#C84A6A",null,0,-2)+
 pt("tail",150,94,`<path d="M146 90 L170 98 L164 106 L144 100 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M100 96 Q102 74 126 74 Q152 78 152 98 Q146 112 124 112 Q102 112 100 96 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",126,88,`<path d="M110 84 Q144 76 160 98 Q134 106 114 98 Z" fill="${P.nd}" ${SW2}/><path d="M118 86 Q132 82 144 86" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 pt("head",104,90,fOL("M106 92 Q86 86 86 66 Q86 54 78 50",P.n,7)+
  `<path d="M66 48 Q66 38 78 38 Q90 40 90 50 Q86 58 78 58 Q68 58 66 48 Z" fill="${P.n}" ${SW}/><path d="M68 44 Q74 40 82 42" stroke="#E8C878" stroke-width="3" fill="none"/>`+
  `<path d="M68 48 L36 54 L68 52 Z" fill="${FMOUTH}"/>`+pt("beak",68,52,`<path d="M68 52 L40 54 Q26 56 28 62 Q38 64 44 58 L68 55 Z" fill="${P.b}" ${SW2}/>`)+`<path d="M68 46 L40 50 Q24 50 26 56 Q38 60 44 54 L68 50 Z" fill="${P.b}" ${SW2}/>${fE(76,46,3.4,{iris:"#E8412C",look:[-.4,0]})}`)+
 fG(g,1,`<ellipse cx="40" cy="132" rx="10" ry="4" fill="none" stroke="#8AB4D8" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="126" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(132,52,6)));
FORM_TITLE["Kettlebone"]="Ladle Spoonbill";

/* 170. Nightcart (copper-zinc from stolen door handles and knockers) — a donkey hauling the night cart, a door knocker hanging off its
   harness, long ears swivelling, braying hee-haw with its whole head. */
addForm("Nightcart",{n:"#8A8A90",a:"#F4F0E4",rn:"#C89A6A",rb:"#3A5A8A",ra:"#E8412C"},"stand",(P,g)=>`<rect x="150" y="90" width="44" height="30" rx="3" fill="#6A4A2A" ${SW}/><circle cx="172" cy="128" r="12" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="172" cy="128" r="12" fill="none" stroke="#8A6A3A" stroke-width="3"/><path d="M150 100 L132 96" stroke="#6A4A2A" stroke-width="4"/>`+fShadow(54,110)+
 pt("tail",146,92,fOL("M146 92 Q154 104 150 116",P.nd,3)+`<path d="M148 114 l2 10 l4 -10 Z" fill="${FI}"/>`)+
 fLeg("legB",138,108,34,8,P.nd,FI,.5)+fLeg("legB",100,108,34,8,P.nd,FI,1.3)+
 `<path d="M84 100 Q84 76 114 76 Q144 78 148 100 Q144 116 116 116 Q88 116 84 100 Z" fill="${P.n}" ${SW}/><path d="M92 106 Q116 116 142 106" stroke="${P.ac}" stroke-width="5" fill="none"/><path d="M96 78 Q96 100 100 114" stroke="#6A4A2A" stroke-width="5" fill="none"/>`+
 `<circle cx="100" cy="98" r="7" fill="none" stroke="${FI}" stroke-width="4.4"/><circle cx="100" cy="98" r="7" fill="none" stroke="${P.b}" stroke-width="2.6"/><circle cx="100" cy="90" r="3" fill="${P.b}" ${SW2}/>`+
 fLeg("legF",130,110,32,8,P.n,FI,0)+fLeg("legF",92,110,32,8,P.n,FI,.8)+
 pt("head",92,88,fOL("M94 90 Q82 76 78 62",P.n,12)+`<path d="M82 60 Q90 70 94 86" stroke="${FI}" stroke-width="4" fill="none"/>`+
  `<path d="M44 64 L60 66 L58 70 L48 68 Z" fill="${FMOUTH}"/>`+pt("jaw",60,70,`<path d="M60 70 Q50 78 44 68 Q52 74 60 72 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M42 62 Q44 46 62 44 Q80 46 82 58 Q78 70 62 68 Q46 70 42 62 Z" fill="${P.n}" ${SW}/><path d="M42 62 Q44 54 52 56 Q52 66 44 66 Z" fill="${P.ac}"/>${fE(64,52,3.8,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",74,46,`<path d="M72 48 Q66 20 74 14 Q82 22 80 48 Z" fill="${P.n}" ${SW2}/><path d="M74 44 Q70 26 75 20" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+pt("ear",80,48,`<path d="M78 50 Q86 24 96 22 Q96 36 84 52 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M10 100 l8 -4 M10 110 l10 0" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="118" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(122,52,6)));
FORM_TITLE["Nightcart"]="Knocker Donkey";

/* 171. Jukeslug (zinc-copper-nickel: fake coins for the Union Hall jukebox) — a lyrebird, the mimic that can copy any song, its lyre-shaped
   tail thrown up over its back in display, bill open on somebody else's tune. */
addForm("Jukeslug",{n:"#7A5A3A",a:"#F4E8D0",rn:"#C8D8F0",rb:"#8A3A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,104)+
 pt("tail",120,104,`<path d="M118 104 Q130 40 170 26 Q160 60 132 104 Z" fill="${P.b}" ${SW}/><path d="M120 104 Q160 60 192 70 Q176 92 130 108 Z" fill="${P.b}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M124 102 Q${138+i*8} ${60+i*6} ${150+i*8} ${40+i*10}" stroke="${P.ac}" stroke-width="1.4" fill="none" opacity=".8"/>`).join("")}${[[154,40],[160,32],[176,72],[184,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.ll}"/>`).join("")}`)+
 fLeg("legB",108,116,28,3.6,"#5A4A3A",null,.4,4)+
 `<path d="M78 104 Q80 82 104 80 Q126 84 128 104 Q122 120 104 120 Q82 120 78 104 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",104,94,`<path d="M94 90 Q122 86 128 108 Q110 114 96 104 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legF",96,118,26,3.6,"#5A4A3A",null,0)+
 pt("head",88,86,fOL("M90 88 Q80 76 80 64",P.n,8)+`<circle cx="76" cy="60" r="11" fill="${P.n}" ${SW}/>`+
  `<path d="M66 58 L50 60 L66 62 Z" fill="${FMOUTH}"/>`+pt("beak",66,62,`<path d="M66 62 L50 61 L66 65 Z" fill="${FI}" ${SW2}/>`)+`<path d="M66 56 L48 60 L66 59 Z" fill="${FI}" ${SW2}/>${fE(74,56,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="36" cy="40" r="4" fill="${P.b}" ${SW2}/><path d="M40 40 v-14 l8 3" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="26" cy="54" r="3" fill="${P.b}" ${SW2}/><path d="M29 54 v-10" stroke="${FI}" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="104" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(70,30,6)));
FORM_TITLE["Jukeslug"]="Jukebox Lyrebird";

/* 172. Sidingnail (manganese iron: rail spikes pulled up from Pomeroy's siding) — a stegosaurus with a double row of rail-spike plates and
   a spiked tail it swings like a hammer, lowing through a small beaky mouth. */
addForm("Sidingnail",{n:"#6A7A5A",a:"#C8A060",rn:"#E8C8D0",rb:"#3A4A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(72)+
 `<path d="M10 148 H190" stroke="#6A4A2A" stroke-width="3"/><path d="M24 144 h18 M64 144 h18 M104 144 h18 M144 144 h18" stroke="#8A6A3A" stroke-width="5"/>`+
 pt("tail",152,108,fOL("M150 108 Q176 108 186 124",P.n,9)+[[178,112,-30],[186,120,10],[182,126,60]].map(([x,y,a])=>`<path d="M${x} ${y} l0 -12" stroke="${FI}" stroke-width="4.4" stroke-linecap="round" transform="rotate(${a} ${x} ${y})"/><path d="M${x} ${y} l0 -12" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round" transform="rotate(${a} ${x} ${y})"/>`).join(""))+
 fLeg("legB",138,116,28,12,P.nd,P.ndd,.5)+fLeg("legB",96,114,30,10,P.nd,P.ndd,1.3)+
 [[80,90],[94,80],[110,74],[126,76],[140,86]].map(([x,y])=>`<path d="M${x-7} ${y+14} L${x} ${y-10} L${x+7} ${y+14} Z" fill="${P.b}" ${SW2}/><rect x="${x-3}" y="${y-14}" width="6" height="5" rx="1" fill="${P.d}" ${SW2}/>`).join("")+
 `<path d="M66 110 Q66 82 106 80 Q146 82 154 110 Q148 126 106 126 Q72 126 66 110 Z" fill="${P.n}" ${SW}/><path d="M72 118 Q106 130 148 118" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".7"/>`+
 fLeg("legF",128,118,26,12,P.n,P.ndd,0)+fLeg("legF",86,116,28,10,P.n,P.ndd,.8)+
 pt("head",70,104,`<path d="M30 112 L46 114 L44 118 L34 116 Z" fill="${FMOUTH}"/>`+pt("beak",46,117,`<path d="M46 117 Q38 122 30 116 Q38 120 46 120 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 110 Q30 96 46 96 Q64 98 72 106 Q66 116 46 116 Q30 116 28 110 Z" fill="${P.n}" ${SW}/>${fE(46,104,3.4,{iris:"#C8A040",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M14 120 l4 -14" stroke="${P.b}" stroke-width="3"/><path d="M12 106 h10" stroke="${P.d}" stroke-width="4"/>`)+
 fG(g,2,`<circle cx="106" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(110,50,6)));
FORM_TITLE["Sidingnail"]="Railspike Stegosaurus";

/* 173. Knucklecast (copper-tin-lead: bench-vice jaws, moulded off the foreman's own knuckles) — an alligator snapping turtle with a jaw
   like a vice, rough plated shell, lying in wait with its mouth open, then clamping. */
addForm("Knucklecast",{n:"#5A5A3A",a:"#F08AA0",rn:"#E8D8C0",rb:"#3A5A8A",ra:"#E8604A"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",150,124,fOL("M150 124 Q170 128 180 120",P.nd,6))+
 fLeg("legB",138,126,14,10,P.nd,P.ndd,.5,6)+
 `<path d="M62 124 Q62 84 108 82 Q150 84 156 124 Z" fill="${P.b}" ${SW}/>${[[82,100],[100,94],[118,92],[136,100],[92,114],[112,110],[132,114]].map(([x,y])=>`<path d="M${x-7} ${y+6} L${x} ${y-8} L${x+7} ${y+6} Z" fill="${P.d}" ${SW2}/>`).join("")}<path d="M62 124 Q108 132 156 124" stroke="${FI}" stroke-width="3" fill="none"/>`+
 fLeg("legF",82,126,12,10,P.n,P.ndd,0,-6)+
 pt("head",68,116,`<path d="M24 114 L60 116 L58 124 L28 122 Z" fill="${FMOUTH}"/><path d="M34 120 q4 -3 8 0 q-4 3 -8 0" fill="${P.ac}"/>`+
  pt("jaw",62,122,`<path d="M62 122 L28 124 Q22 126 28 130 L62 130 Z" fill="${P.nd}" ${SW}/><path d="M28 124 l-4 4" stroke="${FI}" stroke-width="2.4"/>`)+
  `<path d="M22 112 Q24 98 44 96 Q66 96 74 112 L62 118 L22 116 Z" fill="${P.n}" ${SW}/><path d="M22 116 L16 120 L26 118 Z" fill="${P.nd}" ${SW2}/>${fE(50,104,3.6,{iris:"#C8A040",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M16 140 h16 M24 132 v16" stroke="${P.b}" stroke-width="3"/>`)+
 fG(g,2,`<circle cx="108" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(108,62,6)));
FORM_TITLE["Knucklecast"]="Vice-Jaw Snapper";

/* 174. Fluepowder (iron-silicon-calcium: chimney soot swept from the Kiln, scattered as grit on the icy rim walk) — a ptarmigan in its
   winter white with sooty tips, feathered snowshoe feet, crouching then flushing up with a croak. */
addForm("Fluepowder",{n:"#F4F4F8",a:"#3A3A44",rn:"#C8A070",rb:"#B04A3A",ra:"#3AC0E0"},"stand",(P,g)=>`<path d="M10 146 Q100 138 190 146" stroke="#E8F4FC" stroke-width="6" fill="none" stroke-linecap="round"/>${[[30,140],[60,138],[150,140],[170,142]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="${P.b}"/>`).join("")}`+fShadow(42,106)+
 pt("tail",136,110,`<path d="M132 104 L156 106 L150 118 L130 116 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M74 114 Q76 88 104 86 Q132 88 136 114 Q130 132 104 132 Q78 132 74 114 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",106,104,`<path d="M96 100 Q126 94 138 112 Q118 122 98 114 Z" fill="${P.n}" ${SW2}/><path d="M124 106 L138 112 L126 116 Z" fill="${P.ac}"/>`)+
 pt("legF",96,130,`<path d="M88 130 Q86 142 98 144 Q108 142 104 130 Z" fill="${P.n}" ${SW2}/>`)+pt("legB",110,130,`<path d="M104 130 Q104 142 114 144 Q122 140 118 130 Z" fill="${P.n}" ${SW2}/>`,.5)+
 pt("head",86,94,`<circle cx="78" cy="84" r="13" fill="${P.n}" ${SW}/><path d="M78 72 Q84 68 88 72" stroke="#E8412C" stroke-width="3" fill="none"/>`+
  `<path d="M66 82 L58 84 L66 86 Z" fill="${FMOUTH}"/>`+pt("beak",66,86,`<path d="M66 86 L58 85 L66 88 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M66 80 Q58 80 58 84 L66 83 Z" fill="${P.ac}" ${SW2}/><path d="M66 82 L80 80" stroke="${P.ac}" stroke-width="2"/>${fE(76,80,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 120 l6 -6 M24 126 l8 -2" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(108,60,6)));
FORM_TITLE["Fluepowder"]="Grit Ptarmigan";

/* 175. Clinkerbead (iron-silicon-aluminium-calcium: beads the Great Kiln spits out when it's in a temper) — an archerfish that spits beads
   of clinker at things, lining up its shot with a jutting jaw, fins flicking. */
addForm("Clinkerbead",{n:"#D8D0B8",a:"#2A2A34",rn:"#9AD8C8",rb:"#B04A3A",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M10 116 Q60 110 100 116 Q150 122 190 114" stroke="#8AB4D8" stroke-width="2.4" fill="none"/><ellipse class="shd" cx="104" cy="150" rx="46" ry="4" fill="#000" opacity=".12"/>`+
 `<g class="p-glow">${[[34,96],[22,80],[14,62]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="${4-i*.8}" fill="${P.b}" ${SW2}/>`).join("")}</g>`+
 pt("tail",150,110,`<path d="M146 106 L174 92 L168 112 L176 130 L146 116 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M54 110 Q58 88 100 86 Q140 88 150 110 Q140 132 100 134 Q60 132 54 110 Z" fill="${P.n}" ${SW}/>${[[80,92],[100,90],[120,94],[136,104]].map(([x,y])=>`<path d="M${x-4} ${y} l8 0 l-2 10 l-4 0 Z" fill="${P.ac}"/>`).join("")}`+
 pt("fin",116,88,`<path d="M106 88 L128 74 L134 92 Z" fill="${P.nd}" ${SW2}/>`)+pt("fin",96,124,`<path d="M94 122 Q88 138 76 142 Q80 128 86 122 Z" fill="${P.nd}" ${SW2}/>`,.4)+
 pt("head",62,106,`<path d="M42 100 L60 98 L60 104 L46 104 Z" fill="${FMOUTH}"/>`+pt("jaw",62,104,`<path d="M62 104 L38 98 L44 108 L62 110 Z" fill="${P.nd}" ${SW2}/>`)+`${fE(66,96,5.4,{iris:"#C8A040",look:[-.5,-.3]})}`)+
 fG(g,1,`<circle cx="40" cy="130" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,64,6)));
FORM_TITLE["Clinkerbead"]="Bead-Spitting Archerfish";

/* 176. Comradeship (copper-zinc-tin: Union badges struck from the bosses' darts trophies) — a prairie dog standing sentry for its whole
   town, a fist badge on its chest, throwing its arms up in the "jump-yip" every neighbour answers. */
addForm("Comradeship",{n:"#C8A070",a:"#F4E8D8",rn:"#A8B8D8",rb:"#B04A3A",ra:"#F2C94C"},"stand",(P,g)=>`<ellipse cx="100" cy="146" rx="40" ry="8" fill="#8A6A4A" ${SW2}/><ellipse cx="100" cy="144" rx="22" ry="4" fill="#3A2A1A"/>`+
 pt("tail",116,130,`<path d="M114 128 Q130 132 132 142" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M114 128 Q130 132 132 142" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 `<path d="M82 138 Q76 100 98 86 Q122 90 120 132 Q114 144 100 144 Q86 144 82 138 Z" fill="${P.n}" ${SW}/><path d="M90 134 Q88 108 98 100 Q110 108 108 138 Z" fill="${P.ac}"/>`+
 `<circle cx="99" cy="112" r="6" fill="${P.b}" ${SW2}/><path d="M96 114 v-4 h2 v-2 h2 v2 h2 v4 Z" fill="${P.dd}"/>`+
 pt("armF",92,100,fOL("M92 100 Q78 88 76 72",P.n,5)+`<circle cx="76" cy="70" r="3.4" fill="${P.n}" ${SW2}/>`)+pt("armB",108,100,fOL("M108 100 Q122 86 124 70",P.nd,5)+`<circle cx="124" cy="68" r="3.4" fill="${P.nd}" ${SW2}/>`,.3)+
 pt("head",100,88,`<path d="M80 80 Q80 62 98 60 Q116 62 116 80 Q112 92 98 92 Q84 92 80 80 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M84 84 L94 84 L92 88 L86 88 Z" fill="${FMOUTH}"/><rect x="86" y="84" width="4" height="3" fill="#FFFFFF"/>`+pt("jaw",94,86,`<path d="M94 86 Q90 92 84 86 Q90 90 94 88 Z" fill="${P.ac}" ${SW2}/>`)+
  `<ellipse cx="82" cy="78" rx="2.4" ry="2" fill="${FI}"/>${fE(94,72,3.8,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",108,64,`<circle cx="108" cy="64" r="3.6" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M40 60 l-6 -4 M40 70 l-8 0 M160 60 l6 -4 M160 70 l8 0" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="100" cy="128" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(140,44,6)));
FORM_TITLE["Comradeship"]="Sentry Prairie Dog";

/* 177. Tubwheel (cast iron: the ore-tub wheels from when this was an honest quarry) — a pill millipede that rolls itself into a wheel and
   unrolls to scuttle on a hundred legs, antennae feeling ahead. */
addForm("Tubwheel",{n:"#4A4A54",a:"#E8C878",rn:"#E8C8A0",rb:"#3A8A6A",ra:"#E8412C"},"crawl",(P,g)=>`<path d="M10 146 H190" stroke="#6A5A4A" stroke-width="4"/><path d="M10 141 H190" stroke="${P.b}" stroke-width="2" stroke-dasharray="14 6"/>`+fShadow(66)+
 Array.from({length:8},(_,i)=>pt(i%2?"legB":"legF",150-i*12,126,`<path d="M${150-i*12} 126 l-2 14 M${146-i*12} 126 l-3 14" stroke="${FI}" stroke-width="2.2" stroke-linecap="round"/>`,i*.12)).join("")+
 `<path d="M60 128 Q60 92 106 90 Q152 92 160 128 Z" fill="${P.n}" ${SW}/>${[72,84,96,108,120,132,144].map(x=>`<path d="M${x} ${128} Q${x+2} ${100-Math.sin((x-60)/100*Math.PI)*8} ${x+8} ${92+Math.abs(x-108)*.08}" stroke="${P.nd}" stroke-width="3" fill="none"/>`).join("")}<path d="M66 110 Q106 96 154 112" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".5"/>`+
 `<circle cx="106" cy="110" r="10" fill="${P.b}" ${SW2}/><circle cx="106" cy="110" r="4" fill="${FI}"/>${[0,1,2,3].map(i=>`<path d="M106 110 L${106+Math.cos(i*1.57)*10} ${110+Math.sin(i*1.57)*10}" stroke="${P.dd}" stroke-width="2"/>`).join("")}`+
 pt("head",62,120,`<path d="M36 120 Q38 106 54 106 Q68 108 70 122 Q66 132 54 132 Q40 132 36 120 Z" fill="${P.n}" ${SW}/>${fE(50,116,3.4,{iris:P.ac,look:[-.4,0]})}`+
  pt("ant",46,110,`<path d="M46 110 Q32 92 18 94" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+pt("ant",50,108,`<path d="M50 108 Q42 88 30 82" stroke="${FI}" stroke-width="1.8" fill="none"/>`,.4)+
  `<path d="M36 124 L44 124 L42 128 Z" fill="${FMOUTH}"/>`+pt("jaw",44,127,`<path d="M44 127 L36 128 L40 132 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="176" cy="132" r="9" fill="none" stroke="${FI}" stroke-width="4"/><circle cx="176" cy="132" r="9" fill="none" stroke="${P.b}" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="130" cy="108" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(106,70,6)));
FORM_TITLE["Tubwheel"]="Tubwheel Millipede";

/* 178. Shiftwhistle (copper-nickel-zinc: the shift whistles Grunt Lark tunes by ear) — a hoary marmot sitting up on its lookout rock,
   whistling the shift change through cupped cheeks, paws drawn in, tail flicking. */
addForm("Shiftwhistle",{n:"#A8906A",a:"#F4E8D8",rn:"#8A8AA8",rb:"#3A6A8A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M54 148 Q60 122 100 118 Q144 122 150 148 Z" fill="#8A8A8A" ${SW}/><path d="M70 136 l10 -6 M120 132 l12 4" stroke="#6A6A6A" stroke-width="2"/>`+
 pt("tail",120,116,`<path d="M116 114 Q140 112 146 98 Q138 96 126 104 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M82 124 Q76 90 100 80 Q124 84 124 118 Q120 130 104 130 Q86 130 82 124 Z" fill="${P.n}" ${SW}/><path d="M90 122 Q88 100 100 94 Q112 102 110 126 Z" fill="${P.ac}"/>`+
 pt("armF",94,100,fOL("M94 100 Q86 106 90 112",P.nd,6))+pt("armB",108,100,fOL("M108 100 Q116 106 112 112",P.nd,6),.3)+
 pt("head",100,82,`<path d="M78 72 Q78 52 100 50 Q122 52 122 72 Q118 88 100 88 Q82 88 78 72 Z" fill="${P.n}" ${SW}/><path d="M80 58 Q100 44 120 58 Q110 54 100 54 Q90 54 80 58 Z" fill="${P.ndd}"/>`+
  `<path d="M84 74 Q100 82 116 74 Q112 86 100 86 Q88 86 84 74 Z" fill="${P.ac}"/><ellipse cx="100" cy="72" rx="3" ry="2.4" fill="${FI}"/>`+
  `<circle cx="100" cy="80" r="3" fill="${FMOUTH}"/>`+pt("jaw",100,82,`<path d="M97 82 Q100 86 103 82 Z" fill="${P.ac}" ${SW2}/>`)+
  `${fE(90,64,3.8,{iris:"#2A1A0A",look:[-.3,0]})}${fE(110,64,3.8,{iris:"#2A1A0A",look:[-.3,0]})}`+pt("ear",80,56,`<circle cx="80" cy="56" r="4" fill="${P.nd}" ${SW2}/>`)+pt("ear",120,56,`<circle cx="120" cy="56" r="4" fill="${P.nd}" ${SW2}/>`,.4))+
 `<g class="p-glow"><path d="M86 82 q-10 -4 -14 -12 M84 88 q-14 0 -20 -6" stroke="${P.b}" stroke-width="2" fill="none"/></g>`+
 fG(g,1,`<rect x="20" y="96" width="22" height="6" rx="3" fill="${P.b}" ${SW2}/><circle cx="24" cy="99" r="1.4" fill="${FI}"/>`)+
 fG(g,2,`<circle cx="100" cy="114" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(140,52,6)));
FORM_TITLE["Shiftwhistle"]="Whistling Marmot";

/* 179. Lockjaw (nickel-chromium-molybdenum iron: padlocks for the Syndicate's lockers) — an alligator gar, armoured in diamond scales with
   a long jaw full of needles that clamps like a padlock's shackle. */
addForm("Lockjaw",{n:"#6A7A5A",a:"#E8E4DA",rn:"#E8C8B0",rb:"#3A3A6A",ra:"#E8604A"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="66" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",166,96,`<path d="M162 90 Q186 80 192 96 Q186 112 162 104 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M54 98 Q60 80 110 80 Q154 82 168 96 Q154 112 110 114 Q60 114 54 98 Z" fill="${P.n}" ${SW}/>`+
 `<clipPath id="lkjc"><path d="M54 98 Q60 80 110 80 Q154 82 168 96 Q154 112 110 114 Q60 114 54 98 Z"/></clipPath><g clip-path="url(#lkjc)" opacity=".7">${Array.from({length:14},(_,i)=>`<path d="M${56+i*9} 76 l-20 40 M${56+i*9} 76 l20 40" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}</g><path d="M60 104 Q110 116 160 102" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("fin",140,84,`<path d="M132 84 L146 72 L152 88 Z" fill="${P.nd}" ${SW2}/>`)+pt("fin",142,108,`<path d="M134 108 L148 120 L152 104 Z" fill="${P.nd}" ${SW2}/>`,.4)+
 pt("head",60,96,`<path d="M58 90 L10 94 L10 98 L58 98 Z" fill="${P.n}" ${SW}/>${Array.from({length:7},(_,i)=>`<path d="M${16+i*6} 98 l2 4 l2 -4" fill="#FFFFFF"/>`).join("")}`+
  `<path d="M58 98 L10 98 L12 102 L58 104 Z" fill="${FMOUTH}"/>`+pt("jaw",60,102,`<path d="M60 102 L12 100 Q8 104 14 106 L60 108 Z" fill="${P.nd}" ${SW2}/>${Array.from({length:7},(_,i)=>`<path d="M${18+i*6} 102 l2 -4 l2 4" fill="#FFFFFF" stroke="${FI}" stroke-width=".5"/>`).join("")}`)+
  `<path d="M54 90 q8 -10 0 -20" stroke="${FI}" stroke-width="4" fill="none" opacity="0"/><path d="M48 92 Q48 82 56 82 Q64 82 64 92" stroke="${FI}" stroke-width="5" fill="none"/><path d="M48 92 Q48 82 56 82 Q64 82 64 92" stroke="${P.b}" stroke-width="3" fill="none"/>${fE(66,92,3.6,{iris:"#C8A040",look:[-.4,0]})}`)+
 fG(g,1,`<rect x="20" y="120" width="14" height="12" rx="2" fill="${P.b}" ${SW2}/><path d="M22 120 Q22 112 27 112 Q32 112 32 120" stroke="${FI}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="110" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(110,60,6)));
FORM_TITLE["Lockjaw"]="Padlock Gar";

/* 180. Pigeon Ring (aluminium alloy: leg rings for the Works' racing pigeons) — a peregrine falcon, the fastest thing in the sky, ring on
   its leg, stooping from a height with wings swept and talons out, hooked beak open. */
addForm("Pigeon Ring",{n:"#5A6478",a:"#F2D040",rn:"#E8D8C0",rb:"#B04A3A",ra:"#3AC0E0"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",126,74,`<path d="M122 70 L156 48 L160 56 L128 82 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("wingB",112,78,`<path d="M112 78 Q144 52 186 60 Q156 76 118 92 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M80 98 Q84 76 106 72 Q128 74 128 86 Q122 104 104 108 Q86 110 80 98 Z" fill="${P.n}" ${SW}/><path d="M86 102 Q96 90 112 90" stroke="#F4F0E4" stroke-width="6" fill="none" opacity=".8"/>${[[92,98],[100,94],[108,100]].map(([x,y])=>`<path d="M${x} ${y} l3 0" stroke="${FI}" stroke-width="2"/>`).join("")}`+
 pt("legF",96,106,fOL("M96 106 L86 120",P.ac,3.6)+`<path d="M86 120 l-6 4 M86 120 l-2 6 M86 120 l4 4" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/><rect x="86" y="110" width="7" height="5" rx="1" fill="${P.b}" ${SW2} transform="rotate(-30 89 112)"/>`)+
 pt("wingF",104,82,`<path d="M104 82 Q76 100 30 104 Q60 82 98 76 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${86-i*14} ${88+i*3} l-4 6" stroke="${FI}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",84,80,`<circle cx="78" cy="78" r="12" fill="${P.n}" ${SW}/><path d="M74 82 Q76 92 82 90" stroke="${FI}" stroke-width="4" fill="none"/><path d="M68 84 Q74 88 80 86" stroke="#F4F0E4" stroke-width="3" fill="none"/>`+
  `<path d="M66 76 L58 80 L66 82 Z" fill="${FMOUTH}"/>`+pt("beak",66,82,`<path d="M66 82 L60 81 L66 84 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M68 74 Q58 74 58 82 L66 79 Z" fill="#5A5A62" ${SW2}/>${fE(76,74,4,{iris:"#2A1A0A",look:[-.4,0]})}<circle cx="76" cy="74" r="6" fill="none" stroke="${P.ac}" stroke-width="1.6"/>`)+
 fG(g,1,`<path d="M150 100 l20 10 M146 110 l20 10" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="106" cy="94" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,46,6)));
FORM_TITLE["Pigeon Ring"]="Stooping Falcon";

/* 181. Brewstir (stainless iron: the tea hut spoons, each one stolen from the Institute canteen) — a stoat in its summer brown, stood up
   tall to look over the brew, then bounding in its famous dancing hop, jaws snapping. */
addForm("Brewstir",{n:"#9A6A3A",a:"#F4E8D8",rn:"#F4F4F8",rb:"#3A6A8A",ra:"#2A2A34"},"slink",(P,g)=>fShadow(54,104)+
 `<path d="M150 146 h30 v-20 q0 -6 -6 -6 h-18 q-6 0 -6 6 Z" fill="#E8E4DA" ${SW}/><path d="M180 128 q8 2 4 10" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M162 120 L170 92" stroke="${FI}" stroke-width="4.4" stroke-linecap="round"/><path d="M162 120 L170 92" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/><ellipse cx="171" cy="90" rx="3" ry="5" fill="${P.b}" ${SW2}/>`+
 pt("tail",128,124,fOL("M126 124 Q146 126 150 116",P.n,6)+`<path d="M146 120 Q154 116 154 108 Q148 108 146 114 Z" fill="${FI}"/>`)+
 fLeg("legB",120,130,14,7,P.nd,P.nd,.4)+
 `<path d="M80 130 Q76 104 92 90 Q112 86 124 118 Q126 134 104 136 Q86 136 80 130 Z" fill="${P.n}" ${SW}/><path d="M86 128 Q84 108 94 98 Q102 112 100 132 Z" fill="${P.ac}"/>`+
 pt("armF",88,104,fOL("M88 104 Q80 112 82 118",P.n,5))+
 pt("head",92,90,`<path d="M58 84 Q60 68 78 66 Q96 68 98 84 Q94 96 78 96 Q62 96 58 84 Z" fill="${P.n}" ${SW}/><path d="M60 88 Q70 86 80 92 Q72 98 62 94 Z" fill="${P.ac}"/>`+
  `<path d="M58 86 L68 88 L66 90 Z" fill="${FMOUTH}"/>`+pt("jaw",68,89,`<path d="M68 89 L58 88 L62 92 Z" fill="${P.ac}" ${SW2}/>`)+`<ellipse cx="58" cy="82" rx="2.6" ry="2" fill="${FI}"/>${fE(74,78,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",86,68,`<circle cx="88" cy="68" r="5" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M168 82 q-4 -6 0 -12 M176 84 q-4 -6 0 -12" stroke="#BFC5CB" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,62,6)));
FORM_TITLE["Brewstir"]="Teaspoon Stoat";

/* 182. Bellmouth (copper-tin bell bronze: a stolen school bell recast for the bench shift) — a three-wattled bellbird, the loudest bird on
   earth, throwing its head back and its bill wide for a clang that carries for miles, wattles swinging. */
addForm("Bellmouth",{n:"#C8783A",a:"#2A2A34",rn:"#E8E4F0",rb:"#3A6A8A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M20 124 Q100 116 186 128" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("tail",126,112,`<path d="M122 106 L152 128 L144 134 L118 114 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M86 106 Q86 82 108 80 Q130 84 130 106 Q124 122 108 122 Q90 122 86 106 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,96,`<path d="M100 92 Q128 88 134 108 Q118 116 104 106 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M100 120 l-2 6 M110 120 l0 6" stroke="${FI}" stroke-width="2.4"/>`+
 pt("head",98,86,`<circle cx="90" cy="76" r="14" fill="${P.ac}" ${SW}/><path d="M88 62 Q96 66 102 74" stroke="${P.n}" stroke-width="3" fill="none" opacity=".7"/>`+
  `<path d="M78 72 L62 70 L78 82 Z" fill="${FMOUTH}"/>`+pt("beak",78,80,`<path d="M78 80 L64 82 L78 84 Z" fill="${FI}" ${SW2}/>`)+`<path d="M80 70 L62 70 L78 76 Z" fill="${FI}" ${SW2}/>${fE(88,72,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("sway",80,72,fOL("M80 72 Q74 64 76 50",P.nd,2.6))+pt("sway",80,80,fOL("M80 80 Q72 92 76 104",P.nd,2.6),.4)+pt("sway",82,78,fOL("M82 78 Q90 92 86 104",P.nd,2.6),.8))+
 `<g class="p-glow"><path d="M50 64 q-8 6 -4 18 M40 58 q-10 12 -4 30" stroke="${P.b}" stroke-width="2.4" fill="none"/></g>`+
 fG(g,1,`<path d="M30 30 Q30 18 40 18 Q50 18 50 30 L52 34 L28 34 Z" fill="${P.b}" ${SW2}/><circle cx="40" cy="36" r="2" fill="${FI}"/>`)+
 fG(g,2,`<circle cx="108" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,56,6)));
FORM_TITLE["Bellmouth"]="Clanging Bellbird";

/* 183. Lastorders (tin-antimony-copper pewter: Union Hall tankards poured from a stolen church organ's pipes) — a toucan, its bill a
   tankard's worth of colour, perched at the bar, tossing its head back with a croaky call. */
addForm("Lastorders",{n:"#1E1E26",a:"#F28A30",rn:"#E8E4DA",rb:"#3AA0C8",ra:"#E8412C"},"perch",(P,g)=>`<rect x="14" y="122" width="176" height="10" rx="2" fill="#6A4A2A" ${SW}/><rect x="150" y="98" width="20" height="24" rx="3" fill="${P.b}" ${SW2}/><path d="M170 104 q8 4 0 12" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M152 100 q8 -6 16 0" fill="#FFFFFF" ${SW2}/>`+
 pt("tail",128,110,`<path d="M124 104 L148 130 L138 134 L118 112 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M90 106 Q90 80 110 78 Q130 82 130 106 Q124 122 110 122 Q94 122 90 106 Z" fill="${P.n}" ${SW}/><path d="M92 98 Q96 84 108 84 Q110 96 98 104 Z" fill="#F2E080"/>`+
 pt("wingF",114,96,`<path d="M104 92 Q130 90 134 110 Q118 116 106 106 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M104 120 l-2 4 M112 120 l0 4" stroke="#3A6AD8" stroke-width="3"/>`+
 pt("head",102,82,`<circle cx="100" cy="72" r="12" fill="${P.n}" ${SW}/><circle cx="98" cy="70" r="6" fill="#5FC8F0"/>`+
  `<path d="M90 70 L50 76 L90 80 Z" fill="${FMOUTH}"/>`+pt("beak",90,78,`<path d="M90 78 L52 78 Q48 82 54 84 L90 84 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M90 62 Q60 60 46 74 Q48 78 54 76 L90 74 Z" fill="#F2C94C" ${SW}/><path d="M48 74 Q60 70 90 70" stroke="#E8412C" stroke-width="4" fill="none"/><path d="M48 74 L52 76" stroke="${FI}" stroke-width="3"/>${fE(98,70,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M24 100 q4 -8 0 -16 M32 100 q4 -8 0 -16" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="112" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,48,6)));
FORM_TITLE["Lastorders"]="Tankard Toucan";

/* 184. Lathetail (copper-zinc-lead: the curls the bunkhouse lathe throws off all day) — a poodle in a coat of lathe curls, clipped pompoms
   on legs and tail, prancing high-stepping, ears flopping, yapping. */
addForm("Lathetail",{n:"#E8C060",a:"#F08AA0",rn:"#3A3A4A",rb:"#B07A3A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(50,108)+
 pt("tail",142,92,fOL("M142 94 Q150 80 150 66",P.nd,4)+`<circle cx="150" cy="62" r="8" fill="${P.n}" ${SW2}/>${Array.from({length:5},(_,i)=>`<circle cx="${146+i%3*4}" cy="${58+Math.floor(i/3)*6}" r="2.6" fill="none" stroke="${P.d}" stroke-width="1.4"/>`).join("")}`)+
 [[136,104,.5],[104,104,1.3]].map(([x,y,d])=>pt("legB",x,y,fOL(`M${x} ${y} L${x} ${y+36}`,P.nd,4)+`<circle cx="${x}" cy="${y+30}" r="6" fill="${P.n}" ${SW2}/>`,d)).join("")+
 `<path d="M86 98 Q86 76 114 74 Q144 76 148 96 Q142 112 116 112 Q90 112 86 98 Z" fill="${P.n}" ${SW}/>${Array.from({length:18},(_,i)=>`<circle cx="${92+(i%6)*10}" cy="${82+Math.floor(i/6)*9}" r="4" fill="none" stroke="${P.d}" stroke-width="1.6"/>`).join("")}`+
 [[128,106,0],[96,106,.8]].map(([x,y,d])=>pt("legF",x,y,fOL(`M${x} ${y} L${x} ${y+34}`,P.n,4)+`<circle cx="${x}" cy="${y+28}" r="6" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",92,84,fOL("M94 88 Q86 74 84 64",P.nd,8)+
  `<path d="M54 64 L68 66 L66 70 L56 68 Z" fill="${FMOUTH}"/>`+pt("jaw",68,70,`<path d="M68 70 Q60 76 54 68 Q60 72 68 72 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M52 62 Q54 52 70 50 Q86 50 88 62 Q84 70 70 70 Q56 70 52 62 Z" fill="${P.n}" ${SW}/><circle cx="74" cy="44" r="10" fill="${P.n}" ${SW2}/>${Array.from({length:4},(_,i)=>`<circle cx="${70+i%2*8}" cy="${40+Math.floor(i/2)*7}" r="3" fill="none" stroke="${P.d}" stroke-width="1.4"/>`).join("")}`+
  `<ellipse cx="52" cy="60" rx="2.6" ry="2" fill="${FI}"/>${fE(66,58,3.6,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M74 52 l4 4" stroke="${P.ac}" stroke-width="3"/>`+
  pt("ear",80,56,`<path d="M78 54 Q90 56 90 74 Q84 78 78 70 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 q4 -8 8 0 q4 -8 8 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="118" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(118,52,6)));
FORM_TITLE["Lathetail"]="Swarf Poodle";

/* 185. Hearthgrain (magnesium-aluminium-zinc powder: Smelter Ingrid's firelighters, kept in a tin marked SUGAR) — a firecrest, a tiny bird
   with a blazing crest it flares like a lit match, flitting and hopping, calling a thin "zit-zit". */
addForm("Hearthgrain",{n:"#7AA04A",a:"#FF7A2A",rn:"#C8C8E0",rb:"#3A3A6A",ra:"#E8412C"},"hop",(P,g)=>`<rect x="132" y="112" width="34" height="34" rx="3" fill="${P.b}" ${SW}/><rect x="132" y="108" width="34" height="7" rx="2" fill="${P.d}" ${SW2}/><path d="M138 124 h22 M138 130 h16" stroke="${P.dd}" stroke-width="2"/>`+fShadow(30,96)+
 pt("tail",112,110,`<path d="M108 104 L134 110 L130 118 L106 114 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M72 108 Q74 86 94 84 Q114 88 114 108 Q108 122 94 122 Q76 122 72 108 Z" fill="${P.n}" ${SW}/><path d="M76 112 Q84 104 98 108 Q104 118 94 122 Q80 122 76 112 Z" fill="#F4E8D0"/>`+
 pt("wingF",96,98,`<path d="M86 94 Q112 90 118 108 Q102 114 90 106 Z" fill="${P.nd}" ${SW2}/><path d="M96 102 h12 M96 106 h10" stroke="#F4F0E4" stroke-width="1.6"/>`)+
 fLeg("legF",90,120,20,2.4,"#8A6A3A",null,0)+fLeg("legB",98,120,20,2.4,"#8A6A3A",null,.4)+
 pt("head",84,90,`<circle cx="80" cy="82" r="12" fill="${P.n}" ${SW}/><path d="M70 82 L90 80" stroke="${FI}" stroke-width="2.4"/><path d="M70 86 L88 86" stroke="#F4F0E4" stroke-width="2.4"/>`+
  pt("ear",82,72,`<path d="M72 74 Q80 54 90 62 Q96 56 94 70 Z" fill="${P.ac}" ${SW2}/><path d="M80 70 Q84 62 88 66" stroke="#FFE070" stroke-width="2.4" fill="none" class="p-glow"/>`)+
  `<path d="M68 82 L60 84 L68 86 Z" fill="${FMOUTH}"/>`+pt("beak",68,86,`<path d="M68 86 L60 85 L68 88 Z" fill="${FI}" ${SW2}/>`)+`<path d="M68 80 L58 84 L68 83 Z" fill="${FI}" ${SW2}/>${fE(78,82,3,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<g class="p-glow"><circle cx="40" cy="70" r="2.4" fill="${P.ac}"/><circle cx="48" cy="60" r="1.8" fill="#FFE070"/><circle cx="34" cy="56" r="1.6" fill="${P.ac}"/></g>`)+
 fG(g,2,`<circle cx="94" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(116,58,6)));
FORM_TITLE["Hearthgrain"]="Matchlit Firecrest";

/* 186. Gauzeguard (copper-nickel: the safety-lamp gauzes in the Drift) — a canary, the miner's old warning bird, singing in its little
   brass lamp-cage, hopping from perch to perch, throat trembling. */
addForm("Gauzeguard",{n:"#F2D040",a:"#E89A30",rn:"#9AD0E8",rb:"#7A3A8A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M100 10 V22" stroke="${FI}" stroke-width="2.4"/><circle cx="100" cy="10" r="4" fill="none" stroke="${P.b}" stroke-width="2.4"/><path d="M60 140 L60 48 Q60 22 100 22 Q140 22 140 48 L140 140" fill="none" stroke="${P.b}" stroke-width="3"/>${[70,80,90,100,110,120,130].map(x=>`<path d="M${x} ${x==70||x==130?40:28} V140" stroke="${P.b}" stroke-width="1.4" opacity=".6"/>`).join("")}<rect x="54" y="136" width="92" height="10" rx="2" fill="${P.d}" ${SW}/><path d="M64 110 H136" stroke="#8A6A3A" stroke-width="4" stroke-linecap="round"/>`+
 pt("tail",114,102,`<path d="M110 96 L134 106 L128 114 L106 104 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M78 98 Q80 78 98 76 Q116 80 116 98 Q110 112 96 112 Q82 112 78 98 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,90,`<path d="M90 86 Q114 82 120 100 Q104 106 92 98 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M94 110 l-2 4 M100 110 l0 4" stroke="${FI}" stroke-width="2"/>`+
 pt("head",90,80,`<circle cx="86" cy="72" r="12" fill="${P.n}" ${SW}/>`+
  `<path d="M74 70 L64 72 L74 76 Z" fill="${FMOUTH}"/>`+pt("beak",74,76,`<path d="M74 76 L64 74 L74 78 Z" fill="#F0A0A8" ${SW2}/>`)+`<path d="M74 68 L62 72 L74 72 Z" fill="#F0A0A8" ${SW2}/>${fE(84,68,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 `<g class="p-glow"><path d="M50 60 q-6 -6 -2 -14 M42 66 q-8 -6 -4 -18" stroke="${P.b}" stroke-width="2" fill="none"/></g>`+
 fG(g,1,`<path d="M164 120 Q164 100 174 100 Q184 100 184 120 Z" fill="${P.ac}" opacity=".7" ${SW2}/><path d="M168 102 V120 M174 100 V120 M180 102 V120" stroke="${P.b}" stroke-width="1.2"/>`)+
 fG(g,2,`<circle cx="98" cy="102" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,4,5)));
FORM_TITLE["Gauzeguard"]="Lamp-Cage Canary";

/* 187. Roofbolt (manganese iron: the roof bolts the old miners hammered into the Drift) — a stocky pit pony with a miner's lamp on its
   harness, shaggy forelock over its eyes, stamping a hoof, whinnying. */
addForm("Roofbolt",{n:"#4A3A30",a:"#F2E0A0",rn:"#E8D8C8",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="10" y="10" width="180" height="10" fill="#5A4A3A" ${SW2}/>${[40,100,160].map(x=>`<rect x="${x-3}" y="18" width="6" height="10" fill="${P.b}" ${SW2}/>`).join("")}`+fShadow(54,110)+
 pt("tail",150,94,`<path d="M148 90 Q164 96 160 128 Q152 118 146 100 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",140,108,30,11,P.nd,P.ndd,.5)+fLeg("legB",100,108,30,11,P.nd,P.ndd,1.3)+
 `<path d="M82 100 Q82 74 116 74 Q150 76 152 100 Q148 116 118 118 Q86 118 82 100 Z" fill="${P.n}" ${SW}/><path d="M100 76 Q102 96 96 114" stroke="#7A5A3A" stroke-width="5" fill="none"/><circle cx="96" cy="94" r="7" fill="${P.ac}" class="p-glow" ${SW2}/><rect x="92" y="98" width="8" height="5" fill="${P.b}" ${SW2}/>`+
 fLeg("legF",132,110,28,11,P.n,P.ndd,0)+pt("legF",92,110,fOL("M92 110 L84 124 L86 138",P.n,11)+`<path d="M78 138 h14" stroke="${P.ndd}" stroke-width="6" stroke-linecap="round"/>`,.8)+
 pt("head",90,86,fOL("M92 90 Q80 76 76 62",P.n,14)+`<path d="M86 56 Q96 66 98 86 Q92 80 88 70 Z" fill="${P.nd}" ${SW2}/>`+
  `<path d="M42 66 L58 68 L56 72 L46 70 Z" fill="${FMOUTH}"/>`+pt("jaw",58,72,`<path d="M58 72 Q50 80 42 70 Q50 76 58 74 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M40 64 Q40 48 58 46 Q78 46 80 60 Q76 72 58 70 Q44 72 40 64 Z" fill="${P.n}" ${SW}/><path d="M40 66 Q42 58 50 60 Q50 68 42 68 Z" fill="${P.ac}" opacity=".6"/>${fE(62,54,3.8,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M56 46 Q64 40 74 48 Q66 50 62 56 Z" fill="${P.nd}" ${SW2}/>`+
  pt("ear",74,46,`<path d="M72 48 L72 34 L80 44 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 l6 -6 l6 6" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(122,54,6)));
FORM_TITLE["Roofbolt"]="Pit Pony";

/* 188. Sumpshine (gallium-tin-zinc: a puddle at the bottom of the flooded sump that never mixes; Wexley's lucky bottle) — a quicksilver
   slug, a puddle of liquid metal with eyestalks, oozing forward, eyestalks pulling in and out. */
addForm("Sumpshine",{n:"#C8D0D8",a:"#5FC8F0",rn:"#F0D890",rb:"#7A4AA8",ra:"#E8412C"},"crawl",(P,g)=>`<ellipse cx="100" cy="146" rx="70" ry="7" fill="#6A8AA0" opacity=".4"/>`+
 pt("tail",150,132,`<path d="M146 126 Q176 128 186 142 Q164 144 146 140 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M44 140 Q42 106 90 102 Q140 102 156 140 Z" fill="${P.n}" ${SW}/><path d="M60 118 Q90 104 130 116" stroke="#FFFFFF" stroke-width="6" fill="none" opacity=".7" stroke-linecap="round"/><path d="M70 130 Q100 124 136 132" stroke="${P.b}" stroke-width="3" fill="none" opacity=".6"/><circle cx="110" cy="124" r="5" fill="#FFFFFF" opacity=".6"/>`+
 pt("head",60,128,pt("ant",56,112,fOL("M56 112 L44 82",P.n,4)+`${fE(44,80,4.4,{iris:P.ac,look:[-.4,0]})}`)+pt("ant",64,110,fOL("M64 110 L62 80",P.n,4)+`${fE(62,78,4.4,{iris:P.ac,look:[-.4,0]})}`,.5)+
  pt("ant",48,126,fOL("M48 126 L34 118",P.n,3),1)+
  `<path d="M42 134 L56 134 L54 138 Z" fill="${FMOUTH}"/>`+pt("jaw",56,137,`<path d="M56 137 Q48 142 42 136 Q48 140 56 139 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<rect x="160" y="96" width="14" height="22" rx="4" fill="#E8F4FC" opacity=".7" ${SW2}/><rect x="160" y="108" width="14" height="10" rx="3" fill="${P.n}"/><rect x="161" y="92" width="12" height="5" fill="#8A6A3A" ${SW2}/>`)+
 fG(g,2,`<circle cx="100" cy="122" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(100,84,6)));
FORM_TITLE["Sumpshine"]="Quicksilver Slug";

/* 189. Jamjar Ghost (gallium-indium-tin, liquid at room temperature: Ingrid's "thermometer", which once climbed out of its jar) — a ghost
   shrimp, see-through but for its insides, its one big claw clicking, flicking its tail fan to shoot backwards. */
addForm("Jamjar Ghost",{n:"#D8E8F4",a:"#F08AA0",rn:"#F4E0B0",rb:"#7A4AA8",ra:"#3AC0A0"},"crawl",(P,g)=>`<path d="M140 146 L140 90 Q140 84 146 84 L182 84 Q188 84 188 90 L188 146 Z" fill="#E8F4FC" opacity=".55" ${SW2}/><rect x="142" y="78" width="44" height="8" rx="2" fill="#B88A50" ${SW2}/>`+fShadow(60,96)+
 pt("tail",136,118,`${[0,1,2].map(i=>`<path d="M${128+i*8} ${110+i*2} q8 2 8 14 l-10 0 Z" fill="${P.n}" opacity=".7" ${SW2}/>`).join("")}<path d="M150 116 L168 108 L166 132 L150 126 Z" fill="${P.n}" opacity=".75" ${SW2}/>`)+
 [[96,126],[108,128],[120,126]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+4} ${y+14}`,P.nd,2),i*.2)).join("")+
 `<path d="M70 118 Q72 98 104 96 Q132 98 136 118 Q130 132 104 132 Q74 132 70 118 Z" fill="${P.n}" opacity=".7" ${SW}/><path d="M82 114 Q100 106 124 116" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".8"/><circle cx="96" cy="118" r="5" fill="${P.b}" opacity=".9"/><path d="M110 110 q6 6 14 2" stroke="${P.b}" stroke-width="2" fill="none"/>`+
 pt("claw",76,116,fOL("M76 116 L56 108",P.n,5)+`<path d="M56 108 Q36 92 26 104 Q34 108 44 108 L30 114 Q42 122 56 114 Z" fill="${P.n}" opacity=".85" ${SW}/>`)+
 pt("head",72,114,`<path d="M54 116 Q56 104 70 104 L76 120 Q62 126 54 116 Z" fill="${P.n}" opacity=".8" ${SW}/>${fE(64,108,3.6,{iris:P.ac,look:[-.4,0]})}`+
  pt("ant",62,104,`<path d="M62 104 Q44 76 18 74 M64 104 Q56 80 40 64" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`)+
  `<path d="M54 118 L62 120 L60 122 Z" fill="${FMOUTH}"/>`+pt("jaw",62,121,`<path d="M62 121 L54 122 L58 125 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M150 96 q8 -8 16 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,76,6)));
FORM_TITLE["Jamjar Ghost"]="Glass Ghost Shrimp";

/* 190. Dartflight (heavy tungsten: the Union Hall darts banned after the league final) — an anhinga, the darter, drying its wings spread on a
   post, neck kinked like a loaded spring, then shooting its dagger bill forward. */
addForm("Dartflight",{n:"#2A2A30",a:"#E8E4DA",rn:"#E8C8A0",rb:"#C04A3A",ra:"#3AC0E0"},"perch",(P,g)=>`<rect x="104" y="112" width="14" height="40" rx="3" fill="#6A4A2A" ${SW}/>`+
 pt("wingB",116,86,`<path d="M116 86 Q150 50 184 58 Q176 82 160 88 Q170 94 160 104 Q136 102 120 100 Z" fill="${P.nd}" ${SW}/>${[[140,74],[154,72],[166,70],[146,90]].map(([x,y])=>`<path d="M${x} ${y} l4 6" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 pt("tail",120,104,`<path d="M116 100 L136 132 L126 134 L112 108 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M96 100 Q98 80 116 80 Q132 84 132 102 Q126 114 114 114 Q98 114 96 100 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",104,88,`<path d="M104 88 Q74 50 36 56 Q44 78 60 86 Q48 94 58 104 Q82 104 100 100 Z" fill="${P.n}" ${SW}/>${[[64,70],[76,68],[86,72],[68,92]].map(([x,y])=>`<path d="M${x} ${y} l-4 6" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 `<path d="M108 112 l-2 6 M116 112 l0 6" stroke="${FI}" stroke-width="2.4"/>`+
 pt("head",104,84,fOL("M104 86 Q90 76 98 62 Q104 52 92 44",P.n,6)+
  `<path d="M80 42 Q80 34 90 34 Q98 36 98 44 Q94 50 88 50 Q80 50 80 42 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M82 42 L50 46 L82 46 Z" fill="${FMOUTH}"/>`+pt("beak",82,46,`<path d="M82 46 L50 46 L82 49 Z" fill="#E8C878" ${SW2}/>`)+`<path d="M82 39 L48 45 L82 43 Z" fill="#E8C878" ${SW2}/>${fE(88,40,3,{iris:"#E8412C",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M20 120 L44 114 M40 110 L44 114 L40 118" stroke="${P.b}" stroke-width="2.4" fill="none"/><path d="M16 118 l4 2 l-4 2 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,2,`<circle cx="114" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,40,6)));
FORM_TITLE["Dartflight"]="Darter Anhinga";

/* 191. Blowfuse (bismuth-lead-tin-cadmium: safety plugs that melt and let the quench water in) — a pufferfish with its spines raised like a
   fuse about to blow, little fins whirring, pursed mouth popping open. */
addForm("Blowfuse",{n:"#E8D890",a:"#3A6A8A",rn:"#C8E8F0",rb:"#B04A3A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",140,92,`<path d="M136 88 L158 76 L156 92 L158 108 L136 98 Z" fill="${P.nd}" ${SW}/>`)+
 pt("fin",100,92,Array.from({length:18},(_,i)=>{const a=i*20*Math.PI/180;return`<path d="M${100+Math.cos(a)*34} ${92+Math.sin(a)*34} L${100+Math.cos(a)*46} ${92+Math.sin(a)*46}" stroke="${FI}" stroke-width="3.6" stroke-linecap="round"/><path d="M${100+Math.cos(a)*34} ${92+Math.sin(a)*34} L${100+Math.cos(a)*46} ${92+Math.sin(a)*46}" stroke="${P.b}" stroke-width="1.8" stroke-linecap="round"/>`}).join(""))+
 `<circle cx="100" cy="92" r="38" fill="${P.n}" ${SW}/><path d="M66 104 Q100 132 134 104 Q124 126 100 128 Q76 126 66 104 Z" fill="#F4F0E4"/>${[[90,66],[108,62],[120,76],[86,82],[112,84]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4" fill="${P.ac}" opacity=".7"/>`).join("")}`+
 pt("fin",112,98,`<path d="M110 96 Q122 88 126 98 Q122 106 112 104 Z" fill="${P.nd}" ${SW2}/>`,.3)+
 pt("head",72,92,`${fE(78,82,7,{iris:"#2A1A0A",look:[-.4,0]})}<circle cx="62" cy="98" r="5" fill="${P.nd}" ${SW2}/><circle cx="62" cy="98" r="2.4" fill="${FMOUTH}"/>`+pt("jaw",64,102,`<path d="M66 102 Q62 108 58 102 Q62 104 66 104 Z" fill="${P.nl}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 60 l6 6 M36 60 l-6 6" stroke="#E8412C" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,36,6)));
FORM_TITLE["Blowfuse"]="Fuse Pufferfish";

/* 192. Vowkeeper (sterling silver: a drawer of somebody's wedding cutlery; Cook Mags saved one rod) — a pair of lovebirds that never leave
   each other's side, one preening the other, bills touching, wings fluttering. */
addForm("Vowkeeper",{n:"#5AC06A",a:"#F08A5A",rn:"#C8B8F0",rb:"#3A6AB0",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M20 120 Q100 112 186 124" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M100 118 Q100 128 96 136" stroke="${P.b}" stroke-width="3" fill="none"/><ellipse cx="94" cy="138" rx="5" ry="3" fill="${P.b}" ${SW2}/>`+
 [[132,0,"legB"],[70,1,"legF"]].map(([x,k,leg])=>{const s=k?1:-1,b=k?P.n:P.nd;return pt(k?"tail":"sway",x+s*-12,104,`<path d="M${x+s*-10} 98 L${x+s*-34} 120 L${x+s*-26} 124 L${x+s*-8} 106 Z" fill="${b}" ${SW2}/>`,k*.5)+
  `<path d="M${x-16} 102 Q${x-16} 82 ${x} 80 Q${x+16} 82 ${x+16} 102 Q${x+12} 116 ${x} 116 Q${x-12} 116 ${x-16} 102 Z" fill="${b}" ${SW}/>`+
  pt(k?"wingF":"wingB",x+s*-4,92,`<path d="M${x+s*-2} 88 Q${x+s*-22} 90 ${x+s*-22} 108 Q${x+s*-8} 108 ${x+s*2} 98 Z" fill="${P.nd}" ${SW2}/>`)}).join("")+
 pt("head",120,82,`<circle cx="124" cy="70" r="12" fill="${P.ac}" ${SW}/><path d="M112 72 L106 72 L112 76 Z" fill="${FMOUTH}"/>`+pt("jaw",112,75,`<path d="M112 75 L106 74 L112 78 Z" fill="#E8412C" ${SW2}/>`)+`<path d="M114 66 Q104 66 104 72 L112 71 Z" fill="#E8412C" ${SW2}/>${fE(120,66,3.4,{iris:"#2A1A0A",look:[-.6,0]})}`)+
 pt("ear",80,82,`<circle cx="76" cy="70" r="12" fill="${P.ac}" ${SW}/><path d="M88 72 L94 72 L88 76 Z" fill="${FMOUTH}"/><path d="M86 66 Q96 66 96 72 L88 71 Z" fill="#E8412C" ${SW2}/><path d="M88 75 L94 74 L88 78 Z" fill="#E8412C" ${SW2}/>${fE(80,66,3.4,{iris:"#2A1A0A",look:[.6,0]})}`,.8)+
 `<path d="M100 58 q-4 -6 0 -10 q4 4 0 10 q4 -6 0 -10" fill="#F08AA0" ${SW2} opacity="0"/>`+
 fG(g,1,`<path d="M100 40 q-6 -8 0 -12 q6 4 0 12 Z" fill="#F08AA0" ${SW2}/>`)+
 fG(g,2,`<circle cx="100" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,22,6)));
FORM_TITLE["Vowkeeper"]="Inseparable Lovebirds";

/* 193. Tickcoil (cobalt-chromium-iron-nickel: watch mainsprings, stolen and melted and stolen again) — a click beetle that lies on its back
   and then flips itself into the air with a snap of its spring-loaded hinge, antennae combed like a watch's teeth. */
addForm("Tickcoil",{n:"#3A2A24",a:"#E8C060",rn:"#C8D8E8",rb:"#B04A3A",ra:"#3A3A6A"},"hop",(P,g)=>fShadow(54,104)+
 [[112,118],[126,120],[140,118]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+8} ${y+10} L${x+6} 140`,P.nd,2.6),i*.2)).join("")+
 `<path d="M98 112 Q100 88 132 86 Q162 90 164 110 Q158 124 132 124 Q102 124 98 112 Z" fill="${P.n}" ${SW}/>${[108,120,132,144,156].map(x=>`<path d="M${x} 90 L${x} 122" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}<path d="M132 86 V124" stroke="${P.ndd}" stroke-width="2"/>`+
 pt("ear",100,108,`<circle cx="98" cy="108" r="6" fill="none" stroke="${FI}" stroke-width="4"/><path d="M98 108 m-4 0 a4 4 0 1 1 4 4 a2 2 0 1 1 -2 -2" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 [[84,118],[96,120]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-10} ${y+10} L${x-8} 140`,P.n,2.6),i*.2)).join("")+
 pt("head",94,108,`<path d="M66 108 Q66 92 82 90 Q96 92 98 108 Q94 120 82 120 Q68 120 66 108 Z" fill="${P.n}" ${SW}/><circle cx="82" cy="98" r="4" fill="${P.ac}" opacity=".8" class="p-glow"/>${fE(74,104,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",72,96,`<path d="M72 96 L52 76" stroke="${FI}" stroke-width="1.8"/>${[0,1,2,3,4].map(i=>`<path d="M${68-i*4} ${92-i*4} l-5 1" stroke="${FI}" stroke-width="1.4"/>`).join("")}`)+
  `<path d="M66 112 L74 112 L72 116 Z" fill="${FMOUTH}"/>`+pt("jaw",72,115,`<path d="M72 115 L64 116 L68 119 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 60 l4 -6 l4 6 M28 72 l4 -6 l4 6" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="132" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(132,66,6)));
FORM_TITLE["Tickcoil"]="Mainspring Click Beetle";

/* 194. Grinsome (gold-copper-silver: Kilnmaster Varrow's one gleaming tooth, cast from the Syndicate's first night's takings) — a great
   barracuda, sleek and toothy, one fang flashing gold in an underslung grin that opens wide. */
addForm("Grinsome",{n:"#7A8A9A",a:"#2A2A34",rn:"#E8D0B0",rb:"#9A3A8A",ra:"#3AC0E0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="70" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",168,96,`<path d="M164 92 L192 72 L186 96 L192 120 L164 102 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M36 98 Q42 80 104 78 Q156 80 170 96 Q156 112 104 114 Q46 114 36 98 Z" fill="${P.n}" ${SW}/><path d="M50 104 Q104 118 160 104" stroke="#F4F0E4" stroke-width="5" fill="none" opacity=".6"/>`+
 [84,100,116,132,148].map(x=>`<path d="M${x} 82 L${x-6} 98" stroke="${P.ac}" stroke-width="3" opacity=".55"/>`).join("")+
 pt("fin",126,80,`<path d="M118 80 L132 64 L138 82 Z" fill="${P.nd}" ${SW2}/>`)+pt("fin",88,106,`<path d="M86 104 Q80 122 66 126 Q70 112 78 104 Z" fill="${P.nd}" ${SW2}/>`,.4)+
 pt("head",54,96,`<path d="M58 92 L18 94 L18 98 L58 98 Z" fill="${P.n}" ${SW}/>${[24,32,48].map(x=>`<path d="M${x} 98 l2 5 l2 -5" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`).join("")}<path d="M38 98 l2.4 7 l2.4 -7" fill="${P.b}" stroke="${FI}" stroke-width=".8"/>`+
  `<path d="M58 98 L18 98 L20 102 L58 104 Z" fill="${FMOUTH}"/>`+pt("jaw",60,102,`<path d="M60 102 L14 100 Q10 106 18 108 L60 108 Z" fill="${P.nl}" ${SW2}/>${[22,30,42,50].map(x=>`<path d="M${x} 102 l2 -5 l2 5" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`).join("")}`)+
  `${fE(52,90,4,{iris:"#C8A040",look:[-.4,0]})}`)+
 fG(g,1,`${star(20,70,3,"#F2C94C")}`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,56,6)));
FORM_TITLE["Grinsome"]="Gold-Fang Barracuda";

/* 195. Sparkthief (platinum-iridium: picked from the tips of four hundred stolen spark plugs) — a raven, the cleverest thief in the sky, a
   glinting spark-plug tip in its beak, hackles raised, croaking, wings hunched. */
addForm("Sparkthief",{n:"#1E1E2A",a:"#9FE8FF",rn:"#E8E4F4",rb:"#C8A040",ra:"#7A4AE8"},"perch",(P,g)=>`<path d="M20 122 Q100 114 186 126" stroke="#5A4A3A" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("tail",128,106,`<path d="M124 100 L160 124 L150 132 L120 110 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 104 Q80 76 106 74 Q132 78 134 104 Q128 120 106 120 Q84 120 80 104 Z" fill="${P.n}" ${SW}/><path d="M90 84 Q106 78 124 86" stroke="#4A4A6A" stroke-width="3" fill="none" opacity=".8"/>`+
 pt("wingF",112,90,`<path d="M100 86 Q132 80 142 106 Q120 116 104 104 Z" fill="${P.n}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${118+i*8} ${96+i*2} l4 8" stroke="#4A4A6A" stroke-width="1.6"/>`).join("")}`)+
 `<path d="M98 118 l-2 6 M108 118 l0 6" stroke="${FI}" stroke-width="2.6"/>`+
 pt("head",94,80,`<path d="M74 74 Q74 56 92 54 Q108 56 108 72 Q104 84 92 86 Q78 84 74 74 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",96,82,`<path d="M84 80 L80 94 L88 86 L90 98 L94 86 L100 96 L100 82 Z" fill="${P.n}" ${SW2}/>`)+
  `<path d="M76 68 L54 72 L76 76 Z" fill="${FMOUTH}"/>`+pt("beak",76,76,`<path d="M76 76 L56 74 L76 79 Z" fill="${FI}" ${SW2}/>`)+`<path d="M78 64 Q60 64 52 72 L76 70 Z" fill="${FI}" ${SW2}/>`+
  `<rect x="54" y="70" width="10" height="5" rx="1" fill="${P.b}" ${SW2}/><circle cx="52" cy="72" r="2.4" fill="${P.ac}" class="p-glow"/>${fE(88,66,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<g class="p-glow"><path d="M40 60 l4 4 l-4 4 l4 4" stroke="${P.ac}" stroke-width="2" fill="none"/></g>`)+
 fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(122,50,6)));
FORM_TITLE["Sparkthief"]="Spark-Plug Raven";
