/* ---- Shipwreck Coast, 5 ---- */
/* Lusk's Lake Metal: addressed to a lake. A loon, the lake diver, with the returned parcel balanced on its back. */
addForm("Lusk's Lake Metal",{n:"#1A1A24",a:"#F4F0F4",rn:"#E8D8C8",rb:"#3A6A5A",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 120 Q60 112 104 120 Q150 128 194 118 V150 H14 Z" fill="#5A8AA8" opacity=".5"/>`+
 pt("tail",148,110,`<path d="M144 106 L162 108 L146 116 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M68 114 Q72 92 110 90 Q144 92 152 112 Q144 122 110 124 Q76 124 68 114 Z" fill="${P.n}" ${SW}/>${Array.from({length:16},(_,i)=>`<rect x="${86+(i%8)*7}" y="${96+Math.floor(i/8)*7}" width="2.6" height="2.6" fill="${P.ac}"/>`).join("")}`+
 `<g transform="rotate(-6 114 84)"><rect x="100" y="76" width="30" height="16" fill="#C89A5A" ${SW}/><path d="M100 84 h30 M115 76 v16" stroke="#8A6030" stroke-width="1.6"/><rect x="104" y="78" width="9" height="5" fill="#F4F0E4"/><text x="117" y="74" font-size="6" font-weight="bold" fill="#C8302A">RTS</text></g>`+
 pt("head",74,100,`<path d="M76 108 Q70 92 72 80" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M76 108 Q70 92 72 80" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M70 96 h8 M70 100 h8" stroke="${P.ac}" stroke-width="1.6"/><ellipse cx="70" cy="74" rx="11" ry="9" fill="${P.n}" ${SW}/>${E2(68,72,3,"#C8302A")}`+
  `<path d="M60 74 L42 76 L60 78 Z" fill="${FMOUTH}"/>`+pt("beak",60,78,`<path d="M60 78 L44 78 L60 81 Z" fill="${FI}"/>`)+`<path d="M60 70 L40 75 L60 76 Z" fill="${FI}"/>`)+
 fG(g,1,`<path d="M24 60 Q34 50 44 60" stroke="#F4F0F4" stroke-width="2.4" fill="none"/><path d="M28 70 q6 -6 12 0" stroke="#F4F0F4" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="110" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Lusk's Lake Metal"]="Return-to-Sender Loon";SM("Lusk's Lake Metal","Return To Sender","RES","a",60,100,"dodge","No such address. Sent straight back.");

/* Machine Four Metal: machine four has worked perfectly since a shipment was left on its lid. The odd sock that every machine eats, grown into a little monster. */
addForm("Machine Four Metal",{n:"#E8604A",a:"#F4F0F4",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"slink",(P,g)=>`<rect x="122" y="56" width="62" height="88" rx="4" fill="#E8ECF0" ${SW}/><circle cx="153" cy="104" r="22" fill="#9AB8D0" ${SW}/><circle cx="153" cy="104" r="16" fill="#C8E0F0" ${SW2}/><rect x="130" y="62" width="24" height="10" rx="2" fill="#3A3A44"/><text x="170" y="72" font-size="12" font-weight="bold" fill="${FI}">4</text>`+fShadow(66)+
 pt("sway",84,104,`<path d="M104 60 L108 106 Q108 132 82 136 L52 136 Q40 134 42 122 Q46 112 60 112 L84 110 L82 62 Z" fill="${P.n}" ${SW}/>${[72,84,96].map(y=>`<path d="M83 ${y} H106" stroke="${P.ac}" stroke-width="5"/>`).join("")}<path d="M80 60 H106 V70 H80 Z" fill="${P.ac}" ${SW2}/>`+
  pt("head",68,124,`${E2(60,122,4.4)}${E2(74,122,4.4)}`+HMOUTH(62,130,74,P,2.4)))+
 pt("armF",56,118,`<path d="M48 118 Q40 108 34 112" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fG(g,1,`${[[24,40],[40,30],[30,56]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="5" fill="#E8F4F8" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="94" cy="90" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Machine Four Metal"]="Odd-Sock Monster";SM("Machine Four Metal","Spin Cycle","STR","a",20,100,"multi:2-5,tacc-1@20","Round and round and round and round.");

/* Management Special: came with a receipt signed 'Management' and a tip of two buttons. A baboon in a tie, the boss of the whole operation. */
addForm("Management Special",{n:"#8A7A5A",a:"#E8604A",rn:"#3A3A4A",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",150,98,`<path d="M148 100 Q164 88 166 70 Q168 60 160 60" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M148 100 Q164 88 166 70 Q168 60 160 60" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",140,112,30,10,P.nd,P.ndd,.5)+
 `<path d="M84 110 Q80 82 114 78 Q150 80 152 108 Q148 124 116 124 Q86 124 84 110 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",130,114,28,10,P.n,P.ndd,0)+fLeg("legF",96,114,28,10,P.n,P.ndd,.8)+
 pt("head",86,82,`<path d="M58 86 Q56 60 82 58 Q104 60 106 84 Q104 96 90 98 L66 100 Z" fill="${P.n}" ${SW}/><path d="M50 84 Q50 72 66 72 Q78 74 78 86 Q76 98 62 100 Q50 98 50 84 Z" fill="${P.ac}" ${SW}/><path d="M52 84 h-2 M54 88 h-3" stroke="${FI}" stroke-width="1.6"/>${E2(76,72,3.6,"#3A2410")}<path d="M70 66 l12 2" stroke="${FI}" stroke-width="2.4"/>`+
  `<path d="M52 94 L72 96 L70 100 L54 98 Z" fill="${FMOUTH}"/>`+pt("jaw",68,100,`<path d="M72 98 Q62 108 52 98 Q62 102 72 101 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",96,66,`<circle cx="96" cy="66" r="5" fill="${P.n}" ${SW2}/>`)+
  `<path d="M84 98 L92 98 L90 104 L94 124 L88 128 L82 124 L86 104 Z" fill="#3A5AA8" ${SW2}/>`)+
 fG(g,1,`<g transform="rotate(-8 32 128)"><rect x="18" y="116" width="28" height="22" fill="#F4F0E4" ${SW2}/><text x="20" y="124" font-size="5" fill="${FI}">Management</text><circle cx="28" cy="132" r="2.4" fill="#C8A060" ${SW2}/><circle cx="36" cy="132" r="2.4" fill="#C8A060" ${SW2}/></g>`)+fG(g,2,`<circle cx="118" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Management Special"]="Boss Baboon";SM("Management Special","Delegate","RES","s",0,100,"atk+1,tspd-1","Somebody else can do that. Somebody else can do all of that.");

/* Marrowdunite: exists because the navigator got everyone lost. A sidewinder with a map in its jaws, its track going the wrong way. */
addForm("Marrowdunite",{n:"#D8B078",a:"#8A5A2A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"slink",(P,g)=>`<path d="M14 140 Q80 128 194 142 V150 H14 Z" fill="#E8C890" ${SW2}/>${[0,1,2,3].map(i=>`<path d="M${150-i*24} ${132+i%2} l14 -6" stroke="#C8A060" stroke-width="3" stroke-linecap="round"/>`).join("")}`+fShadow(66)+
 pt("tail",150,120,`<path d="M150 120 Q166 108 180 116 Q190 122 184 128" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M150 120 Q166 108 180 116 Q190 122 184 128" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("sway",110,118,`<path d="M58 112 Q80 96 100 114 Q120 132 140 114 Q148 108 152 120" stroke="${FI}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M58 112 Q80 96 100 114 Q120 132 140 114 Q148 108 152 120" stroke="${P.n}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M62 108 Q80 96 98 110 Q120 128 138 112" stroke="${P.ac}" stroke-width="3" stroke-dasharray="4 5" fill="none"/>`)+
 pt("head",56,104,`<path d="M34 108 Q34 94 50 92 Q66 94 66 106 Q62 118 50 118 Z" fill="${P.n}" ${SW}/><path d="M48 92 l2 -6 l4 6" fill="${P.n}" ${SW2}/>${E2(52,100,3,"#E8A020")}`+
  `<path d="M36 108 L50 110 L48 114 L38 112 Z" fill="${FMOUTH}"/>`+pt("jaw",48,113,`<path d="M50 112 Q42 118 36 112 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(-12 26 112)"><rect x="12" y="102" width="26" height="18" fill="#E8D8A0" ${SW2}/><path d="M16 108 q6 4 10 -2 q4 -4 8 2" stroke="#C8302A" stroke-width="1.4" fill="none" stroke-dasharray="2 2"/><path d="M30 112 l3 3 m0 -3 l-3 3" stroke="#C8302A" stroke-width="1.4"/></g>`))+
 fG(g,1,`<path d="M160 40 l6 -8 l6 8 l-6 8 Z" fill="none" stroke="${P.ac}" stroke-width="2"/><text x="163" y="44" font-size="7" font-weight="bold" fill="${P.ac}">?</text>`)+fG(g,2,`<circle cx="100" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Marrowdunite"]="Map-Biting Sidewinder";SM("Marrowdunite","Wrong Turn","RES","a",60,100,"tacc-1,tspd-1@30","Sideways is still a way. Just not the right one.");

/* Misheard Mix: dictated over crackly radio, four numbers misheard, worked anyway. An aardvark with radio-aerial ears, cupping one to hear better. */
addForm("Misheard Mix",{n:"#C8A090",a:"#8A6A5A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(72)+
 pt("tail",160,100,`<path d="M158 102 Q180 110 186 132" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M158 102 Q180 110 186 132" stroke="${P.n}" stroke-width="6.6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",148,114,26,10,P.nd,P.ndd,.5)+fLeg("legB",114,116,24,10,P.nd,P.ndd,1.3)+
 `<path d="M86 106 Q84 80 120 76 Q156 78 162 104 Q158 122 124 122 Q90 122 86 106 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",138,116,24,10,P.n,P.ndd,0)+fLeg("legF",100,116,24,10,P.n,P.ndd,.8)+
 pt("head",88,92,`<path d="M92 98 Q76 92 68 86" stroke="${P.n}" stroke-width="20" stroke-linecap="round"/><path d="M68 86 L30 104 Q26 108 30 112 L36 112 L72 98 Z" fill="${P.n}" ${SW}/><ellipse cx="30" cy="108" rx="4" ry="5" fill="${P.ac}" ${SW2}/>${E2(74,84,3.2)}`+HMOUTH(36,110,46,P,1.6)+
  pt("ear",82,74,`<path d="M80 76 L76 40" stroke="${FI}" stroke-width="3"/><circle cx="76" cy="38" r="3" fill="${P.b}" ${SW2}/><path d="M80 78 Q70 56 78 46 Q90 54 88 76 Z" fill="${P.ac}" ${SW2}/>`)+pt("ear",90,76,`<path d="M88 76 L96 42" stroke="${FI}" stroke-width="3"/><circle cx="96" cy="40" r="3" fill="${P.b}" ${SW2}/><path d="M86 78 Q92 54 104 50 Q106 66 94 80 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M30 40 l4 4 l-4 4 l4 4 M40 36 l5 6 l-5 6 l5 6" stroke="${P.ac}" stroke-width="2" fill="none"/><text x="50" y="50" font-size="10" font-weight="bold" fill="${P.ac}">?</text>`)+fG(g,2,`<circle cx="122" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Misheard Mix"]="Radio-Eared Aardvark";SM("Misheard Mix","Say Again","RES","a",65,90,"tacc-1@40","Did you say fourteen or forty? Never mind, it worked.");

/* Mittenite: a knitting ghost leaves a single mitten beside each new shipment. A snow monkey wearing that one mitten. */
addForm("Mittenite",{n:"#B8A890",a:"#E87A8A",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 140 Q60 130 104 140 Q150 150 194 136 V150 H14 Z" fill="#F4F8FC" ${SW2}/>`+fShadow(56)+
 pt("tail",126,124,`<path d="M124 124 l10 4" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 pt("legB",116,128,fOL("M116 124 L122 142 H130",P.nd,9),.5)+
 `<path d="M80 128 Q74 92 104 88 Q134 92 128 128 Q122 142 104 142 Q86 142 80 128 Z" fill="${P.n}" ${SW}/>${Array.from({length:8},(_,i)=>`<path d="M${86+i*5} ${96+i%3*8} q2 4 -1 8" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 pt("legF",92,128,fOL("M94 124 L88 142 H78",P.n,9))+
 pt("armB",124,104,fOL("M124 104 Q138 110 138 124",P.nd,8),.4)+
 pt("armF",84,104,fOL("M84 104 Q68 100 64 86",P.n,8)+`<path d="M54 64 Q50 84 58 92 Q70 94 74 82 L72 66 Q64 58 54 64 Z" fill="#C8302A" ${SW}/><path d="M72 72 Q80 70 80 76 Q78 80 72 80" fill="#C8302A" ${SW2}/>${[70,76,82].map(y=>`<path d="M56 ${y} h14" stroke="#F4F0F4" stroke-width="1.4"/>`).join("")}`)+
 pt("head",104,72,`<path d="M80 74 Q80 50 104 48 Q128 50 128 74 Q124 92 104 92 Q84 92 80 74 Z" fill="${P.n}" ${SW}/><path d="M88 76 Q88 62 104 62 Q120 62 120 76 Q116 88 104 88 Q92 88 88 76 Z" fill="${P.ac}" ${SW2}/>${E2(98,72,3.4,"#3A2410")}${E2(110,72,3.4,"#3A2410")}`+HMOUTH(100,82,108,P,2))+
 fG(g,1,`${[[30,30],[50,50],[170,30],[160,60],[140,20]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#fff" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,100,6)));
FORM_TITLE["Mittenite"]="One-Mitten Snow Monkey";SM("Mittenite","Warm Hands","RES","s",0,100,"heal:25,def+1","One mitten is better than none.");

/* Model Ship Metal: mixed up with a retired sailor's model ship. A gecko clinging inside a bottle, a tiny ship's mast beside it. */
addForm("Model Ship Metal",{n:"#5AA87A",a:"#F2C94C",rn:"#3A3A4A",rb:"#B8603A",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(80)+
 `<path d="M30 92 Q30 70 52 70 H150 Q160 70 164 80 L176 82 H186 V102 H176 L164 104 Q160 114 150 114 H52 Q30 114 30 92 Z" fill="#C8E8E0" opacity=".55" ${SW}/><rect x="184" y="84" width="8" height="16" fill="#B88A50" ${SW2}/><path d="M40 112 Q100 120 156 112" stroke="#6A8A9A" stroke-width="3" fill="none"/><path d="M50 78 Q90 72 130 76" stroke="#fff" stroke-width="3" fill="none" opacity=".7"/>`+
 `<path d="M60 108 H110 L104 114 H66 Z" fill="#8A5A2A" ${SW2}/><path d="M84 108 V80" stroke="#6A4A2A" stroke-width="2"/><path d="M84 82 L100 96 L84 100 Z M84 84 L70 98 L84 100 Z" fill="#F4F0E4" ${SW2}/>`+
 pt("tail",142,98,`<path d="M138 98 Q152 102 156 92 Q158 84 150 84" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M138 98 Q152 102 156 92 Q158 84 150 84" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 [[136,"legB",.5],[118,"legB",1],[130,"legF",0],[114,"legF",.7]].map(([x,c,d],i)=>pt(c,x,96,`<path d="M${x} 96 L${x+(i%2?-4:4)} ${i<2?84:108}" stroke="${FI}" stroke-width="3"/><circle cx="${x+(i%2?-4:4)}" cy="${i<2?84:108}" r="2.4" fill="${P.n}" ${SW2}/>`,d)).join("")+
 `<path d="M110 96 Q114 88 126 88 Q138 90 140 96 Q138 102 126 104 Q114 104 110 96 Z" fill="${P.n}" ${SW}/>${[118,126,134].map(x=>`<circle cx="${x}" cy="94" r="1.6" fill="${P.ac}"/>`).join("")}`+
 pt("head",110,96,`<path d="M96 96 Q98 88 106 88 Q114 90 114 96 Q112 104 104 104 Q98 104 96 96 Z" fill="${P.n}" ${SW}/>${E2(102,92,2.6,"#C8601A")}`+HMOUTH(96,98,102,P,1.4))+
 fG(g,1,`<path d="M20 140 h30 l-4 6 h-22 Z" fill="#8A5A2A" ${SW2}/>`)+fG(g,2,`<circle cx="126" cy="96" r="2.4" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,40,6)));
FORM_TITLE["Model Ship Metal"]="Ship-in-a-Bottle Gecko";SM("Model Ship Metal","Bottled Up","RES","s",0,100,"def+2,tspd-1","Safe inside the glass. Getting out is another matter.");

/* Monel: a seawater-proof nickel-copper alloy named for a company president around 1905. A marine iguana, the lizard that swims in the sea, sneezing out salt. */
addForm("Monel",{n:"#4A4A54",a:"#C8603A",rn:"#E8D8C8",rb:"#3A6A8A",ra:"#5FE0F0"},"crawl",(P,g)=>`<path d="M14 134 Q60 126 104 134 Q150 142 194 132 V150 H14 Z" fill="#7AB8E8" opacity=".35"/><path d="M14 140 Q40 132 70 140" stroke="#8A8A94" stroke-width="10" stroke-linecap="round"/>`+fShadow(76)+
 pt("tail",156,118,`<path d="M150 116 Q178 112 192 124" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M150 116 Q178 112 192 124" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 [[142,"legB",.5],[104,"legB",1.3]].map(([x,c,d])=>pt(c,x,124,fOL(`M${x} 122 L${x+8} 134 L${x+14} 138`,P.nd,6),d)).join("")+
 `<path d="M76 118 Q78 100 114 98 Q148 100 154 116 Q148 130 114 130 Q80 130 76 118 Z" fill="${P.n}" ${SW}/>${[86,98,110,122,134,146].map(x=>`<path d="M${x} 100 l2 -7 l2 7" fill="${P.nd}" ${SW2}/>`).join("")}<path d="M88 116 Q114 124 146 114" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".6"/>`+
 [[132,"legF",0],[92,"legF",.8]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x-8} 136 L${x-14} 140`,P.n,6),d)).join("")+
 pt("head",78,108,`<path d="M42 110 Q42 92 62 90 Q80 92 82 108 Q76 120 60 120 Z" fill="${P.n}" ${SW}/>${[[50,92],[58,88],[66,88]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.ac}" ${SW2}/>`).join("")}${E2(60,100,3.4,"#C8A020")}`+HMOUTH(44,114,52,P,2)+
  pt("tongue",42,104,`<path d="M40 104 q-8 -4 -14 -2 M40 106 q-10 2 -16 6" stroke="#E8F4F8" stroke-width="2.4" fill="none" stroke-linecap="round"/><circle cx="24" cy="102" r="1.6" fill="#E8F4F8"/><circle cx="22" cy="112" r="1.6" fill="#E8F4F8"/>`))+
 fG(g,1,`<path d="M170 40 q6 -6 12 0 q-6 6 -12 0 Z" fill="#E8F4F8" ${SW2}/>`)+fG(g,2,`<circle cx="114" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,60,6)));
FORM_TITLE["Monel"]="Salt-Sneezing Marine Iguana";SM("Monel","Seaproof","RES","s",0,100,"ward+1,def+1","Salt water, salt spray, salt air. None of it sticks.");

/* Moreby's Hat: the coded ledger was a shopping list: eggs, string, one very specific hat. A hen with all three: eggs in a basket, string, and the hat. */
addForm("Moreby's Hat",{n:"#C8703A",a:"#E8412C",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56)+
 pt("tail",136,96,`<path d="M130 100 Q150 70 162 78 Q156 90 148 96 Q160 92 162 104 Q148 108 132 108 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",116,118,`<path d="M116 116 L118 140" stroke="#E8B040" stroke-width="4"/><path d="M110 142 l8 -2 l8 2" stroke="#E8B040" stroke-width="2.4" fill="none"/>`,.5)+
 `<path d="M80 106 Q80 78 108 76 Q134 80 136 106 Q128 122 106 122 Q86 122 80 106 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${96+i*8} ${96+i%2*6} q4 6 0 10" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("legF",100,118,`<path d="M100 116 L98 140" stroke="#E8B040" stroke-width="4"/><path d="M90 142 l8 -2 l8 2" stroke="#E8B040" stroke-width="2.4" fill="none"/>`)+
 pt("wingF",108,98,`<path d="M100 92 Q124 88 132 108 Q116 114 104 106 Z" fill="${P.nd}" ${SW}/><path d="M118 104 L132 124" stroke="#6A4A2A" stroke-width="2"/><path d="M122 124 Q132 136 146 124 Z" fill="#B88A50" ${SW}/>${[128,134,140].map(x=>`<ellipse cx="${x}" cy="122" rx="3.4" ry="4.4" fill="#F4F0E4" ${SW2}/>`).join("")}`)+
 pt("head",86,76,`<circle cx="84" cy="70" r="13" fill="${P.n}" ${SW}/>${E2(80,66,3.2,"#E8A020")}<path d="M72 70 L62 72 L72 74 Z" fill="${FMOUTH}"/>`+pt("beak",72,74,`<path d="M72 74 L63 74 L72 76 Z" fill="#E8B040" ${SW2}/>`)+`<path d="M72 68 L60 71 L72 72 Z" fill="#E8B040" ${SW2}/><path d="M74 78 Q76 86 80 82" fill="${P.ac}" ${SW2}/>`+
  `<path d="M74 60 Q72 42 88 40 Q102 42 98 60 Z" fill="#3A5A8A" ${SW}/><path d="M66 60 H104" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M66 60 H104" stroke="#3A5A8A" stroke-width="2.4" stroke-linecap="round"/><path d="M98 46 Q112 36 116 46 Q108 48 100 50 Z" fill="#E8C040" ${SW2}/>`)+
 fG(g,1,`<path d="M20 130 q10 -14 20 0 q10 14 20 0" stroke="#C8A060" stroke-width="2" fill="none"/><circle cx="20" cy="130" r="4" fill="none" stroke="#C8A060" stroke-width="2"/>`)+fG(g,2,`<circle cx="106" cy="106" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Moreby's Hat"]="Shopping-List Hen";SM("Moreby's Hat","Eggs, String, Hat","RES","s",0,100,"heal:20,def+1,acc+1","Everything on the list, and nothing that isn't.");

/* Most Mysterious Metal: towed through the tractor parade three years running, Most Mysterious Entry. A parade-float dragon on wheels, streamers flying. */
addForm("Most Mysterious Metal",{n:"#7A4AB8",a:"#F2C94C",rn:"#3A3A4A",rb:"#5AB04A",ra:"#E8412C"},"stand",(P,g)=>fShadow(80)+
 `<rect x="60" y="114" width="110" height="18" rx="3" fill="#E8D8B8" ${SW}/>${[72,92,112,132,152].map((x,i)=>`<path d="M${x} 114 v18" stroke="${["#E8412C","#F2C94C","#4A8AE8","#5AB04A","#E8412C"][i]}" stroke-width="6"/>`).join("")}`+pt("spin",80,138,`<circle cx="80" cy="138" r="8" fill="#3A3A44" ${SW}/><path d="M74 138 h12 M80 132 v12" stroke="${P.b}" stroke-width="2"/>`)+pt("spin",150,138,`<circle cx="150" cy="138" r="8" fill="#3A3A44" ${SW}/><path d="M144 138 h12 M150 132 v12" stroke="${P.b}" stroke-width="2"/>`)+
 `<path d="M20 126 L60 122" stroke="${FI}" stroke-width="3"/>`+
 pt("tail",160,104,`<path d="M156 104 Q178 96 182 74 Q184 62 176 60" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M156 104 Q178 96 182 74 Q184 62 176 60" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/>${[[170,96],[180,80]].map(([x,y])=>`<path d="M${x} ${y} l8 2 l-4 -8 Z" fill="${P.ac}" ${SW2}/>`).join("")}`)+
 `<path d="M76 114 Q76 80 116 78 Q156 80 160 114 Z" fill="${P.n}" ${SW}/>${[90,104,118,132,146].map(x=>`<path d="M${x} 82 l5 -10 l5 10" fill="${P.ac}" ${SW2}/>`).join("")}${[[96,100],[118,98],[140,102]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="5" fill="none" stroke="${P.ac}" stroke-width="2"/>`).join("")}`+
 pt("head",80,92,`<path d="M84 100 Q74 80 70 66" stroke="${P.n}" stroke-width="18" stroke-linecap="round"/><path d="M38 64 Q40 46 62 44 Q82 46 84 62 Q80 74 64 76 L42 74 Z" fill="${P.n}" ${SW}/>${E2(64,56,4.4,"#F2C94C")}<path d="M44 74 L66 76 L64 80 L46 78 Z" fill="${FMOUTH}"/>`+pt("jaw",62,80,`<path d="M64 78 Q52 90 40 78 Q52 84 64 81 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M60 44 L56 30 M70 44 L74 30" stroke="${P.ac}" stroke-width="4" stroke-linecap="round"/><path d="M42 68 Q30 74 26 90 M44 70 Q34 84 36 98" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,1,`<rect x="20" y="40" width="34" height="14" rx="2" fill="#F2C94C" ${SW2}/><text x="24" y="50" font-size="7" font-weight="bold" fill="${FI}">1st ?</text>`)+fG(g,2,`<circle cx="118" cy="98" r="2.4" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Most Mysterious Metal"]="Parade-Float Dragon";SM("Most Mysterious Metal","Grand Parade","STR","a",75,100,"tacc-1@30","Streamers, music, and nobody quite sure what's under the sheet.");
