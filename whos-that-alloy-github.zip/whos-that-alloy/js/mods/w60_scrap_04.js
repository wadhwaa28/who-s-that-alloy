/* ---- Tinker's Scrapyard, 4 ---- */
/* Borrowed Pen Metal: borrowing a pen to sign for it is fine; returning it is unlucky. A curlew whose long curved beak is a borrowed pen. */
addForm("Borrowed Pen Metal",{n:"#B8A080",a:"#2A3A8A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>`<g transform="rotate(-4 50 136)"><rect x="20" y="128" width="54" height="14" fill="#F4F0E4" ${SW2}/><path d="M26 136 q8 -6 14 0 q6 4 12 -2" stroke="${P.ac}" stroke-width="1.6" fill="none"/></g>`+fShadow(54,110)+
 pt("tail",138,94,`<path d="M134 90 L154 98 L136 104 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",120,110,`<path d="M120 108 L122 140" stroke="#8A9AB0" stroke-width="3"/><path d="M114 142 h14" stroke="#8A9AB0" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M90 98 Q92 76 114 74 Q136 78 138 100 Q130 112 112 112 Q94 112 90 98 Z" fill="${P.n}" ${SW}/>${Array.from({length:8},(_,i)=>`<path d="M${98+(i%4)*9} ${82+Math.floor(i/4)*12} l3 6" stroke="${P.nd}" stroke-width="2"/>`).join("")}`+
 pt("legF",106,110,`<path d="M106 108 L104 140" stroke="#8A9AB0" stroke-width="3"/><path d="M96 142 h14" stroke="#8A9AB0" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",94,78,`<circle cx="92" cy="72" r="12" fill="${P.n}" ${SW}/>${E2(90,70,3,"#1A1A1A")}`+
  `<path d="M80 74 Q56 82 44 114 L48 114 Q60 86 82 78 Z" fill="${FMOUTH}"/>`+pt("beak",62,96,`<path d="M82 78 Q62 88 50 116 L54 118 Q66 92 82 82 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M80 72 Q54 80 42 112 L46 114 Q58 84 82 76 Z" fill="${P.ac}" ${SW2}/><path d="M42 112 l2 8 l4 -6 Z" fill="#C8C8D0" ${SW2}/><path d="M66 82 l-2 6" stroke="#C8A040" stroke-width="3"/>`)+
 fG(g,1,`<text x="150" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">keep it</text>`)+fG(g,2,`<circle cx="114" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Borrowed Pen Metal"]="Borrowed-Pen Curlew";SM("Borrowed Pen Metal","Sign Here","SCR","a",65,100,"tdef-1@30","Mind you don't give the pen back. Bad luck.");

/* Brennockite: the launch countdown stopped for nine minutes while staff searched for it. A chimpanzee astronaut in a bubble helmet. */
addForm("Brennockite",{n:"#5A4A3A",a:"#F4F0F4",rn:"#E8D8C8",rb:"#C8302A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M160 146 V40 L172 20 L184 40 V146 Z" fill="#E8E8F0" ${SW}/><path d="M160 120 L150 146 M184 120 L194 146" stroke="${FI}" stroke-width="3"/><rect x="164" y="60" width="16" height="8" fill="#C8302A"/>`+fShadow(54)+
 pt("legB",116,132,fOL("M116 124 L120 142 H132",P.ac,12),.5)+
 `<path d="M80 130 Q74 92 104 86 Q134 92 128 130 Q122 142 104 142 Q86 142 80 130 Z" fill="${P.ac}" ${SW}/><rect x="92" y="98" width="24" height="16" rx="2" fill="#C8C8D0" ${SW2}/>${[96,102,108].map(x=>`<circle cx="${x}" cy="106" r="2" fill="${["#C8302A","#5AB04A","#F2C94C"][(x-96)/6]}"/>`).join("")}`+
 pt("legF",92,132,fOL("M92 124 L88 142 H76",P.ac,12))+
 pt("armF",84,104,fOL("M84 104 Q68 98 64 84",P.ac,10)+`<path d="M58 76 l4 6 M64 74 l0 8 M70 76 l-2 6" stroke="${FI}" stroke-width="2"/>`)+pt("armB",126,104,fOL("M126 104 Q140 112 140 124",P.ac,10),.4)+
 pt("head",104,64,`<circle cx="104" cy="62" r="26" fill="#C8E8F8" opacity=".5" ${SW}/><path d="M86 66 Q86 46 104 44 Q122 46 122 66 Q118 80 104 80 Q90 80 86 66 Z" fill="${P.n}" ${SW}/><path d="M92 66 Q92 56 104 56 Q116 56 116 66 Q114 76 104 76 Q94 76 92 66 Z" fill="#C8A890"/>${E2(98,62,3,"#3A2410")}${E2(110,62,3,"#3A2410")}`+HMOUTH(98,70,110,P,2)+pt("ear",86,62,`<circle cx="84" cy="62" r="5" fill="#C8A890" ${SW2}/>`)+`<path d="M88 46 Q96 40 104 42" stroke="#fff" stroke-width="3" fill="none" opacity=".7"/>`)+
 fG(g,1,`<text x="20" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">T-9:00</text>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="#C8302A" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["Brennockite"]="Astronaut Chimp";SM("Brennockite","Liftoff","STR","a",85,90,"selfspd-1","Three, two, one... and up.");

/* Bunchium: 'a pinch' was read as 'a bunch'. A creature made of one big bunch of grapes, stalk for a sprout of hair. */
addForm("Bunchium",{n:"#7A4AA8",a:"#5A9A3A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"hop",(P,g)=>fShadow(50)+
 [[118,"legB",.5],[92,"legF",0]].map(([x,c,d])=>pt(c,x,128,`<circle cx="${x}" cy="134" r="8" fill="${P.n}" ${SW}/><circle cx="${x-2}" cy="132" r="2" fill="#fff" opacity=".5"/>`,d)).join("")+
 pt("sway",104,96,`${[[84,70],[100,66],[116,70],[76,86],[92,84],[108,84],[124,86],[82,102],[98,100],[114,100],[126,104],[90,116],[106,116],[118,118]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="10" fill="${P.n}" ${SW}/><circle cx="${x-3}" cy="${y-3}" r="2.4" fill="#fff" opacity=".45"/>`).join("")}`+
  pt("head",100,90,`${E2(94,86,4)}${E2(110,86,4)}`+HMOUTH(96,96,108,P,2.6)))+
 pt("ant",100,60,`<path d="M100 60 Q98 44 106 36 M102 50 Q112 44 118 46" stroke="#6A4A2A" stroke-width="3" fill="none"/><path d="M106 40 Q120 30 132 38 Q122 50 108 46 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("armF",72,92,`<circle cx="62" cy="96" r="7" fill="${P.n}" ${SW2}/>`)+pt("armB",134,92,`<circle cx="144" cy="96" r="7" fill="${P.n}" ${SW2}/>`,.4)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">a bunch</text>`)+fG(g,2,`<circle cx="98" cy="100" r="2.6" fill="${P.ll}"/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Bunchium"]="Grape-Bunch Sprite";SM("Bunchium","A Whole Bunch","STR","a",20,100,"multi:2-5","Not a pinch. A bunch. Considerably more.");

/* Burlex: twelve years in a time capsule under an oak, which grew a burl in a familiar shape. A koala clinging to that oak, its burl bulging beside it. */
addForm("Burlex",{n:"#9A9AA4",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M126 0 Q120 70 128 150 H160 Q152 70 158 0 Z" fill="#8A6A4A" ${SW}/>${[20,50,90,120].map(y=>`<path d="M132 ${y} q8 6 20 0" stroke="#6A4A2A" stroke-width="1.6" fill="none"/>`).join("")}<ellipse cx="150" cy="104" rx="16" ry="14" fill="#7A5A3A" ${SW}/><path d="M142 100 q4 -4 8 0 q4 4 8 0" stroke="#5A3A2A" stroke-width="1.6" fill="none"/><ellipse cx="146" cy="20" rx="26" ry="10" fill="#5A9A4A" ${SW2}/>`+fShadow(40,104)+
 pt("legB",122,120,fOL("M118 116 Q130 120 128 130",P.nd,10),.5)+
 `<path d="M86 118 Q80 84 104 80 Q126 84 126 118 Q120 130 104 130 Q90 130 86 118 Z" fill="${P.n}" ${SW}/><path d="M94 114 Q104 122 116 114 Q114 100 104 98 Q96 100 94 114 Z" fill="${P.ac}"/>`+
 pt("armB",120,90,fOL("M118 92 Q126 84 130 78",P.nd,10),.4)+pt("armF",116,104,fOL("M114 104 Q124 102 130 98",P.n,10))+
 pt("head",100,70,`<path d="M80 72 Q80 52 100 50 Q120 52 120 72 Q116 86 100 86 Q84 86 80 72 Z" fill="${P.n}" ${SW}/><ellipse cx="100" cy="72" rx="7" ry="9" fill="#3A3A44" ${SW2}/>${E2(90,64,3,"#3A2410")}${E2(112,64,3,"#3A2410")}`+HMOUTH(96,82,104,P,1.6)+
  pt("ear",80,56,`<circle cx="78" cy="56" r="10" fill="${P.n}" ${SW}/><circle cx="78" cy="56" r="5" fill="${P.ac}"/>`)+pt("ear",120,56,`<circle cx="122" cy="56" r="10" fill="${P.n}" ${SW}/><circle cx="122" cy="56" r="5" fill="${P.ac}"/>`,.3))+
 fG(g,1,`<rect x="24" y="130" width="22" height="14" rx="3" fill="#C8C8D0" ${SW2}/><text x="26" y="140" font-size="7" font-weight="bold" fill="${FI}">12y</text>`)+fG(g,2,`<circle cx="104" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Burlex"]="Oak-Burl Koala";SM("Burlex","Hold Fast","RES","s",0,100,"def+1,endure","Twelve years clinging on. It's not letting go now.");

/* Callout Metal: rescue volunteers pat its crate on their way out. A St Bernard with its brandy-barrel collar, ready for the call-out. */
addForm("Callout Metal",{n:"#F4F0E8",a:"#B85A2A",rn:"#3A3A4A",rb:"#C8302A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 140 Q60 130 104 140 Q150 150 194 136 V150 H14 Z" fill="#F4F8FC" ${SW2}/>`+fShadow(72)+
 pt("tail",160,98,`<path d="M156 100 Q174 104 176 122" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M156 100 Q174 104 176 122" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",148,112,28,11,P.n,P.ndd,.5)+fLeg("legB",114,114,26,11,P.n,P.ndd,1.3)+
 `<path d="M84 104 Q84 78 120 76 Q156 78 162 102 Q158 122 122 122 Q88 122 84 104 Z" fill="${P.n}" ${SW}/><path d="M104 78 Q134 74 156 90 L152 106 Q128 98 106 100 Z" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",138,114,26,11,P.n,P.ndd,0)+fLeg("legF",98,114,26,11,P.n,P.ndd,.8)+
 pt("head",86,90,`<path d="M48 98 Q46 74 70 72 Q94 74 96 96 Q92 112 72 112 Q52 112 48 98 Z" fill="${P.n}" ${SW}/><path d="M54 80 Q70 70 90 82 L86 94 Q72 84 58 92 Z" fill="${P.ac}"/><ellipse cx="48" cy="98" rx="4" ry="3.4" fill="${FI}"/>${E2(64,88,3.6,"#3A2410",[-.4,.3])}${E2(80,86,3.4,"#3A2410",[-.4,.3])}`+HMOUTH(50,104,60,P,2.4)+
  pt("ear",86,78,`<path d="M84 76 Q100 76 98 98 Q92 104 86 96 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M60 110 Q76 118 92 110" stroke="#C8302A" stroke-width="4" fill="none"/><rect x="68" y="114" width="14" height="10" rx="4" fill="#8A5A2A" ${SW}/><path d="M72 114 v10 M78 114 v10" stroke="${P.b}" stroke-width="1.6"/>`)+
 fG(g,1,`<path d="M20 40 h20 v14 h-20 Z" fill="#C8302A" ${SW2}/><path d="M30 42 v10 M25 47 h10" stroke="#fff" stroke-width="3"/>`)+fG(g,2,`<circle cx="122" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Callout Metal"]="Rescue St Bernard";SM("Callout Metal","Call-Out","RES","s",0,100,"heal:40,cure","Somebody's stuck on the fell. Out we go.");

/* Camel's Worth: traded for a single fine camel. A camel spider, the desert hunter that isn't a spider or a camel. */
addForm("Camel's Worth",{n:"#D8B078",a:"#8A5A2A",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 140 Q80 128 194 142 V150 H14 Z" fill="#E8C890" ${SW2}/>`+fShadow(70)+
 [0,1,2,3].map(i=>pt("legB",112+i*4,118,`<path d="M${112+i*4} 118 Q${134+i*12} ${96+i*4} ${150+i*12} 140" stroke="${FI}" stroke-width="5" fill="none"/><path d="M${112+i*4} 118 Q${134+i*12} ${96+i*4} ${150+i*12} 140" stroke="${P.nd}" stroke-width="2.6" fill="none"/>`,i*.15)).join("")+
 `<ellipse cx="128" cy="116" rx="22" ry="14" fill="${P.n}" ${SW}/>${[116,126,136].map(x=>`<path d="M${x} 104 q2 12 0 22" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}<ellipse cx="98" cy="112" rx="14" ry="12" fill="${P.n}" ${SW}/>`+
 [0,1,2,3].map(i=>pt("legF",100-i*4,120,`<path d="M${100-i*4} 120 Q${80-i*10} ${100+i*4} ${64-i*12} 140" stroke="${FI}" stroke-width="5" fill="none"/><path d="M${100-i*4} 120 Q${80-i*10} ${100+i*4} ${64-i*12} 140" stroke="${P.n}" stroke-width="2.6" fill="none"/>`,i*.15+.1)).join("")+
 pt("head",84,108,`<path d="M66 114 Q66 98 82 96 Q94 98 94 112 Z" fill="${P.n}" ${SW}/>${E2(82,102,3.4,"#1A1A1A")}${E2(90,104,3,"#1A1A1A")}`+
  pt("jaw",66,112,`<path d="M70 108 L50 100 L52 106 L68 114 Z" fill="${P.ac}" ${SW2}/><path d="M70 116 L50 122 L52 116 L68 112 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M160 30 Q170 18 180 30 Q190 18 194 34 Q190 44 160 44 Z" fill="#D8B078" ${SW2}/>`)+fG(g,2,`<circle cx="128" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Camel's Worth"]="Camel Spider";SM("Camel's Worth","Fair Swap","SCR","a",75,100,"drain:20","Worth exactly one camel. Or exactly not.");

/* Canteen Sprint Mix: a timer went off in a coat pocket down in the canteen, and somebody sprinted. A basilisk lizard, sprinting so fast it runs on water. */
addForm("Canteen Sprint Mix",{n:"#5AA86A",a:"#E8C060",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 132 Q60 124 104 132 Q150 140 194 130 V150 H14 Z" fill="#7AB8E8" opacity=".4"/>${[[60,132],[90,134],[120,130]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="10" ry="3" fill="none" stroke="#fff" stroke-width="2"/>`).join("")}`+
 pt("tail",136,92,`<path d="M132 92 Q166 96 192 78" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M132 92 Q166 96 192 78" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("legB",120,104,`<path d="M120 102 L136 118 L128 128 H140" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M120 102 L136 118 L128 128 H140" stroke="${P.nd}" stroke-width="4.4" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,.0)+
 `<path d="M84 96 Q88 76 110 74 Q132 78 136 96 Q128 108 110 108 Q90 108 84 96 Z" fill="${P.n}" ${SW}/>${[94,104,114,124].map(x=>`<path d="M${x} 76 l3 -10 l3 10" fill="${P.n}" ${SW2}/>`).join("")}`+
 pt("legF",100,104,`<path d="M100 102 L86 116 L74 128 H62" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M100 102 L86 116 L74 128 H62" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,.5)+
 pt("armF",92,90,fOL("M92 90 L80 98 L82 104",P.n,4))+
 pt("head",86,80,`<path d="M54 80 Q56 66 72 64 Q88 66 90 80 Q86 90 72 90 Z" fill="${P.n}" ${SW}/><path d="M70 64 Q76 50 86 54 Q82 60 80 66 Z" fill="${P.n}" ${SW2}/>${E2(72,74,3.4,"#E8A020")}`+HMOUTH(56,84,64,P,2))+
 fG(g,1,`<path d="M20 70 h-6 M26 80 h-12 M20 90 h-8" stroke="${P.l}" stroke-width="2.4" stroke-linecap="round"/><text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">DING!</text>`)+fG(g,2,`<circle cx="110" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Canteen Sprint Mix"]="Water-Running Basilisk";SM("Canteen Sprint Mix","Sprint","STR","a",55,100,"prio,spd+1","Too fast to sink. Too fast to stop.");

/* Capsulon: buried in the school time capsule, dug up twenty-five years early. An echidna, the great digger, nosing out of the dug-up capsule. */
addForm("Capsulon",{n:"#6A5A4A",a:"#F4E8C0",rn:"#3A3A4A",rb:"#C8C8D0",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 120 H194 V150 H14 Z" fill="#8A6A4A"/><path d="M14 120 H194" stroke="#5A9A3A" stroke-width="6"/><path d="M60 132 Q60 108 80 108 H140 Q160 108 160 132 Q160 148 140 148 H80 Q60 148 60 132 Z" fill="#C8C8D0" ${SW}/><path d="M120 108 V148" stroke="${FI}" stroke-width="2"/><text x="124" y="134" font-size="7" font-weight="bold" fill="${FI}">2050</text>`+
 pt("sway",96,100,`<path d="M62 116 Q60 80 96 76 Q130 80 132 114 Z" fill="${P.n}" ${SW}/>${Array.from({length:18},(_,i)=>{const a=-2.9+i*.15,x=98+Math.cos(a)*30,y=114+Math.sin(a)*34;return`<path d="M${x} ${y} L${x+Math.cos(a)*14} ${y+Math.sin(a)*14}" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M${x} ${y} L${x+Math.cos(a)*14} ${y+Math.sin(a)*14}" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`}).join("")}`)+
 pt("head",62,104,`<path d="M66 110 Q60 96 72 94 Q82 98 80 110 Z" fill="${P.n}" ${SW}/><path d="M66 102 L32 92 L32 96 L66 108 Z" fill="${P.n}" ${SW}/>${E2(70,100,2.6,"#1A1A1A")}`+pt("tongue",32,94,`<path d="M32 94 q-8 2 -12 -2" stroke="${FTONGUE}" stroke-width="1.6" fill="none"/>`))+
 pt("armF",80,114,`<path d="M80 114 l-8 6 M76 114 l-4 8 M84 114 l-4 8" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M170 100 l10 -14 l6 4 l-10 14 Z" fill="#C8C8D0" ${SW2}/><path d="M168 108 l6 -4" stroke="#6A4A2A" stroke-width="4"/>`)+fG(g,2,`<circle cx="98" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Capsulon"]="Capsule-Digging Echidna";SM("Capsulon","Dig Up Early","RES","a",65,100,"def+1","Twenty-five years too soon, but here it is.");

/* Car Wash Special: the courier's map sent the truck through a car wash twice. A shaggy sheepdog whose coat looks exactly like the spinning brushes. */
addForm("Car Wash Special",{n:"#E8E4E0",a:"#3A5AA8",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(72)+
 pt("tail",160,98,`<path d="M156 98 Q172 90 174 80" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M156 98 Q172 90 174 80" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",146,114,26,11,P.n,P.n,.5)+fLeg("legB",112,116,24,11,P.n,P.n,1.3)+
 pt("spin",122,98,`<path d="M84 104 Q84 76 122 74 Q160 76 164 102 Q160 122 124 122 Q88 122 84 104 Z" fill="${P.n}" ${SW}/>${Array.from({length:24},(_,i)=>`<path d="M${88+(i%8)*10} ${82+Math.floor(i/8)*12} q4 6 -2 10" stroke="${i%3?P.ac:"#9AA0B0"}" stroke-width="3" fill="none" stroke-linecap="round"/>`).join("")}`)+
 fLeg("legF",138,116,24,11,P.n,P.n,0)+fLeg("legF",100,116,24,11,P.n,P.n,.8)+
 pt("head",86,90,`<path d="M50 94 Q48 70 72 68 Q94 70 96 92 Q92 108 72 108 Q54 108 50 94 Z" fill="${P.n}" ${SW}/>${Array.from({length:8},(_,i)=>`<path d="M${56+i*5} 72 q2 10 -2 16" stroke="${i%2?P.ac:"#9AA0B0"}" stroke-width="3" fill="none" stroke-linecap="round"/>`).join("")}<ellipse cx="50" cy="96" rx="4" ry="3.4" fill="${FI}"/>`+HMOUTH(52,102,62,P,2)+
  pt("tongue",56,104,`<path d="M54 104 Q54 114 58 114 Q62 114 60 104 Z" fill="${FTONGUE}" ${SW2}/>`))+
 fG(g,1,`${[[30,40],[40,30],[20,56],[176,40]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="5" fill="#E8F4F8" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Car Wash Special"]="Car-Wash Sheepdog";SM("Car Wash Special","Rinse Cycle","DRP","a",65,100,"cure","Soap, scrub, spin, rinse. Twice, if you're unlucky.");

/* Caravanine: caravans travelled at night, partly to dodge questions. An oryx crossing the dunes under the stars, horns like two long lines. */
addForm("Caravanine",{n:"#E8E0D0",a:"#3A3A40",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 140 Q60 120 104 136 Q150 150 194 130 V150 H14 Z" fill="#C8A878" ${SW2}/>${[[30,30],[60,20],[150,24],[176,44],[130,40]].map(([x,y])=>`<path d="M${x} ${y} l1.4 -3 l1.4 3 l3 1.4 l-3 1.4 l-1.4 3 l-1.4 -3 l-3 -1.4 Z" fill="#F2D060"/>`).join("")}`+fShadow(70)+
 pt("tail",158,94,fOL("M156 94 Q166 104 164 118",P.ac,4))+
 fLeg("legB",146,106,34,7,P.n,P.ac,.5)+fLeg("legB",116,108,32,7,P.n,P.ac,1.3)+
 `<path d="M88 98 Q88 78 120 76 Q152 78 156 96 Q152 112 122 112 Q92 112 88 98 Z" fill="${P.n}" ${SW}/><path d="M92 104 Q120 112 152 102" stroke="${P.ac}" stroke-width="4" fill="none"/>`+
 fLeg("legF",138,108,32,7,P.n,P.ac,0)+fLeg("legF",100,108,32,7,P.n,P.ac,.8)+
 pt("head",92,86,`<path d="M96 92 Q86 80 80 68" stroke="${P.n}" stroke-width="14" stroke-linecap="round"/><path d="M56 70 Q58 56 74 56 Q88 58 88 70 Q84 80 72 80 L58 78 Z" fill="${P.n}" ${SW}/><path d="M62 62 L64 76 M74 58 L72 76" stroke="${P.ac}" stroke-width="3"/>${E2(70,66,3.2,"#1A1A1A")}`+HMOUTH(58,74,66,P,1.8)+
  pt("ear",86,60,`<path d="M84 60 Q94 54 96 60 Q90 66 84 64 Z" fill="${P.n}" ${SW2}/>`)+`<path d="M76 56 L108 10" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M76 56 L108 10" stroke="${P.ac}" stroke-width="2.6" stroke-linecap="round"/><path d="M80 58 L116 16" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M80 58 L116 16" stroke="${P.ac}" stroke-width="2.6" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M30 70 a10 10 0 1 0 8 -10 a7 7 0 1 1 -8 10 Z" fill="#F2D060" ${SW2}/>`)+fG(g,2,`<circle cx="122" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Caravanine"]="Starlit Oryx";SM("Caravanine","Night Crossing","RES","s",0,100,"dodge,spd+1","Travel by night. Fewer questions.");
