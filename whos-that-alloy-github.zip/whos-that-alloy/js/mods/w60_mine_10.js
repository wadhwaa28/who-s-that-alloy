/* ---- Rustvein Mine, 10 ---- */
/* Pawvote Blend: approved by a vote of cats, ballots covered in paw prints. A lynx in a rosette, a ballot paper in its jaws. */
addForm("Pawvote Blend",{n:"#C8A070",a:"#2A2A30",rn:"#E8E0D0",rb:"#3A5A3A",ra:"#E8412C"},"stand",(P,g)=>fShadow(70)+
 pt("tail",160,94,`<path d="M156 94 Q166 90 168 98" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M156 94 Q166 90 168 98" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="168" cy="99" r="3.4" fill="${P.ac}"/>`)+
 fLeg("legB",148,110,32,10,P.nd,P.ndd,.5)+fLeg("legB",114,112,30,10,P.nd,P.ndd,1.3)+
 `<path d="M88 104 Q88 80 122 78 Q156 80 160 102 Q156 120 124 120 Q92 120 88 104 Z" fill="${P.n}" ${SW}/>${[[104,90],[120,96],[138,88],[146,104],[110,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.ndd}"/>`).join("")}`+
 fLeg("legF",140,112,30,10,P.n,P.ndd,0)+fLeg("legF",100,112,30,10,P.n,P.ndd,.8)+
 pt("head",94,90,`<path d="M58 92 Q58 70 80 68 Q102 70 104 90 Q100 106 80 106 Q62 106 58 92 Z" fill="${P.n}" ${SW}/><path d="M58 96 L48 104 L60 104 M102 96 L112 106 L100 104" fill="#F4F0E4" ${SW2}/><ellipse cx="62" cy="92" rx="3" ry="2.4" fill="${FI}"/>${E2(72,84,4,"#A8A020")}${E2(88,84,4,"#A8A020")}`+
  `<path d="M62 98 L76 98 L74 102 L64 102 Z" fill="${FMOUTH}"/>`+pt("jaw",74,101,`<path d="M76 100 Q68 106 62 100 Q68 103 76 103 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(14 54 106)"><rect x="40" y="98" width="20" height="14" fill="#F4F0E4" ${SW2}/><rect x="44" y="102" width="5" height="5" fill="none" stroke="${FI}" stroke-width="1"/><ellipse cx="54" cy="106" rx="2" ry="1.6" fill="${FI}"/></g>`)+
  pt("ear",70,70,`<path d="M64 74 L68 52 L80 70 Z" fill="${P.n}" ${SW2}/><path d="M68 52 L67 42" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+pt("ear",92,72,`<path d="M88 70 L98 52 L102 76 Z" fill="${P.nd}" ${SW2}/><path d="M98 52 L100 42" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.3)+
  `<circle cx="104" cy="100" r="7" fill="#3A5AA8" ${SW2}/><path d="M102 106 l-2 8 M106 106 l2 8" stroke="#3A5AA8" stroke-width="3"/><circle cx="104" cy="100" r="3" fill="#F2C94C"/>`)+
 fG(g,1,`<rect x="20" y="116" width="28" height="26" fill="#6A4A3A" ${SW2}/><rect x="28" y="114" width="12" height="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Pawvote Blend"]="Ballot Lynx";SM("Pawvote Blend","Landslide","STR","a",75,100,"","The vote wasn't close. It was never going to be close.");


/* Platform Two Special: eleven passengers waited on platform two for a 'departure' that was its catalogue number. A pigeon on the platform under the departure board. */
addForm("Platform Two Special",{n:"#8A8A9A",a:"#5AA87A",rn:"#E8D8C8",rb:"#B85A3A",ra:"#E8412C"},"stand",(P,g)=>`<rect x="14" y="140" width="180" height="8" fill="#C8C0B0" ${SW2}/><path d="M14 140 H194" stroke="#F2C94C" stroke-width="3"/><rect x="120" y="12" width="68" height="30" rx="3" fill="#1A1A22" ${SW2}/><text x="124" y="24" font-size="8" font-weight="bold" fill="#F2C94C" font-family="monospace">2  92:14</text><text x="124" y="36" font-size="7" fill="#F2C94C" font-family="monospace">ON TIME?</text><path d="M134 42 V56 M174 42 V56" stroke="${FI}" stroke-width="2"/>`+fShadow(50,110)+
 pt("tail",136,110,`<path d="M132 104 L156 112 L152 122 L130 116 Z" fill="${P.nd}" ${SW}/><path d="M138 112 l14 6" stroke="${P.ndd}" stroke-width="3"/>`)+
 pt("legB",112,126,`<path d="M112 124 L114 138" stroke="#E87A8A" stroke-width="3"/><path d="M106 140 h14" stroke="#E87A8A" stroke-width="3" stroke-linecap="round"/>`,.5)+
 `<path d="M80 110 Q82 84 110 82 Q136 86 138 110 Q130 128 108 128 Q86 126 80 110 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",110,100,`<path d="M100 96 Q128 92 140 110 Q124 122 104 116 Z" fill="${P.nd}" ${SW}/><path d="M112 104 h18 M114 110 h16" stroke="${P.ndd}" stroke-width="3"/>`)+
 pt("legF",98,126,`<path d="M98 124 L96 138" stroke="#E87A8A" stroke-width="3"/><path d="M88 140 h14" stroke="#E87A8A" stroke-width="3" stroke-linecap="round"/>`)+
 pt("head",88,84,`<path d="M86 96 Q80 84 84 74" stroke="${P.ac}" stroke-width="16" stroke-linecap="round"/><circle cx="82" cy="70" r="12" fill="${P.n}" ${SW}/>${E2(78,66,3.6,"#E87A2A")}<path d="M70 70 L60 72 L70 74 Z" fill="${FMOUTH}"/>`+pt("beak",70,74,`<path d="M70 74 L61 74 L70 76 Z" fill="#3A3A44"/>`)+`<path d="M70 68 L58 71 L70 72 Z" fill="#3A3A44"/><circle cx="71" cy="68" r="2" fill="#F4F0F4"/>`)+
 fG(g,1,`<path d="M30 140 v-30 h8 v30 M28 110 h12" stroke="${FI}" stroke-width="2" fill="none"/><rect x="26" y="96" width="16" height="14" fill="#3A5AA8" ${SW2}/><text x="31" y="107" font-size="10" font-weight="bold" fill="#fff">2</text>`)+fG(g,2,`<circle cx="108" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(60,40,6)));
FORM_TITLE["Platform Two Special"]="Platform Pigeon";SM("Platform Two Special","Mind The Gap","RES","s",0,100,"tacc-1,spd+1","Please stand well back from the edge.");

/* Ploverine: two birdwatchers bet whether a rare plover would come before noon. It never came. Here it is anyway, hiding behind its own binoculars. */
addForm("Ploverine",{n:"#C8B090",a:"#2A2A30",rn:"#E8E0D0",rb:"#3A6A4A",ra:"#E8412C"},"stand",(P,g)=>fShadow(54,110)+
 pt("tail",136,98,`<path d="M132 94 L152 100 L132 106 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",116,110,`<path d="M116 108 L118 142" stroke="${FI}" stroke-width="3.4"/><path d="M110 142 h14" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M84 98 Q86 76 108 74 Q132 78 136 100 Q128 114 106 114 Q88 112 84 98 Z" fill="${P.n}" ${SW}/><path d="M86 100 Q96 112 110 112 Q100 104 96 92 Z" fill="#F4F0E4"/><path d="M92 82 Q100 78 108 80" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 pt("legF",102,110,`<path d="M102 108 L100 142" stroke="${FI}" stroke-width="3.4"/><path d="M92 142 h14" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",90,74,`<circle cx="84" cy="68" r="14" fill="${P.n}" ${SW}/><path d="M72 60 Q84 54 96 60" stroke="${P.ac}" stroke-width="4" fill="none"/><path d="M72 72 Q84 78 96 72" stroke="#F4F0E4" stroke-width="4" fill="none"/>`+
  `<path d="M72 68 L62 70 L72 72 Z" fill="${FMOUTH}"/>`+pt("beak",72,72,`<path d="M72 72 L63 72 L72 74 Z" fill="${FI}"/>`)+`<path d="M72 66 L60 69 L72 70 Z" fill="${FI}"/>`)+
 pt("wingF",94,88,`<path d="M100 86 Q86 80 78 72" stroke="${P.nd}" stroke-width="7" stroke-linecap="round"/><g transform="rotate(-10 74 66)"><rect x="64" y="56" width="10" height="16" rx="3" fill="#2A2A30" ${SW2}/><rect x="76" y="56" width="10" height="16" rx="3" fill="#2A2A30" ${SW2}/><rect x="72" y="60" width="6" height="6" fill="#2A2A30"/><circle cx="69" cy="58" r="4" fill="#7AB8E8" ${SW2}/><circle cx="81" cy="58" r="4" fill="#7AB8E8" ${SW2}/></g>`)+
 fG(g,1,`<rect x="160" y="30" width="26" height="26" rx="13" fill="#F4F0E4" ${SW2}/><path d="M173 34 V43 L178 47" stroke="${FI}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="110" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,70,6)));
FORM_TITLE["Ploverine"]="No-Show Plover";SM("Ploverine","Never Showed","RES","s",0,100,"dodge,spd+1","Wait all morning if you like. It isn't coming.");

/* Potin: cast in clay strip moulds by Iron Age Celts for coins, which often carried a stylised boar. The boar from those coins, in swirls and dots. */
addForm("Potin",{n:"#7A6A5A",a:"#E8D8A0",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(70)+
 pt("tail",160,90,`<path d="M158 90 Q172 82 168 72 Q160 70 162 80" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M158 90 Q172 82 168 72 Q160 70 162 80" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",146,108,30,9,P.nd,P.ndd,.5)+fLeg("legB",112,110,28,9,P.nd,P.ndd,1.3)+
 `<path d="M86 100 Q84 74 120 70 Q158 72 162 98 Q158 118 122 118 Q90 118 86 100 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${96+i*8} ${70-(i<4?i:7-i)*2} l2 -14" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M${96+i*8} ${70-(i<4?i:7-i)*2} l2 -14" stroke="${P.nd}" stroke-width="2.6" stroke-linecap="round"/>`).join("")}`+
 `<path d="M108 96 a8 8 0 1 1 16 0 a5 5 0 1 1 -10 0" stroke="${P.ac}" stroke-width="2.4" fill="none"/><path d="M132 92 a7 7 0 1 0 14 0 a4 4 0 1 0 -8 0" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${[[100,108],[118,110],[136,110],[150,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.ac}"/>`).join("")}`+
 fLeg("legF",136,110,28,9,P.n,P.ndd,0)+fLeg("legF",100,110,28,9,P.n,P.ndd,.8)+
 pt("head",90,90,`<path d="M52 92 Q52 74 74 72 Q92 74 94 92 Q90 106 72 106 Z" fill="${P.n}" ${SW}/><path d="M52 90 L42 88 L42 100 L54 100 Z" fill="${P.nd}" ${SW2}/><circle cx="45" cy="92" r="1.6" fill="${FI}"/><circle cx="45" cy="97" r="1.6" fill="${FI}"/>`+
  `<circle cx="72" cy="84" r="5" fill="none" stroke="${P.ac}" stroke-width="2"/>${E2(72,84,3,"#3A2410")}`+pt("jaw",54,102,`<path d="M54 100 L68 104 L66 108 L54 106 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M58 98 Q52 88 56 82" stroke="#F4F0E4" stroke-width="3.4" fill="none" stroke-linecap="round"/>`+
  pt("ear",82,74,`<path d="M78 76 L84 60 L90 76 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<circle cx="32" cy="128" r="12" fill="${P.b}" ${SW2}/><circle cx="32" cy="128" r="8" fill="none" stroke="${P.d}" stroke-width="1.6"/><circle cx="32" cy="128" r="2" fill="${P.d}"/>`)+fG(g,2,`<circle cx="122" cy="96" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(122,30,6)));
FORM_TITLE["Potin"]="Coin-Stamp Boar";SM("Potin","Strike The Die","STR","a",75,100,"tdef-1@30","One hard blow, and the picture is pressed in for good.");

/* Potterite: a pottery class ended up with this recipe instead. A clay-pot golem on a turning wheel, still being shaped. */
addForm("Potterite",{n:"#C87A4A",a:"#7AB0C8",rn:"#3A3A4A",rb:"#E8D8C0",ra:"#F2C94C"},"stand",(P,g)=>`<ellipse cx="104" cy="140" rx="46" ry="8" fill="#6A6A74" ${SW}/>`+pt("spin",104,138,`<ellipse cx="104" cy="137" rx="40" ry="5" fill="#8A8A94" ${SW2}/><path d="M74 137 h10 M124 137 h10" stroke="#5A5A64" stroke-width="2"/>`)+
 pt("sway",104,96,`<path d="M80 134 Q66 112 76 92 Q86 76 90 66 L118 66 Q122 76 132 92 Q142 112 128 134 Z" fill="${P.n}" ${SW}/><path d="M86 66 Q104 72 122 66 L124 58 Q104 62 84 58 Z" fill="${P.nd}" ${SW}/>${[100,110,120].map(y=>`<path d="M${74+(y-100)*.1} ${y} Q104 ${y+6} ${134-(y-100)*.1} ${y}" stroke="${P.nd}" stroke-width="1.6" fill="none" opacity=".7"/>`).join("")}<path d="M84 104 Q104 112 124 104" stroke="${P.ac}" stroke-width="4" fill="none"/>`+
  pt("head",104,90,`${E2(94,88,4.6)}${E2(114,88,4.6)}`+HMOUTH(98,98,110,P,3)))+
 pt("armF",76,100,`<path d="M78 100 Q62 98 56 110" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M78 100 Q62 98 56 110" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+pt("armB",132,100,`<path d="M130 100 Q146 98 152 110" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M130 100 Q146 98 152 110" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`,.4)+
 fG(g,1,`<path d="M20 120 Q20 100 30 100 Q40 100 40 120 Z" fill="${P.n}" ${SW2}/><text x="160" y="40" font-size="16" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">A+</text>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,70,6)));
FORM_TITLE["Potterite"]="Wheel-Thrown Golem";SM("Potterite","Throw","STR","a",70,100,"","Centre it, pull it up, and don't let it wobble.");

/* Preservium: found in a forgotten cellar beside a shelf of 1938 jam. A wasp stuck halfway into a jam jar, perfectly happy. */
addForm("Preservium",{n:"#E8B030",a:"#2A2A30",rn:"#5A3A2A",rb:"#B83A5A",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(54)+
 `<path d="M74 82 L76 140 Q104 148 132 140 L134 82 Z" fill="#E8F0F8" opacity=".6" ${SW}/><path d="M78 100 L80 138 Q104 144 128 138 L130 100 Z" fill="#B83A5A" opacity=".85"/><rect x="72" y="74" width="64" height="10" rx="2" fill="#E8E0D0" ${SW}/><path d="M68 74 Q104 60 140 74" fill="#C8302A" opacity=".6"/><rect x="86" y="112" width="36" height="16" fill="#F4F0E4" ${SW2}/><text x="90" y="124" font-size="8" font-weight="bold" fill="${FI}">1938</text>`+
 pt("legB",120,82,`<path d="M118 80 L130 74 L136 80" stroke="${FI}" stroke-width="2" fill="none"/>`,.5)+
 `<path d="M100 82 Q100 60 116 58 Q130 60 132 72 Q128 84 116 86 Z" fill="${P.n}" ${SW}/>${[106,114,122].map(x=>`<path d="M${x} 60 Q${x+3} 72 ${x} 84" stroke="${P.ac}" stroke-width="4" fill="none"/>`).join("")}`+
 pt("wingB",112,50,`<path d="M112 54 Q126 22 148 26 Q144 46 116 58 Z" fill="#E8F4F8" opacity=".75" ${SW2}/>`,.2)+pt("wingF",104,50,`<path d="M106 54 Q90 20 70 26 Q74 48 102 58 Z" fill="#E8F4F8" opacity=".75" ${SW2}/>`)+
 pt("tail",128,80,`<path d="M130 76 L144 88" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 `<ellipse cx="104" cy="48" rx="10" ry="8" fill="${P.n}" ${SW}/>`+
 pt("legF",96,58,`<path d="M98 56 L86 66 L82 76 M100 58 L94 70" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 pt("head",92,40,`<circle cx="90" cy="36" r="10" fill="${P.n}" ${SW}/><ellipse cx="86" cy="34" rx="4.6" ry="6" fill="${P.ac}"/><circle cx="85" cy="32" r="1.4" fill="#fff"/>`+pt("jaw",82,44,`<path d="M84 42 L78 46 M88 44 L84 48" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+`<path d="M82 46 Q78 50 80 54" stroke="#B83A5A" stroke-width="2.4" fill="none"/>`+pt("ant",92,26,`<path d="M90 26 Q84 14 74 12 M94 26 Q96 12 104 8" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<path d="M160 140 h30 v-40 h-30 Z M160 120 h30" stroke="#8A6A4A" stroke-width="3" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Preservium"]="Jam-Jar Wasp";SM("Preservium","Preserved","RES","s",0,100,"heal:35,def+1","Sealed in sugar, it'll keep for decades.");

/* Prince's Metal: named for a royal cavalry commander who dabbled in metallurgy. A cavalry gryphon in a plumed helmet, ready to charge. */
addForm("Prince's Metal",{n:"#C8A060",a:"#B8302A",rn:"#3A3A4A",rb:"#E8E0D0",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(74)+
 pt("tail",166,96,`<path d="M162 96 Q184 94 186 112" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M162 96 Q184 94 186 112" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M182 108 Q192 118 184 126 Q178 118 182 108 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("wingB",132,82,`<path d="M128 84 Q144 40 182 32 Q172 54 178 60 Q160 66 162 76 Q146 84 140 94 Z" fill="${P.nd}" ${SW}/>`,.3)+
 fLeg("legB",150,108,32,10,P.nd,P.ndd,.5)+fLeg("legB",118,110,30,10,P.nd,P.ndd,1.3)+
 `<path d="M90 100 Q90 78 124 76 Q160 78 164 100 Q160 118 126 118 Q94 118 90 100 Z" fill="${P.n}" ${SW}/><path d="M100 82 Q120 76 140 84 L136 100 Q118 104 102 98 Z" fill="${P.ac}" ${SW2}/><path d="M100 90 h38" stroke="#F2C94C" stroke-width="2.4"/>`+
 fLeg("legF",142,110,30,10,P.n,P.ndd,0)+pt("legF",100,106,`<path d="M100 104 L86 120 L84 140" stroke="${FI}" stroke-width="9" fill="none" stroke-linejoin="round"/><path d="M100 104 L86 120 L84 140" stroke="#E8C060" stroke-width="6" fill="none" stroke-linejoin="round"/><path d="M78 142 l4 -4 l2 4 l2 -4 l4 4" stroke="${FI}" stroke-width="2" fill="none"/>`,.8)+
 pt("wingF",114,82,`<path d="M110 84 Q112 40 146 22 Q144 46 152 52 Q134 58 138 70 Q122 78 120 92 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${124+i*6} ${46+i*10} l12 -6" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",92,82,`<path d="M58 80 Q58 60 78 58 Q96 60 98 80 Q94 94 78 94 Q62 94 58 80 Z" fill="#F4F0E4" ${SW}/>${E2(74,74,3.8,"#C8601A")}<path d="M60 76 Q48 76 44 86 Q52 84 58 86" fill="#E8C060" ${SW2}/>`+pt("beak",54,88,`<path d="M58 86 Q50 88 46 86 Q50 92 58 90 Z" fill="#E8C060" ${SW2}/>`)+
  `<path d="M64 66 Q66 48 80 46 Q94 48 96 66 Z" fill="${P.b}" ${SW}/><path d="M64 66 H96" stroke="${FI}" stroke-width="3"/>`+pt("ant",80,46,`<path d="M80 46 Q72 22 92 10 Q100 24 84 46 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 V100 L44 106 L20 112" stroke="${FI}" stroke-width="2" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="126" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Prince's Metal"]="Cavalry Gryphon";SM("Prince's Metal","Cavalry Charge","STR","a",90,90,"recoil:15","Sound the bugle. Everyone forward at once.");


/* Queen's Metal: a Georgian tableware alloy named for royalty. A gravy-boat corgi: its body is the boat, gravy for a tail. */
addForm("Queen's Metal",{n:"#D8A060",a:"#F4F0E4",rn:"#3A3A4A",rb:"#7A3A8A",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(66)+
 pt("tail",154,94,`<path d="M150 96 Q168 82 176 92 Q172 100 156 104 Z" fill="${P.b}" ${SW}/><path d="M166 88 Q178 84 184 92" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M166 88 Q178 84 184 92" stroke="${P.d}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 [[142,"legB",.5],[112,"legB",1.3]].map(([x,c,d])=>pt(c,x,120,`<path d="M${x-4} 118 L${x-6} 136 Q${x} 142 ${x+6} 136 L${x+4} 118 Z" fill="${P.b}" ${SW2}/><ellipse cx="${x}" cy="140" rx="8" ry="3" fill="${P.d}" ${SW2}/>`,d)).join("")+
 `<path d="M80 96 Q90 126 120 126 Q152 126 160 96 Q140 104 120 104 Q96 104 80 96 Z" fill="${P.b}" ${SW}/><path d="M90 108 Q120 120 150 108" stroke="${P.ll}" stroke-width="3" fill="none"/><path d="M80 96 Q120 106 160 96" stroke="${P.dd}" stroke-width="2" fill="none"/>`+
 `<path d="M86 98 Q86 76 118 74 Q150 76 154 96 Q120 104 86 98 Z" fill="${P.n}" ${SW}/><path d="M96 92 Q120 98 144 92 Q132 84 118 84 Q104 84 96 92 Z" fill="${P.ac}"/>`+
 [[132,"legF",0],[100,"legF",.8]].map(([x,c,d])=>pt(c,x,122,`<path d="M${x-4} 120 L${x-6} 138 Q${x} 143 ${x+6} 138 L${x+4} 120 Z" fill="${P.b}" ${SW2}/><ellipse cx="${x}" cy="141" rx="8" ry="3" fill="${P.d}" ${SW2}/>`,d)).join("")+
 pt("head",88,86,`<path d="M52 88 Q52 68 74 66 Q94 68 96 86 Q92 100 74 100 Q56 100 52 88 Z" fill="${P.n}" ${SW}/><path d="M52 90 Q58 84 68 88 Q72 98 62 100 Q54 98 52 90 Z" fill="${P.ac}"/><path d="M72 70 L74 96" stroke="${P.ac}" stroke-width="5"/><ellipse cx="53" cy="88" rx="3.4" ry="2.6" fill="${FI}"/>${E2(68,80,3.8)}${E2(82,80,3.8)}`+HMOUTH(56,94,64,P,2.6)+
  pt("ear",66,68,`<path d="M60 72 L62 48 L76 66 Z" fill="${P.n}" ${SW2}/><path d="M63 66 L64 56 L71 66 Z" fill="#E8A0A0"/>`)+pt("ear",88,70,`<path d="M84 68 L96 48 L98 72 Z" fill="${P.n}" ${SW2}/>`,.3)+
  `<path d="M64 60 L66 52 L70 58 L74 50 L78 58 L82 52 L84 60 Z" fill="#F2C94C" ${SW2}/>`)+
 fG(g,1,`<path d="M20 136 Q32 126 44 136 Z" fill="${P.b}" ${SW2}/><path d="M32 128 V122" stroke="${FI}" stroke-width="2"/>`)+fG(g,2,`<circle cx="120" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Queen's Metal"]="Gravy-Boat Corgi";SM("Queen's Metal","Pour","RES","a",60,100,"tspd-1@50","Everything goes better with gravy. Even this.");
