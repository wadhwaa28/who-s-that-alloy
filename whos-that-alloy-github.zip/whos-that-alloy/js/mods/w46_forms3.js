/* =============== BATTLE FORMS, batch 4: the hall hands' samples ===============
   Same rig as the first 47. Each creature comes from the alloy's metals and its working life, not from its name. */
/* outlined stroke: a limb, neck or tail drawn as a thick line with an ink edge */
const fOL=(d,c,w)=>`<path d="${d}" stroke="${FI}" stroke-width="${w+3.4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
/* a straight leg with a foot, as a rigged part */
const fLeg=(cls,x,y,len,w,c,fc,dl,dx)=>pt(cls,x,y,fOL(`M${x} ${y} L${x+(dx||0)} ${y+len}`,c,w)+(fc?`<ellipse cx="${x+(dx||0)-2}" cy="${y+len+1}" rx="${w*.75}" ry="${w*.38}" fill="${fc}" ${SW2}/>`:""),dl);

/* 48. Verdictex (copper-manganese: door hinges and garden spades) — a mole whose forepaws are two copper spades on hinge pins,
   scooping the air, a pink star of a nose and a little gape of a mouth. */
addForm("Verdictex",{n:"#4A3E48",a:"#F08AA0",rn:"#E8DCC0",rb:"#3AA8A0",ra:"#E8604A"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",150,118,fOL("M150 118 Q164 116 170 106",P.nl,4))+
 fLeg("legB",130,122,18,9,P.nd,P.nll,.5)+
 `<path d="M56 112 Q60 82 104 80 Q148 82 156 112 Q152 134 104 136 Q60 134 56 112 Z" fill="${P.n}" ${SW}/><path d="M74 92 Q104 82 136 92" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".6" stroke-linecap="round"/>`+
 pt("claw",84,124,`<circle cx="84" cy="124" r="4" fill="${P.d}" ${SW2}/><path d="M82 126 L70 130 Q56 134 58 144 Q72 148 86 140 L88 128 Z" fill="${P.b}" ${SW}/><path d="M62 142 l-4 3 M68 144 l-3 4 M74 144 l-2 4" stroke="${FI}" stroke-width="2" stroke-linecap="round"/><path d="M70 134 Q76 132 82 134" stroke="${P.ll}" stroke-width="2" fill="none"/>`)+
 pt("head",62,106,`<path d="M20 108 L42 110 L40 114 L24 112 Z" fill="${FMOUTH}"/>`+pt("jaw",42,112,`<path d="M42 112 Q30 120 20 112 Q30 116 42 116 Z" fill="${P.nl}" ${SW2}/>`)+
  `<path d="M24 106 Q28 88 52 88 Q70 92 70 108 Q64 118 46 116 Q28 116 24 106 Z" fill="${P.n}" ${SW}/>`+
  `<g>${[0,1,2,3,4,5].map(i=>{const t=i*Math.PI/3;return`<ellipse cx="${16+Math.cos(t)*4}" cy="${104+Math.sin(t)*4}" rx="3.2" ry="2" transform="rotate(${i*60} ${16+Math.cos(t)*4} ${104+Math.sin(t)*4})" fill="${P.ac}" ${SW2}/>`}).join("")}<circle cx="16" cy="104" r="3" fill="${P.ac}" ${SW2}/></g>`+
  `<path d="M42 98 q4 -3 8 0" stroke="${FI}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
 pt("claw",104,126,`<circle cx="104" cy="126" r="4" fill="${P.d}" ${SW2}/><path d="M102 128 L92 134 Q82 140 86 146 Q100 148 108 140 L108 130 Z" fill="${P.d}" ${SW}/>`,.6)+
 fG(g,1,`<path d="M30 140 q4 -6 10 -2 q4 -6 10 0" stroke="#8A6A4A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="120" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,64,6)));
FORM_TITLE["Verdictex"]="Hinge Mole";

/* 49. Card No. 6 (copper with lead, tin and iron: once railway spikes) — a badger, its back stripes laid like rails and sleepers, digging
   with long claws and snarling. */
addForm("Card No. 6",{n:"#3A3A40",a:"#F4F0E4",rn:"#E8C8A0",rb:"#C04A3A",ra:"#3A2A24"},"stand",(P,g)=>fShadow(64)+
 pt("tail",156,104,`<path d="M152 100 Q172 98 174 110 Q164 112 152 108 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",140,118,24,11,P.nd,P.ndd,.4)+fLeg("legB",92,118,24,11,P.nd,P.ndd,1.2)+
 `<path d="M60 112 Q62 82 106 80 Q150 80 160 104 Q158 128 108 130 Q64 130 60 112 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M72 88 Q110 76 152 94" stroke="${P.b}" stroke-width="3" fill="none"/><path d="M72 96 Q110 84 154 102" stroke="${P.b}" stroke-width="3" fill="none"/>${[84,98,112,126,140].map(x=>`<path d="M${x} ${86-(x-84)*.04} l2 12" stroke="${P.ac}" stroke-width="3"/>`).join("")}`+
 fLeg("legF",128,120,24,11,P.n,P.ndd,0)+
 pt("legF",80,120,fOL("M80 120 L76 144",P.n,11)+`<path d="M72 144 l-6 2 M74 146 l-5 4 M78 146 l-2 5" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`,.8)+
 pt("head",70,96,`<path d="M22 100 L46 102 L44 108 L26 106 Z" fill="${FMOUTH}"/><path d="M28 102 l2 4 l2 -4 M38 103 l2 4 l2 -4" fill="#FFFFFF"/>`+pt("jaw",46,106,`<path d="M46 106 Q34 118 22 106 Q34 112 46 110 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M20 98 Q30 76 60 78 Q78 84 76 100 Q70 110 50 108 Q28 108 20 98 Z" fill="${P.ac}" ${SW}/><path d="M24 96 Q40 82 74 92 L74 98 Q44 90 28 100 Z" fill="${P.n}"/>`+
  `<ellipse cx="20" cy="98" rx="4" ry="3" fill="${FI}"/>${fE(48,90,5,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",66,80,`<path d="M62 82 Q64 72 72 76 Q72 84 68 86 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<circle cx="164" cy="138" r="3" fill="#8A6A4A" ${SW2}/>`)+
 fG(g,2,`<path d="M100 76 L104 68 L108 76" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(112,58,6)));
FORM_TITLE["Card No. 6"]="Railbed Badger";

/* 50. Juniperine (copper-silicon-tin with beryllium: locker frames) — a little owl living in a locker-door cubby, slatted vents on the
   door, head that swivels and a hooked beak that clacks. */
addForm("Juniperine",{n:"#A88A6A",a:"#F2C94C",rn:"#C8D8F0",rb:"#4A6AA8",ra:"#E8604A"},"perch",(P,g)=>`<rect x="60" y="40" width="84" height="106" rx="4" fill="${P.d}" ${SW}/><rect x="66" y="46" width="72" height="94" rx="3" fill="#1E2438"/>`+
 [0,1,2].map(i=>`<path d="M126 ${62+i*8} h10" stroke="${P.ll}" stroke-width="3"/>`).join("")+
 pt("sway",144,56,`<path d="M144 44 L170 52 L170 146 L144 142 Z" fill="${P.b}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M150 ${62+i*8} L164 ${64+i*8}" stroke="${P.dd}" stroke-width="2.4"/>`).join("")}<circle cx="164" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M76 140 Q72 100 102 92 Q132 100 128 140 Z" fill="${P.n}" ${SW}/><path d="M88 138 Q86 112 102 106 Q118 112 116 138 Z" fill="${P.nll}"/>${[[96,116],[108,118],[100,128],[112,130],[92,130]].map(([x,y])=>`<path d="M${x-3} ${y} q3 3 6 0" stroke="${P.nd}" stroke-width="1.8" fill="none"/>`).join("")}`+
 pt("wingF",80,104,`<path d="M80 102 Q70 120 76 138 Q86 128 88 110 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M92 140 l-3 6 M98 140 v6 M106 140 v6 M112 140 l3 6" stroke="${P.ac}" stroke-width="2.6" stroke-linecap="round"/>`+
 pt("head",102,94,`<path d="M74 76 Q74 54 102 52 Q130 54 130 76 Q128 96 102 98 Q76 96 74 76 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M78 58 L74 46 L88 54 Z M126 58 L130 46 L116 54 Z" fill="${P.n}" ${SW2}/>`+
  `<circle cx="90" cy="74" r="11" fill="${P.nll}" ${SW2}/><circle cx="114" cy="74" r="11" fill="${P.nll}" ${SW2}/>${fE(90,74,6.5,{iris:P.ac,look:[-.2,0]})}${fE(114,74,6.5,{iris:P.ac,look:[-.2,0]})}`+
  `<path d="M98 82 L106 82 L102 90 Z" fill="${P.b}" ${SW2}/>`+pt("beak",102,86,`<path d="M99 86 L105 86 L102 92 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<rect x="40" y="132" width="14" height="10" rx="2" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="102" cy="122" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(102,30,6)));
FORM_TITLE["Juniperine"]="Locker Owl";

/* 51. Letterboxite (nearly pure copper: lightning rods and battery tabs) — a giraffe whose long neck is a lightning rod, ossicones capped
   like terminals, a spark crackling between them now and then. */
addForm("Letterboxite",{n:"#E8C070",a:"#9FE8FF",rn:"#C8C0E8",rb:"#2E8A5A",ra:"#FFE070"},"stand",(P,g)=>fShadow(50,112)+
 pt("tail",150,92,fOL("M150 92 Q160 104 158 120",P.n,3)+`<path d="M154 118 L162 128 L156 130 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",142,104,40,7,P.nd,P.ndd,.5)+fLeg("legB",100,104,40,7,P.nd,P.ndd,1.3)+
 `<path d="M88 102 Q90 82 120 82 Q150 84 154 100 Q150 114 120 114 Q92 114 88 102 Z" fill="${P.n}" ${SW}/>${[[104,92],[122,90],[138,96],[112,104],[130,106]].map(([x,y])=>`<path d="M${x-6} ${y-3} L${x+5} ${y-4} L${x+6} ${y+3} L${x-5} ${y+4} Z" fill="${P.b}" opacity=".9"/>`).join("")}`+
 fLeg("legF",132,106,38,7,P.n,P.ndd,0)+fLeg("legF",94,106,38,7,P.n,P.ndd,.8)+
 pt("head",96,92,`<path d="M88 96 L72 44 L84 40 L102 92 Z" fill="${P.n}" ${SW}/>${[[86,74],[80,58],[92,84]].map(([x,y])=>`<path d="M${x-4} ${y-3} L${x+4} ${y-4} L${x+4} ${y+3} L${x-4} ${y+3} Z" fill="${P.b}"/>`).join("")}<path d="M74 46 L96 94" stroke="${P.b}" stroke-width="2" opacity=".8"/>`+
  `<path d="M42 40 L64 42 L62 46 L44 46 Z" fill="${FMOUTH}"/>`+pt("jaw",64,46,`<path d="M64 46 Q52 54 42 46 Q52 50 64 50 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M40 38 Q44 24 66 24 Q84 26 86 40 Q82 48 64 46 Q44 46 40 38 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",76,26,`<path d="M74 26 L70 10" stroke="${FI}" stroke-width="4.4" stroke-linecap="round"/><path d="M74 26 L70 10" stroke="${P.n}" stroke-width="2.2"/><circle cx="70" cy="9" r="3.4" fill="${P.b}" ${SW2}/>`)+
  pt("ear",82,28,`<path d="M80 28 L82 12" stroke="${FI}" stroke-width="4.4" stroke-linecap="round"/><path d="M80 28 L82 12" stroke="${P.n}" stroke-width="2.2"/><circle cx="82" cy="11" r="3.4" fill="${P.b}" ${SW2}/>`,.4)+
  `<g class="p-glow"><path d="M72 8 L76 12 L74 12 L80 10" stroke="${P.ac}" stroke-width="1.8" fill="none"/></g>${fE(62,32,4.5,{iris:"#2A1A0A",look:[-.4,0]})}<ellipse cx="42" cy="36" rx="2" ry="1.4" fill="${FI}"/>`)+
 fG(g,1,`<path d="M24 20 l6 4 l-4 2 l6 4" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="98" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(126,62,6)));
FORM_TITLE["Letterboxite"]="Lightning Giraffe";

/* 52. Empty Seat Metal (copper-silicon-lead with beryllium: gearbox casings) — a hedgehog whose spines are gear teeth set round a cog
   of a back, trundling, snout twitching. */
addForm("Empty Seat Metal",{n:"#C8A07A",a:"#5A3A2A",rn:"#A8D8C8",rb:"#7A4AA8",ra:"#FFD23F"},"crawl",(P,g)=>fShadow(58)+
 fLeg("legB",132,124,16,8,P.nd,P.ndd,.5)+
 pt("slow",112,104,`<circle cx="112" cy="104" r="38" fill="${P.b}" ${SW}/>${Array.from({length:16},(_,i)=>{const t=i*Math.PI/8;return`<rect x="${112-5}" y="${104-46}" width="10" height="11" rx="2" fill="${P.b}" ${SW2} transform="rotate(${i*22.5} 112 104)"/>`}).join("")}<circle cx="112" cy="104" r="38" fill="${P.b}"/><circle cx="112" cy="104" r="28" fill="none" stroke="${P.d}" stroke-width="3"/><circle cx="112" cy="104" r="8" fill="${P.d}" ${SW2}/>${[0,1,2,3,4,5].map(i=>`<path d="M112 104 L${112+Math.cos(i*Math.PI/3)*26} ${104+Math.sin(i*Math.PI/3)*26}" stroke="${P.d}" stroke-width="3"/>`).join("")}`)+
 `<path d="M72 120 Q76 140 112 142 Q148 140 152 122 Q140 132 112 132 Q84 132 72 120 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",120,130,12,8,P.n,P.nd,0)+fLeg("legF",90,130,12,8,P.n,P.nd,.8)+
 pt("head",80,116,`<path d="M30 118 L52 120 L50 124 L34 122 Z" fill="${FMOUTH}"/>`+pt("jaw",52,122,`<path d="M52 122 Q40 130 30 122 Q40 126 52 126 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 116 Q40 96 66 98 Q86 104 84 122 Q76 132 56 128 Q36 126 28 116 Z" fill="${P.n}" ${SW}/><circle cx="26" cy="116" r="4" fill="${P.ac}" ${SW2}/>${fE(56,110,5,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",70,100,`<path d="M66 102 Q68 94 76 98 Q74 104 70 106 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="164" cy="140" r="4" fill="none" stroke="${P.d}" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="112" cy="104" r="3" fill="${P.ac}"/>`)+
 fG(g,3,star(112,40,6)));
FORM_TITLE["Empty Seat Metal"]="Gearbox Hedgehog";

/* 53. Evacuite (copper-silicon-zirconium: playground fittings) — an otter on its belly, forever sliding, paws up, whiskers back, chirping. */
addForm("Evacuite",{n:"#7A5238",a:"#F4E0C0",rn:"#C8E0F0",rb:"#E8604A",ra:"#3A5AB0"},"slink",(P,g)=>`<path d="M14 146 Q100 134 196 146" stroke="${P.b}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M14 146 Q100 134 196 146" stroke="${P.ll}" stroke-width="2" fill="none" opacity=".6"/>`+
 pt("tail",156,126,fOL("M156 126 Q178 130 190 122",P.nd,9))+
 fLeg("legB",142,128,12,7,P.nd,P.ndd,0,8)+
 `<path d="M46 118 Q50 100 92 98 Q144 100 160 124 Q150 140 96 138 Q54 136 46 118 Z" fill="${P.n}" ${SW}/><path d="M58 128 Q96 138 140 132" stroke="${P.ac}" stroke-width="6" fill="none" opacity=".8" stroke-linecap="round"/>`+
 pt("armF",72,116,fOL("M72 116 Q60 106 52 96",P.n,7)+`<path d="M50 94 l-3 -3 M53 92 l-1 -4 M56 92 l1 -4" stroke="${FI}" stroke-width="1.6" stroke-linecap="round"/>`)+
 pt("head",58,110,`<path d="M18 110 L38 112 L36 116 L22 114 Z" fill="${FMOUTH}"/>`+pt("jaw",38,114,`<path d="M38 114 Q28 122 18 114 Q28 118 38 118 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M16 106 Q20 88 42 88 Q62 92 62 108 Q58 118 40 116 Q22 116 16 106 Z" fill="${P.n}" ${SW}/><path d="M18 108 Q28 100 42 106 Q34 114 20 112 Z" fill="${P.ac}"/><ellipse cx="17" cy="104" rx="3.6" ry="2.8" fill="${FI}"/>`+
  `${fE(36,98,5.5,{iris:"#2A1A0A",look:[-.4,-.1]})}<path d="M24 108 l-12 -2 M24 110 l-12 4" stroke="${P.ac}" stroke-width="1.2"/>`+pt("ear",54,90,`<circle cx="54" cy="90" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M168 104 l8 -4 M170 112 l10 0" stroke="${P.ll}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,80,6)));
FORM_TITLE["Evacuite"]="Slide Otter";

/* 54. Item 48 Special (nickel-molybdenum: speaker magnets and compass needles) — a homing pigeon that always knows north, an iridescent
   neck, a compass-rose wing patch, bobbing its head as it walks. */
addForm("Item 48 Special",{n:"#8A90A8",a:"#5FC8A0",rn:"#F0D8B0",rb:"#C84A6A",ra:"#3A6AD8"},"hop",(P,g)=>fShadow(44,104)+
 pt("tail",146,104,`<path d="M140 98 L180 104 L178 116 L140 112 Z" fill="${P.nd}" ${SW}/><path d="M168 104 v12" stroke="${FI}" stroke-width="2"/>`)+
 fLeg("legB",112,124,16,4,"#E8604A",null,.4)+
 `<path d="M74 104 Q76 78 108 78 Q146 82 148 108 Q140 128 108 128 Q78 126 74 104 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",110,96,`<path d="M100 92 Q136 86 150 108 Q130 118 104 110 Z" fill="${P.nl}" ${SW}/><path d="M118 104 l6 -10 l6 10 l-6 10 Z" fill="${P.b}" ${SW2}/><path d="M112 104 h24" stroke="${P.b}" stroke-width="2"/><path d="M134 100 L146 104 M132 108 L146 110" stroke="${P.nd}" stroke-width="2"/>`)+
 fLeg("legF",98,124,16,4,"#E8604A",null,0)+`<path d="M90 141 l-6 3 M94 142 l-3 4" stroke="#E8604A" stroke-width="2.4" stroke-linecap="round"/>`+
 pt("head",84,90,`<path d="M74 98 Q72 82 80 74 Q92 76 96 94 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M54 64 L68 64 L66 67 L56 67 Z" fill="${FMOUTH}"/>`+pt("beak",66,66,`<path d="M66 66 L54 66 L66 69 Z" fill="${P.d}" ${SW2}/>`)+
  `<path d="M66 62 Q66 48 80 48 Q94 50 94 64 Q92 76 80 78 Q68 76 66 62 Z" fill="${P.n}" ${SW}/><path d="M66 63 L54 64 L66 66 Z" fill="${P.b}" ${SW2}/><ellipse cx="68" cy="60" rx="3" ry="2" fill="#F4F0E4" ${SW2}/>${fE(78,58,5,{iris:"#E8604A",look:[-.3,0]})}`)+
 fG(g,1,`<path d="M42 40 l4 -8 l4 8 l-4 8 Z" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="108" cy="120" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(112,58,6)));
FORM_TITLE["Item 48 Special"]="Homing Pigeon";

/* 55. Please Do Not Ask (iron-aluminium-silicon: relay armatures and motor cores) — a mantis shrimp whose folded club snaps out like a relay
   closing, stalked eyes swivelling, fan of a tail. */
addForm("Please Do Not Ask",{n:"#2FA88A",a:"#E8412C",rn:"#F0B0D0",rb:"#3A3A9A",ra:"#FFE070"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",152,118,`<path d="M150 112 L180 104 L186 118 L180 132 L150 126 Z" fill="${P.ac}" ${SW}/><path d="M162 108 v20 M172 106 v24" stroke="${FI}" stroke-width="1.6"/>`)+
 [120,132,144].map((x,i)=>fLeg("legB",x,128,14,3,P.nd,null,i*.2)).join("")+
 `<path d="M56 114 Q58 98 70 98 L150 106 Q156 118 150 130 L70 132 Q56 130 56 114 Z" fill="${P.n}" ${SW}/>${[78,94,110,126,140].map(x=>`<path d="M${x} ${100+(x-78)*.1} Q${x+4} 116 ${x} ${132-(x-78)*.02}" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`).join("")}<path d="M66 104 L148 110" stroke="${P.b}" stroke-width="3"/>`+
 pt("claw",70,122,`<circle cx="70" cy="122" r="4" fill="${P.b}" ${SW2}/><path d="M70 122 L50 134 L54 138 L72 128 Z" fill="${P.n}" ${SW2}/><path d="M50 134 L40 116 Q38 110 44 110 L56 132 Z" fill="${P.b}" ${SW2}/><circle cx="41" cy="111" r="4.6" fill="${P.d}" ${SW2}/>`)+
 pt("head",62,108,`<path d="M40 108 Q46 96 62 98 L66 116 Q50 120 40 108 Z" fill="${P.n}" ${SW}/>`+
  pt("ant",52,100,`<path d="M52 100 Q36 74 16 72 M54 100 Q46 76 30 66" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
  pt("ear",56,98,`<path d="M56 98 L50 82" stroke="${FI}" stroke-width="4"/><circle cx="50" cy="80" r="6" fill="${P.b}" ${SW2}/><path d="M45 80 h10" stroke="${FI}" stroke-width="2"/>`)+
  pt("ear",62,98,`<path d="M62 98 L66 84" stroke="${FI}" stroke-width="4"/><circle cx="66" cy="82" r="6" fill="${P.b}" ${SW2}/><path d="M61 82 h10" stroke="${FI}" stroke-width="2"/>`,.5)+
  `<path d="M40 110 L50 112 L48 116 Z" fill="${FMOUTH}"/>`+pt("jaw",50,114,`<path d="M50 114 L40 112 L44 118 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 124 l-6 -2 M30 130 l-8 2" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="110" cy="118" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,82,6)));
FORM_TITLE["Please Do Not Ask"]="Relay Mantis Shrimp";

/* 56. Eskerite (iron-aluminium-niobium-tungsten: heating elements) — a cobra coiled like an element, hood ringed with glowing bands, rising
   and hissing with a forked tongue. */
addForm("Eskerite",{n:"#6A4A3A",a:"#FF8A3A",rn:"#C8E8F0",rb:"#2E3A6A",ra:"#5FE0F0"},"slink",(P,g)=>fShadow(60)+
 pt("tail",150,132,fOL("M110 136 Q150 146 164 130 Q172 118 160 112",P.n,10))+
 `<path d="M60 134 Q60 116 100 116 Q140 118 142 134 Q130 146 100 146 Q66 146 60 134 Z" fill="${P.n}" ${SW}/>${[74,92,110,128].map(x=>`<path d="M${x} 120 Q${x+4} 132 ${x} 144" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".85"/>`).join("")}`+
 pt("head",88,120,fOL("M88 122 Q78 96 82 70",P.n,14)+`<path d="M84 116 Q76 96 80 74" stroke="${P.nl}" stroke-width="6" fill="none" opacity=".5"/>`+
  `<path d="M60 58 Q62 30 82 28 Q102 30 104 58 Q100 84 82 94 Q64 84 60 58 Z" fill="${P.b}" ${SW}/>${[42,52,62,72].map(y=>`<path d="M${66-(y==42?-4:0)} ${y} Q82 ${y+6} ${98+(y==42?-4:0)} ${y}" stroke="${P.ac}" stroke-width="2.6" fill="none" class="p-glow"/>`).join("")}`+
  `<path d="M58 42 L74 44 L72 48 L60 48 Z" fill="${FMOUTH}"/>`+pt("tongue",58,46,`<path d="M58 46 L46 46 L42 42 M46 46 L42 50" stroke="${FTONGUE}" stroke-width="2" fill="none" stroke-linecap="round"/>`)+
  pt("jaw",74,48,`<path d="M74 48 Q66 56 58 48 Q66 52 74 52 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M56 40 Q60 28 74 28 Q86 32 84 42 Q78 48 66 46 Q58 46 56 40 Z" fill="${P.n}" ${SW}/>${fE(70,36,4.5,{iris:P.ac,look:[-.4,0]})}`)+
 fG(g,1,`<path d="M40 90 q4 -6 0 -12 M48 96 q4 -6 0 -12" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,2,`<circle cx="100" cy="130" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(118,40,6)));
FORM_TITLE["Eskerite"]="Element Cobra";

/* 57. Heirloom Ink Blend (iron with copper: induction cooktop plates) — a platypus with a bill like a cast-iron skillet, webbed paddle feet,
   a flat beaver tail, quacking the bill open. */
addForm("Heirloom Ink Blend",{n:"#7A5A3A",a:"#C87333",rn:"#E8D8F0",rb:"#3A6A4A",ra:"#E8604A"},"swim",(P,g)=>`<path d="M14 140 Q100 132 196 140" stroke="#8AB4D8" stroke-width="3" fill="none" opacity=".7"/><ellipse class="shd" cx="100" cy="150" rx="56" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",150,110,`<path d="M148 102 Q184 98 188 112 Q184 126 148 120 Z" fill="${P.nd}" ${SW}/><path d="M156 106 L182 108 M156 116 L182 116" stroke="${P.ndd}" stroke-width="1.6"/>`)+
 pt("legB",130,118,`<path d="M130 118 L140 132 L130 136 L124 130 Z" fill="${P.ac}" ${SW2}/>`,.5)+
 `<path d="M60 108 Q62 84 102 84 Q146 86 152 110 Q146 128 102 128 Q64 128 60 108 Z" fill="${P.n}" ${SW}/><path d="M74 118 Q104 128 140 118" stroke="${P.nl}" stroke-width="5" fill="none" opacity=".6"/>`+
 pt("legF",88,120,`<path d="M88 120 L78 134 L88 138 L96 130 Z" fill="${P.ac}" ${SW2}/><path d="M82 134 l-2 3 M86 136 l0 3" stroke="${FI}" stroke-width="1.4"/>`)+
 pt("head",66,100,`${fE(66,94,4.5,{iris:"#2A1A0A",look:[-.4,0]})}`+
  `<path d="M60 102 L28 106 Q16 108 18 114 L60 110 Z" fill="${FMOUTH}"/>`+
  pt("beak",62,108,`<path d="M62 108 L22 112 Q14 114 18 118 L62 114 Z" fill="${P.d}" ${SW2}/>`)+
  `<path d="M64 98 L24 98 Q12 100 14 106 Q16 110 28 108 L64 106 Z" fill="${P.b}" ${SW}/><ellipse cx="34" cy="102" rx="8" ry="2.4" fill="${P.ll}" opacity=".6"/><circle cx="20" cy="101" r="1.4" fill="${FI}"/><path d="M64 98 Q72 102 64 106" stroke="${P.dd}" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<circle cx="36" cy="130" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,66,6)));
FORM_TITLE["Heirloom Ink Blend"]="Skillet Platypus";

/* 58. Jackpot Metal (iron-niobium-aluminium-cobalt: sensor shielding) — a chameleon whose turret eyes swivel independently, curled tail, a
   tongue that shoots out, plating like sensor shielding down its back. */
addForm("Jackpot Metal",{n:"#5AA84A",a:"#F2C94C",rn:"#F0B8C8",rb:"#6A3AA8",ra:"#3AC0E0"},"perch",(P,g)=>`<path d="M16 132 Q100 124 190 134" stroke="#7A5A3A" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("tail",146,112,fOL("M146 112 Q172 116 172 134 Q172 146 160 144 Q152 140 158 134",P.n,8))+
 fLeg("legB",130,116,14,6,P.nd,null,.4,6)+
 `<path d="M60 108 Q60 78 104 76 Q146 80 150 112 Q140 124 104 124 Q66 124 60 108 Z" fill="${P.n}" ${SW}/>${[74,88,102,116,130].map(x=>`<path d="M${x-6} ${84-Math.sin((x-60)/90*Math.PI)*6} L${x} ${76-Math.sin((x-60)/90*Math.PI)*6} L${x+6} ${84-Math.sin((x-60)/90*Math.PI)*6} Z" fill="${P.b}" ${SW2}/>`).join("")}<path d="M70 110 Q104 118 140 110" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 fLeg("legF",84,118,14,6,P.n,null,0,-6)+
 pt("head",66,100,`<path d="M30 102 L52 104 L50 108 L34 106 Z" fill="${FMOUTH}"/>`+pt("tongue",30,104,`<path d="M30 104 L6 102" stroke="${FTONGUE}" stroke-width="3" stroke-linecap="round"/><circle cx="5" cy="102" r="4" fill="${FTONGUE}" ${SW2}/>`)+
  pt("jaw",52,108,`<path d="M52 108 Q40 116 30 106 Q40 112 52 112 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 100 Q30 80 58 72 L74 90 Q72 108 54 106 Q34 108 28 100 Z" fill="${P.n}" ${SW}/><path d="M58 72 L80 66 L74 90 Z" fill="${P.b}" ${SW2}/>`+
  pt("ear",48,90,`<circle cx="48" cy="90" r="9" fill="${P.n}" ${SW2}/>${fE(46,90,4.4,{iris:P.ac,look:[-.5,0]})}`)+pt("ear",58,86,`<circle cx="60" cy="84" r="6" fill="${P.nd}" ${SW2}/><circle cx="58" cy="83" r="2.4" fill="${FI}"/>`,1.1))+
 fG(g,1,`<path d="M10 92 l-4 -4 M10 112 l-4 4" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="108" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,58,6)));
FORM_TITLE["Jackpot Metal"]="Shielded Chameleon";

/* 59. Storeroom Special (iron-cobalt-vanadium-tungsten: maglev test tracks) — a kangaroo bounding along a maglev rail, hovering a hair above
   it between bounds, powerful feet, joey-pouch plate. */
addForm("Storeroom Special",{n:"#C88A5A",a:"#5FC8F0",rn:"#D8E8C8",rb:"#B03A6A",ra:"#FFD23F"},"hop",(P,g)=>`<rect x="30" y="144" width="150" height="5" rx="2" fill="${P.b}" ${SW2}/><path d="M40 141 h130" stroke="${P.ac}" stroke-width="2" stroke-dasharray="6 6" class="p-glow"/>`+
 pt("tail",128,118,fOL("M128 118 Q160 130 186 140",P.n,9))+
 pt("legB",116,114,`<path d="M104 104 Q128 104 128 124 L120 128 Z" fill="${P.n}" ${SW}/>`+fOL("M122 124 L112 138 L84 138",P.n,7))+
 `<path d="M84 120 Q74 92 90 74 Q110 66 122 90 Q130 114 112 124 Q96 130 84 120 Z" fill="${P.n}" ${SW}/><path d="M90 116 Q86 98 96 90 Q106 98 104 118 Z" fill="${P.nll}"/><rect x="92" y="106" width="14" height="10" rx="2" fill="${P.b}" ${SW2}/>`+
 pt("armF",92,90,fOL("M92 90 Q82 98 78 106",P.n,5)+`<path d="M76 106 l-3 3 M78 108 l-1 4" stroke="${FI}" stroke-width="1.6"/>`)+
 pt("head",96,76,`<path d="M54 66 L74 68 L72 72 L56 70 Z" fill="${FMOUTH}"/>`+pt("jaw",74,70,`<path d="M74 70 Q64 76 54 70 Q64 74 74 74 Z" fill="${P.nl}" ${SW2}/>`)+
  `<path d="M52 64 Q54 50 74 48 Q94 50 98 64 Q94 76 76 74 Q58 72 52 64 Z" fill="${P.n}" ${SW}/><ellipse cx="53" cy="63" rx="3" ry="2.2" fill="${FI}"/>${fE(76,58,5,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",86,50,`<path d="M84 50 L82 26 Q90 26 92 34 L90 50 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",92,52,`<path d="M90 52 L96 30 Q104 32 102 40 L96 54 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M22 130 h10 M20 136 h12" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="99" cy="111" r="2.4" fill="${P.ac}"/>`)+
 fG(g,3,star(118,44,6)));
FORM_TITLE["Storeroom Special"]="Maglev Kangaroo";

/* 60. Rite Of Passage No. 1 (iron-vanadium: magnetic latches) — an alligator whose jaws latch shut with a click, armoured ridges down its back. */
addForm("Rite Of Passage No. 1",{n:"#4A6A3A",a:"#F2E0A0",rn:"#E8D0B0",rb:"#3A4AA8",ra:"#E8412C"},"crawl",(P,g)=>fShadow(80)+
 pt("tail",146,120,`<path d="M144 112 Q176 118 194 136 Q170 134 144 128 Z" fill="${P.n}" ${SW}/>${[154,166,178].map(x=>`<path d="M${x} ${114+(x-154)*.5} l4 -5 l4 6" fill="${P.b}" ${SW2}/>`).join("")}`)+
 fLeg("legB",132,126,14,8,P.nd,null,.5,6)+
 `<path d="M60 120 Q62 100 100 100 Q144 102 150 120 Q144 134 100 134 Q66 134 60 120 Z" fill="${P.n}" ${SW}/>${[76,90,104,118,132].map(x=>`<path d="M${x-5} 103 L${x} 95 L${x+5} 103 Z" fill="${P.b}" ${SW2}/>`).join("")}<path d="M68 128 Q100 136 142 128" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".75"/>`+
 fLeg("legF",80,128,12,8,P.n,null,0,-6)+
 pt("head",68,114,`<path d="M14 116 L66 116 L66 122 L20 122 Z" fill="${FMOUTH}"/>${[22,30,38,46,54].map(x=>`<path d="M${x} 116 l2 4 l2 -4" fill="#FFFFFF"/>`).join("")}`+
  pt("jaw",68,120,`<path d="M68 120 L16 122 Q10 124 16 128 L68 128 Z" fill="${P.nd}" ${SW}/>${[22,32,42,52].map(x=>`<path d="M${x} 122 l2 -4 l2 4" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`).join("")}`)+
  `<path d="M12 112 Q14 104 30 104 L58 100 Q74 100 76 114 L68 116 L14 118 Z" fill="${P.n}" ${SW}/><circle cx="16" cy="108" r="1.6" fill="${FI}"/><rect x="56" y="110" width="8" height="8" rx="1.4" fill="${P.b}" ${SW2}/>`+
  `<path d="M54 100 Q60 90 70 98 Z" fill="${P.n}" ${SW2}/>${fE(62,98,4.2,{iris:"#E8C040",look:[-.4,0],lid:.35,lidC:P.n})}`)+
 fG(g,1,`<path d="M8 104 l-4 -4" stroke="${P.ac}" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="104" cy="116" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,78,6)));
FORM_TITLE["Rite Of Passage No. 1"]="Latchjaw Gator";

/* 61. Octopium (iron-nickel-vanadium: motor cores) — a hamster running flat out inside its own motor: a wheel of laminated core plates that
   spins under its feet, cheeks stuffed, tiny paws pumping. */
addForm("Octopium",{n:"#E8B070",a:"#F4F0E4",rn:"#B8C8F0",rb:"#C04A3A",ra:"#FFE070"},"stand",(P,g)=>`<rect x="94" y="96" width="12" height="52" fill="${P.d}" ${SW2}/><path d="M74 148 L126 148" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`+
 pt("spin",100,90,`<circle cx="100" cy="90" r="50" fill="none" stroke="${FI}" stroke-width="10"/><circle cx="100" cy="90" r="50" fill="none" stroke="${P.b}" stroke-width="6"/>${Array.from({length:12},(_,i)=>`<path d="M${100+Math.cos(i*Math.PI/6)*44} ${90+Math.sin(i*Math.PI/6)*44} L${100+Math.cos(i*Math.PI/6)*54} ${90+Math.sin(i*Math.PI/6)*54}" stroke="${P.dd}" stroke-width="2.4"/>`).join("")}${[0,1,2].map(i=>`<path d="M100 90 L${100+Math.cos(i*2.094)*46} ${90+Math.sin(i*2.094)*46}" stroke="${P.d}" stroke-width="3"/>`).join("")}`)+
 `<circle cx="100" cy="90" r="5" fill="${P.ac}" ${SW2}/>`+
 pt("legB",112,124,fOL("M112 124 L122 134",P.nd,6),.0)+
 `<path d="M74 120 Q70 96 96 92 Q124 92 126 116 Q120 132 98 132 Q78 132 74 120 Z" fill="${P.n}" ${SW}/><path d="M80 124 Q84 108 98 106 Q108 116 104 130 Q88 132 80 124 Z" fill="${P.ac}"/>`+
 pt("legF",88,126,fOL("M88 126 L80 136",P.n,6),.5)+
 pt("armF",80,110,fOL("M80 110 L68 118",P.n,5)+`<circle cx="67" cy="119" r="2.6" fill="#F0A0A8" ${SW2}/>`)+
 pt("head",80,104,`<path d="M44 98 Q42 78 64 76 Q86 78 88 98 Q84 112 64 112 Q46 112 44 98 Z" fill="${P.n}" ${SW}/><path d="M48 104 Q46 94 58 96 Q60 108 50 110 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M40 98 L48 98 L48 102 L42 102 Z" fill="${FMOUTH}"/>`+pt("jaw",48,101,`<path d="M48 101 Q44 106 40 101 Q44 104 48 104 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M38 94 Q40 88 46 90 Q46 96 40 98 Z" fill="#F0A0A8" ${SW2}/><path d="M42 96 l-8 -3 M42 98 l-8 1" stroke="${FI}" stroke-width="1"/>`+
  `${fE(60,88,5,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",72,78,`<circle cx="74" cy="76" r="6" fill="${P.n}" ${SW2}/><circle cx="74" cy="76" r="3" fill="#F0A0A8"/>`))+
 fG(g,1,`<path d="M40 60 q-4 -4 -2 -8 M30 70 q-6 -2 -6 -6" stroke="${P.d}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="108" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(152,30,6)));
FORM_TITLE["Octopium"]="Motorwheel Hamster";

/* 62. Owlhurstium (nickel-niobium: compass needles) — a narwhal whose spiral tusk swings round to point north like a needle, mottled hide,
   tail flukes beating. */
addForm("Owlhurstium",{n:"#8A9AAA",a:"#E8412C",rn:"#F0D8A0",rb:"#3A6AB0",ra:"#2FB463"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="56" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",156,98,`<path d="M152 96 L170 96 L186 78 Q192 92 182 102 Q192 112 186 124 L170 106 L152 104 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M54 98 Q58 72 100 72 Q146 74 158 100 Q146 122 100 124 Q60 122 54 98 Z" fill="${P.n}" ${SW}/><path d="M64 108 Q100 124 146 108" stroke="${P.nll}" stroke-width="7" fill="none" opacity=".7"/>${[[90,84],[106,80],[122,86],[136,92],[98,94],[116,96]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="4" ry="2.6" fill="${P.nd}" opacity=".7"/>`).join("")}`+
 pt("fin",88,108,`<path d="M88 106 Q80 124 66 130 Q70 116 78 106 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",60,94,`<path d="M52 88 L4 70" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M52 88 L4 70" stroke="${P.b}" stroke-width="4" stroke-linecap="round"/>${[44,36,28,20,12].map(x=>`<path d="M${x} ${70+(x-4)*.375-3} l-3 6" stroke="${P.dd}" stroke-width="1.4"/>`).join("")}<path d="M4 70 L12 70 L10 76 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M50 100 L66 102 L64 106 L52 104 Z" fill="${FMOUTH}"/>`+pt("jaw",66,104,`<path d="M66 104 Q58 110 50 104 Q58 108 66 108 Z" fill="${P.nll}" ${SW2}/>`)+
  `${fE(70,92,4.5,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="100" cy="56" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/><circle cx="108" cy="46" r="2" fill="none" stroke="#8AB4D8" stroke-width="1.4"/>`)+
 fG(g,2,`<path d="M104 72 L108 64 L112 72" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(132,52,6)));
FORM_TITLE["Owlhurstium"]="Needle Narwhal";

/* 63. Sleeperine (titanium-zirconium: once snowplow blades, now armour plating) — an ankylosaur, a walking tank: plated back, a plow-blade
   brow, and a club of a tail that swings. */
addForm("Sleeperine",{n:"#A88A5A",a:"#E8E4DA",rn:"#C8D8E8",rb:"#B04A3A",ra:"#2E3A6A"},"stand",(P,g)=>fShadow(72)+
 pt("tail",152,104,fOL("M150 106 Q174 104 184 92",P.n,10)+`<path d="M178 82 Q194 82 196 94 Q194 106 180 104 Q172 94 178 82 Z" fill="${P.b}" ${SW}/><path d="M184 86 l4 -4 M190 96 l5 0 M184 102 l3 4" stroke="${FI}" stroke-width="2"/>`)+
 fLeg("legB",138,114,26,13,P.nd,P.ndd,.5)+fLeg("legB",88,114,26,13,P.nd,P.ndd,1.3)+
 `<path d="M56 112 Q56 74 104 72 Q152 74 158 110 Q150 124 104 124 Q62 124 56 112 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M60 104 Q62 70 104 66 Q150 70 156 104 Z" fill="${P.b}" ${SW}/>${[[76,90],[92,80],[110,78],[128,82],[142,92],[86,98],[104,92],[122,94],[138,102]].map(([x,y])=>`<path d="M${x-6} ${y+4} L${x} ${y-6} L${x+6} ${y+4} Z" fill="${P.d}" ${SW2}/>`).join("")}<path d="M60 104 Q104 112 156 104" stroke="${P.ll}" stroke-width="2.4" fill="none"/>`+
 fLeg("legF",126,116,26,13,P.n,P.ndd,0)+fLeg("legF",76,116,26,13,P.n,P.ndd,.8)+
 pt("head",62,102,`<path d="M20 106 L44 108 L42 112 L24 110 Z" fill="${FMOUTH}"/>`+pt("beak",44,111,`<path d="M44 111 Q32 120 20 110 Q32 116 44 116 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M18 104 Q20 88 42 86 Q64 88 66 104 Q60 114 42 112 Q22 112 18 104 Z" fill="${P.n}" ${SW}/><path d="M16 92 Q30 78 66 88 L64 94 Q34 86 20 98 Z" fill="${P.b}" ${SW2}/><path d="M60 92 L70 82 L68 94 Z" fill="${P.d}" ${SW2}/>${fE(44,98,4.5,{iris:"#C88A2A",look:[-.4,0],lid:.3,lidC:P.b})}`)+
 fG(g,1,`<path d="M10 140 q6 -6 12 0" stroke="#E8F4FC" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="110" cy="74" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,50,6)));
FORM_TITLE["Sleeperine"]="Plow Ankylosaur";

/* 64. Stagehand Mix (titanium-zirconium-aluminium-vanadium: satellite brackets) — a dragonfly with four solar-panel wings, a long jointed
   body, huge eyes, and mandibles that work. */
addForm("Stagehand Mix",{n:"#2E8AB0",a:"#F2C94C",rn:"#F0B0C8",rb:"#2FA060",ra:"#3A2A6A"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 pt("wingB",96,86,`<path d="M96 86 L118 30 L140 36 L104 90 Z" fill="${P.b}" opacity=".85" ${SW2}/>${[0,1,2].map(i=>`<path d="M${104+i*8} ${66-i*8+12} L${118+i*8} ${46-i*6+8}" stroke="${P.dd}" stroke-width="1.2"/>`).join("")}<path d="M101 76 L134 40" stroke="${P.dd}" stroke-width="1.2"/>`)+
 pt("wingB",104,88,`<path d="M104 88 L156 50 L168 64 L108 94 Z" fill="${P.b}" opacity=".85" ${SW2}/><path d="M112 88 L160 58" stroke="${P.dd}" stroke-width="1.2"/>`,.3)+
 pt("tail",108,92,`${[0,1,2,3,4,5].map(i=>`<rect x="${108+i*13}" y="${88+i*1.5}" width="13" height="9" rx="4" fill="${i%2?P.nd:P.n}" ${SW2}/>`).join("")}<path d="M186 96 l6 -4 M186 100 l6 4" stroke="${FI}" stroke-width="2"/>`)+
 `<path d="M78 92 Q80 78 96 78 Q112 80 112 94 Q108 104 94 104 Q80 104 78 92 Z" fill="${P.n}" ${SW}/><path d="M86 84 L104 84" stroke="${P.ac}" stroke-width="2.4"/>`+
 [86,94,102].map((x,i)=>fLeg("legF",x,102,12,2.4,FI,null,i*.2,-4)).join("")+
 pt("wingF",92,84,`<path d="M92 84 L54 34 L70 26 L98 82 Z" fill="${P.b}" opacity=".9" ${SW2}/><path d="M88 78 L62 32" stroke="${P.dd}" stroke-width="1.2"/>${[0,1,2].map(i=>`<path d="M${70+i*6} ${44+i*10} l10 -4" stroke="${P.dd}" stroke-width="1.2"/>`).join("")}`)+
 pt("wingF",90,88,`<path d="M90 88 L40 74 L36 90 L88 94 Z" fill="${P.b}" opacity=".9" ${SW2}/><path d="M86 90 L42 82" stroke="${P.dd}" stroke-width="1.2"/>`,.3)+
 pt("head",78,90,`<path d="M50 94 L58 94 L56 98 Z" fill="${FMOUTH}"/>`+pt("jaw",58,96,`<path d="M58 96 L48 98 L52 102 Z" fill="${P.ac}" ${SW2}/>`)+
  `<circle cx="66" cy="88" r="14" fill="${P.n}" ${SW}/>${fE(62,82,8,{iris:P.ac,look:[-.3,0]})}${fE(74,80,6,{iris:P.ac,look:[-.3,0]})}`)+
 fG(g,1,`<path d="M34 120 l6 0 M30 128 l8 0" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="96" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(100,58,6)));
FORM_TITLE["Stagehand Mix"]="Panel Dragonfly";

/* 65. Cobbledon (titanium-iron: once the stirrers in glass furnaces) — a flamingo on one leg, its long neck a stirring rod dipping into a
   glowing pool, beak bent like a ladle. */
addForm("Cobbledon",{n:"#F08A9A",a:"#FFB040",rn:"#B8E0D0",rb:"#3A4A8A",ra:"#FF6A3A"},"perch",(P,g)=>`<ellipse cx="74" cy="146" rx="44" ry="6" fill="${P.ac}" opacity=".6" ${SW2}/><ellipse class="p-glow" cx="74" cy="146" rx="30" ry="3" fill="#FFF0A0"/>`+
 pt("legB",118,108,fOL("M118 108 L124 124 L112 128",P.b,3.4))+
 pt("legF",108,110,fOL("M108 110 L110 146",P.b,3.4)+`<path d="M104 146 h10" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 pt("tail",146,90,`<path d="M140 84 L166 80 L160 96 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M96 92 Q98 68 126 70 Q150 74 150 92 Q144 110 120 112 Q98 110 96 92 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",122,84,`<path d="M108 80 Q140 72 156 94 Q132 104 112 96 Z" fill="${P.nl}" ${SW2}/><path d="M140 92 L156 94 L146 100 Z" fill="${FI}"/>`)+
 pt("head",100,84,fOL("M100 84 Q76 70 80 46 Q84 30 70 26",P.n,7)+`<path d="M74 30 Q70 18 58 20 Q48 24 50 34 Q60 30 68 34 Z" fill="${P.n}" ${SW2}/>`+
  `<path d="M52 28 L48 40 L54 42 Z" fill="${FMOUTH}"/>`+pt("beak",52,30,`<path d="M52 30 Q44 40 46 52 L52 50 Q50 40 56 32 Z" fill="${P.b}" ${SW2}/><path d="M46 52 L50 52" stroke="${FI}" stroke-width="3"/>`)+
  `${fE(62,24,3.6,{iris:P.ac,look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="60" cy="134" r="2.6" fill="#FFF0A0" ${SW2}/>`)+
 fG(g,2,`<circle cx="124" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,48,6)));
FORM_TITLE["Cobbledon"]="Stirring Flamingo";

/* 66. Seven Stamp Special (titanium-tin-niobium-chromium: cutting dies) — a sawfish with a long toothed rostrum like a cutting die,
   sweeping it side to side over the sand. */
addForm("Seven Stamp Special",{n:"#B8A890",a:"#E8E4DA",rn:"#A0C8E8",rb:"#B03A5A",ra:"#FFD23F"},"swim",(P,g)=>`<ellipse class="shd" cx="110" cy="150" rx="60" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",160,106,`<path d="M156 102 L188 76 L180 106 L190 128 L156 112 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M72 108 Q76 88 112 86 Q150 88 162 108 Q150 124 112 124 Q78 124 72 108 Z" fill="${P.n}" ${SW}/><path d="M80 114 Q112 126 154 114" stroke="${P.ac}" stroke-width="6" fill="none" opacity=".6"/>`+
 pt("fin",118,88,`<path d="M108 88 L122 64 L132 90 Z" fill="${P.nd}" ${SW}/>`)+pt("fin",96,118,`<path d="M92 116 Q84 134 70 140 Q74 124 82 116 Z" fill="${P.nd}" ${SW2}/>`,.5)+
 pt("head",76,104,`<path d="M76 100 L10 102 L10 108 L76 110 Z" fill="${P.b}" ${SW}/>${Array.from({length:9},(_,i)=>`<path d="M${16+i*6.5} 102 l2 -5 l2 5 M${16+i*6.5} 108 l2 5 l2 -5" fill="#FFFFFF" stroke="${FI}" stroke-width="1"/>`).join("")}`+
  `<path d="M74 112 L88 114 L86 118 L76 116 Z" fill="${FMOUTH}"/>`+pt("jaw",88,116,`<path d="M88 116 Q80 122 74 116 Q80 120 88 120 Z" fill="${P.nl}" ${SW2}/>`)+
  `${fE(86,98,4.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M20 130 q6 -4 12 0 q6 4 12 0" stroke="#C8B480" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(140,62,6)));
FORM_TITLE["Seven Stamp Special"]="Die Sawfish";

/* 67. Spoon Drawer Mix (titanium-molybdenum: rocket nozzles) — a squid that flies by jet, a nozzle of a siphon, fins at its tip, arms
   trailing and curling, a beak that snaps among them. */
addForm("Spoon Drawer Mix",{n:"#E86A5A",a:"#FFD23F",rn:"#C8E8F0",rb:"#4A3A9A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="44" ry="4" fill="#000" opacity=".12"/>`+
 pt("fin",156,74,`<path d="M150 66 L182 52 L176 74 L182 96 L150 82 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M70 74 Q84 56 120 58 Q156 62 160 74 Q156 86 120 90 Q84 92 70 74 Z" fill="${P.n}" ${SW}/>${[[96,68],[112,72],[128,66],[142,74],[104,80]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.nd}"/>`).join("")}`+
 `<path d="M108 90 L118 100 L128 98 L120 88 Z" fill="${P.b}" ${SW2}/><g class="p-glow"><path d="M126 100 Q138 110 150 106 Q140 100 128 96 Z" fill="${P.ac}" opacity=".8"/></g>`+
 [0,1,2,3,4].map(i=>pt("sway",72,78+i*2,fOL(`M72 ${76+i*2} Q${48-i*2} ${84+i*8} ${30+i*4} ${96+i*10} Q${24+i*4} ${104+i*10} ${32+i*4} ${108+i*10}`,i%2?P.nd:P.n,4.5),i*.25)).join("")+
 pt("head",74,76,`<path d="M62 70 Q62 60 76 60 Q88 62 88 74 Q86 86 76 88 Q64 86 62 70 Z" fill="${P.n}" ${SW}/>${fE(76,70,6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  `<path d="M60 80 L66 78 L66 84 Z" fill="${FMOUTH}"/>`+pt("beak",64,82,`<path d="M64 82 L56 82 L62 88 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<circle cx="164" cy="112" r="3" fill="${P.ac}" opacity=".7"/><circle cx="176" cy="120" r="2" fill="${P.ac}" opacity=".6"/>`)+
 fG(g,2,`<circle cx="124" cy="80" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,40,6)));
FORM_TITLE["Spoon Drawer Mix"]="Jet Squid";

/* 68. Supply Boat Blend (titanium with a little aluminium: kayak fittings) — a pelican paddling, its great pouch-bill dropping open to scoop. */
addForm("Supply Boat Blend",{n:"#F0ECE0",a:"#F2A030",rn:"#C8B8E0",rb:"#2E8A6A",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 132 Q60 126 100 132 Q140 138 190 130" stroke="#8AB4D8" stroke-width="3" fill="none"/><ellipse class="shd" cx="104" cy="150" rx="50" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",150,106,`<path d="M146 102 L172 98 L166 114 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M86 116 Q86 84 118 82 Q150 86 154 114 Q146 130 118 130 Q90 130 86 116 Z" fill="${P.n}" ${SW}/><path d="M86 120 Q120 136 156 118" stroke="#8AB4D8" stroke-width="3" fill="none" opacity=".7"/>`+
 pt("wingF",118,94,`<path d="M104 92 Q140 84 160 108 Q132 118 108 108 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${132+i*8} ${100+i*2} l8 4" stroke="${FI}" stroke-width="1.6"/>`).join("")}<rect x="124" y="94" width="10" height="5" rx="2" fill="${P.b}" ${SW2}/>`)+
 pt("head",96,96,fOL("M98 100 Q86 80 84 64",P.n,9)+`<path d="M72 60 Q72 48 86 48 Q98 50 98 62 Q94 70 84 70 Q74 70 72 60 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M74 60 L28 66 L74 66 Z" fill="${FMOUTH}"/>`+
  pt("beak",74,66,`<path d="M74 64 L28 68 Q36 90 58 88 Q72 84 76 70 Z" fill="${P.ac}" opacity=".9" ${SW}/><path d="M40 72 Q52 84 70 76" stroke="${FI}" stroke-width="1.4" fill="none" opacity=".5"/>`)+
  `<path d="M74 58 L28 64 L28 66 L76 64 Z" fill="${P.b}" ${SW2}/><path d="M28 64 l-3 4 l5 -1 Z" fill="${P.d}" ${SW2}/>${fE(84,56,4,{iris:"#E8C040",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="30" cy="114" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="124" cy="120" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,62,6)));
FORM_TITLE["Supply Boat Blend"]="Paddle Pelican";

/* 69. Lost Children Blend (titanium-vanadium-tin: blanks for metal files) — a parrotfish that rasps coral with its fused beak-teeth, the
   file's crosshatch on its scales, fins rowing. */
addForm("Lost Children Blend",{n:"#3AB8A0",a:"#F08AC0",rn:"#F0D890",rb:"#6A3AB0",ra:"#3AC0E0"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="50" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",150,94,`<path d="M146 90 L176 70 Q170 94 178 118 L146 102 Z" fill="${P.ac}" ${SW}/>`)+
 `<path d="M50 96 Q54 64 100 62 Q146 64 152 96 Q146 124 100 128 Q54 126 50 96 Z" fill="${P.n}" ${SW}/>`+
 `<clipPath id="lcbc"><path d="M50 96 Q54 64 100 62 Q146 64 152 96 Q146 124 100 128 Q54 126 50 96 Z"/></clipPath><g clip-path="url(#lcbc)" opacity=".55">${Array.from({length:12},(_,i)=>`<path d="M${60+i*10} 56 l-30 80 M${36+i*10} 56 l30 80" stroke="${P.b}" stroke-width="2"/>`).join("")}</g>`+
 pt("fin",96,62,`<path d="M74 66 Q100 46 136 62 Z" fill="${P.ac}" ${SW2}/>`)+pt("fin",98,104,`<path d="M96 100 Q88 118 76 122 Q80 108 88 100 Z" fill="${P.ac}" ${SW2}/>`,.4)+
 pt("head",62,94,`<path d="M40 92 Q40 78 54 76 L56 96 Z" fill="${P.b}" ${SW2}/><path d="M42 82 h10 M41 88 h12" stroke="${FI}" stroke-width="1.4"/>`+
  `<path d="M40 96 L54 96 L54 102 L42 100 Z" fill="${FMOUTH}"/>`+pt("beak",56,100,`<path d="M56 98 L40 98 Q38 108 52 110 Z" fill="${P.d}" ${SW2}/><path d="M42 102 h10" stroke="${FI}" stroke-width="1.4"/>`)+
  `${fE(68,86,6,{iris:P.ac,look:[-.4,0]})}<path d="M60 74 Q70 70 80 76" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<path d="M20 130 l4 -10 l4 10 l4 -8 l4 8" stroke="#F08A9A" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="112" cy="90" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,40,6)));
FORM_TITLE["Lost Children Blend"]="Rasp Parrotfish";

/* 70. Tessickite (tantalum-hafnium: counterweights) — an elephant built as a counterweight, slow and enormous, trunk swinging, ears fanning,
   trumpeting with its mouth wide. */
addForm("Tessickite",{n:"#7A7A86",a:"#F4F0E4",rn:"#E8C8A0",rb:"#3A6AB0",ra:"#FFD23F"},"stand",(P,g)=>fShadow(74)+
 pt("tail",164,92,fOL("M164 90 Q172 104 168 118",P.nd,3)+`<path d="M164 116 l4 6 l4 -6" stroke="${FI}" stroke-width="2"/>`)+
 fLeg("legB",150,110,34,15,P.nd,P.ndd,.5)+fLeg("legB",106,110,34,15,P.nd,P.ndd,1.3)+
 `<path d="M80 100 Q80 60 126 58 Q168 62 168 100 Q164 122 126 124 Q84 122 80 100 Z" fill="${P.n}" ${SW}/>`+
 `<rect x="104" y="66" width="44" height="18" rx="3" fill="${P.b}" ${SW2}/><path d="M110 75 h32" stroke="${P.ll}" stroke-width="2"/><circle cx="126" cy="66" r="4" fill="${P.d}" ${SW2}/>`+
 fLeg("legF",138,112,32,15,P.n,P.ndd,0)+fLeg("legF",94,112,32,15,P.n,P.ndd,.8)+
 pt("head",84,80,`<path d="M58 92 L76 94 L74 100 L62 98 Z" fill="${FMOUTH}"/>`+pt("jaw",76,98,`<path d="M76 98 Q68 106 60 98 Q68 102 76 102 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M54 76 Q56 52 80 52 Q100 56 100 80 Q96 96 78 96 Q58 96 54 76 Z" fill="${P.n}" ${SW}/>`+
  pt("sway",58,84,fOL("M58 84 Q40 92 40 112 Q40 128 30 132",P.n,10)+`<path d="M48 96 h-8 M44 108 h-8 M42 120 h-8" stroke="${P.nd}" stroke-width="1.6"/>`)+
  `<path d="M62 90 Q56 98 48 96" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/>`+
  pt("ear",88,66,`<path d="M86 60 Q112 54 114 78 Q112 100 90 94 Z" fill="${P.nd}" ${SW}/><path d="M92 68 Q104 70 102 86" stroke="${P.ndd}" stroke-width="1.6" fill="none"/>`)+`${fE(70,72,4.2,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M20 140 l6 -4 M28 144 l6 -2" stroke="${P.nd}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="126" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(126,40,6)));
FORM_TITLE["Tessickite"]="Counterweight Elephant";

/* 71. Hastelloy C (nickel-molybdenum-chromium: chemical-plant piping that shrugs off acid) — a llama in a pipe-lagging wool coat, flanged
   collar, ears swivelling, lips curling back to spit. */
addForm("Hastelloy C",{n:"#E8DCC8",a:"#9BE05A",rn:"#C8A8D8",rb:"#2E7AA0",ra:"#FFB040"},"stand",(P,g)=>fShadow(54,112)+
 pt("tail",150,86,`<path d="M148 84 Q160 80 160 92 Q154 96 148 92 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",142,104,40,8,P.nd,P.ndd,.5)+fLeg("legB",100,104,40,8,P.nd,P.ndd,1.3)+
 `<path d="M86 96 Q86 74 118 72 Q152 74 154 96 Q150 112 120 114 Q88 114 86 96 Z" fill="${P.n}" ${SW}/>${[[96,82],[110,78],[126,78],[140,84],[100,98],[116,96],[132,98],[146,96]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="5" fill="${P.nl}" ${SW2}/>`).join("")}`+
 fLeg("legF",134,106,38,8,P.n,P.ndd,0)+fLeg("legF",94,106,38,8,P.n,P.ndd,.8)+
 pt("head",92,86,fOL("M94 88 Q84 66 86 38",P.n,13)+`<rect x="80" y="62" width="16" height="7" rx="2" fill="${P.b}" ${SW2}/><circle cx="83" cy="65.5" r="1.4" fill="${FI}"/><circle cx="93" cy="65.5" r="1.4" fill="${FI}"/>`+
  `<path d="M58 40 L72 42 L70 46 L60 44 Z" fill="${FMOUTH}"/>`+pt("jaw",72,46,`<path d="M72 46 Q64 52 58 46 Q64 50 72 50 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M56 38 Q58 22 78 22 Q96 24 96 40 Q92 48 76 46 Q60 46 56 38 Z" fill="${P.n}" ${SW}/><path d="M56 38 Q60 36 64 40" stroke="${FI}" stroke-width="1.6" fill="none"/>`+
  pt("tongue",58,42,`<circle cx="50" cy="42" r="2.4" fill="${P.ac}" ${SW2}/><circle cx="42" cy="40" r="1.8" fill="${P.ac}"/>`)+
  `${fE(76,32,4.6,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}`+
  pt("ear",86,22,`<path d="M84 24 Q80 8 86 6 Q90 12 90 24 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",92,24,`<path d="M90 26 Q94 10 100 10 Q100 18 96 26 Z" fill="${P.nd}" ${SW2}/>`,.5))+
 fG(g,1,`<path d="M30 60 q4 -4 0 -8 M38 54 q4 -4 0 -8" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="90" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,54,6)));
FORM_TITLE["Hastelloy C"]="Acidproof Llama";

/* 72. Squeezebox Blend (nickel-chromium-niobium: rock-crusher teeth and armour) — a hyena with bone-crushing jaws, sloped back, bristling
   mane, laughing with its mouth wide. */
addForm("Squeezebox Blend",{n:"#C8A870",a:"#3A2A24",rn:"#A8C8E8",rb:"#8A3A3A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(62)+
 pt("tail",150,104,fOL("M150 104 Q164 112 166 126",P.nd,5)+`<path d="M162 122 Q170 128 166 136 Q160 132 160 124 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",140,110,34,9,P.nd,P.ndd,.5,-2)+fLeg("legB",106,104,40,10,P.nd,P.ndd,1.3)+
 `<path d="M70 98 Q70 70 104 70 Q140 78 154 104 Q148 122 112 122 Q76 118 70 98 Z" fill="${P.n}" ${SW}/>${[[96,90],[112,94],[128,98],[140,106],[104,104],[120,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.ac}" opacity=".7"/>`).join("")}`+
 `<path d="M78 74 L84 64 L90 72 L96 62 L102 72 L108 64 L114 74 L120 68 L124 78" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",126,112,32,9,P.n,P.ndd,0,-2)+fLeg("legF",86,108,36,10,P.n,P.ndd,.8)+
 pt("head",78,86,`<path d="M30 88 L58 90 L56 96 L34 94 Z" fill="${FMOUTH}"/><path d="M36 90 l3 5 l3 -5 M48 91 l3 5 l3 -5" fill="${P.b}" stroke="${FI}" stroke-width=".8"/>`+
  pt("jaw",58,94,`<path d="M58 94 Q44 108 30 96 L34 94 Q46 100 58 98 Z" fill="${P.nd}" ${SW2}/><path d="M38 98 l3 -5 l3 5 M48 99 l3 -5 l3 5" fill="${P.b}" stroke="${FI}" stroke-width=".8"/>`)+
  `<path d="M28 86 Q32 66 58 66 Q80 70 82 88 Q76 96 58 94 Q36 94 28 86 Z" fill="${P.n}" ${SW}/><path d="M28 86 Q30 80 38 80 Q36 88 30 90 Z" fill="${P.ac}"/>${fE(54,78,5,{iris:"#C88A2A",look:[-.4,0]})}`+
  pt("ear",68,66,`<path d="M64 68 Q62 52 72 52 Q78 60 74 70 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",74,68,`<path d="M72 70 Q74 56 82 56 Q84 64 80 72 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M18 118 l6 -6 l4 6 l6 -8" stroke="#8A8A8A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="112" cy="84" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,46,6)));
FORM_TITLE["Squeezebox Blend"]="Crusher Hyena";

/* 73. Last Hider Mix (cobalt-molybdenum-nickel-chromium: cutting dies and crusher teeth) — a warthog with die-cut tusks curling up, a
   bristly crest, kneeling to root and snorting. */
addForm("Last Hider Mix",{n:"#8A6A5A",a:"#4A3A2A",rn:"#C8E0B0",rb:"#2E4A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(60)+
 pt("tail",150,98,fOL("M150 98 Q160 80 156 70",P.nd,3)+`<path d="M154 66 l2 -8 l4 6 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",138,114,30,9,P.nd,P.ndd,.5)+fLeg("legB",100,114,30,9,P.nd,P.ndd,1.3)+
 `<path d="M70 108 Q72 78 106 76 Q144 78 154 104 Q150 122 110 124 Q76 124 70 108 Z" fill="${P.n}" ${SW}/><path d="M74 82 L82 72 L88 80 L96 70 L102 78 L110 70 L116 78 L124 72 L128 80" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",128,116,28,9,P.n,P.ndd,0)+fLeg("legF",88,116,28,9,P.n,P.ndd,.8)+
 pt("head",80,102,`<path d="M30 110 L52 112 L50 116 L34 114 Z" fill="${FMOUTH}"/>`+pt("jaw",52,114,`<path d="M52 114 Q40 122 30 114 Q40 118 52 118 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 106 Q30 84 60 82 Q84 86 86 104 Q80 116 56 114 Q34 114 28 106 Z" fill="${P.n}" ${SW}/><ellipse cx="28" cy="104" rx="5" ry="7" fill="${P.nl}" ${SW2}/><circle cx="27" cy="101" r="1.4" fill="${FI}"/><circle cx="27" cy="107" r="1.4" fill="${FI}"/>`+
  `<path d="M42 96 a4 4 0 1 1 6 4" fill="${P.nd}" ${SW2}/>`+
  pt("claw",44,108,`<path d="M44 108 Q30 104 30 88 Q34 96 46 102 Z" fill="${P.b}" ${SW2}/>`)+pt("claw2",50,110,`<path d="M50 110 Q40 106 40 94 Q44 100 52 104 Z" fill="${P.b}" ${SW2}/>`)+
  `${fE(62,94,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",76,86,`<path d="M72 88 Q78 74 86 80 Q84 88 78 92 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M14 140 q4 -6 10 -4 q4 -4 8 0" stroke="#8A6A4A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="112" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,54,6)));
FORM_TITLE["Last Hider Mix"]="Die-Tusk Warthog";

/* 74. Waspaloy (nickel-chromium-cobalt: jet-engine turbine discs) — a hummingbird whose wings blur like turbine blades, hanging in place,
   needle bill, a gleaming gorget. */
addForm("Waspaloy",{n:"#3AA87A",a:"#E8412C",rn:"#E8C0E0",rb:"#3A5AB0",ra:"#FFD23F"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="30" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",124,106,`<path d="M120 102 L150 128 L136 132 L116 110 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("wingB",112,82,`<path d="M112 82 Q130 40 164 30 Q150 64 118 90 Z" fill="${P.b}" opacity=".55" ${SW2}/>`)+
 `<path d="M86 92 Q88 72 108 72 Q128 76 128 98 Q124 114 106 114 Q88 112 86 92 Z" fill="${P.n}" ${SW}/><path d="M94 104 Q104 112 120 106" stroke="#F4F0E4" stroke-width="5" fill="none" opacity=".7"/>`+
 `<path d="M96 116 l-2 6 M104 116 l0 6" stroke="${FI}" stroke-width="2"/>`+
 pt("wingF",108,84,`<path d="M108 84 Q120 36 150 20 Q140 60 112 92 Z" fill="${P.b}" opacity=".8" ${SW2}/>${[0,1,2].map(i=>`<path d="M${112+i*4} ${80-i*2} L${136+i*4} ${36+i*6}" stroke="${P.dd}" stroke-width="1.2"/>`).join("")}`)+
 pt("head",92,82,`<circle cx="86" cy="76" r="13" fill="${P.n}" ${SW}/><path d="M76 84 Q86 92 98 86 L96 80 Q86 84 78 80 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M74 74 L34 76 L74 77 Z" fill="${FMOUTH}"/>`+pt("beak",74,77,`<path d="M74 77 L34 77 L74 79 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M74 73 L34 75.5 L74 76 Z" fill="${P.d}" ${SW2}/>`+
  `${fE(84,72,4.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M168 40 l6 -2 M168 48 l8 0" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="108" cy="98" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(80,46,6)));
FORM_TITLE["Waspaloy"]="Turbine Hummingbird";

/* 75. Stokeite (niobium-hafnium: rocket nozzles and exhaust manifolds) — a small whale with an exhaust-manifold blowhole, spouting hot
   vapour, a wide grinning mouth that opens. */
addForm("Stokeite",{n:"#4A5A7A",a:"#FFB040",rn:"#F0C8A0",rb:"#2E8A6A",ra:"#E8604A"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="60" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",160,100,`<path d="M156 98 Q172 96 178 82 Q190 76 192 86 Q186 94 180 98 Q190 104 192 114 Q182 118 176 110 Q170 104 156 106 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M40 100 Q42 66 100 64 Q150 66 162 100 Q150 128 100 130 Q46 128 40 100 Z" fill="${P.n}" ${SW}/><path d="M44 108 Q100 136 156 108 L150 118 Q100 136 50 116 Z" fill="${P.nll}"/>${[0,1,2,3,4].map(i=>`<path d="M${60+i*12} ${116+i*1.4} l0 ${8-i}" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 `<path d="M86 66 L84 54 L100 54 L98 66 Z" fill="${P.b}" ${SW2}/><rect x="80" y="50" width="24" height="6" rx="2" fill="${P.d}" ${SW2}/>`+
 `<g class="p-glow"><path d="M92 48 Q80 30 88 16 Q92 28 96 22 Q104 34 92 48 Z" fill="${P.ac}" opacity=".85" ${SW2}/><circle cx="76" cy="22" r="3" fill="${P.ac}" opacity=".6"/><circle cx="108" cy="26" r="2.6" fill="${P.ac}" opacity=".6"/></g>`+
 pt("fin",92,114,`<path d="M92 112 Q86 132 70 138 Q74 122 82 112 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",50,100,`<path d="M40 102 L80 104 L78 108 L46 108 Z" fill="${FMOUTH}"/>`+pt("jaw",80,106,`<path d="M80 106 Q60 118 42 106 Q60 112 80 110 Z" fill="${P.nll}" ${SW2}/>`)+
  `<path d="M38 100 Q60 104 80 102" stroke="${FI}" stroke-width="2.4" fill="none"/>${fE(76,90,5,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="34" cy="74" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="120" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(132,52,6)));
FORM_TITLE["Stokeite"]="Exhaust Whale";

/* 76. Ventrilon (silver-indium: soft, heavy, a paperweight) — a sloth hanging from a branch by hooked silver claws, so unhurried it barely
   moves, slow blink, slow yawn. */
addForm("Ventrilon",{n:"#9A8A70",a:"#4A3A2A",rn:"#B8D8C8",rb:"#B04A8A",ra:"#FFD23F"},"perch",(P,g)=>`<path d="M14 34 Q100 26 190 36" stroke="#6A4A2A" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M150 32 q8 -10 18 -6" stroke="#4A8A3A" stroke-width="4" fill="none"/><ellipse cx="170" cy="24" rx="7" ry="4" fill="#5AA84A" ${SW2}/>`+
 pt("armB",130,64,fOL("M130 64 Q136 46 138 34",P.nd,10)+`<path d="M134 32 q6 -8 10 0 M138 32 q6 -6 8 2" stroke="${P.b}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`,.6)+
 pt("legB",142,92,fOL("M142 92 Q156 70 158 36",P.nd,10)+`<path d="M154 34 q6 -8 10 0 M158 34 q6 -6 8 2" stroke="${P.b}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`,1.2)+
 `<path d="M80 74 Q86 52 120 52 Q156 56 160 86 Q156 112 124 114 Q90 112 80 74 Z" fill="${P.n}" ${SW}/>${[[96,64],[112,60],[128,64],[144,74],[104,86],[124,88],[146,94],[114,104]].map(([x,y])=>`<path d="M${x} ${y} q3 6 0 10" stroke="${P.nd}" stroke-width="1.8" fill="none"/>`).join("")}`+
 pt("legF",112,100,fOL("M112 100 Q100 70 104 36",P.n,10)+`<path d="M100 34 q6 -8 10 0 M104 34 q6 -6 8 2" stroke="${P.b}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
 pt("armF",92,70,fOL("M92 70 Q78 54 78 34",P.n,10)+`<path d="M74 32 q6 -8 10 0 M78 32 q6 -6 8 2" stroke="${P.b}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`,.3)+
 pt("head",84,84,`<path d="M54 92 Q52 72 74 70 Q96 72 96 92 Q94 110 74 112 Q56 110 54 92 Z" fill="${P.n}" ${SW}/><path d="M58 92 Q60 78 74 78 Q90 80 90 94 Q86 106 74 106 Q60 104 58 92 Z" fill="${P.nll}"/>`+
  `<path d="M58 84 Q66 80 70 90 Q64 94 58 90 Z M90 84 Q82 80 78 90 Q84 94 90 90 Z" fill="${P.ac}"/>${fE(65,87,3.4,{iris:"#2A1A0A",lid:.45,lidC:P.ac})}${fE(83,87,3.4,{iris:"#2A1A0A",lid:.45,lidC:P.ac})}`+
  `<ellipse cx="74" cy="96" rx="3" ry="2" fill="${FI}"/><path d="M68 100 L80 100 L78 104 L70 104 Z" fill="${FMOUTH}"/>`+pt("jaw",80,102,`<path d="M80 102 Q74 108 68 102 Q74 106 80 106 Z" fill="${P.nl}" ${SW2}/>`))+
 fG(g,1,`<rect x="30" y="132" width="22" height="12" rx="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="124" cy="80" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(42,58,6)));
FORM_TITLE["Ventrilon"]="Paperweight Sloth";

/* 77. Teaspoonium (palladium-silver-ruthenium: watch cases) — a cuckoo that bursts out of a little watch-case door on the hour, wings
   flapping, bill wide, calling. */
addForm("Teaspoonium",{n:"#7A8AA8",a:"#F2C94C",rn:"#E8C8A8",rb:"#2E6A5A",ra:"#E8412C"},"hop",(P,g)=>`<circle cx="120" cy="92" r="46" fill="${P.b}" ${SW}/><circle cx="120" cy="92" r="38" fill="#F4F0E4" ${SW2}/>${Array.from({length:12},(_,i)=>`<path d="M${120+Math.cos(i*Math.PI/6)*32} ${92+Math.sin(i*Math.PI/6)*32} L${120+Math.cos(i*Math.PI/6)*36} ${92+Math.sin(i*Math.PI/6)*36}" stroke="${FI}" stroke-width="2"/>`).join("")}<rect x="114" y="38" width="12" height="8" rx="2" fill="${P.d}" ${SW2}/>`+
 pt("slow",120,92,`<path d="M120 92 L120 64" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+`<path d="M120 92 L138 100" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`+
 `<rect x="88" y="104" width="36" height="34" rx="3" fill="#2A1A10" ${SW2}/>`+pt("sway",88,104,`<path d="M88 104 L70 98 L70 132 L88 138 Z" fill="${P.d}" ${SW2}/>`)+
 `<path d="M100 146 L100 136 M112 146 L112 136" stroke="${FI}" stroke-width="3"/><rect x="82" y="138" width="46" height="8" rx="2" fill="${P.d}" ${SW2}/>`+
 pt("tail",116,118,`<path d="M114 114 L140 112 L136 124 L114 122 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M74 120 Q76 104 96 102 Q116 104 118 122 Q112 136 96 136 Q78 134 74 120 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${84+i*8} 124 q3 3 6 0" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("wingF",98,112,`<path d="M96 108 Q118 104 120 122 Q104 128 94 118 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",84,104,`<circle cx="76" cy="96" r="12" fill="${P.n}" ${SW}/><path d="M66 96 L50 92 L66 100 Z" fill="${FMOUTH}"/>`+pt("beak",66,99,`<path d="M66 99 L52 98 L66 102 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M66 92 L50 93 L66 96 Z" fill="${P.ac}" ${SW2}/>${fE(74,92,4.4,{iris:"#E8C040",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M40 60 l6 -4 M38 70 l8 0" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="120" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(160,40,6)));
FORM_TITLE["Teaspoonium"]="Watchcase Cuckoo";

/* 78. The Goose's Batch (platinum-rhodium-palladium: jewellery) — a grey crowned crane, a spray of fine wire for a crown, long legs, wings
   that open in a dance, bill that bugles. */
addForm("The Goose's Batch",{n:"#9AA0AA",a:"#E8412C",rn:"#F0D8B8",rb:"#7A3AA8",ra:"#3AC0E0"},"perch",(P,g)=>fShadow(40,112)+
 fLeg("legB",120,108,38,3.4,FI,null,0,6)+fLeg("legF",108,108,38,3.4,FI,null,0,-4)+
 pt("wingB",126,88,`<path d="M124 80 Q164 66 176 96 Q150 104 126 98 Z" fill="${P.nl}" ${SW2}/>`)+
 pt("tail",142,98,`<path d="M138 94 L168 104 L162 112 L136 104 Z" fill="${P.ndd}" ${SW2}/>`)+
 `<path d="M94 94 Q96 74 120 74 Q146 78 148 96 Q142 112 120 112 Q98 112 94 94 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",118,84,`<path d="M110 80 Q146 74 156 98 Q132 104 112 96 Z" fill="#F4F0E4" ${SW2}/><path d="M138 94 L156 98 L144 102 Z" fill="#B8783A"/>`)+
 pt("head",100,86,fOL("M100 86 Q88 70 90 50",FI,6)+`<path d="M78 48 Q78 36 92 36 Q104 38 104 50 Q100 58 90 58 Q80 58 78 48 Z" fill="${FI}" stroke="${FI}" stroke-width="2"/><ellipse cx="96" cy="46" rx="5" ry="4" fill="#F4F0E4"/><path d="M84 54 Q86 62 90 60" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
  pt("ant",92,36,`${[-40,-25,-10,5,20,35].map(a=>`<path d="M92 36 L${92+Math.sin(a*Math.PI/180)*18} ${36-Math.cos(a*Math.PI/180)*18}" stroke="${P.b}" stroke-width="1.4"/><circle cx="${92+Math.sin(a*Math.PI/180)*18}" cy="${36-Math.cos(a*Math.PI/180)*18}" r="1.8" fill="${P.b}" ${SW2}/>`).join("")}`)+
  `<path d="M78 46 L62 48 L78 50 Z" fill="${FMOUTH}"/>`+pt("beak",78,50,`<path d="M78 50 L62 49 L78 52 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M78 44 L62 47.5 L78 48 Z" fill="#5A5A62" ${SW2}/>${fE(86,46,3.4,{iris:"#E8E4F0",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="60" cy="30" r="2" fill="${P.b}" ${SW2}/><circle cx="54" cy="38" r="1.6" fill="${P.b}"/>`)+
 fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(136,52,6)));
FORM_TITLE["The Goose's Batch"]="Wire-Crowned Crane";

/* 79. Sea Stack Metal (gold-zinc-platinum-silver: jewellery from a wreck's strongbox) — an octopus clutching a ring and a chain in its arms,
   arms rippling, siphon puffing, beak hidden underneath. */
addForm("Sea Stack Metal",{n:"#C85A3A",a:"#F2C94C",rn:"#B8D8F0",rb:"#4A3A9A",ra:"#E8604A"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="56" ry="4" fill="#000" opacity=".14"/>`+
 [[70,118,"M70 118 Q50 130 40 120 Q30 110 42 104"],[86,124,"M86 124 Q80 144 62 146"],[104,126,"M104 126 Q108 146 126 146"],[120,122,"M120 122 Q146 134 156 122 Q164 112 152 106"],[132,114,"M132 114 Q160 112 168 96"]].map(([x,y,d],i)=>pt("sway",x,y,fOL(d,i%2?P.nd:P.n,8)+`<path d="${d}" stroke="${P.nll}" stroke-width="2" fill="none" stroke-dasharray="1 5" stroke-linecap="round"/>`,i*.3)).join("")+
 `<circle cx="40" cy="108" r="7" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="40" cy="108" r="7" fill="none" stroke="${P.b}" stroke-width="2.6"/><circle cx="40" cy="101" r="3" fill="${P.ac}" ${SW2}/>`+
 `<path d="M150 104 q6 -6 12 -2 q6 -6 12 0" stroke="${P.b}" stroke-width="3" fill="none" stroke-dasharray="4 2"/>`+
 `<path d="M64 96 Q60 50 104 44 Q148 50 142 96 Q136 124 104 126 Q70 124 64 96 Z" fill="${P.n}" ${SW}/>${[[86,64],[104,58],[122,66],[94,80],[118,82]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.nd}" opacity=".7"/>`).join("")}`+
 pt("head",104,96,`${fE(88,98,7,{iris:P.ac,look:[-.4,0],lid:.25,lidC:P.n})}${fE(120,98,6,{iris:P.ac,look:[-.4,0],lid:.25,lidC:P.n})}`+
  `<path d="M132 104 L146 98 L148 106 L136 110 Z" fill="${P.nd}" ${SW2}/><circle cx="146" cy="102" r="2" fill="${FMOUTH}"/>`+
  `<path d="M98 112 L110 112 L108 116 L100 116 Z" fill="${FMOUTH}"/>`+pt("beak",110,114,`<path d="M110 114 L98 114 L104 120 Z" fill="${P.ndd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="160" cy="70" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="50" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,28,6)));
FORM_TITLE["Sea Stack Metal"]="Strongbox Octopus";

/* 80. Canopium (palladium-silver-copper: medals and watch cases) — a koi, scales like a heap of medals, barbels trailing, long fins
   rippling, mouth gulping open and shut. */
addForm("Canopium",{n:"#F4F0E4",a:"#E8412C",rn:"#2E3A5A",rb:"#E8A040",ra:"#F4F0E4"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="50" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",148,96,`<path d="M144 94 Q170 70 188 72 Q176 96 188 122 Q170 122 144 102 Z" fill="${P.ac}" opacity=".9" ${SW}/><path d="M160 88 L182 78 M160 104 L182 116" stroke="${P.nd}" stroke-width="1.4"/>`)+
 `<path d="M46 98 Q50 72 96 70 Q140 72 150 98 Q140 122 96 124 Q52 122 46 98 Z" fill="${P.n}" ${SW}/>`+
 `<clipPath id="cnpc"><path d="M46 98 Q50 72 96 70 Q140 72 150 98 Q140 122 96 124 Q52 122 46 98 Z"/></clipPath><g clip-path="url(#cnpc)">${[[60,80,22],[118,96,26],[98,74,14]].map(([x,y,r])=>`<circle cx="${x+20}" cy="${y}" r="${r}" fill="${P.ac}"/>`).join("")}${Array.from({length:24},(_,i)=>`<circle cx="${70+(i%8)*10}" cy="${82+Math.floor(i/8)*12+(i%2)*4}" r="5.5" fill="none" stroke="${P.b}" stroke-width="1.6" opacity=".8"/>`).join("")}</g>`+
 pt("fin",92,76,`<path d="M80 74 Q100 54 128 72 Z" fill="${P.ac}" opacity=".85" ${SW2}/>`)+pt("fin",86,114,`<path d="M84 112 Q74 136 58 140 Q62 124 76 112 Z" fill="${P.n}" opacity=".9" ${SW2}/>`,.4)+
 pt("head",56,96,`<path d="M40 94 L50 92 L50 102 L42 102 Z" fill="${FMOUTH}"/>`+pt("jaw",50,100,`<path d="M50 100 Q44 106 38 100 Q44 104 50 104 Z" fill="${P.nl}" ${SW2}/>`)+`<path d="M38 92 Q40 86 50 88" stroke="${FI}" stroke-width="2" fill="none"/>`+
  pt("ant",46,100,`<path d="M46 100 Q36 112 24 112 M48 102 Q40 118 30 122" stroke="${P.b}" stroke-width="1.6" fill="none"/>`)+`${fE(62,88,5,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="26" cy="80" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="100" cy="98" r="4" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,46,6)));
FORM_TITLE["Canopium"]="Medal Koi";

/* 81. Windowsill Special (palladium-copper-ruthenium: ceremonial keys and trophy cups) — a hornbill whose casque is cut like the bow of a
   great key, bill clacking, tail long. */
addForm("Windowsill Special",{n:"#2A2A34",a:"#F2E0B0",rn:"#E8D8C8",rb:"#2E8A6A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M20 128 Q100 120 190 130" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("tail",142,110,`<path d="M138 104 L186 140 L176 146 L132 114 Z" fill="${P.n}" ${SW}/><path d="M172 132 L184 142" stroke="${P.ac}" stroke-width="4"/>`)+
 `<path d="M98 102 Q100 80 122 80 Q146 84 146 106 Q140 122 120 122 Q100 120 98 102 Z" fill="${P.n}" ${SW}/><path d="M104 112 Q118 122 136 116" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 pt("wingF",124,92,`<path d="M112 90 Q144 86 152 110 Q128 116 114 104 Z" fill="${P.n}" ${SW2}/><path d="M134 104 L152 110 L140 112 Z" fill="${P.ac}"/>`)+
 `<path d="M112 120 l-2 8 M120 120 l2 8" stroke="${FI}" stroke-width="3"/>`+
 pt("head",104,90,`<circle cx="94" cy="80" r="14" fill="${P.n}" ${SW}/><circle cx="90" cy="84" r="5" fill="${P.ac}" opacity=".5"/>`+
  `<path d="M82 78 L36 92 L82 88 Z" fill="${FMOUTH}"/>`+pt("beak",82,88,`<path d="M82 88 L38 93 Q50 98 82 92 Z" fill="${P.b}" ${SW2}/>`)+`<path d="M84 74 L36 90 Q50 76 84 70 Z" fill="${P.b}" ${SW2}/>`+
  `<path d="M84 70 Q66 62 52 74 L70 72 Z" fill="${P.d}" ${SW2}/><circle cx="66" cy="66" r="5" fill="none" stroke="${FI}" stroke-width="3.4"/><circle cx="66" cy="66" r="5" fill="none" stroke="${P.d}" stroke-width="1.8"/>`+
  `${fE(94,78,4.4,{iris:"#E8412C",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 60 l4 6 l4 -6" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="122" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,52,6)));
FORM_TITLE["Windowsill Special"]="Keybill Hornbill";

/* 82. Straight Face Metal (molybdenum with promethium, the element once used in glowing paint) — a firefly, its lantern of an abdomen
   pulsing, wing cases parted, legs dangling, mandibles working. */
addForm("Straight Face Metal",{n:"#3A2A24",a:"#C8FF6A",rn:"#E8D8F0",rb:"#C04A3A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="34" ry="4" fill="#000" opacity=".12"/><circle class="p-glow" cx="138" cy="100" r="30" fill="${P.ac}" opacity=".25"/>`+
 pt("wingB",108,82,`<path d="M108 82 Q140 40 170 50 Q150 80 112 90 Z" fill="#E8F4FC" opacity=".6" ${SW2}/>`)+
 `<path d="M118 88 Q140 80 160 92 Q166 108 150 116 Q130 118 118 104 Z" fill="${P.ac}" ${SW}/>${[132,144].map(x=>`<path d="M${x} 86 Q${x+4} 100 ${x} 116" stroke="${P.d}" stroke-width="1.8" fill="none" opacity=".5"/>`).join("")}`+
 `<path d="M84 92 Q86 76 104 76 Q122 78 124 94 Q120 106 104 106 Q88 106 84 92 Z" fill="${P.n}" ${SW}/>`+
 [92,102,112].map((x,i)=>fLeg("legF",x,104,14,2.4,FI,null,i*.2,-3)).join("")+
 pt("wingF",104,80,`<path d="M100 78 Q124 60 150 72 Q130 90 104 90 Z" fill="${P.b}" ${SW}/><path d="M106 80 L144 72" stroke="${P.ll}" stroke-width="2"/>`)+
 pt("head",84,88,`<path d="M66 82 Q70 70 84 72 Q94 76 92 88 Q88 98 76 96 Q66 94 66 82 Z" fill="${P.ac}" ${SW}/><path d="M68 84 Q74 76 88 80 L90 88 Q78 86 70 90 Z" fill="${P.n}"/>`+
  pt("ant",76,74,`<path d="M76 74 Q66 54 50 50 M82 74 Q78 56 68 44" stroke="${FI}" stroke-width="2" fill="none"/>`)+
  `${fE(74,84,4.8,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M62 88 L68 86 L68 92 Z" fill="${FMOUTH}"/>`+pt("jaw",66,92,`<path d="M66 92 L58 92 L62 96 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<circle cx="40" cy="120" r="2.4" fill="${P.ac}"/><circle cx="170" cy="130" r="2" fill="${P.ac}"/>`)+
 fG(g,2,`<circle cx="104" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(100,50,6)));
FORM_TITLE["Straight Face Metal"]="Lantern Firefly";

/* 83. Raffline (tungsten-cobalt with a trace of radon: radiation-damage tests) — a tapir in a test-rig harness, nosing about with its
   flexible snout, two-tone hide, stubby toes. */
addForm("Raffline",{n:"#2A2A30",a:"#F4F0E4",rn:"#E8C8A0",rb:"#3A7AB0",ra:"#2A2A30"},"stand",(P,g)=>fShadow(64)+
 pt("tail",156,96,`<path d="M154 94 Q162 94 162 102" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",144,110,30,11,P.n,P.ndd,.5)+fLeg("legB",98,110,30,11,P.n,P.ndd,1.3)+
 `<path d="M66 104 Q66 72 106 70 Q150 72 158 102 Q152 122 110 122 Q70 122 66 104 Z" fill="${P.n}" ${SW}/><path d="M92 72 Q128 68 150 84 Q154 104 140 118 L96 120 Q86 96 92 72 Z" fill="${P.ac}"/>`+
 `<path d="M98 72 L98 120 M132 74 L132 120" stroke="${P.b}" stroke-width="4"/><circle cx="98" cy="96" r="4" fill="${P.d}" ${SW2}/><circle cx="132" cy="96" r="4" fill="${P.d}" ${SW2}/>`+
 fLeg("legF",132,112,28,11,P.n,P.ndd,0)+fLeg("legF",84,112,28,11,P.n,P.ndd,.8)+
 pt("head",74,92,`<path d="M42 100 L58 102 L56 106 L44 104 Z" fill="${FMOUTH}"/>`+pt("jaw",58,104,`<path d="M58 104 Q50 110 44 104 Q50 108 58 108 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M40 92 Q44 74 64 74 Q82 78 82 96 Q76 106 60 104 Q44 104 40 92 Z" fill="${P.n}" ${SW}/>`+
  pt("sway",42,90,fOL("M42 90 Q30 92 26 104 Q24 110 30 112",P.n,7)+`<ellipse cx="30" cy="112" rx="3" ry="2" fill="${FI}"/>`)+
  `${fE(60,86,4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",72,76,`<path d="M68 78 Q68 64 78 66 Q80 74 74 80 Z" fill="${P.n}" ${SW2}/><path d="M71 70 q3 -2 5 0" stroke="${P.ac}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<circle cx="30" cy="60" r="4" fill="none" stroke="${P.b}" stroke-width="2"/><circle cx="30" cy="60" r="1.4" fill="${P.b}"/>`)+
 fG(g,2,`<circle cx="114" cy="80" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(114,52,6)));
FORM_TITLE["Raffline"]="Test-Rig Tapir";

/* 84. Vellumite (tin with astatine: so unstable it exists only in computer simulations) — a moth drawn in wireframe, its wings a mesh
   grid, feathery antennae, the outline flickering like a render. */
addForm("Vellumite",{n:"#2E3A6A",a:"#5FE0F0",rn:"#F0E0C0",rb:"#E87AB0",ra:"#3A2A6A"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 pt("wingB",104,84,`<path d="M104 84 Q150 40 178 64 Q170 100 108 96 Z" fill="${P.n}" opacity=".85" ${SW2}/>${[0,1,2,3].map(i=>`<path d="M${108+i*3} ${88+i} Q${140+i*6} ${60+i*8} ${170-i*2} ${66+i*8}" stroke="${P.ac}" stroke-width="1" fill="none"/>`).join("")}${[120,136,152].map(x=>`<path d="M${x} ${74-(x-120)*.3} L${x+4} ${96-(x-120)*.1}" stroke="${P.ac}" stroke-width="1"/>`).join("")}`)+
 `<path d="M84 92 Q86 80 100 80 Q114 82 116 96 Q140 104 140 116 Q126 120 108 108 Q90 106 84 92 Z" fill="${P.n}" ${SW}/>${[112,122,132].map(x=>`<path d="M${x} ${100+(x-112)*.2} q2 6 0 12" stroke="${P.ac}" stroke-width="1.4" fill="none"/>`).join("")}`+
 [92,100,108].map((x,i)=>fLeg("legF",x,104,12,2,FI,null,i*.2,-3)).join("")+
 pt("wingF",100,86,`<path d="M100 86 Q70 30 36 44 Q36 90 96 96 Z" fill="${P.b}" opacity=".8" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${98-i} ${90-i} Q${70-i*6} ${48+i*8} ${42+i*2} ${50+i*10}" stroke="${P.ac}" stroke-width="1.2" fill="none"/>`).join("")}${[52,66,80].map(x=>`<path d="M${x} ${42+(x-52)*.1} L${x+4} ${88-(x-52)*.4}" stroke="${P.ac}" stroke-width="1.2"/>`).join("")}<circle cx="64" cy="66" r="7" fill="none" stroke="${P.ac}" stroke-width="2" class="p-glow"/>`)+
 pt("head",86,90,`<circle cx="78" cy="90" r="10" fill="${P.n}" ${SW}/>${fE(74,88,5,{iris:P.ac,look:[-.4,0]})}<path d="M66 94 L72 94 L70 98 Z" fill="${FMOUTH}"/>`+pt("jaw",72,96,`<path d="M72 96 L64 96 L68 100 Z" fill="${P.nl}" ${SW2}/>`)+
  pt("ant",78,80,`<path d="M78 80 Q66 60 56 56" stroke="${FI}" stroke-width="1.6" fill="none"/>${[0,1,2,3,4].map(i=>`<path d="M${74-i*4} ${74-i*3.4} l-4 -4 M${74-i*4} ${74-i*3.4} l2 -5" stroke="${FI}" stroke-width="1"/>`).join("")}`)+pt("ant",82,80,`<path d="M82 80 Q80 60 72 50" stroke="${FI}" stroke-width="1.6" fill="none"/>${[0,1,2,3].map(i=>`<path d="M${81-i*2.4} ${72-i*5} l-5 -2 M${81-i*2.4} ${72-i*5} l4 -3" stroke="${FI}" stroke-width="1"/>`).join("")}`,.4))+
 fG(g,1,`<rect x="30" y="118" width="8" height="8" fill="none" stroke="${P.ac}" stroke-width="1.6"/><rect x="40" y="128" width="5" height="5" fill="none" stroke="${P.ac}" stroke-width="1.4"/>`)+
 fG(g,2,`<circle cx="100" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,40,6)));
FORM_TITLE["Vellumite"]="Wireframe Moth";

/* 85. Polka Blend (tungsten with iron and thorium: radiation shielding) — a wombat with a shield-plate rump it backs into its burrow,
   square-built, digging claws, a broad yawning mouth. */
addForm("Polka Blend",{n:"#8A7A6A",a:"#F2C94C",rn:"#C8D8B8",rb:"#2E3A6A",ra:"#E8604A"},"stand",(P,g)=>fShadow(60)+
 fLeg("legB",134,122,20,12,P.nd,P.ndd,.5)+fLeg("legB",96,122,20,12,P.nd,P.ndd,1.3)+
 `<path d="M62 116 Q62 82 104 80 Q146 82 152 114 Q148 132 106 132 Q66 132 62 116 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M132 84 Q160 92 158 120 Q152 130 136 130 Q144 106 132 84 Z" fill="${P.b}" ${SW}/><path d="M140 94 Q152 104 148 122" stroke="${P.ll}" stroke-width="2" fill="none"/><circle cx="148" cy="108" r="5" fill="${P.ac}" ${SW2}/><path d="M148 104 l0 3 M145 110 l2 -1 M151 110 l-2 -1" stroke="${FI}" stroke-width="1.4"/>`+
 fLeg("legF",122,124,18,12,P.n,P.ndd,0)+pt("legF",80,122,fOL("M80 122 L78 142",P.n,12)+`<path d="M72 142 l-6 2 M74 144 l-4 4 M78 145 l-2 4" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`,.8)+
 pt("head",72,106,`<path d="M24 110 L48 112 L46 118 L28 116 Z" fill="${FMOUTH}"/>`+pt("jaw",48,116,`<path d="M48 116 Q36 126 24 116 Q36 122 48 120 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M22 104 Q24 82 52 80 Q76 84 78 106 Q72 116 50 114 Q28 114 22 104 Z" fill="${P.n}" ${SW}/><path d="M18 100 Q18 92 28 92 Q32 100 26 106 Q20 106 18 100 Z" fill="${P.nd}" ${SW2}/>`+
  `${fE(46,96,4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",64,82,`<path d="M60 84 Q60 70 70 72 Q72 80 68 86 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M160 140 q6 -6 12 -2" stroke="#8A6A4A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,62,6)));
FORM_TITLE["Polka Blend"]="Shieldrump Wombat";

/* 86. Sockium (tin-polonium-nickel: polonium makes its own heat) — an axolotl kept warm by its own core, feathery gill-fronds glowing
   ember-red, smiling mouth, little splayed hands. */
addForm("Sockium",{n:"#F0B8C0",a:"#FF6A3A",rn:"#3A3A4A",rb:"#5FE0A0",ra:"#FFD23F"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="54" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",142,104,`<path d="M140 98 Q170 92 190 104 Q170 120 140 114 Z" fill="${P.n}" ${SW}/><path d="M146 98 Q170 86 188 102" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".7"/>`)+
 fLeg("legB",128,116,14,5,P.nd,null,.4,6)+
 `<path d="M64 108 Q66 90 100 88 Q136 90 146 106 Q138 122 100 122 Q70 122 64 108 Z" fill="${P.n}" ${SW}/><circle class="p-glow" cx="104" cy="104" r="8" fill="${P.ac}" opacity=".45"/>`+
 pt("legF",82,118,fOL("M82 118 L76 132",P.n,5)+`<path d="M76 132 l-5 2 M76 132 l-3 5 M76 132 l1 5" stroke="${P.nd}" stroke-width="2" stroke-linecap="round"/>`)+
 pt("head",70,100,`<path d="M28 98 Q28 78 54 76 Q78 78 80 98 Q76 114 54 114 Q30 114 28 98 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M30 102 Q42 108 54 104 L52 108 Q40 110 30 104 Z" fill="${FMOUTH}"/>`+pt("jaw",54,106,`<path d="M54 106 Q42 114 30 104 Q42 110 54 108 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(40,92,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  [[66,82,-50],[70,90,-20],[70,98,10]].map(([x,y,a],i)=>pt("ear",x,y,`<g transform="rotate(${a} ${x} ${y})"><path d="M${x} ${y} L${x+22} ${y}" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>${[0,1,2,3].map(k=>`<path d="M${x+5+k*5} ${y} l2 -6 M${x+5+k*5} ${y} l2 6" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`).join("")}</g>`,i*.3)).join(""))+
 fG(g,1,`<circle cx="34" cy="62" r="2.6" fill="${P.ac}" opacity=".7"/><circle cx="26" cy="54" r="1.8" fill="${P.ac}" opacity=".6"/>`)+
 fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,68,6)));
FORM_TITLE["Sockium"]="Ember Axolotl";

/* 87. Cobbite (aluminium with tin and hydrogen locked inside) — a seahorse buoyed up by a hydrogen float bladder, curling tail, dorsal fin
   fluttering, snout that snaps up food. */
addForm("Cobbite",{n:"#F2B84A",a:"#BFE8FF",rn:"#C8B8E8",rb:"#2E8A8A",ra:"#E8604A"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="30" ry="4" fill="#000" opacity=".12"/>`+
 `<circle cx="132" cy="54" r="16" fill="${P.ac}" opacity=".75" ${SW}/><path d="M124 46 q4 -4 8 -2" stroke="#FFFFFF" stroke-width="2.4" fill="none"/><path d="M128 70 L116 82" stroke="${FI}" stroke-width="1.6"/>`+
 pt("tail",108,118,fOL("M106 116 Q118 136 108 146 Q96 150 94 140 Q94 132 102 134",P.n,8))+
 `<path d="M86 66 Q102 62 112 82 Q120 104 106 120 Q92 126 88 112 Q84 96 86 66 Z" fill="${P.n}" ${SW}/>${[76,86,96,106].map(y=>`<path d="M${88} ${y} Q${100} ${y+4} ${112} ${y-2}" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}<path d="M92 82 Q96 96 94 112" stroke="${P.nll}" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("fin",112,92,`<path d="M110 84 Q126 86 126 100 Q118 102 110 98 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("head",90,66,`<path d="M74 56 Q76 40 94 42 Q106 46 104 62 Q98 72 86 70 Z" fill="${P.n}" ${SW}/><path d="M86 42 l2 -8 l4 6 l4 -6 l2 8" fill="${P.n}" ${SW2}/>`+
  `<path d="M76 56 L52 60 L76 62 Z" fill="${FMOUTH}"/>`+pt("jaw",76,62,`<path d="M76 62 L52 62 L54 66 L76 66 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M78 54 L52 58 L52 61 L78 60 Z" fill="${P.n}" ${SW2}/>${fE(88,54,4.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="60" cy="30" r="3" fill="none" stroke="${P.ac}" stroke-width="1.6"/><circle cx="68" cy="20" r="2" fill="none" stroke="${P.ac}" stroke-width="1.4"/>`)+
 fG(g,2,`<circle cx="100" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(152,30,6)));
FORM_TITLE["Cobbite"]="Float Seahorse";

/* 88. Marmalite (zirconium with darmstadtium: legendary, only ever simulated) — a great stag whose antlers branch into a map of stars,
   coat spangled, stamping and bellowing. */
addForm("Marmalite",{n:"#3A3A6A",a:"#FFE070",rn:"#F0E8D8",rb:"#E87A3A",ra:"#3A6AD8"},"stand",(P,g)=>fShadow(58,112)+
 pt("tail",156,90,`<path d="M154 86 Q164 84 164 94 Q158 96 154 92 Z" fill="#F4F0E4" ${SW2}/>`)+
 fLeg("legB",146,106,38,7,P.nd,P.ndd,.5)+fLeg("legB",104,106,38,7,P.nd,P.ndd,1.3)+
 `<path d="M88 98 Q88 74 122 72 Q156 74 160 96 Q156 114 124 116 Q92 116 88 98 Z" fill="${P.n}" ${SW}/>${[[104,84],[120,80],[138,84],[112,98],[132,100],[148,94]].map(([x,y])=>star(x,y,2.6,P.ac)).join("")}`+
 fLeg("legF",138,108,36,7,P.n,P.ndd,0)+fLeg("legF",96,108,36,7,P.n,P.ndd,.8)+
 pt("head",96,88,fOL("M98 92 Q86 72 82 56",P.n,12)+`<path d="M80 74 Q86 82 92 80" stroke="#F4F0E4" stroke-width="5" fill="none"/>`+
  `<path d="M52 56 L70 58 L68 62 L56 60 Z" fill="${FMOUTH}"/>`+pt("jaw",70,62,`<path d="M70 62 Q62 68 52 62 Q62 66 70 66 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M50 54 Q54 40 72 40 Q90 42 90 56 Q86 64 70 62 Q54 62 50 54 Z" fill="${P.n}" ${SW}/><ellipse cx="51" cy="53" rx="3" ry="2.2" fill="${FI}"/>${fE(72,48,4.4,{iris:P.ac,look:[-.4,0]})}`+
  pt("ear",84,44,`<path d="M82 44 Q92 34 100 40 Q94 48 86 48 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ant",78,40,`<path d="M78 40 Q70 20 82 4 M74 26 Q62 22 58 12 M80 14 Q92 12 96 4" stroke="${P.b}" stroke-width="3.4" fill="none" stroke-linecap="round"/>${[[82,4],[58,12],[96,4]].map(([x,y])=>star(x,y,3.2,P.ac)).join("")}`)+
  pt("ant",86,40,`<path d="M86 40 Q100 24 92 8 M94 24 Q108 22 112 12" stroke="${P.d}" stroke-width="3" fill="none" stroke-linecap="round"/>${[[92,8],[112,12]].map(([x,y])=>star(x,y,2.8,P.ac)).join("")}`,.4))+
 fG(g,1,`${star(30,30,3,P.ac)}${star(170,40,2.6,P.ac)}`)+
 fG(g,2,`<circle cx="124" cy="94" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(140,52,6)));
FORM_TITLE["Marmalite"]="Starmap Stag";

/* 89. Borrowed Pen No. 2 (titanium with rutherfordium: legendary, only ever simulated) — a griffin, eagle at the front and lion behind,
   great wings beating, hooked beak gaping, talons flexing. */
addForm("Borrowed Pen No. 2",{n:"#C8A060",a:"#F4F0E4",rn:"#2E2E4A",rb:"#5FE0F0",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="50" ry="5" fill="#000" opacity=".14"/>`+
 pt("tail",150,104,fOL("M150 104 Q176 110 184 92",P.n,5)+`<path d="M180 92 Q186 80 194 86 Q192 96 184 96 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("wingB",110,80,`<path d="M110 80 Q130 20 178 12 Q170 34 160 44 Q170 46 168 56 Q150 62 140 70 Q146 78 120 92 Z" fill="${P.d}" ${SW}/>`)+
 fLeg("legB",142,110,26,9,P.nd,P.ndd,.5,4)+
 `<path d="M80 100 Q82 76 116 76 Q150 80 156 102 Q150 120 118 120 Q84 120 80 100 Z" fill="${P.n}" ${SW}/><path d="M80 98 Q84 74 108 76 Q104 104 92 118 Q80 112 80 98 Z" fill="${P.ac}"/>`+
 pt("legF",92,114,fOL("M92 114 L86 136",P.b,6)+`<path d="M84 136 l-6 4 M86 138 l-3 6 M88 138 l2 6" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("wingF",108,84,`<path d="M108 84 Q96 24 56 14 Q66 34 74 42 Q62 44 66 54 Q82 58 88 66 Q80 74 100 94 Z" fill="${P.b}" ${SW}/><path d="M100 82 Q90 48 66 26" stroke="${P.ll}" stroke-width="2" fill="none"/>`)+
 pt("head",88,88,`<path d="M62 74 Q60 58 76 56 Q92 58 94 74 Q92 88 78 90 Q64 88 62 74 Z" fill="${P.ac}" ${SW}/><path d="M86 58 L96 52 L94 62 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M64 72 L50 74 L62 80 Z" fill="${FMOUTH}"/>`+pt("beak",64,78,`<path d="M64 78 L52 76 L60 84 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M66 66 Q52 66 46 76 Q52 74 64 74 Z" fill="${P.b}" ${SW2}/>${fE(76,68,4.4,{iris:"#E8A020",look:[-.4,0]})}`)+
 fG(g,1,`${star(30,100,3)}${star(178,130,2.6)}`)+
 fG(g,2,`<circle cx="120" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,6,6)));
FORM_TITLE["Borrowed Pen No. 2"]="Eclipse Griffin";

/* 90. Seventy Special (niobium-molybdenum with neon) — a lionfish lit up like a neon sign, venomous fin-rays fanned out and raised,
   pouting mouth. */
addForm("Seventy Special",{n:"#E86A8A",a:"#5FFFE0",rn:"#F0E8C0",rb:"#3A2A8A",ra:"#FF6AD0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="46" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",148,98,`<path d="M144 94 L174 80 L168 98 L174 116 L144 104 Z" fill="${P.n}" opacity=".9" ${SW}/>`)+
 pt("fin",108,78,`${[0,1,2,3,4,5,6].map(i=>{const a=(-60+i*16)*Math.PI/180,x=92+i*8,y=80-Math.sin((i/6)*Math.PI)*4;return`<path d="M${x} ${y} L${x+Math.sin(a)*34} ${y-Math.cos(a)*34}" stroke="${FI}" stroke-width="3.6" stroke-linecap="round"/><path d="M${x} ${y} L${x+Math.sin(a)*34} ${y-Math.cos(a)*34}" stroke="${P.ac}" stroke-width="1.6" stroke-linecap="round" class="p-glow"/>`}).join("")}`)+
 `<path d="M60 96 Q62 74 102 72 Q140 74 150 98 Q140 118 102 120 Q66 120 60 96 Z" fill="${P.n}" ${SW}/>${[78,90,102,114,126,138].map(x=>`<path d="M${x} ${74+Math.abs(x-104)*.08} Q${x+4} 96 ${x} ${118-Math.abs(x-104)*.06}" stroke="#F4F0E4" stroke-width="3" fill="none" opacity=".85"/>`).join("")}`+
 pt("fin",92,108,`${[0,1,2,3,4].map(i=>`<path d="M92 108 Q${80+i*4} ${124+i*3} ${60+i*8} ${132+i*3}" stroke="${FI}" stroke-width="3.2" fill="none" stroke-linecap="round"/><path d="M92 108 Q${80+i*4} ${124+i*3} ${60+i*8} ${132+i*3}" stroke="${P.ac}" stroke-width="1.4" fill="none" stroke-linecap="round"/>`).join("")}`,.4)+
 pt("head",66,96,`<path d="M52 96 L66 96 L64 102 L54 100 Z" fill="${FMOUTH}"/>`+pt("jaw",66,100,`<path d="M66 100 Q58 108 50 100 Q58 104 66 104 Z" fill="${P.nl}" ${SW2}/>`)+`<path d="M50 94 Q54 88 64 90" stroke="${FI}" stroke-width="2" fill="none"/>`+
  `${fE(74,88,5,{iris:P.ac,look:[-.4,0]})}<path d="M70 80 l-4 -8 M76 80 l0 -9" stroke="${P.ac}" stroke-width="1.6"/>`)+
 fG(g,1,`<circle cx="30" cy="80" r="3" fill="none" stroke="${P.ac}" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="108" cy="98" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(118,26,6)));
FORM_TITLE["Seventy Special"]="Neon Lionfish";
