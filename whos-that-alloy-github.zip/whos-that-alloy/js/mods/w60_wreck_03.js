/* ---- Shipwreck Coast, 3 ---- */
/* Fennickite: the crate in Fennick Cavern will outlast its stalactites. A cave glow-worm hanging its sticky silk threads like a chandelier. */
addForm("Fennickite",{n:"#C8D8A0",a:"#7AF0C0",rn:"#3A3A4A",rb:"#8A6A4A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 14 H194 V30 Q170 40 150 30 Q130 46 104 30 Q80 44 60 30 Q40 40 14 30 Z" fill="#6A6A74" ${SW}/>${[[44,30,22],[120,32,30],[170,30,18]].map(([x,y,h])=>`<path d="M${x-6} ${y} L${x} ${y+h} L${x+6} ${y} Z" fill="#7A7A84" ${SW2}/>`).join("")}`+
 Array.from({length:9},(_,i)=>pt(i%2?"legB":"legF",70+i*8,52,`<path d="M${70+i*8} 50 V${90+(i*17%40)}" stroke="#E8F4F8" stroke-width="1.2" opacity=".8"/>${[0,1,2,3].map(k=>`<circle cx="${70+i*8}" cy="${60+k*9}" r="1.8" fill="${P.ac}" opacity=".85"/>`).join("")}`,i*.11)).join("")+
 `<path d="M60 44 Q80 52 104 48 Q130 44 150 52 Q140 60 104 58 Q72 58 60 44 Z" fill="${P.n}" ${SW}/>${[76,92,108,124,140].map(x=>`<path d="M${x} 48 q2 6 0 10" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 pt("head",58,48,`<circle cx="54" cy="48" r="9" fill="${P.n}" ${SW}/>${E2(52,46,3,"#1A1A1A")}`+HMOUTH(46,52,52,P,1.8))+
 pt("tail",152,52,`<circle cx="156" cy="54" r="8" fill="${P.ac}" ${SW}/><circle cx="156" cy="54" r="14" fill="${P.ac}" opacity=".25"/>`)+
 fG(g,1,`<path d="M20 140 Q40 130 60 140" stroke="#7A7A84" stroke-width="5" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="52" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Fennickite"]="Cave Glow-Worm";SM("Fennickite","Sticky Threads","RES","s",0,100,"tspd-2","Glowing beads in the dark. Fly towards them and you stay there.");

/* Fifth Voice Metal: a barbershop quartet calls it their fifth member and bought it a waistcoat. A howler monkey in a waistcoat and boater, holding the low note. */
addForm("Fifth Voice Metal",{n:"#2A2A30",a:"#C8302A",rn:"#E8D8C8",rb:"#3A6A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54)+
 pt("tail",126,118,`<path d="M124 120 Q154 120 160 96 Q162 84 154 84 Q148 88 154 94" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M124 120 Q154 120 160 96 Q162 84 154 84 Q148 88 154 94" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,128,fOL("M116 124 L122 142 H132",P.nd,8),.5)+
 `<path d="M84 126 Q80 94 104 90 Q128 94 124 126 Q118 140 104 140 Q88 140 84 126 Z" fill="${P.n}" ${SW}/><path d="M90 98 L104 92 L118 98 L116 132 Q104 136 92 132 Z" fill="${P.ac}" ${SW2}/>${[106,116,126].map(y=>`<circle cx="104" cy="${y}" r="1.8" fill="#F2C94C"/>`).join("")}<path d="M98 98 L104 112 L110 98" stroke="#F4F0F4" stroke-width="3" fill="none"/>`+
 pt("legF",92,128,fOL("M94 124 L88 142 H76",P.n,8))+
 pt("armF",88,104,fOL("M88 104 Q72 100 66 86",P.n,6))+pt("armB",120,104,fOL("M120 104 Q136 108 140 120",P.nd,6),.4)+
 pt("head",100,76,`<path d="M78 80 Q78 56 100 54 Q122 56 122 80 Q118 96 100 96 Q82 96 78 80 Z" fill="${P.n}" ${SW}/><path d="M84 82 Q86 70 100 70 Q114 70 116 82" fill="#5A4A44"/>${E2(92,72,3.6,"#3A2410")}${E2(108,72,3.6,"#3A2410")}`+
  `<ellipse cx="100" cy="88" rx="9" ry="7" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",100,92,`<path d="M90 90 Q100 104 110 90 Q100 96 90 90 Z" fill="${P.n}" ${SW2}/>`)+
  `<ellipse cx="100" cy="56" rx="24" ry="5" fill="#E8D890" ${SW2}/><rect x="86" y="44" width="28" height="12" fill="#E8D890" ${SW2}/><path d="M86 52 h28" stroke="${P.ac}" stroke-width="3"/>`)+
 fG(g,1,`<path d="M30 70 q8 -6 16 0 M26 80 q10 -8 22 0 M34 60 q4 -3 8 0" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Fifth Voice Metal"]="Barbershop Howler";SM("Fifth Voice Metal","Low Note","RES","a",70,100,"tdef-1@40","The bass line, held so long and so low the floor hums.");

/* Forkliftium: please don't ask the shipping department about the forklift. A rhinoceros beetle whose horn is a pair of forklift forks. */
addForm("Forkliftium",{n:"#3A3A40",a:"#E8B020",rn:"#E8D8C8",rb:"#8A4A2A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 [0,1,2].map(i=>pt("legB",124+i*10,124,`<path d="M${124+i*10} 124 L${132+i*12} 112 L${140+i*12} 142" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M92 124 Q92 92 128 90 Q164 92 166 124 Q160 136 128 136 Q96 136 92 124 Z" fill="${P.n}" ${SW}/><path d="M128 90 V136" stroke="${FI}" stroke-width="2"/><path d="M100 104 Q128 96 158 104" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".75"/><path d="M110 118 h36" stroke="${P.ac}" stroke-width="3" stroke-dasharray="6 4" opacity=".75"/>`+
 [0,1,2].map(i=>pt("legF",100+i*6,126,`<path d="M${100+i*6} 126 L${92+i*6} 114 L${84+i*8} 142" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linejoin="round"/>`,i*.2+.1)).join("")+
 pt("head",88,114,`<path d="M70 124 Q70 104 90 102 Q104 104 104 122 Z" fill="${P.n}" ${SW}/>${E2(84,112,3.4,"#E8B020")}`+HMOUTH(70,120,78,P,2)+
  pt("ant",82,104,`<path d="M84 104 V60" stroke="${FI}" stroke-width="7"/><path d="M84 104 V60" stroke="${P.ac}" stroke-width="4"/><path d="M84 64 H40 M84 84 H40" stroke="${FI}" stroke-width="6" stroke-linecap="round"/><path d="M84 64 H40 M84 84 H40" stroke="${P.b}" stroke-width="3.4" stroke-linecap="round"/><rect x="40" y="48" width="30" height="16" fill="#B88A50" ${SW2}/>`))+
 fG(g,1,`<path d="M160 40 l10 -10 l10 10 Z" fill="${P.ac}" ${SW2}/><text x="167" y="40" font-size="8" font-weight="bold" fill="${FI}">!</text>`)+fG(g,2,`<circle cx="128" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,60,6)));
FORM_TITLE["Forkliftium"]="Forklift Rhinoceros Beetle";SM("Forkliftium","Lift And Shift","STR","a",80,95,"tdef-1@30","Under, up, and away. Mind the shelving.");

/* Friendlium: logged aboard an airship as 'miscellaneous, friendly'. A flying blimp-pig with a propeller tail and a gondola, grinning. */
addForm("Friendlium",{n:"#E8A8A8",a:"#5A8AC8",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0A0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",164,74,`<path d="M156 74 Q166 66 170 74 Q164 80 158 78" stroke="${FI}" stroke-width="3" fill="none"/>`+pt("spin",174,74,`<path d="M174 60 V88 M160 74 H188" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M174 60 V88 M160 74 H188" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`))+
 `<path d="M40 74 Q46 40 104 38 Q160 40 164 74 Q160 108 104 110 Q46 108 40 74 Z" fill="${P.n}" ${SW}/>${[60,80,100,120,140].map(x=>`<path d="M${x} 42 Q${x+2} 74 ${x} 106" stroke="${P.nd}" stroke-width="1.4" fill="none" opacity=".6"/>`).join("")}<path d="M60 52 Q90 42 120 46" stroke="#fff" stroke-width="3" fill="none" opacity=".5"/>`+
 `<path d="M84 110 L80 120 M124 110 L128 120" stroke="${FI}" stroke-width="1.6"/><rect x="76" y="120" width="56" height="16" rx="4" fill="${P.ac}" ${SW}/>${[84,96,108,120].map(x=>`<rect x="${x}" y="124" width="7" height="6" fill="#E8F4F8" ${SW2}/>`).join("")}`+
 pt("wingF",130,90,`<path d="M130 96 L150 110 L136 112 Z" fill="${P.nd}" ${SW}/>`)+pt("wingB",130,58,`<path d="M130 52 L150 38 L136 36 Z" fill="${P.nd}" ${SW}/>`,.3)+
 pt("head",48,74,`<ellipse cx="38" cy="76" rx="9" ry="11" fill="${P.nd}" ${SW}/><ellipse cx="35" cy="72" rx="2" ry="3" fill="${FI}"/><ellipse cx="35" cy="80" rx="2" ry="3" fill="${FI}"/>${E2(58,64,4.2)}`+HMOUTH(50,88,62,P,2.6)+pt("ear",64,48,`<path d="M58 50 L64 34 L72 50 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 q8 -6 16 0 q8 -6 16 0" stroke="#fff" stroke-width="4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,18,6)));
FORM_TITLE["Friendlium"]="Blimp Pig";SM("Friendlium","Friendly Drift","RES","s",0,100,"heal:25,tatk-1","It just floats over and says hello. Hard to fight that.");

/* Gentleman's Blend: 'mix gently' became 'mix gentlemen'. An emperor tamarin, the monkey with the grand white moustache, raising its hat. */
addForm("Gentleman's Blend",{n:"#4A4A50",a:"#F4F0F4",rn:"#E8D8C8",rb:"#B8602A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(54)+
 pt("tail",126,116,`<path d="M124 118 Q160 122 168 144" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M124 118 Q160 122 168 144" stroke="#C8603A" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,128,fOL("M116 124 L122 142 H130",P.nd,7),.5)+
 `<path d="M86 126 Q82 96 104 92 Q126 96 124 126 Q118 140 104 140 Q90 140 86 126 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",94,128,fOL("M94 124 L88 142 H78",P.n,7))+
 pt("armB",120,104,fOL("M120 104 Q132 110 130 122",P.nd,5),.4)+
 pt("armF",88,102,fOL("M88 102 Q74 92 76 74",P.n,5)+`<g transform="rotate(-20 76 66)"><ellipse cx="76" cy="70" rx="14" ry="3" fill="${FI}"/><rect x="66" y="50" width="20" height="20" rx="2" fill="${FI}"/><path d="M66 64 h20" stroke="#8A2A3A" stroke-width="3"/></g>`)+
 pt("head",104,78,`<circle cx="104" cy="74" r="16" fill="${P.n}" ${SW}/>${E2(98,70,3.6,"#3A2410")}${E2(110,70,3.6,"#3A2410")}<ellipse cx="104" cy="80" rx="3" ry="2" fill="${FI}"/>`+
  `<path d="M104 84 Q90 84 82 100 Q80 110 74 112 Q84 112 92 100 Q98 92 104 90 Q110 92 116 100 Q124 112 134 112 Q128 110 126 100 Q118 84 104 84 Z" fill="${P.ac}" ${SW}/>`+pt("jaw",104,90,`<path d="M100 88 Q104 92 108 88" stroke="${FMOUTH}" stroke-width="2.4" fill="none"/>`))+
 fG(g,1,`<circle cx="150" cy="40" r="6" fill="none" stroke="${FI}" stroke-width="2"/><path d="M156 40 q10 6 10 20" stroke="${FI}" stroke-width="1.2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Gentleman's Blend"]="Hat-Doffing Tamarin";SM("Gentleman's Blend","Mix Gently","RES","s",0,100,"tatk-1,ward+1","After you. No, after you. Please, I insist.");

/* Ghost Order No. 9: orders kept coming from a computer that had been unplugged. The computer's ghost: a sheet-draped monitor, plug trailing. */
addForm("Ghost Order No. 9",{n:"#E8ECF4",a:"#5AE08A",rn:"#3A3A4A",rb:"#7A8AC8",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",104,124,`<path d="M74 110 Q72 132 84 132 Q90 142 100 132 Q108 142 116 132 Q126 140 132 130 Q138 126 134 110 Z" fill="${P.n}" opacity=".85" ${SW}/>`)+
 pt("legB",126,128,`<path d="M128 126 Q150 136 166 132 Q178 128 176 140" stroke="${FI}" stroke-width="3" fill="none"/><rect x="172" y="138" width="10" height="7" rx="1" fill="${P.b}" ${SW2}/><path d="M174 145 v4 M180 145 v4" stroke="${FI}" stroke-width="1.6"/>`,.5)+
 `<path d="M70 114 Q66 50 104 42 Q142 50 138 114 Z" fill="${P.n}" ${SW}/><rect x="82" y="60" width="44" height="36" rx="4" fill="#2A3A3A" ${SW}/><rect x="86" y="64" width="36" height="28" rx="2" fill="#1A2A22"/>`+
 pt("head",104,78,`<text x="90" y="80" font-size="10" font-weight="bold" fill="${P.ac}" font-family="monospace">O_O</text>`+pt("jaw",104,88,`<rect x="96" y="84" width="16" height="3" fill="${P.ac}"/>`))+
 pt("armF",72,92,`<path d="M72 92 Q54 90 50 80" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".85"/><rect x="34" y="68" width="18" height="12" fill="#F4F0E4" ${SW2}/><text x="36" y="77" font-size="6" font-weight="bold" fill="${FI}">No.9</text>`)+pt("armB",136,92,`<path d="M136 92 Q154 88 158 98" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".85"/>`,.4)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}" font-family="monospace">OFF?</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(30,30,6)));
FORM_TITLE["Ghost Order No. 9"]="Unplugged Monitor Ghost";SM("Ghost Order No. 9","Phantom Order","RES","a",60,100,"irr@30","Nobody placed it. It arrives anyway.");

/* Goat Grievance Mix: pressed into a clay tablet beside a furious complaint about a neighbour's goat. A lamassu, the winged bull of those clay-tablet kingdoms, beard curled. */
addForm("Goat Grievance Mix",{n:"#C8A070",a:"#3A2A20",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(76)+
 pt("tail",162,96,fOL("M160 96 Q172 110 168 128",P.n,3)+`<path d="M164 124 Q172 132 166 138 Q160 132 164 124 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("wingB",132,82,`<path d="M126 86 Q138 46 176 30 Q172 50 178 54 Q164 58 166 68 Q150 72 146 92 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${142+i*8} ${80-i*10} l14 -6" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`,.3)+
 fLeg("legB",150,110,30,11,P.nd,P.ac,.5)+fLeg("legB",116,112,28,11,P.nd,P.ac,1.3)+
 `<path d="M86 102 Q86 78 124 76 Q160 78 164 100 Q160 120 126 120 Q90 120 86 102 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${96+i*14} 112 q4 6 8 0" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")}`+
 fLeg("legF",142,112,28,11,P.n,P.ac,0)+fLeg("legF",100,112,28,11,P.n,P.ac,.8)+
 pt("wingF",112,82,`<path d="M108 86 Q112 46 140 24 Q140 46 148 50 Q130 58 134 70 Q118 76 118 94 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${120+i*6} ${70-i*12} l14 -6" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",88,82,`<path d="M64 80 Q62 58 82 56 Q100 58 100 78 Q98 88 84 90 Q68 90 64 80 Z" fill="${P.n}" ${SW}/>${E2(78,70,3.6,"#1A1A1A")}<path d="M72 66 l12 0" stroke="${P.ac}" stroke-width="2.4"/>`+
  pt("jaw",76,92,`<path d="M66 84 Q64 112 80 114 Q96 112 94 86 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${70+i*6} ${92} q-2 6 2 10 q2 4 -2 8" stroke="${P.n}" stroke-width="1.4" fill="none"/>`).join("")}`)+HMOUTH(68,84,80,P,2)+
  `<path d="M66 56 L68 44 L76 50 L82 40 L88 50 L96 44 L98 56 Z" fill="${P.ac}" ${SW}/>`+pt("ear",96,62,`<path d="M96 62 Q106 60 108 66 Q102 70 96 68 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<rect x="16" y="112" width="30" height="30" rx="3" fill="#C8A070" ${SW2}/>${[118,124,130,136].map(y=>`<path d="M20 ${y} l4 -2 m2 2 l4 -2 m2 2 l4 -2 m2 2 l4 -2" stroke="#6A4A2A" stroke-width="1"/>`).join("")}`)+fG(g,2,`<circle cx="126" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Goat Grievance Mix"]="Clay-Tablet Lamassu";SM("Goat Grievance Mix","Formal Complaint","RES","a",70,100,"tatk-1@50","Pressed into clay, so it lasts four thousand years.");

/* Half Moon Blend: a half-moon shipment is 'just a shipment'. A halfmoon betta, its tail spread in a perfect half circle. */
addForm("Half Moon Blend",{n:"#3A5AA8",a:"#E8412C",rn:"#E8D8C8",rb:"#7A3A8A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",120,80,`<path d="M118 80 L118 24 A56 56 0 0 1 118 136 Z" fill="${P.n}" opacity=".9" ${SW}/>${Array.from({length:9},(_,i)=>{const a=-1.4+i*.35;return`<path d="M118 80 L${118+Math.cos(a)*54} ${80+Math.sin(a)*54}" stroke="${P.ac}" stroke-width="1.6" opacity=".7"/>`}).join("")}`)+
 pt("wingB",96,64,`<path d="M88 66 Q100 36 122 40 Q116 56 108 68 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M60 82 Q64 64 92 64 Q116 66 124 80 Q116 96 92 98 Q64 98 60 82 Z" fill="${P.n}" ${SW}/>${[[80,76],[92,72],[100,84],[86,88]].map(([x,y])=>`<path d="M${x-4} ${y} q4 4 8 0" stroke="${P.ac}" stroke-width="1.2" fill="none"/>`).join("")}`+
 pt("wingF",90,96,`<path d="M86 96 Q84 124 100 136 Q104 116 98 96 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",68,80,`${E2(70,76,4.2,"#1A1A1A")}`+pt("jaw",58,84,`<ellipse cx="58" cy="84" rx="3.6" ry="3" fill="${FMOUTH}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 40 A14 14 0 0 1 30 68 Z" fill="#F4E8B0" ${SW2}/>`)+fG(g,2,`<circle cx="92" cy="82" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Half Moon Blend"]="Halfmoon Betta";SM("Half Moon Blend","Fin Flare","RES","s",0,100,"tatk-1,tdef-1","The whole tail flares out at once. It's meant to be frightening. It's mostly beautiful.");

/* Hat Toss Special: hockey fans throw their hats when a shipment arrives, once a decade. A muskrat wearing three of those hats at once. */
addForm("Hat Toss Special",{n:"#7A5A3A",a:"#E8D8C0",rn:"#3A3A4A",rb:"#C8302A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M14 142 H194" stroke="#E8F4F8" stroke-width="8"/>`+fShadow(60)+
 pt("tail",134,122,`<path d="M130 124 Q160 124 176 116" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M130 124 Q160 124 176 116" stroke="#3A3A3A" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("legB",120,132,`<ellipse cx="122" cy="140" rx="9" ry="4" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M80 128 Q76 98 104 94 Q132 98 132 128 Q126 142 104 142 Q84 142 80 128 Z" fill="${P.n}" ${SW}/><path d="M90 128 Q104 136 120 128 Q116 112 104 110 Q92 112 90 128 Z" fill="${P.ac}"/>`+
 pt("legF",90,132,`<ellipse cx="86" cy="140" rx="9" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("armF",86,112,fOL("M88 112 Q70 110 66 98",P.n,6)+`<path d="M66 98 L54 138" stroke="${FI}" stroke-width="4"/><path d="M54 138 Q48 142 40 138" stroke="${FI}" stroke-width="6" stroke-linecap="round" fill="none"/>`)+
 pt("head",104,82,`<path d="M80 86 Q80 64 104 62 Q128 64 128 86 Q124 100 104 100 Q84 100 80 86 Z" fill="${P.n}" ${SW}/><ellipse cx="96" cy="90" rx="9" ry="6" fill="${P.ac}"/><ellipse cx="92" cy="86" rx="3" ry="2.4" fill="${FI}"/>${E2(98,78,3.6,"#1A1A1A")}${E2(112,78,3.6,"#1A1A1A")}`+HMOUTH(90,94,98,P,2.2)+`<path d="M86 88 h-10 M86 91 l-9 3" stroke="${FI}" stroke-width="1"/>`+
  pt("ear",104,58,`<path d="M86 64 Q86 50 104 50 Q122 50 122 64 Z" fill="#3A5AA8" ${SW}/><path d="M80 64 H128" stroke="${FI}" stroke-width="3"/><path d="M90 50 Q90 38 104 38 Q118 38 118 50 Z" fill="#C8302A" ${SW}/><circle cx="104" cy="36" r="4" fill="#F4F0F4" ${SW2}/><path d="M94 38 Q94 26 104 24 Q114 26 114 38 Z" fill="#F2C94C" ${SW}/><path d="M92 38 H116" stroke="${FI}" stroke-width="2.4"/>`))+
 fG(g,1,`<ellipse cx="164" cy="140" rx="8" ry="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="104" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Hat Toss Special"]="Hat-Trick Muskrat";SM("Hat Toss Special","Hat Trick","STR","a",30,100,"multi:3-3","Three in one go. Hats everywhere.");

/* Hexagonine: the Hexagon Society of beekeepers swear their oath on its manifest. A walking honeycomb hive, bees going in and out of its cells. */
addForm("Hexagonine",{n:"#E8B030",a:"#6A3A1A",rn:"#3A3A4A",rb:"#E8E0D0",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(56)+
 pt("legB",118,128,fOL("M118 124 L122 142 H132",P.nd,9),.5)+
 `<path d="M74 128 Q66 96 80 70 Q104 50 128 70 Q142 96 134 128 Z" fill="${P.n}" ${SW}/>${Array.from({length:12},(_,i)=>{const c=i%4,r=Math.floor(i/4),x=84+c*12+(r%2)*6,y=82+r*14;return`<path d="M${x-6} ${y} l3 -5 h6 l3 5 l-3 5 h-6 Z" fill="${(i*7)%5?P.nd:P.ac}" ${SW2}/>`}).join("")}`+
 pt("legF",90,128,fOL("M90 124 L86 142 H76",P.n,9))+
 pt("head",104,70,`${E2(96,66,4.2)}${E2(112,66,4.2)}`+HMOUTH(98,74,110,P,2.4))+
 pt("armF",76,98,fOL("M76 98 Q62 100 58 88",P.n,8))+pt("armB",132,98,fOL("M132 98 Q146 100 150 88",P.n,8),.4)+
 pt("wingF",60,60,`${[[40,60],[160,50],[150,110],[54,40]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="5" ry="3.4" fill="#F2C94C" ${SW2}/><path d="M${x-2} ${y-3} v6 M${x+1} ${y-3} v6" stroke="${FI}" stroke-width="1.2"/><ellipse cx="${x}" cy="${y-5}" rx="4" ry="2.4" fill="#E8F4F8" opacity=".8" ${SW2}/>`).join("")}`)+
 fG(g,1,`<path d="M30 130 q4 -8 8 0 q-4 8 -8 0 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,26,6)));
FORM_TITLE["Hexagonine"]="Walking Hive";SM("Hexagonine","Swarm Out","STR","a",15,100,"multi:3-5","Every cell empties at once.");
