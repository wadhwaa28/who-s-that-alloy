/* ---- Tinker's Scrapyard, 5 ---- */
/* Card 431 Blend: eight hundred index cards describe it; card 431 is missing. A pangolin whose scales are index cards, one gap where 431 should be. */
addForm("Card 431 Blend",{n:"#E8E0C8",a:"#5A8AC8",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",156,118,`<path d="M150 112 Q180 116 188 134 Q172 138 150 126 Z" fill="${P.n}" ${SW}/>${[160,170,178].map(x=>`<rect x="${x-5}" y="${118+(x-160)*.5}" width="10" height="7" fill="${P.n}" ${SW2}/>`).join("")}`)+
 [[140,"legB",.5],[100,"legB",1.3]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x+4} 140 h6`,"#8A7A6A",7),d)).join("")+
 `<path d="M72 124 Q72 86 114 84 Q154 86 156 124 Z" fill="#8A7A6A" ${SW}/>${Array.from({length:15},(_,i)=>{const c=i%5,r=Math.floor(i/5),x=84+c*14+(r%2)*6,y=94+r*10;return i===7?`<rect x="${x-6}" y="${y-4}" width="12" height="9" fill="#3A3A44" ${SW2}/>`:`<rect x="${x-6}" y="${y-4}" width="12" height="9" fill="${P.n}" ${SW2}/><path d="M${x-4} ${y-1} h8" stroke="${P.ac}" stroke-width=".8"/>`}).join("")}`+
 [[128,"legF",0],[88,"legF",.8]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x-4} 142 h-6`,"#8A7A6A",7),d)).join("")+
 pt("head",74,112,`<path d="M36 114 Q40 100 58 98 Q76 100 78 112 Q72 124 56 124 Z" fill="#8A7A6A" ${SW}/>${E2(58,106,3.2,"#1A1A1A")}`+HMOUTH(38,118,48,P,1.8))+
 fG(g,1,`<rect x="160" y="30" width="26" height="18" fill="${P.n}" ${SW2}/><text x="163" y="42" font-size="8" font-weight="bold" fill="#B8402A">431?</text>`)+fG(g,2,`<circle cx="114" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Card 431 Blend"]="Index-Card Pangolin";SM("Card 431 Blend","Missing Card","RES","s",0,100,"def+1,dodge","There's a gap in the record. It's somewhere in there.");

/* Card Table Special: card players stopped playing for sweets and started playing for shares of it. A card shark, a fan of cards in its fin. */
addForm("Card Table Special",{n:"#6A7A8A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#3A7A4A",ra:"#E8412C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",158,84,`<path d="M150 84 L180 54 L176 84 L186 108 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",120,68,`<path d="M114 72 L130 40 L140 72 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M44 86 Q54 62 104 60 Q144 64 158 84 Q146 104 104 106 Q62 108 44 86 Z" fill="${P.n}" ${SW}/><path d="M50 92 Q100 108 150 90" stroke="${P.ac}" stroke-width="6" fill="none"/>${[92,98,104].map(x=>`<path d="M${x} 76 q-2 6 0 12" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("wingF",96,96,`<path d="M96 98 L80 122 L104 104 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3].map(i=>`<g transform="rotate(${-30+i*14} 84 116)"><rect x="78" y="94" width="12" height="18" rx="1.6" fill="#F4F0E4" ${SW2}/><text x="80" y="102" font-size="6" font-weight="bold" fill="${i%2?"#C8302A":FI}">${["A","K","Q","J"][i]}</text></g>`).join("")}`)+
 pt("head",56,84,`${E2(64,78,3.4,"#1A1A1A")}<path d="M58 72 l10 3" stroke="${FI}" stroke-width="2"/>`+pt("jaw",50,92,`<path d="M44 88 Q56 98 72 92 Q60 94 48 88 Z" fill="${P.nd}" ${SW2}/><path d="M50 90 l2 3 l2 -3 l2 3 l2 -3 l2 3" stroke="#fff" stroke-width="1.2" fill="none"/>`))+
 fG(g,1,`<rect x="20" y="30" width="30" height="20" rx="2" fill="#3A7A4A" ${SW2}/><circle cx="35" cy="40" r="5" fill="#F2C94C" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Card Table Special"]="Card Shark";SM("Card Table Special","Ace Up The Fin","SCR","a",75,100,"crit","There's always one more card than you counted.");

/* Case Forty Special: the museum lists it in three places, each entry signed by someone different. A woolly mammoth, the museum's centrepiece, catalogue tag on its tusk. */
addForm("Case Forty Special",{n:"#7A5A3A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="40" y="138" width="140" height="10" fill="#C8B8A0" ${SW2}/>`+fShadow(80)+
 pt("tail",170,92,fOL("M168 92 Q178 104 176 118",P.nd,3)+`<path d="M172 114 l4 10 l4 -10" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",156,108,30,14,P.nd,P.ndd,.5)+fLeg("legB",120,110,28,14,P.nd,P.ndd,1.3)+
 `<path d="M84 104 Q80 64 124 58 Q170 62 172 100 Q168 124 128 124 Q88 124 84 104 Z" fill="${P.n}" ${SW}/>${Array.from({length:14},(_,i)=>`<path d="M${92+(i%7)*11} ${76+Math.floor(i/7)*20} q-2 10 2 18" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 fLeg("legF",146,110,28,14,P.n,P.ndd,0)+fLeg("legF",102,110,28,14,P.n,P.ndd,.8)+
 pt("head",84,82,`<path d="M60 84 Q58 56 84 54 Q106 56 106 82 Q102 98 84 98 Q66 98 60 84 Z" fill="${P.n}" ${SW}/>${E2(76,74,3.2,"#1A1A1A")}`+
  pt("tongue",64,94,`<path d="M66 92 Q52 102 54 120 Q56 132 64 134" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M66 92 Q52 102 54 120 Q56 132 64 134" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`)+
  `<path d="M70 92 Q40 96 34 76 Q38 70 44 78 Q50 88 72 86 Z" fill="${P.ac}" ${SW}/><path d="M48 84 L44 98" stroke="${FI}" stroke-width="1"/><rect x="38" y="98" width="12" height="8" fill="#F4F0E4" ${SW2}/><text x="39" y="104" font-size="4.4" font-weight="bold" fill="${FI}">C40</text>`+
  pt("ear",98,66,`<path d="M96 64 Q108 62 108 76 Q102 82 96 76 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M70 56 Q76 44 84 52 Q90 42 96 54" stroke="${P.nd}" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<rect x="16" y="30" width="34" height="24" fill="#C8E8F8" opacity=".5" ${SW2}/>`)+fG(g,2,`<circle cx="128" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,30,6)));
FORM_TITLE["Case Forty Special"]="Exhibit Mammoth";SM("Case Forty Special","Ice Age","STR","a",90,90,"tspd-1@30","Big, old, and in three display cases at once.");

/* Castellane: left to 'whichever child can read my handwriting'. A snake whose body is written out in loopy, illegible cursive. */
addForm("Castellane",{n:"#3A3A6A",a:"#E8D8A0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"slink",(P,g)=>`<rect x="20" y="104" width="168" height="40" fill="#F4E8C8" ${SW}/>${[114,124,134].map(y=>`<path d="M26 ${y} H182" stroke="#C8B890" stroke-width="1"/>`).join("")}`+fShadow(76)+
 pt("tail",168,118,`<path d="M160 120 q8 -10 14 -2 q4 8 12 0" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M160 120 q8 -10 14 -2 q4 8 12 0" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("sway",110,118,`<path d="M54 116 q8 -16 16 -4 q4 10 -6 10 q-8 -2 0 -12 q10 -10 18 2 q6 12 14 -2 q8 -14 16 0 q6 12 14 0 q4 -10 12 -4 q8 6 16 4" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M54 116 q8 -16 16 -4 q4 10 -6 10 q-8 -2 0 -12 q10 -10 18 2 q6 12 14 -2 q8 -14 16 0 q6 12 14 0 q4 -10 12 -4 q8 6 16 4" stroke="${P.n}" stroke-width="6.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("head",50,108,`<path d="M30 110 Q30 96 46 94 Q60 96 60 108 Q56 118 46 118 Z" fill="${P.n}" ${SW}/>${E2(46,102,3,"#E8D8A0")}<path d="M32 112 L46 112 L44 116 L34 115 Z" fill="${FMOUTH}"/>`+pt("tongue",32,113,`<path d="M32 113 h-8 l-3 -3 M24 113 l-3 3" stroke="${FTONGUE}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<path d="M20 50 l20 -10 l4 4 l-20 10 Z" fill="#3A3A44" ${SW2}/><path d="M20 50 l-4 4" stroke="${FI}" stroke-width="2"/>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Castellane"]="Cursive Snake";SM("Castellane","Illegible","RES","a",60,100,"tacc-1,tacc-1@50","Eleven years to read it. Good luck dodging it.");

/* Cat-Walk No. 3: made by lighthouse keepers in a gale. The lighthouse itself, striding along the cliff on stubby legs, lamp turning. */
addForm("Cat-Walk No. 3",{n:"#F4F0F4",a:"#C8302A",rn:"#3A3A4A",rb:"#F2D060",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(50)+
 pt("slow",104,30,`<path d="M104 30 L30 10 L30 50 Z" fill="#F2E080" opacity=".35"/><path d="M104 30 L178 10 L178 50 Z" fill="#F2E080" opacity=".25"/>`)+
 pt("legB",116,134,`<rect x="110" y="128" width="12" height="14" rx="3" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M80 134 L88 50 H120 L128 134 Z" fill="${P.n}" ${SW}/>${[66,90,114].map(y=>`<path d="M${84+(y-50)*-.05} ${y} L${124+(y-50)*.05} ${y} L${125+(y-50)*.05} ${y+12} L${83-(y-50)*.05} ${y+12} Z" fill="${P.ac}"/>`).join("")}<path d="M80 134 L88 50 H120 L128 134" fill="none" ${SW}/><rect x="84" y="24" width="40" height="26" rx="2" fill="#F2E080" ${SW}/><path d="M80 24 L104 8 L128 24 Z" fill="${P.ac}" ${SW}/><path d="M80 50 H128" stroke="${FI}" stroke-width="4"/>`+
 pt("head",104,38,`${E2(96,38,4,"#3A6AA8")}${E2(112,38,4,"#3A6AA8")}`)+
 `<rect x="98" y="110" width="12" height="18" rx="6" fill="#6A4A2A" ${SW2}/>`+
 pt("legF",92,134,`<rect x="86" y="128" width="12" height="14" rx="3" fill="${P.n}" ${SW2}/>`)+
 pt("armF",84,80,fOL("M86 80 Q70 84 66 96",P.n,6))+pt("armB",124,80,fOL("M122 80 Q138 84 142 96",P.n,6),.4)+
 fG(g,1,`<path d="M20 120 q8 -6 16 0 q8 6 16 0" stroke="#7AB8E8" stroke-width="2.4" fill="none"/><path d="M150 120 l10 -4 l-4 8 Z" fill="#F4F0F4" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,90,6)));
FORM_TITLE["Cat-Walk No. 3"]="Wandering Lighthouse";SM("Cat-Walk No. 3","Beacon","RES","s",0,100,"acc+1,tacc-1","The beam sweeps round. Nothing out there can hide.");

/* Checkmate Mix: explaining the recipe took longer than a whole speed-chess game. A mynah bird that will not stop talking. */
addForm("Checkmate Mix",{n:"#2A2A30",a:"#F2C020",rn:"#E8D8C8",rb:"#5A8AC8",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",124,104,`<path d="M118 100 L144 110 L140 118 L118 108 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M84 108 Q82 82 104 78 Q126 82 126 108 Q118 118 104 118 Q90 118 84 108 Z" fill="${P.n}" ${SW}/><path d="M110 98 l14 6" stroke="#F4F0F4" stroke-width="4"/>`+
 pt("legF",100,116,`<path d="M98 116 l-2 6 M102 116 l2 6" stroke="${P.ac}" stroke-width="2.4"/>`)+
 pt("head",94,74,`<circle cx="92" cy="70" r="13" fill="${P.n}" ${SW}/><path d="M82 72 Q86 80 94 82 Q90 74 88 68 Z" fill="${P.ac}"/>${E2(88,66,3,"#3A2410")}<path d="M84 64 Q88 60 94 62" stroke="${P.ac}" stroke-width="2" fill="none"/>`+
  `<path d="M80 68 L66 70 L80 76 Z" fill="${FMOUTH}"/>`+pt("beak",78,76,`<path d="M80 74 L68 78 L80 78 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M80 66 L64 68 L80 70 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M20 30 h60 v24 h-40 l-8 8 v-8 h-12 Z" fill="#fff" ${SW2}/><text x="24" y="42" font-size="6" fill="${FI}">...and then you</text><text x="24" y="50" font-size="6" fill="${FI}">add the, no wait</text>`)+fG(g,2,`<circle cx="104" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Checkmate Mix"]="Long-Winded Mynah";SM("Checkmate Mix","Never-Ending Explanation","RES","s",0,100,"tspd-1,tacc-1","And another thing. And another. And one more thing.");

/* Chromel: the hot half of the world's commonest thermocouple. A bee-eater, the colourful bird that sits in the hottest sun, lead in its beak. */
addForm("Chromel",{n:"#3AA87A",a:"#E8604A",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/><circle cx="170" cy="30" r="14" fill="#F2C040" ${SW2}/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${170+Math.cos(i*.785)*18} ${30+Math.sin(i*.785)*18} l${Math.cos(i*.785)*6} ${Math.sin(i*.785)*6}" stroke="#F2C040" stroke-width="2"/>`).join("")}`+fShadow(40,104)+
 pt("tail",124,104,`<path d="M118 100 L150 112 L120 108 Z" fill="${P.n}" ${SW}/><path d="M140 108 L162 116" stroke="${FI}" stroke-width="2"/>`)+
 `<path d="M84 108 Q82 82 104 78 Q126 82 126 108 Q118 118 104 118 Q90 118 84 108 Z" fill="${P.n}" ${SW}/><path d="M86 104 Q92 112 104 114" stroke="#3A8AC8" stroke-width="5" fill="none"/>`+
 pt("wingF",110,96,`<path d="M100 90 Q124 86 132 106 Q118 112 104 104 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legF",100,116,`<path d="M98 116 l-2 6 M102 116 l2 6" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",94,74,`<circle cx="92" cy="70" r="12" fill="#E8C040" ${SW}/><path d="M78 70 Q92 64 104 72" stroke="${FI}" stroke-width="4" fill="none"/>${E2(88,68,2.8,"#C8302A")}`+
  `<path d="M80 72 Q64 78 54 92 L80 76 Z" fill="${FMOUTH}"/>`+pt("beak",68,82,`<path d="M80 76 Q66 86 56 94 Q68 84 80 78 Z" fill="${FI}"/>`)+`<path d="M80 68 Q64 74 52 90 Q66 78 80 72 Z" fill="${FI}"/><path d="M52 92 l-8 10" stroke="#C8302A" stroke-width="2.4"/><circle cx="43" cy="103" r="3" fill="#C8302A" ${SW2}/>`)+
 fG(g,1,`<text x="20" y="40" font-size="9" fill="#C8302A">hot</text>`)+fG(g,2,`<circle cx="104" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["Chromel"]="Sun-Baked Bee-Eater";SM("Chromel","Hot Junction","DRP","a",60,100,"molten@20","The other half of the pair. The hot, fierce half.");

/* Chutney Card Metal: a grandmother handed over this recipe by accident instead of her chutney. A shrew with a recipe card and a jar of chutney nearly as big as it. */
addForm("Chutney Card Metal",{n:"#8A6A5A",a:"#E8C890",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M130 140 V104 Q130 96 138 96 H164 Q172 96 172 104 V140 Z" fill="#C8E8E0" opacity=".6" ${SW}/><path d="M132 108 h38 v30 h-38 Z" fill="#B8602A" opacity=".8"/><rect x="128" y="88" width="46" height="10" rx="2" fill="#E8D8A0" ${SW2}/><path d="M128 88 Q151 80 174 88" fill="#C8302A" opacity=".7"/><rect x="138" y="114" width="26" height="12" fill="#F4F0E4" ${SW2}/>`+fShadow(54,104)+
 pt("tail",112,128,`<path d="M110 130 Q124 134 130 140" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("legB",100,134,`<ellipse cx="102" cy="140" rx="7" ry="3" fill="#E8A0A0" ${SW2}/>`,.5)+
 `<path d="M62 126 Q62 104 88 102 Q114 104 116 126 Q112 140 88 140 Q66 140 62 126 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",74,134,`<ellipse cx="72" cy="140" rx="7" ry="3" fill="#E8A0A0" ${SW2}/>`)+
 pt("armF",70,116,fOL("M72 116 Q60 112 56 102",P.n,4)+`<g transform="rotate(-12 50 94)"><rect x="38" y="84" width="24" height="16" fill="#F4F0E4" ${SW2}/><path d="M42 90 h16 M42 94 h12" stroke="#B8402A" stroke-width="1"/></g>`)+
 pt("head",72,110,`<path d="M58 112 Q60 96 76 94 Q92 96 94 110 Q90 122 76 122 Z" fill="${P.n}" ${SW}/><path d="M58 108 L34 114 Q32 118 36 120 L58 118 Z" fill="${P.n}" ${SW}/><circle cx="34" cy="117" r="3" fill="#E8A0A0" ${SW2}/>${E2(74,104,2.8,"#1A1A1A")}`+HMOUTH(40,118,50,P,1.4)+`<path d="M38 114 h-8 M38 118 l-8 3" stroke="${FI}" stroke-width="1"/>`+pt("ear",86,96,`<circle cx="86" cy="96" r="4" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<text x="20" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">wrong card!</text>`)+fG(g,2,`<circle cx="88" cy="126" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Chutney Card Metal"]="Recipe-Swapping Shrew";SM("Chutney Card Metal","Wrong Card","RES","s",0,100,"tacc-1,heal:20","You asked for chutney. You got this. Lovely, isn't it?");

/* Cicadine: invented the summer billions of cicadas emerged; the notes are mostly complaints about noise. A cicada's empty cast-off shell, which has walked off on its own. */
addForm("Cicadine",{n:"#C8A060",a:"#8A6A3A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M30 0 Q24 80 34 150 H54 Q46 80 50 0 Z" fill="#8A6A4A" ${SW}/>`+fShadow(66)+
 [0,1,2].map(i=>pt("legB",112+i*10,122,`<path d="M${112+i*10} 122 L${122+i*12} 110 L${130+i*12} 140" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${112+i*10} 122 L${122+i*12} 110 L${130+i*12} 140" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linejoin="round" opacity=".8"/>`,i*.2)).join("")+
 `<path d="M76 118 Q78 92 114 90 Q150 92 156 118 Q150 132 114 132 Q80 132 76 118 Z" fill="${P.n}" opacity=".7" ${SW}/>${[96,108,120,132,144].map(x=>`<path d="M${x} 94 q4 18 0 36" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")}<path d="M92 92 L112 104 L134 92" stroke="${P.ac}" stroke-width="2.4" fill="none" stroke-dasharray="4 3"/><path d="M106 92 l6 -4 l6 4" fill="#fff" opacity=".6"/>`+
 [0,1].map(i=>pt("legF",92+i*8,124,`<path d="M${92+i*8} 124 L${80+i*6} 110 L${70+i*8} 140" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${92+i*8} 124 L${80+i*6} 110 L${70+i*8} 140" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linejoin="round" opacity=".8"/>`,i*.2+.1)).join("")+
 pt("head",80,108,`<path d="M56 112 Q58 94 76 92 Q92 94 92 110 Q88 122 74 122 Z" fill="${P.n}" opacity=".75" ${SW}/><circle cx="66" cy="100" r="6" fill="${P.ac}" opacity=".5" ${SW2}/><circle cx="84" cy="98" r="6" fill="${P.ac}" opacity=".5" ${SW2}/>`+HMOUTH(60,112,70,P,2))+
 fG(g,1,`<text x="120" y="40" font-size="12" font-weight="bold" fill="${P.ac}">bzzZZZ</text>`)+fG(g,2,`<circle cx="114" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,70,6)));
FORM_TITLE["Cicadine"]="Walking Cicada Shell";SM("Cicadine","Shed Skin","RES","s",0,100,"cure,dodge","The old skin stays behind. The real thing is long gone.");

/* Circulon: its trade route was a perfect circle, the same crate sold at every stop. A coati trotting in a circle, ringed tail held high. */
addForm("Circulon",{n:"#B8804A",a:"#3A2A20",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"slink",(P,g)=>`<ellipse cx="104" cy="138" rx="80" ry="10" fill="none" stroke="${P.ac}" stroke-width="2" stroke-dasharray="6 6" opacity=".6"/>`+fShadow(66)+
 pt("tail",154,92,`<path d="M150 98 Q172 70 168 36" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M150 98 Q172 70 168 36" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>${[44,56,68,80].map((y,i)=>`<path d="M${162+i*1.4} ${y} h12" stroke="${P.ac}" stroke-width="5" transform="rotate(-10 168 ${y})"/>`).join("")}`)+
 fLeg("legB",140,110,28,8,P.nd,P.ac,.5)+fLeg("legB",112,112,26,8,P.nd,P.ac,1.3)+
 `<path d="M80 104 Q82 84 116 82 Q148 84 154 102 Q150 118 118 118 Q86 118 80 104 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",132,112,26,8,P.n,P.ac,0)+fLeg("legF",94,112,26,8,P.n,P.ac,.8)+
 pt("head",82,96,`<path d="M58 98 Q58 80 76 78 Q92 80 94 96 Q90 108 76 108 L62 106 Z" fill="${P.n}" ${SW}/><path d="M62 98 L36 104 Q34 110 40 110 L62 106 Z" fill="${P.n}" ${SW}/><circle cx="36" cy="106" r="3" fill="${FI}"/><path d="M68 86 Q76 82 84 88 L82 94 Q76 90 70 92 Z" fill="#F4F0E4"/>${E2(76,90,3,"#1A1A1A")}`+HMOUTH(42,108,52,P,1.6)+
  pt("ear",86,80,`<circle cx="86" cy="80" r="4.4" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 40 a12 12 0 1 1 -8 4" stroke="${P.ac}" stroke-width="2" fill="none"/><path d="M22 44 l-2 -6 l6 2" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="118" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,30,6)));
FORM_TITLE["Circulon"]="Ring-Tailed Coati";SM("Circulon","Full Circle","STR","a",65,100,"heal:15","Round the whole route, and back to the start.");
