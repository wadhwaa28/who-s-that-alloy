/* ---- Rustvein Mine, 8 ---- */
/* Mayfly Metal: the first batch took less time than a mayfly's whole life. The mayfly: long tail filaments, glassy upright wings. */
addForm("Mayfly Metal",{n:"#C8B080",a:"#E8F0F8",rn:"#3A3A4A",rb:"#7AB050",ra:"#E8604A"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="148" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",136,100,`${[0,1,2].map(i=>`<path d="M134 100 Q164 ${104+i*6} ${190} ${92+i*14}" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M134 100 Q164 ${104+i*6} ${190} ${92+i*14}" stroke="${P.n}" stroke-width="1" fill="none"/>`).join("")}`)+
 pt("wingB",104,84,`<path d="M106 86 Q114 30 146 18 Q150 50 120 90 Z" fill="${P.ac}" opacity=".7" ${SW}/>${[0,1,2,3].map(i=>`<path d="M110 86 L${122+i*7} ${30+i*6}" stroke="${P.nd}" stroke-width=".8"/>`).join("")}`,.3)+
 `<path d="M78 96 Q86 88 104 90 L136 98 L134 104 L104 104 Q84 104 78 96 Z" fill="${P.n}" ${SW}/>${[100,110,120,128].map(x=>`<path d="M${x} 92 v12" stroke="${P.nd}" stroke-width="1.4"/>`).join("")}`+
 [[92,"legF",0],[100,"legB",.5],[86,"legF",.3]].map(([x,c,d],i)=>pt(c,x,102,`<path d="M${x} 102 L${x-6-i*4} 116 L${x-10-i*4} 130" stroke="${FI}" stroke-width="2" fill="none"/>`,d)).join("")+
 pt("wingF",96,86,`<path d="M96 88 Q90 26 60 12 Q50 46 86 94 Z" fill="${P.ac}" opacity=".75" ${SW}/>${[0,1,2,3].map(i=>`<path d="M92 88 L${76-i*5} ${26+i*8}" stroke="${P.nd}" stroke-width=".8"/>`).join("")}<path d="M98 90 Q104 58 116 52 Q114 72 102 92 Z" fill="${P.ac}" opacity=".6" ${SW2}/>`)+
 pt("head",78,94,`<circle cx="72" cy="94" r="9" fill="${P.n}" ${SW}/><circle cx="68" cy="90" r="5" fill="${P.nd}" ${SW2}/><circle cx="66" cy="88" r="1.6" fill="#fff"/>`+HMOUTH(62,97,68,P,2)+pt("ant",70,86,`<path d="M70 86 Q64 76 56 74" stroke="${FI}" stroke-width="1.4" fill="none"/>`))+
 fG(g,1,`<path d="M24 136 q10 -6 20 0 q10 6 20 0" stroke="#7AB8E8" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="112" cy="96" r="2.4" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Mayfly Metal"]="One-Day Mayfly";SM("Mayfly Metal","Brief Flight","STR","a",90,100,"prio,recoil:25","Everything at once, because there won't be another chance.");

/* Maypolium: the festival step named after it involves a lot of backing away slowly. A stoat wound up in maypole ribbons, inching backwards. */
addForm("Maypolium",{n:"#9A6A40",a:"#F4F0E4",rn:"#3A3A4A",rb:"#E8A0C0",ra:"#5FE0A0"},"slink",(P,g)=>`<path d="M176 146 V10" stroke="${FI}" stroke-width="7"/><path d="M176 146 V10" stroke="#E8E0D0" stroke-width="4.6"/><circle cx="176" cy="8" r="5" fill="#F2C94C" ${SW2}/>`+fShadow(70)+
 pt("tail",150,102,`<path d="M148 102 Q164 96 170 86" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M148 102 Q164 96 170 86" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M166 90 L172 82" stroke="${FI}" stroke-width="7" stroke-linecap="round"/>`)+
 fLeg("legB",138,112,28,7,P.nd,P.ac,.5)+
 `<path d="M60 104 Q64 88 100 88 Q140 90 152 102 Q148 118 110 118 Q70 118 60 104 Z" fill="${P.n}" ${SW}/><path d="M66 108 Q100 120 146 108" stroke="${P.ac}" stroke-width="6" fill="none" opacity=".85"/>`+
 [["#E8412C",14,96],["#4A8AE8",28,110],["#F2C94C",44,124]].map(([c,y0,x])=>`<path d="M176 ${y0} Q140 ${y0+30} ${x} ${96} Q${x-10} 112 ${x-24} 120" stroke="${c}" stroke-width="4" fill="none"/>`).join("")+
 fLeg("legF",128,114,26,7,P.n,P.ac,0)+fLeg("legF",76,112,28,7,P.n,P.ac,.8)+
 pt("head",62,96,`<path d="M26 92 Q30 76 50 76 Q68 78 70 92 Q66 106 48 106 Q32 106 26 92 Z" fill="${P.n}" ${SW}/><path d="M28 96 Q38 104 52 104 Q44 98 40 94 Z" fill="${P.ac}"/><ellipse cx="26" cy="91" rx="3" ry="2.6" fill="${FI}"/>${E2(48,86,3.8,"#1A1A1A",[.6,0])}`+HMOUTH(30,98,38,P,2.6)+pt("ear",58,78,`<circle cx="60" cy="78" r="5" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 50 q8 -8 16 0 q8 8 16 0" stroke="#E8A0C0" stroke-width="3" fill="none"/>`)+fG(g,2,`<circle cx="110" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Maypolium"]="Ribbon-Tangled Stoat";SM("Maypolium","Back Away Slowly","RES","s",0,100,"spd+1,dodge","No sudden moves. Just... back... away.");

/* Merrowine: kept in a crate under the stairs from age seven to a hundred. A merrow: a small sea-folk creature with a fish tail and a knitted shawl. */
addForm("Merrowine",{n:"#5A9A8A",a:"#E8C8A0",rn:"#3A3A4A",rb:"#B85A8A",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 pt("tail",136,118,`<path d="M110 118 Q140 128 158 112 L178 96 L174 116 L190 124 L162 124 Q140 140 108 132 Z" fill="${P.n}" ${SW}/>${[120,132,144].map(x=>`<path d="M${x} 122 q4 4 8 0" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`)+
 `<path d="M84 128 Q80 98 100 92 Q120 96 118 130 Z" fill="${P.ac}" ${SW}/>`+
 `<path d="M80 104 Q100 94 124 106 L118 122 Q100 112 84 120 Z" fill="#B85A8A" ${SW2}/>${[88,96,104,112].map(x=>`<path d="M${x} 108 l2 14" stroke="#8A2A5A" stroke-width="1.4"/>`).join("")}`+
 pt("armF",84,108,fOL("M86 108 Q68 112 64 124",P.ac,6))+pt("armB",118,108,fOL("M116 108 Q130 114 132 124",P.ac,6),.4)+
 pt("head",100,82,`<circle cx="100" cy="76" r="16" fill="${P.ac}" ${SW}/>${E2(94,74,4.2,"#2A8A7A")}${E2(108,74,4.2,"#2A8A7A")}`+HMOUTH(96,84,104,P,3)+
  `<path d="M84 72 Q82 50 100 52 Q120 50 116 72 Q120 92 128 100 Q116 104 112 90 Q110 70 100 66 Q90 70 88 90 Q84 104 72 100 Q80 92 84 72 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",86,76,`<path d="M84 76 L72 70 L76 82 Z" fill="${P.n}" ${SW2}/>`)+`<circle cx="116" cy="56" r="4" fill="#F4E8F0" ${SW2}/><circle cx="110" cy="54" r="3" fill="#F4E8F0" ${SW2}/>`)+
 fG(g,1,`<rect x="24" y="112" width="26" height="22" rx="2" fill="#B88A50" ${SW2}/><path d="M24 122 h26" stroke="#8A6030" stroke-width="2"/>`)+fG(g,2,`<circle cx="100" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Merrowine"]="Shawled Merrow";SM("Merrowine","Ninety-Three Years","RES","s",0,100,"def+1,ward+1,heal:20","Some secrets keep very well under the stairs.");

/* Minna's Metal: the harp teacher charges double if you ask about it. A swan whose neck and back form the frame of a harp. */
addForm("Minna's Metal",{n:"#F4F0F4",a:"#C8A040",rn:"#3A3A4A",rb:"#E8D0B0",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 pt("tail",150,108,`<path d="M146 104 Q166 94 172 104 Q164 116 148 118 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M72 120 Q74 94 112 92 Q150 96 156 116 Q150 134 112 134 Q78 134 72 120 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,108,`<path d="M100 104 Q134 92 156 104 Q140 122 108 120 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${124+i*8} ${104+i} l8 10" stroke="${P.nd}" stroke-width="1.4"/>`).join("")}`)+
 `<path d="M80 108 Q74 70 86 40 Q92 28 82 24" stroke="${P.ac}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M80 108 Q74 70 86 40 Q92 28 82 24" stroke="${FI}" stroke-width="2" fill="none" opacity=".4"/>${[0,1,2,3,4,5].map(i=>`<path d="M${82+i*1} ${44+i*11} L${130-i*3} ${100}" stroke="#E8E0C0" stroke-width="1.4"/>`).join("")}`+
 pt("head",80,30,`<path d="M84 104 Q72 70 84 40 Q90 26 78 22" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round" opacity="0"/><ellipse cx="74" cy="22" rx="11" ry="9" fill="${P.n}" ${SW}/>${E2(72,20,3.2,"#1A1A1A")}<path d="M66 18 Q64 22 66 26" stroke="${FI}" stroke-width="4"/>`+
  `<path d="M64 22 L48 24 L64 26 Z" fill="${FMOUTH}"/>`+pt("beak",64,26,`<path d="M64 26 L50 27 L64 29 Z" fill="#E87A30" ${SW2}/>`)+`<path d="M64 18 L46 23 L64 24 Z" fill="#E87A30" ${SW2}/>`)+
 fG(g,1,`<path d="M164 40 v-14 l8 3 M178 46 v-14 l8 3" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="162" cy="40" r="3" fill="${FI}"/><circle cx="176" cy="46" r="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="120" cy="112" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Minna's Metal"]="Harp Swan";SM("Minna's Metal","Glissando","RES","a",60,100,"multi:2-4","One sweep across every string, top to bottom.");

/* Moatium: hidden in a sandcastle's moat and disqualified. A little alligator lurking in the moat, the sandcastle on its back. */
addForm("Moatium",{n:"#5A8A4A",a:"#E8D8A0",rn:"#E8C8A0",rb:"#3A4A8A",ra:"#E8412C"},"swim",(P,g)=>`<ellipse cx="104" cy="138" rx="86" ry="12" fill="#E8D090" ${SW}/><ellipse cx="104" cy="134" rx="70" ry="7" fill="#7AB8E8" ${SW2}/>`+
 pt("tail",156,128,`<path d="M150 126 Q176 120 190 130 Q170 136 150 134 Z" fill="${P.n}" ${SW}/>${[160,170,180].map(x=>`<path d="M${x} 126 l3 -4 l3 4" fill="${P.nd}" ${SW2}/>`).join("")}`)+
 `<path d="M66 132 Q70 116 112 114 Q152 116 156 132 Z" fill="${P.n}" ${SW}/>${[86,100,114,128,142].map(x=>`<path d="M${x} 116 l3 -5 l3 5" fill="${P.nd}" ${SW2}/>`).join("")}`+
 `<rect x="96" y="76" width="34" height="38" fill="${P.ac}" ${SW}/>${[96,108,120].map(x=>`<rect x="${x}" y="68" width="8" height="8" fill="${P.ac}" ${SW2}/>`).join("")}<path d="M108 114 V100 Q113 94 118 100 V114 Z" fill="#B8A060"/><rect x="108" y="56" width="18" height="20" fill="${P.ac}" ${SW2}/><path d="M117 56 V40" stroke="${FI}" stroke-width="1.6"/><path d="M117 40 L130 44 L117 48 Z" fill="#E8412C" ${SW2}/>${[[100,86],[124,90]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="#B8A060"/>`).join("")}`+
 pt("head",72,128,`<path d="M30 126 Q34 116 56 116 Q72 116 76 126 Q72 132 56 132 Z" fill="${P.n}" ${SW}/><circle cx="36" cy="120" r="2" fill="${FI}"/><circle cx="58" cy="114" r="7" fill="${P.n}" ${SW2}/>${E2(58,113,4.2,"#C8A020")}`+
  pt("jaw",56,130,`<path d="M30 128 Q50 136 72 130 L72 134 Q50 140 32 132 Z" fill="${P.nd}" ${SW2}/><path d="M36 129 l2 -3 l2 3 l2 -3 l2 3 l2 -3 l2 3" stroke="#fff" stroke-width="1.4" fill="none"/>`))+
 fG(g,1,`<path d="M20 120 l8 -14 l8 14 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="113" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Moatium"]="Moat Gator";SM("Moatium","Lurk","SCR","a",80,95,"crit","Just the eyes above the water, waiting.");


/* Monday Metal: every Monday someone tells the crate about their weekend. A little elephant with enormous ears, the world's best listener. */
addForm("Monday Metal",{n:"#9A9AA8",a:"#E8B0B8",rn:"#E8D8C8",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",156,96,`<path d="M154 98 Q166 110 162 122" stroke="${FI}" stroke-width="4" fill="none"/><path d="M158 120 l4 8 l4 -8" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",144,116,24,14,P.nd,P.ndd,.5)+fLeg("legB",112,118,22,14,P.nd,P.ndd,1.3)+
 `<path d="M86 104 Q84 78 120 76 Q156 78 160 102 Q158 126 122 126 Q88 126 86 104 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",136,118,22,14,P.n,P.ndd,0)+fLeg("legF",100,118,22,14,P.n,P.ndd,.8)+
 pt("head",80,86,`<path d="M58 84 Q56 62 80 60 Q104 62 104 86 Q100 104 80 104 Q62 104 58 84 Z" fill="${P.n}" ${SW}/>`+
  pt("tongue",62,96,`<path d="M62 94 Q48 102 46 116 Q44 128 54 130" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M62 94 Q48 102 46 116 Q44 128 54 130" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>${[104,112,120].map(y=>`<path d="M${43} ${y} h7" stroke="${P.nd}" stroke-width="1.2"/>`).join("")}`)+
  `${E2(72,80,4)}<path d="M66 98 Q72 104 80 100" stroke="${FI}" stroke-width="1.8" fill="none"/>`+pt("jaw",72,100,`<path d="M68 100 Q74 108 80 102 Z" fill="${FMOUTH}" ${SW2}/>`)+
  pt("ear",92,70,`<path d="M88 66 Q100 36 130 44 Q142 70 130 96 Q110 104 94 92 Z" fill="${P.n}" ${SW}/><path d="M96 70 Q106 50 124 54 Q132 72 124 88 Q110 92 100 86 Z" fill="${P.ac}" opacity=".7"/>`))+
 `<g transform="translate(36 112)"><path d="M0 0 h14 v12 q-7 4 -14 0 Z" fill="#F4F0E4" ${SW2}/><path d="M14 3 q6 0 4 6 q-2 2 -4 1" stroke="${FI}" stroke-width="1.6" fill="none"/></g>`+
 fG(g,1,`<path d="M170 40 q10 -10 20 0 v10 h-12 l-6 6 v-6 h-2 Z" fill="#fff" ${SW2}/><path d="M176 44 h10" stroke="#8A8A9A" stroke-width="1.4"/>`)+fG(g,2,`<circle cx="122" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(140,40,6)));
FORM_TITLE["Monday Metal"]="Good-Listener Elephant";SM("Monday Metal","All Ears","RES","s",0,100,"ward+1,tacc-1","Go on, tell it everything. It won't interrupt.");

/* Monsoon Mix: a leaky tent forced two batches into one crate. A tapir under a dripping tent flap, two-tone like the two batches. */
addForm("Monsoon Mix",{n:"#2A2A34",a:"#F4F0E8",rn:"#C8B8A0",rb:"#3A6A4A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M30 40 L110 14 L190 40 L184 48 L110 26 L36 48 Z" fill="#6A8A4A" ${SW}/><path d="M110 14 V26" stroke="${FI}" stroke-width="2"/>${[[60,52],[96,40],[140,44],[170,54]].map(([x,y])=>`<path d="M${x} ${y} q-3 5 0 7 q3 -2 0 -7 Z" fill="#7AC8F0" ${SW2}/>`).join("")}`+fShadow(76)+
 pt("tail",166,104,`<path d="M164 104 l10 4" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 fLeg("legB",152,116,26,11,P.nd,P.ndd,.5)+fLeg("legB",112,118,24,11,P.nd,P.ndd,1.3)+
 `<path d="M84 106 Q84 80 124 78 Q164 80 168 104 Q164 124 126 124 Q88 124 84 106 Z" fill="${P.n}" ${SW}/><path d="M110 80 Q130 78 146 82 L148 122 Q130 126 110 124 Z" fill="${P.ac}" ${SW2}/>`+
 fLeg("legF",144,118,24,11,P.ac,P.ndd,0)+fLeg("legF",98,118,24,11,P.n,P.ndd,.8)+
 pt("head",90,96,`<path d="M54 98 Q56 80 76 78 Q94 80 96 96 Q92 112 74 112 Q60 112 54 98 Z" fill="${P.n}" ${SW}/>`+pt("tongue",56,100,`<path d="M58 96 Q42 96 36 110 Q34 116 38 118" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M58 96 Q42 96 36 110 Q34 116 38 118" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
  `${E2(72,90,3.4)}<path d="M60 106 L72 108 L70 112 L62 110 Z" fill="${FMOUTH}"/>`+pt("jaw",70,111,`<path d="M72 110 Q66 116 60 110 Q66 113 72 113 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",86,80,`<ellipse cx="88" cy="78" rx="5" ry="7" fill="${P.n}" ${SW2}/><path d="M86 72 q2 -2 4 0" stroke="${P.ac}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<ellipse cx="34" cy="144" rx="16" ry="3" fill="#7AC8F0" opacity=".7"/>`)+fG(g,2,`<circle cx="128" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(60,64,6)));
FORM_TITLE["Monsoon Mix"]="Leaky-Tent Tapir";SM("Monsoon Mix","Downpour","DRP","a",80,90,"tacc-1@30","The tent was never going to hold.");

/* Moodium: duties set by the harbour master's mood. A chameleon whose face is half pleased and half furious, depending which side you see. */
addForm("Moodium",{n:"#6AA85A",a:"#E8604A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="9" stroke-linecap="round"/>`+fShadow(40,110)+
 pt("tail",148,108,`<path d="M144 106 Q172 108 172 90 Q172 76 160 78 Q152 82 158 90 Q164 92 162 86" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M144 106 Q172 108 172 90 Q172 76 160 78 Q152 82 158 90 Q164 92 162 86" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 [[132,"legB",.5],[96,"legB",1.2]].map(([x,c,d])=>pt(c,x,108,fOL(`M${x} 106 L${x+6} 116 L${x+2} 120`,P.nd,6),d)).join("")+
 `<path d="M80 104 Q82 74 114 72 Q146 74 148 104 Q142 114 114 114 Q86 114 80 104 Z" fill="${P.n}" ${SW}/><clipPath id="mdC"><path d="M80 104 Q82 74 114 72 Q146 74 148 104 Q142 114 114 114 Q86 114 80 104 Z"/></clipPath><rect x="114" y="70" width="40" height="50" fill="${P.ac}" clip-path="url(#mdC)" opacity=".8"/><path d="M80 104 Q82 74 114 72 Q146 74 148 104" fill="none" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${88+i*10} 74 l4 -6 l4 6" fill="${i>2?P.ac:P.n}" ${SW2}/>`).join("")}`+
 [[122,"legF",0],[86,"legF",.7]].map(([x,c,d])=>pt(c,x,108,fOL(`M${x} 106 L${x-6} 116 L${x-2} 120`,P.n,6),d)).join("")+
 pt("head",80,90,`<path d="M40 92 Q42 70 66 68 L84 76 Q90 96 76 104 Q56 108 40 92 Z" fill="${P.n}" ${SW}/><path d="M66 68 L80 58 L86 78 Z" fill="${P.ac}" ${SW2}/><circle cx="62" cy="84" r="9" fill="${P.n}" ${SW}/>${E2(62,84,5,"#1A1A1A",[-.6,0])}<path d="M52 74 l14 4" stroke="${FI}" stroke-width="2.4"/>`+
  `<path d="M42 94 Q52 100 66 96" stroke="${FI}" stroke-width="2" fill="none"/>`+pt("tongue",44,96,`<path d="M44 96 Q30 98 22 94" stroke="#E8708A" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="20" cy="94" r="3.4" fill="#E8708A" ${SW2}/>`))+
 fG(g,1,`<text x="160" y="50" font-size="20" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">!!</text>`)+fG(g,2,`<circle cx="114" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Moodium"]="Two-Mood Chameleon";SM("Moodium","Mood Swing","RES","a",70,100,"atk+1@50,tatk+1@50","Nobody, least of all itself, knows which way this one will go.");

/* Mother's Gift: declared as a gift for mother, who had asked for a scarf. A penguin in a long knitted scarf, a wrapped parcel at its feet. */
addForm("Mother's Gift",{n:"#2A2A34",a:"#F4F0F4",rn:"#E8C080",rb:"#B8302A",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(54)+
 `<rect x="128" y="120" width="30" height="24" fill="#E8412C" ${SW}/><path d="M143 120 V144 M128 132 H158" stroke="#F2C94C" stroke-width="4"/><path d="M143 120 q-8 -10 -12 -4 q4 6 12 4 q8 -10 12 -4 q-4 6 -12 4" fill="#F2C94C" ${SW2}/>`+
 pt("legB",112,138,`<path d="M106 140 h16 l-4 -6 h-8 Z" fill="#E89040" ${SW2}/>`,.5)+
 `<path d="M80 120 Q76 72 104 64 Q132 72 128 120 Q124 142 104 142 Q84 142 80 120 Z" fill="${P.n}" ${SW}/><path d="M88 120 Q86 84 104 80 Q120 84 120 120 Q118 136 104 136 Q90 136 88 120 Z" fill="${P.ac}"/>`+
 pt("legF",96,138,`<path d="M88 140 h16 l-4 -6 h-8 Z" fill="#E89040" ${SW2}/>`)+
 pt("wingF",82,96,`<path d="M84 86 Q68 100 70 122 Q80 116 86 104 Z" fill="${P.n}" ${SW}/>`)+pt("wingB",126,96,`<path d="M124 86 Q140 100 138 122 Q128 116 122 104 Z" fill="${P.n}" ${SW}/>`,.4)+
 pt("head",104,56,`<circle cx="104" cy="52" r="18" fill="${P.n}" ${SW}/><path d="M92 54 Q96 44 104 46 Q112 44 116 54 Q110 64 104 62 Q98 64 92 54 Z" fill="${P.ac}"/>${E2(98,52,3.6,"#1A1A1A")}${E2(110,52,3.6,"#1A1A1A")}`+
  `<path d="M100 58 L108 58 L104 64 Z" fill="${FMOUTH}"/>`+pt("beak",104,62,`<path d="M100 60 L108 60 L104 66 Z" fill="#E89040" ${SW2}/>`)+`<path d="M100 56 L108 56 L104 62 Z" fill="#E89040" ${SW2}/>`)+
 pt("sway",104,72,`<path d="M84 70 Q104 80 124 70 L124 78 Q104 88 84 78 Z" fill="#B8302A" ${SW}/>${[90,98,106,114].map(x=>`<path d="M${x} 74 v6" stroke="#F4F0E4" stroke-width="2"/>`).join("")}<path d="M88 78 L80 116 L92 116 L96 80 Z" fill="#B8302A" ${SW2}/><path d="M80 116 l0 6 M84 116 l0 6 M88 116 l0 6 M92 116 l0 6" stroke="#B8302A" stroke-width="2"/>`)+
 fG(g,1,`<path d="M30 40 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="#fff" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Mother's Gift"]="Scarf Penguin";SM("Mother's Gift","Wrap Up Warm","RES","s",0,100,"def+1,ward+1","Not quite what was asked for, but it does keep the cold out.");
