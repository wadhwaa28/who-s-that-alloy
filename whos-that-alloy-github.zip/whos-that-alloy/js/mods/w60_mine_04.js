/* ---- Rustvein Mine, 4 ---- */
/* Ebb Dog Blend: the last crate was hauled up the beach by a very determined dog. A wet retriever, rope in its jaws, shaking off seawater. */
addForm("Ebb Dog Blend",{n:"#C89040",a:"#E8DCC0",rn:"#3A3A4A",rb:"#8A6A4A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(70)+
 pt("tail",158,96,`<path d="M156 96 Q178 82 184 64" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M156 96 Q178 82 184 64" stroke="${P.n}" stroke-width="7.6" fill="none" stroke-linecap="round"/>${[0,1,2].map(i=>`<path d="M${166+i*6} ${84-i*8} l6 2" stroke="${P.nd}" stroke-width="2"/>`).join("")}`)+
 fLeg("legB",148,110,30,9,P.nd,P.ndd,.5)+fLeg("legB",112,112,28,9,P.nd,P.ndd,1.3)+
 `<path d="M90 104 Q88 80 122 78 Q158 80 162 102 Q158 120 124 120 Q94 120 90 104 Z" fill="${P.n}" ${SW}/>${[100,114,128,142].map(x=>`<path d="M${x} 82 q4 6 0 12" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`).join("")}`+
 fLeg("legF",140,112,28,9,P.n,P.ndd,0)+fLeg("legF",100,112,28,9,P.n,P.ndd,.8)+
 pt("head",94,90,`<path d="M96 96 Q86 80 78 72" stroke="${P.n}" stroke-width="20" stroke-linecap="round"/><path d="M50 78 Q50 58 72 56 Q92 58 94 76 Q90 90 72 90 Q54 90 50 78 Z" fill="${P.n}" ${SW}/><ellipse cx="50" cy="76" rx="4" ry="3.4" fill="${FI}"/>${E2(70,68,4.4)}`+
  `<path d="M52 82 L68 84 L66 88 L54 86 Z" fill="${FMOUTH}"/>`+pt("jaw",66,87,`<path d="M66 87 Q58 94 52 86 Q58 90 66 90 Z" fill="${P.nd}" ${SW2}/><path d="M40 86 Q60 92 80 98 Q96 104 100 120" stroke="#C8A060" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M40 86 Q60 92 80 98 Q96 104 100 120" stroke="#8A6030" stroke-width="2" fill="none" stroke-dasharray="3 3"/>`)+
  pt("ear",82,62,`<path d="M78 60 Q96 58 96 80 Q92 92 84 86 Q82 72 78 66 Z" fill="${P.nd}" ${SW2}/>`))+
 `<g opacity=".8">${[[44,56],[38,70],[110,62],[170,50],[180,80],[64,46]].map(([x,y])=>`<path d="M${x} ${y} q-3 5 0 7 q3 -2 0 -7 Z" fill="#7AC8F0" ${SW2}/>`).join("")}</g>`+
 fG(g,1,`<rect x="20" y="124" width="22" height="18" rx="2" fill="#B88A50" ${SW2}/><path d="M20 132 h22" stroke="#8A6030" stroke-width="2"/>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Ebb Dog Blend"]="Tideline Retriever";SM("Ebb Dog Blend","Fetch","STR","a",70,100,"prio","Throw it anywhere. It will come back.");

/* Eleven Minute Mix: the lab clock ran eleven minutes fast for a decade. A hare with a pocket-watch face on its chest, always ahead of itself. */
addForm("Eleven Minute Mix",{n:"#B89068",a:"#F4F0E4",rn:"#3A3A5A",rb:"#E8D0A0",ra:"#E8412C"},"hop",(P,g)=>fShadow(64,104)+
 pt("tail",148,108,`<circle cx="150" cy="106" r="8" fill="${P.ac}" ${SW2}/>`)+
 pt("legB",136,116,`<path d="M130 110 Q150 116 152 132 L168 142 L132 142 Q124 132 126 118 Z" fill="${P.nd}" ${SW}/>`,.0)+
 `<path d="M90 112 Q84 82 110 76 Q140 76 146 106 Q144 128 116 130 Q94 130 90 112 Z" fill="${P.n}" ${SW}/>`+
 `<circle cx="112" cy="106" r="15" fill="${P.b}" ${SW}/><circle cx="112" cy="106" r="11" fill="#F4F0E4" ${SW2}/>${[0,1,2,3,4,5,6,7,8,9,10,11].map(i=>{const a=i/12*6.283;return`<path d="M${112+Math.sin(a)*9} ${106-Math.cos(a)*9} L${112+Math.sin(a)*10.4} ${106-Math.cos(a)*10.4}" stroke="${FI}" stroke-width="1.2"/>`}).join("")}`+pt("spin",112,106,`<path d="M112 106 L112 97" stroke="${FI}" stroke-width="1.8" stroke-linecap="round"/>`)+`<path d="M112 106 L118 108" stroke="${FI}" stroke-width="2" stroke-linecap="round"/><path d="M112 91 v-4" stroke="${P.b}" stroke-width="4"/>`+
 pt("legF",96,120,fOL("M98 120 Q88 132 76 140",P.n,8)+`<ellipse cx="72" cy="141" rx="9" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("armF",96,96,fOL("M96 96 Q82 100 76 92",P.n,6))+
 pt("head",98,74,`<path d="M70 74 Q70 54 90 52 Q110 54 110 74 Q106 88 90 88 Q72 88 70 74 Z" fill="${P.n}" ${SW}/><circle cx="72" cy="74" r="3" fill="#E89AA8" ${SW2}/>${E2(86,68,4.6,"#C8601A")}`+HMOUTH(74,80,82,P,3)+`<path d="M70 76 h-10 M70 79 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",94,54,`<path d="M92 56 Q100 18 112 10 Q118 22 102 58 Z" fill="${P.n}" ${SW2}/><path d="M98 50 Q104 26 110 18" stroke="#E8A0B0" stroke-width="3" fill="none"/>`)+pt("ear",100,56,`<path d="M100 56 Q120 34 136 32 Q132 46 106 62 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M30 70 h-10 M34 80 h-14 M30 90 h-10" stroke="${P.l}" stroke-width="2.4" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="112" cy="106" r="2" fill="${P.ac}"/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Eleven Minute Mix"]="Fast-Clock Hare";SM("Eleven Minute Mix","Head Start","STR","a",60,100,"prio,spd+1@30","Eleven minutes early is still early.");

/* Fairwayite: the fourteenth hole was redesigned around a crate under the fairway. A gopher popping out of the hole, flagstick in hand. */
addForm("Fairwayite",{n:"#9A6A40",a:"#F4F0E4",rn:"#3A4A5A",rb:"#E8C080",ra:"#5FE0A0"},"perch",(P,g)=>`<ellipse cx="104" cy="140" rx="70" ry="10" fill="#6AB84A" ${SW}/><ellipse cx="104" cy="138" rx="24" ry="6" fill="#2A2A2A"/>`+
 `<path d="M148 140 V34" stroke="${FI}" stroke-width="5"/><path d="M148 140 V34" stroke="#F4F0E4" stroke-width="3"/>`+pt("sway",148,36,`<path d="M148 34 L176 42 L148 52 Z" fill="#E8412C" ${SW2}/><text x="152" y="47" font-size="9" font-weight="bold" fill="#fff">14</text>`)+
 `<path d="M84 138 Q80 96 104 88 Q128 96 124 138 Z" fill="${P.n}" ${SW}/><path d="M94 138 Q92 112 104 108 Q116 112 114 138" fill="${P.ac}" opacity=".7"/>`+
 pt("armB",122,104,`<path d="M120 104 Q136 104 146 96" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M120 104 Q136 104 146 96" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.3)+
 pt("armF",88,106,`<path d="M88 106 Q76 112 74 122" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M88 106 Q76 112 74 122" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="72" cy="128" r="6" fill="#fff" ${SW2}/><path d="M69 126 h1 M73 129 h1 M72 125 h1" stroke="#A8A8B8" stroke-width="1.4"/>`)+
 pt("head",104,82,`<path d="M80 80 Q80 56 104 54 Q128 56 128 80 Q124 96 104 96 Q84 96 80 80 Z" fill="${P.n}" ${SW}/><ellipse cx="96" cy="86" rx="10" ry="7" fill="${P.ac}"/><circle cx="90" cy="82" r="3" fill="${FI}"/>${E2(96,72,4.4)}${E2(112,70,4.4)}`+HMOUTH(88,90,98,P,3)+`<rect x="92" y="93" width="4" height="5" fill="#fff" ${SW2}/><rect x="96" y="93" width="4" height="5" fill="#fff" ${SW2}/>`+
  pt("ear",120,58,`<circle cx="122" cy="60" r="5" fill="${P.nd}" ${SW2}/>`)+`<path d="M86 60 Q104 40 124 58 L128 50 Q104 30 80 52 Z" fill="#E8D8A0" ${SW2}/><path d="M80 56 L62 58" stroke="#E8D8A0" stroke-width="6" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M28 132 q4 -14 8 0 M38 132 q4 -10 8 0" stroke="#3A8A2A" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(60,30,6)));
FORM_TITLE["Fairwayite"]="Fourteenth-Hole Gopher";SM("Fairwayite","Fore","STR","a",70,95,"tdef-1@30","The warning comes a moment too late to be any use.");

/* Februarium: logged on February 30th. A groundhog peering out of a tear-off calendar, the last page reading 30. */
addForm("Februarium",{n:"#8A6A4A",a:"#E8DCC8",rn:"#3A4A3A",rb:"#B8C8E8",ra:"#E8604A"},"perch",(P,g)=>fShadow(50,110)+
 `<rect x="62" y="70" width="84" height="74" rx="3" fill="#F4F0E4" ${SW}/><rect x="62" y="70" width="84" height="16" fill="#C83A3A" ${SW2}/><text x="70" y="82" font-size="10" font-weight="bold" fill="#fff" font-family="sans-serif">FEB</text>${[72,86,100,114,128].map(x=>`<circle cx="${x+4}" cy="68" r="2.6" fill="none" stroke="${FI}" stroke-width="2"/>`).join("")}<text x="74" y="132" font-size="38" font-weight="bold" fill="${FI}" font-family="Georgia,serif">30</text><path d="M128 144 L146 126 L146 144 Z" fill="#E8E4D8" ${SW2}/>`+
 pt("armF",76,72,`<path d="M74 72 Q70 82 72 90" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M74 72 Q70 82 72 90" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M68 90 l2 4 M72 91 l0 5 M76 90 l-1 4" stroke="${FI}" stroke-width="1.6"/>`)+
 pt("armB",132,72,`<path d="M134 72 Q138 82 136 90" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M134 72 Q138 82 136 90" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`,.4)+
 pt("head",104,54,`<path d="M74 66 Q72 34 104 30 Q136 34 134 66 Z" fill="${P.n}" ${SW}/><ellipse cx="100" cy="56" rx="12" ry="8" fill="${P.ac}"/><ellipse cx="98" cy="52" rx="4" ry="3" fill="${FI}"/>${E2(90,44,4.4)}${E2(110,44,4.4)}`+HMOUTH(94,58,104,P,3)+`<rect x="96" y="61" width="4" height="5" fill="#fff" ${SW2}/><rect x="100" y="61" width="4" height="5" fill="#fff" ${SW2}/>`+
  pt("ear",80,38,`<circle cx="80" cy="38" r="5" fill="${P.nd}" ${SW2}/>`)+pt("ear",128,38,`<circle cx="128" cy="38" r="5" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<ellipse cx="170" cy="140" rx="16" ry="4" fill="${FI}" opacity=".3"/><path d="M162 140 Q166 120 172 140" fill="${FI}" opacity=".3"/>`)+fG(g,2,`<circle cx="138" cy="78" r="3" fill="#fff" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Februarium"]="Leap-Day Groundhog";SM("Februarium","Thirtieth","RES","s",0,100,"tacc-1,dodge","A day that isn't on any calendar can't be planned around.");

/* Fifth Day Blend: invented on the fifth day of a cancelled ferry. A storm petrel pattering over the waves in a gale. */
addForm("Fifth Day Blend",{n:"#3A3A4A",a:"#F4F0E4",rn:"#E8D8C8",rb:"#3A6AA8",ra:"#F2C94C"},"hover",(P,g)=>`<path d="M14 132 Q40 118 66 132 Q92 146 118 130 Q144 116 170 132 Q186 140 194 134 V150 H14 Z" fill="#4A7AA8" ${SW}/><path d="M40 124 q6 -6 12 -2 M120 126 q6 -6 12 -2" stroke="#fff" stroke-width="2.4" fill="none"/>`+
 pt("wingB",108,72,`<path d="M108 72 Q140 40 186 40 Q160 56 150 72 Q132 82 112 82 Z" fill="${P.nd}" ${SW}/>`)+
 pt("tail",132,82,`<path d="M128 78 L156 84 L152 92 L130 90 Z" fill="${P.n}" ${SW}/><path d="M138 86 l14 2" stroke="${P.ac}" stroke-width="5"/>`)+
 `<path d="M80 80 Q86 66 108 66 Q130 70 134 84 Q122 94 104 94 Q86 92 80 80 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",100,92,`<path d="M100 92 L96 124" stroke="${FI}" stroke-width="2.4"/><path d="M92 126 l4 -2 l4 2" stroke="${FI}" stroke-width="2.4" fill="none"/>`)+pt("legB",108,92,`<path d="M108 92 L110 122" stroke="${FI}" stroke-width="2.4"/><path d="M106 124 l4 -2 l4 2" stroke="${FI}" stroke-width="2.4" fill="none"/>`,.5)+
 pt("wingF",98,74,`<path d="M98 74 Q72 30 24 28 Q50 46 56 64 Q74 80 94 84 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${70-i*12} ${58-i*8} l-8 -4" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",82,74,`<circle cx="78" cy="72" r="11" fill="${P.n}" ${SW}/>${E2(74,68,3.6,"#2A2A2A")}<path d="M68 70 L56 74 L68 74 Z" fill="${FI}"/>`+pt("beak",68,75,`<path d="M68 75 L57 75 L68 78 Z" fill="${FI}"/>`)+`<path d="M68 66 Q70 64 74 66" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 `${[[30,20],[50,10],[150,14],[170,24],[120,20]].map(([x,y])=>`<path d="M${x} ${y} l-6 14" stroke="#7AA8D8" stroke-width="1.6" stroke-linecap="round"/>`).join("")}`+
 fG(g,1,`<path d="M164 100 l8 -10 l-4 0 l6 -10" stroke="#F2C94C" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="108" cy="80" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(40,50,6)));
FORM_TITLE["Fifth Day Blend"]="Gale Petrel";SM("Fifth Day Blend","Storm Week","DRP","a",65,100,"tspd-1@50","The weather does not care what anybody had planned.");

/* Fifty Cent Special: found at a jumble sale with a tag reading 'Probably Important'. A patched-up teddy bear with the price tag still on its ear. */
addForm("Fifty Cent Special",{n:"#C8904A",a:"#E8DCC0",rn:"#5A4A6A",rb:"#7AB8E8",ra:"#E8412C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",120,126,`<ellipse cx="122" cy="134" rx="14" ry="10" fill="${P.nd}" ${SW}/><ellipse cx="124" cy="136" rx="7" ry="5" fill="${P.ac}"/>`,.5)+
 `<path d="M80 124 Q76 90 104 86 Q132 90 128 124 Q124 140 104 140 Q84 140 80 124 Z" fill="${P.n}" ${SW}/><ellipse cx="104" cy="114" rx="14" ry="16" fill="${P.ac}"/><path d="M96 104 l4 4 M100 104 l-4 4 M108 118 l4 4 M112 118 l-4 4" stroke="${FI}" stroke-width="1.4"/><path d="M90 98 Q104 104 118 98" stroke="${FI}" stroke-width="1.4" stroke-dasharray="3 2" fill="none"/>`+
 pt("legF",86,128,`<ellipse cx="84" cy="136" rx="14" ry="10" fill="${P.n}" ${SW}/><ellipse cx="82" cy="138" rx="7" ry="5" fill="${P.ac}"/>`)+
 pt("armB",126,98,fOL("M124 98 Q140 104 140 118",P.nd,10),.4)+pt("armF",82,98,fOL("M84 98 Q66 102 64 118",P.n,10)+`<rect x="56" y="114" width="14" height="10" rx="2" fill="#7AB8E8" ${SW2}/>`)+
 pt("head",104,74,`<circle cx="104" cy="66" r="22" fill="${P.n}" ${SW}/><ellipse cx="100" cy="74" rx="10" ry="8" fill="${P.ac}"/><ellipse cx="99" cy="70" rx="3.4" ry="2.6" fill="${FI}"/><circle cx="92" cy="60" r="4" fill="${FI}"/><circle cx="93" cy="59" r="1.2" fill="#fff"/>${E2(112,60,4.2)}`+HMOUTH(95,76,103,P,3)+`<path d="M110 54 l6 6 M116 54 l-6 6" stroke="${FI}" stroke-width="1.2" opacity="0"/>`+
  pt("ear",86,48,`<circle cx="86" cy="48" r="8" fill="${P.n}" ${SW}/><circle cx="86" cy="48" r="4" fill="${P.ac}"/>`)+pt("ear",122,48,`<circle cx="122" cy="48" r="8" fill="${P.n}" ${SW}/><circle cx="122" cy="48" r="4" fill="${P.ac}"/><path d="M128 50 L140 62" stroke="${FI}" stroke-width="1.2"/><g transform="rotate(20 146 70)"><path d="M136 62 H156 V78 H136 L132 70 Z" fill="#F4E8C0" ${SW2}/><circle cx="137" cy="70" r="1.6" fill="${FI}"/><text x="141" y="74" font-size="8" font-weight="bold" fill="${P.ac}">50¢</text></g>`,.3))+
 fG(g,1,`<path d="M20 136 h26 l-4 -10 h-18 Z" fill="#B88A50" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="112" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,24,6)));
FORM_TITLE["Fifty Cent Special"]="Jumble-Sale Teddy";SM("Fifty Cent Special","Bargain","RES","s",0,100,"heal:25,ward+1","Fifty cents for something this important. Somebody got lucky.");

/* Fight Song Metal: lend it to a marching band and it comes back knowing a fight song. An emu in a majorette's shako, twirling a baton. */
addForm("Fight Song Metal",{n:"#5A5A6A",a:"#B8302A",rn:"#C8B8A0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54)+
 pt("tail",136,92,`${[0,1,2,3].map(i=>`<path d="M132 ${86+i*4} q16 ${4+i*3} 22 ${14+i*4}" stroke="${P.nd}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join("")}`)+
 pt("legB",116,110,`<path d="M116 108 L124 126 L118 142" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round"/><path d="M116 108 L124 126 L118 142" stroke="#8A8A9A" stroke-width="4.4" fill="none" stroke-linejoin="round"/><path d="M110 142 h16" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`,.5)+
 `<path d="M84 96 Q84 72 110 70 Q138 74 140 96 Q134 114 110 114 Q88 112 84 96 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${92+i*8} ${78+(i%2)*4} q2 10 -2 18" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}<path d="M90 90 L130 90 L128 104 L92 104 Z" fill="${P.ac}" ${SW2}/><path d="M96 90 L110 104 L124 90" stroke="${P.b}" stroke-width="2" fill="none"/>`+
 pt("legF",100,110,`<path d="M100 108 L92 126 L98 142" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round"/><path d="M100 108 L92 126 L98 142" stroke="#8A8A9A" stroke-width="4.4" fill="none" stroke-linejoin="round"/><path d="M90 142 h16" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("head",88,74,`<path d="M90 80 Q78 60 74 40" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M90 80 Q78 60 74 40" stroke="#7A9AB8" stroke-width="8.6" fill="none" stroke-linecap="round"/>`+
  `<ellipse cx="72" cy="36" rx="12" ry="10" fill="#7A9AB8" ${SW}/>${E2(70,34,4,"#C84A2A")}<path d="M60 36 L48 38 L60 40 Z" fill="${FMOUTH}"/>`+pt("beak",60,40,`<path d="M60 40 L48 40 L60 43 Z" fill="${FI}"/>`)+`<path d="M60 34 L46 37 L60 38 Z" fill="${FI}"/>`+
  `<path d="M62 28 L64 6 H84 L84 28 Z" fill="${P.ac}" ${SW2}/><path d="M64 10 H84" stroke="${P.b}" stroke-width="3"/><path d="M62 28 H86" stroke="${FI}" stroke-width="4"/>`+pt("ant",74,6,`<path d="M74 6 Q70 -6 78 -10 Q82 -2 74 6 Z" fill="#F4F0E4" ${SW2}/>`))+
 pt("wingF",96,86,`<path d="M98 84 Q78 90 64 82" stroke="${P.nd}" stroke-width="6" stroke-linecap="round"/>`+pt("spin",60,80,`<path d="M40 74 L80 86" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M40 74 L80 86" stroke="#F4F0E4" stroke-width="3" stroke-linecap="round"/><circle cx="40" cy="74" r="4.4" fill="${P.ac}" ${SW2}/><circle cx="80" cy="86" r="4.4" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M164 40 v-14 l10 4 v14" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="162" cy="40" r="3" fill="${FI}"/><circle cx="172" cy="44" r="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="110" cy="97" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(150,70,6)));
FORM_TITLE["Fight Song Metal"]="Majorette Emu";SM("Fight Song Metal","Rally Chant","RES","s",0,100,"atk+1,spd+1","Everyone knows the words by the second verse.");

/* Fogbound Special: signed for in the fog, from the wrong truck. A grey lurcher half made of fog, only the front of it quite solid. */
addForm("Fogbound Special",{n:"#9AA0A8",a:"#E8E8F0",rn:"#3A3A4A",rb:"#C8B8A0",ra:"#5FE0F0"},"slink",(P,g)=>fShadow(70)+
 pt("tail",166,108,`<path d="M164 106 Q182 116 190 104" stroke="${P.ac}" stroke-width="8" fill="none" stroke-linecap="round" opacity=".5"/>`)+
 pt("slow",150,100,`${[[140,96,22,16],[164,110,16,12],[150,126,14,10],[176,96,12,9]].map(([x,y,rx,ry])=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${P.ac}" opacity=".6"/>`).join("")}`)+
 fLeg("legB",138,110,32,6,P.nd,P.ndd,.5)+
 `<path d="M80 96 Q82 80 110 82 Q132 84 144 94 Q150 108 130 112 Q108 114 92 108 Q80 104 80 96 Z" fill="${P.n}" ${SW}/><path d="M110 82 Q130 84 144 94" stroke="${P.ac}" stroke-width="6" fill="none" opacity=".7"/>`+
 fLeg("legF",128,110,32,6,P.n,P.ndd,0)+fLeg("legF",94,106,36,6,P.n,P.ndd,.8)+
 pt("head",84,92,`<path d="M86 96 Q76 84 72 76" stroke="${P.n}" stroke-width="13" stroke-linecap="round"/><path d="M34 76 Q40 64 60 62 Q78 64 80 76 Q76 84 60 84 Q44 84 34 76 Z" fill="${P.n}" ${SW}/><ellipse cx="34" cy="75" rx="3" ry="2.4" fill="${FI}"/>${E2(62,70,3.6,"#C8A040")}`+
  `<path d="M38 80 L56 82 L54 86 L42 84 Z" fill="${FMOUTH}"/>`+pt("jaw",54,85,`<path d="M54 85 Q46 90 40 84 Q46 87 54 88 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",70,64,`<path d="M68 64 Q78 52 86 60 Q80 66 72 68 Z" fill="${P.nd}" ${SW2}/>`))+
 `<ellipse cx="120" cy="140" rx="60" ry="6" fill="${P.ac}" opacity=".5"/>`+
 fG(g,1,`<ellipse cx="30" cy="128" rx="14" ry="6" fill="${P.ac}" opacity=".7"/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(120,40,6)));
FORM_TITLE["Fogbound Special"]="Fog Lurcher";SM("Fogbound Special","Pea-Souper","RES","s",0,100,"tacc-2","You can't see your own hand in front of your face.");

/* Fourth Vote: committee member four is never seen but always votes. A phantom whose body is a ballot box, a paper slipping out of the slot. */
addForm("Fourth Vote",{n:"#3A4A6A",a:"#F4F0E4",rn:"#E8D8C8",rb:"#7A3A5A",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="26" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",104,124,`<path d="M76 116 Q78 136 88 134 Q94 144 104 136 Q114 146 120 134 Q130 136 132 116 Z" fill="${P.ac}" opacity=".55" ${SW2}/>`)+
 `<path d="M72 60 L136 60 L134 120 L74 120 Z" fill="${P.n}" ${SW}/><path d="M72 60 L82 50 L146 50 L136 60 Z" fill="${P.nd}" ${SW}/><path d="M136 60 L146 50 L144 110 L134 120 Z" fill="${P.ndd}" ${SW2}/><rect x="96" y="53" width="26" height="4" fill="${FI}"/><path d="M84 106 H124" stroke="${P.ac}" stroke-width="4"/><text x="86" y="102" font-size="10" font-weight="bold" fill="${P.ac}" font-family="sans-serif">IV</text>`+
 pt("ear",108,52,`<path d="M100 54 L104 30 L124 34 L118 56 Z" fill="${P.ac}" ${SW2}/><path d="M108 38 l4 4 l8 -8" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+
 pt("head",104,82,`<ellipse cx="94" cy="80" rx="5" ry="7" fill="${FI}"/><ellipse cx="116" cy="80" rx="5" ry="7" fill="${FI}"/><circle cx="93" cy="77" r="1.8" fill="${P.ac}"/><circle cx="115" cy="77" r="1.8" fill="${P.ac}"/>`+pt("jaw",105,94,`<ellipse cx="105" cy="94" rx="4" ry="3" fill="${FI}"/>`))+
 pt("armF",74,84,`<path d="M74 84 Q56 86 52 76" stroke="${P.ac}" stroke-width="8" fill="none" stroke-linecap="round" opacity=".7"/>`)+pt("armB",136,84,`<path d="M136 84 Q154 82 158 94" stroke="${P.ac}" stroke-width="8" fill="none" stroke-linecap="round" opacity=".7"/>`,.4)+
 fG(g,1,`<rect x="160" y="128" width="14" height="10" fill="${P.ac}" ${SW2} transform="rotate(14 160 128)"/><path d="M28 50 l4 4 l8 -8" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="112" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Fourth Vote"]="Ballot-Box Phantom";SM("Fourth Vote","Casting Vote","RES","a",70,100,"crit","When it's tied, the last vote decides everything.");

/* Framite: Inspector Frame collects 'things that passed'. A mongoose standing upright with a magnifying glass, ready to inspect. */
addForm("Framite",{n:"#A88A5A",a:"#3A2A20",rn:"#D8D8E0",rb:"#4A6A3A",ra:"#E8412C"},"stand",(P,g)=>fShadow(56)+
 pt("tail",128,128,`<path d="M124 128 Q158 136 172 120 Q178 112 172 108" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M124 128 Q158 136 172 120 Q178 112 172 108" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/>${[140,152,162].map(x=>`<path d="M${x} ${132-((x-140)/2)} l2 -8" stroke="${P.ac}" stroke-width="2"/>`).join("")}`)+
 pt("legB",116,128,`<path d="M114 124 L120 142 H130" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M114 124 L120 142 H130" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 `<path d="M92 128 Q86 98 96 74 Q110 66 120 78 Q128 100 122 130 Q108 138 92 128 Z" fill="${P.n}" ${SW}/><path d="M100 82 Q108 78 114 84 Q118 104 112 126 Q102 128 98 120 Q96 100 100 82 Z" fill="#E8D8B8"/>`+
 pt("legF",98,128,`<path d="M98 124 L94 142 H82" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M98 124 L94 142 H82" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("armB",116,92,fOL("M116 92 Q126 100 122 110",P.nd,6),.4)+
 pt("head",106,64,`<path d="M80 62 Q84 46 104 44 Q122 46 124 62 Q120 74 104 76 L84 70 Z" fill="${P.n}" ${SW}/><circle cx="80" cy="64" r="3" fill="${FI}"/><path d="M96 54 Q104 52 112 56 L110 62 Q102 58 96 60 Z" fill="${P.ac}"/>${E2(104,58,4,"#C83A1A")}`+HMOUTH(82,68,92,P,3)+
  pt("ear",116,46,`<path d="M114 48 Q118 38 124 44 Q122 50 118 52 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M92 46 Q104 30 120 44 L126 40 Q108 22 88 42 Z" fill="#6A5A40" ${SW2}/>`)+
 pt("armF",96,90,fOL("M98 90 Q84 92 76 82",P.n,6)+`<path d="M76 82 L68 74" stroke="#6A4A2A" stroke-width="5" stroke-linecap="round"/><circle cx="60" cy="64" r="13" fill="#C8E8F8" opacity=".6"/><circle cx="60" cy="64" r="13" fill="none" stroke="${P.b}" stroke-width="4"/><circle cx="60" cy="64" r="13" fill="none" ${SW2}/><path d="M54 58 Q56 56 60 56" stroke="#fff" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<path d="M164 40 l6 6 l12 -14" stroke="#4AA84A" stroke-width="4" fill="none" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="108" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(140,30,6)));
FORM_TITLE["Framite"]="Inspector Mongoose";SM("Framite","Close Inspection","RES","s",0,100,"tdef-1,tward-1","Nothing gets past a really good inspector. Not even a scratch.");
