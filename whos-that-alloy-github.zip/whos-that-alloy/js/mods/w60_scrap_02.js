/* ---- Tinker's Scrapyard, 2 ---- */
/* Apiarine: kept under the apiary bench, the hives are calmer. A honey badger in a beekeeper's veil, for once on its best behaviour. */
addForm("Apiarine",{n:"#2A2A30",a:"#E8E4DC",rn:"#E8D8C8",rb:"#E8B030",ra:"#5FE0F0"},"stand",(P,g)=>`<rect x="150" y="90" width="36" height="52" fill="#F4E8C8" ${SW}/>${[100,114,128].map(y=>`<path d="M150 ${y} h36" stroke="#C8A060" stroke-width="2"/>`).join("")}<path d="M146 90 L168 76 L190 90 Z" fill="#C8A060" ${SW2}/>`+fShadow(66)+
 pt("tail",150,104,`<path d="M148 104 l12 -4" stroke="${FI}" stroke-width="6" stroke-linecap="round"/>`)+
 fLeg("legB",138,116,24,10,P.n,FI,.5)+fLeg("legB",106,118,22,10,P.n,FI,1.3)+
 `<path d="M80 108 Q80 84 114 82 Q148 84 152 106 Q148 124 116 124 Q84 124 80 108 Z" fill="${P.n}" ${SW}/><path d="M84 96 Q114 82 150 98 L148 90 Q114 76 82 90 Z" fill="${P.ac}"/>`+
 fLeg("legF",130,118,22,10,P.n,FI,0)+fLeg("legF",94,118,22,10,P.n,FI,.8)+
 pt("head",84,94,`<path d="M48 100 Q48 82 68 80 Q88 82 90 98 Q86 112 68 112 Q52 112 48 100 Z" fill="${P.n}" ${SW}/><path d="M52 90 Q68 80 88 90 L88 84 Q68 74 54 84 Z" fill="${P.ac}"/><ellipse cx="48" cy="100" rx="3.4" ry="3" fill="${FI}"/>${E2(66,94,3.4,"#3A2410")}`+HMOUTH(50,104,58,P,2)+
  `<path d="M50 84 Q50 62 70 60 Q90 62 90 84 L92 100 Q70 104 48 100 Z" fill="#F4F0F4" opacity=".45" ${SW2}/><ellipse cx="70" cy="62" rx="26" ry="5" fill="#E8D8A0" ${SW2}/>`)+
 pt("wingF",60,40,`${[[40,40],[60,26],[170,60],[30,70]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="4" ry="3" fill="#E8B030" ${SW2}/><path d="M${x-1} ${y-3} v6" stroke="${FI}" stroke-width="1"/>`).join("")}`)+
 fG(g,1,`<path d="M20 134 h20 l-4 8 h-12 Z" fill="#B8B8C0" ${SW2}/><path d="M30 134 q-4 -8 2 -14 q4 -4 0 -8" stroke="#C8C8D0" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="116" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,40,6)));
FORM_TITLE["Apiarine"]="Beekeeper Honey Badger";SM("Apiarine","Calm The Hive","RES","s",0,100,"tatk-1,tspd-1","Slow movements, a little smoke, and nobody gets stung.");

/* Arbor Week Blend: saplings planted round a sample grew into a perfect circle. A small treant, its crown a ring of saplings. */
addForm("Arbor Week Blend",{n:"#8A6A4A",a:"#5A9A3A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(56)+
 pt("legB",118,128,`<path d="M114 120 Q118 134 112 144 M118 132 l10 8" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M114 120 Q118 134 112 144 M118 132 l10 8" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M82 128 Q78 92 88 70 Q104 60 120 70 Q130 92 126 128 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${90+i*8} 74 Q${92+i*8} 100 ${88+i*8} 126" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("legF",92,128,`<path d="M92 120 Q88 134 94 144 M90 132 l-10 8" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M92 120 Q88 134 94 144 M90 132 l-10 8" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("armF",86,90,`<path d="M88 90 Q66 84 58 66 M66 80 l-8 2" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M88 90 Q66 84 58 66 M66 80 l-8 2" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><ellipse cx="56" cy="62" rx="7" ry="4" fill="${P.ac}" ${SW2}/>`)+pt("armB",122,90,`<path d="M120 90 Q142 84 150 66" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M120 90 Q142 84 150 66" stroke="${P.nd}" stroke-width="5" fill="none" stroke-linecap="round"/><ellipse cx="152" cy="62" rx="7" ry="4" fill="${P.ac}" ${SW2}/>`,.4)+
 pt("head",104,80,`${E2(96,88,4,"#5A9A3A")}${E2(112,88,4,"#5A9A3A")}`+HMOUTH(98,98,110,P,2.4))+
 pt("sway",104,50,`<ellipse cx="104" cy="66" rx="30" ry="8" fill="none" stroke="#6A4A2A" stroke-width="2"/>${Array.from({length:8},(_,i)=>{const a=i/8*6.283,x=104+Math.cos(a)*30,y=62+Math.sin(a)*8;return`<path d="M${x} ${y+2} V${y-14}" stroke="#6A4A2A" stroke-width="2"/><ellipse cx="${x}" cy="${y-18}" rx="7" ry="6" fill="${P.ac}" ${SW2}/>`}).join("")}`)+
 fG(g,1,`<circle cx="30" cy="130" r="10" fill="none" stroke="${P.ac}" stroke-width="2" stroke-dasharray="3 3"/>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Arbor Week Blend"]="Sapling-Crowned Treant";SM("Arbor Week Blend","Perfect Circle","RES","s",0,100,"heal:30,def+1","Plant them round it, and they grow in a ring.");

/* Argument Metal: a boy dreamed of 'a recipe that argues'. A Tasmanian devil, mid-squabble, shouting its point. */
addForm("Argument Metal",{n:"#2A2A30",a:"#F4F0F4",rn:"#E8D8C8",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(60)+
 pt("tail",142,106,`<path d="M140 106 Q160 108 166 96" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M140 106 Q160 108 166 96" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",130,118,22,10,P.nd,FI,.5)+
 `<path d="M80 112 Q78 86 110 84 Q142 86 146 110 Q142 126 112 126 Q84 126 80 112 Z" fill="${P.n}" ${SW}/><path d="M90 96 Q110 90 130 96" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 fLeg("legF",120,120,22,10,P.n,FI,0)+fLeg("legF",90,120,22,10,P.n,FI,.8)+
 pt("head",84,96,`<path d="M46 100 Q46 78 70 76 Q92 78 94 98 Q90 112 70 112 Q50 112 46 100 Z" fill="${P.n}" ${SW}/><ellipse cx="46" cy="98" rx="4" ry="3.4" fill="#E8A0A0"/>${E2(66,88,3.6,"#1A1A1A")}<path d="M60 82 l12 2" stroke="${P.ac}" stroke-width="2"/>`+
  `<path d="M48 100 L76 102 L74 108 L50 106 Z" fill="${FMOUTH}"/>`+pt("jaw",68,106,`<path d="M76 104 Q62 118 48 104 Q62 112 76 108 Z" fill="${P.nd}" ${SW2}/><path d="M52 106 l2 4 l2 -4 l2 4 l2 -4 l2 4" stroke="#fff" stroke-width="1.4" fill="none"/>`)+
  pt("ear",78,78,`<ellipse cx="80" cy="76" rx="7" ry="9" fill="${P.n}" ${SW2}/><ellipse cx="80" cy="76" rx="3.6" ry="5" fill="#E8A0A0"/>`))+
 fG(g,1,`<path d="M20 40 q10 -14 22 -4 q8 -10 18 0 q4 12 -10 14 h-22 q-12 -2 -8 -10 Z" fill="#fff" ${SW2}/><text x="26" y="44" font-size="10" font-weight="bold" fill="${P.ac}">NO!</text>`)+fG(g,2,`<circle cx="112" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Argument Metal"]="Quarrelsome Tasmanian Devil";SM("Argument Metal","Shouting Match","RES","a",70,100,"tdef-1,tatk-1@30","Nobody's listening, but everybody's shouting.");

/* As You Were: every shift ends with the supervisor saluting the storeroom. A rock hyrax standing to attention, saluting. */
addForm("As You Were",{n:"#9A7A5A",a:"#E8D8C0",rn:"#3A3A4A",rb:"#3A5A3A",ra:"#E8412C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",116,132,`<ellipse cx="118" cy="138" rx="9" ry="5" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M84 128 Q80 94 104 90 Q128 94 126 128 Q120 142 104 142 Q88 142 84 128 Z" fill="${P.n}" ${SW}/><path d="M92 126 Q104 134 118 126 Q116 112 104 110 Q94 112 92 126 Z" fill="${P.ac}"/>`+
 pt("legF",92,132,`<ellipse cx="90" cy="138" rx="9" ry="5" fill="${P.n}" ${SW2}/>`)+
 pt("armB",124,104,fOL("M124 104 Q132 114 128 126",P.nd,6),.4)+
 pt("head",104,76,`<path d="M82 78 Q82 56 104 54 Q126 56 126 78 Q122 92 104 92 Q86 92 82 78 Z" fill="${P.n}" ${SW}/><ellipse cx="96" cy="82" rx="7" ry="5" fill="${P.ac}"/><ellipse cx="92" cy="80" rx="3" ry="2.4" fill="${FI}"/>${E2(100,72,3.4,"#1A1A1A")}${E2(114,72,3.4,"#1A1A1A")}`+HMOUTH(94,86,102,P,2)+
  pt("ear",86,58,`<circle cx="86" cy="58" r="4" fill="${P.nd}" ${SW2}/>`)+`<path d="M90 56 Q104 44 120 56 L118 60 Q104 52 92 60 Z" fill="#3A5A3A" ${SW2}/><path d="M118 56 h8" stroke="${FI}" stroke-width="3"/>`)+
 pt("armF",88,100,`<path d="M88 100 Q76 90 82 72 L92 66" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M88 100 Q76 90 82 72 L92 66" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 fG(g,1,`<rect x="150" y="100" width="34" height="42" fill="#8A6A4A" ${SW2}/><rect x="154" y="104" width="26" height="8" fill="#F4F0E4" ${SW2}/><text x="155" y="110" font-size="5" font-weight="bold" fill="${FI}">STORES</text>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["As You Were"]="Saluting Rock Hyrax";SM("As You Were","As You Were","RES","s",0,100,"cure,def+1","Salute, and everything goes back exactly as it should be.");

/* Ask Doris Metal: found behind a filing cabinet with a sticky note: 'ask Doris'. A sea slug as bright as a pad of sticky notes, a note stuck to its back. */
addForm("Ask Doris Metal",{n:"#8A5AC8",a:"#F2D040",rn:"#3A3A4A",rb:"#E8604A",ra:"#5FE0F0"},"ooze",(P,g)=>fShadow(66)+
 `<path d="M48 130 Q50 108 92 104 Q140 100 162 120 Q168 132 150 136 Q100 140 60 138 Q48 136 48 130 Z" fill="${P.n}" ${SW}/>${[[70,118],[90,112],[110,110],[130,112],[148,120]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.ac}"/>`).join("")}<path d="M52 132 Q100 126 160 130" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 pt("tail",150,108,`${[0,1,2,3,4].map(i=>`<path d="M${140+i*4} 110 Q${144+i*6} ${92-i*2} ${150+i*6} ${86-i}" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M${140+i*4} 110 Q${144+i*6} ${92-i*2} ${150+i*6} ${86-i}" stroke="#E8604A" stroke-width="3" fill="none" stroke-linecap="round"/>`).join("")}`)+
 `<g transform="rotate(-8 106 98)"><rect x="94" y="86" width="24" height="22" fill="#F2E060" ${SW2}/><text x="96" y="96" font-size="5.6" font-weight="bold" fill="${FI}">ask</text><text x="96" y="104" font-size="5.6" font-weight="bold" fill="${FI}">Doris</text></g>`+
 pt("head",60,118,`${E2(58,116,3.4)}`+HMOUTH(50,124,58,P,2)+pt("ant",60,108,`<path d="M56 110 Q48 90 54 84 M62 108 Q66 88 74 84" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M56 110 Q48 90 54 84 M62 108 Q66 88 74 84" stroke="${P.ac}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`))+
 fG(g,1,`<rect x="20" y="40" width="22" height="20" fill="#F2E060" ${SW2} transform="rotate(10 31 50)"/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Ask Doris Metal"]="Sticky-Note Sea Slug";SM("Ask Doris Metal","Ask Doris","RES","s",0,100,"cure,heal:20","Doris would know. Doris always knew.");

/* Attempt 10000 Blend: the ten-thousandth random recipe of an overnight program, and it worked. A chimera stitched from random bits of other creatures. */
addForm("Attempt 10000 Blend",{n:"#8A8A9A",a:"#E8604A",rn:"#3A3A4A",rb:"#5AB04A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(66)+
 pt("tail",160,96,`<path d="M156 98 Q176 92 180 74" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M156 98 Q176 92 180 74" stroke="#5AB04A" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M176 68 l6 -6 l2 10 Z" fill="#5AB04A" ${SW2}/>`)+
 pt("wingB",130,80,`<path d="M126 84 Q140 50 170 46 Q156 66 150 88 Z" fill="#E8D8C0" ${SW}/>`,.3)+
 pt("legB",146,112,`<path d="M146 110 L150 126 L144 140" stroke="${FI}" stroke-width="3.6" fill="none"/><path d="M138 142 l6 -2 l6 2" stroke="${FI}" stroke-width="2" fill="none"/>`,.5)+fLeg("legB",112,114,28,9,"#C8904A",FI,1.3)+
 `<path d="M84 104 Q86 80 118 78 Q152 80 158 102 Q152 120 120 120 Q90 120 84 104 Z" fill="${P.n}" ${SW}/><path d="M118 78 V120" stroke="${FI}" stroke-width="1.6" stroke-dasharray="3 2"/><path d="M118 80 Q150 82 156 102 Q150 118 118 118 Z" fill="${P.ac}" opacity=".5"/>`+
 pt("legF",140,114,`<path d="M140 112 L136 128 L142 142" stroke="${FI}" stroke-width="3.6" fill="none"/>`)+fLeg("legF",98,114,28,9,"#C8904A",FI,.8)+
 pt("head",86,90,`<path d="M50 92 Q50 74 70 72 Q90 74 92 90 Q88 104 70 104 Q54 104 50 92 Z" fill="${P.n}" ${SW}/><path d="M70 72 V104" stroke="${FI}" stroke-width="1.6" stroke-dasharray="3 2"/>${E2(62,86,4.4,"#E8A020")}<circle cx="80" cy="86" r="3" fill="${FI}"/><circle cx="81" cy="85" r="1" fill="#fff"/>`+
  `<path d="M52 96 L62 96 L60 100 Z" fill="${FMOUTH}"/>`+pt("beak",50,98,`<path d="M54 96 L40 98 L54 102 Z" fill="#E8B040" ${SW2}/>`)+pt("ear",80,74,`<path d="M76 76 L80 58 L88 74 Z" fill="${P.n}" ${SW2}/>`)+`<path d="M62 74 Q58 62 66 58" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}" font-family="monospace">#10000</text>`)+fG(g,2,`<circle cx="118" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Attempt 10000 Blend"]="Random-Parts Chimera";SM("Attempt 10000 Blend","Random Seed","RES","a",50,100,"multi:1-4,tacc-1@20","Nine thousand nine hundred and ninety-nine didn't work. This one does.");

/* Auctioneer's Chair: it came with its own chair, which nobody could sit in. That chair, a wingback on four restless legs, padding about like a dog. */
addForm("Auctioneer's Chair",{n:"#7A2A3A",a:"#C8A040",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(60)+
 [[134,"legB",.5],[118,"legB",1.3]].map(([x,c,d])=>pt(c,x,118,`<path d="M${x} 116 Q${x+4} 130 ${x} 142" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M${x} 116 Q${x+4} 130 ${x} 142" stroke="#6A4A2A" stroke-width="4.4" fill="none" stroke-linecap="round"/><circle cx="${x}" cy="142" r="3" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 `<path d="M76 116 L76 92 Q76 84 84 84 H136 Q144 84 144 92 V116 Z" fill="${P.n}" ${SW}/><path d="M118 84 V40 Q118 26 132 26 Q148 26 148 40 V100 Q144 106 136 104 V86" fill="${P.n}" ${SW}/><path d="M80 98 h56" stroke="${P.nd}" stroke-width="2"/>${[[124,44],[140,44],[132,60],[124,76],[140,76]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.ac}"/>`).join("")}<path d="M72 92 Q66 80 76 76 Q86 78 84 90 Z" fill="${P.nd}" ${SW2}/>`+
 [[96,"legF",0],[82,"legF",.8]].map(([x,c,d])=>pt(c,x,118,`<path d="M${x} 116 Q${x-4} 130 ${x} 142" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M${x} 116 Q${x-4} 130 ${x} 142" stroke="#6A4A2A" stroke-width="4.4" fill="none" stroke-linecap="round"/><circle cx="${x}" cy="142" r="3" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 pt("head",132,58,`${E2(126,56,4.2)}${E2(140,56,4.2)}`+HMOUTH(128,68,138,P,2.4))+
 pt("tail",150,98,`<path d="M148 100 Q164 96 168 84" stroke="${P.ac}" stroke-width="3" fill="none"/><circle cx="168" cy="82" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<rect x="20" y="40" width="30" height="16" fill="#F4F0E4" ${SW2}/><text x="22" y="52" font-size="8" font-weight="bold" fill="${FI}">LOT 3</text>`)+fG(g,2,`<circle cx="110" cy="106" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Auctioneer's Chair"]="Restless Wingback Chair";SM("Auctioneer's Chair","Going Once","RES","a",70,100,"multi:1-3","Going once, going twice...");

/* Auditex: every audit perfect, which made the auditors suspicious. A marmoset with one eyebrow very firmly raised. */
addForm("Auditex",{n:"#9A8A7A",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",124,110,`<path d="M120 112 Q150 130 160 112 Q166 100 156 96" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M120 112 Q150 130 160 112 Q166 100 156 96" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round" stroke-dasharray="6 3"/>`)+
 `<path d="M88 114 Q84 88 104 84 Q124 88 122 114 Q116 122 104 122 Q92 122 88 114 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",96,116,`<path d="M96 114 l-4 6 M100 116 l0 6" stroke="${FI}" stroke-width="3"/>`)+
 pt("armF",92,96,fOL("M92 96 Q80 100 82 110",P.n,5))+
 pt("head",104,72,`<circle cx="104" cy="70" r="14" fill="${P.n}" ${SW}/><path d="M84 64 Q76 54 82 46 Q90 54 92 62 Z" fill="${P.ac}" ${SW2}/><path d="M124 64 Q132 54 126 46 Q118 54 116 62 Z" fill="${P.ac}" ${SW2}/><path d="M98 64 Q104 60 110 64 L110 78 Q104 82 98 78 Z" fill="#E8D0C0"/>${E2(99,70,3.2,"#3A2410",[.4,0])}${E2(109,70,3.4,"#3A2410",[.4,0])}<path d="M95 66 l7 0 M106 62 l8 -3" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`+HMOUTH(100,78,108,P,1.6))+
 fG(g,1,`<text x="150" y="40" font-size="18" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">?!</text>`)+fG(g,2,`<circle cx="104" cy="106" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Auditex"]="Eyebrow-Raising Marmoset";SM("Auditex","Too Perfect","RES","a",60,100,"tdef-1,crit","Nothing's ever this tidy. What are you hiding?");

/* Auntie's Metal: traded on the salt road for centuries, always by somebody's aunt. An alpaca in a shawl, salt bags slung either side. */
addForm("Auntie's Metal",{n:"#E8DCC8",a:"#B8402A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",152,90,`<circle cx="154" cy="92" r="6" fill="${P.n}" ${SW2}/>`)+
 fLeg("legB",140,104,38,8,P.nd,P.ndd,.5)+fLeg("legB",112,106,36,8,P.nd,P.ndd,1.3)+
 `<path d="M88 98 Q88 74 120 72 Q150 74 154 96 Q150 112 122 112 Q92 112 88 98 Z" fill="${P.n}" ${SW}/>${Array.from({length:10},(_,i)=>`<circle cx="${96+(i%5)*12}" cy="${82+Math.floor(i/5)*12}" r="5" fill="${P.n}" stroke="${P.nd}" stroke-width="1"/>`).join("")}<rect x="96" y="100" width="20" height="18" rx="4" fill="#F4F0F4" ${SW2}/><rect x="128" y="100" width="20" height="18" rx="4" fill="#F4F0F4" ${SW2}/><text x="98" y="112" font-size="6" font-weight="bold" fill="${FI}">SALT</text>`+
 fLeg("legF",132,106,36,8,P.n,P.ndd,0)+fLeg("legF",100,106,36,8,P.n,P.ndd,.8)+
 pt("head",94,82,`<path d="M98 90 Q90 60 92 40" stroke="${FI}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M98 90 Q90 60 92 40" stroke="${P.n}" stroke-width="12.6" fill="none" stroke-linecap="round"/><path d="M84 64 Q96 72 106 62 L108 76 Q96 84 84 78 Z" fill="${P.ac}" ${SW2}/>${[88,94,100].map(x=>`<path d="M${x} 78 v8" stroke="${P.ac}" stroke-width="2"/>`).join("")}`+
  `<path d="M76 40 Q74 24 92 22 Q106 24 104 38 Q102 46 92 46 Q78 46 76 40 Z" fill="${P.n}" ${SW}/><circle cx="90" cy="24" r="8" fill="${P.n}" stroke="${P.nd}" stroke-width="1"/>${E2(88,34,3.4,"#1A1A1A")}`+HMOUTH(76,40,82,P,1.8)+
  pt("ear",98,22,`<path d="M96 24 L98 10 L104 22 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 136 Q36 128 52 136 Z" fill="#F4F0F4" ${SW2}/>`)+fG(g,2,`<circle cx="122" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Auntie's Metal"]="Salt-Road Auntie Alpaca";SM("Auntie's Metal","Auntie Knows Best","RES","s",0,100,"heal:25,ward+1","Sit down, have something to eat, and listen to your aunt.");

/* Autumnite: it has only ever worked in autumn. A jay burying acorns among falling leaves. */
addForm("Autumnite",{n:"#C8A08A",a:"#3A6AC8",rn:"#3A3A4A",rb:"#B8602A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 140 Q104 130 194 142 V150 H14 Z" fill="#B8803A" ${SW2}/>${[[30,30,"#E8901A"],[60,50,"#C8402A"],[150,26,"#E8C040"],[176,60,"#C8602A"],[40,96,"#E8901A"]].map(([x,y,c])=>`<path d="M${x} ${y} q6 -8 12 0 q-6 8 -12 0 Z" fill="${c}" ${SW2} transform="rotate(${x%40} ${x} ${y})"/>`).join("")}`+fShadow(54,110)+
 pt("tail",136,98,`<path d="M130 94 L160 102 L156 112 L132 106 Z" fill="${FI}"/><path d="M130 94 L154 100" stroke="${P.ac}" stroke-width="3"/>`)+
 pt("legB",116,112,`<path d="M116 110 L118 138" stroke="#C8A080" stroke-width="3"/><path d="M110 140 h14" stroke="#C8A080" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M84 100 Q86 78 110 76 Q132 80 134 102 Q126 116 106 116 Q88 114 84 100 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",110,92,`<path d="M98 88 Q124 82 138 100 Q122 110 102 104 Z" fill="${FI}" ${SW}/><path d="M104 90 h18" stroke="${P.ac}" stroke-width="4"/><path d="M104 90 h18" stroke="#F4F0F4" stroke-width="1.4" stroke-dasharray="2 2"/><path d="M100 96 h16" stroke="#F4F0F4" stroke-width="2"/>`)+
 pt("legF",100,112,`<path d="M100 110 L98 138" stroke="#C8A080" stroke-width="3"/><path d="M90 140 h14" stroke="#C8A080" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",88,76,`<circle cx="86" cy="70" r="13" fill="${P.n}" ${SW}/><path d="M80 58 Q88 48 98 58" stroke="#F4F0F4" stroke-width="5" fill="none"/>${[82,88,94].map(x=>`<path d="M${x} 52 v6" stroke="${FI}" stroke-width="1.4"/>`).join("")}<path d="M78 74 l-6 6" stroke="${FI}" stroke-width="3"/>${E2(84,68,3.2,"#3A6AC8")}`+
  `<path d="M74 70 L62 72 L74 74 Z" fill="${FMOUTH}"/>`+pt("beak",74,74,`<path d="M74 74 L63 74 L74 77 Z" fill="${FI}"/>`)+`<path d="M74 68 L60 71 L74 72 Z" fill="${FI}"/><ellipse cx="58" cy="74" rx="5" ry="6" fill="#B8803A" ${SW2}/><path d="M54 70 Q58 64 62 70 Z" fill="#6A4A2A" ${SW2}/>`)+
 fG(g,1,`<ellipse cx="164" cy="138" rx="5" ry="6" fill="#B8803A" ${SW2}/><path d="M160 134 Q164 128 168 134 Z" fill="#6A4A2A" ${SW2}/>`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,30,6)));
FORM_TITLE["Autumnite"]="Acorn-Burying Jay";SM("Autumnite","Bury For Winter","RES","s",0,100,"heal:20,def+1","Hide a thousand acorns. Remember most of them.");
