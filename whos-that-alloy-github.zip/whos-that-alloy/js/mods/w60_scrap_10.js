/* ---- Tinker's Scrapyard, 10 ---- */
/* Farewell Blend: the retirement speeches ran long, and somewhere between the toasts it came together. A tree kangaroo waving a farewell handkerchief. */
addForm("Farewell Blend",{n:"#8A5A3A",a:"#E8C890",rn:"#3A3A4A",rb:"#F4F0F4",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",120,114,`<path d="M116 116 Q130 136 126 150" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M116 116 Q130 136 126 150" stroke="${P.ac}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 `<path d="M86 116 Q82 84 104 80 Q126 84 124 116 Q118 126 104 126 Q90 126 86 116 Z" fill="${P.n}" ${SW}/><path d="M94 114 Q104 122 116 114 Q114 98 104 96 Q96 98 94 114 Z" fill="${P.ac}"/>`+
 pt("legF",96,118,`<path d="M96 116 l-6 6 M102 118 l0 6" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("armB",120,96,fOL("M120 96 Q130 104 128 114",P.n,6),.4)+
 pt("armF",88,96,`<path d="M90 96 Q74 84 74 64" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M90 96 Q74 84 74 64" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`+pt("sway",74,56,`<path d="M74 58 Q58 46 44 52 Q50 64 46 74 Q60 70 74 62 Z" fill="#F4F0F4" ${SW}/><path d="M50 56 l14 0" stroke="#C8C8D0" stroke-width="1"/>`))+
 pt("head",104,68,`<path d="M84 70 Q84 50 104 48 Q124 50 124 70 Q120 84 104 84 Q88 84 84 70 Z" fill="${P.n}" ${SW}/><ellipse cx="104" cy="74" rx="8" ry="6" fill="${P.ac}"/><ellipse cx="104" cy="70" rx="3" ry="2.4" fill="${FI}"/>${E2(96,64,3.2,"#1A1A1A")}${E2(112,64,3.2,"#1A1A1A")}`+HMOUTH(100,78,108,P,1.6)+
  pt("ear",88,52,`<circle cx="88" cy="52" r="5" fill="${P.n}" ${SW2}/>`)+pt("ear",120,52,`<circle cx="120" cy="52" r="5" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<text x="150" y="40" font-family="Georgia,serif" font-size="11" font-style="italic" fill="${P.ac}">cheerio!</text>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Farewell Blend"]="Hanky-Waving Tree Kangaroo";SM("Farewell Blend","Fond Farewell","RES","s",0,100,"heal:30,tatk-1","One last wave. Do keep in touch.");

/* Favorex: valued in 'favours owed'; some families are still repaying. A cleaner wrasse, the fish that does favours for every fish on the reef. */
addForm("Favorex",{n:"#5A8AC8",a:"#2A2A30",rn:"#3A3A4A",rb:"#F2C94C",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 140 Q104 130 194 142 V150 H14 Z" fill="#E8B0A0" opacity=".6"/><path d="M130 146 Q126 110 140 90 Q150 110 146 146 M156 146 Q160 116 174 104 Q174 126 168 146" stroke="#E8604A" stroke-width="6" fill="none" stroke-linecap="round"/>`+
 pt("tail",136,84,`<path d="M130 84 L150 70 L148 84 L150 98 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",108,72,`<path d="M88 74 Q108 64 128 74 Z" fill="${P.nd}" ${SW2}/>`,.3)+
 `<path d="M60 84 Q66 72 96 72 Q126 74 132 84 Q126 96 96 96 Q66 96 60 84 Z" fill="${P.n}" ${SW}/><path d="M64 84 H130" stroke="${P.ac}" stroke-width="5"/><path d="M70 78 Q96 74 122 78" stroke="#fff" stroke-width="2" fill="none" opacity=".5"/>`+
 pt("wingF",92,92,`<path d="M90 92 L84 104 L98 96 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",64,82,`${E2(70,80,3,"#E8C040")}`+pt("jaw",58,86,`<ellipse cx="58" cy="86" rx="3" ry="2.4" fill="${FMOUTH}" ${SW2}/>`))+
 fG(g,1,`<rect x="20" y="30" width="34" height="18" rx="2" fill="#F4F0E4" ${SW2}/><text x="22" y="42" font-size="7" font-weight="bold" fill="${FI}">I.O.U.</text>`)+fG(g,2,`<circle cx="96" cy="84" r="3" fill="#F2C94C" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Favorex"]="Favour-Keeping Cleaner Wrasse";SM("Favorex","Owe Me One","RES","s",0,100,"cure,heal:20","I'll clean yours, you don't eat me. Fair's fair.");

/* Faxium: an old fax printed this recipe unprompted at 2 a.m. A galah, the pink cockatoo, screeching like a dial-up fax machine. */
addForm("Faxium",{n:"#E8A0B0",a:"#B8B8C0",rn:"#3A3A4A",rb:"#F4F0F4",ra:"#5FE0F0"},"perch",(P,g)=>`<rect x="130" y="110" width="56" height="30" rx="4" fill="#E8E4DC" ${SW}/><rect x="136" y="114" width="20" height="8" fill="#3A3A44"/><path d="M140 110 Q150 80 166 86 Q160 98 162 110" fill="#F4F0E4" ${SW2}/><path d="M146 96 h12 M146 100 h10" stroke="#8A8A9A" stroke-width="1"/>`+`<path d="M30 126 H120" stroke="#6A4A2A" stroke-width="7" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",100,118,`<path d="M96 114 L116 140 L104 144 L92 120 Z" fill="${P.ac}" ${SW}/>`)+
 `<path d="M64 116 Q62 86 84 82 Q106 86 106 116 Q98 126 84 126 Q70 126 64 116 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",88,100,`<path d="M78 94 Q100 90 108 112 Q94 118 82 110 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legF",82,124,`<path d="M80 124 l-2 4 M86 124 l2 4" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",78,74,`<circle cx="78" cy="70" r="14" fill="${P.n}" ${SW}/><path d="M70 58 Q78 50 86 58 Q80 56 72 62 Z" fill="#F4F0F4" ${SW2}/>${E2(76,66,3,"#1A1A1A")}<circle cx="76" cy="66" r="5.4" fill="none" stroke="#E8A0A0" stroke-width="1.4"/>`+
  `<path d="M66 72 Q56 72 56 82 L66 78 Z" fill="${FMOUTH}"/>`+pt("beak",62,80,`<path d="M66 78 Q58 86 54 82 Q60 80 66 76 Z" fill="#C8C8D0" ${SW2}/>`)+`<path d="M66 66 Q52 64 52 78 Q60 72 66 72 Z" fill="#C8C8D0" ${SW2}/>`)+
 fG(g,1,`<path d="M20 40 l4 -4 l4 4 l4 -4 l4 4 l4 -4 l4 4" stroke="${P.ac}" stroke-width="2" fill="none"/><text x="20" y="56" font-size="8" font-weight="bold" fill="${P.ac}" font-family="monospace">KSSHHH</text>`)+fG(g,2,`<circle cx="84" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Faxium"]="Fax-Screeching Galah";SM("Faxium","Handshake Screech","RES","a",55,100,"tacc-1,irr@30","Beeeee-dee-dee-krrrsssh. Connected.");

/* Faxon: a paper jam fused one recipe's second page onto another's first. A concertina paper dragon, folded from those fused pages. */
addForm("Faxon",{n:"#F4F0E4",a:"#3A5AA8",rn:"#3A3A4A",rb:"#C8302A",ra:"#F2C94C"},"slink",(P,g)=>fShadow(80)+
 pt("tail",170,104,`<path d="M164 100 L186 86 L180 104 L192 112 Z" fill="${P.n}" ${SW}/>`)+
 pt("sway",116,104,`${Array.from({length:8},(_,i)=>{const x=70+i*13,y=100+Math.sin(i*.9)*8;return`<path d="M${x} ${y-14} L${x+13} ${y-10} L${x+13} ${y+12} L${x} ${y+14} Z" fill="${i%2?P.n:"#E8E4D8"}" ${SW2}/><path d="M${x+2} ${y-6} h8 M${x+2} ${y-2} h8 M${x+2} ${y+2} h6" stroke="${P.ac}" stroke-width=".8"/>`}).join("")}`)+
 [[150,"legB",.5],[96,"legF",0]].map(([x,c,d])=>pt(c,x,114,`<path d="M${x} 112 L${x-4} 136 H${x+6}" stroke="${FI}" stroke-width="3" fill="none"/>`,d)).join("")+
 pt("head",62,98,`<path d="M30 96 L60 82 L70 98 L60 112 Z" fill="${P.n}" ${SW}/><path d="M60 82 L54 66 L66 80 M66 86 L74 72 L72 90" fill="${P.n}" ${SW2}/>${E2(54,92,3.4,"#C8302A")}<path d="M30 96 L60 104" stroke="${FI}" stroke-width="1.4"/>`+pt("jaw",44,104,`<path d="M30 98 L56 106 L50 112 Z" fill="#E8E4D8" ${SW2}/>`))+
 fG(g,1,`<g transform="rotate(-10 30 130)"><rect x="18" y="120" width="26" height="20" fill="${P.n}" ${SW2}/><path d="M22 126 h18 M22 130 h14" stroke="${P.ac}" stroke-width="1"/></g>`)+fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Faxon"]="Concertina Paper Dragon";SM("Faxon","Paper Jam","RES","s",0,100,"tspd-1,def+1","Crumpled, folded, and stuck together for good.");

/* Ferretex: the lab ferret hid the recipe card in a rubber boot for a month. A polecat poking out of that welly boot, card in its mouth. */
addForm("Ferretex",{n:"#4A3A30",a:"#F4E8D0",rn:"#3A3A4A",rb:"#3A7A4A",ra:"#E8412C"},"perch",(P,g)=>fShadow(60)+
 `<path d="M80 146 L86 74 H122 L126 120 Q150 122 156 136 L156 146 Z" fill="#3A7A4A" ${SW}/><path d="M84 80 H124" stroke="#2A5A3A" stroke-width="4"/><path d="M126 120 Q150 122 156 136" stroke="#2A5A3A" stroke-width="2" fill="none"/>`+
 pt("sway",104,64,`<path d="M88 80 Q86 58 104 52 Q122 58 120 80 Z" fill="${P.n}" ${SW}/><path d="M78 56 Q80 38 100 36 Q118 38 120 54 Q116 66 100 66 Q84 66 78 56 Z" fill="${P.n}" ${SW}/><path d="M86 48 Q100 40 114 48 L112 56 Q100 50 88 56 Z" fill="${P.ac}"/><ellipse cx="78" cy="56" rx="3" ry="2.6" fill="${FI}"/>${E2(92,50,3.2,"#1A1A1A")}${E2(108,48,3,"#1A1A1A")}`+
  `<path d="M80 60 L94 62 L92 66 L82 64 Z" fill="${FMOUTH}"/>`+pt("jaw",90,65,`<path d="M94 64 Q86 70 80 64 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(-14 72 68)"><rect x="60" y="62" width="18" height="12" fill="#F4F0E4" ${SW2}/><path d="M63 66 h12 M63 70 h8" stroke="#8A8A9A" stroke-width=".8"/></g>`)+
  pt("ear",108,38,`<circle cx="110" cy="38" r="5" fill="${P.ac}" ${SW2}/>`))+
 pt("armF",90,80,`<ellipse cx="88" cy="80" rx="6" ry="4" fill="${P.n}" ${SW2}/>`)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">1 month</text>`)+fG(g,2,`<circle cx="104" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Ferretex"]="Welly-Boot Polecat";SM("Ferretex","Stash","RES","s",0,100,"dodge,def+1","It's safe. You just won't find it for a month.");

/* Fettle's Palindrome: its catalogue number reads the same upside down. An upside-down catfish, the real one that swims belly-up. */
addForm("Fettle's Palindrome",{n:"#8A7A5A",a:"#3A3A30",rn:"#E8D8C8",rb:"#5AB0C8",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/><path d="M14 40 H194" stroke="#5AB0C8" stroke-width="2" opacity=".5"/>`+
 pt("tail",150,76,`<path d="M144 76 L170 58 L164 76 L170 94 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",112,100,`<path d="M104 96 L114 118 L124 98 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M56 76 Q62 94 100 96 Q136 94 148 76 Q136 58 100 58 Q62 58 56 76 Z" fill="${P.n}" ${SW}/><path d="M60 72 Q100 60 146 72" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".6"/>${[[88,82],[104,86],[120,82],[96,72],[114,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.ac}" opacity=".6"/>`).join("")}`+
 pt("wingF",96,58,`<path d="M92 60 L84 42 L104 58 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",62,76,`${E2(70,80,3.4,"#E8C040",[0,.6])}`+pt("jaw",56,76,`<ellipse cx="56" cy="76" rx="3" ry="4" fill="${FMOUTH}" ${SW2}/>`)+`<path d="M58 70 Q44 60 36 64 M58 82 Q44 92 36 88 M60 74 Q46 72 40 76" stroke="${FI}" stroke-width="1.6" fill="none"/>`)+
 fG(g,1,`<text x="150" y="130" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">69</text>`)+fG(g,2,`<circle cx="100" cy="76" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Fettle's Palindrome"]="Upside-Down Catfish";SM("Fettle's Palindrome","Either Way Up","RES","s",0,100,"dodge,acc+1","Turn it over. It looks exactly the same.");

/* Folleon: three official founding dates, each with a signed certificate. A three-headed hound pup, each head insisting on a different date. */
addForm("Folleon",{n:"#5A4A44",a:"#E8604A",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(70)+
 pt("tail",156,102,`<path d="M152 102 Q170 92 172 76" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M152 102 Q170 92 172 76" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M168 74 l6 -6 l2 8 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",144,116,24,10,P.nd,P.ndd,.5)+fLeg("legB",112,118,22,10,P.nd,P.ndd,1.3)+
 `<path d="M84 110 Q84 86 118 84 Q152 86 156 108 Q152 126 120 126 Q88 126 84 110 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",136,118,22,10,P.n,P.ndd,0)+fLeg("legF",98,118,22,10,P.n,P.ndd,.8)+
 [[62,70,0],[84,58,.2],[106,68,.4]].map(([x,y,d],i)=>pt(i===1?"head":(i?"ear":"jaw"),x,y,`<path d="M${96+i*6} 96 L${x+10} ${y+10}" stroke="${P.n}" stroke-width="12" stroke-linecap="round"/><circle cx="${x}" cy="${y}" r="13" fill="${P.n}" ${SW}/><path d="M${x-12} ${y+2} L${x-20} ${y+4} L${x-12} ${y+8} Z" fill="${P.nd}" ${SW2}/>${E2(x-4,y-3,3,"#E8604A")}<path d="M${x-12} ${y+6} l8 0" stroke="${FMOUTH}" stroke-width="2.4"/><path d="M${x+2} ${y-12} l2 -8 l6 6" fill="${P.n}" ${SW2}/><text x="${x-6}" y="${y-18}" font-size="6" font-weight="bold" fill="${P.ac}">${["1801","1822","1856"][i]}</text>`,d)).join("")+
 fG(g,1,`${[0,1,2].map(i=>`<rect x="${150+i*8}" y="${30+i*4}" width="14" height="10" fill="#F4F0E4" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="120" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Folleon"]="Three-Headed Hound Pup";SM("Folleon","Triple Certificate","STR","a",30,100,"multi:3-3","Three heads, three dates, three bites.");

/* Footfallite: footsteps pace its aisle, stop at the crate, and turn back. A pair of empty boots, pacing on their own. */
addForm("Footfallite",{n:"#5A3A2A",a:"#C8A060",rn:"#3A3A4A",rb:"#E8E0D0",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M14 146 H194" stroke="#9A9AA0" stroke-width="4"/>${[[40,144],[60,140],[80,144]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="7" ry="3" fill="${P.n}" opacity=".3"/>`).join("")}`+fShadow(56)+
 pt("legB",122,110,`<path d="M114 60 L116 122 L144 126 Q150 140 132 142 L110 142 L108 60 Z" fill="${P.nd}" ${SW}/><path d="M108 60 h10" stroke="${FI}" stroke-width="3"/><path d="M110 132 h34" stroke="${P.ac}" stroke-width="2"/>`,.5)+
 pt("legF",88,110,`<path d="M80 56 L82 122 L110 126 Q116 140 98 142 L76 142 L74 56 Z" fill="${P.n}" ${SW}/><path d="M74 56 h10" stroke="${FI}" stroke-width="3"/><path d="M76 132 h34" stroke="${P.ac}" stroke-width="2"/>${[70,80,90,100].map(y=>`<path d="M78 ${y} l6 3" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",80,50,`<ellipse cx="78" cy="54" rx="8" ry="3" fill="#1A1A22" ${SW2}/>${E2(76,74,3.2,"#E8E0D0")}${E2(86,74,3.2,"#E8E0D0")}`)+
 fG(g,1,`<text x="150" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">tap... tap...</text>`)+fG(g,2,`<circle cx="92" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Footfallite"]="Pacing Empty Boots";SM("Footfallite","Footsteps","RES","a",60,100,"irr@30","Tap. Tap. Tap. Stop. Turn round. Tap. Tap.");

/* Footnotium: Section 8's footnote about it has its own footnote. A dust mite so tiny it needs a magnifying glass, reading the very small print. */
addForm("Footnotium",{n:"#C8B8A0",a:"#7AB8E8",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"crawl",(P,g)=>`<rect x="20" y="20" width="168" height="124" fill="#F4F0E4" ${SW}/>${[34,44,54].map(y=>`<path d="M30 ${y} H178" stroke="#8A8A9A" stroke-width="2"/>`).join("")}<text x="30" y="132" font-size="5" fill="${FI}">* see footnote ** see footnote ***</text>`+
 `<circle cx="104" cy="96" r="44" fill="#E8F4FC" opacity=".55" ${SW}/><path d="M136 128 L170 146" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/><circle cx="104" cy="96" r="44" fill="none" stroke="${P.b}" stroke-width="5"/>`+
 Array.from({length:8},(_,i)=>{const s=i<4?-1:1,k=i%4,x=104+s*(14+k*2);return pt(i%2?"legB":"legF",x,100,`<path d="M${104+s*8} ${96+k*3} Q${104+s*22} ${84+k*8} ${104+s*(28+k*2)} ${108+k*4}" stroke="${FI}" stroke-width="3" fill="none"/>`,i*.1)}).join("")+
 `<ellipse cx="104" cy="98" rx="18" ry="14" fill="${P.n}" ${SW}/>${[[98,92],[110,94],[104,104]].map(([x,y])=>`<path d="M${x} ${y} l2 -4" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 pt("head",104,82,`<circle cx="104" cy="82" r="8" fill="${P.n}" ${SW}/>${E2(100,80,2.6)}${E2(108,80,2.6)}`+pt("jaw",104,88,`<path d="M101 87 l3 3 l3 -3" stroke="${FI}" stroke-width="1.4" fill="none"/>`))+
 fG(g,1,`<text x="150" y="16" font-size="12" font-weight="bold" fill="${P.ac}">***</text>`)+fG(g,2,`<circle cx="104" cy="98" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,110,6)));
FORM_TITLE["Footnotium"]="Small-Print Mite";SM("Footnotium","Small Print","RES","s",0,100,"tacc-1,tdef-1","It's all there in the footnotes. And the footnotes' footnotes.");

/* Forfeit Metal: mention it mid-game at the backgammon club and you forfeit a turn. A ray patterned like a backgammon board, points and all. */
addForm("Forfeit Metal",{n:"#8A5A3A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="54" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",156,96,`<path d="M152 96 Q172 102 192 92" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M152 96 Q172 102 192 92" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 pt("wingB",130,90,`<path d="M110 66 Q156 60 166 96 Q140 100 110 98 Z" fill="${P.nd}" ${SW}/>`,.4)+
 `<path d="M44 94 Q52 56 104 58 Q150 60 156 96 Q134 124 104 122 Q64 124 44 94 Z" fill="${P.n}" ${SW}/><clipPath id="bgC"><path d="M44 94 Q52 56 104 58 Q150 60 156 96 Q134 124 104 122 Q64 124 44 94 Z"/></clipPath><g clip-path="url(#bgC)">${Array.from({length:6},(_,i)=>`<path d="M${58+i*16} 58 L${66+i*16} 88 L${74+i*16} 58 Z" fill="${i%2?P.ac:"#B8402A"}"/><path d="M${58+i*16} 124 L${66+i*16} 96 L${74+i*16} 124 Z" fill="${i%2?"#B8402A":P.ac}"/>`).join("")}<path d="M104 58 V124" stroke="${FI}" stroke-width="3"/></g><path d="M44 94 Q52 56 104 58 Q150 60 156 96 Q134 124 104 122 Q64 124 44 94" fill="none" ${SW}/>${[[86,92],[122,94]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="6" fill="${i?FI:"#F4F0F4"}" ${SW2}/>`).join("")}`+
 pt("wingF",58,98,`<path d="M58 84 Q30 86 20 108 Q42 116 62 106 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",56,90,`${E2(60,82,3.6)}${E2(72,78,3.4)}`+HMOUTH(52,100,62,P,2))+
 fG(g,1,`<g transform="rotate(14 30 40)"><rect x="22" y="32" width="16" height="16" rx="3" fill="#F4F0F4" ${SW2}/><circle cx="27" cy="37" r="1.6" fill="${FI}"/><circle cx="33" cy="43" r="1.6" fill="${FI}"/></g>`)+fG(g,2,`<circle cx="104" cy="90" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Forfeit Metal"]="Backgammon Ray";SM("Forfeit Metal","Forfeit A Turn","RES","s",0,100,"tspd-2","You said it. Miss a go.");

/* Forty Winks Blend: napping is forbidden near it, and unofficially encouraged. A lion fast asleep in a nightcap, tail twitching. */
addForm("Forty Winks Blend",{n:"#D8A860",a:"#8A5A2A",rn:"#3A3A4A",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(80)+
 pt("tail",160,120,`<path d="M156 122 Q180 126 186 112" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M156 122 Q180 126 186 112" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M184 112 Q192 104 186 98 Q180 104 184 112 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M80 126 Q80 104 120 102 Q160 104 164 124 Q160 136 120 136 Q84 136 80 126 Z" fill="${P.n}" ${SW}/>`+
 [[130,"legF",0],[96,"legF",.8]].map(([x,c,d])=>pt(c,x,132,`<ellipse cx="${x-10}" cy="136" rx="16" ry="5" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",74,118,`${Array.from({length:12},(_,i)=>{const a=i/12*6.283;return`<circle cx="${70+Math.cos(a)*22}" cy="${112+Math.sin(a)*20}" r="10" fill="${P.ac}" ${SW2}/>`}).join("")}<path d="M48 114 Q48 94 70 92 Q92 94 92 114 Q88 130 70 130 Q52 130 48 114 Z" fill="${P.n}" ${SW}/><path d="M58 110 q4 3 8 0 M74 110 q4 3 8 0" stroke="${FI}" stroke-width="2" fill="none"/><ellipse cx="68" cy="118" rx="4" ry="3" fill="${FI}"/>`+HMOUTH(64,122,74,P,1.6)+
  `<path d="M54 98 Q66 70 92 82 Q104 92 100 102 Q88 92 76 96 Z" fill="#3A5AA8" ${SW}/><circle cx="102" cy="104" r="5" fill="#F4F0F4" ${SW2}/>`)+
 fG(g,1,`<text x="130" y="60" font-family="Georgia,serif" font-size="16" font-weight="bold" fill="${P.ac}">Z z z</text>`)+fG(g,2,`<circle cx="120" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Forty Winks Blend"]="Nightcapped Lion";SM("Forty Winks Blend","Forty Winks","RES","s",0,100,"heal:50,selfspd-1","Just a quick nap. The best ideas come halfway through.");
