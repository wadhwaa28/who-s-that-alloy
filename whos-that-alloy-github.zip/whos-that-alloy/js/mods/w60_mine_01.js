/* ---- Rustvein Mine, 1 ---- */
/* Act One Special: a play about it never reaches the second act. A moth whose wings are two stage curtains, forever about to open. */
addForm("Act One Special",{n:"#8A2A3A",a:"#F2C94C",rn:"#2E3A6A",rb:"#B8BCD8",ra:"#E8A0C0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="34" ry="4" fill="#000" opacity=".12"/>`+
 pt("wingB",110,72,`<path d="M110 70 L160 30 L176 40 Q170 80 178 118 Q150 110 114 88 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${130+i*11} ${52-i*5} Q${134+i*11} ${84} ${128+i*12} ${112-i*2}" stroke="${P.ndd}" stroke-width="2" fill="none"/>`).join("")}<path d="M160 30 L176 40" stroke="${P.ac}" stroke-width="4"/><circle cx="174" cy="116" r="3.4" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M96 70 Q104 60 114 70 L118 110 Q110 124 100 112 Z" fill="${P.b}" ${SW}/>${[80,90,100].map(y=>`<path d="M98 ${y} Q108 ${y+4} 116 ${y}" stroke="${P.d}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("wingF",98,72,`<path d="M98 70 L48 26 L30 36 Q38 78 28 120 Q60 112 94 90 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${78-i*11} ${50-i*5} Q${74-i*11} ${84} ${80-i*12} ${112-i*2}" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}<path d="M48 26 L30 36" stroke="${P.ac}" stroke-width="4"/><path d="M44 96 Q56 92 60 100" stroke="${P.ac}" stroke-width="3" fill="none"/><circle cx="34" cy="118" r="3.4" fill="${P.ac}" ${SW2}/>`)+
 pt("head",104,66,`<circle cx="104" cy="58" r="13" fill="${P.b}" ${SW}/>${E2(98,56,4.4,P.ac)}${E2(110,56,4.4,P.ac)}<path d="M100 66 Q104 69 108 66" stroke="${FI}" stroke-width="1.8" fill="none"/>`+
  pt("ant",100,46,`<path d="M100 46 Q88 30 76 30" stroke="${FI}" stroke-width="2" fill="none"/>${[0,1,2,3].map(i=>`<path d="M${96-i*5} ${40-i*2.4} l-2 -5" stroke="${FI}" stroke-width="1.4"/>`).join("")}`)+pt("ant",108,46,`<path d="M108 46 Q118 30 132 28" stroke="${FI}" stroke-width="2" fill="none"/>${[0,1,2,3].map(i=>`<path d="M${112+i*5} ${40-i*2.4} l2 -5" stroke="${FI}" stroke-width="1.4"/>`).join("")}`,.4))+
 fG(g,1,`<path d="M20 140 h40" stroke="${P.ac}" stroke-width="3" stroke-dasharray="6 4"/>`)+fG(g,2,`<circle cx="106" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,22,6)));
FORM_TITLE["Act One Special"]="Curtain Moth";SM("Act One Special","Interval","RES","s",0,100,"tspd-1,heal:20","Everything stops for the interval, whether it wants to or not.");

/* Armisticine: its recipe waited in an envelope marked 'Open in the event of peace'. A dove carrying the sealed envelope. */
addForm("Armisticine",{n:"#E8E4DA",a:"#B8302A",rn:"#4A4A5A",rb:"#7AB8E8",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="30" ry="4" fill="#000" opacity=".12"/>`+
 pt("wingB",112,78,`<path d="M112 78 Q132 34 172 30 Q160 50 168 58 Q150 64 156 74 Q138 82 120 90 Z" fill="${P.nd}" ${SW}/>`)+
 pt("tail",132,98,`<path d="M128 94 L162 104 Q164 116 152 116 L126 104 Z" fill="${P.n}" ${SW}/><path d="M138 102 L156 110" stroke="${P.nd}" stroke-width="1.6"/>`)+
 `<path d="M74 92 Q76 76 100 74 Q126 76 134 98 Q122 110 100 110 Q80 108 74 92 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,84,`<path d="M100 84 Q82 40 40 34 Q52 54 44 62 Q64 66 58 76 Q76 82 92 96 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${84-i*12} ${58+i*8} l-12 -4" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",80,84,`<circle cx="72" cy="78" r="12" fill="${P.n}" ${SW}/>${E2(70,74,3.8,"#C84A3A")}<path d="M62 78 L52 80 L62 82 Z" fill="${FMOUTH}"/>`+
  pt("beak",62,81,`<path d="M62 81 L52 81 L62 84 Z" fill="#E89AA8" ${SW2}/>`)+`<path d="M62 76 L50 79 L62 80 Z" fill="#E89AA8" ${SW2}/>`+
  `<g transform="rotate(-8 44 92)"><rect x="30" y="84" width="28" height="18" rx="2" fill="#F4F0E4" ${SW2}/><path d="M30 84 L44 95 L58 84" stroke="${FI}" stroke-width="1.4" fill="none"/><circle cx="44" cy="95" r="4" fill="${P.ac}" ${SW2}/></g>`)+
 `<path d="M98 108 l-2 8 M106 108 l0 8" stroke="#E89AA8" stroke-width="2.4"/>`+
 fG(g,1,`<path d="M164 128 q6 -10 14 -8" stroke="#5AA84A" stroke-width="2.4" fill="none"/><ellipse cx="172" cy="122" rx="4" ry="2" fill="#5AA84A"/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(120,24,6)));
FORM_TITLE["Armisticine"]="Envelope Dove";SM("Armisticine","Ceasefire","RES","s",0,100,"tatk-2","Both sides put down what they were holding.");

/* Arsenical Bronze: the tools of the very first smiths. An aurochs, the wild ox those smiths hunted, with horns knapped like early blades. */
addForm("Arsenical Bronze",{n:"#3A2A20",a:"#E8DCC0",rn:"#C8A070",rb:"#6A8A5A",ra:"#E8412C"},"stand",(P,g)=>fShadow(72,112)+
 pt("tail",164,90,fOL("M162 90 Q172 104 168 124",P.n,3)+`<path d="M164 120 l4 10 l4 -10 Z" fill="${P.ndd}" ${SW2}/>`)+
 fLeg("legB",152,104,40,10,P.nd,P.ndd,.5)+fLeg("legB",110,106,38,10,P.nd,P.ndd,1.3)+
 `<path d="M84 98 Q82 64 122 62 Q160 64 166 96 Q162 116 124 118 Q88 118 84 98 Z" fill="${P.n}" ${SW}/><path d="M94 66 Q118 52 146 66 Q130 72 108 74 Z" fill="${P.ndd}"/><path d="M104 104 Q124 112 154 104" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".5"/>`+
 fLeg("legF",142,106,38,10,P.n,P.ndd,0)+fLeg("legF",98,106,38,10,P.n,P.ndd,.8)+
 pt("head",88,84,`<path d="M54 92 L72 94 L70 98 L58 96 Z" fill="${FMOUTH}"/>`+pt("jaw",72,97,`<path d="M72 97 Q62 104 54 96 Q62 100 72 100 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M52 88 Q52 70 70 68 Q90 70 92 88 Q88 98 72 98 Q56 98 52 88 Z" fill="${P.n}" ${SW}/><path d="M54 90 Q54 84 60 84 Q62 92 56 94 Z" fill="${P.ac}" opacity=".6"/>`+
  `<path d="M74 70 Q66 48 44 46 L48 52 L40 54 L50 58 Q62 60 70 74 Z" fill="${P.b}" ${SW2}/><path d="M50 52 l6 2 M54 58 l6 0" stroke="${P.dd}" stroke-width="1.4"/>`+
  `<path d="M86 70 Q96 50 116 44 L114 50 L122 50 L114 56 Q102 60 90 74 Z" fill="${P.d}" ${SW2}/>${E2(70,78,3.8)}`+pt("ear",82,72,`<path d="M80 72 Q90 64 96 70 Q90 76 84 76 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 136 l12 -10 l4 4 l-12 10 Z" fill="${P.b}" ${SW2}/>`)+fG(g,2,`<circle cx="124" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(132,38,6)));
FORM_TITLE["Arsenical Bronze"]="First-Smith Aurochs";SM("Arsenical Bronze","Knapped Horn","SCR","a",75,100,"tdef-1@30","The first bronze edges were shaped like the flint ones they replaced.");

/* Backspin Mix: a carousel must turn backwards for its first spin. A carousel horse, pole and all, galloping in reverse. */
addForm("Backspin Mix",{n:"#F4F0E4",a:"#E8412C",rn:"#2E2E3A",rb:"#E8C060",ra:"#5FE0F0"},"hop",(P,g)=>`<rect x="104" y="6" width="6" height="140" rx="3" fill="${P.b}" ${SW}/>${[20,34,48].map(y=>`<path d="M104 ${y} l6 4" stroke="${P.ll}" stroke-width="3"/>`).join("")}<ellipse cx="107" cy="6" rx="10" ry="4" fill="${P.d}" ${SW2}/>`+fShadow(44,108)+
 pt("tail",150,86,`<path d="M148 84 Q172 80 180 100 Q176 112 166 106 Q168 96 150 94 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",142,100,fOL("M142 100 L156 112 L164 128",P.nd,7)+`<path d="M160 128 h10" stroke="${P.d}" stroke-width="6" stroke-linecap="round"/>`,.0)+
 `<path d="M82 92 Q84 72 112 70 Q146 72 152 92 Q148 108 116 110 Q88 110 82 92 Z" fill="${P.n}" ${SW}/><path d="M96 86 Q112 78 134 80 L132 100 Q112 104 94 98 Z" fill="${P.ac}" ${SW2}/>${[100,112,124].map(x=>`<circle cx="${x}" cy="90" r="2.6" fill="${P.b}" ${SW2}/>`).join("")}`+
 pt("legF",94,100,fOL("M94 100 L76 104 L70 116",P.n,7)+`<path d="M66 116 h10" stroke="${P.d}" stroke-width="6" stroke-linecap="round"/>`)+pt("legF",104,102,fOL("M104 102 L96 120 L100 132",P.n,7),.5)+
 pt("head",88,74,`<path d="M88 76 L76 46 Q74 38 66 40 L52 52 Q48 58 54 60 L66 58 L80 82 Z" fill="${P.n}" ${SW}/><path d="M80 44 Q92 52 96 74 Q90 66 84 58 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M52 54 L60 56" stroke="${FI}" stroke-width="1.6"/>`+pt("jaw",58,58,`<path d="M58 58 Q54 64 50 58 Z" fill="${P.nd}" ${SW2}/>`)+`${E2(64,48,3.6)}`+pt("ear",72,42,`<path d="M70 42 L72 32 L76 42 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 60 q10 -10 20 0" stroke="${P.ac}" stroke-width="2.4" fill="none" marker-end=""/><path d="M30 60 l4 -6 M30 60 l6 2" stroke="${P.ac}" stroke-width="2.4"/>`)+fG(g,2,`<circle cx="118" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(140,30,6)));
FORM_TITLE["Backspin Mix"]="Reversing Carousel Horse";SM("Backspin Mix","Wrong Way Round","STR","a",65,100,"tacc-1@40","The first spin of the day goes backwards. Everyone gets a little dizzy.");

/* Benchane: officially, for customs purposes, a bench. A long low spaniel built like a garden bench, slats and all. */
addForm("Benchane",{n:"#B88A5A",a:"#2E6A3A",rn:"#C8D0E0",rb:"#6A4A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(70)+
 pt("tail",164,98,`<path d="M160 96 Q178 84 186 92 Q180 102 162 104 Z" fill="${P.n}" ${SW2}/>`)+
 [[154,"legB",.5],[120,"legB",1.3]].map(([x,c,d])=>pt(c,x,112,`<path d="M${x-5} 110 L${x-6} 140 L${x+4} 140 L${x+5} 110 Z" fill="${P.ac}" ${SW2}/><path d="M${x-8} 140 h16" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 `<rect x="64" y="90" width="104" height="24" rx="8" fill="${P.n}" ${SW}/>${[72,88,104,120,136,152].map(x=>`<path d="M${x} 92 V112" stroke="${P.nd}" stroke-width="2.4"/>`).join("")}<path d="M66 82 H164" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M66 82 H164" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/>${[74,108,150].map(x=>`<path d="M${x} 82 V92" stroke="${P.ac}" stroke-width="3"/>`).join("")}`+
 `<path d="M96 100 q14 8 30 0" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
 [[146,"legF",0],[86,"legF",.8]].map(([x,c,d])=>pt(c,x,112,`<path d="M${x-5} 110 L${x-6} 140 L${x+4} 140 L${x+5} 110 Z" fill="${P.ac}" ${SW2}/><path d="M${x-8} 140 h16" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 pt("head",68,94,`<path d="M30 96 L48 98 L46 102 L34 100 Z" fill="${FMOUTH}"/>`+pt("jaw",48,101,`<path d="M48 101 Q40 108 32 100 Q40 104 48 104 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 94 Q30 76 50 74 Q70 76 72 94 Q66 104 48 102 Q32 102 28 94 Z" fill="${P.n}" ${SW}/><ellipse cx="29" cy="92" rx="3.4" ry="2.8" fill="${FI}"/>${E2(48,86,4.4)}`+
  pt("ear",60,80,`<path d="M56 80 Q74 76 74 98 Q70 110 62 104 Q60 92 56 86 Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${62+i*3} ${84+i*6} q3 2 6 0" stroke="${P.ndd}" stroke-width="1.2" fill="none"/>`).join("")}`))+
 fG(g,1,`<rect x="20" y="128" width="16" height="12" rx="2" fill="#B88A5A" ${SW2}/><path d="M22 132 h12" stroke="${FI}" stroke-width="1"/>`)+fG(g,2,`<circle cx="114" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(118,58,6)));
FORM_TITLE["Benchane"]="Park Bench Spaniel";SM("Benchane","Take A Seat","STR","g",0,100,"def+1,heal:20","A bench is for sitting down and getting your breath back.");

/* Bonkite: just before the final step, the mixer lid flew off and bonked a supervisor. A box turtle whose shell top flips up like that lid. */
addForm("Bonkite",{n:"#7A8A4A",a:"#E8C060",rn:"#E8D0C0",rb:"#3A5AA8",ra:"#E8412C"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",158,124,`<path d="M154 120 L170 124 L154 130 Z" fill="${P.n}" ${SW2}/>`)+
 [[146,.5],[96,0]].map(([x,d])=>pt("legB",x,124,`<path d="M${x-6} 122 L${x-8} 144 H${x+6} L${x+6} 122 Z" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M70 124 Q72 104 112 102 Q152 104 156 124 Z" fill="${P.b}" ${SW}/><path d="M70 124 H156" stroke="${FI}" stroke-width="4"/><path d="M76 120 Q112 116 150 120" stroke="${P.d}" stroke-width="2" fill="none"/>`+
 pt("ear",150,104,`<path d="M74 104 Q76 70 112 66 Q148 70 152 104 Q112 96 74 104 Z" fill="${P.b}" ${SW}/>${[[96,82],[112,76],[128,82],[104,92],[122,92]].map(([x,y])=>`<path d="M${x-7} ${y} l3.5 -6 h7 l3.5 6 l-3.5 6 h-7 Z" fill="${P.d}" ${SW2}/>`).join("")}<path d="M108 66 Q112 58 116 66" stroke="${FI}" stroke-width="5" fill="none"/><path d="M108 66 Q112 58 116 66" stroke="${P.ll}" stroke-width="2.4" fill="none"/>`)+
 [[132,.5],[86,0]].map(([x,d])=>pt("legF",x,124,`<path d="M${x-6} 122 L${x-8} 145 H${x+6} L${x+6} 122 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",70,116,fOL("M74 118 Q60 116 52 108",P.n,11)+`<path d="M30 104 L46 106 L44 110 L34 108 Z" fill="${FMOUTH}"/>`+pt("beak",46,109,`<path d="M46 109 Q38 114 30 106 Q38 110 46 112 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 102 Q30 90 46 90 Q60 92 60 104 Q56 110 46 108 Q32 108 28 102 Z" fill="${P.n}" ${SW}/>${E2(44,98,4.2)}<path d="M38 88 l-3 -6 M44 86 l0 -7" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,1,`<circle cx="30" cy="70" r="6" fill="none" stroke="${P.ac}" stroke-width="2"/><path d="M26 64 l-3 -4 M34 64 l3 -4" stroke="${P.ac}" stroke-width="2"/>`)+fG(g,2,`<circle cx="112" cy="112" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(112,44,6)));
FORM_TITLE["Bonkite"]="Flip-Lid Box Turtle";SM("Bonkite","Lid Off","DRP","a",75,100,"tacc-1@40","Pressure builds under a lid until something has to give.");

/* Bounceleyite: the trampoline club keeps it locked away since 1996. A sifaka, the dancing lemur, mid-bounce on a little trampoline. */
addForm("Bounceleyite",{n:"#F4F0E4",a:"#6A3A2A",rn:"#3A3A4A",rb:"#E8A060",ra:"#5FE0A0"},"hop",(P,g)=>`<ellipse cx="104" cy="140" rx="40" ry="7" fill="${P.b}" ${SW}/><path d="M68 140 l-6 8 M140 140 l6 8 M104 146 v4" stroke="${FI}" stroke-width="3"/><ellipse cx="104" cy="139" rx="32" ry="4" fill="${P.d}"/>`+
 pt("tail",116,94,fOL("M116 94 Q150 96 160 70 Q166 50 154 40",P.n,7))+
 pt("legB",112,104,fOL("M112 102 Q130 108 124 122 L114 128",P.n,8),.0)+
 `<path d="M88 104 Q82 74 100 64 Q120 66 120 98 Q118 116 104 116 Q90 116 88 104 Z" fill="${P.n}" ${SW}/><path d="M96 70 Q104 64 112 72 L108 100 Q100 104 94 96 Z" fill="${P.ac}" opacity=".85"/>`+
 pt("legF",96,108,fOL("M96 108 Q80 116 88 126 L94 130",P.n,8))+
 pt("armB",112,74,fOL("M112 74 Q132 60 136 40",P.n,6)+`<path d="M134 38 l-4 -4 M136 36 l0 -6 M138 38 l4 -4" stroke="${FI}" stroke-width="1.8"/>`,.4)+
 pt("armF",96,74,fOL("M96 74 Q76 58 72 40",P.n,6)+`<path d="M70 38 l-4 -4 M72 36 l0 -6 M74 38 l4 -4" stroke="${FI}" stroke-width="1.8"/>`)+
 pt("head",104,62,`<circle cx="102" cy="52" r="14" fill="${P.n}" ${SW}/><path d="M92 50 Q96 64 102 64 Q108 64 112 50 Q108 58 102 58 Q96 58 92 50 Z" fill="${P.ac}"/>${E2(96,50,4.4,"#E8A020")}${E2(108,50,4.4,"#E8A020")}<ellipse cx="102" cy="58" rx="2.4" ry="1.8" fill="${FI}"/>`+
  `<path d="M98 62 L106 62 L104 65 L100 65 Z" fill="${FMOUTH}"/>`+pt("jaw",104,64,`<path d="M105 64 Q102 68 99 64 Z" fill="${P.ac}" ${SW2}/>`)+pt("ear",90,44,`<circle cx="89" cy="44" r="3.4" fill="${P.nd}" ${SW2}/>`)+pt("ear",114,44,`<circle cx="115" cy="44" r="3.4" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M40 110 q4 -8 8 0 M156 110 q4 -8 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(150,24,6)));
FORM_TITLE["Bounceleyite"]="Trampoline Sifaka";SM("Bounceleyite","Rebound","STR","a",70,100,"spd+1","A trampoline gives back the energy you bring down into it.");

/* Brackford Hush: a wartime depot had a 'crate whisperer'. A bat-eared fox, ears forward, whispering to the crate under its paws. */
addForm("Brackford Hush",{n:"#C8A070",a:"#3A2A24",rn:"#C8D8E8",rb:"#3A6A8A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="34" y="118" width="38" height="28" rx="2" fill="#B88A50" ${SW}/><path d="M34 128 h38 M34 138 h38 M44 118 v28" stroke="#8A6030" stroke-width="2"/>`+fShadow(48,118)+
 pt("tail",158,104,`<path d="M156 102 Q182 98 186 118 Q178 126 166 118 Q160 112 154 110 Z" fill="${P.n}" ${SW}/><path d="M176 112 Q184 116 184 122" stroke="${P.ac}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",148,114,30,7,P.nd,P.ac,.5)+fLeg("legB",116,116,28,7,P.nd,P.ac,1.3)+
 `<path d="M96 108 Q96 86 124 84 Q156 86 160 106 Q156 122 126 122 Q100 122 96 108 Z" fill="${P.n}" ${SW}/><path d="M102 114 Q126 124 152 114" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".7"/>`+
 fLeg("legF",140,116,28,7,P.n,P.ac,0)+pt("legF",104,114,fOL("M104 114 L86 118 L72 118",P.n,7)+`<ellipse cx="70" cy="118" rx="5" ry="3.6" fill="${P.ac}" ${SW2}/>`,.8)+
 pt("head",92,98,`<path d="M56 108 L70 108 L68 112 L58 111 Z" fill="${FMOUTH}"/>`+pt("jaw",70,111,`<path d="M70 111 Q62 116 56 110 Q62 113 70 113 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M54 104 Q56 88 74 86 Q94 88 96 102 Q92 112 74 112 Q58 112 54 104 Z" fill="${P.n}" ${SW}/><path d="M54 104 Q58 96 66 98 Q66 108 58 108 Z" fill="${P.ac}"/><ellipse cx="54" cy="103" rx="2.4" ry="2" fill="${FI}"/>`+
  `<path d="M70 94 Q74 92 80 96" stroke="${P.ac}" stroke-width="3" fill="none"/>${E2(72,98,3.6)}`+
  pt("ear",80,88,`<path d="M74 90 Q60 54 74 46 Q92 58 88 90 Z" fill="${P.n}" ${SW2}/><path d="M77 84 Q68 60 76 54" stroke="${P.nll}" stroke-width="4" fill="none"/>`)+pt("ear",88,90,`<path d="M84 90 Q90 54 106 52 Q110 70 94 94 Z" fill="${P.nd}" ${SW2}/>`,.4)+
  `<path d="M46 98 q-4 -4 0 -8 M40 100 q-6 -6 0 -12" stroke="${P.l}" stroke-width="1.6" fill="none" opacity=".8"/>`)+
 fG(g,1,`<path d="M44 108 q4 -4 8 0" stroke="${FI}" stroke-width="1.6" fill="none"/>`)+fG(g,2,`<circle cx="126" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,58,6)));
FORM_TITLE["Brackford Hush"]="Crate-Whisperer Fox";SM("Brackford Hush","Whisper","RES","s",0,100,"tatk-1,tacc-1","Say it quietly enough and it sounds like a secret.");

/* Brackite: Ottilie Brack's diary mentions it once: 'finally, finally, finally.' A bookworm crawling out of that diary. */
addForm("Brackite",{n:"#E8B0A0",a:"#6A2A3A",rn:"#C8E0C0",rb:"#3A3A6A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60,104)+
 `<path d="M50 144 L58 108 L126 112 L120 146 Z" fill="${P.ac}" ${SW}/><path d="M58 108 L126 112 L132 104 L64 100 Z" fill="#F4F0E4" ${SW2}/><path d="M64 100 L132 104" stroke="${FI}" stroke-width="1.4"/>${[0,1,2,3,4].map(i=>`<path d="M${68+i*12} ${103+i*.7} h8" stroke="#8A8A9A" stroke-width="1.2"/>`).join("")}<path d="M90 110 L88 144" stroke="${P.dd}" stroke-width="1.6"/><path d="M60 126 h18 M60 132 h14" stroke="#F2C94C" stroke-width="2"/>`+
 pt("tail",128,106,`${[0,1,2,3].map(i=>`<circle cx="${130+i*9}" cy="${104-Math.sin(i)*6}" r="${8-i}" fill="${P.n}" ${SW}/>`).join("")}`)+
 `${[0,1,2].map(i=>`<circle cx="${112-i*12}" cy="${92-i*10}" r="${10+i}" fill="${P.n}" ${SW}/><path d="M${104-i*12} ${92-i*10} q8 4 16 0" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("head",88,70,`<circle cx="82" cy="62" r="14" fill="${P.n}" ${SW}/>${E2(76,58,4.4)}${E2(88,56,4.2)}<circle cx="76" cy="58" r="7" fill="none" stroke="${FI}" stroke-width="1.6"/><circle cx="88" cy="56" r="7" fill="none" stroke="${FI}" stroke-width="1.6"/><path d="M83 57 h-1" stroke="${FI}" stroke-width="1.6"/>`+
  HMOUTH(70,66,78,P,4)+`<path d="M60 70 q4 -6 10 -2" stroke="${P.nd}" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<path d="M30 40 q6 -6 12 0 q6 -6 12 0" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="112" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(120,36,6)));
FORM_TITLE["Brackite"]="Diary Bookworm";SM("Brackite","Finally","STR","a",80,100,"selfspd-1","Some things take a very long time, and then they happen all at once.");

/* Brask's Squeezebox: smuggled out of a port inside an accordion. A dachshund whose long body is the accordion's bellows. */
addForm("Brask's Squeezebox",{n:"#8A3A2A",a:"#F4F0E4",rn:"#3A4A6A",rb:"#E8C060",ra:"#E8412C"},"stand",(P,g)=>fShadow(76)+
 pt("tail",172,104,`<path d="M170 104 Q186 92 190 96" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M170 104 Q186 92 190 96" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",160,120,22,7,P.nd,P.ndd,.5)+fLeg("legB",76,120,22,7,P.nd,P.ndd,1.3)+
 `<rect x="140" y="96" width="32" height="30" rx="6" fill="${P.n}" ${SW}/><rect x="60" y="96" width="32" height="30" rx="6" fill="${P.n}" ${SW}/>`+
 pt("sway",116,110,`<path d="M90 98 ${[0,1,2,3,4,5].map(i=>`L${96+i*8} ${i%2?92:100}`).join(" ")} L142 98 L142 124 ${[5,4,3,2,1,0].map(i=>`L${96+i*8} ${i%2?130:122}`).join(" ")} L90 124 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${96+i*8} ${i%2?92:100} V${i%2?130:122}" stroke="${P.dd}" stroke-width="1.4"/>`).join("")}`)+
 `${[66,74,82].map(x=>`<circle cx="${x}" cy="104" r="2" fill="${P.ll}" ${SW2}/><circle cx="${x}" cy="112" r="2" fill="${P.ll}" ${SW2}/>`).join("")}`+
 fLeg("legF",152,122,20,7,P.n,P.ndd,0)+fLeg("legF",68,122,20,7,P.n,P.ndd,.8)+
 pt("head",62,104,`<path d="M20 104 L40 106 L38 110 L24 108 Z" fill="${FMOUTH}"/>`+pt("jaw",40,109,`<path d="M40 109 Q30 116 22 108 Q30 112 40 112 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M18 100 Q22 84 44 82 Q64 86 64 100 Q58 110 40 110 Q22 110 18 100 Z" fill="${P.n}" ${SW}/><ellipse cx="19" cy="99" rx="3" ry="2.6" fill="${FI}"/>${E2(42,92,4.2)}`+
  pt("ear",54,86,`<path d="M50 86 Q66 84 64 108 Q58 112 54 104 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M190 70 v-12 l8 3" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="188" cy="70" r="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="156" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(116,70,6)));
FORM_TITLE["Brask's Squeezebox"]="Accordion Dachshund";SM("Brask's Squeezebox","One Tune","RES","a",70,100,"multi:1-3","He only ever played the one tune after that. He played it very well.");
