/* =============== YOUR ROOM ===============
   Off the Institute's locker room there's a door marked STAFF QUARTERS, and behind it a room that's yours: a bed, a desk, a lamp, and a
   lot of empty floor. Furnish it however you like. Everything you've done out in the field turns up as something for it (a seal plaque
   for every Assay Hall, the besom off Hollowmere Hill, a sealed vial on a stand that's watching you) and display cases hold any alloy
   you've registered. Plain furniture can be bought from the Quartermaster's catalogue with points earned registering alloys.
   EDIT ROOM puts things down, picks them up, moves them, and changes the walls and floor. */
const RM={W:16,H:11,door:[7,10],spawn:[7,9],edit:false,carry:null,zone:null};
const RINK="#121B40";
const rmS=(o)=>store.get("wta_room",null)||{items:[{id:"bed",x:2,y:2},{id:"desk",x:11,y:2},{id:"chair",x:11,y:3},{id:"lamp",x:13,y:2},{id:"shelf",x:5,y:1},{id:"case",x:9,y:1,a:null},{id:"rug",x:7,y:6}],wall:"cream",floor:"boards",owned:[]};
const rmSave=st=>store.set("wta_room",st);
/* points to spend: every alloy you register adds its round's points; an old save starts with a little for everything already registered */
const rmPts=()=>{let p=store.get("wta_room_pts",null);if(p===null){p=(S.caught?S.caught.size:0)*10;store.set("wta_room_pts",p)}return p};
{const _w=win;win=function(){const r=S.r;_w();if(r&&r.won&&!(typeof TUT!=="undefined"&&TUT.on)){store.set("wta_room_pts",rmPts()+Math.max(0,r.pts|0))}}}

/* ---- drawing kit ---- */
const rsh=(w)=>`<ellipse cx="20" cy="38" rx="${w||14}" ry="2.4" fill="#000" opacity=".22"/>`;
const rk=(w)=>`stroke="${RINK}" stroke-width="${w||1.2}" stroke-linejoin="round"`;
const SEAL_COL={"z-mine":"#8A5A3A","z-scrap":"#6A5A4A","z-wreck":"#3A5A7A","z-volcano":"#7A3A2A","z-vault":"#8A6A2A","z-reactor":"#4A6A5A","z-glacier":"#5A7AA0","z-crater":"#5A4A7A"};
const plaque=(col,inner)=>`<rect x="8" y="9" width="24" height="24" rx="3" fill="#6A4A2A" ${rk()}/><rect x="10.6" y="11.6" width="18.8" height="18.8" rx="2" fill="${col}"/><circle cx="20" cy="21" r="7.4" fill="#F2C94C" ${rk(1)}/>${inner}<path d="M20 4 L20 9" stroke="#5A4A3A" stroke-width=".8"/><circle cx="20" cy="4" r="1" fill="#8A8A92"/>`;
/* ---- the catalogue: everything that can go in the room ---- */
const SEAL_SYM={"z-mine":`<path d="M16 25 L20 17 L24 25 Z M18.6 21 L21.4 21" stroke="#5A3A10" stroke-width="1.2" fill="none"/>`,"z-scrap":`<circle cx="20" cy="21" r="3.6" fill="none" stroke="#5A3A10" stroke-width="1.6" stroke-dasharray="2 1.4"/>`,"z-wreck":`<path d="M15.6 22 Q18 19 20 22 Q22 25 24.4 22" stroke="#5A3A10" stroke-width="1.4" fill="none"/>`,"z-volcano":`<path d="M20 16 Q16.6 21 20 25.6 Q23.4 21 20 16 Z" fill="#C8641A"/>`,"z-vault":`<path d="M16 18 H24 M17 18 V24 M20 18 V24 M23 18 V24 M15.6 24.4 H24.4" stroke="#5A3A10" stroke-width="1.1"/>`,"z-reactor":`<circle cx="20" cy="21" r="1.4" fill="#5A3A10"/>${[0,120,240].map(a=>`<path d="M20 21 L${(20+4.4*Math.cos((a-90)*Math.PI/180)).toFixed(1)} ${(21+4.4*Math.sin((a-90)*Math.PI/180)).toFixed(1)}" stroke="#5A3A10" stroke-width="2.4"/>`).join("")}`,"z-glacier":`<path d="M20 16 V26 M15.6 18.6 L24.4 23.4 M24.4 18.6 L15.6 23.4" stroke="#5A3A10" stroke-width="1.2"/>`,"z-crater":`<path d="M20 15.6 l1.4 3.8 4 .2 -3.2 2.4 1.2 3.8 -3.4 -2.2 -3.4 2.2 1.2 -3.8 -3.2 -2.4 4 -.2 Z" fill="#5A3A10"/>`};
const ROOM_ITEMS=[
 /* ---- what everyone starts with ---- */
 {id:"bed",name:"Iron Bed",cat:"Furniture",w:2,start:1,desc:"An Institute-issue iron bedstead with a patchwork quilt. It creaks.",
  svg:`<g transform="scale(2 1)"><ellipse cx="20" cy="38" rx="17" ry="2.2" fill="#000" opacity=".2"/></g><rect x="6" y="10" width="4" height="28" fill="#4A4E5A" ${rk()}/><rect x="70" y="16" width="4" height="22" fill="#4A4E5A" ${rk()}/><rect x="8" y="20" width="64" height="12" rx="2" fill="#F2EDE0" ${rk()}/><rect x="10" y="17" width="14" height="7" rx="3" fill="#FFFFFF" ${rk(1)}/>${[0,1,2,3,4].map(i=>`<rect x="${26+i*9}" y="19" width="9" height="13" fill="${["#C8643A","#3A7AB8","#E8B840","#6AA84A","#B84A6A"][i]}" opacity=".85"/>`).join("")}<path d="M26 19 H71" stroke="${RINK}" stroke-width=".8"/><path d="M6 12 H10 M70 18 H74" stroke="#7A7E8A" stroke-width="1.4"/>`,use:["You sit on the bed. It creaks, the same as it did the first night.","You could sleep for a week. You won't. There's rubble out there."]},
 {id:"desk",name:"Writing Desk",cat:"Furniture",w:2,start:1,desc:"An oak desk with a green blotter and one drawer that sticks.",
  svg:`<ellipse cx="40" cy="38" rx="32" ry="2.4" fill="#000" opacity=".2"/><rect x="6" y="14" width="68" height="6" rx="1" fill="#8A5A2E" ${rk()}/><rect x="8" y="20" width="22" height="16" fill="#7A4E26" ${rk()}/><rect x="10" y="23" width="18" height="5" rx="1" fill="#8A5A2E" ${rk(.8)}/><circle cx="19" cy="25.5" r=".9" fill="#E8C860"/><path d="M70 20 V36" stroke="${RINK}" stroke-width="2.4"/><rect x="34" y="11" width="22" height="4" fill="#3A6A3A" ${rk(.8)}/><rect x="60" y="9" width="7" height="5" fill="#F4ECD8" ${rk(.6)}/>`,use:["Your desk. The blotter's covered in element symbols and a doodle of Dr. Marlow that you'll deny drawing."]},
 {id:"chair",name:"Desk Chair",cat:"Furniture",start:1,desc:"A bentwood chair. Wobbles on the left.",
  svg:`${rsh(9)}<path d="M13 6 Q12 0 20 0 Q28 0 27 6 L27 22" fill="none" stroke="#6A4022" stroke-width="2.6"/><rect x="11" y="20" width="18" height="4" rx="1" fill="#8A5A2E" ${rk()}/><path d="M13 24 L12 37 M27 24 L28 37 M15 24 L16 34 M25 24 L24 34" stroke="#6A4022" stroke-width="2"/>`},
 {id:"lamp",name:"Desk Lamp",cat:"Furniture",start:1,desc:"A brass lamp with a green shade. It's always been on.",glow:1,
  svg:`${rsh(7)}<circle cx="20" cy="12" r="14" fill="#FFE8A0" opacity=".25"/><rect x="14" y="33" width="12" height="4" rx="1" fill="#C8A040" ${rk()}/><path d="M20 33 V18" stroke="#B8902A" stroke-width="2"/><path d="M11 18 Q20 6 29 18 Z" fill="#3A7A4A" ${rk()}/><path d="M13 18 H27" stroke="#FFE8A0" stroke-width="1.6"/>`},
 {id:"shelf",name:"Bookshelf",cat:"Furniture",start:1,tall:1,desc:"Field guides, a periodic table with your notes in the margins, and a dictionary propping up the end.",
  svg:`${rsh(15)}<rect x="6" y="-14" width="28" height="51" fill="#7A4E26" ${rk()}/>${[-10,4,18].map((y,r)=>`<path d="M7 ${y+12} H33" stroke="${RINK}" stroke-width="1.2"/>`+Array.from({length:6},(_,i)=>`<rect x="${8.4+i*4}" y="${y+1+(i%3)}" width="3.4" height="${11-(i%3)}" fill="${["#B84A3A","#3A6AA8","#E8B840","#4A8A4A","#8A4AA8","#C87A3A"][(i+r*2)%6]}" ${rk(.5)}/>`).join("")).join("")}`,use:["Every field guide the Institute ever printed, and three it didn't."]},
 {id:"case",name:"Display Case",cat:"Display",start:1,display:1,desc:"A glass case on a plinth for showing off a registered alloy. Interact with it to choose which.",
  svg:`${rsh(11)}<rect x="10" y="26" width="20" height="11" fill="#6A4A2A" ${rk()}/><path d="M11 26 V6 H29 V26" fill="#DDF0FF" fill-opacity=".25" ${rk(1)}/><path d="M13 9 L16 6" stroke="#FFFFFF" stroke-width="1.2" opacity=".7"/>`},
 {id:"rug",name:"Rag Rug",cat:"Floor",start:1,flat:1,w:2,desc:"Braided from old lab coats. You can tell which ones.",
  svg:`<ellipse cx="40" cy="22" rx="36" ry="14" fill="#C8B490" ${rk(1)}/><ellipse cx="40" cy="22" rx="28" ry="10" fill="none" stroke="#8A6A9A" stroke-width="2.4"/><ellipse cx="40" cy="22" rx="20" ry="7" fill="none" stroke="#5A8AB8" stroke-width="2.4"/><ellipse cx="40" cy="22" rx="11" ry="3.8" fill="#E8DCC0"/>`},
 /* ---- earned out in the field ---- */
 {id:"brassrod",name:"Your First Brass Rod",cat:"Trophy",desc:"The rod from your very first morning, on a little stand.",how:"Finish the tutorial.",open:()=>!!store.get("wta_tut",0),
  svg:`${rsh(9)}<rect x="12" y="30" width="16" height="7" rx="1" fill="#5A3A1E" ${rk()}/><g transform="rotate(-24 20 22)"><rect x="9" y="19" width="22" height="6" rx="3" fill="#D8B050" ${rk()}/><path d="M12 20.4 H28" stroke="#FFF0B0" stroke-width="1"/></g>`,use:["The brass rod from your first morning. You knew nothing. You still know very little. But more than that."]},
 {id:"rank",name:"Field Commission",cat:"Wall",wall:1,desc:"Your field rank, framed, signed by Dr. Marlow in very large handwriting.",how:"Earn your first field promotion.",open:()=>typeof FO_RANKS!=="undefined"&&typeof foRank==="function"&&FO_RANKS.indexOf(foRank())>=1,
  svg:`<rect x="8" y="8" width="24" height="20" fill="#C8A040" ${rk()}/><rect x="10.6" y="10.6" width="18.8" height="14.8" fill="#F4ECD8"/><path d="M13 14 H27 M13 17 H24 M13 20 H26" stroke="#8A7A5A" stroke-width=".8"/><circle cx="25" cy="22.6" r="2" fill="#B83A2A"/><path d="M20 3 L14 8 M20 3 L26 8" stroke="#5A4A3A" stroke-width=".7"/>`,use:()=>[`Field rank: ${typeof foRank==="function"?foRank().toUpperCase():"RECRUIT"}. Signed by Dr. Marlow, and underlined three times.`]},
 {id:"satchel",name:"Marlow's Old Satchel",cat:"Trophy",desc:"Dr. Marlow's first field satchel. He gave it to you 'on loan'. He has not mentioned it since.",how:"Reach the rank of Field Staff.",open:()=>typeof FO_RANKS!=="undefined"&&typeof foRank==="function"&&FO_RANKS.indexOf(foRank())>=3,
  svg:`${rsh(10)}<path d="M10 18 Q20 4 30 18" stroke="#6A4022" stroke-width="2" fill="none"/><rect x="9" y="18" width="22" height="18" rx="3" fill="#8A5A2E" ${rk()}/><path d="M9 22 H31" stroke="${RINK}" stroke-width="1"/><rect x="18" y="22" width="4" height="5" fill="#C8A040" ${rk(.6)}/>`},
 {id:"portrait",name:"The Founder's Portrait",cat:"Wall",wall:1,desc:"A copy of the founder's portrait from the hall. You know whose face it is now.",how:"Finish the founder's story.",open:()=>!!store.get("wta_fin_done",0),
  svg:`<rect x="9" y="5" width="22" height="28" fill="#8A6A2A" ${rk()}/><rect x="11.6" y="7.6" width="16.8" height="22.8" fill="#4A3A2E"/><circle cx="20" cy="16" r="4.4" fill="#E8C8A0"/><path d="M14 30 Q20 21 26 30 Z" fill="#2A2A3A"/><circle cx="18.3" cy="16" r="1.4" fill="none" stroke="#2A2A2A" stroke-width=".6"/><circle cx="21.7" cy="16" r="1.4" fill="none" stroke="#2A2A2A" stroke-width=".6"/>`,use:["The founder, young, round spectacles. You know who he grew up to be. He's still looking like he's about to say something."]},
 {id:"vellbox",name:"Deposit Box 001",cat:"Trophy",desc:"Chronicler Vell's deposit box, empty now, with the Vault's compliments.",how:"Open box 001 in the Gilded Vault.",open:()=>typeof Q!=="undefined"&&Q.flag&&Q.flag("half2"),
  svg:`${rsh(10)}<rect x="10" y="20" width="20" height="16" fill="#8A7A5A" ${rk()}/><rect x="12" y="23" width="16" height="10" fill="#6A5A3A" ${rk(.8)}/><circle cx="20" cy="28" r="2.4" fill="#C8A040" ${rk(.6)}/><path d="M16 35 H24" stroke="#C8A040" stroke-width="1"/>`},
 {id:"governor",name:"Governor's Cushion",cat:"Trophy",desc:"A velvet cushion with a ring-shaped dent in it, for the Governor when you're not wearing it.",how:"Get the Governor ring.",open:()=>typeof ocOwned==="function"&&ocOwned(),
  svg:`${rsh(9)}<rect x="12" y="30" width="16" height="7" fill="#5A3A1E" ${rk()}/><ellipse cx="20" cy="28" rx="11" ry="5" fill="#7A2A4A" ${rk()}/><ellipse cx="20" cy="26.6" rx="4.4" ry="2" fill="none" stroke="#E8C860" stroke-width="1.6"/><circle cx="20" cy="25" r="1.4" fill="#F4F0E4" ${rk(.4)}/>`},
 {id:"pitlamp",name:"Foreman Dray's Lamp",cat:"Trophy",desc:"The brass pit lamp you found at the end of the top tunnel. Dray says keep it; he's got his dad's back.",how:"Do Foreman Dray's favour in the mine.",open:()=>{try{return TQ("lamp")>=2}catch(e){return false}},glow:1,
  svg:`${rsh(7)}<circle cx="20" cy="20" r="12" fill="#FFE8A0" opacity=".2"/><path d="M15 12 Q20 6 25 12" stroke="#8A6A2A" stroke-width="1.4" fill="none"/><rect x="14" y="13" width="12" height="20" rx="3" fill="#C8A040" ${rk()}/><rect x="16" y="16" width="8" height="10" rx="1" fill="#FFE8A0"/><rect x="13" y="32" width="14" height="5" rx="1" fill="#8A6A2A" ${rk()}/>`},
 {id:"toolrack",name:"Tool Rack",cat:"Wall",wall:1,desc:"Hooks for everything you carry: the crowbar, the pick, the boots, the lamp.",how:"Get any field tool.",open:()=>typeof toolList==="function"&&toolList().length>0,
  svg:`<rect x="4" y="10" width="32" height="4" fill="#6A4022" ${rk()}/>${[9,17,25,32].map(x=>`<path d="M${x} 14 v3" stroke="#4A4A52" stroke-width="1.2"/>`).join("")}<path d="M9 17 L7 31 M7 31 L10 31" stroke="#5A5A62" stroke-width="2" fill="none"/><path d="M17 17 L17 27 M13 18 Q17 15 21 18" stroke="#6A6A72" stroke-width="1.8" fill="none"/><path d="M23 17 L23 27 L28 27 L28 24" fill="#3A4A5A" ${rk(.8)}/>`},
 {id:"syndcap",name:"Syndicate Cap",cat:"Trophy",desc:"A flat cap off one of the Slag Syndicate, hung on a hat stand. They'll want it back. They're not getting it.",how:"Win a showdown at the Slag Works.",open:()=>typeof slagWins==="function"&&slagWins()>=1,tall:1,
  svg:`${rsh(8)}<path d="M20 37 V0" stroke="#5A3A1E" stroke-width="2"/><path d="M14 37 H26" stroke="#5A3A1E" stroke-width="2.4"/><path d="M13 -2 Q20 -8 27 -2 L29 1 Q20 -1 11 1 Z" fill="#26262C" ${rk(.9)}/><path d="M16 4 L20 0 L24 4" stroke="#5A3A1E" stroke-width="1.4" fill="none"/>`},
 {id:"kiln",name:"Kiln-Brick Stove",cat:"Furniture",desc:"A little stove built from bricks off the Slag Works' kiln. It's never cold.",how:"Register the Kiln Heart.",open:()=>S.caught&&S.caught.has("Kiln Heart"),glow:1,
  svg:`${rsh(12)}<rect x="8" y="12" width="24" height="25" fill="#A8826A" ${rk()}/>${[16,22,28].map(y=>`<path d="M8 ${y} H32" stroke="#6A4A3A" stroke-width=".8"/>`).join("")}<rect x="13" y="22" width="14" height="10" rx="2" fill="#2A1A10" ${rk(.8)}/><path d="M15 31 Q20 24 25 31" fill="#FF8A2A"/><rect x="16" y="2" width="6" height="10" fill="#8A6A5A" ${rk()}/>`},
 {id:"trunk",name:"Guising Trunk",cat:"Event",desc:"Hollowmere's dressing-up trunk. The sheet ghost is on top. Somebody's put the tattie bogle's hat in here again.",how:"Dress up for Lantern Night.",open:()=>!!store.get("wta_lnt_cos",null),
  svg:`${rsh(13)}<rect x="7" y="20" width="26" height="17" rx="2" fill="#7A4A2A" ${rk()}/><path d="M7 20 Q20 10 33 20" fill="#8A5A3A" ${rk()}/><path d="M12 18 Q16 12 22 14" stroke="#F4F2EC" stroke-width="4" fill="none"/><rect x="18" y="24" width="4" height="5" fill="#C8A040" ${rk(.6)}/>`},
 {id:"neep",name:"Neep Lantern",cat:"Event",desc:"A carved neep with a candle in it, the old Hollowmere way. Its grin is slightly lopsided.",how:"Light every neep lantern on every map.",open:()=>{try{return LNT_NEEPS().every(k=>lntLit().has(k))}catch(e){return false}},glow:1,
  svg:`${rsh(8)}<circle cx="20" cy="24" r="12" fill="#FFB43A" opacity=".2"/><ellipse cx="20" cy="27" rx="10" ry="9" fill="#E8DCB8" ${rk()}/><path d="M15 25 L17 22 L18.4 26 Z M22 26 L23.4 22 L25.4 25 Z M14 30 Q20 34 26 30 L24 29 L22 31 L20 29 L18 31 L16 29 Z" fill="#FFB43A"/><path d="M18 18 Q17 13 14 12 M22 18 Q24 13 27 12" stroke="#4A7A3A" stroke-width="1.6" fill="none"/>`},
 {id:"pumpkin",name:"Carved Pumpkin",cat:"Event",desc:"A carved pumpkin, the way the rest of the country does it. Hollowmere disapproves, quietly.",how:"Visit Hollowmere on Lantern Night.",open:()=>{try{return !!lntF("hm")}catch(e){return false}},glow:1,
  svg:`${rsh(10)}<circle cx="20" cy="26" r="12" fill="#FFB43A" opacity=".2"/><ellipse cx="13" cy="28" rx="7" ry="8" fill="#C8641A" ${rk()}/><ellipse cx="27" cy="28" rx="7" ry="8" fill="#C8641A" ${rk()}/><ellipse cx="20" cy="28" rx="8" ry="8.4" fill="#E8862A" ${rk()}/><path d="M15 26 L17.6 23 L18.6 27 Z M22 27 L22.6 23 L25 26 Z M14 30.6 L16.6 33 L18 31.4 L20 33.6 L22 31.4 L23.4 33 L26 30.6 Q20 36 14 30.6 Z" fill="#FFD27A"/><path d="M20 20 Q21 16 23 15" stroke="#4A6A24" stroke-width="2" fill="none"/>`},
 {id:"besom",name:"The Old Besom",cat:"Event",desc:"The besom off the top of Hollowmere Hill, leaning in the corner. It's facing the window. It's always facing the window.",how:"Register Besomite.",open:()=>S.caught&&S.caught.has("Besomite"),tall:1,
  svg:`${rsh(7)}<path d="M18 -10 L22 26" stroke="#8A5A2A" stroke-width="2.6"/><path d="M16 26 L28 26 L32 38 L12 38 Z" fill="#C8A060" ${rk()}/>${[15,19,23,27].map(x=>`<path d="M${x} 27 L${x-1+((x-21)/3)} 37" stroke="#8A6A3A" stroke-width=".8"/>`).join("")}<path d="M15.6 26 H28.4" stroke="#5A3A1A" stroke-width="2"/>`},
 {id:"sconce",name:"Candle-Antler Sconce",cat:"Wall",wall:1,desc:"A shed antler from the thing that stands over the last lantern, with a candle on every tine. They don't burn down.",how:"Register Wickwarden.",open:()=>S.caught&&S.caught.has("Wickwarden"),glow:1,
  svg:`<circle cx="20" cy="14" r="14" fill="#FFB43A" opacity=".18"/><rect x="15" y="24" width="10" height="10" rx="2" fill="#6A4A2A" ${rk()}/><path d="M20 26 Q14 18 10 12 M14 18 L12 10 M20 26 Q26 18 30 12 M26 18 L28 10 M20 26 V14" stroke="#C8BCA0" stroke-width="2" fill="none" stroke-linecap="round"/>${[[10,12],[12,10],[30,12],[28,10],[20,14]].map(([x,y])=>`<rect x="${x-1}" y="${y-4}" width="2" height="4" fill="#F4ECD8"/><path class="lnt-flame" d="M${x} ${y-8} Q${x+1.4} ${y-5.4} ${x} ${y-4} Q${x-1.4} ${y-5.4} ${x} ${y-8} Z" fill="#FFB43A"/>`).join("")}`},
 {id:"gwvial",name:"The Vial on the Stand",cat:"Event",desc:"The Gutterwick's vial, contained, on a little brass stand. It's empty. Something in it is looking at you anyway.",how:"Register the Gutterwick.",open:()=>S.caught&&S.caught.has(typeof GW_NAME!=="undefined"?GW_NAME:"Gutterwick"),
  svg:`${rsh(8)}<rect x="12" y="33" width="16" height="4" fill="#C8A040" ${rk()}/><path d="M14 33 L16 29 H24 L26 33" fill="none" stroke="#C8A040" stroke-width="1.4"/><rect x="16" y="8" width="8" height="21" rx="4" fill="#0A0814" ${rk()}/><rect x="15.4" y="6" width="9.2" height="3" fill="#6A4A2A" ${rk(.6)}/><circle class="rm-gweye" cx="18.6" cy="16" r=".9" fill="#FFFFFF"/><circle class="rm-gweye" cx="21.4" cy="16" r=".9" fill="#FFFFFF"/>`,use:["It's empty. It's contained. It's looking at you."]},
 {id:"shadowjar",name:"A Shadow in a Jar",cat:"Event",desc:"A jam jar with a lid screwed on tight and a little bit of dark inside. It moves when you're not looking.",how:"Gather 25 traces of shadow.",open:()=>(store.get("wta_shd_trace",0)||0)>=25,
  svg:`${rsh(7)}<rect x="12" y="16" width="16" height="21" rx="3" fill="#DDF0FF" fill-opacity=".35" ${rk()}/><rect x="11" y="13" width="18" height="4" rx="1" fill="#C8A040" ${rk(.8)}/><path class="rm-jar" d="M16 33 Q15 24 20 22 Q25 24 24 33 Z" fill="#0A0814"/><circle cx="18.6" cy="26" r=".7" fill="#FFFFFF"/><circle cx="21.4" cy="26" r=".7" fill="#FFFFFF"/>`},
 {id:"seals",name:"Assayer's Cup",cat:"Trophy",desc:"A silver cup with all eight hall seals engraved round it. The Assayers clubbed together.",how:"Earn all eight Assay Hall seals.",open:()=>{try{return asData().seals.length>=8}catch(e){return false}},
  svg:`${rsh(9)}<rect x="13" y="32" width="14" height="5" fill="#5A3A1E" ${rk()}/><path d="M18 32 V27 H22 V32" fill="#C8C8D0" ${rk(.8)}/><path d="M11 10 H29 Q29 24 20 26 Q11 24 11 10 Z" fill="#D8D8E0" ${rk()}/><path d="M11 13 Q6 13 7 18 Q8 21 12 20 M29 13 Q34 13 33 18 Q32 21 28 20" stroke="#B8B8C0" stroke-width="1.6" fill="none"/><path d="M13 12 L15 22" stroke="#FFFFFF" stroke-width="1.2" opacity=".7"/>`},
 /* ---- a plaque for each Assay Hall's seal ---- */
 ...["z-mine","z-scrap","z-wreck","z-volcano","z-vault","z-reactor","z-glacier","z-crater"].map(z=>({id:"seal_"+z,name:(typeof GYMS!=="undefined"&&GYMS[z]?GYMS[z].seal:"Seal")+" Plaque",cat:"Wall",wall:1,desc:`The ${typeof GYMS!=="undefined"&&GYMS[z]?GYMS[z].seal:"seal"}, mounted on a board, from the ${typeof GYMS!=="undefined"&&GYMS[z]?GYMS[z].hall.toLowerCase().replace(/(^|\s)\S/g,m=>m.toUpperCase()):"hall"}.`,how:`Earn the ${typeof GYMS!=="undefined"&&GYMS[z]?GYMS[z].seal:"seal"}.`,
   open:()=>{try{return asData().seals.includes(z)}catch(e){return false}},svg:plaque(SEAL_COL[z],SEAL_SYM[z])})),
 /* ---- the Quartermaster's catalogue ---- */
 {id:"armchair",name:"Armchair",cat:"Furniture",price:150,desc:"Deep, worn and mustard-coloured. It was in the common room until somebody spilled tea on it.",
  svg:`${rsh(14)}<rect x="8" y="10" width="24" height="16" rx="5" fill="#C8A040" ${rk()}/><rect x="5" y="18" width="8" height="16" rx="3" fill="#B8902A" ${rk()}/><rect x="27" y="18" width="8" height="16" rx="3" fill="#B8902A" ${rk()}/><rect x="11" y="24" width="18" height="9" rx="2" fill="#D8B050" ${rk()}/><path d="M8 34 V37 M32 34 V37" stroke="#5A3A1E" stroke-width="2"/><ellipse cx="22" cy="28" rx="3" ry="1.6" fill="#8A6A2A" opacity=".4"/>`,use:["You sink into the armchair. There's a tea stain the exact shape of the Cove."]},
 {id:"fern",name:"Potted Fern",cat:"Furniture",price:80,desc:"A fern in a cracked crucible. It thrives on neglect.",
  svg:`${rsh(8)}<path d="M13 27 L15 37 H25 L27 27 Z" fill="#C86A3A" ${rk()}/><path d="M17 31 L19 29 L18 33" stroke="#8A3A1A" stroke-width=".6" fill="none"/>${[[-40,10],[-15,13],[10,14],[35,12],[-28,6],[22,7]].map(([a,l])=>`<path d="M20 27 Q${20+Math.sin(a*Math.PI/180)*l*.5} ${27-l*.8} ${20+Math.sin(a*Math.PI/180)*l*1.1} ${27-l*1.2}" stroke="#3A8A3A" stroke-width="2.4" fill="none" stroke-linecap="round"/>`).join("")}`},
 {id:"cactus",name:"Cactus",cat:"Furniture",price:60,desc:"It came back from the Caldera in somebody's boot.",
  svg:`${rsh(6)}<rect x="14" y="29" width="12" height="8" fill="#C86A3A" ${rk()}/><path d="M17 29 V14 Q17 10 20 10 Q23 10 23 14 V29 Z" fill="#4A8A3A" ${rk()}/><path d="M17 20 H14 V16 M23 22 H26 V17" stroke="#4A8A3A" stroke-width="2.6" fill="none" stroke-linecap="round"/><circle cx="20" cy="10" r="1.6" fill="#E85A8A"/>`},
 {id:"clock",name:"Wall Clock",cat:"Wall",wall:1,price:120,desc:"A railway clock. It's four minutes fast and nobody knows how to change it.",
  svg:`<circle cx="20" cy="20" r="12" fill="#F4ECD8" ${rk(1.6)}/><circle cx="20" cy="20" r="12" fill="none" stroke="#6A4022" stroke-width="2.4"/>${Array.from({length:12},(_,i)=>`<path d="M${(20+9.4*Math.cos(i*Math.PI/6)).toFixed(1)} ${(20+9.4*Math.sin(i*Math.PI/6)).toFixed(1)} L${(20+10.6*Math.cos(i*Math.PI/6)).toFixed(1)} ${(20+10.6*Math.sin(i*Math.PI/6)).toFixed(1)}" stroke="${RINK}" stroke-width=".8"/>`).join("")}<path class="rm-hand" d="M20 20 L20 12" stroke="${RINK}" stroke-width="1.4" stroke-linecap="round"/><path d="M20 20 L25 22" stroke="${RINK}" stroke-width="1.6" stroke-linecap="round"/>`},
 {id:"window",name:"Curtained Window",cat:"Wall",wall:1,price:90,desc:"A window onto the moor, with curtains Hobbs found in a box marked 'CURTAINS (?)'.",
  svg:`<rect x="8" y="6" width="24" height="26" fill="#4A6A9A" ${rk()}/><circle cx="26" cy="12" r="2.6" fill="#F4ECD8"/><path d="M8 26 Q14 22 20 25 Q26 22 32 26 V32 H8 Z" fill="#3A5A3A"/><path d="M20 6 V32 M8 19 H32" stroke="#6A4022" stroke-width="1.6"/><path d="M6 4 H34" stroke="#5A3A1E" stroke-width="2"/><path d="M6 5 Q10 18 7 33 L11 33 Q13 18 11 5 Z M34 5 Q30 18 33 33 L29 33 Q27 18 29 5 Z" fill="#B84A4A" ${rk(.8)}/>`},
 {id:"poster",name:"Periodic Table Poster",cat:"Wall",wall:1,price:60,desc:"Every element, colour-coded, with three of them circled in your own handwriting.",
  svg:`<rect x="6" y="8" width="28" height="20" fill="#F4ECD8" ${rk()}/>${Array.from({length:5},(_,r)=>Array.from({length:9},(_,c)=>(r<1&&c>0&&c<8)||(r<3&&c>1&&c<7&&r>0)?"":`<rect x="${8+c*2.8}" y="${10+r*3.2}" width="2.4" height="2.8" fill="${["#E8846A","#E8C860","#8AC86A","#6AA8E8","#B88AE8"][(c+r)%5]}"/>`).join("")).join("")}<circle cx="16.8" cy="20" r="2" fill="none" stroke="#B83A2A" stroke-width=".6"/>`},
 {id:"globe",name:"Globe",cat:"Furniture",price:140,desc:"An old globe. Drossmarch is a smudge on it, which seems unfair.",
  svg:`${rsh(8)}<path d="M14 37 H26 M20 37 V30" stroke="#5A3A1E" stroke-width="2.4"/><path d="M10 18 A10 10 0 0 0 30 18" stroke="#C8A040" stroke-width="1.4" fill="none"/><circle cx="20" cy="18" r="9" fill="#4A8AC8" ${rk()}/><path d="M14 14 Q18 12 19 16 Q16 20 13 18 Z M22 18 Q26 16 27 20 Q24 24 22 22 Z" fill="#6AA84A"/>`},
 {id:"records",name:"Gramophone",cat:"Furniture",price:250,desc:"A wind-up gramophone and one record, which is the Assay Hall march. Sorry.",
  svg:`${rsh(11)}<rect x="10" y="26" width="20" height="11" fill="#7A4E26" ${rk()}/><ellipse cx="20" cy="26" rx="9" ry="2" fill="#1A1A1E"/><path d="M22 25 L28 14" stroke="#C8A040" stroke-width="1.6"/><path d="M24 15 Q30 4 38 8 Q36 16 28 16 Z" fill="#C8A040" ${rk()}/>`,use:["You wind it up. It plays the Assay Hall march. You let it."]},
 {id:"tank",name:"Fish Tank",cat:"Furniture",price:300,w:2,desc:"A fish tank with two fish in it, called Brass and Bronze. Brass is the bossy one.",
  svg:`<ellipse cx="40" cy="38" rx="30" ry="2.4" fill="#000" opacity=".2"/><rect x="8" y="26" width="64" height="11" fill="#5A3A1E" ${rk()}/><rect x="10" y="6" width="60" height="20" fill="#5AA8D8" fill-opacity=".55" ${rk()}/><path d="M10 26 Q25 22 40 26 T70 26" fill="#C8B480" opacity=".8"/><path d="M18 26 V16 M22 26 Q24 18 20 14 M58 26 Q56 18 60 12" stroke="#3A8A3A" stroke-width="1.6" fill="none"/><g class="rm-fish"><path d="M34 14 Q38 11 42 14 Q38 17 34 14 Z M42 14 L45 12 L45 16 Z" fill="#D8A040"/></g><g class="rm-fish2"><path d="M50 19 Q54 16 58 19 Q54 22 50 19 Z M50 19 L47 17 L47 21 Z" fill="#C86A3A"/></g>`},
 {id:"telescope",name:"Telescope",cat:"Furniture",price:220,desc:"A brass telescope on a tripod, from the Starfall observers. It's pointed at the ceiling.",
  svg:`${rsh(10)}<path d="M20 22 L12 37 M20 22 L28 37 M20 22 V37" stroke="#5A3A1E" stroke-width="1.6"/><g transform="rotate(-30 20 20)"><rect x="8" y="16" width="26" height="7" rx="2" fill="#C8A040" ${rk()}/><rect x="4" y="17" width="5" height="5" fill="#8A6A2A" ${rk(.8)}/></g>`},
 {id:"beanbag",name:"Beanbag",cat:"Furniture",price:90,desc:"A beanbag in Institute blue. It's lost about half its beans.",
  svg:`${rsh(13)}<path d="M7 35 Q4 22 14 18 Q22 14 28 20 Q36 26 33 35 Q20 39 7 35 Z" fill="#3A6AA8" ${rk()}/><path d="M14 24 Q20 28 26 24" stroke="#5A8AC8" stroke-width="1.4" fill="none"/>`},
 {id:"plantstand",name:"Specimen Jars",cat:"Furniture",price:110,desc:"A stand of empty specimen jars, labelled for alloys you haven't found yet.",
  svg:`${rsh(11)}<rect x="8" y="26" width="24" height="3" fill="#6A4022" ${rk()}/><path d="M10 29 V37 M30 29 V37" stroke="#6A4022" stroke-width="2"/>${[11,18,25].map((x,i)=>`<rect x="${x}" y="${16+i%2*2}" width="6" height="${10-i%2*2}" rx="1" fill="#DDF0FF" fill-opacity=".4" ${rk(.8)}/><rect x="${x+.6}" y="${20}" width="4.8" height="2" fill="#F4ECD8"/>`).join("")}`},
 {id:"case2",name:"Display Case",cat:"Display",price:200,display:1,desc:"Another glass case, for another alloy you're proud of.",
  svg:`${rsh(11)}<rect x="10" y="26" width="20" height="11" fill="#6A4A2A" ${rk()}/><path d="M11 26 V6 H29 V26" fill="#DDF0FF" fill-opacity=".25" ${rk(1)}/><path d="M13 9 L16 6" stroke="#FFFFFF" stroke-width="1.2" opacity=".7"/>`},
 {id:"case3",name:"Tall Display Case",cat:"Display",price:260,display:1,desc:"A tall glass case with a brass rim, for the alloy that deserves it.",
  svg:`${rsh(11)}<rect x="10" y="28" width="20" height="9" fill="#3A2A1E" ${rk()}/><path d="M11 28 V2 H29 V28" fill="#DDF0FF" fill-opacity=".25" ${rk(1)}/><path d="M10 2 H30 M10 28 H30" stroke="#C8A040" stroke-width="1.6"/>`},
 {id:"rugred",name:"Red Rug",cat:"Floor",price:100,flat:1,w:2,desc:"A red rug with a gold border. Too good for this floor.",
  svg:`<rect x="4" y="10" width="72" height="24" rx="2" fill="#9A2A2A" ${rk()}/><rect x="8" y="13" width="64" height="18" fill="none" stroke="#E8C860" stroke-width="1.6"/><path d="M40 16 L46 22 L40 28 L34 22 Z" fill="#E8C860"/>`},
 {id:"rugmoor",name:"Moorland Rug",cat:"Floor",price:100,flat:1,w:2,desc:"Woven in heather colours by somebody in Hollowmere who wouldn't take money for it, so the Quartermaster charges instead.",
  svg:`<ellipse cx="40" cy="22" rx="36" ry="13" fill="#7A6A8A" ${rk()}/>${[0,1,2].map(i=>`<ellipse cx="40" cy="22" rx="${30-i*8}" ry="${11-i*3}" fill="none" stroke="${["#A8B87A","#C88AA8","#E8D8A0"][i]}" stroke-width="2"/>`).join("")}`}];
const RITEM=Object.fromEntries(ROOM_ITEMS.map(i=>[i.id,i]));
const RM_WALLS=[{id:"cream",name:"Institute Cream",col:"#E8DCC0",pat:"#D8CCB0"},{id:"sage",name:"Sage Stripe",col:"#B8C8A8",pat:"#A0B090",price:120},{id:"navy",name:"Navy Damask",col:"#3A4A6A",pat:"#4A5A7A",price:120},{id:"rose",name:"Rose Paper",col:"#D8A8A8",pat:"#C89898",price:120},{id:"panel",name:"Oak Panelling",col:"#8A5A2E",pat:"#7A4E26",price:160},{id:"moor",name:"Moorland Mural",col:"#7A8A6A",pat:"#5A6A8A",price:200,how:"Visit Hollowmere on Lantern Night.",open:()=>{try{return !!lntF("hm")}catch(e){return false}}}];
const RM_FLOORS=[{id:"boards",name:"Bare Boards",col:"#A8784A",line:"#8A5E36"},{id:"oak",name:"Polished Oak",col:"#8A5A2E",line:"#6A4422",price:150},{id:"tiles",name:"Lab Tiles",col:"#D8DCE0",line:"#B8BCC4",price:150},{id:"carpet",name:"Green Carpet",col:"#4A7A4A",line:"#3E6A3E",price:150},{id:"slate",name:"Slate Flags",col:"#6A6E78",line:"#4E525C",price:180}];
const rmOpen=it=>it.start||(it.price?((rmS().owned||[]).includes(it.id)):(!it.open||it.open()));
const rmOwnedCount=id=>id;

/* ---- the zone ---- */
function rmMap(st){const W=RM.W,H=RM.H,M=[];for(let y=0;y<H;y++){let r="";for(let x=0;x<W;x++){r+=(y===0||y===H-1||x===0||x===W-1)?"#":"."}M.push(r)}
  M[H-1]=M[H-1].slice(0,RM.door[0])+"D"+M[H-1].slice(RM.door[0]+1);
  /* furniture that stands on the floor blocks it; rugs and wall pieces don't */
  (st.items||[]).forEach(p=>{const it=RITEM[p.id];if(!it||it.wall||it.flat)return;for(let k=0;k<(it.w||1);k++){const x=p.x+k,r=M[p.y];if(r&&x>0&&x<W-1)M[p.y]=r.slice(0,x)+"H"+r.slice(x+1)}});
  return M}
const ROOM_ZONE={name:"YOUR ROOM",sub:"Staff quarters, Quillmoor Institute. Yours, to do with as you like.",cls:"z-quill",special:"room",map:[]};
const inRoom=()=>!!(EXP.zone&&EXP.zone.special==="room");
function rmEnter(){EXP.path=null;sfx("clunk");ROOM_ZONE.map=rmMap(rmS());EXP.forceZone=ROOM_ZONE;EXP.spawn=RM.spawn.slice();EXP.stash=null;EXP.resume=null;startExplore()}
function rmLeave(){RM.edit=false;RM.carry=null;EXP.path=null;sfx("clunk");EXP.forceZone=ZONES.find(q=>q.cls==="z-quill");EXP.spawn=[9,32];EXP.stash=null;EXP.resume=null;startExplore()}
{const _se=startExplore;startExplore=function(){if(EXP.forceZone===ROOM_ZONE)ROOM_ZONE.map=rmMap(rmS());_se()}}
/* the room's own walls and floor */
/* (always through the rest of the chain first, so the chunked drawing still knows the room's size) */
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const r=_tl(c,x,y,seed,M);if(!inRoom())return r;const st=rmS();let mine=null;
    if(c==="D")mine=["f hdoor",HALL_MAT];else if(c==="#")mine=y===0?["w rmw rmw-"+(st.wall||"cream"),""]:["w rmside",""];else if(c==="."||c==="H")mine=["f rmf rmf-"+(st.floor||"boards"),""];
    if(!mine)return r;if(typeof CH!=="undefined"&&CH.b){CH.inner[y*CH.W+x]=mine[1];return[mine[0]+" cull",""]}return mine}}
/* the door in the locker room */
const RM_DOOR_SVG=`<svg viewBox="0 0 40 40" aria-hidden="true" style="overflow:visible"><rect x="8" y="-2" width="24" height="40" rx="1" fill="#7A4E26" stroke="${RINK}" stroke-width="1.4"/><rect x="11" y="2" width="18" height="14" rx="1" fill="#8A5E36" stroke="${RINK}" stroke-width=".8"/><rect x="11" y="20" width="18" height="14" rx="1" fill="#8A5E36" stroke="${RINK}" stroke-width=".8"/><circle cx="27" cy="19" r="1.4" fill="#E8C860" stroke="${RINK}" stroke-width=".5"/><rect x="13" y="6" width="14" height="5" fill="#F4ECD8" stroke="${RINK}" stroke-width=".5"/><path d="M15 8.6 H25" stroke="#3A3A3A" stroke-width=".7"/></svg>`;
{const _wp=worldPlace;worldPlace=function(){_wp();const z=EXP.zone;if(!z)return;
  if(z.cls==="z-quill"&&!z.special&&!(typeof TUT!=="undefined"&&TUT.on)){const W=EXP.W,H=EXP.H,d=document.createElement("div");d.className="mapobj rmdoor";d.style.cssText=`width:${100/W}%;height:${100/H}%;left:${RM.door[0]===7?9/W*100:9/W*100}%;top:${33/H*100}%`;d.innerHTML=RM_DOOR_SVG;$("#world").insertBefore(d,$("#player"));
    EXP.objs.push({x:9,y:33,tile:1,use:()=>rmEnter()})}
  if(inRoom())rmPlace()}}
/* walking into the door goes through it */
{const _st=step;step=function(dx,dy){if(!EXP.busy&&S.phase==="explore"&&EXP.zone&&!DLG.open){const nx=EXP.x+dx,ny=EXP.y+dy;
    if(EXP.zone.cls==="z-quill"&&!EXP.zone.special&&nx===9&&ny===33){rmEnter();return false}
    if(inRoom()&&nx===RM.door[0]&&ny===RM.door[1]){rmLeave();return false}}
  return _st(dx,dy)}}
SIGNS["z-quill"]=SIGNS["z-quill"]||{};

/* ---- putting the room's things in it ---- */
function rmItemEl(p,idx){const it=RITEM[p.id];if(!it)return null;const W=EXP.W,H=EXP.H,w=it.w||1,d=document.createElement("div");
  d.className="mapobj rmi"+(it.wall?" rmwall":"")+(it.flat?" rmflat":"")+(it.tall?" rmtall":"");d.dataset.i=idx;
  d.style.width=(w*100/W)+"%";d.style.height=(100/H)+"%";d.style.left=(p.x/W*100)+"%";d.style.top=(p.y/H*100)+"%";
  let inner=it.svg;if(it.display)inner+=rmCaseInner(p);
  d.innerHTML=`<svg viewBox="0 0 ${40*w} 40" aria-hidden="true" style="overflow:visible">${inner}</svg>`;return d}
/* what's in a display case: a tiny version of the alloy, with its shine if it's Radiant */
function rmCaseInner(p){if(!p.a)return`<text x="20" y="18" text-anchor="middle" font-size="5" fill="#8A8A92" font-family="sans-serif">EMPTY</text>`;const a=alloyByName(p.a);if(!a)return"";
  const sv=specimenSVG(a).replace(/<svg[^>]*viewBox="([^"]+)"[^>]*>/,'<svg x="11.6" y="6.4" width="16.8" height="19" viewBox="$1" preserveAspectRatio="xMidYMid meet">');
  return sv+(p.rad?`<path d="M26 8 l.8 2 2 .8 -2 .8 -.8 2 -.8 -2 -2 -.8 2 -.8 Z" fill="#F2C94C"/>`:"")}
function rmPlace(){const st=rmS();document.querySelectorAll("#world>.rmi").forEach(e=>e.remove());const w=$("#world"),pl=$("#player");
  (st.items||[]).forEach((p,i)=>{const it=RITEM[p.id];if(!it)return;const d=rmItemEl(p,i);if(d)w.insertBefore(d,pl);
    if(it.flat)return;const lines=typeof it.use==="function"?it.use():it.use;
    EXP.objs.push({x:p.x,y:p.y,tile:1,rm:1,use:()=>{if(RM.edit){rmPick(i);return}if(it.display){rmChooseAlloy(i);return}talk("",lines||[it.desc])}})});
  rmBar()}

/* ---- EDIT ROOM ---- */
function rmBar(){let b=$("#rm-bar");if(!inRoom()||S.phase!=="explore"){if(b)b.remove();return}const mw=$("#mapwrap");if(!mw)return;
  if(!b){b=document.createElement("div");b.id="rm-bar";mw.appendChild(b)}
  if(RM.carry){const it=RITEM[RM.carry.id];b.innerHTML=`<span>Placing: <b>${it.name}</b>. Click ${it.wall?"a spot on the back wall":"a floor square"}.</span><button class="btn" id="rm-stow">PACK AWAY</button><button class="btn" id="rm-cancel">CANCEL</button>`;
    $("#rm-stow").onclick=()=>{RM.carry=null;rmRefresh()};$("#rm-cancel").onclick=()=>{if(RM.carry.from){const st=rmS();st.items.push(RM.carry.from);rmSave(st)}RM.carry=null;rmRefresh()}}
  else if(RM.edit){b.innerHTML=`<span><b>EDITING.</b> Click a piece to pick it up.</span><button class="btn go" id="rm-open">ADD / CHANGE</button><button class="btn" id="rm-done">DONE</button>`;$("#rm-open").onclick=rmPanel;$("#rm-done").onclick=()=>{RM.edit=false;rmRefresh()}}
  else{b.innerHTML=`<button class="btn go" id="rm-edit">EDIT ROOM</button>`;$("#rm-edit").onclick=()=>{RM.edit=true;rmRefresh()}}
  $("#mapwrap").classList.toggle("rm-editing",!!(RM.edit||RM.carry));$("#mapwrap").classList.toggle("rm-carry",!!RM.carry);$("#mapwrap").classList.toggle("rm-carry-wall",!!(RM.carry&&RITEM[RM.carry.id].wall))}
function rmRefresh(){if(!inRoom())return;ROOM_ZONE.map=rmMap(rmS());const keep=[EXP.x,EXP.y];EXP.spawn=keep;EXP.forceZone=ROOM_ZONE;EXP.stash=null;EXP.resume=null;startExplore()}
function rmPick(i){const st=rmS(),p=st.items[i];if(!p)return;st.items.splice(i,1);rmSave(st);RM.carry={id:p.id,a:p.a,rad:p.rad,from:p};sfx("sel");rmRefresh()}
/* can it go there? on free floor (or the back wall), not on the doorway, and never cutting the room in two */
function rmCanPut(id,x,y){const it=RITEM[id],st=rmS(),W=RM.W,H=RM.H,w=it.w||1;
  if(it.wall){if(y!==0||x<1||x+w-1>W-2)return false;return!st.items.some(p=>RITEM[p.id]&&RITEM[p.id].wall&&p.y===0&&x<p.x+(RITEM[p.id].w||1)&&p.x<x+w)}
  if(y<1||y>H-2||x<1||x+w-1>W-2)return false;
  for(let k=0;k<w;k++){if(x+k===RM.spawn[0]&&y===RM.spawn[1])return false;if(x+k===EXP.x&&y===EXP.y&&!it.flat)return false}
  const clash=st.items.some(p=>{const q=RITEM[p.id];if(!q||q.wall)return false;if(!!q.flat!==!!it.flat)return false;return p.y===y&&x<p.x+(q.w||1)&&p.x<x+w});if(clash)return false;
  if(it.flat)return true;
  const M=rmMap({items:[...st.items,{id,x,y}]});const seen=new Set([RM.spawn+""]),q=[RM.spawn.slice()];
  while(q.length){const[a,b]=q.pop();for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=a+dx,ny=b+dy,k=nx+","+ny;if(seen.has(k)||(M[ny]||"")[nx]!==".")continue;seen.add(k);q.push([nx,ny])}}
  let free=0;M.forEach(r=>{for(const ch of r)if(ch===".")free++});return seen.size===free}
(function(){const bind=()=>{const mw=$("#mapwrap");if(!mw||mw.__rm)return;mw.__rm=1;
  mw.addEventListener("click",e=>{if(!inRoom()||!(RM.carry||RM.edit)||e.target.closest("#rm-bar"))return;const m=$("#map");if(!m)return;const r=m.getBoundingClientRect();
    const x=Math.floor((e.clientX-r.left)/r.width*EXP.W),y=Math.floor((e.clientY-r.top)/r.height*EXP.H);e.stopPropagation();e.preventDefault();
    if(RM.carry){if(rmCanPut(RM.carry.id,x,y)){const st=rmS();st.items.push({id:RM.carry.id,x,y,a:RM.carry.a||null,rad:RM.carry.rad||0});rmSave(st);RM.carry=null;sfx("pickup");rmRefresh()}else{sfx("miss");say0("It won't go there. It needs free floor, can't block the door, and can't cut the room off.")}return}
    /* editing: pick up whatever is on that square (a rug last, if something stands on it) */
    const st=rmS();let hit=-1;st.items.forEach((p,i)=>{const it=RITEM[p.id];if(!it)return;if(p.y===y&&x>=p.x&&x<p.x+(it.w||1)){if(hit<0||RITEM[st.items[hit].id].flat)hit=i}});if(hit>=0)rmPick(hit)},true)};
  const t=setInterval(()=>{if($("#mapwrap")){bind();clearInterval(t)}},300)})();
/* the panel: your things, the walls and floor, and the Quartermaster's catalogue */
function rmPanel(tab){tab=tab||RM.tab||"things";RM.tab=tab;const m=modal("rmpanel","YOUR ROOM"),L=m.querySelector(".bag-list"),st=rmS(),pts=rmPts();
  const placedCount=id=>st.items.filter(p=>p.id===id).length;
  const tabs=`<div class="rm-tabs">${[["things","YOUR THINGS"],["looks","WALLS & FLOOR"],["shop","CATALOGUE"]].map(([k,n])=>`<button class="btn${k===tab?" go":""}" data-tab="${k}">${n}</button>`).join("")}<span class="rm-pts">${pts} pts</span></div>`;
  const pv=it=>`<svg viewBox="${it.w===2?"0 -6 80 46":"0 -14 40 54"}" aria-hidden="true">${it.svg}</svg>`;
  let body="";
  if(tab==="things"){const mine=ROOM_ITEMS.filter(rmOpen),lock=ROOM_ITEMS.filter(i=>!rmOpen(i)&&!i.price);
    body=`<p class="bag-empty">Pick something to put in the room. Each piece can go in once.</p>`+mine.map(it=>{const n=placedCount(it.id);return`<div class="bag-item rm-it"><div class="rm-pv">${pv(it)}</div><div><b>${it.name}</b><p>${it.desc}</p></div>${n?`<span class="always">IN THE ROOM</span>`:`<button class="btn go" data-put="${it.id}">PLACE</button>`}</div>`}).join("")
      +(lock.length?`<h5 class="bag-h">STILL TO EARN</h5>`+lock.map(it=>`<div class="bag-item rm-it locked"><div class="rm-pv">${pv(it)}</div><div><b>${it.name}</b><p>${it.how||""}</p></div><span class="always">LOCKED</span></div>`).join(""):"")}
  else if(tab==="looks"){const sw=(L,kind)=>L.map(o=>{const own=!o.price&&(!o.open||o.open())||(st.owned||[]).includes(kind+":"+o.id),cur=(kind==="wall"?st.wall:st.floor)===o.id;
      return`<div class="bag-item rm-it${!own&&o.open&&!o.open()?" locked":""}"><div class="rm-sw rm${kind==="wall"?"w":"f"}-${o.id}"></div><div><b>${o.name}</b><p>${o.how&&!(o.open&&o.open())?o.how:own?"Yours.":o.price+" pts"}</p></div>${cur?`<span class="always">IN USE</span>`:own?`<button class="btn go" data-look="${kind}:${o.id}">USE</button>`:o.open&&!o.open()?`<span class="always">LOCKED</span>`:`<button class="btn" data-buy="${kind}:${o.id}" ${pts<o.price?"disabled":""}>BUY ${o.price}</button>`}</div>`}).join("");
    body=`<h5 class="bag-h">WALLPAPER</h5>${sw(RM_WALLS,"wall")}<h5 class="bag-h">FLOOR</h5>${sw(RM_FLOORS,"floor")}`}
  else{body=`<p class="bag-empty">The Quartermaster's catalogue. Points come from registering alloys: every one you register adds its round's points.</p>`+ROOM_ITEMS.filter(i=>i.price).map(it=>{const own=(st.owned||[]).includes(it.id);
      return`<div class="bag-item rm-it"><div class="rm-pv">${pv(it)}</div><div><b>${it.name}</b><p>${it.desc}</p></div>${own?`<span class="always">OWNED</span>`:`<button class="btn" data-buy="item:${it.id}" ${pts<it.price?"disabled":""}>BUY ${it.price}</button>`}</div>`}).join("")}
  L.innerHTML=tabs+body;
  L.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>rmPanel(b.dataset.tab));
  L.querySelectorAll("[data-put]").forEach(b=>b.onclick=()=>{RM.carry={id:b.dataset.put};m.hidden=true;RM.edit=true;rmBar();say0(`Placing the ${RITEM[b.dataset.put].name.toUpperCase()}: click ${RITEM[b.dataset.put].wall?"a spot on the back wall":"a free floor square"}.`)});
  L.querySelectorAll("[data-look]").forEach(b=>b.onclick=()=>{const[k,id]=b.dataset.look.split(":"),S2=rmS();S2[k]=id;rmSave(S2);sfx("sel");m.hidden=true;rmRefresh()});
  L.querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>{const[k,id]=b.dataset.buy.split(":"),S2=rmS(),o=k==="item"?RITEM[id]:(k==="wall"?RM_WALLS:RM_FLOORS).find(q=>q.id===id),p=rmPts();if(!o||p<o.price)return;
    store.set("wta_room_pts",p-o.price);S2.owned=[...(S2.owned||[]),k==="item"?id:k+":"+id];rmSave(S2);sfx("pickup");say0(`Bought: ${o.name.toUpperCase()}.`);rmPanel(tab)})}
/* choosing what goes in a display case: any registered alloy, shown Radiant if you've caught it Radiant */
function rmChooseAlloy(i){const m=modal("rmcase","DISPLAY CASE"),L=m.querySelector(".bag-list"),st=rmS(),p=st.items[i];
  const got=ALLOYS.filter(a=>S.caught.has(a.name)).sort((x,y)=>x.no-y.no);
  L.innerHTML=`<p class="bag-empty">${got.length?"Pick a registered alloy to show in this case.":"You haven't registered anything yet. Go and find something to be proud of."}</p><div class="rm-grid">${p&&p.a?`<button class="rm-al" data-a="">EMPTY THE CASE</button>`:""}${got.map(a=>`<button class="rm-al${p&&p.a===a.name?" on":""}" data-a="${a.name}"><span class="rm-als">${specimenSVG(a)}</span><b>${a.name}</b>${radOwned(a)?`<i data-r="${a.name}" title="Show it Radiant">✦</i>`:""}</button>`).join("")}</div>`;
  L.querySelectorAll(".rm-al").forEach(b=>b.onclick=e=>{const S2=rmS(),q=S2.items[i];if(!q)return;q.a=b.dataset.a||null;q.rad=e.target.dataset&&e.target.dataset.r?1:0;rmSave(S2);sfx("sel");m.hidden=true;rmRefresh();if(q.a)say0(`The ${q.a.toUpperCase()} goes in the case.${q.rad?" It shines.":""}`)})}
/* new things for the room, as you earn them */
function rmNew(){const seen=store.get("wta_room_seen",null),open=ROOM_ITEMS.filter(i=>!i.price&&!i.start&&rmOpen(i)).map(i=>i.id);
  if(seen===null){store.set("wta_room_seen",open);return}const fresh=open.filter(id=>!seen.includes(id));if(!fresh.length)return;store.set("wta_room_seen",[...seen,...fresh]);
  setTimeout(()=>say0(`New for your room: ${fresh.map(id=>RITEM[id].name.toUpperCase()).join(", ")}. Put ${fresh.length>1?"them":"it"} out with EDIT ROOM in your room, through the locker room in the Institute.`),1600)}
{const _se=startExplore;startExplore=function(){_se();rmNew();rmBar()}}
{const _en=encounter;encounter=function(){const b=$("#rm-bar");if(b)b.remove();_en()}}
