/* ---- Shipwreck Coast, 2 ---- */
/* Clockwise Metal: you walk around it clockwise, and apologise. A dung beetle rolling its ball, always clockwise. */
addForm("Clockwise Metal",{n:"#2A3A2A",a:"#5AA87A",rn:"#E8D8C8",rb:"#8A6A4A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(70)+
 pt("spin",64,104,`<circle cx="64" cy="104" r="30" fill="#8A6A4A" ${SW}/>${[[54,92],[74,98],[60,116],[78,114],[50,106]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="#6A4A2A"/>`).join("")}<path d="M64 74 A30 30 0 0 1 94 104" stroke="#F2C94C" stroke-width="3" fill="none" stroke-dasharray="6 4"/>`)+
 [0,1,2].map(i=>pt("legB",130+i*8,118,`<path d="M${130+i*8} 118 L${140+i*12} 104 L${150+i*12} 138" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M100 120 Q100 92 132 90 Q164 92 166 120 Q160 134 132 134 Q104 134 100 120 Z" fill="${P.n}" ${SW}/><path d="M132 90 V134" stroke="${FI}" stroke-width="2"/><path d="M108 100 Q132 94 158 102" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".7"/>`+
 pt("head",100,116,`<path d="M88 122 Q88 106 100 104 Q112 106 112 122 Z" fill="${P.n}" ${SW}/><path d="M84 112 l-4 -6 l6 2 l2 -6 l4 6" stroke="${FI}" stroke-width="2" fill="${P.n}"/>${E2(98,112,3)}`+HMOUTH(88,118,94,P,2))+
 [0,1].map(i=>pt("armF",104,122,`<path d="M104 122 L${96-i*4} ${108+i*8} L${90-i*2} ${110+i*10}" stroke="${FI}" stroke-width="3.4" fill="none"/>`,i*.3)).join("")+
 fG(g,1,`<path d="M170 40 a14 14 0 1 1 -10 -4" stroke="${P.ac}" stroke-width="2.4" fill="none"/><path d="M160 36 l-2 -6 l6 2" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="132" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Clockwise Metal"]="Clockwise Dung Beetle";SM("Clockwise Metal","Roll Round","STR","a",70,100,"","Round and round it goes, the right way, always.");

/* Colleyite: boats won't sail the day it arrives. A cormorant on a post, wings hung out to dry, warning everyone off. */
addForm("Colleyite",{n:"#2A2A30",a:"#E8C060",rn:"#E8E0D0",rb:"#3A6A8A",ra:"#5FE0F0"},"perch",(P,g)=>`<rect x="94" y="114" width="20" height="36" fill="#6A4A2A" ${SW}/><path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 pt("wingB",112,80,`<path d="M110 80 Q140 60 172 70 Q166 82 172 92 Q156 92 160 104 Q136 100 114 96 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${130+i*10} ${76+i*2} l8 18" stroke="${P.n}" stroke-width="1.6"/>`).join("")}`,.3)+
 pt("tail",108,112,`<path d="M104 110 L116 132 L108 132 L100 114 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M92 108 Q88 82 104 76 Q118 80 118 108 Q112 118 104 118 Q94 118 92 108 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",104,116,`<path d="M100 114 l-4 4 h8 M108 114 l4 4 h-8" stroke="${FI}" stroke-width="3"/>`)+
 pt("wingF",96,80,`<path d="M98 80 Q68 60 36 70 Q42 82 36 92 Q52 92 48 104 Q72 100 94 96 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${78-i*10} ${76+i*2} l-8 18" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",104,68,`<path d="M106 76 Q100 62 104 52" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M106 76 Q100 62 104 52" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><ellipse cx="102" cy="46" rx="10" ry="8" fill="${P.n}" ${SW}/>${E2(102,44,3.2,"#3AA87A")}<path d="M96 48 Q100 52 104 50" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
  `<path d="M92 44 L76 46 L92 48 Z" fill="${FMOUTH}"/>`+pt("beak",92,48,`<path d="M92 48 L76 48 Q76 52 80 50 L92 51 Z" fill="#6A6A70" ${SW2}/>`)+`<path d="M92 42 L74 46 L92 46 Z" fill="#6A6A70" ${SW2}/>`)+
 fG(g,1,`<path d="M30 130 l12 -14 l12 14 Z" fill="#B8402A" ${SW2}/><path d="M42 116 V100" stroke="${FI}" stroke-width="2"/><path d="M42 100 l10 4 l-10 4" fill="#B8402A" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Colleyite"]="Omen Cormorant";SM("Colleyite","Bad Omen","RES","s",0,100,"tatk-1,tspd-1","Nobody's going out today. Not with that sitting there.");

/* Cralite: the dental waiting room's ancient magazine mentions it. A crocodile at the dentist, mouth wide open, a little plover cleaning its teeth. */
addForm("Cralite",{n:"#5A7A4A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8A0C8",ra:"#E8412C"},"crawl",(P,g)=>fShadow(80)+
 pt("tail",160,122,`<path d="M150 116 Q180 118 194 134 Q176 136 150 130 Z" fill="${P.n}" ${SW}/>${[162,172,182].map(x=>`<path d="M${x} ${120+(x-162)*.4} l3 -5 l3 5" fill="${P.nd}" ${SW2}/>`).join("")}`)+
 [[144,"legB",.5],[104,"legB",1.3]].map(([x,c,d])=>pt(c,x,128,fOL(`M${x} 126 L${x+8} 140 h6`,P.nd,8),d)).join("")+
 `<path d="M76 124 Q78 106 116 104 Q150 106 156 122 Q150 136 116 136 Q80 136 76 124 Z" fill="${P.n}" ${SW}/>${[90,104,118,132,146].map(x=>`<path d="M${x} 106 l3 -5 l3 5" fill="${P.nd}" ${SW2}/>`).join("")}`+
 [[134,"legF",0],[92,"legF",.8]].map(([x,c,d])=>pt(c,x,130,fOL(`M${x} 128 L${x-8} 142 h-6`,P.n,8),d)).join("")+
 pt("head",80,116,`<path d="M30 120 Q34 110 60 108 Q80 108 84 120 Q78 128 60 128 Z" fill="${P.n}" ${SW}/><circle cx="64" cy="104" r="7" fill="${P.n}" ${SW2}/>${E2(64,103,4,"#C8A020")}<path d="M32 120 H80" stroke="${FMOUTH}" stroke-width="3"/>`+
  pt("jaw",64,92,`<path d="M30 116 Q40 76 74 104 L80 112 Q50 98 34 118 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${40+i*8} ${106-i*3} l2 6 l2 -6" fill="#fff" ${SW2}/>`).join("")}<g transform="translate(46 84)"><ellipse cx="6" cy="10" rx="7" ry="5" fill="#E8E0D0" ${SW2}/><circle cx="2" cy="6" r="4" fill="#E8E0D0" ${SW2}/><circle cx="1" cy="5" r="1" fill="${FI}"/><path d="M-2 6 l-5 1" stroke="${FI}" stroke-width="1.4"/><path d="M8 14 l-1 5 M5 14 l-1 5" stroke="${FI}" stroke-width="1"/></g>`))+
 fG(g,1,`<g transform="rotate(8 170 40)"><rect x="156" y="28" width="28" height="26" fill="#F4E8C0" ${SW2}/><path d="M176 28 l8 8 h-8 Z" fill="#E8D8A0" ${SW2}/><path d="M160 36 h12 M160 40 h16 M160 44 h14" stroke="#8A8A9A" stroke-width="1"/></g>`)+fG(g,2,`<circle cx="116" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,60,6)));
FORM_TITLE["Cralite"]="Open-Wide Crocodile";SM("Cralite","Open Wide","SCR","a",85,90,"tdef-1@30","Say 'ah'. It certainly is.");

/* Devarda's Alloy: chemists powder it to test for nitrates. A squid that changes colour band by band as it tests the water, like an indicator strip. */
addForm("Devarda's Alloy",{n:"#E8A0B0",a:"#5A8AE8",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0A0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/>`+
 Array.from({length:6},(_,i)=>pt(i%2?"legB":"legF",70,90+i*2,`<path d="M74 ${88+i*3} Q${50-i*2} ${96+i*6} ${30-i} ${92+i*9}" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M74 ${88+i*3} Q${50-i*2} ${96+i*6} ${30-i} ${92+i*9}" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,i*.15)).join("")+
 pt("tail",160,86,`<path d="M150 80 L178 64 L174 86 L178 106 L150 92 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M70 86 Q74 66 110 64 Q150 68 160 86 Q150 104 110 106 Q74 106 70 86 Z" fill="${P.n}" ${SW}/><clipPath id="dvC"><path d="M70 86 Q74 66 110 64 Q150 68 160 86 Q150 104 110 106 Q74 106 70 86 Z"/></clipPath><g clip-path="url(#dvC)">${["#E8A0B0","#E8C060","#9AD86A","#5AB0C8","#5A8AE8","#8A5AC8"].map((c,i)=>`<rect x="${88+i*12}" y="60" width="12" height="50" fill="${c}" opacity=".7"/>`).join("")}</g><path d="M70 86 Q74 66 110 64 Q150 68 160 86 Q150 104 110 106 Q74 106 70 86" fill="none" ${SW}/>`+
 pt("head",80,84,`${E2(84,80,5,"#1A1A1A",[-.4,0])}`+HMOUTH(70,88,78,P,2.4))+
 fG(g,1,`<path d="M20 30 v30 h10 v-30" stroke="${FI}" stroke-width="2" fill="#E8F4F8"/><rect x="20" y="46" width="10" height="14" fill="#5A8AE8" opacity=".6"/>`)+fG(g,2,`<circle cx="110" cy="86" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Devarda's Alloy"]="Indicator Squid";SM("Devarda's Alloy","Reagent Test","RES","a",60,100,"tdef-1,tward-1@50","A change of colour gives away what's really there.");

/* Do-Not-Ask Metal: 'Received. Paid. Do not ask.' A hooded seal inflating the strange red balloon on its nose, as a warning not to ask. */
addForm("Do-Not-Ask Metal",{n:"#7A7A84",a:"#C8302A",rn:"#E8D8C8",rb:"#3A5A8A",ra:"#F2C94C"},"slosh",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#E8F4F8" ${SW2}/>`+fShadow(66)+
 pt("tail",156,128,`<path d="M150 126 L174 116 L170 130 L182 140 L156 136 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M74 136 Q66 100 90 88 Q120 80 140 104 Q158 122 156 138 Z" fill="${P.n}" ${SW}/>${Array.from({length:10},(_,i)=>`<path d="M${92+(i%5)*12} ${100+Math.floor(i/5)*16} q4 -4 8 0 q-4 4 -8 0 Z" fill="${P.ndd}"/>`).join("")}`+
 pt("armF",84,124,`<path d="M88 118 Q68 126 64 140 Q80 142 92 132 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",80,84,`<path d="M52 86 Q50 64 76 60 Q100 62 102 84 Q98 100 76 100 Q56 100 52 86 Z" fill="${P.ndd}" ${SW}/><path d="M66 70 Q76 62 90 70 L88 86 Q76 82 68 86 Z" fill="${P.n}" opacity=".6"/>${E2(76,76,4.4,"#1A1A1A")}`+
  pt("tongue",56,84,`<ellipse cx="44" cy="80" rx="14" ry="10" fill="${P.ac}" ${SW}/><path d="M36 74 Q42 70 48 72" stroke="#fff" stroke-width="2" fill="none" opacity=".6"/>`)+HMOUTH(56,92,66,P,2.4))+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">DO NOT</text><text x="156" y="52" font-size="10" font-weight="bold" fill="${P.ac}">ASK</text>`)+fG(g,2,`<circle cx="114" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Do-Not-Ask Metal"]="Hooded Seal";SM("Do-Not-Ask Metal","Inflate","RES","s",0,100,"tatk-1,def+1","The red hood comes up. That means stop asking.");

/* Dorritite: every retirement party toasts it, the first thing each retiree ever learned. A gibbon swinging in with a raised glass and a gold watch. */
addForm("Dorritite",{n:"#5A4A3A",a:"#E8D8B8",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 28 Q104 18 194 30" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("armB",116,30,`<path d="M114 30 Q122 50 116 74" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M114 30 Q122 50 116 74" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.4)+
 pt("legB",112,110,`<path d="M110 108 Q126 120 120 136" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M110 108 Q126 120 120 136" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M90 110 Q86 80 104 74 Q120 80 120 108 Q116 120 104 120 Q92 120 90 110 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",96,110,`<path d="M96 108 Q84 122 90 136" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M96 108 Q84 122 90 136" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("armF",92,84,`<path d="M92 84 Q70 90 60 74" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M92 84 Q70 90 60 74" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="72" cy="88" r="5" fill="#F2C94C" ${SW2}/><path d="M52 52 L64 52 L60 68 L56 68 Z" fill="#E8F4F8" opacity=".8" ${SW2}/><path d="M53 56 h10" stroke="#F2C94C" stroke-width="4"/><path d="M58 68 V74 M54 74 h8" stroke="${FI}" stroke-width="1.6"/>`)+
 pt("head",104,66,`<circle cx="104" cy="62" r="15" fill="${P.n}" ${SW}/><path d="M92 62 Q104 50 116 62 Q114 76 104 76 Q94 76 92 62 Z" fill="${P.ac}"/>${E2(98,62,3.6,"#3A2410")}${E2(110,62,3.6,"#3A2410")}`+HMOUTH(100,70,108,P,2.4))+
 fG(g,1,`<path d="M150 70 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="#F2C94C" ${SW2}/><path d="M164 90 q6 -10 12 0" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,120,6)));
FORM_TITLE["Dorritite"]="Toasting Gibbon";SM("Dorritite","Raise A Glass","RES","s",0,100,"atk+1,ward+1","To the first thing you ever learned here.");

/* Double Six Metal: a double six means everyone gets cake. A cow whose patches are domino pips, a double six on its side. */
addForm("Double Six Metal",{n:"#F4F0E8",a:"#2A2A30",rn:"#3A3A4A",rb:"#E8A0B0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(78)+
 pt("tail",162,92,fOL("M160 92 Q172 104 170 122",P.n,3)+`<path d="M166 118 Q174 128 166 134 Q162 126 166 118 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",150,110,32,11,P.nd,P.ac,.5)+fLeg("legB",112,112,30,11,P.nd,P.ac,1.3)+
 `<path d="M84 102 Q84 76 124 74 Q162 76 166 100 Q162 120 126 120 Q88 120 84 102 Z" fill="${P.n}" ${SW}/><rect x="96" y="80" width="62" height="32" rx="4" fill="none" stroke="${P.ac}" stroke-width="2.4"/><path d="M127 80 V112" stroke="${P.ac}" stroke-width="2.4"/>${[[104,88],[104,96],[104,104],[118,88],[118,96],[118,104],[136,88],[136,96],[136,104],[150,88],[150,96],[150,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.8" fill="${P.ac}"/>`).join("")}<ellipse cx="120" cy="120" rx="10" ry="5" fill="#E8A0B0" ${SW2}/>`+
 fLeg("legF",142,112,30,11,P.n,P.ac,0)+fLeg("legF",98,112,30,11,P.n,P.ac,.8)+
 pt("head",88,88,`<path d="M54 92 Q52 72 72 70 Q92 72 94 90 Q92 104 76 106 Q56 106 54 92 Z" fill="${P.n}" ${SW}/><path d="M52 96 Q54 88 66 90 Q74 92 72 102 Q64 108 56 104 Z" fill="#E8A0B0" ${SW2}/><circle cx="58" cy="96" r="1.6" fill="${FI}"/><circle cx="66" cy="96" r="1.6" fill="${FI}"/>${E2(72,82,3.8)}<circle cx="82" cy="78" r="3" fill="${P.ac}"/>`+HMOUTH(58,102,68,P,2)+
  pt("ear",86,72,`<path d="M84 72 Q98 64 100 72 Q94 78 86 78 Z" fill="${P.n}" ${SW2}/>`)+`<path d="M74 70 Q72 60 78 56 M82 70 Q86 60 92 58" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M74 70 Q72 60 78 56 M82 70 Q86 60 92 58" stroke="#E8E0C8" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M20 130 L40 130 L36 118 L24 118 Z" fill="#E8C890" ${SW2}/><path d="M22 118 Q30 110 38 118" fill="#F4F0F4" ${SW2}/><path d="M30 112 V104" stroke="#E8412C" stroke-width="2.4"/>`)+fG(g,2,`<circle cx="127" cy="116" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Double Six Metal"]="Domino Cow";SM("Double Six Metal","Double Six","RES","a",66,100,"heal:15","Roll a double six and everybody gets cake.");

/* Double-O Blend: batch 'OO7' brought weeks of spy jokes. A mink in a dinner jacket, sleek and secret. */
addForm("Double-O Blend",{n:"#3A2A24",a:"#F4F0F4",rn:"#E8D8C8",rb:"#3A5A8A",ra:"#E8412C"},"slink",(P,g)=>fShadow(70)+
 pt("tail",158,100,`<path d="M156 102 Q178 100 186 84" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M156 102 Q178 100 186 84" stroke="${P.n}" stroke-width="7.6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",146,110,30,8,P.nd,P.ndd,.5)+
 `<path d="M68 104 Q70 86 108 84 Q148 86 160 100 Q156 116 116 118 Q76 118 68 104 Z" fill="#1A1A22" ${SW}/><path d="M74 100 L92 90 L96 116 Q80 116 74 104 Z" fill="${P.ac}"/><path d="M84 96 l6 -2 l0 6 Z M84 96 l-6 -2 l0 6 Z" fill="${FI}"/>`+
 fLeg("legF",136,112,28,8,"#1A1A22",P.ndd,0)+fLeg("legF",86,110,30,8,"#1A1A22",P.ndd,.8)+
 pt("head",68,94,`<path d="M30 90 Q34 74 52 72 Q70 74 72 88 Q68 100 52 100 Q36 100 30 90 Z" fill="${P.n}" ${SW}/><ellipse cx="30" cy="89" rx="3" ry="2.6" fill="${FI}"/><path d="M42 78 l12 2" stroke="${FI}" stroke-width="2"/>${E2(50,84,3.6,"#4A8A4A",[-.6,.2])}`+HMOUTH(32,94,40,P,2.2)+pt("ear",62,74,`<circle cx="62" cy="74" r="5" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<circle cx="160" cy="40" r="14" fill="none" stroke="${FI}" stroke-width="3"/><circle cx="160" cy="40" r="9" fill="none" stroke="${FI}" stroke-width="1.6"/><path d="M160 22 v8 M160 50 v8 M142 40 h8 M170 40 h8" stroke="${FI}" stroke-width="2"/>`)+fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Double-O Blend"]="Secret-Agent Mink";SM("Double-O Blend","Licence To Spill","STR","a",70,100,"crit","Shaken, not stirred. Also slightly melted.");

/* Ducks Unmentioned: a note said 'Tell no one about the ducks.' A duck in an obvious disguise: false nose, glasses and moustache. */
addForm("Ducks Unmentioned",{n:"#F4F0E4",a:"#E8A040",rn:"#3A3A4A",rb:"#3A8A5A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(56,108)+
 pt("tail",136,94,`<path d="M132 90 L152 82 L148 98 Z" fill="${P.n}" ${SW}/>`)+
 pt("legB",116,112,`<path d="M116 110 L118 136" stroke="${P.ac}" stroke-width="3.4"/><path d="M108 140 L118 136 L128 140 Z" fill="${P.ac}" ${SW2}/>`,.5)+
 `<path d="M80 100 Q82 76 112 74 Q138 78 142 100 Q132 116 108 116 Q86 114 80 100 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,92,`<path d="M100 88 Q126 82 140 100 Q124 110 104 104 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legF",100,112,`<path d="M100 110 L98 136" stroke="${P.ac}" stroke-width="3.4"/><path d="M88 140 L98 136 L108 140 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("head",86,74,`<circle cx="84" cy="64" r="15" fill="${P.n}" ${SW}/>${E2(80,60,3.6)}${E2(92,60,3.4)}<circle cx="80" cy="60" r="6" fill="none" stroke="${FI}" stroke-width="2"/><circle cx="92" cy="60" r="5.6" fill="none" stroke="${FI}" stroke-width="2"/><path d="M86 60 h0" stroke="${FI}" stroke-width="2"/><path d="M72 52 l14 -2 M88 50 l10 2" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`+
  `<path d="M70 66 L52 68 L70 74 Z" fill="${FMOUTH}"/>`+pt("beak",70,72,`<path d="M70 72 Q56 74 52 70 Q56 78 70 76 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M70 62 Q54 62 50 68 L70 68 Z" fill="${P.ac}" ${SW2}/><ellipse cx="66" cy="64" rx="5" ry="6" fill="#E8B0A0" ${SW2}/><path d="M58 68 Q66 64 74 68 Q70 72 66 70 Q62 72 58 68 Z" fill="${FI}"/>`)+
 fG(g,1,`<g transform="rotate(-8 34 128)"><rect x="18" y="120" width="32" height="18" fill="#F4F0E4" ${SW2}/><text x="20" y="132" font-size="5.4" font-weight="bold" fill="${FI}">no ducks</text></g>`)+fG(g,2,`<circle cx="110" cy="102" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Ducks Unmentioned"]="Disguised Duck";SM("Ducks Unmentioned","Nothing To See","RES","s",0,100,"dodge,tacc-1","There are no ducks here. Definitely not. Move along.");

/* Fairholmite: delivered to a bakery and forgotten behind the flour. A blob of rising dough that has come to life, flour-dusted and stretching. */
addForm("Fairholmite",{n:"#F0E0C0",a:"#C8904A",rn:"#3A3A4A",rb:"#E8A0B0",ra:"#5FE0A0"},"ooze",(P,g)=>`<path d="M60 140 H150 L146 132 H64 Z" fill="#8A6A4A" ${SW}/>`+fShadow(54)+
 pt("sway",104,104,`<path d="M66 134 Q58 100 76 84 Q86 60 104 66 Q126 58 134 82 Q152 98 144 134 Z" fill="${P.n}" ${SW}/><path d="M80 90 Q90 80 100 84" stroke="#fff" stroke-width="3" fill="none" opacity=".6"/>${[[90,110],[118,102],[106,124],[130,118],[84,124]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="${P.ac}" opacity=".6"/>`).join("")}<path d="M70 132 Q104 124 140 132" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".5"/>`+
  pt("head",104,96,`${E2(94,94,4.6)}${E2(114,94,4.6)}`+HMOUTH(98,106,110,P,3)))+
 pt("armF",72,108,`<path d="M72 108 Q54 104 50 92" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M72 108 Q54 104 50 92" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/>`)+pt("armB",138,106,`<path d="M136 106 Q154 98 156 86" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M136 106 Q154 98 156 86" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/>`,.4)+
 `<g opacity=".7">${[[86,72],[120,66],[100,60],[140,90]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#fff"/>`).join("")}</g>`+
 fG(g,1,`<rect x="160" y="110" width="26" height="32" rx="4" fill="#E8D8B8" ${SW2}/><text x="163" y="128" font-size="7" font-weight="bold" fill="#8A6A4A">FLOUR</text>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Fairholmite"]="Rising Dough";SM("Fairholmite","Prove","RES","s",0,100,"def+1,atk+1","Leave it somewhere warm and it doubles in size.");
