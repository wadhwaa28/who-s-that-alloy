/* ---- Tinker's Scrapyard, 3 ---- */
/* Averagium: three calculators, three answers, so the lab averaged them. A Bactrian camel whose two humps make a bell curve. */
addForm("Averagium",{n:"#C8A070",a:"#3A5A8A",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(76)+
 pt("tail",164,96,fOL("M162 96 Q172 108 168 124",P.n,3)+`<path d="M164 120 l4 8 l4 -8" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",152,108,34,9,P.nd,P.ndd,.5)+fLeg("legB",118,110,32,9,P.nd,P.ndd,1.3)+
 `<path d="M86 100 Q86 88 98 86 Q108 50 120 84 Q132 50 146 86 Q166 88 166 102 Q162 118 126 118 Q90 118 86 100 Z" fill="${P.n}" ${SW}/><path d="M92 92 Q108 52 120 84 Q132 52 150 92" stroke="${P.ac}" stroke-width="2" fill="none" stroke-dasharray="4 3"/><path d="M90 108 H162" stroke="${P.ac}" stroke-width="1.6"/>${[100,120,140].map(x=>`<path d="M${x} 106 v4" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`+
 fLeg("legF",144,110,32,9,P.n,P.ndd,0)+fLeg("legF",102,110,32,9,P.n,P.ndd,.8)+
 pt("head",94,94,`<path d="M96 100 Q78 96 72 74" stroke="${FI}" stroke-width="16" fill="none" stroke-linecap="round"/><path d="M96 100 Q78 96 72 74" stroke="${P.n}" stroke-width="12.6" fill="none" stroke-linecap="round"/><path d="M46 72 Q48 58 66 58 Q80 60 80 72 Q76 82 62 82 L48 80 Z" fill="${P.n}" ${SW}/>${E2(64,68,3.4)}<path d="M48 78 L62 80 L60 84 L50 82 Z" fill="${FMOUTH}"/>`+pt("jaw",58,83,`<path d="M60 82 Q52 90 46 82 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",76,62,`<path d="M74 62 L80 54 L82 64 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<rect x="20" y="40" width="22" height="30" rx="3" fill="#3A3A44" ${SW2}/><rect x="23" y="43" width="16" height="7" fill="#9AD86A"/>${[0,1,2].map(r=>[0,1,2].map(c=>`<rect x="${23+c*5.6}" y="${53+r*5.4}" width="4" height="4" fill="#C8C8D0"/>`).join("")).join("")}`)+fG(g,2,`<circle cx="126" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Averagium"]="Bell-Curve Bactrian";SM("Averagium","Split The Difference","RES","s",0,100,"cure,heal:20","Not too much, not too little. Exactly in the middle.");

/* Back Soon Metal: a caving club crawled all Saturday to retrieve a sample someone left with a 'back soon' note. A cave swiftlet, clicking its way through the dark. */
addForm("Back Soon Metal",{n:"#5A4A44",a:"#E8D8C0",rn:"#3A3A4A",rb:"#7AB8C8",ra:"#F2C94C"},"hover",(P,g)=>`<path d="M14 14 H194 V34 Q160 44 130 30 Q100 46 70 32 Q40 44 14 32 Z" fill="#5A5A64" ${SW}/><path d="M14 150 V128 Q50 118 90 132 Q140 120 194 132 V150 Z" fill="#5A5A64" ${SW}/>${[40,90,150].map(x=>`<path d="M${x-6} ${36+(x%3)} L${x} ${54} L${x+6} ${36}" fill="#6A6A74" ${SW2}/>`).join("")}`+
 pt("wingB",112,80,`<path d="M110 80 Q140 56 180 60 Q150 74 130 92 Z" fill="${P.nd}" ${SW}/>`,.3)+
 pt("tail",128,90,`<path d="M124 86 L146 96 L138 98 L144 106 L124 96 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 90 Q84 76 104 76 Q124 78 130 92 Q120 100 104 100 Q86 100 80 90 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",98,82,`<path d="M98 82 Q66 52 26 58 Q58 72 80 96 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",80,86,`<circle cx="78" cy="86" r="10" fill="${P.n}" ${SW}/>${E2(76,84,3.2,"#1A1A1A")}`+HMOUTH(66,88,72,P,2))+
 pt("slow",50,90,`<path d="M58 80 q-6 6 0 12 M50 76 q-10 10 0 20 M42 72 q-14 14 0 28" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,1,`<g transform="rotate(-8 170 120)"><rect x="156" y="110" width="28" height="18" fill="#F2E060" ${SW2}/><text x="158" y="122" font-size="6" font-weight="bold" fill="${FI}">back soon</text></g>`)+fG(g,2,`<circle cx="104" cy="88" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,110,6)));
FORM_TITLE["Back Soon Metal"]="Echo-Clicking Cave Swiftlet";SM("Back Soon Metal","Echo Click","STR","a",60,100,"acc+1","Click, listen, turn. It never touches a wall.");

/* Backwardsium: fourth graders followed a recipe exactly backwards. A hummingbird, the bird that can fly backwards, doing exactly that. */
addForm("Backwardsium",{n:"#3AA87A",a:"#C8304A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="24" ry="3" fill="#000" opacity=".1"/><path d="M40 120 Q40 90 60 80" stroke="#5A9A3A" stroke-width="3" fill="none"/><path d="M60 80 Q50 70 54 60 Q64 66 62 78 Q74 70 72 82 Z" fill="#C8306A" ${SW2}/>`+
 pt("wingB",112,72,`<ellipse cx="124" cy="52" rx="10" ry="26" fill="${P.nl}" opacity=".6" ${SW2} transform="rotate(30 124 52)"/>`,.1)+
 pt("tail",132,100,`<path d="M126 96 L150 112 L140 116 L146 124 L124 106 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M92 92 Q94 74 112 74 Q130 78 132 98 Q124 108 110 108 Q96 108 92 92 Z" fill="${P.n}" ${SW}/><path d="M94 92 Q100 102 112 102 Q104 94 100 86 Z" fill="${P.ac}"/>`+
 pt("wingF",104,74,`<ellipse cx="96" cy="50" rx="10" ry="26" fill="${P.nl}" opacity=".7" ${SW2} transform="rotate(-24 96 50)"/>`)+
 pt("head",96,76,`<circle cx="96" cy="74" r="10" fill="${P.n}" ${SW}/>${E2(92,72,2.8,"#1A1A1A")}<path d="M86 76 L58 82 L86 78 Z" fill="${FI}"/>`+pt("tongue",62,82,`<path d="M62 82 l-6 2" stroke="${FTONGUE}" stroke-width="1.4"/>`))+
 fG(g,1,`<path d="M150 50 h24 M150 50 l6 -5 M150 50 l6 5" stroke="${P.ac}" stroke-width="2.4" fill="none"/><text x="150" y="70" font-size="9" font-weight="bold" fill="${P.ac}">ʇᴉ ǝʞɐɯ</text>`)+fG(g,2,`<circle cx="110" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,110,6)));
FORM_TITLE["Backwardsium"]="Reversing Hummingbird";SM("Backwardsium","Reverse","RES","s",0,100,"dodge,spd+1","Backwards, and somehow ahead of everyone.");

/* Bananium: the reason for the 'no labelling after midnight' rule: its tag says 'bananas??'. A banana slug, bright and slow and very confused about its label. */
addForm("Bananium",{n:"#E8D040",a:"#3A3A30",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#E8412C"},"ooze",(P,g)=>fShadow(70)+
 `<path d="M40 132 Q44 110 80 108 Q130 104 168 116 Q176 128 160 134 Q110 140 60 138 Q40 138 40 132 Z" fill="${P.n}" ${SW}/>${[[80,118],[104,114],[128,118],[146,122],[92,128],[120,128]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="3" ry="2" fill="${P.ac}" opacity=".7"/>`).join("")}<path d="M60 112 Q100 104 150 112" stroke="#F4F0C0" stroke-width="3" fill="none" opacity=".7"/><path d="M44 134 Q100 140 164 132" stroke="#C8B020" stroke-width="2" fill="none"/>`+
 pt("tail",166,124,`<path d="M164 124 Q180 122 186 128 Q176 132 164 130 Z" fill="${P.n}" ${SW2}/>`)+
 `<g transform="rotate(-10 120 98)"><path d="M112 104 L110 92 H132 L134 104 Z" fill="#F4E8C0" ${SW2}/><text x="112" y="101" font-size="6" font-weight="bold" fill="${FI}">bananas??</text></g>`+
 pt("head",50,120,`<path d="M30 126 Q30 108 48 106 Q64 108 64 124 Z" fill="${P.n}" ${SW}/>`+HMOUTH(32,124,40,P,2)+pt("ant",48,104,`<path d="M44 106 L36 84 M52 106 L56 84" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M44 106 L36 84 M52 106 L56 84" stroke="${P.n}" stroke-width="2.4" stroke-linecap="round"/>${E2(36,82,3.2)}${E2(56,82,3.2)}`))+
 fG(g,1,`<path d="M20 50 Q30 34 46 40 Q36 44 34 54 Q26 58 20 50 Z" fill="#E8D040" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Bananium"]="Banana Slug";SM("Bananium","Slime Trail","RES","s",0,100,"tspd-2","Slow, shiny, and the floor is never the same again.");

/* Barker's Muddle: carnival barkers get tongue-tied on its ingredients. A proboscis monkey whose enormous nose works like a barker's megaphone. */
addForm("Barker's Muddle",{n:"#C88A5A",a:"#E8B8A0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56)+
 pt("tail",126,118,`<path d="M124 120 Q154 126 160 146" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M124 120 Q154 126 160 146" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,130,fOL("M116 126 L120 142 H130",P.nd,9),.5)+
 `<path d="M80 128 Q76 94 104 88 Q130 94 128 128 Q122 142 104 142 Q86 142 80 128 Z" fill="${P.n}" ${SW}/><path d="M88 104 L104 96 L120 104 L118 134 Q104 138 90 134 Z" fill="#B8402A" ${SW2}/>${[104,112,120].map(y=>`<path d="M90 ${y} h28" stroke="#F2C94C" stroke-width="2"/>`).join("")}`+
 pt("legF",92,130,fOL("M94 126 L88 142 H78",P.n,9))+
 pt("armB",124,104,fOL("M124 104 Q138 108 140 120",P.nd,6),.4)+pt("armF",86,104,fOL("M86 104 Q70 110 66 122",P.n,6)+`<path d="M62 124 L60 142" stroke="#6A4A2A" stroke-width="3"/><circle cx="60" cy="122" r="4" fill="#F2C94C" ${SW2}/>`)+
 pt("head",104,72,`<path d="M82 74 Q82 52 104 50 Q126 52 126 74 Q122 88 104 88 Q86 88 82 74 Z" fill="${P.n}" ${SW}/>${E2(98,66,3.2,"#3A2410")}${E2(112,66,3.2,"#3A2410")}<path d="M100 72 Q86 76 82 90 Q90 98 100 92 Q106 82 108 74 Z" fill="${P.ac}" ${SW}/>`+HMOUTH(100,84,110,P,2)+
  `<path d="M84 52 Q104 40 124 52 L122 46 Q104 34 86 46 Z" fill="#E8D890" ${SW2}/><path d="M84 52 H124" stroke="#B8402A" stroke-width="3"/>`)+
 fG(g,1,`<path d="M26 70 q8 -6 16 0 M22 80 q12 -8 24 0 M30 60 q4 -3 8 0" stroke="${P.ac}" stroke-width="2" fill="none"/><text x="140" y="40" font-size="9" font-weight="bold" fill="${P.ac}">ROLL UP!</text>`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Barker's Muddle"]="Barker Proboscis Monkey";SM("Barker's Muddle","Roll Up","RES","a",60,100,"tacc-1,tspd-1@30","Roll up, roll up! See the... the... oh, never mind.");

/* Birdbath Metal: a gust blew the only copy of the recipe into a birdbath. A sparrow splashing in that birdbath. */
addForm("Birdbath Metal",{n:"#A88060",a:"#E8E0D0",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M98 146 V112 H110 V146 Z" fill="#B8B8C0" ${SW}/><ellipse cx="104" cy="146" rx="22" ry="4" fill="#A8A8B0" ${SW2}/><path d="M50 106 Q104 130 158 106 Z" fill="#B8B8C0" ${SW}/><ellipse cx="104" cy="106" rx="54" ry="8" fill="#9AC8E8" ${SW}/><g transform="rotate(10 140 104)"><rect x="130" y="100" width="20" height="10" fill="#F4F0E4" opacity=".7" ${SW2}/></g>`+
 pt("tail",120,96,`<path d="M116 92 L138 82 L134 96 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M84 104 Q84 82 104 80 Q122 84 122 104 Z" fill="${P.n}" ${SW}/><path d="M86 102 Q94 94 104 98 Q110 104 104 104 Z" fill="${P.ac}"/>`+
 pt("wingF",108,92,`<path d="M100 88 Q122 74 134 82 Q122 98 104 98 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${110+i*6} ${88-i*2} l6 -4" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",92,80,`<circle cx="90" cy="76" r="11" fill="${P.n}" ${SW}/><path d="M82 70 Q90 64 98 70" stroke="#8A6A4A" stroke-width="4" fill="none"/>${E2(88,76,2.8,"#1A1A1A")}<path d="M80 76 L72 78 L80 80 Z" fill="${FMOUTH}"/>`+pt("beak",80,80,`<path d="M80 80 L73 80 L80 82 Z" fill="#6A6A70"/>`)+`<path d="M80 74 L70 77 L80 78 Z" fill="#6A6A70"/>`)+
 pt("sway",104,94,`${[[72,92],[64,84],[140,90],[150,82],[76,98]].map(([x,y])=>`<path d="M${x} ${y} q-3 5 0 7 q3 -2 0 -7 Z" fill="#7AC8F0" ${SW2}/>`).join("")}`)+
 fG(g,1,`<path d="M20 40 q8 -10 18 -4 q-6 4 -8 10" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Birdbath Metal"]="Splashing Sparrow";SM("Birdbath Metal","Splash","DRP","a",50,100,"tacc-1","Wings out, water everywhere, and a very clean sparrow.");

/* Biscuitex: guards leave a biscuit for the resident ghost, and it's always nibbled by morning. A ghost crab (the real one) with that nibbled biscuit. */
addForm("Biscuitex",{n:"#E8DCC8",a:"#C89050",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 140 Q104 130 194 142 V150 H14 Z" fill="#E8D8B0" ${SW2}/>`+fShadow(66)+
 [0,1,2,3].map(i=>pt("legB",122+i*6,120,`<path d="M${122+i*6} 120 L${134+i*10} 108 L${142+i*10} 140" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${122+i*6} 120 L${134+i*10} 108 L${142+i*10} 140" stroke="${P.nd}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>`,i*.15)).join("")+
 `<path d="M80 122 Q82 98 112 96 Q142 98 146 120 Q140 132 112 132 Q84 132 80 122 Z" fill="${P.n}" ${SW}/><path d="M86 106 Q112 98 140 106" stroke="#fff" stroke-width="3" fill="none" opacity=".6"/>`+
 [0,1,2].map(i=>pt("legF",92+i*6,124,`<path d="M${92+i*6} 124 L${82+i*4} 112 L${74+i*6} 140" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${92+i*6} 124 L${82+i*4} 112 L${74+i*6} 140" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>`,i*.15+.1)).join("")+
 pt("claw",84,110,fOL("M86 112 Q70 104 64 94",P.n,6)+`<circle cx="52" cy="84" r="14" fill="${P.ac}" ${SW}/>${[[46,80],[54,88],[58,78]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.4" fill="#8A5A2A"/>`).join("")}<path d="M40 76 q4 4 0 8 q4 2 2 6" fill="#E8DCC8" stroke="none"/>`+pt("claw2",62,92,`<path d="M62 92 Q56 98 60 102 Q66 98 66 94 Z" fill="${P.nd}" ${SW2}/>`))+
 pt("head",112,100,`<path d="M104 100 L100 72 M120 100 L124 72" stroke="${FI}" stroke-width="3"/><path d="M96 64 h8 v14 h-8 Z M120 64 h8 v14 h-8 Z" fill="${FI}"/><circle cx="100" cy="68" r="2" fill="#fff"/><circle cx="124" cy="68" r="2" fill="#fff"/>`+HMOUTH(106,108,118,P,2))+
 fG(g,1,`<text x="150" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">boo</text>`)+fG(g,2,`<circle cx="112" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Biscuitex"]="Biscuit-Nibbling Ghost Crab";SM("Biscuitex","Midnight Nibble","RES","s",0,100,"heal:25,dodge","By morning there's only crumbs, and nobody saw a thing.");

/* Bless Us Mix: a sneeze and a thunderclap at exactly the same moment. A small storm cloud with a face, mid-sneeze, lightning out of its nose. */
addForm("Bless Us Mix",{n:"#8A90A0",a:"#F2D040",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/>`+
 pt("sway",104,76,`${[[72,84,20],[94,66,24],[122,64,22],[144,80,18],[110,90,26],[82,96,16],[136,96,16]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.n}" ${SW}/>`).join("")}${[[72,84,20],[94,66,24],[122,64,22],[144,80,18],[110,90,26]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r-2}" fill="${P.n}"/>`).join("")}<path d="M76 70 Q90 56 106 58" stroke="#C8C8D8" stroke-width="3" fill="none" opacity=".7"/>`+
  pt("head",104,82,`<path d="M88 78 q4 -3 8 0 M110 78 q4 -3 8 0" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M100 82 q3 3 6 0" stroke="${FI}" stroke-width="1.6" fill="none"/>`+pt("jaw",103,92,`<ellipse cx="103" cy="94" rx="6" ry="5" fill="${FMOUTH}" ${SW2}/>`)))+
 pt("tail",104,116,`<path d="M100 112 L92 128 L102 128 L94 146" stroke="${FI}" stroke-width="6" fill="none" stroke-linejoin="round"/><path d="M100 112 L92 128 L102 128 L94 146" stroke="${P.ac}" stroke-width="3.4" fill="none" stroke-linejoin="round"/>`)+
 pt("wingF",60,80,`${[[52,104],[60,116],[150,110],[160,100]].map(([x,y])=>`<path d="M${x} ${y} l-3 8" stroke="#7AB8E8" stroke-width="2" stroke-linecap="round"/>`).join("")}`)+
 fG(g,1,`<text x="20" y="40" font-size="12" font-weight="bold" fill="${P.ac}">ACH-</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,30,6)));
FORM_TITLE["Bless Us Mix"]="Sneezing Storm Cloud";SM("Bless Us Mix","Thunder Sneeze","DRP","a",75,95,"irr@30","Bless you! Everyone in the room jumps.");

/* Board No. 52: the oversight board has met about it every year since 1952; the snacks have improved. A kookaburra on the boardroom chair, laughing at the whole thing. */
addForm("Board No. 52",{n:"#C8B8A0",a:"#6A4A2A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"perch",(P,g)=>`<rect x="40" y="114" width="130" height="10" fill="#6A4A2A" ${SW}/><path d="M50 124 V146 M160 124 V146" stroke="#6A4A2A" stroke-width="6"/>${[[140,108],[150,110],[60,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4" fill="#E8C060" ${SW2}/>`).join("")}`+fShadow(40,104)+
 pt("tail",124,100,`<path d="M118 96 L146 104 L142 114 L120 106 Z" fill="${P.ac}" ${SW}/>${[128,136].map(x=>`<path d="M${x} ${100+(x-126)*.3} v8" stroke="#3A6AA8" stroke-width="2"/>`).join("")}`)+
 `<path d="M84 106 Q82 80 104 76 Q126 80 126 106 Q118 116 104 116 Q90 116 84 106 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",110,92,`<path d="M98 86 Q124 82 132 104 Q116 110 102 102 Z" fill="${P.ac}" ${SW}/><path d="M104 92 h16" stroke="#3A6AA8" stroke-width="3"/>`)+
 pt("legF",100,114,`<path d="M98 114 l-2 4 M102 114 l2 4" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",92,72,`<circle cx="90" cy="68" r="15" fill="${P.n}" ${SW}/><path d="M84 66 Q96 62 104 68" stroke="${P.ac}" stroke-width="4" fill="none"/>${E2(84,66,3.2,"#3A2410")}`+
  `<path d="M76 68 L52 74 L76 76 Z" fill="${FMOUTH}"/>`+pt("beak",76,76,`<path d="M76 76 L54 78 L76 82 Z" fill="${FI}"/>`)+`<path d="M76 62 L50 70 Q52 72 54 72 L76 70 Z" fill="${FI}"/>`)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">ha ha ha</text><text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}">1952</text>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,80,6)));
FORM_TITLE["Board No. 52"]="Boardroom Kookaburra";SM("Board No. 52","Laughing Fit","RES","s",0,100,"tatk-1,tacc-1","Seventy years of hearings, and it still finds them hilarious.");

/* Boomerangite: 'If found, return to Stores Room B'. It keeps being returned. A bandicoot carrying a boomerang that always comes home. */
addForm("Boomerangite",{n:"#B8905A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"hop",(P,g)=>fShadow(60,104)+
 pt("tail",142,118,`<path d="M138 118 Q160 122 168 116" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M138 118 Q160 122 168 116" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
 pt("legB",128,124,`<path d="M122 118 Q140 120 140 134 L154 140 H126 Z" fill="${P.nd}" ${SW}/>`,.0)+
 `<path d="M84 122 Q82 96 108 94 Q134 96 138 120 Q132 134 108 134 Q88 134 84 122 Z" fill="${P.n}" ${SW}/>${[116,124,132].map(x=>`<path d="M${x} 98 q-2 8 0 14" stroke="${P.nd}" stroke-width="3" fill="none"/>`).join("")}`+
 pt("legF",94,126,`<path d="M96 122 L86 138 H76" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M96 122 L86 138 H76" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("armF",90,108,fOL("M90 108 Q76 100 72 90",P.n,5)+`<path d="M56 78 Q72 72 80 86 L74 90 Q68 82 58 86 Z" fill="${P.ac}" ${SW}/><path d="M60 80 l6 2" stroke="#B8402A" stroke-width="2"/>`)+
 pt("head",92,96,`<path d="M54 102 Q56 86 74 84 Q92 86 94 100 Q90 112 74 112 L58 110 Z" fill="${P.n}" ${SW}/><path d="M54 102 L44 104 Q44 108 56 108 Z" fill="${P.n}" ${SW2}/><circle cx="45" cy="105" r="2.4" fill="${FI}"/>${E2(72,96,3.4,"#1A1A1A")}`+HMOUTH(52,108,60,P,1.8)+pt("ear",84,86,`<path d="M80 88 L82 72 L90 86 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M150 30 a20 20 0 1 1 -16 32" stroke="${P.ac}" stroke-width="2" stroke-dasharray="4 4" fill="none"/><path d="M134 62 l-2 -6 l6 2" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="108" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Boomerangite"]="Boomerang Bandicoot";SM("Boomerangite","Comes Back Round","STR","a",50,100,"multi:2-2","Out it goes, and back it comes for a second go.");
