/* ---- Rustvein Mine, 12 ---- */
/* Seventeen Across: the clue was 'Found where it was never left.' A cuckoo, sitting smugly in a nest that isn't its own. */
addForm("Seventeen Across",{n:"#7A8A9A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B88A50",ra:"#E8412C"},"perch",(P,g)=>`<path d="M58 140 Q56 116 104 114 Q152 116 150 140 Q104 150 58 140 Z" fill="#8A6A3A" ${SW}/>${Array.from({length:12},(_,i)=>`<path d="M${60+i*8} ${120+(i%3)*6} l${i%2?10:-8} ${i%2?8:6}" stroke="#5A4020" stroke-width="2" stroke-linecap="round"/>`).join("")}${[[140,124],[148,128]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="6" ry="7" fill="#9AD8E8" ${SW2}/>`).join("")}`+
 pt("tail",136,94,`<path d="M130 92 L174 84 L172 96 L132 104 Z" fill="${P.nd}" ${SW}/>${[146,156,166].map(x=>`<circle cx="${x}" cy="${88+(x-146)*-.05}" r="2" fill="#F4F0E4"/>`).join("")}`)+
 `<path d="M80 112 Q78 82 106 80 Q134 84 136 110 Q124 124 104 122 Q84 122 80 112 Z" fill="${P.n}" ${SW}/><path d="M84 110 Q100 124 122 116 Q110 106 96 96 Z" fill="${P.ac}"/>${[0,1,2,3].map(i=>`<path d="M${90+i*7} ${104+i*2} h6" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 pt("wingF",108,94,`<path d="M100 92 Q126 86 140 100 Q124 110 104 106 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",86,80,`<circle cx="82" cy="72" r="14" fill="${P.n}" ${SW}/>${E2(78,68,3.8,"#E8A020")}<path d="M74 64 l8 2" stroke="${FI}" stroke-width="1.6"/>`+
  `<path d="M68 72 L54 74 L68 76 Z" fill="${FMOUTH}"/>`+pt("beak",68,76,`<path d="M68 76 L56 76 L68 79 Z" fill="#E8C040" ${SW2}/>`)+`<path d="M68 70 Q58 70 52 74 L68 74 Z" fill="#E8C040" ${SW2}/>`)+
 fG(g,1,`<g transform="translate(20 30)">${[0,1,2].map(r=>[0,1,2].map(c=>`<rect x="${c*9}" y="${r*9}" width="9" height="9" fill="${(r+c)%3?"#fff":FI}" stroke="${FI}" stroke-width="1"/>`).join("")).join("")}<text x="1" y="7" font-size="5" fill="${FI}">17</text></g>`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Seventeen Across"]="Nest-Squatting Cuckoo";SM("Seventeen Across","Not My Nest","RES","s",0,100,"tdef-1,heal:20","Move in when nobody's looking and act like it was always yours.");


/* Shibuichi: its name means 'one-fourth'. A tanuki under a quarter moon, belly drum and all. */
addForm("Shibuichi",{n:"#8A7A6A",a:"#2A2A30",rn:"#E8D8C0",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>pt("slow",168,24,`<path d="M168 8 A16 16 0 0 1 168 40 Z" fill="#F4E8B0" ${SW2}/>`)+fShadow(56)+
 pt("tail",136,118,`<path d="M132 116 Q160 112 166 130 Q160 140 144 134 Z" fill="${P.n}" ${SW}/>${[146,154].map(x=>`<path d="M${x} ${118+(x-146)*.3} l2 12" stroke="${P.ac}" stroke-width="4"/>`).join("")}`)+
 pt("legB",120,132,`<ellipse cx="124" cy="140" rx="11" ry="5" fill="${P.ac}" ${SW2}/>`,.5)+
 `<path d="M78 124 Q72 88 104 84 Q136 88 132 124 Q126 142 104 142 Q82 142 78 124 Z" fill="${P.n}" ${SW}/><ellipse cx="104" cy="118" rx="20" ry="18" fill="${P.nl}" ${SW2}/><circle cx="104" cy="120" r="2.4" fill="${P.nd}"/>`+
 pt("legF",88,132,`<ellipse cx="84" cy="140" rx="11" ry="5" fill="${P.ac}" ${SW2}/>`)+
 pt("armF",82,104,fOL("M84 102 Q72 108 80 116",P.ac,8)+`<ellipse cx="84" cy="116" rx="4.4" ry="4" fill="${P.ac}" ${SW2}/>`)+pt("armB",126,104,fOL("M124 102 Q136 108 128 116",P.ac,8),.4)+
 pt("head",104,72,`<path d="M78 74 Q78 50 104 48 Q130 50 130 74 Q126 92 104 92 Q82 92 78 74 Z" fill="${P.n}" ${SW}/><path d="M84 68 Q92 60 100 70 Q94 78 84 76 Z M108 70 Q116 60 124 68 Q124 76 114 78 Z" fill="${P.ac}"/>${E2(92,70,3.6,"#C8A020")}${E2(116,70,3.6,"#C8A020")}<ellipse cx="104" cy="80" rx="8" ry="5" fill="${P.nl}"/><ellipse cx="104" cy="78" rx="3" ry="2.4" fill="${FI}"/>`+HMOUTH(100,84,108,P,2)+
  pt("ear",84,52,`<path d="M80 56 L82 42 L92 52 Z" fill="${P.ac}" ${SW2}/>`)+pt("ear",124,52,`<path d="M116 52 L126 42 L128 56 Z" fill="${P.ac}" ${SW2}/>`,.3)+`<path d="M88 50 Q104 34 120 50 L116 54 Q104 44 92 54 Z" fill="#5A9A4A" ${SW2}/>`)+
 fG(g,1,`<text x="20" y="40" font-size="16" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">¼</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Shibuichi"]="Quarter-Moon Tanuki";SM("Shibuichi","Belly Drum","RES","s",0,100,"atk+2","Pom, pom, pom. The drumming gets louder every time.");

/* Shortcut Mix: the team skipped two stages to impress the new manager. A roadrunner cutting across the corner, dust trailing. */
addForm("Shortcut Mix",{n:"#8A7A5A",a:"#3A6AA8",rn:"#3A3A4A",rb:"#E8C080",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 146 H120 V100 H194" stroke="#C8B890" stroke-width="10" fill="none" opacity=".6"/><path d="M60 146 Q120 140 160 100" stroke="#C8B890" stroke-width="3" stroke-dasharray="6 4" fill="none"/>`+fShadow(58,108)+
 `${[[150,132,8],[164,128,6],[176,136,5]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#D8C8A0" opacity=".7"/>`).join("")}`+
 pt("tail",132,84,`<path d="M126 86 L176 60 L180 68 L132 96 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${140+i*12} ${82-i*7} l8 3" stroke="#F4F0E4" stroke-width="2"/>`).join("")}`)+
 pt("legB",116,104,`<path d="M116 102 L136 124 L148 140" stroke="${FI}" stroke-width="4" fill="none" stroke-linejoin="round"/><path d="M144 140 l8 -2 M148 140 l6 4" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 `<path d="M82 92 Q86 72 110 72 Q132 76 134 96 Q124 108 106 108 Q88 106 82 92 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${94+i*8} ${80+i%2*4} l4 8" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 pt("legF",104,104,`<path d="M104 102 L92 124 L76 138" stroke="${FI}" stroke-width="4" fill="none" stroke-linejoin="round"/><path d="M76 138 l-8 0 M76 138 l-4 6" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 pt("head",86,76,`<path d="M90 82 Q78 70 76 56" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M90 82 Q78 70 76 56" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/><ellipse cx="72" cy="50" rx="12" ry="9" fill="${P.n}" ${SW}/>${E2(70,48,3.6,"#E8A020")}<path d="M74 52 l8 2" stroke="${P.ac}" stroke-width="2"/>`+
  `<path d="M62 50 L36 54 L62 56 Z" fill="${FMOUTH}"/>`+pt("beak",62,56,`<path d="M62 56 L38 56 L62 59 Z" fill="${FI}"/>`)+`<path d="M62 46 L34 52 L62 52 Z" fill="${FI}"/>`+
  pt("ant",76,42,`${[0,1,2,3].map(i=>`<path d="M${72+i*3} 42 L${76+i*6} ${26+i*2}" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M${72+i*3} 42 L${76+i*6} ${26+i*2}" stroke="${P.nd}" stroke-width="1.4" stroke-linecap="round"/>`).join("")}`))+
 fG(g,1,`<path d="M20 60 h-6 M26 70 h-10 M22 80 h-8" stroke="${P.l}" stroke-width="2.4" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="108" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Shortcut Mix"]="Corner-Cutting Roadrunner";SM("Shortcut Mix","Cut The Corner","STR","a",70,90,"prio","Why go around when you can go straight through?");

/* Signalman's Special: logged in a special ledger though no train carrying it was ever scheduled. An ibis whose raised wing is a railway semaphore arm. */
addForm("Signalman's Special",{n:"#F4F0E4",a:"#C8302A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50,110)+
 pt("tail",128,94,`<path d="M124 90 L144 100 L126 104 Z" fill="${FI}"/>`)+
 pt("legB",110,108,`<path d="M110 106 L114 144" stroke="${FI}" stroke-width="3.4"/><path d="M104 144 h16" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M80 96 Q82 74 106 72 Q128 76 130 98 Q122 112 102 112 Q84 110 80 96 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",98,108,`<path d="M98 106 L96 144" stroke="${FI}" stroke-width="3.4"/><path d="M88 144 h16" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("wingB",118,82,`<path d="M114 82 L152 40" stroke="${FI}" stroke-width="6" stroke-linecap="round"/><g transform="rotate(-48 152 40)"><rect x="140" y="34" width="44" height="12" fill="${P.ac}" ${SW}/><rect x="170" y="34" width="6" height="12" fill="#fff"/><circle cx="144" cy="40" r="3" fill="#F2C94C" ${SW2}/></g>`,.3)+
 pt("head",86,74,`<path d="M88 82 Q74 66 82 50" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M88 82 Q74 66 82 50" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="80" cy="44" r="10" fill="${FI}" ${SW}/>${E2(78,42,3,"#E8412C")}`+
  `<path d="M72 46 Q56 52 50 70 L56 70 Q60 56 72 50 Z" fill="${FMOUTH}"/>`+pt("beak",62,58,`<path d="M72 50 Q58 58 54 72 L50 70 Q56 54 72 46 Z" fill="${FI}"/>`)+`<path d="M72 42 Q54 48 46 68 L50 70 Q56 54 72 46 Z" fill="${FI}"/>`)+
 fG(g,1,`<rect x="160" y="110" width="30" height="34" fill="#8A6A4A" ${SW2}/><rect x="164" y="114" width="22" height="14" fill="#F4F0E4" ${SW2}/><path d="M166 118 h18 M166 122 h12" stroke="#8A8A9A" stroke-width="1"/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Signalman's Special"]="Semaphore Ibis";SM("Signalman's Special","Clear Signal","RES","s",0,100,"spd+1,acc+1","Arm up. The line ahead is clear.");


/* Single Rack Blend: the recipe was jotted using only letters from one rack. An ankylosaur armoured in letter tiles, its tail club a single tile. */
addForm("Single Rack Blend",{n:"#8A7A5A",a:"#E8D8A8",rn:"#3A3A4A",rb:"#B84A3A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(80)+
 pt("tail",164,108,`<path d="M160 106 Q182 108 186 118" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M160 106 Q182 108 186 118" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><rect x="178" y="112" width="18" height="18" rx="2" fill="${P.ac}" ${SW}/><text x="182" y="126" font-size="12" font-weight="bold" fill="${FI}">Z</text>`)+
 fLeg("legB",148,116,22,11,P.nd,P.ndd,.5)+fLeg("legB",110,118,20,11,P.nd,P.ndd,1.3)+
 `<path d="M76 114 Q76 80 120 78 Q164 80 166 112 Q160 128 120 128 Q82 128 76 114 Z" fill="${P.n}" ${SW}/>`+
 `${[[88,96,"Q"],[104,86,"U"],[120,82,"I"],[136,86,"E"],[150,96,"T"],[96,108,"A"],[114,100,"R"],[132,100,"S"],[148,110,"N"]].map(([x,y,l])=>`<rect x="${x-7}" y="${y-7}" width="14" height="14" rx="2" fill="${P.ac}" ${SW2}/><text x="${x-3.6}" y="${y+4}" font-size="10" font-weight="bold" fill="${FI}">${l}</text>`).join("")}`+
 fLeg("legF",140,120,20,11,P.n,P.ndd,0)+fLeg("legF",96,120,20,11,P.n,P.ndd,.8)+
 pt("head",80,108,`<path d="M44 112 Q44 96 62 94 Q82 96 82 112 Q78 124 62 124 Q48 124 44 112 Z" fill="${P.n}" ${SW}/><path d="M48 100 l-6 -6 M72 96 l4 -8" stroke="${P.nd}" stroke-width="4" stroke-linecap="round"/>${E2(62,104,3.6)}`+HMOUTH(44,116,54,P,2.6))+
 fG(g,1,`<rect x="18" y="128" width="34" height="10" rx="2" fill="#8A5A2A" ${SW2}/>${[22,30,38].map(x=>`<rect x="${x}" y="122" width="7" height="7" fill="${P.ac}" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="120" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(120,50,6)));
FORM_TITLE["Single Rack Blend"]="Letter-Tile Ankylosaur";SM("Single Rack Blend","Triple Word","STR","a",90,85,"","Land it on the right square and it counts three times over.");

/* Skater's Special: pushed across the ice in a relay, then nobody knew where it was going. A polar bear on skates, shoving a crate. */
addForm("Skater's Special",{n:"#F4F0E8",a:"#5A8AC8",rn:"#3A3A4A",rb:"#C8A070",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 142 H194" stroke="#C8E8F8" stroke-width="10"/><path d="M30 140 q20 -4 40 0 M110 142 q20 -4 40 0" stroke="#fff" stroke-width="2" fill="none"/>`+fShadow(80)+
 `<rect x="24" y="96" width="38" height="40" rx="2" fill="#B88A50" ${SW}/><path d="M24 116 h38 M36 96 v40" stroke="#8A6030" stroke-width="2"/>`+
 pt("tail",160,98,`<circle cx="162" cy="98" r="5" fill="${P.n}" ${SW2}/>`)+
 [[146,"legB",.5],[112,"legB",1.3]].map(([x,c,d])=>pt(c,x,114,`<rect x="${x-6}" y="112" width="12" height="22" rx="5" fill="${P.nd}" ${SW2}/><path d="M${x-10} 134 h18 v4 h-18 Z" fill="${P.ac}" ${SW2}/><path d="M${x-12} 140 h22" stroke="${FI}" stroke-width="2"/>`,d)).join("")+
 `<path d="M84 104 Q82 74 122 72 Q160 74 164 102 Q160 122 124 122 Q88 122 84 104 Z" fill="${P.n}" ${SW}/><path d="M92 86 Q104 80 112 90 L130 86 Q144 80 152 90" stroke="#E8412C" stroke-width="5" fill="none"/>`+
 [[136,"legF",0],[100,"legF",.8]].map(([x,c,d])=>pt(c,x,116,`<rect x="${x-6}" y="114" width="12" height="20" rx="5" fill="${P.n}" ${SW2}/><path d="M${x-10} 134 h18 v4 h-18 Z" fill="${P.ac}" ${SW2}/><path d="M${x-12} 140 h22" stroke="${FI}" stroke-width="2"/>`,d)).join("")+
 pt("armF",88,96,fOL("M90 96 Q76 98 64 106",P.n,10)+`<ellipse cx="62" cy="108" rx="5" ry="6" fill="${P.n}" ${SW2}/>`)+
 pt("head",88,84,`<path d="M54 86 Q54 66 74 64 Q94 66 96 84 Q92 98 74 98 Q58 98 54 86 Z" fill="${P.n}" ${SW}/><ellipse cx="55" cy="84" rx="3.6" ry="3" fill="${FI}"/>${E2(70,78,3.6)}`+HMOUTH(56,90,64,P,2.4)+pt("ear",84,66,`<circle cx="84" cy="66" r="5" fill="${P.n}" ${SW2}/>`)+`<path d="M70 66 Q80 50 92 66 Z" fill="#E8412C" ${SW2}/><circle cx="81" cy="54" r="4" fill="#F4F0F4" ${SW2}/>`)+
 fG(g,1,`<path d="M180 120 l-8 -16 M188 120 l0 -18" stroke="#C8E8F8" stroke-width="3"/>`)+fG(g,2,`<circle cx="124" cy="108" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Skater's Special"]="Relay-Skating Polar Bear";SM("Skater's Special","Hand-Off","STR","a",65,100,"spd+1","Push it on to the next one and hope they know where it's going.");

/* Sledge Run Blend: nine days by sledge to a weather hut. A husky in harness, frost on its whiskers, pulling hard. */
addForm("Sledge Run Blend",{n:"#8A8A98",a:"#F4F0F4",rn:"#3A3A4A",rb:"#C8A070",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M14 144 H194" stroke="#E8F0F8" stroke-width="8"/>`+`<path d="M150 112 L186 112 L190 128 L150 128 Z" fill="#B88A50" ${SW}/><path d="M146 134 H192 Q196 134 196 128" stroke="${FI}" stroke-width="3" fill="none"/><path d="M152 128 v6 M184 128 v6" stroke="${FI}" stroke-width="2.4"/><rect x="156" y="98" width="24" height="16" fill="#C89A5A" ${SW2}/>`+fShadow(66)+
 `<path d="M136 96 L152 114" stroke="#3A3A44" stroke-width="2"/>`+
 pt("tail",136,86,`<path d="M134 88 Q150 76 146 64 Q138 66 140 76" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M134 88 Q150 76 146 64 Q138 66 140 76" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",126,104,34,8,P.nd,P.ndd,.5)+fLeg("legB",96,106,32,8,P.nd,P.ndd,1.3)+
 `<path d="M72 98 Q72 76 104 74 Q134 76 138 96 Q134 112 106 112 Q76 112 72 98 Z" fill="${P.n}" ${SW}/><path d="M76 100 Q104 112 132 100" stroke="${P.ac}" stroke-width="6" fill="none"/><path d="M84 80 L84 108 M84 92 L136 96" stroke="#C83A2A" stroke-width="4"/>`+
 fLeg("legF",118,106,32,8,P.ac,P.ndd,0)+pt("legF",80,104,`<path d="M80 102 L64 118 L58 136" stroke="${FI}" stroke-width="10" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M80 102 L64 118 L58 136" stroke="${P.ac}" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,.8)+
 pt("head",76,86,`<path d="M40 82 Q40 64 58 62 Q78 64 80 80 Q76 94 58 94 Q44 94 40 82 Z" fill="${P.n}" ${SW}/><path d="M40 84 Q46 76 56 80 Q60 90 50 94 Q42 92 40 84 Z" fill="${P.ac}"/><path d="M50 70 Q58 66 66 72 L64 76 Q58 72 52 76 Z" fill="${P.ac}"/><ellipse cx="40" cy="82" rx="3" ry="2.6" fill="${FI}"/>${E2(58,74,3.6,"#4A8AE8")}`+
  `<path d="M42 88 L56 90 L54 94 L44 92 Z" fill="${FMOUTH}"/>`+pt("jaw",54,93,`<path d="M56 92 Q48 100 42 92 Q48 96 56 95 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M44 86 h-8 M44 88 l-8 3" stroke="#fff" stroke-width="1.4"/>`+
  pt("ear",66,64,`<path d="M62 66 L66 50 L74 64 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",74,66,`<path d="M72 64 L80 52 L82 68 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M20 30 l4 8 l-8 -4 h8 l-8 4 Z" fill="none" stroke="#9AC8E8" stroke-width="2"/>`)+fG(g,2,`<circle cx="106" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,40,6)));
FORM_TITLE["Sledge Run Blend"]="Sledge Husky";SM("Sledge Run Blend","Mush","STR","a",75,100,"spd+1@40","Nine days out, and still pulling.");

/* Speculum Metal: Newton ground his first reflecting telescope's mirror from it. A telescope-eyed goldfish, each bulging eye a lens. */
addForm("Speculum Metal",{n:"#E8A040",a:"#C8D8E8",rn:"#3A3A4A",rb:"#B85AC8",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",140,84,`<path d="M134 84 Q160 52 186 58 Q168 76 176 84 Q168 92 186 112 Q160 116 134 88 Z" fill="${P.n}" opacity=".9" ${SW}/>${[0,1,2].map(i=>`<path d="M140 ${82+i*2} Q164 ${66+i*14} 178 ${66+i*20}" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`)+
 pt("wingB",114,62,`<path d="M110 66 Q118 40 136 38 Q132 56 124 68 Z" fill="${P.nd}" ${SW2}/>`,.3)+
 `<path d="M66 84 Q70 58 104 56 Q136 60 140 84 Q134 110 104 110 Q72 108 66 84 Z" fill="${P.n}" ${SW}/>${[[96,72],[112,70],[104,86],[120,84],[92,94],[112,98]].map(([x,y])=>`<path d="M${x-5} ${y} q5 5 10 0" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 pt("wingF",100,96,`<path d="M100 98 Q94 118 80 122 Q84 106 94 96 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",74,80,`<path d="M74 70 L64 64" stroke="${FI}" stroke-width="12" stroke-linecap="round"/><path d="M74 70 L64 64" stroke="${P.n}" stroke-width="9" stroke-linecap="round"/><circle cx="58" cy="60" r="12" fill="${P.ac}" ${SW}/><circle cx="58" cy="60" r="8" fill="#9AB8D8" ${SW2}/><circle cx="56" cy="58" r="3.4" fill="${FI}"/><path d="M52 54 Q54 52 58 52" stroke="#fff" stroke-width="2" fill="none"/>`+
  `<path d="M80 80 L74 92" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><circle cx="72" cy="98" r="9" fill="${P.ac}" ${SW}/><circle cx="72" cy="98" r="5.6" fill="#9AB8D8" ${SW2}/><circle cx="71" cy="97" r="2.4" fill="${FI}"/>`+pt("jaw",64,82,`<ellipse cx="64" cy="82" rx="4" ry="3.4" fill="${FMOUTH}" ${SW2}/>`))+
 fG(g,1,`<circle cx="28" cy="40" r="4" fill="#F4F0E4" ${SW2}/><circle cx="20" cy="54" r="2.4" fill="#F4F0E4" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Speculum Metal"]="Telescope-Eyed Goldfish";SM("Speculum Metal","Reflect","RES","s",0,100,"ward+2","Polished so true it throws everything back the way it came.");
