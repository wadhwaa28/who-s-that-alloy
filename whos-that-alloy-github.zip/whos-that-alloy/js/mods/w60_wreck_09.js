/* ---- Shipwreck Coast, 9 ---- */
/* Tarrant Claim: unclaimed lost property goes to auction after ninety days; this hasn't. A great auk, the long-gone seabird, lot ticket round its neck. */
addForm("Tarrant Claim",{n:"#2A2A30",a:"#F4F0F4",rn:"#E8D8C8",rb:"#5A8AC8",ra:"#E8412C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",116,132,`<path d="M108 138 h16 l-4 -6 h-8 Z" fill="${FI}" ${SW2}/>`,.5)+
 `<path d="M80 126 Q74 80 102 70 Q130 78 128 126 Q122 142 104 142 Q86 142 80 126 Z" fill="${P.n}" ${SW}/><path d="M88 126 Q86 92 102 86 Q118 92 118 126 Q114 138 104 138 Q92 138 88 126 Z" fill="${P.ac}"/>`+
 pt("legF",94,132,`<path d="M86 138 h16 l-4 -6 h-8 Z" fill="${FI}" ${SW2}/>`)+
 pt("wingF",82,98,`<path d="M84 90 Q70 104 74 124 Q82 118 86 104 Z" fill="${P.n}" ${SW}/>`)+pt("wingB",124,98,`<path d="M122 90 Q136 104 132 124 Q124 118 120 104 Z" fill="${P.n}" ${SW}/>`,.4)+
 pt("head",100,62,`<circle cx="100" cy="58" r="15" fill="${P.n}" ${SW}/><ellipse cx="96" cy="56" rx="5" ry="4" fill="${P.ac}"/>${E2(96,56,2.8,"#3A2410")}`+
  `<path d="M86 56 Q72 54 66 66 L86 64 Z" fill="${FMOUTH}"/>`+pt("beak",76,66,`<path d="M86 64 L66 66 Q70 72 86 68 Z" fill="${FI}"/>`)+`<path d="M86 50 Q68 50 64 66 L86 58 Z" fill="${FI}"/><path d="M72 56 v6 M76 54 v7" stroke="${P.ac}" stroke-width="1.4"/>`+
  `<path d="M94 74 L100 82 L106 74" stroke="#C8A060" stroke-width="1.6" fill="none"/><rect x="92" y="82" width="16" height="10" fill="#F4E8C0" ${SW2}/><text x="94" y="90" font-size="6" font-weight="bold" fill="${FI}">LOT</text>`)+
 fG(g,1,`<rect x="150" y="30" width="34" height="16" rx="2" fill="#F4F0E4" ${SW2}/><text x="153" y="42" font-size="8" font-weight="bold" fill="#C8302A">90 days</text>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tarrant Claim"]="Lost-Property Great Auk";SM("Tarrant Claim","Unclaimed","RES","s",0,100,"endure","Nobody ever came for it. It's still here.");

/* Thirteen Special: thirteen crates on Friday the thirteenth, all fine. A horseshoe crab, the lucky horseshoe that's been around four hundred million years. */
addForm("Thirteen Special",{n:"#8A6A4A",a:"#F2C94C",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",150,118,`<path d="M146 116 L192 126" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M146 116 L192 126" stroke="${P.nd}" stroke-width="2.6" stroke-linecap="round"/>`)+
 Array.from({length:5},(_,i)=>pt(i%2?"legB":"legF",88+i*12,128,`<path d="M${88+i*12} 126 L${84+i*12} 140" stroke="${FI}" stroke-width="2.4"/>`,i*.15)).join("")+
 `<path d="M56 128 Q58 84 104 80 Q134 82 146 104 L150 128 Z" fill="${P.n}" ${SW}/><path d="M58 128 Q60 92 100 88 Q120 90 126 100 Q118 128 110 128" fill="none" stroke="${P.nd}" stroke-width="2"/><path d="M126 100 L148 104 L150 128 L120 128 Z" fill="${P.nd}" ${SW2}/>${[130,138,144].map(x=>`<path d="M${x} 106 l-2 -4" stroke="${FI}" stroke-width="2"/>`).join("")}<path d="M70 120 Q72 100 100 98" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".6"/>`+
 pt("head",80,100,`${E2(74,98,3.4,"#1A1A1A")}${E2(94,94,3.2,"#1A1A1A")}`+HMOUTH(76,110,86,P,2))+
 fG(g,1,`<path d="M30 40 Q30 24 40 24 Q50 24 50 40" stroke="${P.ac}" stroke-width="5" fill="none"/><text x="160" y="40" font-size="14" font-weight="bold" fill="${P.ac}">13</text>`)+fG(g,2,`<circle cx="100" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,60,6)));
FORM_TITLE["Thirteen Special"]="Lucky Horseshoe Crab";SM("Thirteen Special","Lucky Thirteen","RES","s",0,100,"endure,def+1","Supposed to be unlucky. Turned out fine.");

/* Thirty-One Mix: thirty-one pages of warnings; page thirty-one: 'You have been warned thirty times.' A poison dart frog, its whole body a warning sign. */
addForm("Thirty-One Mix",{n:"#E8C020",a:"#2A2A30",rn:"#3A3A4A",rb:"#3A8AC8",ra:"#E8412C"},"hop",(P,g)=>`<path d="M14 140 Q104 128 194 142" stroke="#5A8A3A" stroke-width="10" stroke-linecap="round"/>`+fShadow(60,104)+
 pt("legB",140,124,`<path d="M130 112 Q160 106 158 130 L170 138 H136 Z" fill="${P.n}" ${SW}/><path d="M138 128 l16 -12 M146 132 l12 -10" stroke="${P.ac}" stroke-width="3"/>`,.0)+
 `<path d="M70 116 Q66 84 104 80 Q140 84 138 116 Q134 134 104 134 Q74 134 70 116 Z" fill="${P.n}" ${SW}/>${[[86,96],[108,92],[124,104],[96,118],[118,122]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="7" ry="5" fill="${P.ac}" transform="rotate(${x%30} ${x} ${y})"/>`).join("")}`+
 pt("legF",80,124,`<path d="M86 114 Q60 110 60 132 L48 138 H84 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<circle cx="${52+i*8}" cy="140" r="3" fill="${P.n}" ${SW2}/>`).join("")}`)+
 pt("head",84,94,`<path d="M52 96 Q52 78 72 76 Q90 78 92 94 Q88 108 72 108 Q56 108 52 96 Z" fill="${P.n}" ${SW}/><circle cx="64" cy="80" r="7" fill="${P.ac}" ${SW2}/><circle cx="80" cy="78" r="7" fill="${P.ac}" ${SW2}/><circle cx="63" cy="79" r="2" fill="#fff"/><circle cx="79" cy="77" r="2" fill="#fff"/>`+
  `<path d="M54 98 L78 100 L76 104 L56 102 Z" fill="${FMOUTH}"/>`+pt("jaw",74,103,`<path d="M78 102 Q66 110 54 100 Q66 106 78 105 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M150 20 L168 50 H132 Z" fill="${P.n}" ${SW2}/><text x="146" y="46" font-size="18" font-weight="bold" fill="${FI}">!</text>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Thirty-One Mix"]="Warning-Sign Dart Frog";SM("Thirty-One Mix","You Were Warned","SCR","a",50,100,"corrode@50","Thirty warnings. Nobody can say they weren't told.");

/* Thursdayite: first of 'three strange mixtures born of one Thursday'. A thunderbird, the storm-bird of legend, for Thor's day. */
addForm("Thursdayite",{n:"#3A4A7A",a:"#F2C94C",rn:"#E8D8C8",rb:"#B8402A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",116,70,`<path d="M114 72 L150 30 L156 46 L176 38 L170 58 L190 60 L160 82 L124 86 Z" fill="${P.nd}" ${SW}/>`,.3)+
 pt("tail",116,104,`<path d="M110 100 L104 136 L114 126 L120 140 L124 124 L132 132 L126 100 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M84 96 Q86 70 108 68 Q130 72 130 98 Q122 110 106 110 Q90 108 84 96 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${96+i*8} 84 l4 -4 l-2 8 l4 -2" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("wingF",96,72,`<path d="M98 74 L60 30 L56 48 L34 38 L40 58 L18 62 L50 84 L88 88 Z" fill="${P.n}" ${SW}/>${[[46,52],[60,62],[76,74]].map(([x,y])=>`<path d="M${x} ${y} l6 -6 l-2 6 l6 -4" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")}`)+
 pt("legF",104,108,`<path d="M100 108 l-4 10 M108 108 l4 10" stroke="${FI}" stroke-width="3"/><path d="M92 120 l4 -2 l4 2 M108 120 l4 -2 l4 2" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 pt("head",96,60,`<path d="M84 62 Q84 44 100 42 Q114 44 114 60 Q110 70 98 70 Q88 70 84 62 Z" fill="${P.n}" ${SW}/>${E2(94,54,3.6,"#F2C94C")}<path d="M88 48 l10 4" stroke="${FI}" stroke-width="2.4"/><path d="M90 42 L94 30 L98 40 L104 26 L106 42" fill="${P.ac}" ${SW2}/>`+
  `<path d="M84 58 Q70 58 66 68 L84 66 Z" fill="${FMOUTH}"/>`+pt("beak",76,68,`<path d="M84 66 Q74 74 68 70 Q74 68 84 64 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M86 54 Q70 52 64 66 L84 60 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M170 110 l-8 12 h6 l-6 14" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+fG(g,2,`<circle cx="106" cy="94" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,16,6)));
FORM_TITLE["Thursdayite"]="Thor's-Day Thunderbird";SM("Thursdayite","Thunderclap","DRP","a",85,90,"irr@30","One beat of those wings and the sky cracks open.");

/* Tortoisium: the lab tortoise sat on the emergency stop button and saved the day. That tortoise, its shell a big red stop button. */
addForm("Tortoisium",{n:"#7A8A5A",a:"#E8412C",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",156,124,`<path d="M152 120 L166 124 L152 128 Z" fill="${P.n}" ${SW2}/>`)+
 [[144,.5],[100,0]].map(([x,d])=>pt("legB",x,124,`<path d="M${x-6} 122 L${x-8} 144 H${x+6} L${x+6} 122 Z" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M72 126 Q70 104 114 102 Q156 104 156 126 Z" fill="#F2C94C" ${SW}/>${[0,1,2,3,4,5,6].map(i=>`<path d="M${78+i*11} 124 l8 -14" stroke="${FI}" stroke-width="4"/>`).join("")}<path d="M80 104 Q80 70 114 68 Q148 70 148 104 Z" fill="${P.ac}" ${SW}/><path d="M92 80 Q104 72 118 74" stroke="#fff" stroke-width="4" fill="none" opacity=".5"/><text x="96" y="98" font-size="11" font-weight="bold" fill="#F4F0F4">STOP</text><path d="M70 126 H158" stroke="${FI}" stroke-width="4"/>`+
 [[132,.5],[86,0]].map(([x,d])=>pt("legF",x,124,`<path d="M${x-6} 122 L${x-8} 145 H${x+6} L${x+6} 122 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",72,116,fOL("M76 118 Q62 116 54 108",P.n,11)+`<path d="M30 104 Q32 90 48 90 Q62 92 62 104 Q58 112 46 112 Q32 112 30 104 Z" fill="${P.n}" ${SW}/><path d="M38 96 q4 2 8 0" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(32,106,40,P,3))+
 fG(g,1,`<path d="M170 40 a10 10 0 1 1 -1 0" stroke="${P.ac}" stroke-width="3" fill="none"/><path d="M170 30 v12" stroke="${P.ac}" stroke-width="3"/>`)+fG(g,2,`<circle cx="114" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tortoisium"]="Emergency-Stop Tortoise";SM("Tortoisium","Emergency Stop","RES","s",0,100,"tspd-2,def+1","Everything stops. Right now. Thank you, tortoise.");

/* Tuesdium: timers set to minutes instead of hours. An hourglass dolphin, the real one, marked like a sand-timer. */
addForm("Tuesdium",{n:"#2A2A30",a:"#F4F0F4",rn:"#E8D8C8",rb:"#5AB0C8",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M14 120 Q60 112 104 120 Q150 128 194 118 V150 H14 Z" fill="#5A8AA8" opacity=".4"/>`+
 pt("tail",156,84,`<path d="M148 84 L172 64 L168 84 L180 102 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",112,66,`<path d="M108 68 Q112 44 126 40 Q124 58 118 70 Z" fill="${P.n}" ${SW}/>`,.3)+
 `<path d="M44 90 Q52 64 100 64 Q136 66 152 84 Q140 104 104 106 Q66 108 50 100 Z" fill="${P.n}" ${SW}/><path d="M70 72 Q86 86 100 86 Q86 92 74 104 Q86 104 104 92 Q118 102 136 98 Q122 88 112 86 Q128 80 140 74 Q120 76 104 84 Z" fill="${P.ac}"/>`+
 pt("wingF",88,98,`<path d="M86 100 Q80 118 66 124 Q72 110 82 98 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",56,88,`${E2(60,84,3.4,"#1A1A1A")}`+pt("jaw",40,96,`<path d="M32 92 L50 94 Q46 100 34 98 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M32 90 Q36 86 46 88" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<path d="M160 20 h20 l-10 14 l10 14 h-20 l10 -14 Z" fill="none" stroke="${P.ac}" stroke-width="2"/><path d="M166 42 h8 l-4 -4 Z" fill="#E8C060"/>`)+fG(g,2,`<circle cx="104" cy="86" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tuesdium"]="Hourglass Dolphin";SM("Tuesdium","Wrong Units","STR","a",70,100,"prio","Minutes where it should have been hours. Everything happens far too soon.");

/* Tuller's Keepsake: a retiring postmistress asked for nothing but a sample in a presentation box. An ermine nestled in that velvet box. */
addForm("Tuller's Keepsake",{n:"#F4F0F4",a:"#2A2A30",rn:"#3A3A4A",rb:"#7A2A4A",ra:"#F2C94C"},"perch",(P,g)=>fShadow(66)+
 `<path d="M48 132 L56 100 H152 L160 132 Z" fill="#5A1A2A" ${SW}/><path d="M60 104 H148 L152 128 H56 Z" fill="#8A2A4A"/><path d="M56 100 L60 56 H148 L152 100" fill="#7A2A3A" ${SW}/><path d="M64 62 H144 L146 96 H62 Z" fill="#9A3A5A"/><rect x="96" y="128" width="16" height="6" fill="#C8A040" ${SW2}/>`+
 pt("tail",136,110,`<path d="M132 114 Q150 108 152 96" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M132 114 Q150 108 152 96" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M150 100 l3 -8" stroke="${P.ac}" stroke-width="6" stroke-linecap="round"/>`)+
 `<path d="M68 118 Q70 102 100 100 Q130 102 136 116 Q130 124 100 124 Q72 124 68 118 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",76,116,`<ellipse cx="74" cy="118" rx="6" ry="3.4" fill="${P.n}" ${SW2}/>`)+
 pt("head",78,104,`<path d="M54 106 Q56 92 72 90 Q88 92 90 104 Q86 116 72 116 Q58 116 54 106 Z" fill="${P.n}" ${SW}/><ellipse cx="54" cy="106" rx="2.6" ry="2.2" fill="${FI}"/>${E2(68,100,3.2,"#1A1A1A")}`+HMOUTH(56,110,64,P,1.8)+pt("ear",82,92,`<circle cx="82" cy="92" r="4" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<rect x="160" y="30" width="22" height="16" fill="#F4F0E4" ${SW2}/><path d="M160 30 l11 8 l11 -8" stroke="${FI}" stroke-width="1.2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Tuller's Keepsake"]="Keepsake-Box Ermine";SM("Tuller's Keepsake","No Fuss","RES","s",0,100,"heal:40","No cake, no speeches. Just this, in a box.");

/* Twelfth Fielder: scored as the twelfth fielder for a whole afternoon. A stork fielding at long leg, one leg up, ball caught. */
addForm("Twelfth Fielder",{n:"#F4F0F4",a:"#2A2A30",rn:"#3A3A4A",rb:"#5A9A3A",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 142 H194" stroke="#5A9A3A" stroke-width="8"/><path d="M168 142 V100 M176 142 V100 M184 142 V100 M166 100 h20" stroke="#E8D8B0" stroke-width="3"/>`+fShadow(48,110)+
 pt("tail",128,84,`<path d="M124 80 L146 88 L126 94 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",112,98,`<path d="M112 96 L124 112 L110 118" stroke="#E8604A" stroke-width="3.6" fill="none" stroke-linejoin="round"/>`,.5)+
 `<path d="M82 84 Q84 62 106 60 Q128 64 130 86 Q122 98 104 98 Q88 96 82 84 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",108,76,`<path d="M98 72 Q122 66 134 84 Q118 94 100 88 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legF",100,98,`<path d="M100 96 L100 142" stroke="#E8604A" stroke-width="3.6"/><path d="M92 142 h16" stroke="#E8604A" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",90,62,`<path d="M92 72 Q82 52 88 36" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M92 72 Q82 52 88 36" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="86" cy="30" r="10" fill="${P.n}" ${SW}/>${E2(84,28,2.8,"#1A1A1A")}`+
  `<path d="M76 30 L50 38 L76 34 Z" fill="${FMOUTH}"/>`+pt("beak",76,36,`<path d="M76 34 L52 40 L76 38 Z" fill="#E8604A" ${SW2}/>`)+`<path d="M76 26 L48 36 L76 32 Z" fill="#E8604A" ${SW2}/><circle cx="50" cy="38" r="5" fill="#C8302A" ${SW2}/><path d="M47 35 q3 3 6 0" stroke="#F4F0F4" stroke-width="1" fill="none"/>`)+
 fG(g,1,`<rect x="20" y="40" width="30" height="16" rx="2" fill="#F4F0E4" ${SW2}/><text x="23" y="52" font-size="9" font-weight="bold" fill="${FI}">XII</text>`)+fG(g,2,`<circle cx="106" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Twelfth Fielder"]="Long-Leg Stork";SM("Twelfth Fielder","Safe Hands","RES","a",60,100,"crit","Up it goes, down it comes, straight into the beak.");

/* Umbrellium: seventeen umbrellas left behind on a cloudless day. An umbrellabird, its crest flipped over its head like a little umbrella. */
addForm("Umbrellium",{n:"#1A1A24",a:"#5A8AC8",rn:"#E8D8C8",rb:"#B8402A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 120 H194" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(30,104)+
 pt("tail",124,106,`<path d="M120 102 L140 128 L128 130 L114 108 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M86 108 Q84 80 104 76 Q126 80 126 108 Q118 120 104 120 Q92 120 86 108 Z" fill="${P.n}" ${SW}/>`+
 pt("tongue",100,112,`<path d="M100 92 Q96 112 100 132 Q106 140 108 130 Q110 110 108 92 Z" fill="${P.n}" ${SW}/>${[100,110,120].map(y=>`<path d="M100 ${y} q4 3 8 0" stroke="${P.ac}" stroke-width="1.4" fill="none"/>`).join("")}`)+
 pt("legF",104,118,`<path d="M100 118 l-2 4 M108 118 l2 4" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",100,70,`<circle cx="98" cy="70" r="12" fill="${P.n}" ${SW}/>${E2(94,70,3,"#E8E0C0")}<path d="M86 70 L76 72 L86 76 Z" fill="${FMOUTH}"/>`+pt("beak",86,76,`<path d="M86 76 L77 76 L86 78 Z" fill="${FI}"/>`)+`<path d="M86 68 L74 71 L86 72 Z" fill="${FI}"/>`+
  pt("ear",100,56,`<path d="M76 66 Q78 38 102 36 Q126 38 128 64 Q116 56 102 58 Q88 58 76 66 Z" fill="${P.n}" ${SW}/>${[84,94,104,114,122].map(x=>`<path d="M102 38 L${x} 60" stroke="${P.ac}" stroke-width="1.2"/>`).join("")}`))+
 fG(g,1,`${[0,1,2].map(i=>`<path d="M${30+i*16} 140 V122 M${22+i*16} 122 Q${30+i*16} 112 ${38+i*16} 122 Z" stroke="${FI}" stroke-width="1.6" fill="#7AB8E8"/>`).join("")}<circle cx="170" cy="30" r="10" fill="#F2D060" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Umbrellium"]="Umbrellabird";SM("Umbrellium","Brolly","RES","s",0,100,"ward+2","Up it goes. Not a cloud in the sky, but still.");

/* Unset Timer Metal: one timer was never set, so this recipe just ran and ran. A grandfather clock that has dozed off, pendulum still swinging. */
addForm("Unset Timer Metal",{n:"#8A5A3A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#C8A040",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(50)+
 pt("legB",116,138,`<rect x="112" y="132" width="10" height="12" rx="2" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M78 136 V60 Q78 30 104 28 Q130 30 130 60 V136 Z" fill="${P.n}" ${SW}/><rect x="88" y="78" width="32" height="50" rx="4" fill="#3A2A1A" ${SW2}/>`+
 pt("sway",104,80,`<path d="M104 80 V114" stroke="${P.b}" stroke-width="2.4"/><circle cx="104" cy="118" r="8" fill="${P.b}" ${SW2}/>`)+
 pt("head",104,52,`<circle cx="104" cy="52" r="20" fill="${P.ac}" ${SW}/>${[0,1,2,3,4,5,6,7,8,9,10,11].map(i=>{const a=i/12*6.283;return`<path d="M${104+Math.sin(a)*16} ${52-Math.cos(a)*16} L${104+Math.sin(a)*18} ${52-Math.cos(a)*18}" stroke="${FI}" stroke-width="1.4"/>`}).join("")}<path d="M96 48 q3 2 6 0 M106 48 q3 2 6 0" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(100,58,108,P,2)+`<path d="M104 52 L104 40 M104 52 L112 56" stroke="${FI}" stroke-width="1.6" stroke-linecap="round" opacity=".5"/>`)+
 pt("legF",92,138,`<rect x="86" y="132" width="10" height="12" rx="2" fill="${P.n}" ${SW2}/>`)+
 pt("armF",80,96,fOL("M80 96 Q64 100 62 112",P.n,6))+pt("armB",128,96,fOL("M128 96 Q144 100 146 112",P.n,6),.4)+
 fG(g,1,`<text x="150" y="40" font-family="Georgia,serif" font-size="13" font-weight="bold" fill="${P.ac}">z z</text>`)+fG(g,2,`<circle cx="104" cy="118" r="2.4" fill="${P.ll}"/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Unset Timer Metal"]="Dozing Grandfather Clock";SM("Unset Timer Metal","Overrun","RES","s",0,100,"heal:30,selfspd-1","Nobody set an end, so it just kept going.");

/* Vestry Metal: choir practice stopped for a month over whether a crate counted as a member. A song thrush in a choir robe, hymn sheet held up. */
addForm("Vestry Metal",{n:"#A8804A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#7A2A4A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50,110)+
 pt("tail",128,104,`<path d="M124 100 L144 110 L128 114 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",112,122,`<path d="M112 120 L114 140" stroke="#E8A0A0" stroke-width="3"/><path d="M106 142 h14" stroke="#E8A0A0" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M84 124 Q80 86 104 80 Q128 86 128 124 Z" fill="#7A2A4A" ${SW}/><path d="M92 90 Q104 84 116 90 L114 106 Q104 102 94 106 Z" fill="${P.ac}" ${SW2}/><path d="M88 96 Q104 90 120 96" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 pt("legF",98,122,`<path d="M98 120 L96 140" stroke="#E8A0A0" stroke-width="3"/><path d="M88 142 h14" stroke="#E8A0A0" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("wingF",90,100,`<path d="M90 100 Q76 94 74 82" stroke="#7A2A4A" stroke-width="9" stroke-linecap="round"/><g transform="rotate(-10 72 76)"><rect x="60" y="66" width="24" height="18" fill="#F4F0E4" ${SW2}/><path d="M64 72 h16 M64 76 h16 M64 80 h12" stroke="${FI}" stroke-width="1"/></g>`)+
 pt("head",104,72,`<circle cx="104" cy="66" r="14" fill="${P.n}" ${SW}/><path d="M96 70 Q104 78 112 70" fill="${P.ac}"/>${[[100,72],[106,74],[110,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.2" fill="${FI}"/>`).join("")}${E2(98,62,3.2,"#1A1A1A")}`+
  `<path d="M90 64 L76 62 L90 70 Z" fill="${FMOUTH}"/>`+pt("beak",88,70,`<path d="M90 68 L78 72 L90 72 Z" fill="${FI}"/>`)+`<path d="M90 62 L76 60 L90 66 Z" fill="${FI}"/>`)+
 fG(g,1,`<path d="M150 40 v-14 l8 3 M164 46 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="148" cy="40" r="3" fill="${P.ac}"/><circle cx="162" cy="46" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="104" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Vestry Metal"]="Choir-Robe Song Thrush";SM("Vestry Metal","Descant","RES","a",60,100,"atk+1@30","One voice above all the others.");

/* Vossite: a packer has drawn a tiny star on every crate since 1987. A star-nosed mole, its nose a little star of its own. */
addForm("Vossite",{n:"#3A3A44",a:"#E8A0B0",rn:"#E8D8C8",rb:"#8A6A4A",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 136 Q104 128 194 140 V150 H14 Z" fill="#8A6A4A" ${SW2}/>`+fShadow(66)+
 pt("tail",154,118,`<path d="M150 118 Q166 116 176 108" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 [[138,.5],[100,1.3]].map(([x,d])=>pt("legB",x,128,`<path d="M${x-6} 126 Q${x+6} 132 ${x+10} 140 L${x-4} 140 Z" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 `<path d="M74 120 Q74 94 112 92 Q150 94 154 120 Q150 134 112 134 Q78 134 74 120 Z" fill="${P.n}" ${SW}/>${Array.from({length:10},(_,i)=>`<path d="M${86+i*6} ${98+i%2*4} q2 4 0 8" stroke="${P.nd}" stroke-width="1.2" fill="none" opacity=".7"/>`).join("")}`+
 pt("legF",88,128,`<path d="M94 122 Q74 120 64 136 Q80 142 96 134 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${66+i*5} ${136+i%2*2} l-2 5" stroke="${FI}" stroke-width="2"/>`).join("")}`)+
 pt("head",74,112,`<path d="M46 116 Q48 100 66 98 Q82 100 82 114 Q78 126 64 126 Z" fill="${P.n}" ${SW}/><circle cx="64" cy="108" r="1.6" fill="${FI}"/>`+HMOUTH(48,120,56,P,2)+
  pt("ant",40,112,`${Array.from({length:11},(_,i)=>{const a=i/11*6.283;return`<path d="M40 112 L${40+Math.cos(a)*11} ${112+Math.sin(a)*11}" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M40 112 L${40+Math.cos(a)*11} ${112+Math.sin(a)*11}" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>`}).join("")}<circle cx="40" cy="112" r="4" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M170 30 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="#F2C94C" ${SW2}/><text x="150" y="58" font-size="8" fill="${P.ac}">1987</text>`)+fG(g,2,`<circle cx="112" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,60,6)));
FORM_TITLE["Vossite"]="Star-Nosed Mole";SM("Vossite","Star Touch","SCR","a",55,100,"crit,acc+1","Twenty-two little feelers, and not one of them misses.");

/* Waterfall Blend: paddled downriver the long way, stopping at every waterfall. A dipper, the bird that walks straight into waterfalls. */
addForm("Waterfall Blend",{n:"#4A3A30",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8412C"},"perch",(P,g)=>`<path d="M140 0 Q136 60 144 146 H194 V0 Z" fill="#9AD0F0" opacity=".7"/>${[150,160,172,184].map(x=>`<path d="M${x} 0 Q${x-4} 60 ${x+2} 146" stroke="#fff" stroke-width="2" fill="none" opacity=".8"/>`).join("")}<path d="M30 134 Q60 120 120 128 Q150 132 170 140 V150 H30 Z" fill="#8A8A94" ${SW}/>`+fShadow(40,104)+
 pt("tail",124,104,`<path d="M120 100 L132 92 L134 104 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 112 Q78 86 102 82 Q126 86 126 110 Q118 124 102 124 Q86 124 80 112 Z" fill="${P.n}" ${SW}/><path d="M80 104 Q84 94 96 96 Q100 110 90 118 Q82 114 80 104 Z" fill="${P.ac}"/>`+
 pt("legF",100,122,`<path d="M96 120 l-2 8 M106 120 l2 8" stroke="#C8A0A0" stroke-width="2.4"/>`)+
 pt("head",92,80,`<circle cx="90" cy="76" r="12" fill="${P.n}" ${SW}/>${E2(86,72,3,"#1A1A1A")}<path d="M80 74 Q86 70 90 74" stroke="#fff" stroke-width="1.4" fill="none"/><path d="M78 76 L68 78 L78 80 Z" fill="${FMOUTH}"/>`+pt("beak",78,80,`<path d="M78 80 L69 80 L78 82 Z" fill="${FI}"/>`)+`<path d="M78 74 L66 77 L78 78 Z" fill="${FI}"/>`)+
 pt("sway",120,90,`${[[126,70],[132,96],[118,60]].map(([x,y])=>`<path d="M${x} ${y} q-3 5 0 7 q3 -2 0 -7 Z" fill="#7AC8F0" ${SW2}/>`).join("")}`)+
 fG(g,1,`<path d="M20 120 L50 116 L46 124 L24 126 Z" fill="#B8603A" ${SW2}/>`)+fG(g,2,`<circle cx="102" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Waterfall Blend"]="Waterfall Dipper";SM("Waterfall Blend","Behind The Falls","DRP","a",65,100,"dodge@40","Straight through the curtain of water and out the other side.");

/* Waymarker Metal: some trail waymarkers bear its catalogue number; nobody admits to stamping them. A chipmunk with a little stamp, marking the path. */
addForm("Waymarker Metal",{n:"#B87A4A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="150" y="70" width="10" height="72" fill="#8A6A4A" ${SW}/><path d="M146 70 L176 70 L184 78 L176 86 L146 86 Z" fill="#E8D8A0" ${SW}/><text x="150" y="82" font-size="7" font-weight="bold" fill="${FI}">No.247</text>`+fShadow(54)+
 pt("tail",128,120,`<path d="M124 124 Q150 120 152 96 Q152 80 140 82" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M124 124 Q150 120 152 96 Q152 80 140 82" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,130,`<ellipse cx="120" cy="138" rx="10" ry="5" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M80 128 Q76 98 102 94 Q128 98 126 128 Q120 140 102 140 Q86 140 80 128 Z" fill="${P.n}" ${SW}/><path d="M88 102 Q100 96 112 102" stroke="#F4F0E4" stroke-width="4" fill="none"/><path d="M86 108 Q100 102 116 108" stroke="${FI}" stroke-width="3" fill="none"/><path d="M90 126 Q102 134 116 126 Q114 112 102 110 Q92 112 90 126 Z" fill="${P.ac}"/>`+
 pt("legF",88,130,`<ellipse cx="84" cy="138" rx="10" ry="5" fill="${P.n}" ${SW2}/>`)+
 pt("armF",84,110,fOL("M86 110 Q70 108 66 98",P.n,6)+`<rect x="58" y="80" width="12" height="12" rx="2" fill="#8A5A2A" ${SW2}/><rect x="56" y="92" width="16" height="6" fill="#3A3A44" ${SW2}/>`)+
 pt("head",100,82,`<path d="M78 84 Q78 64 100 62 Q122 64 122 84 Q118 98 100 98 Q82 98 78 84 Z" fill="${P.n}" ${SW}/><path d="M86 74 l8 10 M104 70 l2 12" stroke="${FI}" stroke-width="2.4"/><path d="M84 76 l8 10" stroke="#F4F0E4" stroke-width="1.6"/><ellipse cx="90" cy="88" rx="7" ry="5" fill="${P.ac}"/><circle cx="82" cy="86" r="2.4" fill="${FI}"/>${E2(94,78,3.4,"#1A1A1A")}`+HMOUTH(84,92,92,P,2)+pt("ear",110,64,`<circle cx="112" cy="64" r="5" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 h20 v-4 h-20 Z M24 136 v-6 h12 v6" fill="#E8D8A0" ${SW2}/>`)+fG(g,2,`<circle cx="102" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Waymarker Metal"]="Trail-Stamping Chipmunk";SM("Waymarker Metal","Mark The Way","RES","s",0,100,"acc+1,spd+1","This way. Stamp. And this way. Stamp.");

/* Won't-Sulk Metal: carried off the boat first 'so it won't sulk'. A blobfish, the world's sulkiest face. */
addForm("Won't-Sulk Metal",{n:"#E8A0A8",a:"#C8706A",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#F2C94C"},"ooze",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#5A8AA8" opacity=".3"/>`+fShadow(60)+
 pt("tail",148,116,`<path d="M140 112 Q160 104 170 112 Q164 126 142 124 Z" fill="${P.n}" ${SW}/>`)+
 pt("sway",104,104,`<path d="M56 112 Q50 74 92 68 Q136 70 146 106 Q142 134 104 136 Q60 136 56 112 Z" fill="${P.n}" ${SW}/><path d="M66 92 Q76 80 92 80" stroke="#fff" stroke-width="3" fill="none" opacity=".5"/>`+
  pt("head",92,104,`<path d="M80 92 Q72 104 74 120 Q84 128 96 122 Q100 104 92 92 Z" fill="${P.ac}" ${SW}/>${E2(78,88,3,"#1A1A1A",[0,.6])}${E2(102,88,3,"#1A1A1A",[0,.6])}<path d="M74 84 l8 2 M98 86 l8 -2" stroke="${FI}" stroke-width="1.6"/>`+pt("jaw",88,128,`<path d="M70 124 Q88 118 106 124" stroke="${FI}" stroke-width="2.4" fill="none"/>`)))+
 pt("wingF",112,120,`<path d="M110 120 Q118 132 112 140 Q104 132 110 120 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M30 40 q8 -6 16 0" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="34" cy="34" r="1.6" fill="${FI}"/><circle cx="42" cy="34" r="1.6" fill="${FI}"/>`)+fG(g,2,`<circle cx="104" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Won't-Sulk Metal"]="Sulking Blobfish";SM("Won't-Sulk Metal","Sulk","RES","s",0,100,"def+2,tatk-1","Fine. FINE. It didn't want to come first anyway.");

/* Wrenite: storm-swept off the ferry; beachcombers returned every crate within a week. A sandpiper scurrying along the tideline, tag in its beak. */
addForm("Wrenite",{n:"#C8B090",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#E8D8B0" ${SW2}/><path d="M14 132 Q60 124 104 132" stroke="#7AB8E8" stroke-width="3" fill="none"/>`+fShadow(50,110)+
 pt("tail",128,100,`<path d="M124 96 L144 104 L126 108 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",112,110,`<path d="M112 108 L120 124 L116 138" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M110 138 h12" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`,.0)+
 `<path d="M84 100 Q86 80 106 78 Q126 82 128 102 Q120 112 104 112 Q88 112 84 100 Z" fill="${P.n}" ${SW}/><path d="M86 104 Q98 112 116 108 Q104 102 94 96 Z" fill="${P.ac}"/>${[0,1,2,3].map(i=>`<path d="M${98+i*6} 84 l2 6" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 pt("legF",100,110,`<path d="M100 108 L90 124 L94 138" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M88 138 h12" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`,.5)+
 pt("head",90,80,`<circle cx="88" cy="74" r="11" fill="${P.n}" ${SW}/>${E2(86,72,3,"#1A1A1A")}<path d="M78 74 L56 76 L78 78 Z" fill="${FMOUTH}"/>`+pt("beak",78,78,`<path d="M78 78 L58 78 L78 80 Z" fill="${FI}"/>`)+`<path d="M78 72 L54 75 L78 76 Z" fill="${FI}"/><g transform="rotate(14 52 82)"><rect x="44" y="76" width="14" height="9" fill="#E8D8A0" ${SW2}/><circle cx="46" cy="80" r="1.2" fill="${FI}"/></g>`)+
 fG(g,1,`<rect x="160" y="118" width="24" height="18" fill="#B88A50" ${SW2}/><path d="M164 112 l4 6" stroke="${FI}" stroke-width="1.2"/>`)+fG(g,2,`<circle cx="106" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Wrenite"]="Beachcomber Sandpiper";SM("Wrenite","Tideline Dash","STR","a",60,100,"prio,spd+1@30","In with the wave, out with the wave, never wet.");
