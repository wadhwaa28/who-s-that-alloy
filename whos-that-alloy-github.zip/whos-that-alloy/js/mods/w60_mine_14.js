/* ---- Rustvein Mine, 14 ---- */
/* Top Shelf Blend: kept on the top cellar shelf by cheesemongers beside a wheel nobody may cut. A cellar rat guarding that uncut wheel. */
addForm("Top Shelf Blend",{n:"#8A8A8A",a:"#E8A0A8",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0A0"},"stand",(P,g)=>`<path d="M14 120 H194" stroke="#8A6A4A" stroke-width="8"/>`+`<path d="M112 116 L112 82 Q140 72 168 82 L168 116 Q140 124 112 116 Z" fill="#E8C060" ${SW}/><ellipse cx="140" cy="82" rx="28" ry="8" fill="#F2D880" ${SW2}/><path d="M112 98 Q140 106 168 98" stroke="#C8A040" stroke-width="2" fill="none"/><text x="128" y="108" font-size="7" font-weight="bold" fill="#8A5A20">DO NOT</text>`+fShadow(50,108)+
 pt("tail",100,108,`<path d="M96 110 Q108 128 96 140 Q86 148 76 142" stroke="${P.ac}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 pt("legB",90,110,fOL("M90 108 Q98 114 96 118",P.nd,7),.5)+
 `<path d="M58 106 Q56 80 78 76 Q100 80 100 104 Q96 118 78 118 Q60 118 58 106 Z" fill="${P.n}" ${SW}/><path d="M66 108 Q78 116 92 108" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("legF",66,112,fOL("M68 108 Q60 114 64 118",P.n,7))+
 pt("armF",88,90,fOL("M88 90 Q104 88 112 92",P.n,5)+`<ellipse cx="113" cy="93" rx="3.4" ry="3" fill="${P.ac}" ${SW2}/>`)+
 pt("head",70,74,`<path d="M44 74 Q48 58 66 56 Q84 58 86 72 Q82 84 66 86 L48 80 Z" fill="${P.n}" ${SW}/><path d="M44 74 L32 78 L46 82 Z" fill="${P.n}" ${SW2}/><circle cx="33" cy="78" r="2.4" fill="${P.ac}"/>${E2(62,68,3.6,"#1A1A1A")}`+HMOUTH(38,80,46,P,2)+`<path d="M38 76 h-10 M38 79 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",76,58,`<circle cx="76" cy="56" r="8" fill="${P.n}" ${SW2}/><circle cx="76" cy="56" r="4.4" fill="${P.ac}"/>`))+
 fG(g,1,`<path d="M24 100 l14 -10 l4 6 Z" fill="#E8C060" ${SW2}/>`)+fG(g,2,`<circle cx="78" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Top Shelf Blend"]="Cheese-Guarding Rat";SM("Top Shelf Blend","Hands Off","RES","s",0,100,"def+1,tatk-1","Nobody touches the wheel. Nobody.");

/* Totalium: finished in the four minutes of a total eclipse. A jellyfish whose bell is a darkened sun ringed with a corona. */
addForm("Totalium",{n:"#2A2A3A",a:"#F2D060",rn:"#E8E0D0",rb:"#7A4AC8",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="28" ry="3" fill="#000" opacity=".1"/>`+
 Array.from({length:7},(_,i)=>pt(i%2?"legB":"legF",78+i*8,84,`<path d="M${78+i*8} 84 Q${74+i*8} 104 ${80+i*8} 118 Q${86+i*8} 132 ${78+i*8} 144" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M${78+i*8} 84 Q${74+i*8} 104 ${80+i*8} 118 Q${86+i*8} 132 ${78+i*8} 144" stroke="${i%2?P.ac:P.nd}" stroke-width="2" fill="none" stroke-linecap="round"/>`,i*.15)).join("")+
 pt("slow",104,58,Array.from({length:16},(_,i)=>{const a=-3.14+i/15*3.14;return`<path d="M${104+Math.cos(a)*40} ${80+Math.sin(a)*40} L${104+Math.cos(a)*54} ${80+Math.sin(a)*54}" stroke="${P.ac}" stroke-width="3" stroke-linecap="round" opacity=".8"/>`}).join(""))+
 `<path d="M62 84 Q60 38 104 36 Q148 38 146 84 Q126 92 104 88 Q82 92 62 84 Z" fill="${P.n}" ${SW}/><path d="M66 82 Q64 42 104 40 Q144 42 142 82" fill="none" stroke="${P.ac}" stroke-width="3"/><path d="M84 52 Q94 46 104 46" stroke="#fff" stroke-width="2" fill="none" opacity=".4"/>`+
 pt("head",104,68,`${E2(92,64,4.6,"#F2D060")}${E2(116,64,4.6,"#F2D060")}`+HMOUTH(98,74,110,P,3))+
 fG(g,1,`${[[24,30],[180,40],[30,110],[176,120]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="${P.ac}"/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="82" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,20,6)));
FORM_TITLE["Totalium"]="Eclipse Jellyfish";SM("Totalium","Totality","RES","s",0,100,"tacc-2,dodge","For four minutes the whole world goes dark.");


/* Tullyite: exactly one tidal cycle, timed with a pocket watch. A mudskipper perched on a tide post, pocket watch hung round its neck. */
addForm("Tullyite",{n:"#8A7A5A",a:"#5AB0C8",rn:"#3A3A4A",rb:"#E8C060",ra:"#E8412C"},"crawl",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#8A7050" ${SW}/><path d="M14 140 Q60 134 104 140" stroke="#7AB8E8" stroke-width="3" fill="none"/><rect x="154" y="40" width="12" height="100" fill="#8A6A4A" ${SW2}/>${[60,80,100,120].map((y,i)=>`<path d="M154 ${y} h6" stroke="#F4F0E4" stroke-width="2"/><text x="168" y="${y+3}" font-size="6" fill="${FI}">${4-i}</text>`).join("")}`+fShadow(60,104)+
 pt("tail",136,124,`<path d="M130 120 Q150 120 158 132 Q146 136 132 132 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M62 124 Q64 106 98 104 Q130 106 136 124 Q130 136 98 136 Q66 136 62 124 Z" fill="${P.n}" ${SW}/>${[[86,114],[102,112],[118,116],[94,124],[112,126]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.ac}" opacity=".8"/>`).join("")}`+
 pt("wingB",108,104,`<path d="M100 106 Q108 86 124 88 Q118 100 112 108 Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${104+i*5} 104 l${4+i} -12" stroke="${P.ndd}" stroke-width="1"/>`).join("")}`,.4)+
 pt("legF",84,130,`<path d="M88 128 Q76 132 70 142 Q82 144 92 136 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",62,112,`<path d="M34 120 Q34 104 54 102 Q70 104 70 118 Q66 130 52 130 Z" fill="${P.n}" ${SW}/><circle cx="50" cy="98" r="8" fill="${P.n}" ${SW2}/><circle cx="62" cy="98" r="7" fill="${P.n}" ${SW2}/>${E2(50,97,4.4,"#2A2A2A",[0,-.4])}${E2(62,97,4,"#2A2A2A",[0,-.4])}`+HMOUTH(36,122,48,P,2.6)+
  `<path d="M58 128 Q64 136 70 132" stroke="#C8A040" stroke-width="1.6" fill="none"/><circle cx="70" cy="136" r="5.4" fill="#E8C060" ${SW2}/><circle cx="70" cy="136" r="3.4" fill="#F4F0E4"/><path d="M70 136 v-2.4 M70 136 l2 1" stroke="${FI}" stroke-width="1"/>`)+
 fG(g,1,`<path d="M20 120 q6 -6 12 0 q6 6 12 0" stroke="#7AB8E8" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="98" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,60,6)));
FORM_TITLE["Tullyite"]="Tide-Timing Mudskipper";SM("Tullyite","Turn Of The Tide","DRP","a",65,100,"heal:15","High, low, high again. Everything comes back round.");

/* Tumbaga: plant acids made its surface look richer than the metal inside. A pre-Columbian pendant frog, gilded on the outside only. */
addForm("Tumbaga",{n:"#D8A040",a:"#B8603A",rn:"#2A2A3A",rb:"#5AA87A",ra:"#E8412C"},"hop",(P,g)=>fShadow(66)+
 pt("legB",142,124,`<path d="M132 112 Q166 104 164 132 L176 140 H138 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${150+i*8} 140 l${i-1} 4" stroke="${FI}" stroke-width="2"/>`).join("")}`,.0)+
 `<path d="M70 120 Q66 86 104 82 Q142 86 140 120 Q136 138 104 138 Q74 138 70 120 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${82+i*14} 100 q7 -6 14 0" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`).join("")}${[0,1,2,3,4].map(i=>`<circle cx="${80+i*12}" cy="122" r="3" fill="none" stroke="${P.ac}" stroke-width="2"/>`).join("")}<path d="M104 82 V70" stroke="${FI}" stroke-width="3"/><circle cx="104" cy="66" r="5" fill="none" stroke="${FI}" stroke-width="3"/><circle cx="104" cy="66" r="5" fill="none" stroke="${P.b}" stroke-width="1.6"/>`+
 `<path d="M118 128 Q122 134 130 132" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".7"/>`+
 pt("legF",76,126,`<path d="M84 116 Q58 112 60 134 L48 140 H84 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${54+i*8} 140 l${i-1} 4" stroke="${FI}" stroke-width="2"/>`).join("")}`)+
 pt("head",84,96,`<path d="M50 98 Q50 80 70 78 Q88 80 90 96 Q86 110 70 110 Q54 110 50 98 Z" fill="${P.n}" ${SW}/><path d="M56 76 l6 -10 l6 10 M72 76 l6 -10 l6 10" fill="${P.n}" ${SW2}/><rect x="56" y="82" width="12" height="10" rx="5" fill="${P.ac}" ${SW2}/><rect x="72" y="82" width="12" height="10" rx="5" fill="${P.ac}" ${SW2}/><circle cx="62" cy="87" r="3" fill="${FI}"/><circle cx="78" cy="87" r="3" fill="${FI}"/>`+
  `<path d="M52 100 L76 102 L74 106 L54 104 Z" fill="${FMOUTH}"/>`+pt("jaw",72,105,`<path d="M76 104 Q64 112 52 102 Q64 108 76 107 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 40 l4 -6 l4 6 l-4 6 Z M30 50 l4 -6 l4 6 l-4 6 Z" fill="${P.b}" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Tumbaga"]="Gilded Pendant Frog";SM("Tumbaga","Surface Gilding","RES","s",0,100,"def+1,tacc-1","Rich on the outside. Nobody needs to know what's underneath.");

/* Unbumpable Metal: nobody has ever managed to bump it at the bumper cars. A rhinoceros in a bumper car, entirely unbothered. */
addForm("Unbumpable Metal",{n:"#8A8A92",a:"#E8412C",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M100 40 V8" stroke="${FI}" stroke-width="3"/><path d="M92 8 h16" stroke="${FI}" stroke-width="2"/>`+fShadow(80)+
 `<path d="M54 124 Q50 96 66 92 H150 Q166 96 162 124 Z" fill="${P.ac}" ${SW}/><rect x="46" y="120" width="124" height="16" rx="8" fill="#2A2A30" ${SW}/><path d="M60 100 H154" stroke="#F2C94C" stroke-width="3"/><circle cx="148" cy="108" r="6" fill="#F2C94C" ${SW2}/><text x="145" y="111" font-size="7" font-weight="bold" fill="${FI}">7</text><path d="M100 92 V40" stroke="${FI}" stroke-width="3"/>`+
 `<path d="M80 96 Q80 66 116 64 Q152 66 154 94 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${96+i*16} 70 q4 12 0 24" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("armF",86,94,fOL("M88 94 L74 100",P.n,10)+`<circle cx="70" cy="102" r="7" fill="none" stroke="${FI}" stroke-width="4"/>`)+
 pt("head",84,74,`<path d="M44 76 Q44 58 66 54 Q88 56 90 74 Q86 90 66 90 Q48 90 44 76 Z" fill="${P.n}" ${SW}/><path d="M46 66 Q34 50 38 36 Q48 46 56 60 Z" fill="${P.nl}" ${SW2}/><path d="M60 58 Q56 50 60 44 Q66 50 66 58 Z" fill="${P.nl}" ${SW2}/><path d="M64 68 q4 2 8 0" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="68" cy="66" r="1.6" fill="${FI}"/>`+HMOUTH(46,82,56,P,2.4)+
  pt("ear",80,56,`<path d="M78 58 L80 44 L88 56 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 l-6 -4 M22 110 l-8 -2 M20 130 l-6 2" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="116" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Unbumpable Metal"]="Bumper-Car Rhino";SM("Unbumpable Metal","Immovable","RES","s",0,100,"def+2,endure","Go on, try and bump it. Everyone does. Nobody can.");

/* Understudy Metal: stored with the scenery of a touring sea opera, listed as 'the understudy'. A walrus in a ruff collar, waiting in the wings for its cue. */
addForm("Understudy Metal",{n:"#A88070",a:"#F4F0E4",rn:"#3A3A4A",rb:"#7A3A5A",ra:"#F2C94C"},"slosh",(P,g)=>`<path d="M160 10 Q150 70 162 146 H194 V10 Z" fill="#7A2A3A" ${SW}/>${[168,178,188].map(x=>`<path d="M${x} 12 Q${x-6} 70 ${x+2} 144" stroke="#5A1A2A" stroke-width="2" fill="none"/>`).join("")}`+fShadow(70)+
 pt("tail",150,128,`<path d="M144 126 L166 116 L162 130 L172 140 L148 136 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M64 136 Q56 94 88 84 Q122 78 140 104 Q154 124 150 138 Z" fill="${P.n}" ${SW}/>${[[98,104],[116,112],[126,126],[104,124]].map(([x,y])=>`<path d="M${x} ${y} q4 4 8 0" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("armF",78,124,`<path d="M82 118 Q62 126 58 140 Q74 142 86 132 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",80,80,`<path d="M52 82 Q50 58 76 56 Q100 58 102 80 Q98 98 76 98 Q56 98 52 82 Z" fill="${P.n}" ${SW}/><ellipse cx="68" cy="88" rx="10" ry="7" fill="${P.nl}" ${SW2}/><ellipse cx="84" cy="88" rx="9" ry="7" fill="${P.nl}" ${SW2}/>${[[64,86],[70,90],[80,86],[86,90]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".9" fill="${FI}"/>`).join("")}${E2(68,72,3.6)}${E2(86,72,3.6)}`+
  pt("jaw",76,96,`<path d="M66 94 Q76 104 86 94 Z" fill="${FMOUTH}" ${SW2}/><path d="M66 94 L62 116 L68 116 L70 96 M84 96 L86 116 L92 116 L88 94" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M54 98 Q76 112 102 98 L106 104 Q76 122 50 104 Z" fill="#F4F0F4" ${SW2}/>${[60,68,76,84,92].map(x=>`<path d="M${x} ${102+Math.abs(x-76)*-.1} q4 6 8 0" stroke="#C8C8D8" stroke-width="1.4" fill="none"/>`).join("")}`)+
 fG(g,1,`<path d="M20 40 v-14 l8 3 M32 46 v-14 l8 3" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="18" cy="40" r="3" fill="${FI}"/><circle cx="30" cy="46" r="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="112" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,50,6)));
FORM_TITLE["Understudy Metal"]="Opera Walrus";SM("Understudy Metal","Big Break","RES","a",85,90,"","The lead is ill. Tonight, the understudy goes on.");

/* Unforetellium: the fortune tellers find it can't be predicted, and are insulted. A frilled lizard whose frill is a fan of tarot cards, all blank. */
addForm("Unforetellium",{n:"#6A8A5A",a:"#8A5AB8",rn:"#3A3A4A",rb:"#E8C060",ra:"#E8412C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",150,118,`<path d="M146 116 Q176 122 190 138" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M146 116 Q176 122 190 138" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 [[138,"legB",.5],[104,"legB",1.3]].map(([x,c,d])=>pt(c,x,120,fOL(`M${x} 118 L${x+8} 130 L${x+4} 142`,P.nd,6),d)).join("")+
 `<path d="M82 116 Q84 96 116 94 Q148 96 152 114 Q146 128 116 128 Q86 128 82 116 Z" fill="${P.n}" ${SW}/>`+
 [[128,"legF",0],[94,"legF",.8]].map(([x,c,d])=>pt(c,x,120,fOL(`M${x} 118 L${x-8} 130 L${x-4} 143`,P.n,6),d)).join("")+
 pt("head",78,96,`<g>${Array.from({length:7},(_,i)=>{const a=-.9+i*.3;return`<g transform="rotate(${a*57} 86 96)"><rect x="80" y="44" width="14" height="22" rx="2" fill="#F4F0E4" ${SW2}/><rect x="83" y="47" width="8" height="16" fill="none" stroke="${P.ac}" stroke-width="1.2"/><text x="85" y="58" font-size="7" font-weight="bold" fill="${P.ac}">?</text></g>`}).join("")}</g>`+
  `<path d="M50 98 Q52 82 72 80 Q90 82 92 96 Q88 108 70 108 Z" fill="${P.n}" ${SW}/>${E2(70,90,4,"#E8A020")}<path d="M52 102 L70 104 L68 108 L54 106 Z" fill="${FMOUTH}"/>`+pt("jaw",68,107,`<path d="M70 106 Q60 114 52 104 Q60 109 70 109 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="40" r="10" fill="${P.ac}" opacity=".4" ${SW2}/><path d="M24 36 l12 8 M36 36 l-12 8" stroke="${FI}" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="116" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Unforetellium"]="Blank-Tarot Frilled Lizard";SM("Unforetellium","Unreadable","RES","s",0,100,"dodge,tacc-1","Every card comes up blank. Even the fortune tellers give up.");

/* Unicyclite: jugglers think it's bad luck to mention near a unicycle. A kangaroo balancing on a unicycle, juggling. */
addForm("Unicyclite",{n:"#C8805A",a:"#F4E8D8",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"hop",(P,g)=>pt("spin",104,124,`<circle cx="104" cy="124" r="18" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="104" cy="124" r="18" fill="none" stroke="#3A3A44" stroke-width="3"/><path d="M104 106 V142 M86 124 H122 M91 111 L117 137 M117 111 L91 137" stroke="${P.b}" stroke-width="1.4"/>`)+`<path d="M104 124 V100" stroke="${FI}" stroke-width="5"/><path d="M104 124 V100" stroke="${P.b}" stroke-width="3"/><ellipse cx="104" cy="98" rx="10" ry="4" fill="#2A2A30" ${SW2}/>`+fShadow(30,104)+
 pt("tail",116,96,`<path d="M114 94 Q140 104 148 130" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M114 94 Q140 104 148 130" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/>`)+
 pt("legB",112,98,`<path d="M110 96 Q120 108 112 122 L106 124" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M110 96 Q120 108 112 122 L106 124" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M90 98 Q84 66 102 56 Q120 60 120 92 Q118 104 104 104 Q92 104 90 98 Z" fill="${P.n}" ${SW}/><path d="M96 70 Q104 66 112 72 L110 98 Q100 100 96 94 Z" fill="${P.ac}"/>`+
 pt("legF",96,98,`<path d="M96 96 Q86 110 96 124 L102 124" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M96 96 Q86 110 96 124 L102 124" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("armF",96,70,fOL("M96 70 Q80 62 76 50",P.n,5))+pt("armB",112,70,fOL("M112 70 Q128 62 130 50",P.nd,5),.4)+
 pt("spin",104,26,`${[[78,40,"#E8412C"],[104,18,"#4A8AE8"],[130,40,"#F2C94C"]].map(([x,y,c])=>`<circle cx="${x}" cy="${y}" r="5" fill="${c}" ${SW2}/>`).join("")}`)+
 pt("head",100,52,`<path d="M84 52 Q84 36 100 34 Q114 36 114 50 Q110 60 98 60 L86 58 Z" fill="${P.n}" ${SW}/><path d="M84 52 L76 54 Q76 58 84 58 Z" fill="${P.n}" ${SW2}/><circle cx="77" cy="55" r="2" fill="${FI}"/>${E2(96,46,3.6,"#1A1A1A",[0,-.6])}`+HMOUTH(80,58,88,P,2)+
  pt("ear",106,36,`<path d="M102 38 Q104 18 112 16 Q114 30 108 40 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",112,38,`<path d="M108 38 Q116 22 124 22 Q122 34 112 42 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M20 146 h40" stroke="${P.ac}" stroke-width="3" stroke-dasharray="4 4"/>`)+fG(g,2,`<circle cx="104" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Unicyclite"]="Unicycling Kangaroo";SM("Unicyclite","Balancing Act","RES","s",0,100,"spd+1,acc+1","One wheel, three balls, and no idea how it's staying up.");

/* Unidentifium: labelled 'Please do not identify'. Visitors took it as a challenge. A platypus, the animal that baffled everyone who tried to identify it. */
addForm("Unidentifium",{n:"#7A5A3A",a:"#3A3A40",rn:"#E8D8C8",rb:"#5A8AC8",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+fShadow(70)+
 pt("tail",152,118,`<path d="M146 112 Q178 108 186 122 Q178 136 146 128 Z" fill="${P.n}" ${SW}/>${[[160,116],[170,120],[164,126],[176,126]].map(([x,y])=>`<path d="M${x-3} ${y} l3 -2 l3 2" stroke="${P.nd}" stroke-width="1.2" fill="none"/>`).join("")}`)+
 [[138,"legB",.5],[100,"legB",1.3]].map(([x,c,d])=>pt(c,x,126,`<path d="M${x} 124 L${x+2} 136 L${x-6} 142 H${x+10} Z" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 `<path d="M76 120 Q76 98 112 96 Q148 98 150 118 Q146 134 112 134 Q80 134 76 120 Z" fill="${P.n}" ${SW}/>`+
 [[126,"legF",0],[88,"legF",.8]].map(([x,c,d])=>pt(c,x,128,`<path d="M${x} 126 L${x-2} 138 L${x-10} 144 H${x+6} Z" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 pt("head",80,110,`<path d="M58 112 Q60 96 76 96 Q92 98 92 112 Q88 124 76 124 Q62 124 58 112 Z" fill="${P.n}" ${SW}/>${E2(76,106,3.2,"#1A1A1A")}`+
  `<path d="M60 108 Q40 100 30 108 Q28 114 34 116 L60 114 Z" fill="${P.ac}" ${SW}/>`+pt("beak",48,118,`<path d="M60 114 L34 116 Q30 122 40 124 L60 118 Z" fill="${P.ac}" ${SW2}/>`)+`<circle cx="36" cy="108" r="1" fill="#6A6A70"/><circle cx="40" cy="107" r="1" fill="#6A6A70"/>`)+
 fG(g,1,`<g transform="rotate(-6 160 40)"><rect x="140" y="30" width="44" height="20" fill="#F4F0E4" ${SW2}/><text x="143" y="40" font-size="5" font-weight="bold" fill="${FI}">PLEASE DO NOT</text><text x="149" y="47" font-size="5" font-weight="bold" fill="${FI}">IDENTIFY</text></g>`)+fG(g,2,`<circle cx="112" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Unidentifium"]="Unidentifiable Platypus";SM("Unidentifium","Spur","SCR","a",65,100,"corrode@30","Duck's bill, beaver's tail, and a spur nobody expected.");
