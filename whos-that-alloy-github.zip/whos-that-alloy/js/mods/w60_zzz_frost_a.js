/* =============== FROSTBITE CAVERN: forty-two more ===============
   The cavern had the thinnest register of any map. These all belong to it: every one either melts below 150 °C or is so reactive it
   has to be kept somewhere cold and dry. Their measurable properties come from their makeup by the same rules as every other made-up
   alloy; the low-melting mixes keep a melting point to match their family (a eutectic melts far below the average of its parts). */
function frostAlloy(o){const comp=o.comp.slice().sort((a,b)=>b[1]-a[1]),w=Object.fromEntries(comp.map(([s,p])=>[s,p/100])),k=comp.length-1,base=comp[0][0],bp=comp[0][1];
  const d=+(1/comp.reduce((t,[s,p])=>t+p/100/BY[s].d,0)).toFixed(2);
  const mp=o.mp!=null?o.mp:Math.round(comp.reduce((t,[s,p])=>t+p/100*(BY[s].mp+273.15),0)*(k<=1?.93:k===2?.88:.85)-273.15);
  const F=(w.Fe||0)+(w.Co||0)+.9*(w.Ni||0),sc=F-.6*(1-F),mag=sc>.5?2:sc>.15?1:0;
  let hard=comp.reduce((t,[s,p])=>t+p/100*EX[s].h,0)+.4*Math.min(3,k);hard=mp<25?0:+clamp(hard,.5,8.5).toFixed(1);
  const cond=+Math.max(.3,EX[base].c/(1+.25*(100-bp))).toFixed(1);
  let rgb=[0,0,0];comp.forEach(([s,p])=>{const c=hex2rgb(EX[s].col);rgb=rgb.map((v,i)=>v+c[i]*p/100)});let color=rgb2hex(rgb);const lum=(rgb[0]+rgb[1]+rgb[2])/3;
  const white=(w.Ag||0)*.5+(w.In||0)*.4+(w.Ga||0)*.4+(w.Hg||0)*.5;color=mix(color,rgb2hex([lum,lum,lum*1.03]),clamp(white*1.6,0,1));
  const a={name:o.name,aliases:[],comp,d,mp,mag,hard,cond,color,leak:false,finish:o.finish||"p",real:false,fixedHab:"z-glacier",frostNew:true,
    lore:o.lore,uses:o.uses,made:o.made,origin:o.origin,creditKind:o.kind||"group"};
  a.reactive=isReactive(w);
  if(mp<25){a.form="vial";a.fill="liquid"}else{a.form="rod";a.fill=null}
  for(let i=ALLOYS.length-1;i>=0;i--)if(ALLOYS[i].name.toLowerCase()===a.name.toLowerCase()){if(!ALLOYS[i].recovered||ALLOYS[i].quest||ALLOYS[i].threat)return;ALLOYS.splice(i,1)}
  ALLOYS.push(a);a.no=ALLOYS.length;a.types=typesOf(a);a.hab="z-glacier";a.rar=o.rar;a.cat=o.cat||categoryOf(a)}
const FROST_NEW=[
 {name:"Elevenhundred",rar:"common",comp:[["Bi",48],["In",22],["Pb",17],["Sn",13]],mp:57,origin:"Dr. Pia Holm",kind:"person",uses:"Fusible links on the research huts' stove dampers",made:"Poured into a tin measuring cup, which was also measured",
  lore:"Dr. Holm took eleven hundred measurements of one wall of ice before anyone asked her to stop. She poured this to mark the occasion, and then measured it."},
 {name:"Biteless",rar:"common",comp:[["Bi",46],["Pb",30],["Sn",14],["Cd",10]],mp:74,origin:"Ole, ice fisherman",kind:"person",uses:"Fishing weights and jig heads",made:"Cast in a spoon over a primus stove on the ice",
  lore:"Ole casts his own sinkers on the ice, one per day of not catching anything. He has a great many sinkers and is, by his own account, very happy."},
 {name:"Goalkeeper's Thaw",rar:"uncommon",comp:[["Ga",70],["In",20],["Zn",6],["Sn",4]],mp:12,origin:"The Frostbite Snowman Eleven",kind:"group",uses:"Liquid-metal heat spreaders",made:"Collected in a bucket from where the goalkeeper had been standing",
  lore:"The cavern's snowman team is short a goalkeeper because the goalkeeper melted. Where it stood, the team found a puddle that never froze, and kept it as a mascot."},
 {name:"Fennimore Link",rar:"common",comp:[["Bi",54],["Pb",26],["Sn",20]],mp:102,origin:"Fennimore Cold Store",kind:"institution",uses:"Sprinkler heads and fire-door releases",made:"Cast into little links and soldered into each sprinkler head",
  lore:"The Fennimore Cold Store had a fire, which takes some doing in a cold store. Every sprinkler went off at once and the building froze solid. The insurers are still arguing about whether that counts as putting it out."},
 {name:"Mossgate Plug",rar:"common",comp:[["In",56],["Sn",40],["Zn",4]],mp:112,origin:"Mossgate Steam Laundry",kind:"institution",uses:"Safety plugs in boilers",made:"Packed into a bronze plug and screwed into the boiler crown",
  lore:"Mossgate's laundry boiler has a little plug in its crown that melts if the water runs low, so the boiler hisses instead of exploding. It has hissed four times. The laundry has a plaque for each one."},
 {name:"Pellowite",rar:"uncommon",comp:[["Bi",55],["Sn",40],["In",3],["Ag",2]],mp:132,origin:"Pellow & Daughter, Opticians",kind:"group",uses:"Lens-blocking for spectacle grinding",made:"Melted in a water bath and poured round the back of a lens blank",
  lore:"Pellow & Daughter grind spectacles for the whole cavern. The lens is stuck to this while it's ground, then the whole lot goes in warm water and lets go. Old Mr. Pellow says it's the only thing in the shop that knows when to let go."},
 {name:"Hogline Special",rar:"uncommon",comp:[["Bi",52],["Pb",44],["Sn",4]],mp:121,origin:"Frostbite Curling Club",kind:"group",uses:"Ballast weights for curling stones",made:"Poured into the hollow under a stone's handle",
  lore:"The curling club weights its stones by eye. One stone was weighted by a member who had lost the previous three ends, and it has never once stopped short of the hog line since."},
 {name:"Coldsnap",rar:"uncommon",comp:[["Ga",88],["Sn",10],["Zn",2]],mp:21,origin:"Research Hut No. 2",kind:"institution",uses:"Thermometer columns that don't poison anybody",made:"Sealed in a glass column the length of a forearm",
  lore:"Every hut has a thermometer by the door. Hut No. 2's goes solid at twenty-one degrees, which means in the cavern it's always solid. The hut keeps it anyway, because it's the only reading anyone agrees on."},
 {name:"Iceharvest",rar:"common",comp:[["Bi",40],["Pb",38],["Sn",20],["Cd",2]],mp:94,origin:"The Cavern Ice Harvesters",kind:"group",uses:"Hand-poured saw handles and grips",made:"Cast round the tang of an ice saw",
  lore:"Ice harvesters cut blocks off the cavern floor and sell them to the valley in summer. Their saw handles are cast from this, so if a handle ever gets warm enough to melt, they know they've been working too hard."},
 {name:"Lagwrap",rar:"common",comp:[["In",62],["Bi",34],["Sn",4]],mp:70,origin:"Dunmore & Sons, Plumbers",kind:"group",uses:"Filling for pipe bending",made:"Poured into a pipe, bent with the pipe, then melted out in hot water",
  lore:"Dunmore & Sons bend copper pipe by filling it with this first, so it doesn't kink. Then they melt it back out and use it again. Some of this lot has been through four hundred pipes and every frozen house in the cavern."},
 {name:"Skyshow Wager",rar:"uncommon",comp:[["Bi",45],["In",20],["Sn",15],["Pb",15],["Cd",5]],mp:52,origin:"The Hut No. 3 Sweepstake",kind:"event",uses:"Prize tokens and low-melt castings",made:"Poured into the sweepstake tin as the prize",
  lore:"Hut No. 3 runs a sweepstake on which night the aurora will show through the cavern mouth. Nobody has ever won it. The prize is this, and it has been melted down and recast every year since, to keep it interesting."},
 {name:"Lastblock",rar:"uncommon",comp:[["Sn",50],["In",30],["Bi",20]],mp:100,origin:"The Igloo Building Contest",kind:"event",uses:"Keystone wedges and shims",made:"Cast into a little wedge and set in the top of the winning igloo",
  lore:"The igloo contest is won by whoever gets the last block in at the top without the whole thing coming down. One year the last block was a cast wedge of this. The judges allowed it, after a long argument and a short vote."},
 {name:"Runnerglide",rar:"common",comp:[["Ga",62],["Sn",25],["Zn",13]],mp:17,origin:"The Cavern Sledge Derby",kind:"event",uses:"Liquid lubricant for sledge runners",made:"Shaken in a jar and wiped on with a rag",
  lore:"Every team at the sledge derby swears by its own runner wax. One team swore by this instead. It was not allowed to enter again, but nobody has got near its time."},
 {name:"Bootspike",rar:"common",comp:[["Hg",64],["In",30],["Zn",6]],mp:45,origin:"Frostbite Mountaineering Club",kind:"group",uses:"Soft seals in crampon straps",made:"Pressed into the strap buckles while still pasty",
  lore:"The mountaineering club's oldest pair of crampons has buckles filled with this. They go soft in a warm hand and set hard on the ice. The club says that's the right way round for a buckle."},
 {name:"Trailbreaker",rar:"uncommon",comp:[["Ga",50],["In",30],["Bi",10],["Sn",10]],mp:8,origin:"The Snowshoe Post",kind:"group",uses:"Liquid-filled cold packs for long walks",made:"Poured into a leather bag sewn into a snowshoe binding",
  lore:"The cavern's post goes round on snowshoes, first thing, breaking the trail for everyone else. The postman's bindings have a little bag of this sewn in, which he says keeps his feet honest."},
 {name:"Beaconbark",rar:"rare",comp:[["Bi",38],["In",36],["Sn",20],["Zn",6]],mp:66,origin:"Frostbite Mountain Rescue",kind:"group",uses:"Fusible switches in avalanche beacons",made:"Cast into the beacon's switch so it trips if the case is crushed",
  lore:"Mountain rescue's beacons bleep when they're buried. The dog bleeps too, separately, out of solidarity. Nobody trained it to. Everybody is glad it does."},
 {name:"Core Nine",rar:"uncommon",comp:[["Sn",60],["Bi",36],["Zn",4]],mp:140,origin:"The Glaciology Team",kind:"group",uses:"Seals on ice-core tubes",made:"Melted onto the cap of a core tube",
  lore:"The glaciology team drilled nine cores out of the cavern wall. Cores one to eight were ice. Core nine was ice with this running through it like a vein, and it's the only one anyone asks about."},
 {name:"Grottodrip",rar:"common",comp:[["In",70],["Sn",20],["Ga",10]],mp:70,origin:"The meltwater pool",kind:"event",uses:"Seals for cold-room doors",made:"Dripped from an icicle into the pool and fished out",
  lore:"The meltwater pool on the west side of the cavern is fed by a single icicle that never stops dripping. Once in a long while what drips off it isn't water."},
 {name:"Rinkside",rar:"common",comp:[["Bi",58],["Cd",36],["Sn",6]],mp:135,origin:"Frostbite Figure Skating Club",kind:"group",uses:"Blade-mount fillers for skates",made:"Poured into the mounts under a skate blade",
  lore:"The skating club's best pair of skates was refitted with this under the blades. Their owner landed her first triple the next week and has refused to have them looked at since."},
 {name:"Slapshot Blend",rar:"common",comp:[["Hg",52],["Ag",22],["Sn",18],["Cu",8]],mp:110,origin:"The Cavern Hockey Six",kind:"group",uses:"Dense pucks for practice",made:"Pressed into a puck mould and left to harden overnight",
  lore:"The hockey six practise with a puck of this because it's heavier than rubber and doesn't bounce. They play with a rubber one, which the goalie says feels like being hit by a sponge after a season of this."},
 {name:"Toothache Special",rar:"rare",comp:[["Bi",35],["Pb",35],["Sn",20],["In",10]],mp:72,origin:"The Cavern Dentist",kind:"person",uses:"Low-melt impression trays",made:"Poured into an impression tray and held in the mouth until it set",
  lore:"The cavern's one dentist takes impressions with a tray of this, warm. Patients say it's the only warm thing that has ever been in their mouth in the cavern, and some of them come back for it."},
 {name:"Flaskwarm",rar:"common",comp:[["Sn",45],["Pb",30],["Bi",25]],mp:120,origin:"Research Hut No. 1",kind:"institution",uses:"Thermal fuses in flask heaters",made:"Cast into a fuse and fitted in the bottom of a flask warmer",
  lore:"Hut No. 1 had a flask warmer that kept the cocoa hot for three days. It had a fuse of this in the bottom, which melted on the fourth. Nobody has ever wanted cocoa more than three days old."},
 {name:"Hibernation Clause",rar:"uncommon",comp:[["Bi",42],["Pb",26],["Sn",22],["In",10]],mp:70,origin:"Clerk Ambrose Tull",kind:"person",uses:"Seals on documents and deed boxes",made:"Dripped onto a document like sealing wax",
  lore:"The cavern lease has a clause letting the tenant sleep through any month colder than the one before. Clerk Tull wrote it, sealed it with this, and has not been seen in February since."},
 {name:"Coldstore Count",rar:"common",comp:[["Bi",48],["Sn",28],["Pb",18],["Cd",6]],mp:86,origin:"The Cavern Cold Store",kind:"institution",uses:"Fusible tags on stock that mustn't warm up",made:"Cast into tags and wired onto crates",
  lore:"Everything in the cold store wears a little tag of this. If the tag has melted, the crate warmed up, and the crate goes in the bin. The cold store has never once had to bin anything, which the stocktakers find suspicious."},
 {name:"Drip Tray Mix",rar:"uncommon",comp:[["K",70],["Na",26],["Rb",4]],mp:-11,origin:"The Cryostat Lab",kind:"institution",uses:"Liquid coolant loops",made:"Drawn off under dry oil into a sealed ampoule",finish:"p",
  lore:"The cryostat lab keeps a drip tray under the old coolant loop, full of oil, because what drips out of it catches fire in air. The tray has been emptied once. The lab does not discuss the time it was emptied."},
 {name:"Featherrun",rar:"uncommon",comp:[["Li",34],["Mg",58],["Al",8]],origin:"The Cavern Sledge Derby",kind:"event",uses:"Ultralight sledge runners",made:"Rolled thin under argon and riveted to an ash frame",
  lore:"The lightest sledge ever entered in the derby had runners of this. It was so light it took off on the first bump. The derby rules now say the sledge must stay on the snow, which seems obvious and wasn't written down before."},
 {name:"Fizzwell",rar:"rare",comp:[["K",48],["Na",28],["Cs",24]],mp:-40,origin:"Dr. Pia Holm",kind:"person",uses:"Nothing practical; a warning sample",made:"Sealed in glass under oil and labelled in red",
  lore:"Dr. Holm keeps one ampoule of this on her shelf, under oil, as a reminder of why you don't let water near the reactive cabinet. The ampoule once rolled into the sink. The sink is now a crater, and also a reminder."},
 {name:"Shakeup",rar:"common",comp:[["Ga",60],["In",30],["Sn",6],["Bi",4]],mp:5,origin:"The Cavern Souvenir Shop",kind:"institution",uses:"Weighted liquid for snow globes",made:"Poured into a snow globe under a tiny model of the cavern",
  lore:"The souvenir shop's snow globes have a tiny model of the cavern inside, and a drop of this at the bottom that rolls about like quicksilver when you shake it. The shop says the snow globe is 'more accurate than you'd think'."},
 {name:"Dripchime",rar:"uncommon",comp:[["Bi",30],["In",45],["Sn",20],["Zn",5]],mp:58,origin:"The Icicle Gallery",kind:"group",uses:"Tuned chime bars",made:"Cast into thin bars and hung on a string",
  lore:"There's a part of the cavern where the icicles ring when they drip. Somebody cast a set of chimes to match them. On still days the chimes and the icicles play the same tune, which nobody wrote."},
 {name:"Fishblock",rar:"common",comp:[["Pb",40],["Bi",35],["Sn",15],["Cd",10]],mp:82,origin:"Ole, ice fisherman",kind:"person",uses:"Weights for ice-fishing tip-ups",made:"Cast in a hole in the ice and chipped out next morning",
  lore:"Ole found a pike frozen into a block of ice, looking very surprised. He chipped it out and found this in its mouth instead of a hook. He calls it his only catch."},
 {name:"Lost Mitten Box",rar:"common",comp:[["In",48],["Sn",44],["Ag",8]],mp:125,origin:"The Cavern Lost Property Box",kind:"institution",uses:"Cold-working solder for glass to metal",made:"Found melted into the lining of an odd mitten",
  lore:"The lost property box at the cavern mouth is full of odd mittens. Nobody has ever found the other one of any of them. At the bottom of the box, under the mittens, there's a mitten made of this, and nobody has claimed it either."},
 {name:"Draughtstop",rar:"common",comp:[["Bi",50],["In",30],["Pb",20]],mp:66,origin:"Research Hut No. 1",kind:"institution",uses:"Weighting for draught excluders",made:"Poured into a long cloth sausage in short sections",
  lore:"Hut No. 1's draught excluder is a long cloth dog filled with this. It stops the draught under the door so well that the hut once ran out of air. They added a hole."},
 {name:"Stillfall",rar:"rare",comp:[["Ga",55],["In",20],["Sn",15],["Zn",10]],mp:10,origin:"The Frozen Falls",kind:"event",uses:"Liquid-metal seals",made:"Collected from the foot of the frozen falls in the one week it moves",
  lore:"The waterfall at the back of the cavern froze in one go, mid-fall, with a salmon halfway up it. For one week a year, the falls run again. The salmon doesn't. This runs down the ice instead, and collects at the bottom."},
 {name:"Angelprint",rar:"common",comp:[["Sn",40],["Bi",52],["In",8]],mp:118,origin:"The Cavern Infant School",kind:"group",uses:"Moulds for casting impressions",made:"Poured into a snow angel and lifted out whole",
  lore:"The infant school makes snow angels on the first snow day and casts the best one in this. The cast angels hang in the school hall in a long row, and every year the children count them, and every year there is one more than there should be."},
 {name:"Kicksled Post",rar:"common",comp:[["Bi",44],["Pb",26],["Sn",20],["In",10]],mp:68,origin:"The Snowshoe Post",kind:"group",uses:"Postmark dies and seals",made:"Cast into a postmark that reads 'DELIVERED COLD'",
  lore:"When the snow's too deep for snowshoes, the post goes by kicksled. Every letter that comes that way is stamped DELIVERED COLD with a die of this, and the cavern collects them."},
 {name:"Gustcount",rar:"uncommon",comp:[["Hg",46],["Sn",30],["Cu",24]],mp:120,origin:"The Cavern Weather Station",kind:"institution",uses:"Balance weights in anemometer cups",made:"Pressed into the anemometer's cups to balance them",
  lore:"The weather station at the cavern mouth counts every gust that blows in. It has counted eighteen million. The station's keeper doesn't know what he's counting towards, but he's sure he'll know when he gets there."},
 {name:"Bottlewarm",rar:"common",comp:[["Bi",48],["Sn",22],["Pb",20],["Cd",10]],mp:76,origin:"Hester Brandt",kind:"person",uses:"Weights in hot-water bottle stoppers",made:"Cast into the stopper of a stone hot-water bottle",
  lore:"Coach Brandt gives every player a stone hot-water bottle on the bench. The stoppers are cast from this, and they go just soft enough to tell you when the water's too hot. The team has never lost a hand to a hot-water bottle, which is more than can be said for the valley team."},
 {name:"Thawday",rar:"uncommon",comp:[["In",40],["Bi",35],["Sn",25]],mp:64,origin:"The First Thaw Picnic",kind:"event",uses:"Low-melt castings for festival tokens",made:"Cast into a little crocus and handed out at the picnic",
  lore:"The first day the cavern mouth drips instead of freezes, everybody has a picnic outside it in four coats. Every family gets a cast crocus. Some families have fifty, and keep them in a jar, and nobody can remember what the first one looked like."},
 {name:"Frostfair",rar:"uncommon",comp:[["Sn",35],["In",35],["Pb",30]],mp:130,origin:"The Frost Fair on the Lower Ice",kind:"event",uses:"Toy castings and fair tokens",made:"Cast in a stall on the ice and stamped with the year",
  lore:"In a hard winter the lower pool freezes thick enough to hold a fair. There are stalls, a printing press, a roasting pig and one pig who escaped the roasting. The pig gets a token every year, cast in this, and it has more tokens than anybody."},
 {name:"Underice",rar:"rare",comp:[["Cs",60],["K",30],["Rb",10]],mp:-30,origin:"The Cryostat Lab",kind:"institution",uses:"Nothing safe; a sealed research sample",made:"Sealed in a glass ampoule under argon, then sealed in another",
  lore:"Divers under the lower ice saw something glowing and drifting about down there. They went back down with a jar. The lab has the jar, double-sealed, and it has not been opened, and everyone has agreed it never will be."},
 {name:"Firsthut",rar:"legendary",comp:[["Bi",44],["In",26],["Sn",18],["Ga",6],["Ag",6]],mp:48,origin:"The First Winter",kind:"event",uses:"Seals on the oldest door in the cavern",made:"Found sealing the door of Research Hut No. 1",
  lore:"Research Hut No. 1 was the first thing the Institute put up in the cavern, in the first winter. Its door is sealed round the edge with this, and it melts a little each time someone opens the door and sets again when they close it. It has been opened about ninety thousand times."},
 {name:"Deepthaw",rar:"legendary",comp:[["Ga",44],["In",32],["Sn",12],["Bi",8],["Zn",4]],mp:-5,origin:"The Glaciology Team",kind:"group",uses:"Nothing yet; under study",made:"Drained from the bottom of the deepest borehole",
  lore:"The glaciology team drilled down until the drill came up wet. What came up with it is this, and something very large and very hairy that was frozen in the ice nearby has, according to three separate witnesses, started to blink."}];
FROST_NEW.forEach(frostAlloy);

/* ---- their battle forms ---- */
const FLIMB=(d,c,w)=>`<path d="${d}" stroke="${FI}" stroke-width="${(w||4)+3}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${c}" stroke-width="${w||4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
const SNOW=(g)=>fG(g,1,[[30,40],[170,30],[150,70],[44,90]].map(([x,y])=>`<path d="M${x-4} ${y} h8 M${x} ${y-4} v8 M${x-3} ${y-3} l6 6 M${x+3} ${y-3} l-6 6" stroke="#BFE2F4" stroke-width="1.6" stroke-linecap="round"/>`).join(""));
const ICEFLOOR=(cx,rx)=>`<ellipse cx="${cx||100}" cy="146" rx="${rx||70}" ry="9" fill="#DCEFFA" stroke="#9ACBE6" stroke-width="2"/><path d="M${(cx||100)-40} 146 l10 -2 M${(cx||100)+20} 148 l12 -1" stroke="#FFF" stroke-width="2" opacity=".8"/>`;

/* 1 Elevenhundred: a ptarmigan in winter white with a tape measure, measuring the floor */
addForm("Elevenhundred",{n:"#F4F6FA",a:"#E8C040",rn:"#3A4A6A",rb:"#C8B8F0",ra:"#FF8A2A"},"stand",(P,g)=>fShadow(46,100)+ICEFLOOR(100,64)+
 pt("tail",128,112,`<path d="M124 108 Q146 104 150 118 Q140 122 126 118 Z" fill="${P.nd}" ${SW2}/>`)+
 [[92,"legB",.25],[108,"legF",0]].map(([x,c,d])=>pt(c,x,130,`<path d="M${x-6} 128 Q${x} 140 ${x+4} 142 L${x-10} 144 Z" fill="${P.nl}" ${SW2}/>`,d)).join("")+
 `<path d="M74 110 Q76 82 100 80 Q126 82 130 108 Q124 132 102 132 Q80 132 74 110 Z" fill="${P.n}" ${SW}/><path d="M84 104 Q90 94 100 96 M96 116 Q104 110 112 116" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 /* the tape, pulled out along the ice */
 pt("armF",86,108,`<path d="M88 104 Q72 102 70 114 Q82 118 92 112 Z" fill="${P.nd}" ${SW2}/><rect x="40" y="134" width="44" height="7" fill="${P.ac}" ${SW2}/>${[46,54,62,70,78].map(x=>`<path d="M${x} 134 v3" stroke="${FI}" stroke-width="1.2"/>`).join("")}<rect x="62" y="114" width="20" height="18" rx="4" fill="${P.ac}" ${SW2}/><circle cx="72" cy="123" r="4" fill="${P.nd}" ${SW2}/>`)+
 pt("head",88,74,`<circle cx="88" cy="72" r="16" fill="${P.n}" ${SW}/><path d="M80 64 Q84 60 88 62" stroke="#C83A2A" stroke-width="3" fill="none" stroke-linecap="round"/>${E2(82,70,3.6,"#1A1A1A",[-.3,.3])}`+
  `<path d="M72 74 L62 76 L72 78 Z" fill="${FMOUTH}"/>`+pt("beak",70,78,`<path d="M72 78 L62 78 L70 82 Z" fill="#2A2A30" ${SW2}/>`)+`<path d="M72 72 L60 76 L72 76 Z" fill="#2A2A30" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="104" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Elevenhundred"]="Measuring-Tape Ptarmigan";SM("Elevenhundred","One More Reading","SCR","s",0,100,"tacc-1,def+1","Pull the tape out, write it down. Pull it out again. Write that down too.");

/* 2 Biteless: a seal at a hole in the ice, rod out, line down, very content */
addForm("Biteless",{n:"#8A929A",a:"#D8DCE0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(58,110)+ICEFLOOR(104,80)+
 `<ellipse cx="58" cy="144" rx="18" ry="5" fill="#2A4A6A" ${SW2}/>`+pt("slow",58,140,`<path d="M58 106 V142" stroke="#E8E4DA" stroke-width="1"/><circle cx="58" cy="128" r="3" fill="#E8412C" ${SW2}/>`)+
 pt("tail",150,132,`<path d="M146 128 L172 120 L166 132 L174 142 L146 138 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M84 140 Q80 112 104 104 Q136 100 150 126 Q148 142 120 144 Q94 146 84 140 Z" fill="${P.n}" ${SW}/>${[[110,116],[126,122],[100,128],[136,132]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.nd}"/>`).join("")}`+
 pt("armF",96,130,`<path d="M96 128 Q86 140 96 144 Q104 142 106 134 Z" fill="${P.nd}" ${SW2}/><path d="M98 132 L62 100 L56 106" stroke="#6A4A2A" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M62 100 L58 106" stroke="#E8E4DA" stroke-width="1"/>`)+
 pt("head",90,106,`<path d="M106 108 Q104 86 86 84 Q68 86 66 102 Q70 116 90 116 Q104 116 106 108 Z" fill="${P.n}" ${SW}/>${E2(80,98,4.6,"#1A1A1A",[-.2,.3])}<circle cx="68" cy="104" r="3" fill="#1A1A1A"/>`+
  `<path d="M70 106 l-10 -2 M70 108 l-10 2" stroke="${FI}" stroke-width="1"/><path d="M74 90 Q84 76 98 86" fill="#4A6A9A" ${SW2}/><circle cx="86" cy="78" r="3.6" fill="#E8412C" ${SW2}/>`+pt("jaw",76,112,`<path d="M70 110 Q78 118 84 112 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="118" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Biteless"]="Ice-Hole Fishing Seal";SM("Biteless","Not A Nibble","RES","s",0,100,"heal:30,def+1","Three days and not a single bite. Best three days of its life.");

/* 3 Goalkeeper's Thaw (vial): a penguin in goalkeeping gloves in front of a goal made of snow, a little melted */
addForm("Goalkeeper's Thaw",{n:"#2A2E3A",a:"#F4F6FA",rn:"#F4F0F8",rb:"#3A5AA8",ra:"#FF8A2A"},"stand",(P,g)=>fShadow(40,100)+
 `<path d="M44 146 V74 H156 V146" fill="none" stroke="#F4FAFF" stroke-width="10" stroke-linejoin="round"/><path d="M44 146 V74 H156 V146" fill="none" stroke="#9ACBE6" stroke-width="2"/><path d="M50 80 L150 80 M50 80 L60 140 M150 80 L140 140" stroke="#C8D8E4" stroke-width="1" stroke-dasharray="3 3"/><path d="M40 146 q8 -6 16 0 q8 6 16 0" fill="#BFE2F4"/>`+
 [[92,"legB",.25],[108,"legF",0]].map(([x,c,d])=>pt(c,x,140,`<ellipse cx="${x}" cy="144" rx="9" ry="4" fill="#E8A030" ${SW2}/>`,d)).join("")+
 `<path d="M78 136 Q72 98 100 76 Q128 98 122 136 Q112 144 100 144 Q88 144 78 136 Z" fill="${P.n}" ${SW}/><path d="M88 134 Q84 104 100 90 Q116 104 112 134 Q106 140 100 140 Q94 140 88 134 Z" fill="${P.ac}"/>`+
 pt("wingF",78,104,`<path d="M80 96 Q60 96 54 80 Q66 82 78 90 Z" fill="${P.n}" ${SW2}/><circle cx="52" cy="78" r="9" fill="#E8412C" ${SW2}/><path d="M46 74 v8 M50 72 v8 M54 72 v8" stroke="#F4ECD8" stroke-width="1.6"/>`)+
 pt("wingB",122,104,`<path d="M120 96 Q140 96 146 80 Q134 82 122 90 Z" fill="${P.n}" ${SW2}/><circle cx="148" cy="78" r="9" fill="#E8412C" ${SW2}/>`,.3)+
 pt("head",100,72,`<circle cx="100" cy="70" r="15" fill="${P.n}" ${SW}/><ellipse cx="94" cy="70" rx="5" ry="6" fill="${P.ac}"/><ellipse cx="106" cy="70" rx="5" ry="6" fill="${P.ac}"/>${E2(94,70,3,"#1A1A1A",[0,0])}${E2(106,70,3,"#1A1A1A",[0,0])}`+
  `<path d="M96 78 L100 86 L104 78 Z" fill="${FMOUTH}"/>`+pt("beak",100,82,`<path d="M96 80 L100 88 L104 80 Z" fill="#E8A030" ${SW2}/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(20,120,6)));
FORM_TITLE["Goalkeeper's Thaw"]="Goal-Minding Penguin";SM("Goalkeeper's Thaw","Between The Posts","RES","s",0,100,"def+2","Gloves up, knees bent, eyes on the ball. Nothing gets past. Nothing has ever tried.");

/* 4 Fennimore Link: an axolotl whose frilly gills are sprinkler heads, one going off */
addForm("Fennimore Link",{n:"#E8A0B0",a:"#C8C4BA",rn:"#3A4A6A",rb:"#C8E8F0",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60,104)+
 pt("tail",146,126,`<path d="M140 120 Q170 112 186 124 Q170 140 140 136 Z" fill="${P.nl}" ${SW2}/><path d="M144 128 Q164 124 180 126" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`)+
 [[80,"legF",0],[96,"legB",.2],[126,"legF",.3],[140,"legB",.1]].map(([x,c,d])=>pt(c,x,132,`<path d="M${x} 130 Q${x-6} 140 ${x-10} 144 M${x-10} 144 l-4 -2 M${x-10} 144 l-2 3" stroke="${FI}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M70 128 Q74 108 104 106 Q140 106 148 126 Q140 138 106 138 Q78 138 70 128 Z" fill="${P.n}" ${SW}/><path d="M80 130 Q104 136 136 130" stroke="${P.nl}" stroke-width="3" fill="none"/>`+
 pt("head",66,114,`<path d="M84 110 Q80 92 62 92 Q42 94 40 112 Q46 126 66 126 Q82 124 84 110 Z" fill="${P.n}" ${SW}/>${E2(54,106,3.4,"#1A1A1A",[-.3,0])}${E2(70,104,3.4,"#1A1A1A",[-.3,0])}`+
  [[48,92,-30],[60,86,-6],[74,88,18]].map(([x,y,r],i)=>`<g transform="rotate(${r} ${x} ${y+6})"><path d="M${x} ${y+6} V${y-6}" stroke="${P.ac}" stroke-width="3"/><path d="M${x-6} ${y-6} H${x+6} L${x+4} ${y-10} H${x-4} Z" fill="${P.ac}" ${SW2}/></g>`).join("")+
  pt("spin",60,74,`${[0,1,2,3,4,5].map(i=>`<path d="M60 76 L${(60+Math.cos(i*1.05)*14).toFixed(1)} ${(76+Math.sin(i*1.05)*8-10).toFixed(1)}" stroke="#8AC8E8" stroke-width="2" stroke-dasharray="2 3" stroke-linecap="round"/>`).join("")}`)+
  pt("jaw",50,120,`<path d="M42 116 Q52 126 62 120 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="110" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Fennimore Link"]="Sprinkler-Crowned Axolotl";SM("Fennimore Link","Every Head At Once","DRP","a",60,100,"tspd-1@50","The link melts and every sprinkler opens. The fire goes out. So does everything else.");

/* 5 Mossgate Plug: a walrus wearing a boiler's crown plug as a cap, steam hissing out */
addForm("Mossgate Plug",{n:"#A8784E",a:"#F4ECD8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60,106)+ICEFLOOR(106,74)+
 pt("tail",150,134,`<path d="M146 130 L172 126 L168 138 L176 146 L148 142 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M66 140 Q60 100 98 92 Q142 88 152 132 Q146 146 110 146 Q76 146 66 140 Z" fill="${P.n}" ${SW}/><path d="M106 110 q8 -6 16 0 M116 126 q8 -6 16 0" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 pt("armF",86,134,`<path d="M88 128 Q74 138 78 146 Q92 146 96 136 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",80,96,`<path d="M104 98 Q100 70 78 70 Q56 72 54 96 Q58 114 80 114 Q100 112 104 98 Z" fill="${P.n}" ${SW}/>${E2(72,88,3.6,"#1A1A1A",[-.3,0])}${E2(88,86,3.6,"#1A1A1A",[-.3,0])}`+
  `<path d="M60 100 Q70 94 80 100 Q90 94 100 100 Q96 110 80 108 Q64 110 60 100 Z" fill="${P.nl}" ${SW2}/>${[64,70,90,96].map(x=>`<circle cx="${x}" cy="103" r="1" fill="${FI}"/>`).join("")}`+
  pt("jaw",80,108,`<path d="M70 106 Q80 114 90 106 Z" fill="${FMOUTH}"/><path d="M70 106 Q66 124 70 134 Q74 124 74 108 Z M90 106 Q94 124 90 134 Q86 124 86 108 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M66 72 H92 V64 H66 Z" fill="#B08040" ${SW2}/><path d="M70 64 V58 H88 V64" fill="#C8A060" ${SW2}/>`+pt("slow",79,52,`<path d="M74 54 Q70 44 76 38 Q72 32 78 26 M84 54 Q88 44 82 38 Q86 32 82 24" stroke="#E8ECF0" stroke-width="3" fill="none" stroke-linecap="round" opacity=".85"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="120" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,50,6)));
FORM_TITLE["Mossgate Plug"]="Safety-Plug Walrus";SM("Mossgate Plug","Hiss Instead","RES","s",0,100,"ward+1,cure","When the water runs low, it doesn't explode. It hisses, loudly, until somebody comes.");

/* 6 Pellowite: a lemming at a grinding wheel, a spectacle lens stuck to a blob of the alloy */
addForm("Pellowite",{n:"#B8784A",a:"#F4ECD8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(50,100)+
 `<rect x="114" y="104" width="44" height="42" fill="#6A6A70" ${SW}/><circle cx="136" cy="96" r="22" fill="#B8B8C0" ${SW}/><circle cx="136" cy="96" r="6" fill="#4A4A50" ${SW2}/>`+pt("spin",136,96,`<path d="M136 76 V116 M116 96 H156" stroke="#8A8A92" stroke-width="2"/>`)+
 [[86,"legB",.25],[102,"legF",0]].map(([x,c,d])=>pt(c,x,138,`<ellipse cx="${x}" cy="144" rx="7" ry="3.6" fill="#E8A8A0" ${SW2}/>`,d)).join("")+
 `<path d="M70 136 Q66 104 92 98 Q116 100 116 132 Q108 144 92 144 Q74 144 70 136 Z" fill="${P.n}" ${SW}/><path d="M80 134 Q78 114 92 112 Q104 116 104 134 Z" fill="${P.ac}"/>`+
 pt("armF",104,112,`${FLIMB("M100 114 Q112 108 116 100","#E8A8A0",3)}<ellipse cx="120" cy="96" rx="8" ry="10" fill="#E6F6FF" fill-opacity=".7" ${SW2}/><circle cx="122" cy="96" r="3.4" fill="${P.ac}" ${SW2}/>`)+
 pt("head",86,90,`<path d="M106 96 Q104 70 84 70 Q64 72 62 90 Q62 100 70 104 Q90 108 106 96 Z" fill="${P.n}" ${SW}/><path d="M64 86 Q70 96 84 98 Q76 90 76 82 Z" fill="${P.ac}"/>`+
  `<circle cx="80" cy="84" r="7" fill="#E6F6FF" fill-opacity=".5" stroke="#B8902A" stroke-width="2"/>${E2(80,84,3.2,"#1A1A1A",[.2,0])}<circle cx="62" cy="92" r="2.6" fill="#E8708A"/>`+pt("ear",94,70,`<circle cx="94" cy="72" r="6" fill="${P.n}" ${SW2}/>`)+pt("jaw",68,100,`<path d="M64 98 Q70 104 76 100 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="92" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Pellowite"]="Spectacle-Grinding Lemming";SM("Pellowite","Knows When To Let Go","RES","s",0,100,"tacc-1,cure","Into the warm water, and the lens drops free. Perfectly ground. Perfectly clean.");

/* 7 Hogline Special: a tortoise whose shell is a curling stone, a little broom held in front */
addForm("Hogline Special",{n:"#7A8A5A",a:"#C83A2A",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(56,104)+ICEFLOOR(104,80)+
 `<path d="M150 140 H190 M156 136 H186" stroke="#C83A2A" stroke-width="2"/>`+
 [[80,"legF",0],[96,"legB",.2],[118,"legF",.3],[132,"legB",.1]].map(([x,c,d])=>pt(c,x,136,`<path d="M${x-5} 128 Q${x-6} 140 ${x} 144 Q${x+6} 140 ${x+5} 128 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 /* the stone: granite dome, band, handle on top */
 `<path d="M68 132 Q66 98 106 94 Q146 98 144 132 Z" fill="#8A8A92" ${SW}/><path d="M68 124 H144" stroke="${P.ac}" stroke-width="7"/><path d="M68 124 H144" stroke="${FI}" stroke-width="1"/>${[[84,110],[100,104],[118,108],[132,116],[92,118]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.8" fill="#5A5A62"/>`).join("")}`+
 `<path d="M98 94 V84 H124 Q132 84 132 92" fill="none" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M98 94 V84 H124 Q132 84 132 92" fill="none" stroke="${P.ac}" stroke-width="4" stroke-linecap="round"/>`+
 pt("tail",146,130,`<path d="M144 128 L156 132 L144 134 Z" fill="${P.n}" ${SW2}/>`)+
 pt("head",58,118,`<path d="M72 124 Q70 104 54 104 Q38 106 38 118 Q42 128 56 128 Q68 128 72 124 Z" fill="${P.n}" ${SW}/>${E2(50,114,3.6,"#1A1A1A",[-.3,0])}`+
  `<path d="M42 102 L22 78" stroke="#8A6A44" stroke-width="3"/><path d="M14 80 Q22 70 32 76 L28 82 Q20 80 14 80 Z" fill="#E8D8B0" ${SW2}/>`+pt("jaw",44,124,`<path d="M38 120 Q44 128 52 124 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="106" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Hogline Special"]="Curling-Stone Tortoise";SM("Hogline Special","Sweep! Sweep!","STR","a",65,95,"tspd-1@40","Slow down the ice, never short of the line. It's been three seasons. It's never short.");

/* 8 Coldsnap (vial): a crane whose long neck is a thermometer, the bulb as its chest */
addForm("Coldsnap",{n:"#DCE4EC",a:"#C83A2A",rn:"#3A4A6A",rb:"#C8E8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(40,100)+ICEFLOOR(100,56)+
 [[94,"legB",.25],[106,"legF",0]].map(([x,c,d])=>pt(c,x,128,`<path d="M${x} 116 L${x+2} 132 L${x-2} 146 M${x-2} 146 l-8 0 M${x-2} 146 l6 -2" stroke="${FI}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,d)).join("")+
 pt("tail",124,104,`<path d="M120 100 Q146 96 156 112 Q140 112 124 110 Z" fill="${P.nd}" ${SW2}/><path d="M128 104 L150 108" stroke="${FI}" stroke-width="1"/>`)+
 `<path d="M78 108 Q80 90 100 88 Q124 88 128 106 Q120 120 102 120 Q84 120 78 108 Z" fill="${P.n}" ${SW}/><circle cx="96" cy="108" r="9" fill="${P.ac}" ${SW2}/><circle cx="93" cy="105" r="2.4" fill="#FFF" opacity=".7"/>`+
 pt("wingF",108,100,`<path d="M100 96 Q120 92 128 104 Q114 110 102 106 Z" fill="${P.nl}" ${SW2}/>`)+
 pt("head",88,58,`<path d="M92 100 Q88 70 84 48" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M92 100 Q88 70 84 48" stroke="#F4FAFF" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M92 100 Q90 84 89 74" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${[90,82,74,66,58].map(y=>`<path d="M${86+(y-60)*.1} ${y} h4" stroke="${FI}" stroke-width="1"/>`).join("")}`+
  `<circle cx="84" cy="44" r="10" fill="${P.n}" ${SW}/><path d="M80 36 Q84 32 90 36" fill="#C83A2A" stroke="${FI}" stroke-width="1.2"/>${E2(80,44,3,"#1A1A1A",[-.3,0])}`+
  `<path d="M75 46 L52 48 L74 50 Z" fill="${FMOUTH}"/>`+pt("beak",74,50,`<path d="M74 50 L52 50 L72 54 Z" fill="#4A4A50" ${SW2}/>`)+`<path d="M75 44 L50 48 L75 48 Z" fill="#4A4A50" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="112" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,50,6)));
FORM_TITLE["Coldsnap"]="Thermometer-Necked Crane";SM("Coldsnap","Reading Agreed","SCR","s",0,100,"tacc-1@60,def+1","It's always the same reading. That's the point. That's the only reading anyone agrees on.");

/* 9 Iceharvest: a beaver with a two-man ice saw, a block of cut ice behind it */
addForm("Iceharvest",{n:"#8A5A34",a:"#5A3A20",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54,104)+ICEFLOOR(104,76)+
 `<path d="M128 146 V108 H170 V146 Z" fill="#DCEFFA" fill-opacity=".85" ${SW}/><path d="M134 116 L150 112 M140 132 L160 128" stroke="#FFF" stroke-width="3" opacity=".8"/><path d="M128 108 L138 100 H180 L170 108 Z" fill="#EAF6FF" ${SW2}/><path d="M170 108 L180 100 V138 L170 146 Z" fill="#BFE2F4" ${SW2}/>`+
 pt("tail",120,138,`<ellipse cx="128" cy="140" rx="18" ry="7" fill="${P.ac}" ${SW2}/><path d="M114 138 h28 M116 142 h24" stroke="${P.nd}" stroke-width="1" stroke-dasharray="3 2"/>`)+
 [[86,"legB",.25],[104,"legF",0]].map(([x,c,d])=>pt(c,x,138,`<ellipse cx="${x}" cy="144" rx="8" ry="4" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M68 136 Q62 100 92 92 Q122 96 120 132 Q112 146 92 146 Q72 146 68 136 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",80,112,`<path d="M40 76 L132 108 L129 117 L37 85 Z" fill="#C8CCD4" ${SW2}/>${Array.from({length:15},(_,i)=>`<path d="M${39+i*6.1} ${85.5+i*2.12} l3 5 l3 -3" stroke="${FI}" stroke-width="1.4" fill="#C8CCD4"/>`).join("")}<path d="M50 82 L120 106" stroke="#FFF" stroke-width="1.6" opacity=".7"/><path d="M36 74 V88" stroke="#6A4A2A" stroke-width="6" stroke-linecap="round"/>${FLIMB("M84 110 Q76 100 70 94","#8A5A34",4)}`)+
 pt("head",84,86,`<path d="M104 92 Q104 66 84 64 Q62 64 60 84 Q60 98 76 100 Q96 102 104 92 Z" fill="${P.n}" ${SW}/>${E2(76,80,3.6,"#1A1A1A",[-.3,0])}<ellipse cx="64" cy="88" rx="5" ry="4" fill="#3A2A20"/>`+
  pt("ear",94,66,`<circle cx="94" cy="66" r="5" fill="${P.nd}" ${SW2}/>`)+pt("jaw",70,98,`<path d="M64 96 Q70 104 78 98 Z" fill="${FMOUTH}"/><rect x="68" y="96" width="6" height="6" fill="#F4E8C8" ${SW2}/>`))+
 SNOW(g)+fG(g,2,`<circle cx="92" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,120,6)));
FORM_TITLE["Iceharvest"]="Ice-Saw Beaver";SM("Iceharvest","Cut To Size","STR","a",75,90,"crit","One stroke, two, a crack, and a block the size of a cupboard slides off the floor.");

/* 10 Lagwrap: a stoat in its winter coat, wound round with pipe lagging like a scarf, a bent pipe in its paws */
addForm("Lagwrap",{n:"#F4F2EC",a:"#D8A060",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"slink",(P,g)=>fShadow(60,100)+
 pt("tail",150,126,`<path d="M140 124 Q164 116 178 126" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M140 124 Q164 116 178 126" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M172 122 Q182 124 182 130" stroke="#1A1A1E" stroke-width="7" stroke-linecap="round"/>`)+
 [[74,"legF",0],[90,"legB",.2],[128,"legF",.3],[142,"legB",.1]].map(([x,c,d])=>pt(c,x,136,`<path d="M${x} 130 V144" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M${x} 130 V144" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M62 124 Q64 108 100 108 Q140 108 148 122 Q144 136 104 136 Q66 136 62 124 Z" fill="${P.n}" ${SW}/>`+
 /* the lagging */
 `${[78,90,102,114].map((x,i)=>`<path d="M${x} 108 Q${x+6} 122 ${x} 136" stroke="${FI}" stroke-width="9" fill="none"/><path d="M${x} 108 Q${x+6} 122 ${x} 136" stroke="${P.ac}" stroke-width="6" fill="none"/>`).join("")}`+
 pt("armF",68,118,`<path d="M30 132 V112 Q30 100 42 100 H58" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M30 132 V112 Q30 100 42 100 H58" stroke="#C88A50" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("head",58,104,`<path d="M74 110 Q70 90 54 90 Q38 92 34 104 Q40 116 58 116 Q72 116 74 110 Z" fill="${P.n}" ${SW}/><circle cx="35" cy="104" r="2.6" fill="#1A1A1A"/>${E2(50,100,3.2,"#1A1A1A",[-.4,0])}`+
  pt("ear",62,90,`<path d="M58 92 Q60 82 68 86 Q68 92 64 96 Z" fill="${P.n}" ${SW2}/>`)+pt("jaw",42,112,`<path d="M36 108 Q42 116 50 112 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="124" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Lagwrap"]="Pipe-Lagged Stoat";SM("Lagwrap","No Kinks","RES","s",0,100,"def+1,ward+1","Fill it, bend it, melt it out. Four hundred pipes and not one kink.");

/* 11 Skyshow Wager: an arctic fox sat on a sweepstake tin, looking up at the aurora, ticket in its teeth */
addForm("Skyshow Wager",{n:"#F4F2EC",a:"#5AC8A0",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,104)+
 `<path d="M20 30 Q60 10 100 30 T180 26" stroke="${P.ac}" stroke-width="8" fill="none" opacity=".45" stroke-linecap="round"/><path d="M30 44 Q70 26 110 42 T186 40" stroke="#9A7AE8" stroke-width="6" fill="none" opacity=".35" stroke-linecap="round"/>`+
 `<rect x="84" y="120" width="44" height="26" rx="3" fill="#C8A040" ${SW}/><path d="M84 128 H128" stroke="${FI}" stroke-width="1.4"/><rect x="100" y="122" width="12" height="4" fill="#2A2A30"/>`+
 pt("tail",130,112,`<path d="M124 116 Q154 120 162 98 Q164 84 150 82 Q154 98 138 104 Z" fill="${P.n}" ${SW}/><path d="M156 86 Q160 94 156 100" stroke="${P.nd}" stroke-width="2" fill="none"/>`)+
 `<path d="M86 122 Q82 96 104 88 Q126 92 126 120 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",96,116,`<path d="M92 104 V122 M102 104 V122" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M92 104 V122 M102 104 V122" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("head",102,74,`<path d="M118 82 Q118 60 102 58 Q84 58 82 74 Q76 78 76 84 Q86 90 104 90 Q118 90 118 82 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",92,58,`<path d="M88 62 L86 44 L98 56 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",110,58,`<path d="M106 58 L116 44 L116 62 Z" fill="${P.n}" ${SW2}/>`,.3)+
  `${E2(94,70,3.6,"#1A1A1A",[0,-.6])}${E2(108,70,3.6,"#1A1A1A",[0,-.6])}<circle cx="77" cy="82" r="2.6" fill="#1A1A1A"/>`+pt("jaw",84,88,`<path d="M78 86 Q86 92 92 88 Z" fill="${FMOUTH}"/><rect x="70" y="86" width="12" height="7" fill="#F4ECD8" stroke="${FI}" stroke-width="1" transform="rotate(-14 76 90)"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="106" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,110,6)));
FORM_TITLE["Skyshow Wager"]="Aurora-Watching Arctic Fox";SM("Skyshow Wager","Tonight's The Night","CUR","s",0,100,"tacc-1,spd+1","It's going to show tonight. It's sure of it. It's been sure every night for years.");

/* 12 Lastblock: a polar bear cub carrying the last block up to the top of an igloo */
addForm("Lastblock",{n:"#F4F2EA",a:"#DCEFFA",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56,96)+
 `<path d="M108 146 Q108 92 150 90 Q190 92 190 146 Z" fill="${P.ac}" ${SW}/>${[104,118,132].map((y,i)=>`<path d="M${112+i*6} ${y} H${188-i*4}" stroke="#9ACBE6" stroke-width="2"/>`).join("")}${[[130,98],[156,96],[124,112],[150,112],[172,112],[136,126],[162,126]].map(([x,y])=>`<path d="M${x} ${y} v12" stroke="#9ACBE6" stroke-width="2"/>`).join("")}<path d="M138 146 Q138 128 150 128 Q162 128 162 146 Z" fill="#2A3A4A" ${SW2}/>`+
 [[70,"legB",.25],[90,"legF",0]].map(([x,c,d])=>pt(c,x,138,`<ellipse cx="${x}" cy="143" rx="9" ry="5" fill="${P.n}" ${SW2}/>`,d)).join("")+
 `<path d="M56 136 Q50 104 78 96 Q104 100 102 132 Q94 146 78 146 Q60 146 56 136 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",88,104,`<rect x="86" y="70" width="30" height="18" rx="2" fill="${P.ac}" ${SW}/><path d="M90 76 H112" stroke="#FFF" stroke-width="2"/>${FLIMB("M84 108 Q90 96 92 88",P.n,5)}`)+
 pt("head",74,86,`<circle cx="74" cy="84" r="16" fill="${P.n}" ${SW}/>`+pt("ear",64,70,`<circle cx="64" cy="70" r="5" fill="${P.n}" ${SW2}/>`)+pt("ear",84,68,`<circle cx="84" cy="68" r="5" fill="${P.n}" ${SW2}/>`,.3)+
  `${E2(68,82,3.2,"#1A1A1A",[.4,-.4])}${E2(80,82,3.2,"#1A1A1A",[.4,-.4])}<ellipse cx="74" cy="92" rx="5" ry="4" fill="${P.nl}"/><circle cx="74" cy="90" r="2.4" fill="#1A1A1A"/>`+pt("jaw",74,96,`<path d="M70 95 Q74 100 78 95 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="80" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,60,6)));
FORM_TITLE["Lastblock"]="Keystone-Carrying Polar Bear Cub";SM("Lastblock","Top It Off","DRP","a",70,95,"def+1","Last block, top of the dome, and if it doesn't hold, the whole lot comes down on you.");

/* 13 Runnerglide (vial): a badger at the front of a racing sledge, steering rope in its paws */
addForm("Runnerglide",{n:"#5A5A60",a:"#F4F2EC",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(66,104)+
 `<path d="M40 136 H160 Q176 136 176 124" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M40 136 H160 Q176 136 176 124" stroke="#C8CCD4" stroke-width="3" fill="none" stroke-linecap="round"/><rect x="50" y="118" width="110" height="10" rx="2" fill="#A8784E" ${SW2}/><path d="M64 128 V136 M100 128 V136 M140 128 V136" stroke="${FI}" stroke-width="3"/>`+
 `<path d="M30 140 l-14 0 M34 132 l-16 -2 M30 124 l-12 -4" stroke="#BFE2F4" stroke-width="2.4" stroke-linecap="round"/>`+
 pt("tail",142,108,`<path d="M138 108 Q152 104 156 112 Q148 116 138 114 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M84 118 Q80 88 112 84 Q144 86 142 118 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",98,100,`<path d="M164 122 Q140 104 100 104" stroke="#8A6A44" stroke-width="2" fill="none"/>${FLIMB("M104 106 Q94 98 92 106",P.n,5)}`)+
 pt("head",92,80,`<path d="M112 86 Q110 62 90 62 Q68 64 64 80 Q66 92 88 92 Q108 94 112 86 Z" fill="${P.n}" ${SW}/><path d="M66 78 Q80 66 100 66 Q90 72 88 88 Q74 88 66 78 Z" fill="${P.ac}"/><path d="M80 62 Q90 74 92 90" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
  `${E2(82,74,3.4,"#1A1A1A",[-.5,0])}<circle cx="65" cy="80" r="3" fill="#1A1A1A"/><rect x="74" y="66" width="20" height="8" rx="3" fill="#C8E6F4" fill-opacity=".7" ${SW2}/>`+pt("jaw",72,88,`<path d="M66 86 Q72 94 80 88 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="114" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Runnerglide"]="Sledge-Steering Badger";SM("Runnerglide","Waxed Runners","STR","a",60,100,"spd+1","Nobody's runner wax is this good. Nobody's runner wax is allowed to be this good.");

/* 14 Bootspike: a mountain goat with crampons strapped on, picking its way up an ice step */
addForm("Bootspike",{n:"#F4F0E6",a:"#C83A2A",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54,104)+
 `<path d="M20 146 H80 V120 H140 V96 H196 V146 Z" fill="#DCEFFA" ${SW}/><path d="M80 120 L90 126 M140 96 L150 102" stroke="#9ACBE6" stroke-width="2"/>`+
 [[90,"legB",.2,120],[104,"legF",0,120],[136,"legB",.3,96],[148,"legF",.1,96]].map(([x,c,d,y])=>pt(c,x,y-10,`<path d="M${x} ${y-24} V${y-2}" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M${x} ${y-24} V${y-2}" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/><path d="M${x-5} ${y} h10 M${x-4} ${y} l-1 3 M${x} ${y} v3 M${x+4} ${y} l1 3" stroke="#6A6A70" stroke-width="1.6"/><path d="M${x-4} ${y-6} h8" stroke="${P.ac}" stroke-width="2"/>`,d)).join("")+
 pt("tail",156,72,`<path d="M152 74 Q162 66 160 76 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M84 98 Q86 70 118 68 Q152 66 156 84 Q154 100 120 102 Q88 104 84 98 Z" fill="${P.n}" ${SW}/><path d="M96 74 Q120 70 140 74" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 pt("head",80,70,`<path d="M96 76 Q94 52 78 50 Q62 52 60 66 Q60 80 74 84 Q92 86 96 76 Z" fill="${P.n}" ${SW}/><path d="M76 50 Q86 30 102 36 Q90 38 84 52 Z" fill="#6A6A70" ${SW2}/>${E2(74,62,3.4,"#C88A2A",[-.4,0])}`+
  `<path d="M64 80 Q66 94 72 98 Q74 90 72 82" fill="${P.n}" ${SW2}/>`+pt("ear",88,58,`<path d="M88 58 L102 60 L92 64 Z" fill="${P.n}" ${SW2}/>`)+pt("jaw",64,78,`<path d="M60 74 Q64 82 70 78 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="120" cy="88" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,60,6)));
FORM_TITLE["Bootspike"]="Crampon-Footed Mountain Goat";SM("Bootspike","Front Points","STR","a",70,95,"tacc-1@30","Kick, kick, step. The ice gives a little and then holds. It always holds.");

/* 15 Trailbreaker (vial): a wolverine in big snowshoes, post bag on its back */
addForm("Trailbreaker",{n:"#4A3426",a:"#D8A060",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"slink",(P,g)=>fShadow(62,104)+
 [[78,"legF",0],[96,"legB",.2],[124,"legF",.3],[140,"legB",.1]].map(([x,c,d])=>pt(c,x,136,`<path d="M${x} 126 V140" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M${x} 126 V140" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/><ellipse cx="${x}" cy="143" rx="14" ry="4" fill="#C8A878" ${SW2}/><path d="M${x-10} 143 H${x+10} M${x} 140 V146" stroke="#8A6A44" stroke-width="1"/>`,d)).join("")+
 pt("tail",150,116,`<path d="M146 112 Q170 108 176 122 Q160 124 146 120 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M64 124 Q66 100 104 98 Q144 98 152 118 Q146 132 106 132 Q70 132 64 124 Z" fill="${P.n}" ${SW}/><path d="M76 112 Q104 104 138 112" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 `<rect x="98" y="82" width="34" height="22" rx="4" fill="#8A3A2A" ${SW}/><path d="M98 90 H132" stroke="${FI}" stroke-width="1.6"/><path d="M110 86 h10 v6 h-10 Z" fill="#F4ECD8" stroke="${FI}" stroke-width="1"/>`+
 pt("head",62,106,`<path d="M80 110 Q78 88 60 88 Q42 90 40 104 Q44 118 62 118 Q78 118 80 110 Z" fill="${P.n}" ${SW}/><path d="M44 104 Q52 98 62 100" stroke="${P.ac}" stroke-width="3" fill="none"/>${E2(56,100,3.2,"#1A1A1A",[-.3,0])}<circle cx="41" cy="106" r="2.6" fill="#1A1A1A"/>`+
  pt("ear",68,90,`<circle cx="68" cy="90" r="5" fill="${P.n}" ${SW2}/>`)+pt("jaw",48,114,`<path d="M42 110 Q48 118 56 114 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="120" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Trailbreaker"]="Snowshoe-Wearing Wolverine";SM("Trailbreaker","First Out","STR","a",60,100,"spd+1","First thing in the morning, before anyone, through snow up to its chin. The post must go through.");

/* 16 Beaconbark: a big mountain rescue dog with a beacon on its collar, bleeping */
addForm("Beaconbark",{n:"#C87A3A",a:"#F4F0E6",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(58,104)+ICEFLOOR(104,74)+
 pt("tail",150,106,`<path d="M146 108 Q170 96 172 76" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M146 108 Q170 96 172 76" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 [[132,"legB",.25],[146,"legB",.1]].map(([x,c,d])=>pt(c,x,126,`<path d="M${x} 116 V142" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 116 V142" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M70 112 Q72 86 110 86 Q150 86 154 112 Q148 128 110 128 Q74 128 70 112 Z" fill="${P.n}" ${SW}/><path d="M96 92 Q116 86 136 96 Q132 112 112 114 Q96 110 96 92 Z" fill="${P.ac}"/>`+
 [[80,"legF",0],[94,"legF",.2]].map(([x,c,d])=>pt(c,x,126,`<path d="M${x} 116 V142" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 116 V142" stroke="${P.ac}" stroke-width="6" stroke-linecap="round"/>`,d)).join("")+
 pt("head",72,80,`<path d="M92 88 Q92 58 70 56 Q48 58 46 76 Q38 80 38 88 Q48 98 70 98 Q90 98 92 88 Z" fill="${P.n}" ${SW}/><path d="M48 78 Q58 72 66 80 Q64 94 50 94 Q40 92 38 88 Q40 80 48 78 Z" fill="${P.ac}"/><circle cx="39" cy="86" r="3.6" fill="#1A1A1A"/>${E2(66,72,3.8,"#4A2A10",[-.4,0])}`+
  pt("ear",80,62,`<path d="M78 62 Q92 62 92 82 Q82 80 76 70 Z" fill="${P.nd}" ${SW2}/>`)+pt("jaw",50,96,`<path d="M42 94 Q50 104 60 98 Z" fill="${FMOUTH}"/><path d="M48 98 Q50 106 54 104" fill="#E87A8A" stroke="${FI}" stroke-width="1"/>`)+
  `<path d="M74 94 Q84 104 92 96" stroke="#C83A2A" stroke-width="4" fill="none"/><rect x="76" y="100" width="12" height="14" rx="3" fill="#E8C040" ${SW2}/><circle cx="82" cy="105" r="2" fill="#E8412C"/>`+pt("slow",82,106,`<path d="M92 100 q4 6 0 12 M96 96 q7 10 0 20" stroke="#E8412C" stroke-width="1.6" fill="none"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="118" cy="106" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Beaconbark"]="Rescue-Barrel Mountain Dog";SM("Beaconbark","Bleep Along","HEA","s",0,100,"heal:40,ward+1","The beacon bleeps. The dog bleeps too. Between them, they'll find you under any amount of snow.");

/* 17 Core Nine: a woodpecker drilling into a cylinder of ice core, a dark vein running through it */
addForm("Core Nine",{n:"#4A4A58",a:"#E8412C",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(40,120)+
 `<rect x="108" y="20" width="40" height="128" rx="6" fill="#DCEFFA" fill-opacity=".9" ${SW}/>${[40,64,88,112,132].map(y=>`<path d="M108 ${y} H148" stroke="#9ACBE6" stroke-width="1.6"/>`).join("")}<path d="M128 20 Q120 60 130 90 Q138 120 126 148" stroke="#8A8A98" stroke-width="5" fill="none"/><text x="134" y="34" font-size="9" font-weight="bold" fill="${FI}">9</text>`+
 pt("tail",106,122,`<path d="M100 112 L104 146 L110 140 L112 116 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legF",104,100,`<path d="M100 96 L110 98 M100 106 L110 108" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 `<path d="M84 110 Q78 82 96 72 Q112 76 110 108 Q102 124 92 122 Q84 120 84 110 Z" fill="${P.n}" ${SW}/>${[[92,88],[98,100],[90,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="#F4F0E6"/>`).join("")}`+
 pt("wingF",96,90,`<path d="M90 82 Q80 104 88 118 Q96 108 98 92 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",96,62,`<circle cx="94" cy="62" r="14" fill="${P.n}" ${SW}/><path d="M84 52 Q94 42 104 52 Q96 50 90 56 Z" fill="${P.ac}" ${SW2}/>${E2(98,60,3,"#1A1A1A",[.4,0])}`+
  `<path d="M106 62 L118 64 L106 66 Z" fill="${FMOUTH}"/>`+pt("beak",108,66,`<path d="M106 66 L120 66 L106 70 Z" fill="#6A6A70" ${SW2}/>`)+`<path d="M106 60 L122 64 L106 64 Z" fill="#6A6A70" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="96" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,50,6)));
FORM_TITLE["Core Nine"]="Ice-Core Drilling Woodpecker";SM("Core Nine","The Ninth Core","DRP","a",70,95,"tacc-1@30","Eight cores of plain old ice. Then the ninth, and everybody leans in to look.");

/* 18 Grottodrip: a newt clinging to an icicle, a drop forming at the tip below it */
addForm("Grottodrip",{n:"#7A9A5A",a:"#F2A030",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(40,100)+
 `<ellipse cx="100" cy="144" rx="44" ry="8" fill="#3A6E90" ${SW2}/><path d="M80 142 q6 -3 12 0 M104 146 q6 -3 12 0" stroke="#BFE2F4" stroke-width="1.6" fill="none"/>`+
 `<path d="M70 4 H130 L104 112 L100 120 L96 112 Z" fill="#DCEFFA" fill-opacity=".9" ${SW}/><path d="M86 10 L100 100" stroke="#FFF" stroke-width="3" opacity=".7"/>`+
 pt("slow",100,124,`<path d="M100 122 Q96 130 100 134 Q104 130 100 122 Z" fill="#BFE2F4" ${SW2}/>`)+
 pt("tail",108,30,`<path d="M106 34 Q120 20 116 8" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M106 34 Q120 20 116 8" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 [[92,46,"legB",.2],[110,46,"legB",0],[94,74,"legF",.3],[106,74,"legF",.1]].map(([x,y,c,d])=>pt(c,x,y,`<path d="M${x} ${y} L${x+(x<100?-8:8)} ${y+4}" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><circle cx="${x+(x<100?-9:9)}" cy="${y+4}" r="2" fill="${P.ac}"/>`,d)).join("")+
 `<path d="M92 36 Q100 30 108 36 L106 76 Q100 82 94 76 Z" fill="${P.n}" ${SW}/>${[46,56,66].map(y=>`<circle cx="100" cy="${y}" r="2.4" fill="${P.ac}"/>`).join("")}`+
 pt("head",100,86,`<path d="M92 78 Q90 96 100 100 Q110 96 108 78 Z" fill="${P.n}" ${SW}/>${E2(94,86,2.8,"#1A1A1A",[0,.4])}${E2(106,86,2.8,"#1A1A1A",[0,.4])}`+pt("jaw",100,96,`<path d="M95 94 Q100 100 105 94 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="60" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Grottodrip"]="Meltwater Newt";SM("Grottodrip","Drip, Drip","RES","s",0,100,"heal:25","One drop, then another, then another, forever. It isn't in any hurry. It has the whole cavern.");

/* 19 Rinkside: an emu on figure skates, one leg up in an arabesque */
addForm("Rinkside",{n:"#6A5A4A",a:"#8AB8D8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,96)+ICEFLOOR(96,70)+
 `<path d="M50 140 Q80 132 120 144 Q150 152 170 138" stroke="#FFF" stroke-width="2" fill="none" opacity=".9"/>`+
 pt("legF",94,120,`<path d="M96 104 L94 134" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M96 104 L94 134" stroke="#8A8A90" stroke-width="2.6" stroke-linecap="round"/><path d="M84 136 H102 V132 H88 Z" fill="#F4F0E6" ${SW2}/><path d="M82 141 H106" stroke="#C8CCD4" stroke-width="2.4"/>`)+
 pt("legB",112,104,`<path d="M110 104 L140 84" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M110 104 L140 84" stroke="#8A8A90" stroke-width="2.6" stroke-linecap="round"/><path d="M138 80 L152 76 L154 82 L142 88 Z" fill="#F4F0E6" ${SW2}/><path d="M138 90 L158 80" stroke="#C8CCD4" stroke-width="2.4"/>`,.3)+
 `<path d="M80 100 Q74 74 102 70 Q128 72 126 98 Q116 112 100 110 Q84 108 80 100 Z" fill="${P.n}" ${SW}/>${[[90,84],[104,80],[114,92],[96,96]].map(([x,y])=>`<path d="M${x} ${y} q3 4 0 8" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 `<path d="M84 96 Q98 104 114 98" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 pt("head",84,48,`<path d="M88 76 Q80 56 82 38" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M88 76 Q80 56 82 38" stroke="#8AA0B8" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="82" cy="34" r="9" fill="${P.n}" ${SW}/>${E2(78,32,2.8,"#C83A2A",[-.4,0])}`+
  `<path d="M74 36 L62 38 L74 40 Z" fill="${FMOUTH}"/>`+pt("beak",72,40,`<path d="M74 40 L62 40 L72 44 Z" fill="#3A3A40" ${SW2}/>`)+`<path d="M74 34 L60 38 L74 38 Z" fill="#3A3A40" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="104" cy="90" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Rinkside"]="Figure-Skating Emu";SM("Rinkside","Triple Jump","STR","a",70,90,"tacc-1@40","Round once, twice, three times, and down on one blade, as if it was nothing.");

/* 20 Slapshot Blend: a narwhal with a hockey stick, puck on the ice, tusk as a second stick */
addForm("Slapshot Blend",{n:"#8A929A",a:"#F4F0E6",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"swim",(P,g)=>fShadow(58,104)+ICEFLOOR(104,80)+
 `<ellipse cx="44" cy="142" rx="9" ry="3.6" fill="#1A1A1E" ${SW2}/>`+
 pt("tail",158,118,`<path d="M150 116 Q170 104 182 108 Q174 118 182 130 Q170 132 150 124 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M62 120 Q66 96 104 94 Q144 94 156 118 Q146 136 106 136 Q70 136 62 120 Z" fill="${P.n}" ${SW}/>${[[90,104],[110,100],[128,106],[100,118],[138,120]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.nd}"/>`).join("")}`+
 `<path d="M76 126 Q104 134 140 126" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 pt("armF",96,124,`<path d="M96 120 Q84 134 92 140 Q102 138 104 128 Z" fill="${P.nd}" ${SW2}/><path d="M96 126 L60 108" stroke="#6A4A2A" stroke-width="4" stroke-linecap="round"/><path d="M60 108 L46 140 L58 142 L64 112 Z" fill="#E8D8B0" ${SW2}/><path d="M50 132 l10 3" stroke="${FI}" stroke-width="2.4"/>`)+
 pt("head",72,108,`<path d="M84 112 Q80 94 64 96 Q48 98 46 112 Q50 124 66 122 Q80 122 84 112 Z" fill="${P.n}" ${SW}/>${E2(62,106,3.4,"#1A1A1A",[-.4,0])}`+
  `<path d="M48 104 L8 88" stroke="${FI}" stroke-width="6" stroke-linecap="round"/><path d="M48 104 L8 88" stroke="#F4F0E6" stroke-width="3.4" stroke-linecap="round"/>${[16,24,32,40].map(x=>`<path d="M${x} ${88+(x-8)*.4-2} l-2 5" stroke="#B8B0A0" stroke-width="1"/>`).join("")}`+pt("jaw",54,118,`<path d="M48 116 Q54 124 62 118 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="118" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,50,6)));
FORM_TITLE["Slapshot Blend"]="Hockey-Stick Narwhal";SM("Slapshot Blend","Slapshot","DRP","a",80,85,"crit","Wind up, follow through, and a puck that weighs as much as a brick goes the length of the rink.");

/* 21 Toothache Special: a snow leopard with a scarf tied round its jaw for a toothache, holding a warm impression tray */
addForm("Toothache Special",{n:"#E8E0D0",a:"#C83A2A",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56,104)+ICEFLOOR(104,74)+
 pt("tail",150,118,`<path d="M146 120 Q178 128 182 104 Q184 88 172 86" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M146 120 Q178 128 182 104 Q184 88 172 86" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>${[[166,124],[180,108],[178,92]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="none" stroke="#4A4A50" stroke-width="1.6"/>`).join("")}`)+
 [[130,"legB",.25],[144,"legB",.1]].map(([x,c,d])=>pt(c,x,128,`<path d="M${x} 118 V142" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 118 V142" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M72 116 Q74 92 108 90 Q146 90 152 114 Q146 130 110 130 Q76 130 72 116 Z" fill="${P.n}" ${SW}/>${[[92,100],[110,98],[128,102],[100,114],[120,116],[140,110]].map(([x,y])=>`<path d="M${x-3} ${y} a3.4 3.4 0 1 1 6 0" stroke="#4A4A50" stroke-width="1.6" fill="none"/>`).join("")}`+
 [[82,"legF",0],[96,"legF",.2]].map(([x,c,d])=>pt(c,x,128,`<path d="M${x} 118 V142" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 118 V142" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/>`,d)).join("")+
 pt("head",72,86,`<path d="M92 92 Q92 66 72 64 Q50 64 48 84 Q50 102 72 104 Q90 102 92 92 Z" fill="${P.n}" ${SW}/>`+pt("ear",64,66,`<path d="M58 70 Q58 58 68 62 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",84,66,`<path d="M80 64 Q90 58 90 70 Z" fill="${P.n}" ${SW2}/>`,.3)+
  `${E2(64,80,3.4,"#5AA8C8",[-.3,0])}${E2(78,80,3.4,"#5AA8C8",[-.3,0])}<path d="M68 88 l3 3 l3 -3 Z" fill="#E87A8A" stroke="${FI}" stroke-width="1"/>`+pt("jaw",70,98,`<path d="M62 96 Q70 104 78 96 Z" fill="${FMOUTH}"/>`)+
  `<path d="M50 84 Q50 108 72 108 Q94 108 92 84" stroke="${FI}" stroke-width="9" fill="none"/><path d="M50 84 Q50 108 72 108 Q94 108 92 84" stroke="${P.ac}" stroke-width="6" fill="none"/><path d="M70 62 Q66 54 72 50 Q78 54 74 62" fill="${P.ac}" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="112" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Toothache Special"]="Bandaged-Jaw Snow Leopard";SM("Toothache Special","Open Wide","CUR","s",0,100,"tatk-1,tspd-1@40","Warm tray, open wide, and hold it there. Hold it. Nearly. Don't swallow.");
