/* =============== BATTLE FORMS, batch 5: the everyday alloys of the Mine, the Wreck, the Scrapyard and the Reactor ===============
   The common, real-world alloys every surveyor meets first. Same rig; each creature comes from what the metal does for a living. */

/* 91. Brass (copper-zinc: trumpets, door handles, shell casings). A rooster, every line of it, poured in brass. It has the shape:
   comb, wattle, hooked beak, a proud chest, sickle tail, scaly legs. But it is all liquid. Every part is one continuous pour, so the
   outline flows from neck to chest to tail without a seam; edges are rounded where surface tension pulls them; the comb is a row of beads,
   the wattle a hanging drop, the tail feathers streams that bead up at the tips. It moves like heavy liquid: a step sends a slosh through
   it, the head follows a beat late, the tail a beat later and overshoots, the comb and drips wobble last, then everything settles. Light
   streams along the tail feathers, reflections sit on the surface like on a spoon, and the core still glows. */
addForm("Brass",{n:"#C89A3A",a:"#FF8A2A",rn:"#8A90B8",rb:"#BCC4DC",ra:"#7AE8FF"},"slosh",(P,g)=>{
 const HI="#FFF6D8";
 /* the whole rooster is drawn three times with the same rig: ink (one merged outline), metal, then light and detail on top */
 const R=m=>{
  const S=(d,c)=>m===0?`<path d="${d}" fill="${FI}" stroke="${FI}" stroke-width="5.4" stroke-linejoin="round"/>`:m===1?`<path d="${d}" fill="${c||P.b}"/>`:"",
   C=(x,y,r,c)=>m===0?`<circle cx="${x}" cy="${y}" r="${r+2.7}" fill="${FI}"/>`:m===1?`<circle cx="${x}" cy="${y}" r="${r}" fill="${c||P.b}"/>`:"",
   F=s=>m===1?s:"",D=s=>m===2?s:"",
   L=(d,c,w,o,cls)=>D(`<path ${cls?`class="${cls}" `:""}d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" opacity="${o||1}"/>`),
   flow=d=>L(d,HI,2,.9,"flow")+"";
  return ""+
  /* the pool it stands in */
  S(`M66 146 Q66 137 90 137 Q110 135 128 138 Q150 139 148 146 Q142 153 106 153 Q70 153 66 146 Z`,P.d)+
  D(`<path d="M76 142 Q96 138 118 140" stroke="${HI}" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".7"/><ellipse class="p-glow" cx="108" cy="146" rx="14" ry="3" fill="${P.ac}" opacity=".75"/>`)+
  /* tail: three sickle streams that bead at the tips */
  pt("tail",140,98,
   S(`M136 100 Q142 62 166 44 Q176 38 182 44 Q178 52 172 58 Q156 74 150 104 Z`)+C(180,44,5.2)+
   S(`M140 104 Q160 74 184 70 Q194 70 193 79 Q184 82 178 84 Q162 92 152 110 Z`)+C(191,76,5)+
   S(`M140 110 Q164 102 182 108 Q190 112 187 120 Q178 118 170 118 Q158 116 146 118 Z`,P.d)+C(186,118,4.6,P.d)+
   L("M146 98 Q152 70 172 52",P.dd,2.4,.5)+flow("M146 98 Q152 70 172 52")+L("M150 104 Q166 86 184 76",P.dd,2.4,.5)+flow("M150 104 Q166 86 184 76")+flow("M150 112 Q168 108 182 112")+
   D(`<circle cx="178" cy="42" r="1.6" fill="${HI}"/><circle cx="189" cy="74" r="1.6" fill="${HI}"/>`)+
   pt("sway",191,81,S(`M188 80 Q187 88 189 91 Q191 94 194 91 Q195 87 194 80 Z`)+D(`<ellipse cx="190" cy="88" rx=".9" ry="1.8" fill="${HI}"/>`),.1)+
   D(`<g class="fall" style="transform-origin:191px 94px"><path d="M191 92 Q188 97 191 99 Q194 97 191 92 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.6"/></g>`))+
  /* back leg */
  pt("legB",118,112,S(`M114 110 Q111 126 115 140 L122 140 Q120 126 124 110 Z`,P.d)+C(119,142,5.6,P.d)+C(127,145,3.2,P.d)+C(111,145,3,P.d)+L("M117 118 Q116 130 118 138",P.l,1.6,.7)+L("M121 116 Q119 128 121 138",P.dd,1.4,.6),.5)+
  /* body: the chest pushed out proud, the belly sagging into a drop */
  S(`M78 100 Q76 78 104 74 Q134 72 146 94 Q150 108 138 116 Q124 124 106 122 Q86 122 78 110 Z`)+
  pt("sway",112,121,S(`M108 119 Q106 127 109 131 Q112 134 115 131 Q118 127 116 119 Z`)+D(`<ellipse cx="110.6" cy="128" rx=".9" ry="1.8" fill="${HI}"/>`),.3)+
  L("M84 108 Q100 119 132 111",P.d,6,.65)+L("M86 90 Q98 79 120 79",HI,3.6,.9)+D(`<circle cx="90" cy="94" r="2.2" fill="${HI}"/><path class="p-glow" d="M92 114 Q104 119 118 116" stroke="${P.ac}" stroke-width="3" fill="none" stroke-linecap="round" opacity=".6"/>`)+
  /* wing: a lobe whose edge has run into scallops */
  pt("wingF",112,94,S(`M100 92 Q118 82 136 88 Q148 94 145 106 Q141 114 131 112 Q128 118 120 116 Q113 120 107 114 Q100 108 100 100 Z`,P.b)+
   L("M106 106 Q120 108 140 102",P.d,2.4,.6)+L("M106 96 Q120 88 136 92",HI,2.4,.85)+flow("M110 100 Q124 98 140 98"))+
  /* front leg */
  pt("legF",100,112,S(`M96 110 Q93 126 96 140 L104 140 Q103 126 107 110 Z`)+C(100,142,6)+C(91,145,3.4)+C(109,145,3.2)+L("M98 118 Q97 130 99 138",HI,1.6,.8)+L("M103 116 Q101 128 103 138",P.d,1.6,.7)+L("M96 128 h6 M96 133 h6",P.d,1.2,.6))+
  /* neck and head, with the comb and wattle as beads and drops */
  pt("head",92,92,
   S(`M90 98 Q80 86 80 70 Q80 60 84 54 L100 54 Q98 66 100 76 Q104 88 106 98 Z`)+
   S(`M73 56 Q71 40 88 38 Q103 38 105 52 Q105 64 92 66 Q77 66 73 56 Z`)+
   pt("ear",90,41,C(80,36,5)+C(88,29.5,6)+C(97.5,30.5,5.4)+C(105,37,4.4)+D(`<circle cx="78.6" cy="34" r="1.4" fill="${HI}"/><circle cx="86.4" cy="27" r="1.7" fill="${HI}"/><circle cx="96" cy="28" r="1.5" fill="${HI}"/>`))+
   pt("sway",76,61,S(`M72 59 Q68 68 70 74 Q73 81 77 77 Q80 70 78 59 Z`)+D(`<ellipse cx="72.4" cy="71" rx="1" ry="2.2" fill="${HI}"/>`),.2)+
   F(`<path d="M74 51 L59 55.5 L74 60 Z" fill="${FMOUTH}"/>`)+
   pt("beak",74,57,S(`M74 56.5 Q64 57.5 59.5 60.5 Q66 62.5 74 60.5 Z`,P.d))+
   S(`M74.5 49.5 Q64 49.5 57.5 55 Q64 57 74.5 56 Z`)+
   L("M84 90 Q82 76 86 62",HI,3.4,.85)+L("M96 92 Q96 76 98 60",P.d,3,.5)+L("M78 48 Q83 41 93 41",HI,2.6,.9)+
   D(fE(88,50,4.8,{iris:"#3A2410",look:[-.4,0]})+`<path d="M62 54 Q66 52 72 52" stroke="${HI}" stroke-width="1.4" fill="none" stroke-linecap="round"/>`))+
  D(fG(g,1,`<path d="M44 122 L62 104" stroke="#5A4A3A" stroke-width="4" stroke-linecap="round"/><path d="M28 120 Q28 132 38 132 Q48 132 48 120 Z" fill="#6A6A72" stroke="${FI}" stroke-width="2"/><ellipse cx="38" cy="120" rx="10" ry="3" fill="${P.b}" stroke="${FI}" stroke-width="2"/><ellipse class="p-glow" cx="38" cy="120" rx="6" ry="1.6" fill="${P.ac}"/>`)+
   fG(g,2,`<circle cx="124" cy="104" r="3" fill="${HI}" stroke="${FI}" stroke-width="1.6"/>`))};
 return `<ellipse class="shd" cx="106" cy="149" rx="58" ry="6" fill="#000" opacity=".18"/>`+R(0)+R(1)+R(2)+fG(g,3,star(132,40,6))});
FORM_TITLE["Brass"]="Fanfare Rooster";

/* 92. Gilding Metal (copper with a little zinc: badges and enamel pins) — a puffin with an enamel-bright striped bill, stout and upright,
   a row of pins on its chest like badges earned. */
addForm("Gilding Metal",{n:"#2A2A34",a:"#F08A30",rn:"#E8E0D0",rb:"#3A7AC8",ra:"#E8412C"},"stand",(P,g)=>fShadow(40,104)+
 pt("tail",128,118,`<path d="M124 112 L140 126 L126 130 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M80 120 Q74 84 100 72 Q128 80 128 120 Q120 140 102 140 Q84 140 80 120 Z" fill="${P.n}" ${SW}/><path d="M86 122 Q84 96 98 88 Q112 100 110 136 Q92 138 86 122 Z" fill="#F4F0E4"/>`+
 [[94,106],[102,114],[94,122]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="3.6" fill="${[P.b,P.ac,"#3AA8A0"][i]}" ${SW2}/>`).join("")+
 pt("wingF",118,98,`<path d="M114 92 Q130 104 126 126 Q114 118 110 102 Z" fill="${P.n}" ${SW2}/>`)+
 fLeg("legF",94,138,6,4,P.ac,P.ac,0)+fLeg("legB",108,138,6,4,P.ac,P.ac,.5)+
 pt("head",100,80,`<path d="M84 78 Q82 58 100 56 Q118 58 118 78 Q112 90 100 90 Q86 90 84 78 Z" fill="${P.n}" ${SW}/><path d="M86 76 Q86 64 98 64 Q106 68 104 80 Z" fill="#F4F0E4"/>`+
  `<path d="M84 72 L70 74 L84 78 Z" fill="${FMOUTH}"/>`+pt("beak",84,78,`<path d="M84 78 L68 76 Q72 84 84 82 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M86 66 Q70 66 66 76 L84 74 Z" fill="${P.b}" ${SW2}/><path d="M76 68 L78 74 M72 70 L74 75" stroke="${P.ac}" stroke-width="2"/>${fE(94,70,4,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M90 68 l-4 -3" stroke="${P.ac}" stroke-width="1.6"/>`)+
 fG(g,1,`<circle cx="50" cy="90" r="4" fill="${P.b}" ${SW2}/><path d="M48 94 l-2 6 M52 94 l2 6" stroke="${P.ac}" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="102" cy="130" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,46,6)));
FORM_TITLE["Gilding Metal"]="Pinned Puffin";

/* 93. Red Brass (copper with zinc: plumbing fittings and valves) — a mudskipper hauled out on a pipe joint, goggle eyes on top, fin-arms
   propping it up, gulping, then flicking its tail and skipping. */
addForm("Red Brass",{n:"#8A7A5A",a:"#5FC8F0",rn:"#E8C8D8",rb:"#2E7A6A",ra:"#F2C94C"},"crawl",(P,g)=>`<rect x="90" y="134" width="96" height="14" rx="3" fill="${P.b}" ${SW}/><rect x="132" y="126" width="16" height="22" rx="2" fill="${P.d}" ${SW2}/><circle cx="140" cy="122" r="7" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="140" cy="122" r="7" fill="none" stroke="${P.ac}" stroke-width="3"/>`+fShadow(54,90)+
 pt("tail",136,118,`<path d="M132 114 Q156 104 176 108 Q170 120 176 132 Q156 132 132 124 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M44 116 Q46 92 82 92 Q124 94 140 116 Q130 132 84 134 Q48 132 44 116 Z" fill="${P.n}" ${SW}/>${[[70,104],[90,102],[110,106],[80,116],[100,118]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.ac}"/>`).join("")}`+
 pt("fin",96,94,`<path d="M80 94 Q100 76 124 96 Z" fill="${P.nd}" ${SW2}/>${[88,98,108].map(x=>`<path d="M${x} 94 l2 -10" stroke="${FI}" stroke-width="1"/>`).join("")}`)+
 pt("armF",72,124,`<path d="M72 122 Q60 132 56 144 L68 144 Q72 134 80 128 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",56,108,`<path d="M20 112 L48 114 L46 120 L24 118 Z" fill="${FMOUTH}"/>`+pt("jaw",48,118,`<path d="M48 118 Q34 128 20 118 Q34 124 48 122 Z" fill="${P.nl}" ${SW2}/>`)+
  `<path d="M18 110 Q20 98 40 96 L60 100 Q62 114 48 114 L18 112 Z" fill="${P.n}" ${SW}/>${fE(36,90,6.4,{iris:"#2A1A0A",look:[-.4,0]})}${fE(50,88,5.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M20 140 q6 -4 12 0" stroke="#7A5A3A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="94" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(84,70,6)));
FORM_TITLE["Red Brass"]="Valve Mudskipper";

/* 94. Tombac (copper-zinc that passes for gold leaf) — a golden pheasant, all show: a cape that fans round its face, a long barred tail,
   tottering and posing. */
addForm("Tombac",{n:"#E8412C",a:"#2E5AB0",rn:"#E8E4F4",rb:"#7A4AA8",ra:"#2FA060"},"stand",(P,g)=>fShadow(46,108)+
 pt("tail",128,104,`<path d="M124 100 Q170 94 196 122 L190 128 Q160 108 124 112 Z" fill="${P.b}" ${SW}/>${[140,152,164,176].map(x=>`<path d="M${x} ${102+(x-140)*.3} l-2 8" stroke="${FI}" stroke-width="2"/>`).join("")}`)+
 fLeg("legB",112,116,26,3.6,"#C8A060",null,.5,4)+
 `<path d="M80 104 Q82 80 108 80 Q134 84 136 106 Q128 122 108 122 Q84 120 80 104 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,94,`<path d="M98 92 Q130 84 140 106 Q120 112 102 106 Z" fill="${P.ac}" ${SW2}/><path d="M104 92 Q120 88 130 96" stroke="${P.b}" stroke-width="3" fill="none"/>`)+
 fLeg("legF",98,118,24,3.6,"#C8A060",null,0)+
 pt("head",90,86,`<path d="M92 92 Q78 82 84 66 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",88,72,`${[0,1,2,3,4].map(i=>`<path d="M88 72 L${100+i*4} ${76+i*6} L${104+i*4} ${70+i*6} Z" fill="${i%2?P.b:P.d}" ${SW2}/>`).join("")}`)+
  `<path d="M70 66 Q70 52 84 52 Q96 54 96 66 Q92 76 82 76 Q72 74 70 66 Z" fill="${P.n}" ${SW}/><path d="M70 60 Q76 40 96 48 Q90 54 80 54 Z" fill="${P.b}" ${SW2}/>`+
  `<path d="M70 66 L58 66 L70 70 Z" fill="${FMOUTH}"/>`+pt("beak",70,68,`<path d="M70 68 L58 67 L70 71 Z" fill="#E8C878" ${SW2}/>`)+`<path d="M70 62 L58 65.5 L70 66 Z" fill="#E8C878" ${SW2}/>${fE(80,62,4,{iris:"#E8A020",look:[-.4,0]})}`)+
 fG(g,1,`${star(40,40,3)}${star(30,60,2.4)}`)+
 fG(g,2,`<circle cx="108" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,58,6)));
FORM_TITLE["Tombac"]="Gilt Pheasant";

/* 95. Phosphor Bronze (copper-tin: springs and guitar strings) — a spider strumming its web like strings, eight jointed legs, fangs that
   open, hanging by a single wound string. */
addForm("Phosphor Bronze",{n:"#4A3A2A",a:"#F2C94C",rn:"#C8E0F0",rb:"#A03A8A",ra:"#3AC0A0"},"crawl",(P,g)=>`<g opacity=".7">${[0,1,2,3,4].map(i=>`<path d="M${20+i*40} 10 L${30+i*36} 146" stroke="${P.b}" stroke-width="${1.6-i*.15}"/>`).join("")}</g>`+fShadow(56)+
 `<path d="M100 10 L100 70" stroke="${P.ll}" stroke-width="1.4"/>`+
 [[112,98,1],[118,96,1],[124,96,1],[128,100,1],[88,100,-1],[84,98,-1],[80,98,-1],[78,104,-1]].map(([x,y,s],i)=>{const k=i%4;return pt(i<4?"legB":"legF",x,y,fOL(`M${x} ${y} L${x+s*(18+k*6)} ${y-20+k*4} L${x+s*(26+k*8)} 142`,i<4?P.nd:P.n,4),k*.2)}).join("")+
 `<path d="M104 102 Q106 72 136 72 Q164 76 162 102 Q156 124 132 124 Q108 122 104 102 Z" fill="${P.n}" ${SW}/>${[[124,86],[140,84],[150,96],[132,100],[146,110]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.ac}"/>`).join("")}<path d="M118 82 Q134 92 154 86" stroke="${P.b}" stroke-width="2" fill="none"/>`+
 pt("head",96,104,`<path d="M70 104 Q72 88 90 88 Q106 90 108 106 Q104 118 90 118 Q72 118 70 104 Z" fill="${P.n}" ${SW}/>${[[80,98,4],[88,96,3.4],[76,104,2.6],[94,98,2.6]].map(([x,y,r])=>fE(x,y,r,{iris:P.ac,look:[-.4,0]})).join("")}`+
  `<path d="M72 112 L84 114 L82 118 Z" fill="${FMOUTH}"/>`+pt("claw",80,114,`<path d="M80 114 Q70 120 72 128 Q76 124 82 120 Z" fill="${P.b}" ${SW2}/>`)+pt("claw2",86,116,`<path d="M86 116 Q80 124 84 130 Q86 124 90 120 Z" fill="${P.b}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 30 l6 6 M36 30 l-6 6" stroke="${P.ac}" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="134" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(134,56,6)));
FORM_TITLE["Phosphor Bronze"]="String Spider";

/* 96. Beryllium Copper (copper with a pinch of beryllium: springs and tools that never strike a spark) — a springbok pronking: back arched,
   legs locked straight, a fan of white hair raised along its back. */
addForm("Beryllium Copper",{n:"#C8884A",a:"#F4F0E4",rn:"#B8C8E8",rb:"#3A8A5A",ra:"#E8604A"},"hop",(P,g)=>fShadow(48,108)+
 pt("tail",150,92,`<path d="M148 90 Q160 92 160 104 L154 104 Q154 96 148 96 Z" fill="${P.ndd}" ${SW2}/>`)+
 fLeg("legB",142,102,40,5,P.n,P.ndd,.4,4)+fLeg("legB",104,104,38,5,P.nd,P.ndd,.4,-4)+
 `<path d="M88 100 Q90 76 120 76 Q150 78 154 98 Q148 114 120 114 Q92 114 88 100 Z" fill="${P.n}" ${SW}/><path d="M92 104 Q120 116 150 104" stroke="${P.ac}" stroke-width="6" fill="none"/><path d="M96 100 Q120 92 150 98" stroke="${P.ndd}" stroke-width="3" fill="none"/>`+
 pt("fin",122,78,`<path d="M106 80 Q122 60 140 80 Q122 74 106 80 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legF",132,106,38,5,P.n,P.ndd,.4,-2)+fLeg("legF",96,106,38,5,P.n,P.ndd,.4,2)+
 pt("head",96,88,fOL("M98 94 Q86 78 84 64",P.n,10)+
  `<path d="M58 62 L72 64 L70 68 L60 66 Z" fill="${FMOUTH}"/>`+pt("jaw",72,68,`<path d="M72 68 Q64 74 58 68 Q64 72 72 72 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M56 60 Q60 48 76 48 Q90 50 90 62 Q86 70 72 68 Q58 68 56 60 Z" fill="${P.ac}" ${SW}/><path d="M64 52 Q76 56 86 54" stroke="${P.ndd}" stroke-width="2.6" fill="none"/>${fE(74,56,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",80,48,`<path d="M80 48 Q74 30 84 22 Q82 30 86 34" stroke="${P.b}" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M80 44 l4 -2 M78 38 l4 -2" stroke="${FI}" stroke-width="1.4"/>`)+
  pt("ear",86,52,`<path d="M84 52 Q96 42 102 48 Q96 56 88 56 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M164 66 q-4 -6 0 -12" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,56,6)));
FORM_TITLE["Beryllium Copper"]="Pronking Springbok";

/* 97. Manganin (copper-manganese-nickel: precision resistors) — a caterpillar banded in a resistor's colour code, rippling forward, its
   little mouthparts nibbling. */
addForm("Manganin",{n:"#C8B890",a:"#E8412C",rn:"#3A3A4A",rb:"#5FE0A0",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(66)+
 `<path d="M20 148 L36 132 L52 148" stroke="#5AA84A" stroke-width="6" fill="none" stroke-linecap="round"/>`+
 [0,1,2,3,4,5,6].map(i=>{const x=158-i*16,c=["#8A5A2A",FI,P.ac,"#F28A30",P.b,"#2FA060",P.b][i];return pt(i%2?"legB":"legF",x,118,`<g><circle cx="${x}" cy="${116-Math.sin(i*.9)*3}" r="14" fill="${P.n}" ${SW}/><path d="M${x-3} ${103-Math.sin(i*.9)*3} Q${x+1} ${116} ${x-3} ${129-Math.sin(i*.9)*3}" stroke="${c}" stroke-width="5" fill="none"/><path d="M${x-4} 130 l-1 6 M${x+4} 130 l1 6" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/></g>`,i*.12)}).join("")+
 pt("head",50,114,`<circle cx="44" cy="110" r="16" fill="${P.n}" ${SW}/><path d="M34 100 Q44 94 54 100" stroke="${P.b}" stroke-width="3" fill="none"/>${fE(40,106,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",46,96,`<path d="M46 96 Q40 82 30 80" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="30" cy="80" r="2.4" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M28 114 L38 116 L36 120 Z" fill="${FMOUTH}"/>`+pt("jaw",38,118,`<path d="M38 118 L28 118 L32 124 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<ellipse cx="22" cy="132" rx="8" ry="4" fill="#5AA84A" ${SW2}/>`)+
 fG(g,2,`<circle cx="110" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,76,6)));
FORM_TITLE["Manganin"]="Colour-Code Caterpillar";

/* 98. Gunmetal (copper-tin-zinc: cannon barrels and pump parts) — an orca breaching broadside, a cannon-port row along its flank, tall dorsal
   fin, jaws open on a row of teeth. */
addForm("Gunmetal",{n:"#1E2230",a:"#F4F0E4",rn:"#E8D8C0",rb:"#7A3A3A",ra:"#3A6AB0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="62" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",160,96,`<path d="M156 94 Q172 92 180 76 Q192 74 192 84 Q186 92 178 96 Q188 102 190 112 Q180 116 174 106 Q168 100 156 102 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M36 100 Q40 68 100 64 Q152 66 164 98 Q150 126 100 128 Q44 126 36 100 Z" fill="${P.n}" ${SW}/><path d="M40 106 Q100 132 156 106 Q140 124 100 126 Q56 124 40 106 Z" fill="${P.ac}"/><path d="M120 76 Q138 78 146 92 Q128 88 118 82 Z" fill="${P.ac}" opacity=".9"/>`+
 [92,108,124].map(x=>`<circle cx="${x}" cy="96" r="4.4" fill="${P.b}" ${SW2}/><circle cx="${x}" cy="96" r="2" fill="${FI}"/>`).join("")+
 pt("fin",102,68,`<path d="M92 68 L104 26 L116 70 Z" fill="${P.n}" ${SW}/>`)+pt("fin",80,112,`<path d="M80 110 Q74 132 58 138 Q62 122 70 110 Z" fill="${P.n}" ${SW2}/>`,.5)+
 pt("head",48,96,`<path d="M36 100 L72 102 L70 108 L42 108 Z" fill="${FMOUTH}"/>${[44,52,60,68].map(x=>`<path d="M${x} 102 l2 4 l2 -4" fill="#FFFFFF"/>`).join("")}`+pt("jaw",72,106,`<path d="M72 106 Q54 120 38 106 Q54 114 72 110 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M34 98 Q54 102 72 100" stroke="${FI}" stroke-width="2.4" fill="none"/><ellipse cx="68" cy="86" rx="7" ry="4" fill="${P.ac}"/>${fE(62,90,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M26 70 q4 -6 0 -12 M34 66 q4 -6 0 -12" stroke="#8AB4D8" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="140" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,40,6)));
FORM_TITLE["Gunmetal"]="Broadside Orca";

/* 99. Bell Metal (copper with lots of tin: bells and gongs) — a moose, its throat-flap of a "bell" swinging, broad palmate antlers ringing
   like gongs, bellowing. */
addForm("Bell Metal",{n:"#5A3A2A",a:"#F2C94C",rn:"#D8D0E8",rb:"#2E7AA0",ra:"#E8604A"},"stand",(P,g)=>fShadow(66,112)+
 pt("tail",160,90,`<path d="M158 88 Q166 90 164 98 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",150,104,40,8,P.nd,P.ndd,.5)+fLeg("legB",108,104,40,8,P.nd,P.ndd,1.3)+
 `<path d="M88 96 Q86 66 118 64 Q154 66 162 92 Q156 114 124 114 Q92 114 88 96 Z" fill="${P.n}" ${SW}/><path d="M92 82 Q100 62 118 64 L108 90 Z" fill="${P.nd}"/>`+
 fLeg("legF",140,106,38,8,P.nl,P.ndd,0)+fLeg("legF",100,106,38,8,P.nl,P.ndd,.8)+
 pt("head",96,80,`<path d="M100 86 Q86 72 78 78 L74 96 Q90 100 100 94 Z" fill="${P.n}" ${SW}/>`+
  pt("sway",80,96,`<path d="M78 96 Q72 110 80 118 Q88 112 86 96 Z" fill="${P.b}" ${SW2}/><path d="M76 116 Q80 120 84 116" stroke="${P.ll}" stroke-width="2" fill="none"/>`)+
  `<path d="M42 84 L60 86 L58 90 L46 90 Z" fill="${FMOUTH}"/>`+pt("jaw",60,90,`<path d="M60 90 Q50 98 42 90 Q50 94 60 94 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M40 82 Q38 66 58 64 Q80 64 84 80 Q80 90 60 88 Q44 90 40 82 Z" fill="${P.n}" ${SW}/><ellipse cx="44" cy="78" rx="4" ry="3" fill="${FI}"/>${fE(68,72,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",76,64,`<path d="M76 64 Q72 40 52 30 Q50 40 56 42 Q48 46 56 50 Q52 56 62 58 Q66 46 76 64 Z" fill="${P.b}" ${SW}/><path d="M60 40 Q66 48 70 58" stroke="${P.ll}" stroke-width="2" fill="none"/>`)+
  pt("ant",82,64,`<path d="M82 64 Q90 38 112 30 Q114 40 108 42 Q116 46 108 50 Q112 56 100 58 Q94 50 82 64 Z" fill="${P.d}" ${SW}/>`,.5)+
  pt("ear",84,70,`<path d="M82 70 Q96 62 100 70 Q94 76 86 76 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 50 q-4 6 0 12 M28 46 q-4 8 0 18" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="124" cy="90" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(132,46,6)));
FORM_TITLE["Bell Metal"]="Gong Moose";

/* 100. Eutectic Solder (tin-lead that melts all at once: circuit boards) — an ant marching along a circuit trace, carrying a bead of solder,
   antennae tapping, mandibles that open and close. */
addForm("Eutectic Solder",{n:"#3A2A2A",a:"#2FA060",rn:"#E8D0B8",rb:"#B04A8A",ra:"#3A6AD8"},"crawl",(P,g)=>`<rect x="10" y="140" width="180" height="10" rx="2" fill="${P.ac}" opacity=".85" ${SW2}/><path d="M20 145 h40 l6 -3 h40 l6 3 h70" stroke="${P.b}" stroke-width="2" fill="none"/><circle cx="66" cy="142" r="3" fill="${P.b}" ${SW2}/>`+fShadow(56)+
 [[118,112],[132,112],[146,114]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+10} ${y+10} L${x+8} 140`,P.nd,2.6),i*.2)).join("")+
 `<ellipse cx="150" cy="100" rx="24" ry="17" fill="${P.n}" ${SW}/><path d="M136 92 Q150 86 166 94" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/><ellipse cx="116" cy="104" rx="11" ry="8" fill="${P.n}" ${SW}/>`+
 [[104,108],[112,110],[120,110]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-12} ${y+12} L${x-14} 140`,P.n,2.6),i*.2)).join("")+
 pt("head",100,98,`<circle cx="86" cy="94" r="14" fill="${P.n}" ${SW}/>${fE(82,90,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",84,82,`<path d="M84 82 L76 64 L60 60" stroke="${FI}" stroke-width="2.2" fill="none"/><circle cx="60" cy="60" r="2" fill="${P.b}"/>`)+pt("ant",90,82,`<path d="M90 82 L88 62 L74 52" stroke="${FI}" stroke-width="2.2" fill="none"/>`,.4)+
  `<circle cx="62" cy="104" r="7" fill="${P.b}" ${SW2}/><path d="M58 101 q3 -2 6 0" stroke="#FFFFFF" stroke-width="1.6" fill="none"/>`+
  pt("claw",74,100,`<path d="M74 100 Q64 96 60 98 Q66 100 70 104 Z" fill="${P.nd}" ${SW2}/>`)+pt("claw2",74,106,`<path d="M74 106 Q64 112 60 110 Q66 108 70 104 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 128 q4 -6 0 -12" stroke="#BFC5CB" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="150" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(130,66,6)));
FORM_TITLE["Eutectic Solder"]="Trace Ant";

/* 101. SAC305 (tin-silver-copper: the lead-free solder on modern boards) — a bumblebee with honeycomb-chip wings, fuzzy and busy, legs
   heavy with pollen like solder balls, stinger tail twitching. */
addForm("SAC305",{n:"#F2C94C",a:"#2A2A34",rn:"#9FE8D0",rb:"#7A4AA8",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="34" ry="4" fill="#000" opacity=".12"/>`+
 pt("wingB",104,76,`<path d="M104 76 Q118 34 146 36 Q148 62 110 82 Z" fill="#E8F4FC" opacity=".7" ${SW2}/>${[[122,52],[132,46],[128,60]].map(([x,y])=>`<path d="M${x-4} ${y} l2 -3.4 h4 l2 3.4 l-2 3.4 h-4 Z" fill="none" stroke="${P.b}" stroke-width="1.2"/>`).join("")}`)+
 pt("tail",136,98,`<path d="M134 92 L152 100 L134 106 Z" fill="${P.ac}" ${SW2}/>`)+
 `<ellipse cx="112" cy="98" rx="26" ry="20" fill="${P.n}" ${SW}/>${[100,114,128].map(x=>`<path d="M${x} 80 Q${x+5} 98 ${x} 116" stroke="${P.ac}" stroke-width="6" fill="none"/>`).join("")}`+
 [[96,114],[106,116],[116,116]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-4} ${y+12}`,P.ac,2.4)+(i==2?`<circle cx="${x-4}" cy="${y+14}" r="4" fill="${P.b}" ${SW2}/>`:""),i*.2)).join("")+
 pt("wingF",100,78,`<path d="M100 78 Q92 30 64 28 Q58 56 96 84 Z" fill="#E8F4FC" opacity=".8" ${SW2}/>${[[76,44],[86,40],[82,54],[72,56]].map(([x,y])=>`<path d="M${x-4} ${y} l2 -3.4 h4 l2 3.4 l-2 3.4 h-4 Z" fill="none" stroke="${P.b}" stroke-width="1.4"/>`).join("")}`)+
 pt("head",88,94,`<circle cx="78" cy="96" r="14" fill="${P.ac}" ${SW}/>${fE(74,92,4.6,{iris:P.n,look:[-.4,0]})}`+
  pt("ant",76,84,`<path d="M76 84 Q70 70 58 68" stroke="${FI}" stroke-width="2" fill="none"/>`)+pt("ant",82,84,`<path d="M82 84 Q80 70 70 62" stroke="${FI}" stroke-width="2" fill="none"/>`,.4)+
  `<path d="M64 102 L72 102 L70 106 Z" fill="${FMOUTH}"/>`+pt("jaw",70,104,`<path d="M70 104 L62 104 L66 110 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M40 120 q6 -6 12 0 q6 6 12 0" stroke="${P.n}" stroke-width="2" fill="none" stroke-dasharray="3 3"/>`)+
 fG(g,2,`<circle cx="112" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,60,6)));
FORM_TITLE["SAC305"]="Chipwing Bumblebee";

/* 102. Pewter (tin with antimony: tankards and little figurines) — an emperor penguin that looks cast for a mantelpiece, waddling, flippers
   slapping, bill opening to trumpet. */
addForm("Pewter",{n:"#2A2E3A",a:"#F2C94C",rn:"#E8E0D0",rb:"#4A8AB0",ra:"#E8604A"},"stand",(P,g)=>fShadow(40)+
 pt("tail",116,138,`<path d="M112 134 L128 144 L112 146 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M76 130 Q70 82 100 62 Q130 82 124 130 Q116 146 100 146 Q84 146 76 130 Z" fill="${P.n}" ${SW}/><path d="M84 130 Q80 92 98 76 Q116 96 112 140 Q92 144 84 130 Z" fill="#F4F0E4"/><path d="M88 84 Q96 94 108 86" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".8"/>`+
 `<path d="M86 102 Q94 108 106 104" stroke="${P.b}" stroke-width="2" fill="none" opacity=".6"/>`+
 pt("armF",118,92,`<path d="M116 88 Q132 108 128 128 Q118 122 112 100 Z" fill="${P.n}" ${SW2}/>`)+
 pt("legF",92,144,`<path d="M84 146 L98 146 L96 142 Z" fill="${P.ac}" ${SW2}/>`)+pt("legB",106,144,`<path d="M102 146 L114 146 L110 142 Z" fill="${P.ac}" ${SW2}/>`,.6)+
 pt("head",100,74,`<path d="M84 66 Q82 46 100 44 Q118 46 118 66 Q112 78 100 78 Q86 78 84 66 Z" fill="${P.n}" ${SW}/><path d="M108 62 Q116 64 114 76 Q108 72 106 66 Z" fill="${P.ac}"/>`+
  `<path d="M84 58 L64 64 L84 64 Z" fill="${FMOUTH}"/>`+pt("beak",84,64,`<path d="M84 64 L64 65 L84 68 Z" fill="${P.b}" ${SW2}/>`)+`<path d="M86 56 L62 63 L86 60 Z" fill="${P.d}" ${SW2}/>${fE(94,56,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<rect x="140" y="124" width="18" height="20" rx="3" fill="${P.b}" ${SW2}/><path d="M158 128 q8 6 0 12" stroke="${FI}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="98" cy="118" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,44,6)));
FORM_TITLE["Pewter"]="Mantelpiece Penguin";

/* 103. Britannia Metal (tin-antimony-copper: teapots and trophies) — a dormouse that lives in a teapot, peeking from under the lid, the lid
   lifting and dropping as it pops up and squeaks. */
addForm("Britannia Metal",{n:"#C8905A",a:"#F4F0E4",rn:"#B8B0D8",rb:"#2E7A6A",ra:"#E8604A"},"stand",(P,g)=>fShadow(54)+
 pt("tail",150,110,fOL("M146 112 Q172 104 176 82 Q178 70 168 72",P.n,7))+
 `<path d="M140 104 Q160 98 172 114 Q162 112 146 120 Z" fill="${P.b}" ${SW2}/><path d="M62 112 Q48 100 46 116 Q48 128 66 130" stroke="${FI}" stroke-width="9" fill="none"/><path d="M62 112 Q48 100 46 116 Q48 128 66 130" stroke="${P.b}" stroke-width="5" fill="none"/>`+
 `<path d="M60 100 Q60 140 100 144 Q140 140 140 100 Z" fill="${P.b}" ${SW}/><path d="M66 108 Q100 116 134 108" stroke="${P.ll}" stroke-width="3" fill="none"/><rect x="82" y="142" width="36" height="5" rx="2" fill="${P.d}" ${SW2}/>`+
 pt("head",100,96,`<path d="M74 92 Q74 66 100 64 Q126 66 126 92 Z" fill="${P.n}" ${SW}/><path d="M84 92 Q86 78 98 78 Q108 82 106 92 Z" fill="${P.ac}"/>`+
  `${fE(88,80,5.6,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}${fE(108,80,5,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}<circle cx="92" cy="90" r="2.4" fill="#F0A0A8" ${SW2}/>`+
  `<path d="M90 92 L98 92 L96 95 Z" fill="${FMOUTH}"/>`+pt("jaw",96,94,`<path d="M96 94 Q92 98 88 94 Q92 96 96 96 Z" fill="${P.ac}" ${SW2}/>`)+
  pt("ear",78,70,`<circle cx="76" cy="66" r="8" fill="${P.n}" ${SW2}/><circle cx="76" cy="66" r="4" fill="#F0A0A8"/>`)+pt("ear",122,70,`<circle cx="124" cy="66" r="8" fill="${P.n}" ${SW2}/><circle cx="124" cy="66" r="4" fill="#F0A0A8"/>`,.5)+
  pt("ear",130,62,`<path d="M68 62 Q72 40 100 40 Q128 40 132 62 Z" fill="${P.d}" ${SW}/><circle cx="100" cy="37" r="5" fill="${P.b}" ${SW2}/>`,1.2))+
 fG(g,1,`<path d="M40 70 q-6 -8 0 -16 M50 64 q-4 -8 2 -14" stroke="#BFC5CB" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="100" cy="126" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(150,56,6)));
FORM_TITLE["Britannia Metal"]="Teapot Dormouse";

/* 104. Babbitt Metal (tin-antimony-copper: the soft lining of engine bearings) — a three-banded armadillo, its banded shell running like a
   bearing race, trotting on tiptoe, snout snuffling. */
addForm("Babbitt Metal",{n:"#C8A890",a:"#F0A0A8",rn:"#3A3A5A",rb:"#C87A3A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(56)+
 pt("tail",146,118,`<path d="M144 112 L174 128 L170 132 L142 122 Z" fill="${P.b}" ${SW2}/>${[152,160,168].map(x=>`<path d="M${x} ${116+(x-152)*.5} l-2 6" stroke="${FI}" stroke-width="1.4"/>`).join("")}`)+
 fLeg("legB",132,120,22,7,P.nd,P.ndd,.4)+fLeg("legB",92,120,22,7,P.nd,P.ndd,.9)+
 `<path d="M66 118 Q66 76 106 74 Q146 76 150 118 Z" fill="${P.b}" ${SW}/>`+
 [86,98,110,122].map(x=>`<path d="M${x} ${78+Math.abs(x-104)*.2} Q${x+4} 100 ${x} 118" stroke="${P.dd}" stroke-width="2.4" fill="none"/>${[0,1,2,3].map(k=>`<circle cx="${x+6}" cy="${86+k*8}" r="1.6" fill="${P.ll}"/>`).join("")}`).join("")+
 `<path d="M66 118 Q106 126 150 118" stroke="${FI}" stroke-width="3" fill="none"/>`+
 fLeg("legF",124,122,20,7,P.n,P.ndd,0)+fLeg("legF",82,122,20,7,P.n,P.ndd,.5)+
 pt("head",70,106,`<path d="M74 98 Q60 92 52 100 L28 112 Q24 116 30 116 L54 116 Q70 116 76 110 Z" fill="${P.n}" ${SW}/><path d="M52 98 Q64 86 76 94 L74 104 Z" fill="${P.b}" ${SW2}/>`+
  `<path d="M28 114 L40 114 L38 118 Z" fill="${FMOUTH}"/>`+pt("jaw",40,117,`<path d="M40 117 L28 116 L32 120 Z" fill="${P.nd}" ${SW2}/>`)+`<ellipse cx="26" cy="113" rx="2.6" ry="2" fill="${P.ac}" ${SW2}/>`+
  `${fE(54,104,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",66,94,`<path d="M64 94 Q66 82 74 86 Q72 94 68 98 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="140" r="5" fill="none" stroke="${P.b}" stroke-width="2.4"/><circle cx="30" cy="140" r="2" fill="${P.b}"/>`)+
 fG(g,2,`<circle cx="106" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(106,56,6)));
FORM_TITLE["Babbitt Metal"]="Bearing-Race Armadillo";

/* 105. Type Metal (lead-antimony-tin: movable type for printing presses) — a cuttlefish that squirts printer's ink, its skin rippling with
   rows of tiny letters, frilled fin undulating, tentacles reaching out to grab. */
addForm("Type Metal",{n:"#E8D8C0",a:"#1E2238",rn:"#3A2A4A",rb:"#B03A3A",ra:"#F4F0E4"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="54" ry="4" fill="#000" opacity=".12"/>`+
 `<path d="M150 90 Q176 80 186 92 Q176 104 152 102 Z" fill="${P.ac}" opacity=".6"/><circle cx="182" cy="82" r="4" fill="${P.ac}" opacity=".5"/><circle cx="190" cy="100" r="3" fill="${P.ac}" opacity=".4"/>`+
 pt("fin",104,70,`<path d="M66 82 Q70 66 104 66 Q140 66 152 82 Q138 72 104 72 Q76 72 66 82 Z" fill="${P.nl}" ${SW2}/>`)+pt("fin",104,118,`<path d="M66 106 Q72 122 104 124 Q140 124 152 108 Q138 118 104 118 Q76 118 66 106 Z" fill="${P.nl}" ${SW2}/>`,.5)+
 `<path d="M60 94 Q62 72 104 70 Q146 72 156 94 Q146 118 104 120 Q64 118 60 94 Z" fill="${P.n}" ${SW}/>`+
 [80,90,100].map((y,r)=>Array.from({length:10},(_,i)=>`<rect x="${84+i*6.2}" y="${y-6+((i*7+r*3)%3)}" width="${3+((i+r)%3)}" height="${4+((i*5+r)%3)}" rx=".6" fill="${P.ac}" opacity=".55"/>`).join("")).join("")+
 [0,1,2,3].map(i=>pt("sway",62,92+i*3,fOL(`M62 ${90+i*4} Q${44-i*2} ${92+i*6} ${30+i*3} ${88+i*10}`,P.nd,4),i*.25)).join("")+
 pt("claw",60,98,fOL("M60 98 Q40 110 18 106",P.nd,3)+`<ellipse cx="16" cy="106" rx="5" ry="3" fill="${P.nd}" ${SW2}/>`)+
 pt("head",70,92,`${fE(76,86,6.4,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M70 80 Q78 76 84 82" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
  `<path d="M58 96 L66 96 L64 100 Z" fill="${FMOUTH}"/>`+pt("beak",64,98,`<path d="M64 98 L56 98 L60 104 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<rect x="160" y="124" width="10" height="12" rx="1.4" fill="${P.b}" ${SW2}/><path d="M163 134 v-8 h3 q3 0 3 2.5 q0 2.5 -3 2.5 h-3 M166 131 l3 3" stroke="${FI}" stroke-width="1.4" fill="none"/>`)+
 fG(g,2,`<circle cx="130" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,50,6)));
FORM_TITLE["Type Metal"]="Ink Cuttlefish";

/* 106. Terne (lead-tin: old roofing sheet and fuel tanks) — a herring gull up on a tin roof, wings half open, yellow bill with its red spot
   wide in a raucous call. */
addForm("Terne",{n:"#F4F0E4",a:"#E8412C",rn:"#3A3A4A",rb:"#B07A3A",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M14 150 L80 128 L190 128 L190 150 Z" fill="${P.b}" ${SW}/>${[40,60,90,120,150,180].map(x=>`<path d="M${x} ${x<80?150-(x-14)*.33:128} L${x} 150" stroke="${P.dd}" stroke-width="2"/>`).join("")}`+
 pt("tail",138,110,`<path d="M134 104 L162 112 L156 120 L132 114 Z" fill="${FI}" ${SW2}/>`)+
 fLeg("legB",112,120,8,3,"#F0A0A8",null,.4)+
 `<path d="M84 110 Q84 86 110 84 Q136 88 140 110 Q132 124 110 124 Q88 124 84 110 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,96,`<path d="M100 92 Q140 74 168 96 Q140 112 104 108 Z" fill="#9AA0AA" ${SW}/><path d="M146 90 L168 96 L152 104 Z" fill="${FI}"/><circle cx="160" cy="96" r="1.6" fill="#FFFFFF"/>`)+
 fLeg("legF",100,120,8,3,"#F0A0A8",null,0)+
 pt("head",90,92,`<path d="M74 86 Q72 66 90 64 Q106 66 106 84 Q102 96 90 96 Q76 96 74 86 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M74 78 L50 82 L74 84 Z" fill="${FMOUTH}"/>`+pt("beak",74,84,`<path d="M74 84 L52 83 Q56 88 74 88 Z" fill="#F2C94C" ${SW2}/><circle cx="58" cy="86" r="1.8" fill="${P.ac}"/>`)+`<path d="M76 76 L50 81 Q48 84 52 82 L76 80 Z" fill="#F2C94C" ${SW2}/>${fE(86,74,4,{iris:"#F2C94C",look:[-.4,0],lid:.2,lidC:P.n})}`)+
 fG(g,1,`<path d="M30 60 q8 -8 16 0 M150 40 q6 -6 12 0" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="112" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,58,6)));
FORM_TITLE["Terne"]="Tin-Roof Gull";

/* 107. Hard Lead (lead stiffened with antimony: battery grids and fishing weights) — a walrus, as heavy as it looks, hauling itself along on
   its flippers, tusks hooked down, whiskered lip lifting to roar. */
addForm("Hard Lead",{n:"#B08A70",a:"#F4F0E4",rn:"#A8C0D8",rb:"#2E5A4A",ra:"#E8604A"},"slink",(P,g)=>fShadow(74)+
 pt("tail",160,128,`<path d="M156 124 L184 116 L180 132 L188 144 L156 136 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M48 116 Q46 76 98 74 Q150 76 164 126 Q156 144 100 144 Q52 144 48 116 Z" fill="${P.n}" ${SW}/>${[[80,92],[100,86],[120,94],[136,108],[92,110],[114,118]].map(([x,y])=>`<path d="M${x} ${y} q6 -2 10 2" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 `<path d="M100 128 L100 142 M112 126 L112 142" stroke="${P.b}" stroke-width="5"/><rect x="94" y="120" width="24" height="8" rx="2" fill="${P.b}" ${SW2}/>`+
 pt("fin",78,128,`<path d="M78 124 Q64 138 54 146 Q70 148 86 136 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",60,96,`<path d="M22 96 Q22 70 50 68 Q76 70 78 94 Q74 112 50 112 Q26 112 22 96 Z" fill="${P.n}" ${SW}/>${fE(48,82,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  `<path d="M28 104 L52 104 L50 110 L32 110 Z" fill="${FMOUTH}"/>`+pt("jaw",52,108,`<path d="M52 108 Q40 116 28 108 Q40 112 52 112 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ear",40,98,`<path d="M22 96 Q30 88 42 92 Q52 88 58 96 Q50 104 40 102 Q30 104 22 96 Z" fill="${P.nl}" ${SW2}/>${[[26,96],[32,94],[30,99],[46,94],[52,97]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1" fill="${FI}"/>`).join("")}<path d="M26 96 l-10 -4 M26 98 l-10 2" stroke="${FI}" stroke-width="1"/>`)+
  `<path d="M32 100 Q30 120 36 132 L40 130 Q36 116 38 100 Z" fill="${P.ac}" ${SW2}/><path d="M46 100 Q46 120 52 132 L56 130 Q52 116 52 100 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M170 96 l4 -10 l4 10 Z" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="106" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,56,6)));
FORM_TITLE["Hard Lead"]="Ballast Walrus";

/* 108. Bronze (copper-tin: statues, bells and ship propellers) — a warhorse rearing like a statue come to life, mane and tail streaming,
   forelegs pawing the air, lips drawn back in a whinny. */
addForm("Bronze",{n:"#7A4A2A",a:"#3AA88A",rn:"#E8E4F0",rb:"#3A5AB0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(52,118)+
 pt("tail",150,92,`<path d="M148 88 Q176 88 182 112 Q184 126 176 136 Q170 120 160 112 Q156 104 146 100 Z" fill="${P.b}" ${SW}/><path d="M156 96 Q170 104 174 124" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`)+
 pt("legB",142,104,fOL("M142 104 L150 124 L146 144",P.nd,9)+`<path d="M140 144 h12" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,.0)+
 pt("legB",120,108,fOL("M120 108 L126 126 L120 144",P.nd,9)+`<path d="M114 144 h12" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,.5)+
 `<path d="M94 88 Q98 64 128 70 Q156 76 154 98 Q146 116 122 114 Q96 110 94 88 Z" fill="${P.n}" ${SW}/><path d="M106 76 Q128 72 146 82" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("armF",100,92,fOL("M100 92 L80 92 L74 106",P.n,9)+`<path d="M70 106 l8 2" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 pt("armB",106,96,fOL("M106 96 L90 104 L88 120",P.nd,9),.4)+
 pt("head",100,80,fOL("M104 84 Q90 66 90 48",P.n,16)+`<path d="M98 46 Q112 54 112 74 Q106 84 100 86 Q108 66 94 52 Z" fill="${P.b}" ${SW2}/>`+
  `<path d="M58 44 L74 48 L72 52 L60 50 Z" fill="${FMOUTH}"/>`+pt("jaw",74,52,`<path d="M74 52 Q64 60 56 50 Q64 56 74 56 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M56 46 Q54 34 70 30 Q90 26 96 40 Q96 52 76 52 Q60 52 56 46 Z" fill="${P.n}" ${SW}/><ellipse cx="60" cy="42" rx="2.4" ry="1.8" fill="${FI}"/>${fE(80,38,4.2,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",88,30,`<path d="M86 32 L88 18 L94 30 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<rect x="96" y="144" width="56" height="5" rx="1" fill="#8A8A8A" ${SW2}/>`)+
 fG(g,2,`<circle cx="128" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(128,46,6)));
FORM_TITLE["Bronze"]="Statue Warhorse";

/* 109. Muntz Metal (copper-zinc: the sheathing on wooden ships' hulls) — a remora clinging under a hull plank by the sucker on its head,
   letting go to snap at scraps, then sticking fast again. */
addForm("Muntz Metal",{n:"#8A8070",a:"#E8E4DA",rn:"#B8D8F0",rb:"#7A3AA8",ra:"#F2C94C"},"swim",(P,g)=>`<rect x="10" y="30" width="180" height="20" fill="#6A4A2A" ${SW}/><rect x="10" y="44" width="180" height="10" fill="${P.b}" ${SW2}/>${[30,60,90,120,150,180].map(x=>`<circle cx="${x}" cy="49" r="1.8" fill="${P.dd}"/>`).join("")}<ellipse class="shd" cx="104" cy="150" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",158,80,`<path d="M154 76 L182 64 L176 80 L182 96 L154 84 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M38 74 Q42 58 96 58 Q146 60 160 80 Q146 98 96 98 Q46 96 38 74 Z" fill="${P.n}" ${SW}/><path d="M48 84 Q96 100 150 84" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".7"/><path d="M60 72 Q100 66 150 78" stroke="${P.nd}" stroke-width="3" fill="none"/>`+
 pt("fin",116,64,`<path d="M100 62 Q126 52 146 70 Q124 66 104 66 Z" fill="${P.nd}" ${SW2}/>`)+pt("fin",112,94,`<path d="M100 94 Q124 106 146 90 Q124 98 104 96 Z" fill="${P.nd}" ${SW2}/>`,.5)+
 pt("head",54,74,`<ellipse cx="66" cy="58" rx="24" ry="6" fill="${P.nl}" ${SW2}/>${[50,56,62,68,74,80].map(x=>`<path d="M${x} 54 v8" stroke="${P.nd}" stroke-width="1.4"/>`).join("")}`+
  `<path d="M30 74 L54 72 L52 78 L34 78 Z" fill="${FMOUTH}"/>`+pt("jaw",54,78,`<path d="M54 78 Q40 90 28 78 Q40 84 54 82 Z" fill="${P.nd}" ${SW2}/>`)+`${fE(58,68,4.2,{iris:P.ac,look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="30" cy="110" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="78" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,120,6)));
FORM_TITLE["Muntz Metal"]="Hull Remora";

/* 110. Naval Brass (copper-zinc-tin: propeller shafts) — a duck paddling hard, feet going like a propeller beneath the waterline, tail
   waggling, bill wide in a quack. */
addForm("Naval Brass",{n:"#6A5A4A",a:"#2FA060",rn:"#E8E4DA",rb:"#3A6AB0",ra:"#E8604A"},"swim",(P,g)=>`<path d="M10 116 Q50 110 100 116 Q150 122 190 114 L190 160 L10 160 Z" fill="#8AB4D8" opacity=".35"/><path d="M10 116 Q50 110 100 116 Q150 122 190 114" stroke="#5A8AB8" stroke-width="2.4" fill="none"/>`+
 pt("spin",120,134,`${[0,1,2].map(i=>`<ellipse cx="120" cy="126" rx="3.4" ry="8" fill="${P.b}" ${SW2} transform="rotate(${i*120} 120 134)"/>`).join("")}<circle cx="120" cy="134" r="3" fill="${P.d}" ${SW2}/>`)+
 pt("tail",144,100,`<path d="M140 96 L162 88 L160 102 L142 108 Z" fill="${P.nd}" ${SW2}/><path d="M152 90 q4 -6 8 -2" stroke="${FI}" stroke-width="2" fill="none"/>`)+
 `<path d="M74 106 Q76 86 108 84 Q144 86 150 106 Q140 122 108 122 Q80 122 74 106 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,96,`<path d="M100 94 Q134 88 146 104 Q126 112 104 108 Z" fill="${P.nd}" ${SW2}/><path d="M118 100 h16" stroke="${P.b}" stroke-width="4"/>`)+
 pt("head",86,90,fOL("M88 96 Q80 82 82 70",P.ac,9)+`<path d="M86 84 h-10" stroke="#FFFFFF" stroke-width="3"/>`+
  `<path d="M70 66 Q70 52 84 52 Q98 54 96 68 Q92 78 82 78 Q72 76 70 66 Z" fill="${P.ac}" ${SW}/>`+
  `<path d="M70 66 L52 64 L70 70 Z" fill="${FMOUTH}"/>`+pt("beak",70,69,`<path d="M70 69 L52 68 Q54 74 70 73 Z" fill="#F2C94C" ${SW2}/>`)+`<path d="M72 62 L50 64 Q50 67 54 67 L72 66 Z" fill="#F2C94C" ${SW2}/>${fE(82,62,4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="60" cy="128" r="3" fill="none" stroke="#FFFFFF" stroke-width="1.6"/><circle cx="50" cy="136" r="2" fill="none" stroke="#FFFFFF" stroke-width="1.4"/>`)+
 fG(g,2,`<circle cx="110" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,58,6)));
FORM_TITLE["Naval Brass"]="Propeller Duck";

/* 111. Admiralty Brass (copper-zinc-tin: condenser tubes and heat exchangers) — a giant tubeworm living in a bundle of condenser tubes, red
   plumes fanning out and snapping back in. */
addForm("Admiralty Brass",{n:"#E8412C",a:"#F4F0E4",rn:"#5FE0F0",rb:"#4A4A5A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46)+
 `<ellipse cx="100" cy="146" rx="46" ry="6" fill="#5A5A62" ${SW2}/>`+
 [[70,74,.3],[130,84,.7]].map(([x,top,d])=>`<rect x="${x-9}" y="${top}" width="18" height="${146-top}" rx="3" fill="${P.d}" ${SW}/><ellipse cx="${x}" cy="${top}" rx="9" ry="3" fill="#2A1A10" ${SW2}/>`+pt("ear",x,top,[0,1,2,3,4].map(i=>`<path d="M${x} ${top} Q${x-14+i*7} ${top-18} ${x-12+i*6} ${top-30}" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join(""),d)).join("")+
 `<rect x="88" y="54" width="24" height="92" rx="4" fill="${P.b}" ${SW}/><path d="M94 60 v80" stroke="${P.ll}" stroke-width="3"/><ellipse cx="100" cy="54" rx="12" ry="4" fill="#2A1A10" ${SW2}/>`+
 pt("head",100,54,`<path d="M88 54 Q86 26 100 20 Q114 26 112 54 Z" fill="${P.b}" ${SW}/>${[0,1,2,3,4,5,6].map(i=>{const a=(-60+i*20)*Math.PI/180;return`<path d="M100 40 Q${100+Math.sin(a)*20} ${40-Math.cos(a)*14} ${100+Math.sin(a)*30} ${40-Math.cos(a)*30}" stroke="${FI}" stroke-width="7.4" fill="none" stroke-linecap="round"/><path d="M100 40 Q${100+Math.sin(a)*20} ${40-Math.cos(a)*14} ${100+Math.sin(a)*30} ${40-Math.cos(a)*30}" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/>`}).join("")}`+
  `${fE(94,40,3.6,{iris:"#2A1A0A",look:[-.4,0]})}${fE(106,40,3.6,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M95 48 L105 48 L103 51 L97 51 Z" fill="${FMOUTH}"/>`+pt("jaw",103,50,`<path d="M103 50 Q100 54 97 50 Q100 52 103 52 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<circle cx="40" cy="120" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/><circle cx="34" cy="108" r="2" fill="none" stroke="#8AB4D8" stroke-width="1.4"/>`)+
 fG(g,2,`<circle cx="100" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(148,40,6)));
FORM_TITLE["Admiralty Brass"]="Condenser Tubeworm";

/* 112. Aluminium Bronze (copper-aluminium: marine propellers) — an ocean sunfish, a great round disc of a fish with fins top and bottom
   sculling it along like propeller blades, small round mouth gulping. */
addForm("Aluminium Bronze",{n:"#9AA8B8",a:"#F2C94C",rn:"#E8C8A0",rb:"#3A7A5A",ra:"#E8604A"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="44" ry="4" fill="#000" opacity=".14"/>`+
 pt("fin",116,52,`<path d="M104 54 Q114 14 132 10 Q130 34 128 56 Z" fill="${P.b}" ${SW}/>`)+pt("fin",116,136,`<path d="M104 134 Q112 152 130 156 Q130 144 128 132 Z" fill="${P.b}" ${SW}/>`,.8)+
 `<path d="M50 94 Q52 50 104 48 Q148 52 152 94 Q148 138 104 140 Q54 138 50 94 Z" fill="${P.n}" ${SW}/>`+
 pt("tail",150,94,`<path d="M148 60 Q164 72 166 94 Q164 116 148 128 Q156 94 148 60 Z" fill="${P.nd}" ${SW}/>${[72,84,96,108,120].map(y=>`<circle cx="${158}" cy="${y}" r="2" fill="${P.ac}"/>`).join("")}`)+
 `<path d="M66 70 Q100 56 136 72" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".7"/>${[[90,90],[110,84],[120,104],[96,112],[132,92]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.6" fill="${P.nd}" opacity=".4"/>`).join("")}`+
 pt("fin",92,104,`<path d="M90 100 Q100 110 96 122 Q86 114 84 104 Z" fill="${P.nd}" ${SW2}/>`,.3)+
 pt("head",64,94,`${fE(72,82,6.4,{iris:"#2A1A0A",look:[-.4,0]})}<circle cx="52" cy="96" r="5" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",56,100,`<path d="M56 100 Q50 104 46 98 Q52 100 56 98 Z" fill="${P.nl}" ${SW2}/>`))+
 fG(g,1,`<circle cx="32" cy="70" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="110" cy="96" r="4" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(70,40,6)));
FORM_TITLE["Aluminium Bronze"]="Sculling Sunfish";

/* 113. Cupronickel (copper-nickel: coins and seawater pipes) — a starfish clambering over a pile of coins, arms curling one after another,
   a little mouth in the middle. */
addForm("Cupronickel",{n:"#E8804A",a:"#F4E0C0",rn:"#9AD0E8",rb:"#A03A6A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60)+
 [[60,142],[78,144],[140,142],[154,144],[124,146]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="10" ry="3.4" fill="${P.b}" ${SW2}/>`).join("")+
 [0,1,2,3,4].map(i=>{const a=(-90+i*72)*Math.PI/180,ex=100+Math.cos(a)*54,ey=96+Math.sin(a)*46;return pt(["armF","legF","legB","armB","tail"][i],100,96,`<path d="M100 96 L${100+Math.cos(a-.3)*18} ${96+Math.sin(a-.3)*18} Q${ex} ${ey} ${ex} ${ey} L${100+Math.cos(a+.3)*18} ${96+Math.sin(a+.3)*18} Z" fill="${P.n}" stroke="${FI}" stroke-width="3" stroke-linejoin="round"/>${[.35,.55,.75].map(t=>`<circle cx="${100+Math.cos(a)*54*t}" cy="${96+Math.sin(a)*46*t}" r="2.2" fill="${P.ac}"/>`).join("")}`,i*.3)}).join("")+
 `<circle cx="100" cy="96" r="20" fill="${P.n}" ${SW}/>`+
 pt("head",100,96,`${fE(92,90,4.4,{iris:"#2A1A0A",look:[-.4,0]})}${fE(108,90,4.4,{iris:"#2A1A0A",look:[-.4,0]})}<circle cx="100" cy="102" r="3.4" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",100,104,`<path d="M96 104 Q100 110 104 104 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<ellipse cx="40" cy="146" rx="9" ry="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="100" cy="80" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(160,40,6)));
FORM_TITLE["Cupronickel"]="Coinpile Starfish";

/* 114. Nickel Silver (copper-nickel-zinc: keys, zippers and flutes) — an elephant shrew, its long twitching nose fluting about, big ears,
   hopping on stilt-like hind legs, a key-shaped tail tuft. */
addForm("Nickel Silver",{n:"#C89A6A",a:"#F4F0E4",rn:"#B0B8E0",rb:"#2E7A6A",ra:"#E8604A"},"hop",(P,g)=>fShadow(46,106)+
 pt("tail",136,112,fOL("M136 112 Q164 116 178 108",P.nd,3)+`<circle cx="182" cy="106" r="5" fill="none" stroke="${FI}" stroke-width="3.6"/><circle cx="182" cy="106" r="5" fill="none" stroke="${P.b}" stroke-width="2"/>`)+
 pt("legB",126,116,fOL("M122 108 Q140 120 130 134 L122 144",P.nd,7)+`<path d="M116 144 h12" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 `<path d="M80 116 Q78 92 104 88 Q132 88 138 114 Q132 130 106 130 Q84 130 80 116 Z" fill="${P.n}" ${SW}/><path d="M86 122 Q104 132 128 124" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 fLeg("legF",92,124,18,4,P.n,null,0)+
 pt("head",86,100,`<path d="M62 96 Q64 80 82 80 Q98 82 98 98 Q94 108 80 108 Q66 108 62 96 Z" fill="${P.n}" ${SW}/>`+
  pt("sway",64,96,fOL("M64 96 Q46 92 30 98",P.n,6)+`<circle cx="30" cy="98" r="3.4" fill="${P.d}" ${SW2}/>${[54,46,38].map(x=>`<circle cx="${x}" cy="${96-(54-x)*.1}" r="1.2" fill="${P.b}"/>`).join("")}`)+
  `<path d="M58 102 L70 104 L68 106 Z" fill="${FMOUTH}"/>`+pt("jaw",68,106,`<path d="M68 106 L58 104 L62 108 Z" fill="${P.nd}" ${SW2}/>`)+
  `<ellipse cx="80" cy="90" rx="7.6" ry="6" fill="${P.ac}"/>${fE(80,90,4.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",90,82,`<path d="M88 82 Q86 62 98 62 Q104 72 96 86 Z" fill="${P.n}" ${SW2}/><path d="M92 80 Q92 70 97 68" stroke="#F0A0A8" stroke-width="3" fill="none"/>`))+
 fG(g,1,`<path d="M20 80 q4 -4 8 0 q4 4 8 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="108" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,64,6)));
FORM_TITLE["Nickel Silver"]="Flute-Nose Shrew";

/* 115. Constantan (copper-nickel whose resistance hardly changes: strain gauges) — a spider monkey stretched between two branches, long
   arms and tail reaching, swinging, hooting with an open mouth. */
addForm("Constantan",{n:"#3A2A24",a:"#E8C8A0",rn:"#E8D8F0",rb:"#C88A3A",ra:"#3A8AC8"},"perch",(P,g)=>`<path d="M10 40 L70 34" stroke="#6A4A2A" stroke-width="7" stroke-linecap="round"/><path d="M130 30 L190 38" stroke="#6A4A2A" stroke-width="7" stroke-linecap="round"/><ellipse cx="100" cy="150" rx="30" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",120,96,fOL("M120 96 Q164 96 170 60 Q172 44 166 38",P.n,4)+`<path d="M166 38 q-6 -4 -4 -8" stroke="${FI}" stroke-width="3" fill="none"/>`)+
 pt("armB",112,74,fOL("M112 74 Q140 54 156 36",P.nd,5))+
 pt("legB",112,104,fOL("M112 104 Q124 122 116 140",P.nd,5),.6)+
 `<path d="M86 96 Q84 74 102 70 Q120 72 120 96 Q118 112 104 114 Q88 112 86 96 Z" fill="${P.n}" ${SW}/><path d="M94 104 Q96 88 104 84 Q112 92 110 108 Z" fill="${P.ac}" opacity=".6"/>`+
 pt("legF",96,108,fOL("M96 108 Q86 126 92 142",P.n,5))+
 pt("armF",92,76,fOL("M92 76 Q70 58 54 38",P.n,5)+`<path d="M52 38 q-2 -6 4 -6" stroke="${FI}" stroke-width="2.4" fill="none"/>`,.3)+
 pt("head",100,70,`<circle cx="98" cy="58" r="15" fill="${P.n}" ${SW}/><path d="M86 60 Q88 48 98 50 Q108 48 110 60 Q108 72 98 72 Q88 72 86 60 Z" fill="${P.ac}"/>`+
  `${fE(93,58,3.8,{iris:"#2A1A0A",look:[-.4,0]})}${fE(103,58,3.8,{iris:"#2A1A0A",look:[-.4,0]})}`+
  `<path d="M94 66 L102 66 L100 68 L96 68 Z" fill="${FMOUTH}"/>`+pt("jaw",100,68,`<path d="M101 68 Q98 74 95 68 Q98 70 101 70 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ear",84,56,`<circle cx="83" cy="56" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M70 40 L130 30" stroke="${P.b}" stroke-width="1.6" stroke-dasharray="3 3"/>`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(70,92,6)));
FORM_TITLE["Constantan"]="Strain Spider Monkey";

/* 116. Nordic Gold (copper-aluminium-zinc-tin: euro cent coins) — a lynx in a golden winter coat, ear tufts flicking, huge snowshoe paws,
   a stubby tail, a hiss with ears flattened. */
addForm("Nordic Gold",{n:"#C8A060",a:"#2A2A34",rn:"#B8C8E8",rb:"#7A3A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(58,108)+
 pt("tail",150,92,`<path d="M148 88 Q160 82 162 92 Q156 98 150 96 Z" fill="${P.nd}" ${SW2}/><path d="M158 86 Q164 88 162 94" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 fLeg("legB",138,108,30,11,P.nd,P.nd,.5)+fLeg("legB",100,108,30,11,P.nd,P.nd,1.3)+
 `<path d="M84 100 Q84 74 116 72 Q150 74 154 98 Q150 116 118 118 Q88 116 84 100 Z" fill="${P.n}" ${SW}/>${[[100,84],[116,80],[132,84],[144,96],[108,98],[126,100]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.nd}"/>`).join("")}`+
 fLeg("legF",128,110,30,11,P.n,P.nl,0)+fLeg("legF",92,110,30,11,P.n,P.nl,.8)+
 pt("head",84,86,`<path d="M58 92 L76 94 L74 98 L62 96 Z" fill="${FMOUTH}"/><path d="M62 92 l2 4 l2 -4" fill="#FFFFFF"/>`+pt("jaw",76,98,`<path d="M76 98 Q66 106 58 96 Q66 102 76 100 Z" fill="${P.nll}" ${SW2}/>`)+
  `<path d="M54 86 Q56 64 78 62 Q98 66 98 86 Q94 98 76 98 Q58 98 54 86 Z" fill="${P.n}" ${SW}/><path d="M56 92 Q50 100 58 104 Q62 98 66 96 Z M94 92 Q102 100 94 104 Q90 98 88 96 Z" fill="${P.nll}" ${SW2}/>`+
  `<path d="M56 86 L62 88 L58 90 Z" fill="${FI}"/>${fE(68,78,4.6,{iris:"#C8C040",look:[-.4,0]})}`+
  pt("ear",80,64,`<path d="M74 66 L80 46 L88 64 Z" fill="${P.n}" ${SW2}/><path d="M80 46 L80 36" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`)+pt("ear",90,66,`<path d="M86 66 L94 48 L98 68 Z" fill="${P.nd}" ${SW2}/><path d="M94 48 L96 38" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`,.4))+
 fG(g,1,`<circle cx="30" cy="140" r="6" fill="${P.b}" ${SW2}/><circle cx="30" cy="140" r="3" fill="none" stroke="${P.dd}" stroke-width="1.2"/>`)+
 fG(g,2,`<circle cx="118" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(120,52,6)));
FORM_TITLE["Nordic Gold"]="Snowcoin Lynx";

/* 117. Silicon Bronze (copper-silicon: boat fasteners and outdoor sculpture) — a manatee, gentle and enormous, drifting with a paddle tail,
   flippers with fingernails, a whiskery muzzle that munches. */
addForm("Silicon Bronze",{n:"#7A8A8A",a:"#5AA84A",rn:"#E8C8B0",rb:"#3A5AA8",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="62" ry="4" fill="#000" opacity=".14"/><path d="M20 146 q4 -16 0 -26 M28 146 q6 -14 2 -24" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 pt("tail",160,98,`<path d="M156 92 Q192 84 194 102 Q192 118 156 110 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M44 100 Q46 66 100 64 Q156 66 164 100 Q156 128 100 130 Q50 128 44 100 Z" fill="${P.n}" ${SW}/>${[[80,80],[104,76],[128,80],[96,96],[120,100],[140,92]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.nd}" opacity=".6"/>`).join("")}<path d="M60 112 Q100 128 146 112" stroke="${P.nl}" stroke-width="5" fill="none" opacity=".6"/>`+
 `<path d="M118 70 l3 4 M132 74 l3 4" stroke="${P.b}" stroke-width="2.4"/>`+
 pt("fin",78,110,`<path d="M78 108 Q66 126 54 132 Q64 134 82 120 Z" fill="${P.nd}" ${SW2}/><path d="M58 130 l3 -2 M62 132 l3 -2" stroke="${P.nll}" stroke-width="2"/>`)+
 pt("head",50,96,`<path d="M20 98 Q20 80 40 80 Q58 82 58 98 Q54 112 38 112 Q22 112 20 98 Z" fill="${P.n}" ${SW}/><path d="M18 100 Q20 92 30 92 Q36 98 30 106 Q20 106 18 100 Z" fill="${P.nl}" ${SW2}/>${[[22,98],[26,96],[24,102],[28,101]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".9" fill="${FI}"/>`).join("")}`+
  `<path d="M22 106 L34 106 L32 110 L24 110 Z" fill="${FMOUTH}"/>`+pt("jaw",34,108,`<path d="M34 108 Q28 114 22 108 Q28 112 34 112 Z" fill="${P.nd}" ${SW2}/>`)+`${fE(40,90,3.2,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}`)+
 fG(g,1,`<circle cx="60" cy="50" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,46,6)));
FORM_TITLE["Silicon Bronze"]="Drifting Manatee";

/* 118. Surgical Steel (iron-chromium-nickel-molybdenum: implants and boat fittings) — a grey heron stalking the shallows, its bill a
   scalpel, neck coiling back to strike, plumes trailing. */
addForm("Surgical Steel",{n:"#9AA4B0",a:"#2A2A34",rn:"#F0D8C0",rb:"#3A8A8A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M30 144 Q100 138 180 144" stroke="#8AB4D8" stroke-width="3" fill="none"/>`+fShadow(36,118)+
 fLeg("legB",124,108,38,3,"#C8A060",null,0,8)+fLeg("legF",112,108,38,3,"#C8A060",null,0,-2)+
 pt("tail",148,96,`<path d="M144 92 L170 104 L166 112 L142 102 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M98 96 Q102 72 128 74 Q152 80 150 100 Q142 114 122 112 Q100 110 98 96 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",124,88,`<path d="M108 84 Q142 78 158 100 Q132 108 112 98 Z" fill="${P.nd}" ${SW2}/><path d="M138 98 L158 100 L144 106 Z" fill="${P.ac}"/>`)+
 pt("head",104,90,fOL("M106 92 Q86 86 92 66 Q98 50 86 44",P.ll,7)+`<path d="M94 74 Q90 86 98 88" stroke="${P.ac}" stroke-width="1.4" fill="none" stroke-dasharray="2 2"/>`+
  `<path d="M74 40 Q74 30 86 30 Q96 32 96 42 Q92 50 84 50 Q76 48 74 40 Z" fill="${P.ll}" ${SW}/><path d="M80 32 Q92 30 96 36 L112 42" stroke="${P.ac}" stroke-width="3" fill="none" stroke-linecap="round"/>`+
  `<path d="M76 40 L40 42 L76 44 Z" fill="${FMOUTH}"/>`+pt("beak",76,44,`<path d="M76 44 L40 43 L76 47 Z" fill="${P.b}" ${SW2}/>`)+`<path d="M76 37 L38 42 L76 41 Z" fill="${P.b}" ${SW2}/><path d="M50 40 L70 38" stroke="#FFFFFF" stroke-width="1.2"/>${fE(84,38,3.6,{iris:"#F2C94C",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M24 120 q6 -4 12 0 l-6 4 Z" fill="#8AB4D8" ${SW2}/>`)+
 fG(g,2,`<circle cx="124" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(132,52,6)));
FORM_TITLE["Surgical Steel"]="Scalpel Heron";

/* 119. Duralumin (aluminium-copper-magnesium: airship frames and aircraft rivets) — an albatross gliding on enormous riveted wings, hardly
   flapping, tilting on the wind, bill clacking. */
addForm("Duralumin",{n:"#F4F0E4",a:"#E8A0B0",rn:"#3A3A4A",rb:"#B07A3A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="50" ry="4" fill="#000" opacity=".1"/>`+
 pt("wingB",112,84,`<path d="M112 82 L170 50 L192 54 L118 92 Z" fill="${P.d}" ${SW}/>${[130,148,166].map(x=>`<circle cx="${x}" cy="${76-(x-130)*.5}" r="1.4" fill="${P.ll}"/>`).join("")}`)+
 pt("tail",142,96,`<path d="M138 92 L160 96 L138 102 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M70 96 Q74 82 104 82 Q136 84 144 98 Q132 108 104 108 Q76 108 70 96 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,92,`<path d="M100 92 L54 124 L8 128 L12 120 L92 86 Z" fill="${P.b}" ${SW}/><path d="M92 92 L16 124" stroke="${P.ll}" stroke-width="2"/>${[80,64,48,32].map(x=>`<circle cx="${x}" cy="${100+(80-x)*.42}" r="1.6" fill="${P.dd}"/>`).join("")}<path d="M60 108 L56 120 M40 116 L36 126" stroke="${P.dd}" stroke-width="1.4"/>`)+
 pt("head",74,92,`<path d="M58 92 Q58 78 72 78 Q84 80 84 92 Q80 100 70 100 Q60 100 58 92 Z" fill="${P.n}" ${SW}/><path d="M64 84 Q70 80 76 84" stroke="#5A5A62" stroke-width="2" fill="none"/>`+
  `<path d="M60 90 L40 92 L60 94 Z" fill="${FMOUTH}"/>`+pt("beak",60,94,`<path d="M60 94 L40 93 L60 97 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M60 88 L38 92 Q36 94 40 92 L60 91 Z" fill="${P.ac}" ${SW2}/>${fE(68,86,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M20 60 q10 -6 20 0 M150 120 q8 -4 16 0" stroke="#8AB4D8" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="106" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,56,6)));
FORM_TITLE["Duralumin"]="Riveted Albatross";

/* 120. Mild Steel (plain low-carbon steel: car bodies, nails and beams) — a porcupine whose quills are a bristling coat of nails, raising
   them with a rattle, shuffling, a blunt snout that chatters. */
addForm("Mild Steel",{n:"#5A4A3A",a:"#E8C8A0",rn:"#E8D8F0",rb:"#C04A3A",ra:"#3A8AC8"},"crawl",(P,g)=>fShadow(60)+
 fLeg("legB",128,124,14,9,P.nd,P.ndd,.5)+
 `<path d="M62 122 Q62 90 104 88 Q146 90 150 122 Q140 134 104 134 Q70 134 62 122 Z" fill="${P.n}" ${SW}/>`+
 pt("fin",108,96,Array.from({length:22},(_,i)=>{const a=(-150+i*6.4)*Math.PI/180,r1=26,r2=46+(i%3)*6;return`<path d="M${106+Math.cos(a)*r1} ${118+Math.sin(a)*r1} L${106+Math.cos(a)*r2} ${118+Math.sin(a)*r2}" stroke="${FI}" stroke-width="3.6" stroke-linecap="round"/><path d="M${106+Math.cos(a)*r1} ${118+Math.sin(a)*r1} L${106+Math.cos(a)*r2} ${118+Math.sin(a)*r2}" stroke="${P.b}" stroke-width="1.8" stroke-linecap="round"/><circle cx="${106+Math.cos(a)*r1}" cy="${118+Math.sin(a)*r1}" r="2.4" fill="${P.d}"/>`}).join(""))+
 fLeg("legF",84,126,12,9,P.n,P.ndd,0)+
 pt("head",70,114,`<path d="M30 118 L50 120 L48 124 L34 122 Z" fill="${FMOUTH}"/><path d="M36 119 h4 v3 h-4 Z" fill="#F4E0A0"/>`+pt("jaw",50,122,`<path d="M50 122 Q40 130 30 122 Q40 126 50 126 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M28 116 Q30 98 52 96 Q74 100 76 116 Q70 126 52 126 Q34 126 28 116 Z" fill="${P.ac}" ${SW}/><ellipse cx="28" cy="114" rx="4" ry="3.4" fill="${FI}"/>${fE(50,106,4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",64,98,`<circle cx="64" cy="98" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M170 140 l8 -14" stroke="${P.b}" stroke-width="2.4"/><path d="M168 140 h4" stroke="${FI}" stroke-width="3"/>`)+
 fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(106,50,6)));
FORM_TITLE["Mild Steel"]="Nailback Porcupine";

/* 121. Carbon Steel (iron with more carbon: knives, springs and hand tools) — a shrike, the butcher bird, with a black bandit mask and a
   hooked, notched bill, perched on a barbed wire it uses as a larder. */
addForm("Carbon Steel",{n:"#B8BCC4",a:"#2A2A34",rn:"#F0D8B8",rb:"#7A3A3A",ra:"#3AC0A0"},"perch",(P,g)=>`<path d="M10 120 L190 128" stroke="#5A5A62" stroke-width="3"/>${[40,90,140].map(x=>`<path d="M${x-6} ${118+(x-10)*.044} l12 6 M${x+6} ${118+(x-10)*.044} l-12 6" stroke="#5A5A62" stroke-width="2.4"/>`).join("")}`+
 pt("tail",126,116,`<path d="M122 110 L160 136 L152 142 L118 118 Z" fill="${P.ac}" ${SW}/><path d="M148 132 L158 138" stroke="#FFFFFF" stroke-width="2.4"/>`)+
 `<path d="M84 106 Q84 80 106 78 Q128 82 130 106 Q124 124 106 124 Q88 122 84 106 Z" fill="${P.n}" ${SW}/><path d="M88 112 Q88 96 100 92 Q112 102 110 122 Q94 122 88 112 Z" fill="#F4F0E4"/>`+
 pt("wingF",110,94,`<path d="M100 90 Q128 86 134 108 Q118 116 102 106 Z" fill="${P.ac}" ${SW2}/><path d="M108 100 h10" stroke="#FFFFFF" stroke-width="3"/>`)+
 `<path d="M98 122 l-2 6 M108 122 l0 6" stroke="${FI}" stroke-width="2.4"/>`+
 pt("head",96,84,`<circle cx="90" cy="72" r="14" fill="${P.n}" ${SW}/><path d="M76 70 L104 68 L104 76 L78 78 Z" fill="${P.ac}"/>`+
  `<path d="M76 72 L62 74 L76 78 Z" fill="${FMOUTH}"/>`+pt("beak",76,78,`<path d="M76 78 L62 76 L76 80 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M78 68 L62 70 Q58 74 62 76 L66 72 L78 74 Z" fill="${P.b}" ${SW2}/>${fE(88,72,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M40 118 q-2 10 4 16" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="102" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(116,52,6)));
FORM_TITLE["Carbon Steel"]="Butcher Shrike";

/* 122. Stainless Steel (iron-chromium-nickel: sinks and cutlery) — a mute swan with a mirror-polished sheen, neck in an S, wings arched
   up in threat, bill opening to hiss. */
addForm("Stainless Steel",{n:"#F4F4F8",a:"#F28A30",rn:"#2A2A34",rb:"#5FC8A0",ra:"#E8412C"},"swim",(P,g)=>`<path d="M10 128 Q60 122 100 128 Q150 134 190 126" stroke="#8AB4D8" stroke-width="3" fill="none"/><ellipse class="shd" cx="108" cy="150" rx="50" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",156,112,`<path d="M152 106 L172 100 L166 116 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M80 116 Q82 92 116 90 Q152 92 160 114 Q150 132 116 132 Q86 130 80 116 Z" fill="${P.n}" ${SW}/>`+
 pt("wingB",128,96,`<path d="M124 94 Q140 52 172 62 Q170 84 148 100 Z" fill="${P.b}" opacity=".9" ${SW}/>`)+
 pt("wingF",112,98,`<path d="M100 96 Q110 58 146 62 Q148 88 130 106 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${112+i*6} 96 Q${118+i*6} 76 ${130+i*4} 68" stroke="${P.b}" stroke-width="1.6" fill="none"/>`).join("")}`)+
 pt("head",88,104,fOL("M90 108 Q70 100 78 82 Q86 66 72 56",P.n,9)+
  `<path d="M58 54 Q58 42 70 42 Q82 44 82 54 Q78 62 70 62 Q60 62 58 54 Z" fill="${P.n}" ${SW}/><path d="M62 50 Q60 44 66 44" stroke="${FI}" stroke-width="4" fill="none"/>`+
  `<path d="M60 54 L44 56 L60 60 Z" fill="${FMOUTH}"/>`+pt("beak",60,60,`<path d="M60 60 L44 58 L60 62 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M62 50 L42 55 L62 56 Z" fill="${P.ac}" ${SW2}/>${fE(70,50,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M100 116 Q120 108 140 116" stroke="${P.b}" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,2,`<circle cx="116" cy="118" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,32,6)));
FORM_TITLE["Stainless Steel"]="Mirror Swan";

/* 123. Cutlery Stainless (iron-chromium with carbon: knife blades and scissors) — an earwig whose tail forceps open and shut like
   scissors, arched over its back, mandibles nipping. */
addForm("Cutlery Stainless",{n:"#7A3A24",a:"#E8C8A0",rn:"#C8E0F0",rb:"#3A3A6A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(62)+
 pt("claw",146,106,`<path d="M144 104 Q176 96 178 72 Q172 88 150 96 Z" fill="${P.b}" ${SW2}/>`)+pt("claw2",146,112,`<path d="M144 112 Q182 108 186 84 Q178 100 150 104 Z" fill="${P.d}" ${SW2}/>`)+
 [[100,118],[116,120],[132,118]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+8} ${y+12} L${x+4} 140`,P.nd,2.6),i*.2)).join("")+
 `<path d="M70 110 Q72 94 100 94 L150 100 Q156 110 150 120 L100 124 Q72 124 70 110 Z" fill="${P.n}" ${SW}/>${[106,118,130,142].map(x=>`<path d="M${x} ${96} Q${x+3} 110 ${x} 122" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`).join("")}<path d="M74 102 L100 98" stroke="${P.ac}" stroke-width="5" stroke-linecap="round"/>`+
 [[80,118],[92,120]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-10} ${y+12} L${x-12} 140`,P.n,2.6),i*.2)).join("")+
 pt("head",74,108,`<ellipse cx="58" cy="106" rx="16" ry="12" fill="${P.n}" ${SW}/>${fE(54,102,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",54,96,`<path d="M54 96 Q36 76 20 78" stroke="${FI}" stroke-width="2" fill="none"/>`)+pt("ant",60,96,`<path d="M60 96 Q50 72 34 64" stroke="${FI}" stroke-width="2" fill="none"/>`,.4)+
  `<path d="M42 110 L50 110 L48 114 Z" fill="${FMOUTH}"/>`+pt("jaw",48,113,`<path d="M48 113 L38 114 L44 118 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M176 128 l8 -8 M176 120 l8 8" stroke="${P.b}" stroke-width="2.4"/>`)+
 fG(g,2,`<circle cx="112" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,74,6)));
FORM_TITLE["Cutlery Stainless"]="Scissor Earwig";

/* 124. Precipitation Stainless (stainless hardened by ageing: turbine parts and golf club heads) — a kiwi, round as a golf ball, a long
   driver of a bill probing the turf, sturdy legs, swinging its head. */
addForm("Precipitation Stainless",{n:"#8A6A4A",a:"#F4F0E4",rn:"#B8D8C0",rb:"#3A5AB0",ra:"#E8604A"},"stand",(P,g)=>fShadow(44,108)+
 `<path d="M14 146 Q100 140 190 146" stroke="#5AA84A" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="34" cy="138" r="5" fill="#FFFFFF" ${SW2}/>${[[32,136],[36,137],[34,140]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r=".7" fill="${FI}"/>`).join("")}`+
 fLeg("legB",118,124,18,5,"#C8B8A0",null,.5,2)+
 `<path d="M76 104 Q76 70 110 70 Q144 72 146 106 Q140 130 110 130 Q80 130 76 104 Z" fill="${P.n}" ${SW}/>${Array.from({length:14},(_,i)=>`<path d="M${84+(i%5)*12} ${80+Math.floor(i/5)*14} q3 6 0 10" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("legF",100,126,fOL("M100 126 L98 144",'#C8B8A0',5)+`<path d="M98 144 l-8 0 M98 144 l-4 3 M98 144 l4 1" stroke="#C8B8A0" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",88,90,`<path d="M72 92 Q70 74 86 74 Q100 76 100 92 Q96 102 86 102 Q74 102 72 92 Z" fill="${P.n}" ${SW}/>${fE(82,86,3,{iris:"#2A1A0A",look:[-.4,0]})}`+
  `<path d="M74 92 L36 132 L40 134 L76 96 Z" fill="${FMOUTH}"/>`+pt("beak",76,96,`<path d="M76 96 L40 134 L44 134 L78 98 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M72 90 L32 130 L36 132 L76 94 Z" fill="${P.b}" ${SW2}/><path d="M30 128 l6 6" stroke="${P.dd}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M20 120 l8 -16 l4 2 l-8 16 Z" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="112" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,54,6)));
FORM_TITLE["Precipitation Stainless"]="Driver Kiwi";

/* 125. Cast Iron (iron with lots of carbon: skillets, engine blocks and manhole covers) — a black bear reared up on a manhole cover,
   heavy paws swiping, claws out, roaring. */
addForm("Cast Iron",{n:"#2A2A30",a:"#C8A070",rn:"#E8C8A0",rb:"#3A6A8A",ra:"#E8412C"},"stand",(P,g)=>`<ellipse cx="104" cy="146" rx="46" ry="7" fill="${P.b}" ${SW}/>${[-30,-15,0,15,30].map(x=>`<path d="M${104+x-6} 144 h12" stroke="${P.dd}" stroke-width="1.6"/>`).join("")}`+
 pt("legB",120,122,fOL("M120 120 L124 142",P.nd,14))+
 `<path d="M80 124 Q70 84 102 66 Q132 70 134 110 Q132 132 108 136 Q84 136 80 124 Z" fill="${P.n}" ${SW}/><path d="M92 94 Q100 88 110 94 Q104 100 100 102 Z" fill="${P.ac}"/>`+
 pt("legF",96,126,fOL("M96 124 L92 142",P.n,14))+
 pt("armB",120,84,fOL("M120 84 Q140 70 142 52",P.nd,12)+`<path d="M136 46 l-2 -6 M142 44 l0 -6 M148 46 l2 -6" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`,.6)+
 pt("armF",88,86,fOL("M88 86 Q66 80 56 64",P.n,12)+`<path d="M48 62 l-6 -2 M50 56 l-5 -4 M56 52 l-2 -6" stroke="${P.ac}" stroke-width="2.6" stroke-linecap="round"/>`)+
 pt("head",100,68,`<path d="M74 58 Q74 36 98 34 Q120 36 120 58 Q116 72 98 74 Q78 72 74 58 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M64 60 Q66 50 80 50 L86 64 Q76 70 64 66 Z" fill="${P.ac}" ${SW2}/><ellipse cx="66" cy="56" rx="3.4" ry="2.6" fill="${FI}"/>`+
  `<path d="M66 64 L82 66 L80 70 L68 70 Z" fill="${FMOUTH}"/><path d="M70 65 l2 3 l2 -3" fill="#FFFFFF"/>`+pt("jaw",82,68,`<path d="M82 68 Q74 78 66 70 Q74 74 82 72 Z" fill="${P.ac}" ${SW2}/>`)+
  `${fE(90,48,4,{iris:"#7A4A2A",look:[-.4,0]})}`+pt("ear",84,38,`<circle cx="84" cy="36" r="6" fill="${P.n}" ${SW2}/>`)+pt("ear",110,36,`<circle cx="112" cy="36" r="6" fill="${P.n}" ${SW2}/>`,.4))+
 fG(g,1,`<rect x="148" y="128" width="30" height="8" rx="2" fill="${P.b}" ${SW2}/><path d="M178 132 h10" stroke="${FI}" stroke-width="3"/>`)+
 fG(g,2,`<circle cx="106" cy="114" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(140,28,6)));
FORM_TITLE["Cast Iron"]="Manhole Bear";

/* 126. Weathering Steel (steel that rusts to a protective coat: bridges and outdoor sculpture) — a red panda in a rust-red coat, ringed
   tail, perched on a girder, standing up with paws raised to look bigger. */
addForm("Weathering Steel",{n:"#B0482A",a:"#F4E8D8",rn:"#5A8AB0",rb:"#3A6A4A",ra:"#F2C94C"},"perch",(P,g)=>`<rect x="20" y="132" width="164" height="12" fill="${P.b}" ${SW}/><path d="M20 138 h164" stroke="${P.dd}" stroke-width="2"/>${[40,70,100,130,160].map(x=>`<circle cx="${x}" cy="138" r="2" fill="${P.ll}"/>`).join("")}`+
 pt("tail",120,118,`<path d="M118 116 Q150 120 162 104 Q174 88 168 74 Q160 84 152 96 Q138 108 120 108 Z" fill="${P.n}" ${SW}/>${[[136,110],[150,104],[160,92]].map(([x,y])=>`<path d="M${x} ${y-6} q4 6 0 12" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".8"/>`).join("")}`)+
 fLeg("legB",112,118,14,10,P.ndd,P.ndd,.4)+
 `<path d="M82 120 Q78 90 100 82 Q120 86 120 116 Q116 132 100 132 Q86 132 82 120 Z" fill="${P.n}" ${SW}/><path d="M88 120 Q88 100 100 98 Q112 104 110 124 Z" fill="${P.ndd}"/>`+
 fLeg("legF",92,122,10,10,P.ndd,P.ndd,0)+
 pt("armF",88,96,fOL("M88 96 Q72 86 66 72",P.ndd,8)+`<path d="M62 70 l-3 -3 M65 66 l-1 -4 M69 66 l1 -4" stroke="${FI}" stroke-width="1.6" stroke-linecap="round"/>`)+
 pt("armB",112,96,fOL("M112 96 Q126 84 128 70",P.ndd,8),.4)+
 pt("head",100,82,`<path d="M76 70 Q74 48 98 46 Q122 48 122 70 Q118 84 98 86 Q78 84 76 70 Z" fill="${P.n}" ${SW}/><path d="M80 72 Q84 62 92 66 Q90 76 82 78 Z M116 72 Q112 62 104 66 Q106 76 114 78 Z" fill="${P.ac}"/><path d="M86 76 Q98 84 110 76 Q106 86 98 86 Q90 86 86 76 Z" fill="${P.ac}"/>`+
  `${fE(90,64,3.8,{iris:"#2A1A0A",look:[-.4,0]})}${fE(106,64,3.8,{iris:"#2A1A0A",look:[-.4,0]})}<ellipse cx="98" cy="74" rx="2.6" ry="2" fill="${FI}"/>`+
  `<path d="M94 78 L102 78 L100 81 L96 81 Z" fill="${FMOUTH}"/>`+pt("jaw",100,80,`<path d="M101 80 Q98 85 95 80 Q98 82 101 82 Z" fill="${P.ac}" ${SW2}/>`)+
  pt("ear",80,50,`<path d="M78 54 Q76 38 88 42 Q86 50 84 54 Z" fill="${P.n}" stroke="${FI}" stroke-width="2"/><path d="M80 52 Q80 44 85 45" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+pt("ear",116,50,`<path d="M118 54 Q120 38 108 42 Q110 50 112 54 Z" fill="${P.n}" stroke="${FI}" stroke-width="2"/>`,.4))+
 fG(g,1,`<circle cx="40" cy="124" r="3" fill="${P.n}" opacity=".6"/><circle cx="170" cy="126" r="2.4" fill="${P.n}" opacity=".6"/>`)+
 fG(g,2,`<circle cx="100" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(132,40,6)));
FORM_TITLE["Weathering Steel"]="Girder Red Panda";

/* 127. Electrical Steel (iron-silicon: the laminated cores of transformers that hum) — a cicada on a tree trunk, its belly plates
   stacked like core laminations, drumming out a mains hum, wings shivering. */
addForm("Electrical Steel",{n:"#3A5A3A",a:"#9FE8D0",rn:"#E8D0B0",rb:"#7A3A8A",ra:"#F2C94C"},"perch",(P,g)=>`<rect x="150" y="6" width="34" height="146" rx="4" fill="#7A5A3A" ${SW}/><path d="M158 14 v130 M172 24 v110" stroke="#5A3A20" stroke-width="2"/>`+
 pt("wingB",120,74,`<path d="M120 74 Q90 40 60 46 Q70 70 118 84 Z" fill="${P.ac}" opacity=".45" ${SW2}/>`)+
 [[120,96],[132,98],[144,96]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+6} ${y+10} L${x+16} ${y+10}`,P.nd,2.6),i*.2)).join("")+
 `<path d="M86 84 Q90 70 116 70 Q146 72 150 86 Q146 100 116 102 Q90 100 86 84 Z" fill="${P.n}" ${SW}/>${[104,112,120,128,136].map(x=>`<path d="M${x} ${74} L${x} ${100}" stroke="${P.b}" stroke-width="3"/>`).join("")}`+
 pt("wingF",112,74,`<path d="M112 74 Q80 46 40 56 Q52 84 110 88 Z" fill="${P.ac}" opacity=".7" ${SW2}/>${[0,1,2].map(i=>`<path d="M${108-i*2} ${78+i*2} Q${80-i*6} ${60+i*6} ${50+i*4} ${60+i*6}" stroke="${P.nd}" stroke-width="1.2" fill="none"/>`).join("")}`)+
 pt("head",92,84,`<path d="M70 84 Q70 70 84 68 Q98 70 98 84 Q96 98 84 98 Q70 98 70 84 Z" fill="${P.n}" ${SW}/>${fE(76,76,5,{iris:"#E8412C",look:[-.4,0]})}${fE(86,72,4,{iris:"#E8412C",look:[-.4,0]})}`+
  `<path d="M70 90 L78 92 L76 96 Z" fill="${FMOUTH}"/>`+pt("jaw",76,94,`<path d="M76 94 L68 98 L74 100 Z" fill="${P.nd}" ${SW2}/>`)+pt("ant",80,68,`<path d="M80 68 L72 60" stroke="${FI}" stroke-width="1.6"/>`))+
 fG(g,1,`<path d="M30 100 q6 -6 0 -12 M22 104 q8 -10 0 -20" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="120" cy="86" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(100,40,6)));
FORM_TITLE["Electrical Steel"]="Mains-Hum Cicada";

/* 128. Hadfield Steel (manganese steel that hardens as it is pounded: rock crushers and prison bars) — a silverback gorilla that bends bars,
   knuckle-walking, beating its chest, roaring. */
addForm("Hadfield Steel",{n:"#2A2A30",a:"#B8BCC4",rn:"#E8D8C0",rb:"#7A3A2A",ra:"#3A8AC8"},"stand",(P,g)=>fShadow(64)+
 `${[150,162,174].map((x,i)=>`<path d="M${x} 20 ${i==1?"Q"+(x+10)+" 80 "+x:"L"+x} 146" stroke="${FI}" stroke-width="6" fill="none"/><path d="M${x} 20 ${i==1?"Q"+(x+10)+" 80 "+x:"L"+x} 146" stroke="${P.b}" stroke-width="3" fill="none"/>`).join("")}`+
 fLeg("legB",130,116,26,14,P.nd,P.ndd,.5)+
 `<path d="M70 108 Q66 64 104 56 Q140 62 142 104 Q138 126 106 128 Q74 126 70 108 Z" fill="${P.n}" ${SW}/><path d="M104 60 Q136 66 138 100 Q120 80 100 72 Z" fill="${P.ac}" opacity=".85"/><path d="M84 84 Q94 78 104 84 Q96 96 86 92 Z" fill="#4A4A52"/>`+
 fLeg("legF",112,120,24,14,P.n,P.ndd,.8)+
 pt("armB",120,72,fOL("M120 72 Q146 92 140 140",P.nd,16),.5)+
 pt("armF",80,74,fOL("M80 74 Q58 98 62 142",P.n,16)+`<path d="M54 142 h16" stroke="${FI}" stroke-width="6" stroke-linecap="round"/>`)+
 pt("head",88,60,`<path d="M66 54 Q64 30 88 28 Q108 30 108 52 Q106 70 88 72 Q68 70 66 54 Z" fill="${P.n}" ${SW}/><path d="M70 50 Q72 40 88 40 Q102 42 102 50" stroke="${FI}" stroke-width="5" fill="none"/>`+
  `<path d="M72 52 Q72 44 82 46 Q92 46 94 56 Q90 66 82 66 Q72 66 72 52 Z" fill="#4A4A52"/>${fE(78,48,3.4,{iris:"#7A4A2A",look:[-.4,0]})}${fE(92,48,3.4,{iris:"#7A4A2A",look:[-.4,0]})}`+
  `<path d="M74 60 L90 60 L88 64 L76 64 Z" fill="${FMOUTH}"/><path d="M76 60 l2 3 l2 -3 M84 60 l2 3 l2 -3" fill="#FFFFFF"/>`+pt("jaw",90,64,`<path d="M90 64 Q82 72 74 64 Q82 68 90 66 Z" fill="#4A4A52" ${SW2}/>`))+
 fG(g,1,`<path d="M30 140 l6 -8 l4 6 l6 -8" stroke="#8A8A8A" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="112" cy="106" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(118,30,6)));
FORM_TITLE["Hadfield Steel"]="Barbender Gorilla";

/* 129. High-Speed Steel (iron with tungsten, molybdenum and chromium: drill bits) — a weevil whose long snout is a twist drill, boring with
   jaws at its tip, elbowed antennae, armoured back. */
addForm("High-Speed Steel",{n:"#5A4A3A",a:"#F2C94C",rn:"#C8E8D8",rb:"#B04A3A",ra:"#3A3A6A"},"crawl",(P,g)=>fShadow(58)+
 [[112,118],[128,120],[144,118]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+8} ${y+12} L${x+4} 140`,P.nd,3.6),i*.2)).join("")+
 `<path d="M90 110 Q90 74 128 72 Q166 76 166 110 Q160 124 128 124 Q96 124 90 110 Z" fill="${P.n}" ${SW}/>${[[108,90],[124,84],[140,88],[152,98],[116,104],[136,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.ac}" opacity=".6"/>`).join("")}<path d="M128 74 V124" stroke="${P.ndd}" stroke-width="2"/>`+
 [[96,120],[106,122]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-10} ${y+10} L${x-8} 140`,P.n,3.6),i*.2)).join("")+
 pt("head",92,104,`<circle cx="80" cy="102" r="14" fill="${P.n}" ${SW}/>${fE(80,98,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",70,100,`<path d="M70 100 L58 82 L44 82" stroke="${FI}" stroke-width="2.4" fill="none"/><circle cx="44" cy="82" r="2.6" fill="${P.n}" ${SW2}/>`)+
  `<path d="M70 104 L20 118 L22 124 L70 112 Z" fill="${P.b}" ${SW}/>${[28,38,48,58].map(x=>`<path d="M${x} ${118-(x-20)*.26} l4 6" stroke="${P.dd}" stroke-width="2"/>`).join("")}`+
  `<path d="M22 118 L10 118 L14 122 Z" fill="${FMOUTH}"/>`+pt("jaw",20,122,`<path d="M20 122 L8 124 L16 126 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<path d="M6 132 l4 -4 M12 136 l2 -6" stroke="#8A6A4A" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="128" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,54,6)));
FORM_TITLE["High-Speed Steel"]="Drill-Snout Weevil";

/* 130. Tool Steel (iron-chromium-carbon: dies and industrial knives) — a tiger whose stripes are cut like blades, prowling, ears back,
   jaws gaping on its fangs. */
addForm("Tool Steel",{n:"#E88A3A",a:"#F4F0E4",rn:"#E8E4F0",rb:"#2A2A34",ra:"#5FC8F0"},"slink",(P,g)=>fShadow(70)+
 pt("tail",160,104,fOL("M158 102 Q182 96 186 116 Q188 128 180 132",P.n,8)+`<path d="M182 124 l6 4 M184 114 l6 0" stroke="${FI}" stroke-width="3"/>`)+
 fLeg("legB",148,114,30,11,P.nd,P.ac,.5)+fLeg("legB",104,116,28,11,P.nd,P.ac,1.3)+
 `<path d="M68 108 Q70 82 112 82 Q156 84 164 108 Q156 126 114 126 Q74 126 68 108 Z" fill="${P.n}" ${SW}/><path d="M76 116 Q114 128 156 116" stroke="${P.ac}" stroke-width="6" fill="none"/>${[92,108,124,140,152].map(x=>`<path d="M${x} 84 L${x-4} 98 L${x+2} 96 L${x-2} 110" fill="none" stroke="${P.b}" stroke-width="3.4" stroke-linejoin="miter"/>`).join("")}`+
 fLeg("legF",136,116,28,11,P.n,P.ac,0)+fLeg("legF",88,116,28,11,P.n,P.ac,.8)+
 pt("head",76,98,`<path d="M30 102 L54 104 L52 110 L34 108 Z" fill="${FMOUTH}"/><path d="M36 102 l2 6 l2 -6 M46 103 l2 5 l2 -5" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`+pt("jaw",54,108,`<path d="M54 108 Q42 120 30 108 Q42 114 54 112 Z" fill="${P.ac}" ${SW2}/><path d="M38 110 l2 -4 l2 4" fill="#FFFFFF"/>`)+
  `<path d="M28 98 Q30 76 56 74 Q80 78 82 98 Q76 110 56 108 Q34 108 28 98 Z" fill="${P.n}" ${SW}/><path d="M30 100 Q40 92 54 98 Q44 106 32 104 Z" fill="${P.ac}"/><path d="M46 78 l2 8 M56 76 l0 8 M66 78 l-2 8" stroke="${P.b}" stroke-width="2.6"/>`+
  `<ellipse cx="30" cy="96" rx="3" ry="2.4" fill="${FI}"/>${fE(54,88,4.4,{iris:"#C8C040",look:[-.4,0]})}`+pt("ear",70,78,`<path d="M66 80 Q70 68 78 74 Q76 82 72 84 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 70 l10 6 M18 80 l12 2" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="114" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(118,62,6)));
FORM_TITLE["Tool Steel"]="Bladestripe Tiger";

/* 131. Bearing Steel (iron-chromium-carbon: the balls in ball bearings) — a ball python coiled round a ring of bearing balls, head rising
   from the coil, forked tongue tasting the air. */
addForm("Bearing Steel",{n:"#8A6A3A",a:"#F2E0B0",rn:"#3A3A5A",rb:"#C8C8D0",ra:"#E8604A"},"slink",(P,g)=>fShadow(58)+
 `<circle cx="104" cy="124" r="20" fill="none" stroke="${FI}" stroke-width="3"/>${Array.from({length:8},(_,i)=>`<circle cx="${104+Math.cos(i*Math.PI/4)*20}" cy="${124+Math.sin(i*Math.PI/4)*20}" r="5" fill="${P.b}" ${SW2}/>`).join("")}`+
 pt("tail",150,130,fOL("M128 140 Q160 146 170 128 Q174 116 164 114",P.n,12))+
 `<path d="M56 132 Q56 108 104 104 Q152 108 152 132 Q140 148 104 148 Q66 148 56 132 Z" fill="none" stroke="${FI}" stroke-width="20"/><path d="M56 132 Q56 108 104 104 Q152 108 152 132 Q140 148 104 148 Q66 148 56 132 Z" fill="none" stroke="${P.n}" stroke-width="15"/>`+
 [[64,120],[84,108],[110,106],[136,112],[148,128],[128,146],[96,148],[66,142]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="5" ry="3.4" fill="${P.ndd}" opacity=".7"/>`).join("")+
 pt("head",70,116,fOL("M70 118 Q58 92 64 72",P.n,13)+`<path d="M64 112 Q56 92 62 76" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".7"/>`+
  `<path d="M34 64 L54 66 L52 70 L38 68 Z" fill="${FMOUTH}"/>`+pt("tongue",34,66,`<path d="M34 66 L22 66 L18 62 M22 66 L18 70" stroke="${FTONGUE}" stroke-width="2" fill="none" stroke-linecap="round"/>`)+
  pt("jaw",54,70,`<path d="M54 70 Q44 76 34 68 Q44 72 54 72 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M32 62 Q36 50 56 50 Q74 54 74 66 Q70 74 54 70 Q38 70 32 62 Z" fill="${P.n}" ${SW}/><path d="M48 54 Q60 52 70 58" stroke="${P.ndd}" stroke-width="3" fill="none"/>${fE(54,58,3.8,{iris:"#C8A040",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="30" cy="140" r="5" fill="${P.b}" ${SW2}/><circle cx="42" cy="144" r="4" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<circle cx="104" cy="124" r="4" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,80,6)));
FORM_TITLE["Bearing Steel"]="Bearing Python";

/* 132. Chromoly (chromium-molybdenum steel: bike frames and roll cages) — a roadrunner built like a bicycle frame, tubular legs a blur,
   crest up, tail cocked, beak open in a "beep". */
addForm("Chromoly",{n:"#8A7A5A",a:"#3A8AC8",rn:"#E8D0E8",rb:"#E8412C",ra:"#2FA060"},"stand",(P,g)=>fShadow(50,106)+
 pt("tail",128,96,`<path d="M124 92 L176 66 L180 74 L130 102 Z" fill="${P.nd}" ${SW}/>${[140,152,164].map(x=>`<path d="M${x} ${86-(x-140)*.5} l4 6" stroke="#F4F0E4" stroke-width="2"/>`).join("")}`)+
 pt("legB",112,110,fOL("M112 110 L128 126 L120 144",P.b,3.4)+`<path d="M116 144 h10" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 pt("legF",104,110,fOL("M104 110 L88 126 L92 144",P.b,3.4)+`<path d="M86 144 h10" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 `<path d="M84 100 Q86 80 108 80 Q132 84 134 102 Q126 116 108 116 Q88 114 84 100 Z" fill="${P.n}" ${SW}/>${[[96,92],[108,88],[120,94],[102,104],[118,106]].map(([x,y])=>`<path d="M${x} ${y} l4 3" stroke="#F4F0E4" stroke-width="2"/>`).join("")}`+
 `<path d="M100 112 L120 112 L110 96 Z" fill="none" stroke="${P.b}" stroke-width="2.4"/>`+
 pt("wingF",110,92,`<path d="M100 90 Q126 86 134 102 Q118 108 104 102 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",90,88,fOL("M92 92 Q82 80 80 68",P.n,9)+
  `<path d="M66 64 Q66 52 80 52 Q92 54 92 66 Q88 74 78 74 Q68 72 66 64 Z" fill="${P.n}" ${SW}/>`+pt("ear",84,54,`<path d="M80 54 L90 36 L94 46 L98 34 L96 56 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M70 60 Q76 58 84 62" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
  `<path d="M66 62 L42 64 L66 66 Z" fill="${FMOUTH}"/>`+pt("beak",66,66,`<path d="M66 66 L42 65 L66 69 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M68 59 L40 64 L68 63 Z" fill="${P.d}" ${SW2}/>${fE(78,60,3.6,{iris:"#E8604A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M150 130 h24 M156 138 h22" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="110" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,56,6)));
FORM_TITLE["Chromoly"]="Frame Roadrunner";

/* 133. Ferrochrome (mostly chromium, with iron: what gives stainless its chrome) — a mandrill whose face is painted in chrome's own
   colours, blue ridges and a red stripe, yawning to flash its long canines. */
addForm("Ferrochrome",{n:"#5A6A3A",a:"#E8412C",rn:"#E8D8F0",rb:"#3A8AC8",ra:"#2FA060"},"stand",(P,g)=>fShadow(56)+
 pt("tail",146,100,fOL("M146 100 Q156 92 154 82",P.nd,5))+
 fLeg("legB",136,112,30,10,P.nd,P.ndd,.5)+fLeg("legB",98,112,30,10,P.nd,P.ndd,1.3)+
 `<path d="M80 106 Q80 78 112 76 Q146 78 150 104 Q144 120 114 122 Q84 120 80 106 Z" fill="${P.n}" ${SW}/><path d="M140 96 Q154 100 152 116 Q144 116 140 106 Z" fill="${P.b}" ${SW2}/>`+
 fLeg("legF",126,114,28,10,P.n,P.ndd,0)+fLeg("legF",88,114,28,10,P.n,P.ndd,.8)+
 pt("head",86,90,`<path d="M58 84 Q56 58 82 56 Q106 58 106 84 Q102 100 82 102 Q60 100 58 84 Z" fill="${P.n}" ${SW}/><path d="M60 70 Q70 50 92 54 Q80 58 76 70 Z" fill="${P.nl}"/>`+
  `<path d="M44 92 L66 94 L64 100 L48 98 Z" fill="${FMOUTH}"/><path d="M50 94 l2 6 l2 -6 M58 94 l2 6 l2 -6" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`+pt("jaw",66,98,`<path d="M66 98 Q56 108 46 98 Q56 104 66 102 Z" fill="#F2E0B0" ${SW2}/>`)+
  `<path d="M40 84 Q42 68 62 68 Q76 72 76 88 Q70 96 56 94 Q42 94 40 84 Z" fill="${P.b}" ${SW}/><path d="M44 76 Q56 72 70 78 M44 82 Q56 78 70 84" stroke="${P.dd}" stroke-width="1.6" fill="none"/><path d="M42 84 Q56 86 74 80 L74 72 Q58 76 42 80 Z" fill="${P.ac}" ${SW2}/><ellipse cx="42" cy="84" rx="3.6" ry="3" fill="${P.ac}" ${SW2}/>`+
  `${fE(76,72,3.6,{iris:"#E8A020",look:[-.4,0],lid:.3,lidC:P.n})}`+pt("ear",96,66,`<path d="M94 68 Q98 58 104 64 Q102 70 98 72 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 120 l6 -6 l4 4 l6 -6" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="114" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,52,6)));
FORM_TITLE["Ferrochrome"]="Chromeface Mandrill";

/* 134. Ferrosilicon (silicon-iron: thrown into molten steel to pull out oxygen, and used to make hydrogen) — a skunk that answers trouble
   with a hiss of gas, tail flagged high, stamping its front feet. */
addForm("Ferrosilicon",{n:"#1E1E26",a:"#F4F0E4",rn:"#E8D8C0",rb:"#4A8AB0",ra:"#9BE05A"},"stand",(P,g)=>fShadow(54)+
 pt("tail",136,96,`<path d="M134 96 Q160 70 150 38 Q168 40 176 62 Q180 90 146 108 Z" fill="${P.n}" ${SW}/><path d="M142 92 Q160 70 156 46" stroke="${P.ac}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 `<g class="p-glow"><circle cx="170" cy="30" r="8" fill="${P.b}" opacity=".35"/><circle cx="184" cy="44" r="6" fill="${P.b}" opacity=".3"/><circle cx="160" cy="16" r="5" fill="${P.b}" opacity=".3"/></g>`+
 fLeg("legB",126,116,24,9,P.n,P.n,.5)+
 `<path d="M74 112 Q74 84 106 82 Q138 84 142 110 Q136 126 108 126 Q80 126 74 112 Z" fill="${P.n}" ${SW}/><path d="M80 98 Q106 82 136 100" stroke="${P.ac}" stroke-width="7" fill="none" stroke-linecap="round"/>`+
 fLeg("legF",112,118,24,9,P.n,P.n,0)+pt("legF",86,118,fOL("M86 118 L84 140",P.n,9),.5)+
 pt("head",80,102,`<path d="M40 108 L58 110 L56 114 L44 112 Z" fill="${FMOUTH}"/>`+pt("jaw",58,114,`<path d="M58 114 Q48 120 40 112 Q48 116 58 116 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M38 104 Q40 86 60 84 Q80 88 82 104 Q76 114 60 114 Q42 114 38 104 Z" fill="${P.n}" ${SW}/><path d="M44 102 Q52 88 70 90" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/><ellipse cx="38" cy="104" rx="3" ry="2.4" fill="#F0A0A8"/>`+
  `${fE(58,98,4,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",72,86,`<circle cx="72" cy="86" r="4.6" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 136 q4 -4 8 0" stroke="#8A8A8A" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,64,6)));
FORM_TITLE["Ferrosilicon"]="Gas-Hiss Skunk";

/* 135. Sendust (iron-silicon-aluminium: tape-recorder heads) — a mockingbird that records every sound it hears and plays it back, tail
   flicking, wings flashing white patches, bill opening on a long medley. */
addForm("Sendust",{n:"#8A8A90",a:"#F4F0E4",rn:"#E8C8A0",rb:"#3A6A9A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M20 124 Q100 116 186 126" stroke="#6A4A2A" stroke-width="7" fill="none" stroke-linecap="round"/>`+
 pt("tail",128,112,`<path d="M124 106 L170 128 L164 136 L120 114 Z" fill="${P.nd}" ${SW}/><path d="M160 126 L168 132" stroke="${P.ac}" stroke-width="3"/>`)+
 `<path d="M86 104 Q86 80 108 78 Q130 82 132 104 Q126 120 108 120 Q90 120 86 104 Z" fill="${P.n}" ${SW}/><path d="M90 110 Q90 96 102 92 Q112 102 110 118 Q94 118 90 110 Z" fill="${P.ac}"/>`+
 pt("wingF",112,92,`<path d="M100 88 Q130 84 136 104 Q118 112 102 104 Z" fill="${P.nd}" ${SW2}/><rect x="114" y="94" width="10" height="5" rx="1" fill="${P.ac}"/>`)+
 `<path d="M100 118 l-2 6 M110 118 l0 6" stroke="${FI}" stroke-width="2.4"/>`+
 pt("head",96,84,`<circle cx="90" cy="72" r="13" fill="${P.n}" ${SW}/><path d="M78 72 L96 70" stroke="${P.nd}" stroke-width="2"/>`+
  `<path d="M78 70 L60 72 L78 74 Z" fill="${FMOUTH}"/>`+pt("beak",78,74,`<path d="M78 74 L60 73 L78 77 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M78 67 L58 71 L78 70 Z" fill="${P.d}" ${SW2}/>${fE(88,70,3.6,{iris:"#E8C040",look:[-.4,0]})}`)+
 `<g class="p-glow"><rect x="26" y="44" width="34" height="20" rx="3" fill="${P.b}" ${SW2}/><circle cx="36" cy="54" r="5" fill="none" stroke="${FI}" stroke-width="2"/><circle cx="50" cy="54" r="5" fill="none" stroke="${FI}" stroke-width="2"/><path d="M36 59 L50 59" stroke="${FI}" stroke-width="1.4"/></g>`+
 fG(g,1,`<path d="M30 30 q4 -6 8 0 q4 6 8 0 q4 -6 8 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,50,6)));
FORM_TITLE["Sendust"]="Taperecorder Mockingbird";

/* 136. Kanthal (iron-chromium-aluminium: the glowing coils inside kilns and heaters) — a phoenix of heater coil, its wing feathers wound like
   elements that glow orange, a trailing tail of loops, beak open in a crackling cry. */
addForm("Kanthal",{n:"#E8604A",a:"#FFB040",rn:"#7AD0F0",rb:"#3A3A8A",ra:"#F4F0E4"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",126,104,`<path d="M124 102 Q150 120 140 140 Q156 130 170 142 Q164 118 136 98 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<circle cx="${146+i*8}" cy="${126+i*4}" r="4" fill="none" stroke="${P.b}" stroke-width="2"/>`).join("")}`)+
 pt("wingB",110,82,`<path d="M110 82 Q132 32 176 22 Q166 46 172 54 Q150 60 140 72 Q130 84 116 92 Z" fill="${P.ac}" ${SW}/>${[0,1,2].map(i=>`<path d="M${120+i*10} ${74-i*10} q4 -4 8 0 q4 4 8 0" stroke="${P.n}" stroke-width="2" fill="none" class="p-glow"/>`).join("")}`)+
 `<path d="M86 98 Q88 78 108 78 Q128 82 128 100 Q122 114 106 114 Q90 112 86 98 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",104,86,`<path d="M104 86 Q86 30 44 22 Q56 44 50 52 Q70 58 78 70 Q86 84 98 94 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${92-i*10} ${78-i*12} q-4 -4 -8 0 q-4 4 -8 0" stroke="${P.ac}" stroke-width="2.4" fill="none" class="p-glow"/>`).join("")}`)+
 pt("head",88,86,`<path d="M70 80 Q70 64 86 64 Q100 66 100 80 Q96 90 86 90 Q72 90 70 80 Z" fill="${P.n}" ${SW}/>`+pt("ear",90,66,`<path d="M86 66 Q84 50 92 44 Q92 54 98 50 Q100 60 94 68 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M70 78 L56 80 L70 82 Z" fill="${FMOUTH}"/>`+pt("beak",70,82,`<path d="M70 82 L56 81 L70 85 Z" fill="${P.b}" ${SW2}/>`)+`<path d="M72 74 L54 79 L72 78 Z" fill="${P.b}" ${SW2}/>${fE(82,76,3.8,{iris:"#FFE070",look:[-.4,0]})}`)+
 `<path d="M98 112 l-4 10 M106 112 l0 10" stroke="${FI}" stroke-width="2.4"/>`+
 fG(g,1,`<circle cx="30" cy="100" r="3" fill="${P.ac}" opacity=".7"/><circle cx="40" cy="116" r="2" fill="${P.ac}" opacity=".6"/>`)+
 fG(g,2,`<circle cx="106" cy="98" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(102,40,6)));
FORM_TITLE["Kanthal"]="Heatcoil Phoenix";

/* 137. Zicral (aluminium-zinc-magnesium: aircraft wings and climbing carabiners) — a swift, a pair of swept-back blades that never lands,
   banking and slicing, mouth gaping wide to scoop insects. */
addForm("Zicral",{n:"#3A3A44",a:"#F4F0E4",rn:"#E8D0B0",rb:"#3A8AC8",ra:"#E8604A"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",108,84,`<path d="M108 84 Q140 50 190 40 Q156 70 116 92 Z" fill="${P.nd}" ${SW}/>`)+
 pt("tail",128,92,`<path d="M124 88 L156 96 L144 98 L156 104 L124 98 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M76 92 Q80 80 104 80 Q126 82 130 94 Q120 104 102 104 Q82 102 76 92 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",100,90,`<path d="M100 90 Q72 118 14 130 Q56 104 92 84 Z" fill="${P.n}" ${SW}/><path d="M92 90 Q60 112 24 124" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 `<circle cx="132" cy="114" r="7" fill="none" stroke="${FI}" stroke-width="4"/><path d="M128 108 L136 108" stroke="${P.b}" stroke-width="3"/><circle cx="132" cy="114" r="7" fill="none" stroke="${P.b}" stroke-width="2"/><path d="M118 100 L128 108" stroke="${FI}" stroke-width="1.4"/>`+
 pt("head",84,90,`<path d="M66 90 Q66 78 80 78 Q92 80 92 90 Q88 98 78 98 Q68 98 66 90 Z" fill="${P.n}" ${SW}/><path d="M68 92 Q74 96 80 94" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
  `<path d="M66 88 L56 88 L66 94 Z" fill="${FMOUTH}"/>`+pt("beak",66,93,`<path d="M66 93 L56 90 L64 97 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M68 86 L56 88 L68 89 Z" fill="${P.nd}" ${SW2}/>${fE(76,86,3.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M30 60 l10 4 M24 70 l12 2" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,58,6)));
FORM_TITLE["Zicral"]="Carabiner Swift";

/* 138. Silumin (aluminium-silicon: cast engine blocks and housings) — a bulldog built like an engine block, cast-ribbed shoulders, bandy
   front legs, a jowly underbite that drops open to bark. */
addForm("Silumin",{n:"#E8D8C0",a:"#7A5A3A",rn:"#3A3A4A",rb:"#B04A3A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56)+
 pt("tail",146,100,`<path d="M144 98 Q152 92 150 86" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M144 98 Q152 92 150 86" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",134,114,28,9,P.nd,P.nd,.5)+
 `<path d="M72 104 Q70 74 104 72 Q140 76 148 102 Q142 122 108 122 Q76 120 72 104 Z" fill="${P.n}" ${SW}/>${[88,98,108].map(x=>`<path d="M${x} 76 L${x} 104" stroke="${P.b}" stroke-width="4" opacity=".7"/>`).join("")}<circle cx="128" cy="90" r="10" fill="${P.ac}" opacity=".6"/>`+
 pt("legF",116,118,fOL("M116 116 L118 144",P.n,9))+pt("legF",86,114,fOL("M86 112 L76 128 L82 144",P.n,10),.6)+
 pt("head",80,92,`<path d="M42 96 L72 98 L70 106 L46 104 Z" fill="${FMOUTH}"/>`+pt("jaw",72,104,`<path d="M72 104 Q58 120 40 106 L44 98 Q56 108 70 102 Z" fill="${P.n}" ${SW2}/><path d="M46 102 l2 -4 l2 4 M64 102 l2 -4 l2 4" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`)+
  `<path d="M40 92 Q40 66 62 64 Q86 66 88 92 Q84 100 64 100 Q44 100 40 92 Z" fill="${P.n}" ${SW}/><path d="M44 92 Q42 82 52 80 Q60 84 58 96 Q50 100 44 92 Z" fill="${P.ac}" opacity=".7"/><ellipse cx="42" cy="84" rx="4" ry="3" fill="${FI}"/>`+
  `<path d="M54 76 Q62 72 70 76" stroke="${P.nd}" stroke-width="2" fill="none"/>${fE(60,80,3.6,{iris:"#2A1A0A",look:[-.4,0]})}${fE(72,80,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",80,68,`<path d="M78 70 Q84 58 92 66 Q88 72 84 74 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<rect x="150" y="128" width="18" height="12" rx="2" fill="${P.b}" ${SW2}/><path d="M154 128 v-4 M164 128 v-4" stroke="${FI}" stroke-width="2"/>`)+
 fG(g,2,`<circle cx="108" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(112,56,6)));
FORM_TITLE["Silumin"]="Engine-Block Bulldog";

/* 139. Magnalium (aluminium-magnesium: firework sparkle and telescope mirrors) — a tarsier with enormous mirror-bright eyes, clinging to a
   stem, head swivelling right round, mouth open for a high squeak. */
addForm("Magnalium",{n:"#B89A7A",a:"#F2C94C",rn:"#C8D8F0",rb:"#7A4AA8",ra:"#E8604A"},"perch",(P,g)=>`<path d="M140 6 Q132 80 146 152" stroke="#6A4A2A" stroke-width="9" fill="none" stroke-linecap="round"/>${[[136,30],[136,60]].map(([x,y])=>`<ellipse cx="${x-12}" cy="${y}" rx="9" ry="4" fill="#5AA84A" ${SW2}/>`).join("")}`+
 pt("tail",126,120,fOL("M124 118 Q118 140 128 152",P.nd,3)+`<path d="M126 146 q4 6 4 10" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/>`)+
 pt("legB",120,106,fOL("M120 106 Q130 118 136 120",P.nd,6)+`<circle cx="138" cy="120" r="4" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M98 112 Q94 86 110 80 Q128 84 128 108 Q124 124 112 124 Q100 124 98 112 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",112,90,fOL("M112 90 Q124 84 134 86",P.n,5)+`<circle cx="136" cy="86" r="4" fill="${P.n}" ${SW2}/>`)+
 pt("armB",106,98,fOL("M106 98 Q122 102 134 100",P.nd,5),.4)+
 pt("head",108,80,`<path d="M80 66 Q80 40 106 38 Q130 40 130 66 Q128 86 106 88 Q82 86 80 66 Z" fill="${P.n}" ${SW}/>`+
  `${fE(94,62,11,{iris:P.ac,look:[-.2,0]})}${fE(118,62,10,{iris:P.ac,look:[-.2,0]})}<path d="M104 72 L108 72 L106 75 Z" fill="${FI}"/>`+
  `<path d="M100 78 L112 78 L110 81 L102 81 Z" fill="${FMOUTH}"/>`+pt("jaw",110,80,`<path d="M110 80 Q106 86 102 80 Q106 83 110 83 Z" fill="${P.nl}" ${SW2}/>`)+
  pt("ear",84,46,`<path d="M84 48 Q72 34 82 28 Q92 34 92 44 Z" fill="${P.nl}" ${SW2}/>`)+pt("ear",126,44,`<path d="M124 46 Q130 30 140 34 Q138 46 128 50 Z" fill="${P.nl}" ${SW2}/>`,.4))+
 fG(g,1,`${star(40,40,3.4,"#FFE070")}${star(54,24,2.6,"#FF8AD0")}${star(30,64,2.4,"#5FE0F0")}`)+
 fG(g,2,`<circle cx="112" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(70,98,6)));
FORM_TITLE["Magnalium"]="Mirror-Eyed Tarsier";

/* 140. Y Alloy (aluminium-copper-nickel-magnesium: pistons) — an ostrich whose long legs pump like pistons, wings flapping for balance,
   neck pumping, beak open to boom. */
addForm("Y Alloy",{n:"#2A2A30",a:"#F4F0E4",rn:"#E8C8A8",rb:"#3A8A6A",ra:"#E8604A"},"stand",(P,g)=>fShadow(40,112)+
 pt("legB",118,98,`<rect x="114" y="98" width="9" height="22" rx="2" fill="${P.b}" ${SW2}/>`+fOL("M118 118 L122 144","#E8A090",4)+`<path d="M116 144 h10" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 pt("tail",142,84,`<path d="M138 78 Q160 66 166 84 Q158 96 140 92 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M90 86 Q92 62 118 62 Q146 66 146 88 Q140 104 118 104 Q94 104 90 86 Z" fill="${P.n}" ${SW}/>${[[100,74],[116,70],[132,76],[108,88],[126,90]].map(([x,y])=>`<path d="M${x} ${y} q4 4 0 8" stroke="${P.nl}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("wingF",116,76,`<path d="M110 72 Q140 66 152 86 Q132 94 114 86 Z" fill="${P.n}" ${SW2}/><path d="M140 80 Q150 82 152 86" stroke="${P.ac}" stroke-width="4" fill="none"/>`)+
 pt("legF",104,100,`<rect x="100" y="98" width="9" height="22" rx="2" fill="${P.b}" ${SW2}/>`+fOL("M104 118 L100 144","#E8A090",4)+`<path d="M94 144 h10" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 pt("head",96,76,fOL("M98 78 Q84 56 86 30",'#E8A090',6)+
  `<path d="M74 28 Q74 16 86 16 Q96 18 96 28 Q92 36 84 36 Q76 34 74 28 Z" fill="#E8A090" ${SW}/>`+
  `<path d="M74 26 L60 28 L74 30 Z" fill="${FMOUTH}"/>`+pt("beak",74,30,`<path d="M74 30 L60 29 L74 33 Z" fill="${P.d}" ${SW2}/>`)+`<path d="M76 24 L58 28 L76 27 Z" fill="${P.d}" ${SW2}/>${fE(84,24,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,`<path d="M150 134 h24 M154 142 h18" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="118" cy="94" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(128,40,6)));
FORM_TITLE["Y Alloy"]="Piston Ostrich";

/* 141. Birmabright (aluminium-magnesium: the rust-proof bodies of early off-road cars) — a dromedary camel trekking over dunes, hump
   swaying, knobbly knees, lips flapping as it grumbles. */
addForm("Birmabright",{n:"#D8A868",a:"#7A4A2A",rn:"#B8C8E0",rb:"#3A6A4A",ra:"#E8412C"},"stand",(P,g)=>`<path d="M10 146 Q60 134 110 144 Q150 152 190 140" stroke="#E8C878" stroke-width="5" fill="none" stroke-linecap="round"/>`+fShadow(54,112)+
 pt("tail",154,88,fOL("M154 88 Q162 100 158 116",P.nd,3))+
 fLeg("legB",144,100,42,7,P.nd,P.ndd,.5)+fLeg("legB",108,102,40,7,P.nd,P.ndd,1.3)+
 `<path d="M92 96 Q94 76 122 76 Q152 78 156 96 Q150 112 122 112 Q96 112 92 96 Z" fill="${P.n}" ${SW}/>`+
 pt("sway",124,76,`<path d="M106 80 Q114 48 128 48 Q144 50 146 80 Z" fill="${P.n}" ${SW}/><path d="M112 74 Q120 56 134 56" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/><rect x="112" y="72" width="30" height="8" rx="2" fill="${P.b}" ${SW2}/>`)+
 [[136,104],[100,104]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x} ${y+20} L${x-2} ${y+40}`,P.n,7)+`<circle cx="${x}" cy="${y+20}" r="4.6" fill="${P.nd}" ${SW2}/>`,i*.8)).join("")+
 pt("head",96,90,fOL("M98 94 Q74 92 72 70 Q72 58 66 54",P.n,10)+
  `<path d="M38 56 L52 58 L50 62 L40 60 Z" fill="${FMOUTH}"/>`+pt("jaw",52,62,`<path d="M52 62 Q44 70 36 62 Q44 66 52 66 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M36 54 Q38 42 54 40 Q70 42 72 52 Q68 62 54 60 Q40 62 36 54 Z" fill="${P.n}" ${SW}/><path d="M36 54 Q40 52 44 56" stroke="${FI}" stroke-width="1.6" fill="none"/>${fE(58,48,3.8,{iris:"#2A1A0A",look:[-.4,0],lid:.35,lidC:P.n})}`+
  pt("ear",66,42,`<path d="M64 44 Q66 36 72 40 Q70 46 66 48 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="30" r="8" fill="#F2C94C" opacity=".6"/>`)+
 fG(g,2,`<circle cx="124" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(126,32,6)));
FORM_TITLE["Birmabright"]="Trekking Camel";

/* 142. Elektron (magnesium alloy: racing wheels) — a ferret tearing round a race track, long body undulating, racing-stripe mask, jaws
   open in a chattering war-dance. */
addForm("Elektron",{n:"#F0E4C8",a:"#3A2A24",rn:"#C8B8E8",rb:"#E8412C",ra:"#2FA060"},"slink",(P,g)=>fShadow(74)+
 `<circle cx="160" cy="132" r="13" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="160" cy="132" r="13" fill="none" stroke="${P.b}" stroke-width="3"/>${[0,1,2,3,4].map(i=>`<path d="M160 132 L${160+Math.cos(i*1.257)*11} ${132+Math.sin(i*1.257)*11}" stroke="${P.b}" stroke-width="2"/>`).join("")}`+
 pt("tail",150,112,fOL("M148 112 Q170 104 182 110",P.ac,7))+
 fLeg("legB",136,120,20,7,P.ac,P.ac,.4)+fLeg("legB",104,122,18,7,P.ac,P.ac,1.1)+
 `<path d="M56 112 Q60 94 100 92 Q140 92 152 112 Q144 126 100 126 Q62 126 56 112 Z" fill="${P.n}" ${SW}/><path d="M70 100 Q100 94 140 104" stroke="${P.b}" stroke-width="4" fill="none" stroke-linecap="round"/>`+
 fLeg("legF",126,122,18,7,P.ac,P.ac,0)+fLeg("legF",76,120,20,7,P.ac,P.ac,.7)+
 pt("head",62,104,`<path d="M22 108 L42 110 L40 114 L26 112 Z" fill="${FMOUTH}"/><path d="M28 109 l1.6 3 l1.6 -3" fill="#FFFFFF"/>`+pt("jaw",42,113,`<path d="M42 113 Q32 120 22 112 Q32 116 42 116 Z" fill="${P.n}" ${SW2}/>`)+
  `<path d="M20 104 Q22 88 42 86 Q62 88 64 104 Q60 114 42 112 Q24 112 20 104 Z" fill="${P.n}" ${SW}/><path d="M28 96 Q42 90 58 98 L56 104 Q42 98 30 102 Z" fill="${P.ac}"/><ellipse cx="20" cy="104" rx="3" ry="2.4" fill="#F0A0A8" ${SW2}/>`+
  `${fE(42,98,3.6,{iris:"#2A1A0A",look:[-.4,0]})}`+pt("ear",56,88,`<circle cx="56" cy="88" r="4.4" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M10 80 h14 M6 88 h18" stroke="${P.b}" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="102" cy="110" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(104,72,6)));
FORM_TITLE["Elektron"]="Racetrack Ferret";

/* 143. Zamak (zinc-aluminium: die-cast toy cars and zip pulls) — a clockwork mouse with a wind-up key in its back that turns and turns,
   whirring across the floor on little wheels, whiskers twitching. */
addForm("Zamak",{n:"#B8BCC4",a:"#F0A0A8",rn:"#F2D890",rb:"#3A8AC8",ra:"#E8412C"},"crawl",(P,g)=>fShadow(56)+
 pt("tail",146,118,fOL("M146 118 Q170 124 176 110 Q180 98 170 96",P.ac,3))+
 `<path d="M60 124 Q62 90 104 88 Q144 92 150 124 Z" fill="${P.n}" ${SW}/><path d="M70 110 Q104 96 140 110" stroke="${P.b}" stroke-width="3" fill="none"/>${[[84,118],[104,116],[124,118]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.d}"/>`).join("")}`+
 [[84,128],[128,128]].map(([x,y],i)=>pt("spin",x,y,`<circle cx="${x}" cy="${y}" r="9" fill="${FI}"/><circle cx="${x}" cy="${y}" r="5" fill="${P.b}"/><path d="M${x-5} ${y} h10" stroke="${FI}" stroke-width="1.6"/>`)).join("")+
 pt("spin",108,84,`<rect x="106" y="74" width="4" height="12" fill="${P.d}" ${SW2}/><path d="M96 68 Q96 60 104 64 L108 72 L112 64 Q120 60 120 68 Q120 76 108 74 Q96 76 96 68 Z" fill="${P.b}" ${SW}/>`)+
 pt("head",66,110,`<path d="M24 112 Q30 92 54 92 Q72 96 72 114 Q60 122 42 120 Z" fill="${P.n}" ${SW}/><circle cx="24" cy="112" r="4" fill="${P.ac}" ${SW2}/>`+
  `<path d="M28 116 L40 118 L38 120 Z" fill="${FMOUTH}"/>`+pt("jaw",40,119,`<path d="M40 119 L30 118 L34 122 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M32 110 l-12 -6 M32 112 l-12 0 M32 114 l-12 6" stroke="${FI}" stroke-width="1"/>${fE(46,104,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",58,94,`<circle cx="58" cy="90" r="10" fill="${P.n}" ${SW2}/><circle cx="58" cy="90" r="5.6" fill="${P.ac}"/>`))+
 fG(g,1,`<path d="M170 140 l8 -4 M172 146 l10 0" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(132,64,6)));
FORM_TITLE["Zamak"]="Clockwork Mouse";

/* 144. Kirksite (zinc-aluminium-copper: cheap dies for stamping) — a rabbit that stamps a warning with its great hind foot, ears swivelling,
   nose twitching, teeth bared in a growl. */
addForm("Kirksite",{n:"#9A8A7A",a:"#F4F0E4",rn:"#E8C8D8",rb:"#2E5A8A",ra:"#F2C94C"},"hop",(P,g)=>fShadow(48,108)+
 pt("tail",138,112,`<circle cx="140" cy="110" r="8" fill="${P.ac}" ${SW2}/>`)+
 pt("legB",124,116,`<path d="M110 104 Q136 102 136 122 L130 128 Z" fill="${P.n}" ${SW}/>`+fOL("M128 124 L122 142 L94 144",P.nd,8)+`<rect x="86" y="140" width="22" height="7" rx="2" fill="${P.b}" ${SW2}/>`)+
 `<path d="M82 122 Q76 92 98 84 Q122 86 128 112 Q126 130 106 132 Q88 132 82 122 Z" fill="${P.n}" ${SW}/><path d="M88 124 Q86 104 96 98 Q106 106 104 128 Z" fill="${P.ac}"/>`+
 fLeg("legF",92,124,18,5,P.n,P.n,0)+
 pt("head",94,84,`<path d="M62 78 Q62 58 82 56 Q102 58 102 78 Q98 92 82 92 Q66 92 62 78 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M60 82 L74 82 L72 86 L62 86 Z" fill="${FMOUTH}"/><rect x="64" y="82" width="5" height="4" fill="#FFFFFF" ${SW2}/>`+pt("jaw",72,86,`<path d="M72 86 Q66 92 60 86 Q66 90 72 88 Z" fill="${P.ac}" ${SW2}/>`)+
  `<ellipse cx="62" cy="78" rx="3" ry="2.4" fill="#F0A0A8" ${SW2}/>${fE(78,72,4.4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",86,58,`<path d="M82 60 Q76 26 86 22 Q96 26 92 60 Z" fill="${P.n}" ${SW2}/><path d="M86 56 Q82 32 87 28" stroke="#F0A0A8" stroke-width="3" fill="none"/>`)+pt("ear",94,60,`<path d="M90 62 Q98 30 110 32 Q112 42 98 64 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<path d="M80 150 l-8 -4 M110 150 l8 -4" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(124,48,6)));
FORM_TITLE["Kirksite"]="Stamping Rabbit";

/* 145. Magnox (magnesium with a touch of aluminium: the cladding round nuclear fuel rods) — a stick insect that is all clad rods, swaying
   like a twig in the breeze, forelegs held out together, mandibles nibbling. */
addForm("Magnox",{n:"#7A9A5A",a:"#9FE8D0",rn:"#E8C8A0",rb:"#4A3A8A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M180 30 Q170 90 186 150" stroke="#6A4A2A" stroke-width="8" fill="none" stroke-linecap="round"/><ellipse class="shd" cx="100" cy="150" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 [[140,92],[120,94],[100,94]].map(([x,y],i)=>pt("legB",x,y,fOL(`M${x} ${y} L${x+6} ${y-20} L${x+20} ${y+40}`,P.nd,2.6),i*.3)).join("")+
 pt("sway",176,90,`<rect x="60" y="86" width="116" height="10" rx="5" fill="${P.n}" ${SW}/>${[80,100,120,140,160].map(x=>`<path d="M${x} 86 v10" stroke="${P.b}" stroke-width="3"/>`).join("")}<path d="M64 89 H172" stroke="${P.ac}" stroke-width="1.4" opacity=".6" class="p-glow"/>`)+
 [[110,94],[86,94]].map(([x,y],i)=>pt("legF",x,y,fOL(`M${x} ${y} L${x-6} ${y-16} L${x-14} ${y+48}`,P.n,2.6),i*.3)).join("")+
 pt("armF",64,90,fOL("M64 90 L20 82",P.n,2.6)+fOL("M64 92 L22 88",P.nd,2.4))+
 pt("head",64,92,`<ellipse cx="56" cy="90" rx="10" ry="6" fill="${P.n}" ${SW}/>${fE(54,88,2.8,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ant",50,86,`<path d="M50 86 L30 70" stroke="${FI}" stroke-width="1.4"/>`)+
  `<path d="M44 92 L50 92 L48 95 Z" fill="${FMOUTH}"/>`+pt("jaw",48,94,`<path d="M48 94 L42 94 L46 97 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<ellipse cx="160" cy="40" rx="10" ry="4" fill="#5AA84A" ${SW2}/>`)+
 fG(g,2,`<circle cx="120" cy="91" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(118,60,6)));
FORM_TITLE["Magnox"]="Cladrod Stick Insect";
