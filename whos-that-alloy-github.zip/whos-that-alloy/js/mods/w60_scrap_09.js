/* ---- Tinker's Scrapyard, 9 ---- */
/* Egg Hunt Special: Easter egg hunters found a sample in a nest where the eggs should have been. A bilby, long-eared, hunting through a nest of painted eggs. */
addForm("Egg Hunt Special",{n:"#A8A0A8",a:"#E8A0B0",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M120 142 Q120 122 152 120 Q186 122 186 142 Z" fill="#8A6A3A" ${SW}/>${[[140,128,"#E8604A"],[156,124,"#5AB0E8"],[172,128,"#F2C94C"]].map(([x,y,c])=>`<ellipse cx="${x}" cy="${y}" rx="7" ry="9" fill="${c}" ${SW2}/><path d="M${x-6} ${y} q6 -4 12 0" stroke="#fff" stroke-width="1.6" fill="none"/>`).join("")}`+fShadow(60)+
 pt("tail",118,118,`<path d="M114 118 Q134 116 138 104" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M114 118 Q134 116 138 104" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M136 106 l2 -8" stroke="#F4F0F4" stroke-width="5" stroke-linecap="round"/>`)+
 pt("legB",110,128,fOL("M108 124 Q122 128 120 138 L128 142",P.nd,7),.5)+
 `<path d="M68 124 Q66 98 92 94 Q116 98 116 122 Q110 136 92 136 Q72 136 68 124 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",78,130,fOL("M80 126 L72 140 H62",P.n,6))+
 pt("head",70,104,`<path d="M42 108 Q44 92 60 90 Q76 92 78 106 Q74 118 60 118 L46 116 Z" fill="${P.n}" ${SW}/><path d="M44 110 L30 112 Q28 116 32 118 L46 116 Z" fill="${P.n}" ${SW2}/><circle cx="30" cy="116" r="2.4" fill="#E89AA8"/>${E2(58,102,3.4,"#1A1A1A")}`+HMOUTH(36,116,44,P,1.4)+
  pt("ear",62,90,`<path d="M58 92 Q52 60 62 52 Q72 62 68 92 Z" fill="${P.n}" ${SW2}/><path d="M61 86 Q58 66 62 60" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+pt("ear",70,92,`<path d="M66 92 Q72 62 86 56 Q88 72 74 94 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M20 120 h20 v20 h-20 Z" fill="#E8B0C0" ${SW2}/><path d="M20 126 h20 M30 120 v20" stroke="#F2C94C" stroke-width="2"/>`)+fG(g,2,`<circle cx="92" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Egg Hunt Special"]="Egg-Hunt Bilby";SM("Egg Hunt Special","Hide And Seek","RES","s",0,100,"acc+1,heal:20","Behind the shed, under the bench, in the bird's nest.");

/* Egg-and-Spoon Metal: one of four mystery prizes at the village fete. A puffin running the egg-and-spoon race, egg wobbling. */
addForm("Egg-and-Spoon Metal",{n:"#2A2A30",a:"#F4F0F4",rn:"#E8D8C8",rb:"#E8604A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 142 H194" stroke="#5A9A3A" stroke-width="6"/><path d="M170 142 V110 M170 110 h20" stroke="#F4F0F4" stroke-width="3"/>`+fShadow(54)+
 pt("legB",112,122,`<path d="M112 120 L120 136 H128" stroke="#E8604A" stroke-width="5" fill="none" stroke-linecap="round"/>`,.0)+
 `<path d="M84 122 Q80 88 104 82 Q128 88 126 122 Q120 136 104 136 Q88 136 84 122 Z" fill="${P.n}" ${SW}/><path d="M92 120 Q92 98 104 94 Q116 98 116 120 Q112 132 104 132 Q96 132 92 120 Z" fill="${P.ac}"/>`+
 pt("legF",96,122,`<path d="M96 120 L86 136 H76" stroke="#E8604A" stroke-width="5" fill="none" stroke-linecap="round"/>`,.5)+
 pt("wingF",88,100,`<path d="M88 98 Q72 94 62 86" stroke="${P.n}" stroke-width="8" stroke-linecap="round"/><path d="M62 86 L40 82" stroke="#C8C8D0" stroke-width="3" stroke-linecap="round"/><ellipse cx="34" cy="80" rx="8" ry="4" fill="#C8C8D0" ${SW2}/><ellipse cx="34" cy="74" rx="6" ry="7" fill="#F4F0F4" ${SW2}/>`)+
 pt("head",104,72,`<circle cx="104" cy="68" r="15" fill="${P.n}" ${SW}/><path d="M92 66 Q92 56 102 56 Q110 58 110 70 Q104 80 94 76 Z" fill="${P.ac}"/>${E2(100,64,3,"#1A1A1A")}<path d="M96 62 l6 0" stroke="#C8302A" stroke-width="1.6"/>`+
  `<path d="M90 66 Q78 66 76 76 L90 74 Z" fill="${FMOUTH}"/>`+pt("beak",84,76,`<path d="M90 74 Q82 82 76 78 Q82 76 90 72 Z" fill="#E8604A" ${SW2}/>`)+`<path d="M90 62 Q76 60 74 74 Q82 68 90 68 Z" fill="#E8604A" ${SW2}/><path d="M80 64 v8" stroke="#F2C94C" stroke-width="2"/>`)+
 fG(g,1,`<rect x="20" y="30" width="22" height="22" rx="11" fill="#5AB0E8" ${SW2}/><text x="26" y="45" font-size="10" font-weight="bold" fill="#fff">1</text>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Egg-and-Spoon Metal"]="Egg-and-Spoon Puffin";SM("Egg-and-Spoon Metal","Steady Hand","RES","s",0,100,"acc+2","Don't drop it. Don't drop it. Don't drop it.");

/* Elinvar: invented by the Invar laureate so watch springs keep time in any weather. A seahorse whose curled tail is a watch hairspring. */
addForm("Elinvar",{n:"#C8A060",a:"#5AB0C8",rn:"#3A3A4A",rb:"#E8604A",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="20" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",108,108,`<path d="M108 100 Q118 120 108 128 Q96 134 92 124 Q90 116 98 116 Q104 118 102 122 Q100 126 96 124" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M108 100 Q118 120 108 128 Q96 134 92 124 Q90 116 98 116 Q104 118 102 122 Q100 126 96 124" stroke="${P.b}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("wingF",118,74,`<path d="M118 70 Q132 66 134 78 Q126 84 118 80 Z" fill="${P.ac}" opacity=".7" ${SW2}/>`)+
 `<path d="M96 104 Q86 86 96 66 Q106 56 116 64 Q124 82 112 104 Q104 110 96 104 Z" fill="${P.n}" ${SW}/>${[70,78,86,94,102].map(y=>`<path d="M${98-(y-70)*.08} ${y} q8 3 14 0" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}<path d="M112 66 l6 -4 l-2 6 l6 -2 l-4 6" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 pt("head",102,52,`<path d="M96 66 Q90 48 102 40 Q114 40 114 56 Q112 64 104 64 Z" fill="${P.n}" ${SW}/><path d="M98 48 L72 50 L72 56 L98 56 Z" fill="${P.n}" ${SW}/>${E2(104,50,3.6,"#1A1A1A")}`+pt("jaw",72,53,`<ellipse cx="72" cy="53" rx="2.4" ry="3" fill="${FMOUTH}"/>`)+`<path d="M104 40 l2 -8 l4 6 l4 -6" stroke="${P.n}" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<circle cx="30" cy="40" r="12" fill="none" stroke="${P.b}" stroke-width="2"/><path d="M30 40 m0 -8 a8 8 0 1 1 -6 2 a5 5 0 1 1 6 2" stroke="${P.b}" stroke-width="1.2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Elinvar"]="Hairspring Seahorse";SM("Elinvar","Keep Time","RES","s",0,100,"acc+1,ward+1","Hot or cold, it keeps exactly the same beat.");

/* Empty Pen Metal: approved because the other pen ran dry mid-signature. A rhinoceros iguana whose horn is a fountain-pen nib, run out of ink. */
addForm("Empty Pen Metal",{n:"#6A6A74",a:"#2A3A8A",rn:"#3A3A4A",rb:"#C8A040",ra:"#E8412C"},"crawl",(P,g)=>fShadow(72)+
 pt("tail",156,118,`<path d="M150 116 Q176 116 190 128" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M150 116 Q176 116 190 128" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 [[140,"legB",.5],[102,"legB",1.3]].map(([x,c,d])=>pt(c,x,124,fOL(`M${x} 122 L${x+8} 136 L${x+14} 140`,P.nd,7),d)).join("")+
 `<path d="M74 118 Q76 98 114 96 Q148 98 154 116 Q148 130 114 130 Q78 130 74 118 Z" fill="${P.n}" ${SW}/>${[84,96,108,120,132,144].map(x=>`<path d="M${x} 98 l3 -7 l3 7" fill="${P.nd}" ${SW2}/>`).join("")}`+
 [[130,"legF",0],[90,"legF",.8]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x-8} 138 L${x-14} 141`,P.n,7),d)).join("")+
 pt("head",76,108,`<path d="M38 112 Q40 94 60 92 Q78 94 80 108 Q74 122 58 122 Z" fill="${P.n}" ${SW}/>${E2(60,104,3.6,"#C8302A")}<path d="M46 96 L38 72 L54 92 Z" fill="${P.b}" ${SW}/><path d="M46 92 L42 78" stroke="${FI}" stroke-width="1.4"/><circle cx="46" cy="90" r="2" fill="${FI}"/>`+HMOUTH(40,116,50,P,2))+
 fG(g,1,`<path d="M150 30 h20 l-4 16 h-12 Z" fill="#C8E0F0" opacity=".6" ${SW2}/><path d="M154 44 h12" stroke="${P.ac}" stroke-width="2"/>`)+fG(g,2,`<circle cx="114" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Empty Pen Metal"]="Nib-Horned Iguana";SM("Empty Pen Metal","Dry Nib","SCR","a",70,100,"tdef-1@30","Scratch, scratch. Nothing comes out, but it still hurts.");

/* Encore Metal: the fiddler vanished before the hoedown; a crate appeared on her chair. A violin beetle, the beetle shaped just like a fiddle. */
addForm("Encore Metal",{n:"#B8804A",a:"#3A2A20",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 [0,1,2].map(i=>pt("legB",118+i*8,118,`<path d="M${118+i*8} 118 L${130+i*12} 104 L${140+i*12} 140" stroke="${FI}" stroke-width="3" fill="none" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M150 116 Q168 104 172 116 Q168 128 150 116 Z M150 116 Q166 98 156 92" fill="${P.n}" ${SW}/>`+
 `<path d="M82 116 Q82 98 100 100 Q112 92 124 100 Q144 98 150 116 Q144 134 124 132 Q112 140 100 132 Q82 134 82 116 Z" fill="${P.n}" ${SW}/><path d="M102 110 q4 4 0 8 M124 110 q-4 4 0 8" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${[0,1,2,3].map(i=>`<path d="M${84+i*1} ${114+i*1.4} H150" stroke="#E8E0C0" stroke-width=".8"/>`).join("")}`+
 [0,1].map(i=>pt("legF",96+i*8,120,`<path d="M${96+i*8} 120 L${84+i*6} 106 L${74+i*8} 140" stroke="${FI}" stroke-width="3" fill="none" stroke-linejoin="round"/>`,i*.2+.1)).join("")+
 pt("head",80,110,`<path d="M54 112 L82 112" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M54 112 L82 112" stroke="${P.nd}" stroke-width="4" stroke-linecap="round"/><path d="M40 108 Q42 100 52 104 Q56 112 52 120 Q42 124 40 116 Z" fill="${P.nd}" ${SW}/>${E2(48,110,3,"#1A1A1A")}`+pt("ant",44,102,`<path d="M44 102 Q38 90 30 88 M48 102 Q50 88 58 84" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<path d="M150 40 v-14 l8 3 M164 46 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="148" cy="40" r="3" fill="${P.ac}"/><circle cx="162" cy="46" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="114" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Encore Metal"]="Fiddle Beetle";SM("Encore Metal","Encore","RES","a",60,100,"multi:1-2","They want another one. Of course they do.");

/* Endless Queue Metal: your application will be processed in the order it arrived. A millipede whose every segment is a waiting ticket. */
addForm("Endless Queue Metal",{n:"#E8D8A8",a:"#3A3A40",rn:"#3A3A4A",rb:"#C8302A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(80)+
 Array.from({length:10},(_,i)=>{const x=164-i*12,y=124-Math.sin(i*.6)*6;return pt(i%2?"legB":"legF",x,y+8,`<path d="M${x-3} ${y+8} l-2 10 M${x+3} ${y+8} l2 10" stroke="${FI}" stroke-width="1.6"/>`,i*.1)+`<rect x="${x-6}" y="${y-8}" width="12" height="16" rx="2" fill="${P.n}" ${SW2}/><text x="${x-4}" y="${y+3}" font-size="5.6" font-weight="bold" fill="${FI}">${40+i}</text>`}).join("")+
 pt("head",42,120,`<circle cx="42" cy="120" r="12" fill="${P.n}" ${SW}/>${E2(38,116,3.4)}${E2(48,116,3.2)}<path d="M36 126 q6 -3 12 0" stroke="${FI}" stroke-width="2" fill="none"/>`+pt("ant",42,108,`<path d="M38 108 Q32 96 26 94 M46 108 Q50 96 56 94" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<rect x="150" y="30" width="34" height="18" rx="2" fill="${FI}"/><text x="154" y="43" font-size="10" font-weight="bold" fill="#C8302A" font-family="monospace">#12</text>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Endless Queue Metal"]="Ticket-Queue Millipede";SM("Endless Queue Metal","Please Hold","RES","s",0,100,"tspd-2","Your call is important. Please continue to hold.");

/* Enoughium: the randomiser's last pick before it was unplugged for good. A gumball machine come to life, a sample among the gumballs. */
addForm("Enoughium",{n:"#C8302A",a:"#E8E8F0",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(54)+
 pt("legB",116,134,`<rect x="112" y="130" width="10" height="12" rx="2" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M84 136 L88 98 H120 L124 136 Z" fill="${P.n}" ${SW}/><rect x="96" y="112" width="16" height="14" rx="2" fill="#C8C8D0" ${SW2}/><circle cx="104" cy="119" r="4" fill="${P.b}" ${SW2}/><path d="M100 128 h8 v6 h-8 Z" fill="#3A3A44"/>`+
 pt("head",104,64,`<circle cx="104" cy="64" r="34" fill="${P.ac}" opacity=".6" ${SW}/>${[[88,58,"#E8412C"],[102,48,"#5AB0E8"],[118,58,"#F2C94C"],[94,74,"#5AB04A"],[112,76,"#E8A0C0"],[104,62,"#B8B8C0"],[84,44,"#F2C94C"],[122,42,"#E8412C"]].map(([x,y,c])=>`<circle cx="${x}" cy="${y}" r="6" fill="${c}" ${SW2}/>`).join("")}<path d="M84 44 Q92 36 104 34" stroke="#fff" stroke-width="3" fill="none" opacity=".7"/>${E2(94,68,4.4)}${E2(114,68,4.4)}`+HMOUTH(98,80,110,P,2.4)+`<rect x="98" y="26" width="12" height="6" rx="2" fill="${P.n}" ${SW2}/>`)+
 `<rect x="84" y="94" width="40" height="8" rx="3" fill="${P.n}" ${SW2}/>`+
 pt("legF",92,134,`<rect x="86" y="130" width="10" height="12" rx="2" fill="${P.n}" ${SW2}/>`)+
 pt("armF",86,116,fOL("M86 116 Q72 118 68 128",P.n,5))+pt("armB",122,116,fOL("M122 116 Q136 110 140 100",P.n,5),.4)+
 fG(g,1,`<path d="M150 136 h20" stroke="${FI}" stroke-width="3"/><path d="M168 136 q10 0 10 -8" stroke="${FI}" stroke-width="2" fill="none"/><rect x="176" y="122" width="6" height="8" fill="#C8C8D0" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="119" r="2" fill="${P.ll}"/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Enoughium"]="Gumball-Machine Golem";SM("Enoughium","Random Pick","RES","a",50,100,"multi:1-4","Turn the handle. Who knows what comes out.");

/* Erratium: four pages of catalogue listing, three of them corrections. A hornbill with a red pen, editing the casque on its own beak. */
addForm("Erratium",{n:"#2A2A30",a:"#F4F0E4",rn:"#E8D8C8",rb:"#C8302A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M40 124 H170" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",128,110,`<path d="M122 104 L152 128 L144 134 L118 112 Z" fill="${P.ac}" ${SW}/><path d="M132 114 l12 10" stroke="${FI}" stroke-width="3"/>`)+
 `<path d="M86 114 Q84 84 106 80 Q128 84 128 114 Q120 124 106 124 Q92 124 86 114 Z" fill="${P.n}" ${SW}/><path d="M88 112 Q100 122 116 118 Q106 108 96 102 Z" fill="${P.ac}"/>`+
 pt("legF",102,122,`<path d="M100 122 l-2 4 M106 122 l2 4" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",94,74,`<circle cx="94" cy="72" r="14" fill="${P.n}" ${SW}/>${E2(92,70,3.2,"#E8C040")}<path d="M88 62 Q94 58 100 62" stroke="#3AA8E8" stroke-width="2" fill="none"/>`+
  `<path d="M82 74 Q58 80 46 96 L80 82 Z" fill="${FMOUTH}"/>`+pt("beak",64,86,`<path d="M80 82 Q60 90 48 98 Q64 86 80 78 Z" fill="#E8C040" ${SW2}/>`)+`<path d="M82 66 Q56 66 42 92 Q60 76 82 74 Z" fill="#E8C040" ${SW2}/><path d="M80 64 Q66 54 50 66 Q64 62 78 70 Z" fill="#E8A040" ${SW2}/><path d="M56 60 L70 70 M62 58 L66 68" stroke="#C8302A" stroke-width="1.6"/>`)+
 pt("wingF",104,98,`<path d="M100 94 Q84 84 74 74" stroke="${P.n}" stroke-width="7" stroke-linecap="round"/><path d="M76 74 L62 52" stroke="#C8302A" stroke-width="4" stroke-linecap="round"/><path d="M62 52 l-2 -4" stroke="${FI}" stroke-width="2"/>`)+
 fG(g,1,`<rect x="150" y="30" width="30" height="26" fill="#F4F0E4" ${SW2}/>${[36,42,48].map(y=>`<path d="M154 ${y} h22" stroke="#8A8A9A" stroke-width="1"/><path d="M153 ${y-1} l24 2" stroke="#C8302A" stroke-width="1"/>`).join("")}`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Erratium"]="Red-Pen Hornbill";SM("Erratium","Correction","RES","s",0,100,"cure,tacc-1","Strike that. And that. And actually, all of that.");

/* Evanohm: wound into precision resistors for measuring instruments. A pike whose jaw is a vernier calliper, measuring everything it bites. */
addForm("Evanohm",{n:"#6A8A5A",a:"#C8C8D0",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"swim",(P,g)=>`<ellipse class="shd" cx="110" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",164,84,`<path d="M156 84 L182 64 L178 84 L184 104 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",146,70,`<path d="M140 72 L150 56 L158 74 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M60 84 Q66 70 104 68 Q144 70 158 84 Q144 98 104 100 Q66 100 60 84 Z" fill="${P.n}" ${SW}/>${[[90,78],[110,76],[130,80],[100,90],[122,92]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="4" ry="2" fill="#E8C060" opacity=".7"/>`).join("")}`+
 pt("wingF",112,96,`<path d="M110 98 L100 116 L120 102 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",62,84,`<path d="M66 76 L20 78 L20 84 L66 84 Z" fill="${P.ac}" ${SW}/>${Array.from({length:10},(_,i)=>`<path d="M${24+i*4} 78 v3" stroke="${FI}" stroke-width="1"/>`).join("")}${E2(70,78,3.6,"#E8C060")}`+
  pt("jaw",42,90,`<path d="M66 86 L24 88 L24 94 L66 92 Z" fill="${P.ac}" ${SW2}/>${Array.from({length:8},(_,i)=>`<path d="M${28+i*4} 92 v-3" stroke="${FI}" stroke-width="1"/>`).join("")}`))+
 fG(g,1,`<text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}">0.01 mm</text>`)+fG(g,2,`<circle cx="110" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Evanohm"]="Calliper-Jawed Pike";SM("Evanohm","Precise Bite","SCR","a",65,100,"crit,acc+1","Measured to the hundredth of a millimetre, then bitten.");

/* Extra Cycle Blend: every night the mixer ran one extra cycle nobody programmed. A greyhound running one more lap than the race asked for. */
addForm("Extra Cycle Blend",{n:"#9A9AA4",a:"#F4F0F4",rn:"#3A3A4A",rb:"#C8302A",ra:"#5FE0F0"},"slink",(P,g)=>`<ellipse cx="104" cy="138" rx="86" ry="10" fill="none" stroke="#C8B890" stroke-width="5"/>`+fShadow(72)+
 pt("tail",162,92,`<path d="M158 94 Q180 100 186 120" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M158 94 Q180 100 186 120" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
 pt("legB",146,104,`<path d="M146 102 L164 118 L174 128" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M146 102 L164 118 L174 128" stroke="${P.nd}" stroke-width="4.4" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,.0)+
 `<path d="M86 92 Q90 78 116 80 Q140 82 156 96 Q150 108 126 106 Q100 104 86 92 Z" fill="${P.n}" ${SW}/><path d="M100 86 L132 88 L130 100 L102 98 Z" fill="#C8302A" ${SW2}/><text x="110" y="97" font-size="8" font-weight="bold" fill="#fff">6</text>`+
 pt("legF",96,98,`<path d="M96 96 L74 104 L56 100" stroke="${FI}" stroke-width="7" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M96 96 L74 104 L56 100" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,.5)+
 pt("head",86,86,`<path d="M88 90 Q76 82 70 74" stroke="${P.n}" stroke-width="11" stroke-linecap="round"/><path d="M34 72 Q40 62 58 62 Q74 64 76 74 Q72 82 56 82 Q42 82 34 72 Z" fill="${P.n}" ${SW}/><circle cx="35" cy="72" r="2.4" fill="${FI}"/>${E2(60,70,3.2,"#3A2410")}`+HMOUTH(38,76,48,P,1.6)+pt("ear",68,64,`<path d="M66 64 Q76 56 84 62 Q78 68 70 68 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}">LAP 11/10</text>`)+fG(g,2,`<circle cx="120" cy="94" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Extra Cycle Blend"]="Extra-Lap Greyhound";SM("Extra Cycle Blend","One More Lap","STR","a",70,100,"spd+1","The race is over. It's still running.");
