/* =============== LANTERN NIGHT AT HOLLOWMERE: the event alloys ===============
   Thirteen alloys that only turn up at Hollowmere while Lantern Night is on. Five hide in the leaf piles, three are fair prizes,
   four are guising treats, and one waits at the end of the lantern trail. They stay in the register for good once they're registered.
   Plus the event's threat, the Gutterwick, which has to be tracked down and contained like any other. */
HAB["z-hollow"]={name:"Hollowmere",col:"#E8862A"};
const LNT_ORIGIN="Hollowmere Lantern Night";
const LNT_ALLOYS=[
 {name:"Neepling",how:"leaf",comp:[["Sn",62],["Bi",24],["Zn",8],["Cu",6]],d:7.9,mp:182,mag:0,hard:2,cond:8,color:"#C9C0A6",finish:"p",rar:"uncommon",
  lore:"Every Lantern Night, Hollowmere's children carve neeps into lanterns. In 1951 one of them set the candle on a lump of something from the old storeroom, and by morning the lump had poured itself into the shape of the grin.",uses:"Lantern candle-cups and grave-lamp sconces",tmade:"Found poured into a carved neep on Lantern Night, 1951"},
 {name:"Treaclite",how:"leaf",comp:[["Cu",58],["Zn",30],["Mn",7],["Al",5]],d:8.2,mp:880,mag:0,hard:3.6,cond:22,color:"#B8863A",finish:"p",rar:"uncommon",
  lore:"Hollowmere boils its bonfire toffee in one great pan that's older than the church. Scrape the bottom hard enough, the toffee-makers say, and you get this instead of toffee. They have stopped scraping that hard.",uses:"Toffee-pan rivets and fireside fenders",tmade:"Scraped from the bottom of the Hollowmere toffee pan"},
 {name:"Bricklebound",how:"leaf",comp:[["Fe",70],["Cr",12],["Ni",9],["Mo",5],["Si",4]],d:7.9,mp:1420,mag:1,hard:5.5,cond:4,color:"#9A9890",finish:"m",rar:"rare",
  lore:"When the storeroom bricked up in 1932 was finally opened, everything inside was under dust sheets. One sheet had nothing under it but this, and the shape of an armchair that had got up and left.",uses:"Hinges and bolts that must not rust in a sealed room",tmade:"Recovered from under a dust sheet in the Hollowmere storeroom"},
 {name:"Hob's Lure",how:"leaf",comp:[["Ag",60],["Cu",22],["Zn",12],["Sn",6]],d:9.6,mp:690,mag:0,hard:3,cond:55,color:"#D8D4CC",finish:"p",rar:"rare",
  lore:"Moor walkers who follow a light across Hollowmere bog on Lantern Night tend to end up knee-deep and furious. One of them came home with this clutched in his fist, and has never said what he swapped for it.",uses:"Soldered joins in lantern frames",tmade:"Brought back off Hollowmere bog by a walker who won't say how"},
 {name:"Penumbrine",how:"leaf",comp:[["Pb",40],["Sn",35],["Bi",15],["Cd",10]],d:9.4,mp:145,mag:0,hard:1.5,cond:7,color:"#8C8E94",finish:"m",rar:"uncommon",
  lore:"Poured at the edge of the shadow during the Hollowmere eclipse, by somebody who should have been watching the sky and was watching the pot instead. It has been in a bad mood about it ever since.",uses:"Low-melt castings for pinhole viewers and sundial gnomons",tmade:"Poured at the eclipse camp on Hollowmere Hill, in the half-shadow"},
 {name:"Dookite",how:"stall",stall:"dook",comp:[["Al",88],["Mg",6],["Si",4],["Cu",2]],d:2.7,mp:600,mag:0,hard:3,cond:30,color:"#C8CDD2",finish:"p",rar:"uncommon",
  lore:"First prize for apple dooking at the Hollowmere fair, every year since the tub was made. The tub was made out of it, so the prize is mostly a polite way of asking for the tub back.",uses:"Tubs, pails and anything that spends its life wet",tmade:"Presented at the Hollowmere fair as the apple-dooking prize"},
 {name:"Rattlecart",how:"stall",stall:"shuffle",comp:[["Fe",89],["Mn",9],["Si",1.5],["C",0.5]],d:7.8,mp:1410,mag:1,hard:5,cond:5,color:"#7E8088",finish:"m",rar:"uncommon",
  lore:"The old ghost train came to Hollowmere fair on a steam lorry in 1924 and never left. Its wheels wore down to nothing and something else wore on in their place. This is shavings of the something else.",uses:"Wheel rims and rail shoes that take a beating",tmade:"Shaved off the ghost train's wheels at the Hollowmere fair"},
 {name:"Festoonite",how:"stall",stall:"memory",comp:[["Cu",70],["Ni",18],["Zn",12]],d:8.7,mp:1060,mag:0,hard:3.8,cond:7,color:"#C8C4B4",finish:"p",rar:"rare",
  lore:"Hollowmere hangs a mile of bunting on Lantern Night and takes it all down by the fifteenth, every flag counted. One year the count came out one flag over, and the extra flag was this.",uses:"Bunting clips, hooks and flagpole fittings",tmade:"Counted in among the Hollowmere bunting, one flag too many"},
 {name:"Guiser's Grin",how:"guise",door:0,comp:[["Zn",78],["Al",18],["Cu",4]],d:5.2,mp:420,mag:0,hard:2.8,cond:26,color:"#B4B8BC",finish:"p",rar:"uncommon",
  lore:"Guisers in Hollowmere have to do a turn before they get a treat: a song, a joke, a riddle. One year a guiser in a paper mask did a turn so good the whole street gave it everything they had, and it left this behind on the last doorstep.",uses:"Die-cast masks, buckles and button-backs",tmade:"Left on a Hollowmere doorstep by a guiser nobody recognised"},
 {name:"Soulcake",how:"guise",door:1,comp:[["Cu",86],["Sn",11],["Zn",3]],d:8.8,mp:980,mag:0,hard:3.4,cond:14,color:"#B08050",finish:"p",rar:"uncommon",
  lore:"Soul cakes are baked in Hollowmere for anyone who comes souling. The village oven has a cast tray so old that the cakes now come out with a faint ring when you tap them, and so, eventually, did the tray.",uses:"Oven trays, griddles and the bells on a souler's stick",tmade:"Knocked out of the Hollowmere village oven tray"},
 {name:"Bogleworth",how:"guise",door:2,comp:[["Ti",86],["Al",8],["V",6]],d:4.4,mp:1640,mag:0,hard:6,cond:2,color:"#9A9CA2",finish:"m",rar:"rare",
  lore:"The tattie bogle in the top field has stood there since before anyone can remember, in a coat nobody gave it. When the coat was finally mended, the needle came out bent and the patch came out as this.",uses:"Field stakes, fence pins and anything left out in all weathers",tmade:"Stitched out of the top-field tattie bogle's coat"},
 {name:"Nutcrackle",how:"guise",door:3,comp:[["Co",50],["Cr",28],["W",14],["Fe",8]],d:8.6,mp:1300,mag:1,hard:7,cond:3,color:"#A0A4AC",finish:"m",rar:"rare",
  lore:"On Nutcrack Night two nuts go on the fire, one for each sweetheart: if they burn together, so will you. In one Hollowmere hearth a pair of nuts refused to burn at all, and left this in the ashes, warm and very smug.",uses:"Nutcracker jaws and hearth irons",tmade:"Raked out of a Hollowmere hearth on Nutcrack Night"},
 {name:"Besomite",how:"trail",comp:[["Mg",82],["Y",7],["Nd",6],["Zr",5]],d:1.9,mp:590,mag:0,hard:2,cond:18,color:"#C4C6C0",finish:"p",rar:"legendary",
  lore:"Every lantern on the trail is lit in a different place, and the last one is lit on top of Hollowmere Hill. Whoever lights it finds the old besom leaning against the stone, and wrapped round its handle, this.",uses:"Featherweight broom ferrules and anything that has to fly",tmade:"Found wound round the besom on Hollowmere Hill at the end of the lantern trail"},
 {name:"Wickwarden",how:"hunt",comp:[["Sn",44],["Ag",22],["Cu",18],["In",9],["Sb",7]],d:8.2,mp:204,mag:0,hard:2.2,cond:14,color:"#D4CCB8",finish:"p",rar:"legendary",
  lore:"Hollowmere says that whatever goes round on Lantern Night putting the lights out has never once got the last one. Something always stands over the last lantern in the village until morning, and the cold prints always stop a little way short of it.",uses:"Lantern frames and wick-holders soldered to outlast the night",tmade:"Found standing over the last lit lantern in Hollowmere, where the cold prints stopped"}];
const LNT_NAMES=new Set(LNT_ALLOYS.map(o=>o.name));
/* ---- the Gutterwick: Lantern Night's threat ----
   LIGHTS OUT. A flame that eats light. While it's loose the whole lab goes dark, and you only see what your lantern shows you.
   It hunts your light: SHUTTER the lantern when its eyes come close and it loses you. Your oil burns down, the wick can be turned
   down to save it, and if the Gutterwick reaches your light it drinks it and leaves you in the dark. */
const GW_NAME="Gutterwick",WW_NAME="Wickwarden";
{/* an old save may have rebuilt any of these already: keep the real ones, drop the copies, renumber */
  const names=new Set([...LNT_NAMES,GW_NAME]),out=ALLOYS.filter(a=>!(names.has(a.name)&&a.recovered));
  if(out.length!==ALLOYS.length){ALLOYS.length=0;out.forEach((a,i)=>{a.no=i+1;ALLOYS.push(a)})}
  LNT_ALLOYS.forEach(o=>{if(ALLOYS.some(a=>a.name===o.name))return;
    const a={name:o.name,comp:o.comp,d:o.d,mp:o.mp,mag:o.mag,hard:o.hard,cond:o.cond,color:o.color,finish:o.finish,aliases:[],leak:false,real:false,quest:true,event:"lantern",
      fixedHab:"z-hollow",lore:o.lore,uses:o.uses,tmade:o.tmade,made:o.tmade,origin:LNT_ORIGIN,creditKind:"event",lntHow:o.how,lntStall:o.stall,lntDoor:o.door};
    a.reactive=isReactive(frac(a));ALLOYS.push(a);a.no=ALLOYS.length;a.types=typesOf(a);a.hab="z-hollow";a.rar=o.rar;
    if(a.mp<25){a.form="vial";a.fill="liquid"}else{a.form="rod";a.fill=null}a.cat=categoryOf(a)});
  if(!ALLOYS.some(a=>a.name===GW_NAME)){const t={name:GW_NAME,comp:[["Ga",48],["In",20],["Sn",13],["Ce",11],["Bi",8]],d:6.2,mp:9,mag:0,hard:0,cond:3.4,color:"#B8BCC8",tfill:"liquid",fixedHab:"z-hollow",hz:{flash:1},
      lore:"Every Lantern Night something goes round Hollowmere putting the lanterns out. Folk call it the Gutterwick. It is one of the shadows that walk the lanes, but one that has got hold of a vial and will not put it down, and it drinks the light out of every lantern it passes into the glass. Nobody has ever made it let go.",
      tmade:"Nobody made it. It comes back to Hollowmere every Lantern Night",aliases:[],leak:false,finish:"p",real:false,threat:true,event:"lantern",uses:"Nothing. Containment only."};
    t.reactive=isReactive(frac(t));ALLOYS.push(t);t.no=ALLOYS.length;t.types=typesOf(t);t.hab="z-hollow";t.rar="threat";t.form="vial";t.fill="liquid";t.made=t.tmade;THREAT_CAT[GW_NAME]="Light-Eater";t.cat=categoryOf(t)}}
const lntAlloy=n=>ALLOYS.find(a=>a.name===n);

/* ---- their battle forms, each drawn by hand ---- */
const NEEP_GLOW="#FFB43A";
/* Neepling: a hermit crab that has moved into a carved neep lantern, candle and all. */
addForm("Neepling",{n:"#D8643A",a:"#E8D8B4",rn:"#5A8AD8",rb:"#E8E4F4",ra:"#FFD23F"},"crawl",(P,g)=>fShadow(60,104)+
 [[76,"legB",.3],[88,"legB",.1],[118,"legF",.2],[130,"legF",0]].map(([x,c,d])=>pt(c,x,128,`<path d="M${x} 126 Q${x+(x<100?-10:10)} 132 ${x+(x<100?-14:14)} 146" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M${x} 126 Q${x+(x<100?-10:10)} 132 ${x+(x<100?-14:14)} 146" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`,d)).join("")+
 /* the neep: a fat root with its top cut off as a lid, a carved grin, and the candle glowing through */
 `<path d="M60 112 Q50 74 84 58 Q112 50 136 62 Q160 80 148 116 Q140 134 104 136 Q70 136 60 112 Z" fill="${P.ac}" ${SW}/><path d="M68 76 Q100 60 140 72" stroke="#9A5AA0" stroke-width="7" fill="none" opacity=".55" stroke-linecap="round"/>`+
 `<path d="M104 136 Q108 144 102 148" stroke="${FI}" stroke-width="2.4" fill="none"/>`+
 pt("sway",104,52,`<path d="M80 60 Q104 44 132 58 L128 50 Q104 38 84 52 Z" fill="${P.ac}" ${SW2}/><path d="M102 44 Q98 28 90 22 M106 44 Q112 26 124 20 M104 44 Q104 30 106 18" stroke="#5A8A3A" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 `<g><path d="M80 86 L90 78 L96 90 Z M114 90 L120 78 L130 86 Z" fill="${NEEP_GLOW}" ${SW2}/><path d="M78 104 L86 112 L92 104 L98 114 L104 104 L110 114 L116 104 L122 112 L130 102 Q120 124 104 124 Q86 124 78 104 Z" fill="${NEEP_GLOW}" ${SW2}/>`+
 `<animate attributeName="opacity" values="1;.72;1;.86;1" dur="1.3s" repeatCount="indefinite"/></g>`+
 /* the crab, peering out of the carved mouth */
 pt("claw2",132,120,`<path d="M132 120 Q150 118 158 108" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M132 120 Q150 118 158 108" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M152 98 Q170 92 172 106 L160 108 Z" fill="${P.n}" ${SW2}/><path d="M154 112 Q170 118 168 106 L158 108 Z" fill="${P.nd}" ${SW2}/>`,.4)+
 pt("claw",76,120,`<path d="M78 120 Q56 122 46 110" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M78 120 Q56 122 46 110" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M50 96 Q26 88 24 106 L42 110 Z" fill="${P.n}" ${SW}/><path d="M44 114 Q22 124 26 108 L42 110 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("ant",98,104,`<path d="M96 108 Q90 94 92 82" stroke="${P.n}" stroke-width="3" fill="none"/><path d="M108 108 Q114 94 112 82" stroke="${P.n}" stroke-width="3" fill="none"/>${E2(92,80,4,"#1A1A1A",[0,-.2])}${E2(112,80,4,"#1A1A1A",[0,-.2])}`)+
 fG(g,1,`<path d="M28 60 Q30 52 36 56 Q34 62 28 60 Z M170 50 Q174 42 180 48 Q176 54 170 50 Z" fill="${NEEP_GLOW}" opacity=".7"/>`)+fG(g,2,`<circle cx="104" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(168,30,6)));
FORM_TITLE["Neepling"]="Neep-Shelled Hermit Crab";SM("Neepling","Hollowed Grin","HEA","a",60,100,"tacc-1@40","Carved, lit from the inside, and grinning at you. It's a lot to look at.");

/* Treaclite: a fire salamander basking on the bonfire log, with a toffee apple stuck fast to the end of its tail. */
addForm("Treaclite",{n:"#2A2420",a:"#F2B83A",rn:"#E8E4F4",rb:"#5A3A8A",ra:"#5FE0F0"},"slink",(P,g)=>`<path d="M20 140 Q100 128 190 140 L188 150 L22 150 Z" fill="#5A3A22" ${SW2}/><path d="M30 138 Q100 128 180 138" stroke="#7A5232" stroke-width="2" fill="none"/>`+
 `${[[40,132],[70,128],[150,130],[176,134]].map(([x,y])=>`<path d="M${x} ${y} Q${x+4} ${y-14} ${x} ${y-22} Q${x+10} ${y-10} ${x+8} ${y} Z" fill="#FF8A2A" opacity=".75"><animate attributeName="opacity" values=".4;.85;.5;.75;.4" dur="1.${x%7+2}s" repeatCount="indefinite"/></path>`).join("")}`+
 pt("tail",150,112,`<path d="M146 112 Q170 104 176 84" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M146 112 Q170 104 176 84" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/><circle cx="168" cy="98" r="3" fill="${P.ac}"/>`+
  `<path d="M176 84 L178 70" stroke="#A88A5A" stroke-width="3"/><circle cx="178" cy="60" r="12" fill="#B83A2A" ${SW}/><path d="M168 54 Q178 46 188 56 Q186 66 178 72 Q166 68 168 54 Z" fill="#E8A02A" opacity=".8"/><path d="M172 56 Q176 52 180 54" stroke="#fff" stroke-width="2" fill="none" opacity=".7"/>`+
  `<path d="M172 72 Q170 82 172 90 M184 70 Q188 80 184 88" stroke="#E8A02A" stroke-width="1.6" fill="none"><animate attributeName="d" values="M172 72 Q170 82 172 90 M184 70 Q188 80 184 88;M172 72 Q169 86 171 96 M184 70 Q189 84 185 94;M172 72 Q170 82 172 90 M184 70 Q188 80 184 88" dur="2.4s" repeatCount="indefinite"/></path>`)+
 [[66,"legB",.2],[134,"legB",.5]].map(([x,c,d])=>pt(c,x,118,`<path d="M${x} 116 L${x+6} 130 L${x+12} 130" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${x} 116 L${x+6} 130 L${x+12} 130" stroke="${P.nd}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,d)).join("")+
 `<path d="M44 108 Q60 94 100 96 Q140 96 152 110 Q140 122 100 122 Q60 122 44 108 Z" fill="${P.n}" ${SW}/>`+
 `${[[62,104,7],[86,100,6],[108,112,7],[128,102,6],[142,112,4],[74,114,5]].map(([x,y,r])=>`<path d="${fgEll(x,y,r,r*.7)}" fill="${P.ac}"/>`).join("")}`+
 [[80,"legF",0],[124,"legF",.3]].map(([x,c,d])=>pt(c,x,120,`<path d="M${x} 118 L${x-6} 132 L${x-12} 132" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${x} 118 L${x-6} 132 L${x-12} 132" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,d)).join("")+
 pt("head",46,104,`<path d="M52 98 Q34 90 20 100 Q16 110 30 114 Q46 118 56 112 Z" fill="${P.n}" ${SW}/><path d="${fgEll(36,96,6,4)}" fill="${P.ac}"/>${E2(30,100,4.4,"#1A1A1A",[-.3,0])}`+
  pt("jaw",50,110,`<path d="M54 110 Q36 122 20 108 Q34 114 54 112 Z" fill="${P.nd}" ${SW2}/>`)+pt("tongue",22,108,`<path d="M24 108 Q14 110 10 104 M14 108 Q10 114 6 112" stroke="${FTONGUE}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`))+
 fG(g,1,`<path d="M96 70 Q100 60 96 50 M110 74 Q116 62 110 50" stroke="#FFB24A" stroke-width="2" fill="none" opacity=".6"/>`)+fG(g,2,`<circle cx="100" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Treaclite"]="Toffee-Tailed Fire Salamander";SM("Treaclite","Toffee Snare","HEA","a",55,100,"tspd-1@50","Bonfire toffee: sticks to your teeth, your shoes, and anything that tries to run away.");

/* Bricklebound: an armchair that has been under a dust sheet since 1932. The seat opens like a mouth; the armrests reach. */
addForm("Bricklebound",{n:"#E8E2D2",a:"#7A3A4A",rn:"#2A2A3A",rb:"#B8C8F0",ra:"#E8412C"},"stand",(P,g)=>fShadow(58,104)+
 [[64,"legB",.3],[144,"legB",.1],[76,"legF",0],[132,"legF",.2]].map(([x,c,d])=>pt(c,x,132,`<path d="M${x} 130 Q${x+(x<104?-4:4)} 140 ${x} 146" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M${x} 130 Q${x+(x<104?-4:4)} 140 ${x} 146" stroke="#6A4A2A" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M${x-6} 146 h12" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,d)).join("")+
 /* the wingback, the sheet draped over it, a mended tear showing the upholstery */
 pt("head",104,60,`<path d="M66 100 Q60 40 104 32 Q148 40 142 100 Z" fill="${P.n}" ${SW}/><path d="M72 46 Q70 30 82 34 M136 46 Q138 30 126 34" stroke="${FI}" stroke-width="2.4" fill="${P.n}"/>`+
  `<path d="M84 62 Q104 54 124 62" stroke="#C8C0AE" stroke-width="2" fill="none"/><path d="M116 76 L132 70 L128 88 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M80 74 Q90 68 100 74 Q90 82 80 74 Z M108 74 Q118 68 128 74 Q118 82 108 74 Z" fill="${FI}"/>${E2(90,74,3.4,"#E8C860",[0,.2])}${E2(118,74,3.4,"#E8C860",[0,.2])}`)+
 `<path d="M60 128 Q58 104 70 100 H138 Q150 104 148 128 Z" fill="${P.n}" ${SW}/><path d="M64 128 Q70 136 76 128 Q84 138 92 128 Q100 138 108 128 Q116 138 124 128 Q132 138 140 128 Q144 134 148 128" fill="${P.n}" ${SW2}/>`+
 /* the seat: a mouth with a cushion for a tongue */
 `<path d="M74 104 H134 L130 116 H78 Z" fill="${FMOUTH}"/>`+pt("jaw",104,114,`<path d="M74 112 H134 L130 124 Q104 130 78 124 Z" fill="${P.n}" ${SW2}/><path d="M80 112 l4 5 l4 -5 l4 5 l4 -5 l4 5 l4 -5 l4 5 l4 -5 l4 5 l4 -5 l4 5 l4 -5" stroke="${FI}" stroke-width="1.4" fill="#F4F0E4"/>`)+
 pt("tongue",104,108,`<rect x="86" y="104" width="36" height="9" rx="4" fill="${P.ac}" ${SW2}/>`)+
 pt("armB",146,104,fOL("M140 104 Q158 98 166 84",P.n,9)+`<path d="M164 80 l6 -6 M166 84 l8 -2 M162 78 l2 -8" stroke="#6A4A2A" stroke-width="2.4" stroke-linecap="round"/>`,.4)+
 pt("armF",62,104,fOL("M68 104 Q48 96 40 80",P.n,10)+`<path d="M40 76 l-6 -6 M38 80 l-8 -2 M42 74 l-2 -8" stroke="#6A4A2A" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,1,`<rect x="150" y="122" width="26" height="16" rx="2" fill="#F4F0E4" ${SW2} transform="rotate(8 163 130)"/><text x="153" y="134" font-size="8" font-weight="bold" fill="${FI}" font-family="monospace" transform="rotate(8 163 130)">1932</text>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(164,40,6)));
FORM_TITLE["Bricklebound"]="Dust-Sheeted Armchair Mimic";SM("Bricklebound","Sat On For Years","DRP","a",75,95,"tspd-1@30","It has been very patient for a very long time. Now it would like to sit on you.");

/* Hob's Lure: a deep-sea anglerfish whose lure is a tiny candle lantern, swinging in the dark. */
addForm("Hob's Lure",{n:"#4A3A4E",a:"#E8DCC0",rn:"#E8E4F0",rb:"#5A8AD8",ra:"#FFD23F"},"swim",(P,g)=>
 pt("tail",156,92,`<path d="M150 92 L182 70 L176 92 L184 116 Z" fill="${P.nd}" ${SW}/><path d="M160 86 L176 78 M160 98 L178 108" stroke="${FI}" stroke-width="1.2"/>`)+
 pt("wingB",126,74,`<path d="M114 72 Q126 54 140 64 Q132 72 126 78 Z" fill="${P.nd}" ${SW2}/>`,.3)+
 `<path d="M52 92 Q54 54 100 50 Q146 52 156 92 Q148 128 100 130 Q56 128 52 92 Z" fill="${P.n}" ${SW}/>`+
 `${[[78,64],[120,60],[136,104],[90,116]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.nl}" opacity=".6"/>`).join("")}`+
 pt("wingF",112,108,`<path d="M108 104 Q118 128 134 126 Q126 114 120 104 Z" fill="${P.nd}" ${SW2}/>`)+
 /* the lure: a rod from the forehead, and a little lantern on the end */
 pt("ant",92,52,`<path d="M92 52 Q80 18 50 20 Q36 22 34 34" stroke="${FI}" stroke-width="4.6" fill="none" stroke-linecap="round"/><path d="M92 52 Q80 18 50 20 Q36 22 34 34" stroke="${P.n}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`+
  pt("sway",34,34,`<path d="M34 34 V38" stroke="${FI}" stroke-width="1.4"/><circle cx="34" cy="50" r="16" fill="${NEEP_GLOW}" opacity=".22"/><path d="M28 38 H40 L42 42 H26 Z" fill="${P.ac}" ${SW2}/><rect x="27" y="42" width="14" height="14" rx="2" fill="#FFE6A0" opacity=".9" ${SW2}/><path d="M34 46 Q36 49 34 53 Q32 49 34 46 Z" fill="#FF8A2A"><animate attributeName="opacity" values="1;.6;1" dur=".9s" repeatCount="indefinite"/></path><path d="M26 56 H42" stroke="${FI}" stroke-width="2"/>`))+
 /* that mouth */
 `<path d="M52 92 Q60 108 92 112 L56 104 Z" fill="${FMOUTH}"/>`+
 pt("head",80,84,`${E2(78,76,6,"#E8C040",[-.4,.1])}<path d="M52 86 Q70 84 92 92" stroke="${FI}" stroke-width="2.4" fill="none"/>${[58,66,74,82].map(x=>`<path d="M${x} ${86+(x-58)*.25} l3 7 l3 -6" fill="#F4F0E4" stroke="${FI}" stroke-width=".8"/>`).join("")}`+
  pt("jaw",56,100,`<path d="M50 94 Q56 120 96 114 Q66 108 54 96 Z" fill="${P.nd}" ${SW2}/>${[58,66,74,82].map(x=>`<path d="M${x} ${110-(x-58)*.08} l3 -8 l3 7" fill="#F4F0E4" stroke="${FI}" stroke-width=".8"/>`).join("")}`))+
 fG(g,1,`<circle cx="170" cy="40" r="2" fill="#9AD8F0" opacity=".7"/><circle cx="180" cy="28" r="3" fill="none" stroke="#9AD8F0" stroke-width="1" opacity=".6"/>`)+fG(g,2,`<circle cx="120" cy="92" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(176,140,6)));
FORM_TITLE["Hob's Lure"]="Lantern-Lure Anglerfish";SM("Hob's Lure","Follow The Light","CUR","a",65,100,"tacc-1,tspd-1@30","Such a friendly little light. Come a bit closer. A bit closer.");

/* Penumbrine: a tarsier clinging to a branch, holding up a pinhole viewer with the eclipse showing in it as a little crescent. */
addForm("Penumbrine",{n:"#B89A72",a:"#E8DCC0",rn:"#3A3A5A",rb:"#C8B8F0",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M12 120 Q100 112 196 128" stroke="#5A3E26" stroke-width="10" stroke-linecap="round"/><path d="M150 124 Q160 136 176 140" stroke="#5A3E26" stroke-width="5" fill="none" stroke-linecap="round"/>`+fShadow(30,104)+
 pt("tail",116,118,`<path d="M114 118 Q128 138 120 150" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M118 146 Q124 150 122 152 Q114 152 116 146 Z" fill="${P.nd}"/>`)+
 pt("legF",98,118,`<path d="M96 110 Q88 120 92 124 Q100 126 104 118" fill="${P.n}" ${SW2}/><path d="M86 124 h4 M92 126 h4 M98 124 h4" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 `<path d="M88 116 Q82 92 104 86 Q124 92 120 116 Q112 122 104 122 Q94 122 88 116 Z" fill="${P.n}" ${SW}/>`+
 /* the pinhole viewer: a shoebox with a crescent sun cast on the back of it */
 pt("armF",112,94,`<path d="M110 96 Q130 92 136 80" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M110 96 Q130 92 136 80" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`+
  `<g transform="rotate(-12 150 70)"><path d="M130 58 H172 V86 H130 Z" fill="#C8A878" ${SW2}/><path d="M130 58 L138 50 H180 L172 58 Z" fill="#E8C898" ${SW2}/><path d="M172 58 L180 50 V78 L172 86 Z" fill="#A88858" ${SW2}/><rect x="136" y="62" width="30" height="20" fill="#F4F0E4"/><circle cx="151" cy="72" r="7" fill="#F2C94C"/><circle cx="154" cy="70" r="6.4" fill="#F4F0E4"/><circle cx="176" cy="60" r="1.4" fill="${FI}"/></g>`)+
 pt("head",100,70,`<circle cx="100" cy="64" r="22" fill="${P.n}" ${SW}/>`+pt("ear",80,48,`<path d="M84 52 Q72 28 82 32 Q92 38 92 48 Z" fill="${P.nl}" ${SW2}/>`)+pt("ear",118,48,`<path d="M112 48 Q118 30 126 36 Q128 44 118 54 Z" fill="${P.nl}" ${SW2}/>`,.3)+
  `${E2(90,62,9.4,"#C88A2A",[0,0])}${E2(112,62,9.4,"#C88A2A",[0,0])}<path d="M99 72 Q101 74 103 72" stroke="${FI}" stroke-width="1.6" fill="none"/>`+pt("jaw",101,78,`<path d="M96 76 Q101 82 106 76 Q101 79 96 76 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M24 30 A14 14 0 1 0 38 44 A10 10 0 1 1 24 30 Z" fill="#F2C94C" opacity=".7"/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(180,120,6)));
FORM_TITLE["Penumbrine"]="Pinhole-Viewing Tarsier";SM("Penumbrine","Half Shadow","RAD","s",0,100,"tacc-2","Never look straight at it. Look at the little crescent on the back of the box instead.");

/* Dookite: a dipper bird on the rim of the apple-dooking tub, with an apple in its beak and the rest bobbing in the water. */
addForm("Dookite",{n:"#4A3426",a:"#F4F0E4",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#E8412C"},"stand",(P,g)=>
 /* the tub, with water and bobbing apples */
 `<path d="M40 112 L48 148 H160 L168 112 Z" fill="#8A6A44" ${SW}/>${[56,80,104,128,152].map(x=>`<path d="M${x} 112 L${x+(x-104)*.08} 148" stroke="#5A4228" stroke-width="2"/>`).join("")}<path d="M42 122 H166 M46 138 H162" stroke="#4A4A50" stroke-width="3"/>`+
 `<ellipse cx="104" cy="112" rx="64" ry="9" fill="#5A8AB8" ${SW2}/>${[[72,110,0],[96,114,.6],[132,110,1.1],[150,113,.3]].map(([x,y,d])=>`<g><circle cx="${x}" cy="${y}" r="7" fill="#C83A2A" ${SW2}/><path d="M${x} ${y-7} l1 -4" stroke="#5A3A1A" stroke-width="1.6"/><animateTransform attributeName="transform" type="translate" values="0 0;0 -2;0 0" dur="1.${(x%5)+4}s" begin="${d}s" repeatCount="indefinite"/></g>`).join("")}`+
 pt("legF",96,96,`<path d="M92 94 L90 110 M100 94 L102 110" stroke="${FI}" stroke-width="2.6"/><path d="M84 110 h10 M98 110 h10" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("tail",120,76,`<path d="M118 78 L138 58 L142 64 L124 84 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M72 80 Q74 54 100 52 Q124 54 126 80 Q120 98 98 98 Q76 98 72 80 Z" fill="${P.n}" ${SW}/><path d="M74 72 Q80 92 100 94 Q86 84 88 66 Q78 64 74 72 Z" fill="${P.ac}"/>`+
 pt("wingF",108,74,`<path d="M96 66 Q118 64 126 80 Q112 88 100 80 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",80,52,`<circle cx="80" cy="50" r="15" fill="${P.n}" ${SW}/>${E2(74,46,3.4,"#1A1A1A")}<path d="M70 42 Q76 40 80 42" stroke="#F4F0E4" stroke-width="1.6" fill="none"/>`+
  `<path d="M66 52 L50 52 L64 56 Z" fill="${FMOUTH}"/>`+pt("beak",66,54,`<path d="M66 54 L50 54 L64 60 Z" fill="#2A2A30" ${SW2}/>`)+`<path d="M66 50 L48 52 L66 54 Z" fill="#2A2A30" ${SW2}/><circle cx="46" cy="56" r="7" fill="#C83A2A" ${SW2}/><path d="M46 49 l2 -4" stroke="#5A3A1A" stroke-width="1.6"/>`)+
 fG(g,1,`<path d="M30 100 q4 -6 8 0 M170 100 q4 -6 8 0" stroke="#9AC8E8" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="98" cy="86" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Dookite"]="Apple-Dooking Dipper";SM("Dookite","Dook","QUE","a",65,100,"tacc-1@30","Hands behind your back, face in the tub, and come up with an apple or don't come up at all.");

/* Rattlecart: a caterpillar made of ghost-train carriages, its front car's headlamps for eyes and trolley poles for feelers. */
addForm("Rattlecart",{n:"#3A3A4A",a:"#E8C040",rn:"#E8E4F0",rb:"#C83A2A",ra:"#5FE0F0"},"crawl",(P,g)=>`<path d="M14 144 H196" stroke="#5A5A62" stroke-width="3"/><path d="M14 148 H196" stroke="#3A3A42" stroke-width="2"/>${Array.from({length:12},(_,i)=>`<rect x="${18+i*15}" y="142" width="7" height="8" fill="#5A4030"/>`).join("")}`+fShadow(70,108)+
 pt("tail",176,118,`<path d="M170 110 L186 100 L186 124 L170 126 Z" fill="${P.n}" ${SW2}/><circle cx="182" cy="112" r="2.4" fill="#E8412C"/>`)+
 pt("sway",120,116,[176,148,120].map((x,i)=>`<path d="M${x-26} ${100+i} H${x-2} Q${x+2} ${100+i} ${x+2} ${104+i} V${130} H${x-30} V${104+i} Q${x-30} ${100+i} ${x-26} ${100+i} Z" fill="${i%2?P.n:"#4A2A3A"}" ${SW2}/><path d="M${x-24} ${108+i} H${x-6}" stroke="${P.ac}" stroke-width="2"/>`+
   `<path d="M${x-22} ${114+i} q4 -6 8 0 q4 -6 8 0 v8 l-2 -2 l-2 2 l-2 -2 l-2 2 l-2 -2 l-2 2 l-2 -2 Z" fill="#F4F0E4" opacity=".85"/><circle cx="${x-18}" cy="${116+i}" r="1" fill="${FI}"/><circle cx="${x-12}" cy="${116+i}" r="1" fill="${FI}"/>`).join(""))+
 [[48,"legF",0],[66,"legF",.2],[98,"legB",.1],[126,"legB",.3],[154,"legB",.15],[176,"legB",.25]].map(([x,c,d])=>pt(c,x,136,`<circle cx="${x}" cy="138" r="7" fill="#2A2A30" ${SW2}/><circle cx="${x}" cy="138" r="2.4" fill="${P.ac}"/><path d="M${x-5} 138 H${x+5}" stroke="#8A8A92" stroke-width="1.4"/>`,d)).join("")+
 /* the front car is the head */
 pt("head",58,106,`<path d="M36 132 V96 Q36 76 60 74 Q84 76 84 96 V132 Z" fill="${P.n}" ${SW}/><path d="M42 92 Q60 82 78 92" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
  `<circle cx="50" cy="100" r="8" fill="#FFF2B0" ${SW2}/><circle cx="72" cy="100" r="8" fill="#FFF2B0" ${SW2}/><circle cx="50" cy="100" r="3.4" fill="${FI}"/><circle cx="72" cy="100" r="3.4" fill="${FI}"/><circle cx="48" cy="98" r="1.2" fill="#fff"/><circle cx="70" cy="98" r="1.2" fill="#fff"/>`+
  `<path d="M42 114 H80 V120 H42 Z" fill="${FMOUTH}"/>`+pt("jaw",61,120,`<path d="M40 118 H82 V126 Q61 132 40 126 Z" fill="#8A8A92" ${SW2}/><path d="M44 122 H78" stroke="${FI}" stroke-width="1.2"/>`)+
  pt("ant",60,74,`<path d="M52 76 L40 50 M68 76 L80 50" stroke="${FI}" stroke-width="2.4"/><circle cx="40" cy="48" r="3" fill="${P.ac}" ${SW2}/><circle cx="80" cy="48" r="3" fill="${P.ac}" ${SW2}/><path d="M36 42 l-4 -4 M84 42 l4 -4 M40 40 v-5" stroke="#FFE27A" stroke-width="1.6"><animate attributeName="opacity" values="0;1;0;0;1;0" dur="1.6s" repeatCount="indefinite"/></path>`))+
 fG(g,1,`<text x="120" y="92" font-size="9" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif" font-style="italic">G H O S T</text>`)+fG(g,2,`<circle cx="148" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(176,50,6)));
FORM_TITLE["Rattlecart"]="Ghost-Train Caterpillar";SM("Rattlecart","Through The Tunnel","DRP","a",70,100,"multi:2-3","Into the dark, round the bend, and out the other side screaming. Again!");

/* Festoonite: a little wyvern whose wings are strings of bunting stretched between its finger bones. */
addForm("Festoonite",{n:"#5A9A6A",a:"#E8C040",rn:"#E8E4F0",rb:"#C83A2A",ra:"#5FE0F0"},"hover",(P,g)=>fShadow(40,104)+
 pt("wingB",112,70,`<path d="M112 70 L150 30 L176 60" stroke="${FI}" stroke-width="3" fill="none"/>${[[118,64],[128,54],[138,44],[148,34]].map(([x,y],i)=>`<path d="M${x} ${y} L${x+10} ${y-8} L${x+8} ${y+8} Z" fill="${["#E8412C","#F2C94C","#3A9AD8","#F4F0E4"][i]}" ${SW2}/>`).join("")}${[[156,38],[164,46],[172,54]].map(([x,y],i)=>`<path d="M${x} ${y} L${x+8} ${y+8} L${x-4} ${y+10} Z" fill="${["#3A9AD8","#E8412C","#F2C94C"][i]}" ${SW2}/>`).join("")}`,.25)+
 pt("tail",128,102,`<path d="M124 100 Q160 116 182 98" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M124 100 Q160 116 182 98" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M182 98 L198 88 L192 104 L198 112 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("legF",104,108,`<path d="M100 106 L96 124 L90 128 M96 124 L100 130 M112 106 L114 124 L108 130 M114 124 L120 128" stroke="${FI}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
 `<path d="M80 96 Q82 74 104 72 Q128 74 130 98 Q120 112 104 112 Q86 112 80 96 Z" fill="${P.n}" ${SW}/><path d="M90 100 Q104 108 120 100 Q116 88 104 86 Q94 88 90 100 Z" fill="${P.nll}"/>`+
 pt("wingF",96,78,`<path d="M96 78 L56 28 L30 58" stroke="${FI}" stroke-width="3" fill="none"/>${[[90,72],[80,60],[70,48],[60,36]].map(([x,y],i)=>`<path d="M${x} ${y} L${x-10} ${y-8} L${x-8} ${y+8} Z" fill="${["#F2C94C","#3A9AD8","#E8412C","#F4F0E4"][i]}" ${SW2}/>`).join("")}${[[50,36],[42,44],[34,52]].map(([x,y],i)=>`<path d="M${x} ${y} L${x-8} ${y+8} L${x+4} ${y+10} Z" fill="${["#E8412C","#F2C94C","#3A9AD8"][i]}" ${SW2}/>`).join("")}`)+
 pt("head",88,66,`<path d="M96 76 Q90 52 76 50 Q58 50 54 62 Q56 72 72 74 Z" fill="${P.n}" ${SW}/><path d="M78 50 L74 38 L84 48 M88 54 L90 42 L94 56" fill="${P.ac}" ${SW2}/>${E2(72,58,4,"#E8412C")}`+
  pt("jaw",62,70,`<path d="M72 72 Q60 82 50 70 Q60 74 72 72 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M56 66 l2 3 l2 -3 l2 3" stroke="#F4F0E4" stroke-width="1.2" fill="none"/>`)+
 fG(g,1,`<path d="M20 120 L34 116 L30 128 Z M176 130 L190 126 L186 138 Z" fill="#F2C94C" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,100,6)));
FORM_TITLE["Festoonite"]="Bunting-Winged Wyvern";SM("Festoonite","String Them Up","RES","s",0,100,"spd+1,tacc-1","A mile of bunting, every flag snapping in the wind. Very festive. Very distracting.");

/* Guiser's Grin: a raccoon out guising, its own mask covered by a paper one with an enormous grin, a sack of treats in its paw. */
addForm("Guiser's Grin",{n:"#8A8A92",a:"#F4F0E4",rn:"#E8D8B4",rb:"#5A3A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,104)+
 pt("tail",126,120,`<path d="M124 118 Q156 124 166 98" stroke="${FI}" stroke-width="15" fill="none" stroke-linecap="round"/><path d="M124 118 Q156 124 166 98" stroke="${P.n}" stroke-width="11" fill="none" stroke-linecap="round"/>${[[140,121],[154,116],[163,106]].map(([x,y])=>`<path d="${fgEll(x,y,3,5.4)}" fill="#2A2A30"/>`).join("")}`)+
 [[92,"legB",.2],[116,"legF",0]].map(([x,c,d])=>pt(c,x,130,`<path d="M${x} 128 V144" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 128 V144" stroke="#3A3A40" stroke-width="7" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M82 132 Q74 98 104 90 Q132 98 126 132 Q116 138 104 138 Q90 138 82 132 Z" fill="${P.n}" ${SW}/><path d="M92 128 Q90 106 104 102 Q118 106 116 128 Z" fill="${P.nl}"/>`+
 /* the treat sack */
 pt("armF",88,104,`<path d="M90 104 Q74 112 70 124" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M90 104 Q74 112 70 124" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M58 122 Q50 146 72 148 Q92 146 84 122 Q78 118 72 122 Q64 118 58 122 Z" fill="#C8A878" ${SW}/><path d="M64 122 Q72 128 80 122" stroke="#8A6A44" stroke-width="2" fill="none"/><circle cx="66" cy="118" r="4" fill="#C83A2A" ${SW2}/><rect x="74" y="112" width="8" height="8" rx="2" fill="#F2C94C" ${SW2}/>`)+
 pt("armB",122,102,`<path d="M120 102 Q136 92 140 76" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M120 102 Q136 92 140 76" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M136 74 l-2 -6 M140 72 l0 -6 M144 74 l2 -6" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`,.3)+
 pt("head",104,72,`<path d="M80 74 Q80 46 104 44 Q128 46 128 74 Q122 92 104 92 Q86 92 80 74 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",84,48,`<path d="M82 54 L80 34 L94 46 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",124,48,`<path d="M114 46 L128 34 L126 54 Z" fill="${P.n}" ${SW2}/>`,.3)+
  `<path d="M94 86 Q104 92 114 86 Q104 82 94 86 Z" fill="#2A2A30"/>`+pt("jaw",104,88,`<path d="M98 88 Q104 96 110 88 Z" fill="${FMOUTH}"/>`)+
  /* the paper guising mask, tied on with string, pushed slightly askew */
  `<g transform="rotate(-6 104 66)"><path d="M78 56 Q104 46 130 56 Q132 74 122 80 Q104 86 86 80 Q76 74 78 56 Z" fill="${P.ac}" ${SW}/><path d="M78 60 L66 58 M130 60 L142 56" stroke="#8A6A44" stroke-width="1.6"/>`+
  `<path d="M88 62 Q94 56 100 62 Q94 66 88 62 Z M108 62 Q114 56 120 62 Q114 66 108 62 Z" fill="${FI}"/><circle cx="94" cy="62" r="1.6" fill="#E8C040"/><circle cx="114" cy="62" r="1.6" fill="#E8C040"/>`+
  `<path d="M86 70 Q104 86 122 70 Q104 78 86 70 Z" fill="#C83A2A" ${SW2}/><path d="M90 72 v3 M96 74 v4 M102 75 v4 M108 75 v4 M114 74 v4 M120 72 v3" stroke="#F4F0E4" stroke-width="1.6"/><path d="M82 64 Q80 70 84 72 M126 64 Q128 70 124 72" stroke="#E8708A" stroke-width="2" fill="none" opacity=".7"/></g>`)+
 fG(g,1,`<text x="140" y="40" font-size="10" font-family="Georgia,serif" font-style="italic" fill="${P.ac}">trick or...?</text>`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Guiser's Grin"]="Paper-Masked Guising Raccoon";SM("Guiser's Grin","Do A Turn","RES","s",0,100,"tatk-1,heal:20","A joke, a song, a riddle, and a big daft grin. Nobody can stay cross with that.");

/* Soulcake: a wood mouse carrying a soul cake bigger than itself, marked with its cross and studded with currants. */
addForm("Soulcake",{n:"#A8784E",a:"#E8C890",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,98)+
 pt("tail",136,124,`<path d="M134 128 Q170 134 178 110 Q182 96 170 92" stroke="${FI}" stroke-width="5.4" fill="none" stroke-linecap="round"/><path d="M134 128 Q170 134 178 110 Q182 96 170 92" stroke="#D8A890" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
 [[94,"legB",.2],[122,"legF",0]].map(([x,c,d])=>pt(c,x,136,`<path d="M${x} 134 L${x-2} 144 L${x-10} 146" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${x} 134 L${x-2} 144 L${x-10} 146" stroke="#D8A890" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,d)).join("")+
 `<path d="M80 132 Q76 108 100 104 Q130 104 140 124 Q138 138 110 140 Q84 140 80 132 Z" fill="${P.n}" ${SW}/><path d="M86 130 Q92 118 108 120 Q104 132 86 130 Z" fill="${P.ac}"/>`+
 /* the cake on its back, held on with one arm */
 pt("sway",118,92,`<ellipse cx="118" cy="98" rx="44" ry="14" fill="#B8783A" ${SW}/><path d="M74 96 Q118 74 162 96 Q118 112 74 96 Z" fill="#E8B060" ${SW}/><path d="M96 86 L140 104 M140 86 L96 104" stroke="#F4E0B0" stroke-width="3.4" stroke-linecap="round"/>`+
  `${[[90,94],[106,88],[128,90],[146,96],[114,100],[132,102],[100,100]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="#3A1A10"/>`).join("")}`)+
 pt("armF",86,112,`<path d="M88 114 Q78 104 82 96" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M88 114 Q78 104 82 96" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 pt("head",74,112,`<path d="M88 106 Q80 94 66 98 Q50 104 44 118 Q60 124 82 122 Z" fill="${P.n}" ${SW}/><circle cx="44" cy="117" r="3.4" fill="#E8708A" ${SW2}/>${E2(64,108,4.4,"#1A1A1A",[-.3,0])}`+
  `<path d="M46 114 l-10 -4 M46 118 l-10 0 M46 120 l-9 4" stroke="${FI}" stroke-width="1"/>`+pt("jaw",56,121,`<path d="M58 120 Q52 128 46 121 Z" fill="${FMOUTH}"/>`)+
  pt("ear",74,92,`<path d="M66 98 Q60 76 76 76 Q90 80 84 98 Z" fill="${P.n}" ${SW2}/><path d="M70 94 Q68 82 76 82 Q82 86 80 94 Z" fill="#E8A8A8"/>`))+
 fG(g,1,`<path d="M30 70 q4 -4 8 0 M160 60 q4 -4 8 0" stroke="#E8B060" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="110" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Soulcake"]="Soul-Cake Carrying Wood Mouse";SM("Soulcake","A Cake For Your Soul","RES","s",0,100,"heal:40,cure","A soul cake, a soul cake, please good missus a soul cake. One for you, and one for the road.");

/* Bogleworth: a heron standing on one leg in a battered hat and a tattered coat, wings out like a scarecrow's arms, straw at the cuffs. */
addForm("Bogleworth",{n:"#9AA0A8",a:"#6A5A3A",rn:"#E8E4F0",rb:"#5A3A8A",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M104 148 V128" stroke="#6A4A2A" stroke-width="5"/>`+fShadow(30,104)+
 pt("legF",104,116,`<path d="M104 114 V146" stroke="${FI}" stroke-width="4.4"/><path d="M104 114 V146" stroke="#C8A060" stroke-width="2"/><path d="M96 146 H112" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("legB",110,112,`<path d="M108 112 L122 104 L112 96" stroke="${FI}" stroke-width="4" fill="none" stroke-linejoin="round"/><path d="M108 112 L122 104 L112 96" stroke="#C8A060" stroke-width="1.8" fill="none" stroke-linejoin="round"/>`,.3)+
 /* wings held straight out, in coat sleeves, straw poking from the cuffs */
 pt("wingB",120,80,`<path d="M114 78 L176 70 L178 86 L116 94 Z" fill="${P.ac}" ${SW}/><path d="M176 70 L186 66 M178 76 L190 76 M178 82 L188 88 M176 86 L184 94" stroke="#E8C860" stroke-width="2.4" stroke-linecap="round"/><rect x="146" y="74" width="10" height="8" fill="#8A4A5A" ${SW2}/>`,.25)+
 pt("wingF",92,80,`<path d="M96 78 L34 70 L32 86 L94 94 Z" fill="${P.ac}" ${SW}/><path d="M34 70 L24 66 M32 76 L20 76 M32 82 L22 88 M34 86 L26 94" stroke="#E8C860" stroke-width="2.4" stroke-linecap="round"/><rect x="54" y="74" width="12" height="9" fill="#5A7A8A" ${SW2}/><path d="M56 76 l8 5 M64 76 l-8 5" stroke="${FI}" stroke-width=".8"/>`)+
 `<path d="M88 116 Q84 80 104 74 Q124 80 120 116 Q112 122 104 122 Q94 122 88 116 Z" fill="${P.ac}" ${SW}/><path d="M104 76 V118" stroke="#4A3A22" stroke-width="2"/>${[86,96,106].map(y=>`<circle cx="100" cy="${y}" r="1.8" fill="#C8A060"/>`).join("")}<path d="M90 116 l-2 6 M96 118 l-1 6 M112 118 l1 6 M118 116 l2 6" stroke="#E8C860" stroke-width="2" stroke-linecap="round"/>`+
 pt("head",104,60,`<path d="M104 74 Q98 64 102 56" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M104 74 Q98 64 102 56" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><ellipse cx="104" cy="50" rx="11" ry="9" fill="${P.n}" ${SW}/>${E2(100,48,3,"#E8C040")}<path d="M108 44 Q120 40 126 48" stroke="${FI}" stroke-width="1.6" fill="none"/>`+
  `<path d="M94 50 L66 54 L94 53 Z" fill="${FMOUTH}"/>`+pt("beak",94,54,`<path d="M94 54 L66 55 L94 58 Z" fill="#C8A040" ${SW2}/>`)+`<path d="M94 47 L64 53 L94 52 Z" fill="#C8A040" ${SW2}/>`+
  `<path d="M90 42 Q104 30 120 40 L126 44 L86 46 Z" fill="#4A3A2A" ${SW}/><path d="M94 40 Q104 22 116 38" fill="#5A4A34" ${SW2}/><path d="M96 38 H116" stroke="#8A3A2A" stroke-width="2.4"/>`)+
 pt("sway",104,24,`<path d="M100 26 l-2 -8 M106 24 l2 -8" stroke="#E8C860" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M160 120 q6 -4 10 0 q6 -4 10 0" stroke="#3A3A3A" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,30,6)));
FORM_TITLE["Bogleworth"]="Tattie-Bogle Heron";SM("Bogleworth","Stand Very Still","SCR","s",0,100,"def+1,ward+1","It hasn't moved in forty years. Every crow on the moor knows better than to test it.");

/* Nutcrackle: a spotted nutcracker on the hearthstone, a hazelnut in its beak and two more jumping in the fire behind. */
addForm("Nutcrackle",{n:"#5A3A26",a:"#F4F0E4",rn:"#E8E4F0",rb:"#3A3A5A",ra:"#E8412C"},"perch",(P,g)=>`<rect x="14" y="128" width="180" height="20" fill="#7A7A82" ${SW2}/><path d="M60 128 V148 M120 128 V148 M90 138 H150" stroke="#5A5A62" stroke-width="1.6"/>`+
 `<path d="M140 128 Q150 108 160 118 Q170 98 182 128 Z" fill="#FF8A2A" opacity=".85"><animate attributeName="d" values="M140 128 Q150 108 160 118 Q170 98 182 128 Z;M140 128 Q148 100 160 114 Q174 94 182 128 Z;M140 128 Q150 108 160 118 Q170 98 182 128 Z" dur="1.1s" repeatCount="indefinite"/></path>`+
 `${[[152,116,0],[170,112,.5]].map(([x,y,d])=>`<g><ellipse cx="${x}" cy="${y}" rx="5" ry="6" fill="#A8703A" ${SW2}/><path d="M${x-4} ${y-3} Q${x} ${y-8} ${x+4} ${y-3}" fill="#E8C890"/><animateTransform attributeName="transform" type="translate" values="0 0;0 -10;0 0;0 0" dur="1.4s" begin="${d}s" repeatCount="indefinite"/></g>`).join("")}`+fShadow(28,90)+
 pt("tail",108,104,`<path d="M104 104 L134 118 L130 126 L100 112 Z" fill="${P.nd}" ${SW2}/><path d="M126 116 L132 124" stroke="#F4F0E4" stroke-width="3"/>`)+
 pt("legF",88,118,`<path d="M84 114 L82 128 M92 114 L94 128" stroke="${FI}" stroke-width="2.4"/><path d="M76 128 h10 M90 128 h10" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 `<path d="M66 102 Q66 76 90 74 Q112 76 112 102 Q106 118 90 118 Q72 118 66 102 Z" fill="${P.n}" ${SW}/>${[[76,90],[86,84],[96,96],[80,104],[100,108],[90,110],[104,90]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.ac}"/>`).join("")}`+
 pt("wingF",96,92,`<path d="M84 86 Q106 82 114 100 Q100 108 88 100 Z" fill="${P.nd}" ${SW2}/><path d="M92 96 l6 2 M98 92 l6 2" stroke="${P.ac}" stroke-width="1.6"/>`)+
 pt("head",74,70,`<circle cx="74" cy="66" r="15" fill="${P.n}" ${SW}/>${[[78,58],[70,74],[82,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="${P.ac}"/>`).join("")}${E2(68,62,3.4,"#1A1A1A")}`+
  `<path d="M60 66 L36 68 L58 72 Z" fill="${FMOUTH}"/>`+pt("beak",60,70,`<path d="M60 70 L36 69 L58 76 Z" fill="#2A2A30" ${SW2}/>`)+`<path d="M60 62 L34 67 L60 67 Z" fill="#2A2A30" ${SW2}/><ellipse cx="34" cy="68" rx="4.4" ry="5" fill="#A8703A" ${SW2}/><path d="M31 66 Q34 62 37 66" fill="#E8C890"/>`)+
 fG(g,1,`<path d="M150 90 q4 -6 8 0 q4 -6 8 0" stroke="#E8708A" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="90" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Nutcrackle"]="Fortune-Cracking Nutcracker";SM("Nutcrackle","Two Nuts In The Fire","SCR","a",70,90,"crit","If they burn together, so will you. If one of them jumps out, well. That's your answer.");

/* Besomite: a kiwi riding a besom broom through the night, its long beak out front and a scarf streaming behind. */
addForm("Besomite",{n:"#8A6A4A",a:"#C83A2A",rn:"#E8E4F0",rb:"#3A3A5A",ra:"#F2C94C"},"hover",(P,g)=>fShadow(40,104)+
 `<path d="M10 40 A30 30 0 1 0 40 10 A22 22 0 1 1 10 40 Z" fill="#F2E8B0" opacity=".55"/>`+
 /* the besom: a long handle with a bound bundle of twigs at the back */
 pt("tail",160,98,`<path d="M150 92 L196 82 L198 116 L150 104 Z" fill="#C8A060" ${SW}/>${[86,92,98,104,110].map(y=>`<path d="M152 ${y*.5+48} L196 ${y}" stroke="#8A6A3A" stroke-width="1.4"/>`).join("")}<path d="M150 90 V106 M156 89 V106" stroke="#5A3A1A" stroke-width="3"/>`)+
 `<path d="M30 112 L154 96" stroke="${FI}" stroke-width="8" stroke-linecap="round"/><path d="M30 112 L154 96" stroke="#8A5A2A" stroke-width="5" stroke-linecap="round"/>`+
 [[96,"legB",.2],[116,"legF",0]].map(([x,c,d])=>pt(c,x,110,`<path d="M${x} 108 L${x-4} 126 L${x-12} 128 M${x-4} 126 L${x+2} 132" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M${x} 108 L${x-4} 126" stroke="#C8B090" stroke-width="1.6"/>`,d)).join("")+
 `<path d="M80 96 Q80 64 110 62 Q140 64 140 96 Q134 112 110 112 Q86 112 80 96 Z" fill="${P.n}" ${SW}/>${[[96,78],[110,72],[124,80],[102,92],[120,98],[90,100]].map(([x,y])=>`<path d="M${x} ${y} l3 5" stroke="${P.nd}" stroke-width="1.4"/>`).join("")}`+
 pt("sway",118,70,`<path d="M100 72 Q120 64 136 72 Q150 66 172 54 Q166 62 174 66 Q156 76 136 80 Q118 82 100 78 Z" fill="${P.ac}" ${SW2}/><path d="M160 60 l4 6 M166 58 l4 6" stroke="#F4F0E4" stroke-width="1.6"/>`)+
 pt("head",88,74,`<circle cx="84" cy="72" r="13" fill="${P.n}" ${SW}/>${E2(78,68,2.6,"#1A1A1A")}<path d="M72 66 Q60 54 70 46 Q80 52 84 60" fill="#3A2A44" ${SW2}/>`+
  `<path d="M72 76 Q46 84 20 98" stroke="${FI}" stroke-width="5.4" fill="none" stroke-linecap="round"/>`+pt("beak",72,78,`<path d="M72 76 Q46 84 20 98" stroke="#E8D0A0" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
  `<path d="M70 70 Q58 62 46 66" stroke="#2A2A30" stroke-width="1.2" fill="none" opacity=".5"/>`)+
 fG(g,1,`${[[40,30],[170,30],[60,140]].map(([x,y])=>`<path d="M${x} ${y-3} L${x+1} ${y-1} L${x+3} ${y} L${x+1} ${y+1} L${x} ${y+3} L${x-1} ${y+1} L${x-3} ${y} L${x-1} ${y-1} Z" fill="#F2E8B0"/>`).join("")}`)+fG(g,2,`<circle cx="110" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(176,140,6)));
FORM_TITLE["Besomite"]="Broom-Riding Kiwi";SM("Besomite","Over The Moon","STR","a",80,95,"spd+1","Kick off from the top of the hill, and don't look down until you're past the moon.");
/* Wickwarden: a stag made like a punched-tin lantern, lit from inside, with a candle burning on every tine of its antlers.
   It stands over the last lantern on Lantern Night. The antlers sway, the candles flicker, the jaw opens when it bells. */
addForm("Wickwarden",{n:"#C8BCA0",a:"#FFB43A",rn:"#4A5A7A",rb:"#2A3450",ra:"#7AE8FF"},"stand",(P,g)=>{const L=P.ac,LL=g>=2?"#FFF2C8":"#FFE7A0";
 const cand=(x,y,s)=>`<rect x="${x-2.2*s}" y="${y}" width="${4.4*s}" height="${7*s}" rx="1" fill="#F4ECD8" ${SW2}/><g class="pt p-glow" style="transform-origin:${x}px ${y}px"><path d="M${x} ${y-1} Q${x-4*s} ${y-6*s} ${x} ${y-12*s} Q${x+4*s} ${y-6*s} ${x} ${y-1} Z" fill="${L}" stroke="${FI}" stroke-width="1.2"/><path d="M${x} ${y-2} Q${x-1.6*s} ${y-5*s} ${x} ${y-8*s} Q${x+1.6*s} ${y-5*s} ${x} ${y-2} Z" fill="${LL}"/></g>`;
 const antler=(sx,dir)=>{const tips=[[sx+dir*-14,10],[sx+dir*2,4],[sx+dir*16,14],[sx+dir*-24,26]];
   return`<path d="M${sx} 44 Q${sx+dir*-4} 30 ${sx+dir*-6} 18 Q${sx+dir*-8} 12 ${sx+dir*-14} 14 M${sx+dir*-5} 24 Q${sx} 14 ${sx+dir*2} 8 M${sx+dir*-2} 34 Q${sx+dir*10} 26 ${sx+dir*16} 18 M${sx+dir*-4} 30 Q${sx+dir*-16} 30 ${sx+dir*-24} 30" stroke="${FI}" stroke-width="6.4" fill="none" stroke-linecap="round"/>
   <path d="M${sx} 44 Q${sx+dir*-4} 30 ${sx+dir*-6} 18 Q${sx+dir*-8} 12 ${sx+dir*-14} 14 M${sx+dir*-5} 24 Q${sx} 14 ${sx+dir*2} 8 M${sx+dir*-2} 34 Q${sx+dir*10} 26 ${sx+dir*16} 18 M${sx+dir*-4} 30 Q${sx+dir*-16} 30 ${sx+dir*-24} 30" stroke="${P.nd}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`+tips.map(([x,y])=>cand(x,y,1.1)).join("")};
 const holes=(cx,cy,rx,ry)=>{let h="";for(let yy=-2;yy<=2;yy++)for(let xx=-4;xx<=4;xx++){const x=cx+xx*rx/4.6+(yy%2?rx/9:0),y=cy+yy*ry/2.8;if((xx+yy)%2===0&&((x-cx)/rx)**2+((y-cy)/ry)**2<.72)h+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.25" fill="${L}" stroke="${FI}" stroke-width=".5"/>`}return h};
 return fShadow(58,110)+
 pt("tail",150,84,`<path d="M148 84 Q160 72 158 86 Q156 92 148 90 Z" fill="${P.n}" ${SW}/><path d="M152 80 Q158 78 156 86" stroke="#F4ECD8" stroke-width="2" fill="none"/>`)+
 [[132,"legB",.25],[144,"legB",.0]].map(([x,c,d])=>pt(c,x,112,`<path d="M${x-5} 110 L${x-7} 128 L${x-4} 144 L${x+3} 144 L${x+3} 128 L${x+5} 110 Z" fill="${P.nd}" ${SW}/><path d="M${x-5} 140 H${x+4}" stroke="${FI}" stroke-width="2"/>`,d)).join("")+
 `<path d="M80 96 Q78 72 104 68 Q134 64 152 74 Q162 88 154 106 Q144 118 112 118 Q86 118 80 96 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M86 104 Q118 112 150 102" stroke="${P.nd}" stroke-width="2" fill="none"/><path d="M92 76 Q120 70 148 78" stroke="${P.nl}" stroke-width="2.4" fill="none" opacity=".8"/>`+
 `<rect x="104" y="80" width="30" height="24" rx="3" fill="${FI}"/><rect x="107" y="83" width="24" height="18" rx="2" fill="${L}"/>${holes(119,92,11,8)}<path d="M107 92 H131 M119 83 V101" stroke="${FI}" stroke-width="1.6"/>`+
 holes(140,90,9,10)+holes(92,94,8,9)+
 [[88,"legF",0],[100,"legF",.25]].map(([x,c,d])=>pt(c,x,112,`<path d="M${x-5} 110 L${x-6} 128 L${x-4} 144 L${x+3} 144 L${x+3} 128 L${x+5} 110 Z" fill="${P.n}" ${SW}/><path d="M${x-5} 140 H${x+4}" stroke="${FI}" stroke-width="2"/>`,d)).join("")+
 `<path d="M84 90 Q72 74 70 58 L84 54 Q88 72 98 82 Z" fill="${P.n}" ${SW}/>`+
 pt("head",72,56,
  pt("ant",70,42,`<g transform="translate(0 7)">${antler(66,1)+antler(80,-1)}</g>`)+
  pt("ear",82,46,`<path d="M80 48 Q90 36 96 40 Q92 48 84 52 Z" fill="${P.n}" ${SW2}/><path d="M84 48 Q90 42 93 42" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`)+
  `<path d="M84 50 Q74 42 62 46 Q48 52 40 58 Q38 64 46 66 L62 66 Q78 64 84 58 Z" fill="${P.n}" ${SW}/>${E2(66,52,2.8,"#1A1A1A")}<circle cx="41" cy="59" r="2.4" fill="${FI}"/>`+
  pt("beak",60,64,`<path d="M44 64 Q52 70 64 68 L62 64 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="30" r="2" fill="${LL}"/><circle cx="178" cy="40" r="1.6" fill="${LL}"/>`)+fG(g,2,`<path d="M118 66 Q119 60 120 66" stroke="${L}" stroke-width="1.4" fill="none"/>`)+fG(g,3,star(176,128,6))});
FORM_TITLE["Wickwarden"]="Candle-Antlered Stag";SM("Wickwarden","Last Light","HEA","a",85,95,"tacc-1@40","The last lantern on Lantern Night is the one that never goes out, because something is standing over it.");
/* Gutterwick, Overclocked: the shadow all the way out of its vial at last. Gaunt and stooped, all neck and arm, its small head pushed
   forward and split by a grin full of needle teeth that glows with the light it's drunk. It carries its vial hanging from one long hand
   like a lantern, swinging, and what spills out of the bottom is dark. Drawn to go through the same shadow treatment as Hollowmere's alloys. */
addForm("Gutterwick",{n:"#6A6480",a:"#FFB43A",rn:"#4A5A7A",rb:"#2A3450",ra:"#7AE8FF"},"stand",(P,g)=>{const B=P.nd,BB=P.ndd,M=P.n;
 const claw=(x,y,d)=>[0,1,2,3].map(k=>`<path d="M${x} ${y} Q${x+d*(2+k*2)} ${y+6} ${x+d*(1+k*2.4)} ${y+12+k*1.4}" stroke="${BB}" stroke-width="${2.2-k*.3}" fill="none" stroke-linecap="round"/>`).join("");
 return fShadow(46,104)+
 /* the dark spilling out of the lantern, down to the ground */
 `<ellipse cx="70" cy="146" rx="30" ry="4" fill="#000000" opacity=".45"/><ellipse cx="70" cy="146" rx="16" ry="2.6" fill="#000000" opacity=".5"/>${[[66,.5,1.6],[70,.6,2.2],[74,.45,1.4]].map(([x,o,w],i)=>`<path d="M${x} 134 Q${x+(i-1)*2} 140 ${x+(i-1)*4} 146" stroke="#000000" stroke-width="${w}" fill="none" opacity="${o}" stroke-linecap="round"/>`).join("")}`+
 pt("legB",124,92,`<path d="M120 92 L128 92 L132 120 L130 146 L124 146 L125 120 Z" fill="${BB}" ${SW}/><path d="M124 146 L118 148 M130 146 L136 148" stroke="${BB}" stroke-width="2.4" stroke-linecap="round"/>`,.2)+
 pt("armB",128,56,`<path d="M128 56 Q142 74 142 92 Q142 106 138 116" stroke="${BB}" stroke-width="6" fill="none" stroke-linecap="round"/>${claw(138,116,1)}`)+
 `<path d="M98 56 Q106 48 120 48 Q132 50 132 58 Q128 70 124 80 Q122 88 124 94 L112 96 Q112 86 108 78 Q100 68 98 56 Z" fill="${M}" ${SW}/><path d="M106 60 Q114 64 122 58 M107 66 Q115 70 122 64 M109 72 Q116 75 121 70" stroke="${B}" stroke-width="1.2" fill="none" opacity=".8"/>`+
 pt("legF",112,94,`<path d="M108 94 L116 94 L114 120 L118 146 L111 146 L108 120 Z" fill="${B}" ${SW}/><path d="M111 146 L104 148 M117 146 L122 148" stroke="${B}" stroke-width="2.4" stroke-linecap="round"/>`)+
 `<path d="M104 54 Q98 44 92 40" stroke="${M}" stroke-width="8" fill="none" stroke-linecap="round"/>`+
 pt("armF",100,58,`<path d="M100 58 Q86 64 80 80 Q76 90 72 98" stroke="${M}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M72 98 l-2 6 M72 98 l3 6 M72 98 l-5 4" stroke="${B}" stroke-width="1.8" stroke-linecap="round"/>`+
  /* the vial, carried like a lantern */
  pt("sway",71,100,`<path d="M71 100 L70 106" stroke="${B}" stroke-width="1.6"/><ellipse cx="70" cy="108" rx="2.6" ry="1.8" fill="none" stroke="${B}" stroke-width="1.4"/>
   <rect x="64" y="110" width="12" height="4" rx="1" fill="${B}" ${SW2}/><path d="M64 114 L64 128 Q64 134 70 134 Q76 134 76 128 L76 114 Z" fill="${BB}" ${SW2}/>
   <path class="p-glow" d="M64 114 L64 128 Q64 134 70 134 Q76 134 76 128 L76 114" fill="none" stroke="#FFB43A" stroke-width="1.4" opacity=".7"/><path d="M67 118 V128" stroke="#FFFFFF" stroke-width="1" opacity=".5"/>`))+
 pt("head",92,40,`<path d="M92 40 Q78 42 74 30 Q72 18 82 14 Q94 12 96 24 Q97 34 92 40 Z" fill="${M}" ${SW}/><path d="M80 15 Q78 8 82 3 Q84 0 82 -4 M88 13 Q92 8 90 3" stroke="${M}" stroke-width="1.6" fill="none" stroke-linecap="round" opacity=".55"/>
   <g class="eye"><circle cx="80" cy="24" r="1.6" fill="#FFFFFF"/><circle cx="87" cy="23" r="1.6" fill="#FFFFFF"/></g>`+
  pt("beak",86,32,`<path d="M75 30 Q84 37 94 29 Q90 40 84 41 Q78 40 75 30 Z" fill="${BB}" ${SW2}/><path class="p-glow" d="M75 30 Q84 37 94 29" stroke="#FFB43A" stroke-width="1" fill="none" opacity=".8"/>
   ${Array.from({length:8},(_,k)=>{const x=76.4+k*2.2,y=31+Math.sin(k/7*Math.PI)*3.6;return`<path d="M${x.toFixed(1)} ${y.toFixed(1)} L${(x+1).toFixed(1)} ${(y+4).toFixed(1)} L${(x+2).toFixed(1)} ${y.toFixed(1)} Z" fill="#FFFFFF"/>`}).join("")}`))+
 fG(g,1,`<circle cx="40" cy="60" r="1.6" fill="#FFFFFF" opacity=".6"/><circle cx="160" cy="40" r="1.2" fill="#FFFFFF" opacity=".5"/>`)+fG(g,2,`<path d="M58 140 Q70 136 82 140" stroke="#000000" stroke-width="3" fill="none" opacity=".5"/>`)+fG(g,3,star(166,130,6))});
FORM_TITLE["Gutterwick"]="Lamp-Bearing Shade";
