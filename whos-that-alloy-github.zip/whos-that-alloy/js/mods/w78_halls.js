/* =============== THE ASSAY HALLS, FROM OUTSIDE ===============
   Each hall is built the way its own area would build it: a brick pithead hall with a winding tower, a patched tin shed,
   a boathouse on its rock, a stone foundry, a marble hallmark office, a hazard-striped bunker, a snowed-in timber lodge
   and a domed observatory. All of them face south with the front door in the middle, and the hall's seal over the door
   (it turns gold once you've earned it). Drawn 9 squares wide; the roof rises above the footprint. */
const HALL_MAT=PS(`<rect x="0" y="0" width="40" height="40" fill="#2A2A30"/><path d="M6 0 H34 V40 H6 Z" fill="#E8D8A8"/><path d="M6 0 H34 V8 H6 Z" fill="#FFF4D0"/><rect x="9" y="22" width="22" height="13" rx="2" fill="#8A3A2A" stroke="${FI}" stroke-width="1.4"/><path d="M12 26 H28 M12 30 H28" stroke="#C86A4A" stroke-width="1.2"/><path d="M6 0 V40 M34 0 V40" stroke="${FI}" stroke-width="2.4"/>`);
const HX={};
const hxK=(c,w)=>`stroke="${FI}" stroke-width="${w||2.6}" stroke-linejoin="round"`;
function hxSeal(x,y,on,r){r=r||13;return`<circle cx="${x}" cy="${y}" r="${r+3}" fill="${FI}"/><circle cx="${x}" cy="${y}" r="${r}" fill="${on?"#F2C94C":"#D8D0BC"}" stroke="${on?"#8A6418":"#8A8270"}" stroke-width="2"/>
  <circle cx="${x}" cy="${y}" r="${r*.62}" fill="none" stroke="${on?"#B8861E":"#A8A090"}" stroke-width="1.6"/>${on?`<path d="M${x-5} ${y} L${x-1.4} ${y+4} L${x+5.6} ${y-4.4}" stroke="#6A4410" stroke-width="2.6" fill="none" stroke-linecap="round"/>`:`<circle cx="${x}" cy="${y}" r="2.4" fill="#A8A090"/>`}`}
function hxDoor(c,arch,frame){const f=frame||FI;return`<path d="M162 240 V${arch?208:200} ${arch?"Q180 190 198 208":"H198"} V240 Z" fill="${c}" ${hxK()}/><path d="M180 ${arch?199:200} V240" stroke="${f}" stroke-width="1.6"/><circle cx="174" cy="224" r="2" fill="#F2C94C"/><circle cx="186" cy="224" r="2" fill="#F2C94C"/>`}
function hxWin(x,y,w,h,glass,frame){return`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${glass}" ${hxK(0,2.2)}/><path d="M${x+w/2} ${y} V${y+h} M${x} ${y+h/2} H${x+w}" stroke="${frame||FI}" stroke-width="1.6"/><path d="M${x+3} ${y+3} L${x+w*.35} ${y+3}" stroke="#FFFFFF" stroke-width="1.6" opacity=".6"/>`}
const hxShadow=`<ellipse cx="180" cy="241" rx="172" ry="8" fill="#000" opacity=".22"/>`;
const hxSteps=(c)=>`<rect x="148" y="234" width="64" height="6" fill="${c}" ${hxK(0,1.8)}/>`;

/* PITHEAD (the Mine): soot-dark brick, slate roof, a timber winding tower with its wheel over one end */
HX["z-mine"]=on=>`${hxShadow}
  <g transform="translate(276 0)"><path d="M10 120 L30 16 L50 120 M18 78 H42 M14 100 H46 M22 52 H38" stroke="#6A4420" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M10 120 L30 16 L50 120" stroke="${FI}" stroke-width="2" fill="none"/>
   <circle cx="30" cy="22" r="17" fill="none" stroke="#3A3A40" stroke-width="5"/><circle cx="30" cy="22" r="17" fill="none" stroke="${FI}" stroke-width="1.4"/>${[0,45,90,135].map(a=>`<path d="M30 22 l${(17*Math.cos(a*Math.PI/180)).toFixed(1)} ${(17*Math.sin(a*Math.PI/180)).toFixed(1)} M30 22 l${(-17*Math.cos(a*Math.PI/180)).toFixed(1)} ${(-17*Math.sin(a*Math.PI/180)).toFixed(1)}" stroke="#3A3A40" stroke-width="2"/>`).join("")}<circle cx="30" cy="22" r="4" fill="#E0B820" stroke="${FI}" stroke-width="1.4"/></g>
  <rect x="16" y="110" width="328" height="130" fill="#8A4A36" ${hxK()}/>
  ${Array.from({length:12},(_,r)=>`<path d="M18 ${118+r*10} H342" stroke="#6A3426" stroke-width="1.2" opacity=".7"/>`).join("")}${Array.from({length:60},(_,i)=>{const r=i%12,c=(i*7)%16;return`<path d="M${24+c*20+(r%2)*10} ${110+r*10} v10" stroke="#6A3426" stroke-width="1" opacity=".6"/>`}).join("")}
  <path d="M4 114 L54 64 H306 L356 114 Z" fill="#4A4E5A" ${hxK()}/>${[76,88,100].map(y=>`<path d="M${4+(114-y)} ${y} H${356-(114-y)}" stroke="#3A3E48" stroke-width="1.4"/>`).join("")}
  <rect x="226" y="40" width="22" height="34" fill="#7A3A2A" ${hxK(0,2.2)}/><rect x="222" y="36" width="30" height="8" fill="#5A2A1E" ${hxK(0,2)}/>
  ${hxWin(40,140,40,44,"#F6D27A")}${hxWin(98,140,40,44,"#F6D27A")}${hxWin(222,140,40,44,"#F6D27A")}${hxWin(280,140,40,44,"#F6D27A")}
  <rect x="150" y="190" width="60" height="8" fill="#5A3A20" ${hxK(0,1.8)}/>${hxDoor("#5A3A20",false)}${hxSteps("#8A8270")}${hxSeal(180,150,on)}
  <rect x="16" y="226" width="328" height="14" fill="#5A4A3E" ${hxK(0,2)}/>
  ${[60,300].map(x=>`<path d="M${x} 240 V206" stroke="${FI}" stroke-width="2.4"/><rect x="${x-6}" y="196" width="12" height="12" rx="2" fill="#FFE07A" ${hxK(0,1.8)}/>`).join("")}`;

/* SCRAPHEAP (the Scrapyard): a tin shed patched with whatever was to hand, rivets, a gantry hook over the door */
HX["z-scrap"]=on=>`${hxShadow}
  <path d="M14 240 V100 L180 54 L346 100 V240 Z" fill="#8A929A" ${hxK()}/>
  ${Array.from({length:21},(_,i)=>`<path d="M${22+i*16} ${i<10?100-(i*16+8)*.278+10:54+((i*16+22)-180)*.278+10} V240" stroke="#6A727A" stroke-width="2"/>`).join("")}
  <path d="M40 120 h70 v52 h-70 Z" fill="#B87A4A" ${hxK(0,2)} opacity=".95"/><path d="M250 112 h64 v44 h-64 Z" fill="#6A7A5A" ${hxK(0,2)}/><path d="M232 178 h50 v40 h-50 Z" fill="#C8A04A" ${hxK(0,2)}/>
  ${[[44,124],[106,124],[44,168],[106,168],[254,116],[310,116],[254,152],[310,152],[236,182],[278,182],[236,214],[278,214]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="${FI}"/>`).join("")}
  <path d="M6 104 L180 56 L354 104" stroke="#5A6068" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M6 104 L180 56 L354 104" stroke="${FI}" stroke-width="2" fill="none"/>
  <path d="M140 74 V30 H260 V44" stroke="#C8A040" stroke-width="6" fill="none"/><path d="M140 74 V30 H260 V44" stroke="${FI}" stroke-width="1.6" fill="none"/><path d="M240 30 V60" stroke="${FI}" stroke-width="1.6"/><path d="M234 60 q6 10 12 0" stroke="#6A6A6A" stroke-width="3" fill="none"/>
  ${hxWin(56,180,34,26,"#BFE0F0")}${hxWin(296,170,34,26,"#BFE0F0")}
  <rect x="150" y="186" width="60" height="54" fill="#4A5258" ${hxK()}/>${hxDoor("#6A5A4A",false)}<path d="M162 210 H198 M162 224 H198" stroke="#4A3E30" stroke-width="1.6"/>${hxSteps("#7A7268")}${hxSeal(180,124,on)}
  <path d="M14 240 h20 l-4 -12 h-12 Z M320 240 h26 l-6 -10 h-14 Z" fill="#6A5A4A" ${hxK(0,1.6)}/>`;

/* TIDELINE (the Cove): a boathouse on its rock, blue weatherboard, round windows, a bell and a coil of rope by the door */
HX["z-wreck"]=on=>`${hxShadow}
  <rect x="18" y="104" width="324" height="136" fill="#4A7AA8" ${hxK()}/>${Array.from({length:13},(_,i)=>`<path d="M20 ${114+i*10} H340" stroke="#3A6088" stroke-width="1.6"/>`).join("")}
  <path d="M2 110 L180 40 L358 110 Z" fill="#7A5A3A" ${hxK()}/>${[60,80,96].map(y=>`<path d="M${2+(110-y)*2.54} ${y} H${358-(110-y)*2.54}" stroke="#5A4026" stroke-width="1.4"/>`).join("")}
  <path d="M180 40 V14 M168 20 h24 M172 14 l16 0" stroke="${FI}" stroke-width="2.4"/><path d="M168 8 q12 -8 24 0 q-12 8 -24 0 Z" fill="#C8A040" ${hxK(0,1.6)}/>
  ${[70,290].map(x=>`<circle cx="${x}" cy="160" r="22" fill="#BFE0F0" ${hxK(0,3)}/><circle cx="${x}" cy="160" r="22" fill="none" stroke="#C8A040" stroke-width="3"/><path d="M${x-10} ${152} q6 -4 12 0" stroke="#FFFFFF" stroke-width="2" fill="none" opacity=".7"/>`).join("")}
  <rect x="150" y="186" width="60" height="54" fill="#E8E0D0" ${hxK(0,2)}/>${hxDoor("#2E4A6A",true)}${hxSteps("#9A8A6A")}${hxSeal(180,140,on)}
  <path d="M232 120 V140" stroke="${FI}" stroke-width="2"/><path d="M222 140 q10 -16 20 0 v6 h-20 Z" fill="#C8A040" ${hxK(0,1.8)}/>
  <ellipse cx="236" cy="230" rx="16" ry="7" fill="none" stroke="#C8B080" stroke-width="5"/><ellipse cx="236" cy="230" rx="9" ry="4" fill="none" stroke="#C8B080" stroke-width="4"/>
  <rect x="18" y="226" width="324" height="14" fill="#6A5A44" ${hxK(0,2)}/>`;

/* FORGE (the Caldera): black basalt foundry, two stacks breathing heat, arched windows lit from the furnaces inside */
HX["z-volcano"]=on=>`${hxShadow}
  ${[[48,28],[290,38]].map(([x,t])=>`<rect x="${x}" y="${t}" width="26" height="90" fill="#3A302C" ${hxK()}/><rect x="${x-4}" y="${t-6}" width="34" height="10" fill="#2A2220" ${hxK(0,2)}/><ellipse cx="${x+13}" cy="${t-6}" rx="10" ry="3" fill="#FF8A2A"/>`).join("")}
  <rect x="14" y="100" width="332" height="140" fill="#4A3E3A" ${hxK()}/>${Array.from({length:40},(_,i)=>{const r=i%6,c=(i*5)%14;return`<path d="M${22+c*24+(r%2)*12} ${108+r*22} h20 v18 h-20 Z" fill="none" stroke="#2E2624" stroke-width="1.4"/>`}).join("")}
  <path d="M4 104 L40 70 H320 L356 104 Z" fill="#2A2220" ${hxK()}/>
  ${[44,106,236,298].map(x=>`<path d="M${x} 196 V146 Q${x+9} 128 ${x+18} 128 Q${x+27} 128 ${x+36} 146 V196 Z" fill="#FF9A3A" ${hxK(0,2.4)}/><path d="M${x+18} 128 V196 M${x} 166 H${x+36}" stroke="#7A2A10" stroke-width="2"/><path d="M${x+4} 192 V170 Q${x+18} 160 ${x+32} 170 V192" fill="#FFD27A" opacity=".55"/>`).join("")}
  <rect x="146" y="180" width="68" height="60" fill="#2A2220" ${hxK()}/>${hxDoor("#5A5A62",true,"#2A2A30")}${[170,190].map(x=>`<path d="M${x} 200 V238" stroke="#3A3A42" stroke-width="2"/>`).join("")}${hxSteps("#3A302C")}${hxSeal(180,150,on)}
  <rect x="14" y="228" width="332" height="12" fill="#2A2220" ${hxK(0,2)}/>`;

/* HALLMARK (the Vault): pale marble, six columns, a pediment with the seal set in it, gilt edging */
HX["z-vault"]=on=>`${hxShadow}
  <rect x="24" y="96" width="312" height="144" fill="#E8E0CC" ${hxK()}/>
  <path d="M10 98 L180 30 L350 98 Z" fill="#F2ECDA" ${hxK()}/><path d="M38 90 L180 42 L322 90 Z" fill="#E2D8C0" stroke="#C8A848" stroke-width="2"/>
  <rect x="10" y="96" width="340" height="12" fill="#F6F0E0" ${hxK(0,2.2)}/><path d="M12 104 H348" stroke="#C8A848" stroke-width="2"/>
  ${[44,94,144,206,256,306].map(x=>`<rect x="${x}" y="108" width="14" height="114" fill="#FFFAEE" ${hxK(0,2)}/><rect x="${x-4}" y="108" width="22" height="7" fill="#F2ECDA" ${hxK(0,1.6)}/><rect x="${x-4}" y="216" width="22" height="7" fill="#F2ECDA" ${hxK(0,1.6)}/><path d="M${x+5} 116 V214 M${x+9} 116 V214" stroke="#D8D0BC" stroke-width="1.2"/>`).join("")}
  ${hxWin(70,140,18,40,"#3A4A6A","#C8A848")}${hxWin(272,140,18,40,"#3A4A6A","#C8A848")}
  <rect x="10" y="222" width="340" height="18" fill="#D8D0BC" ${hxK(0,2)}/><rect x="0" y="232" width="360" height="8" fill="#C8BEA4" ${hxK(0,1.8)}/>
  ${hxDoor("#6A4A1E",true,"#C8A848")}<path d="M162 210 H198" stroke="#C8A848" stroke-width="1.6"/>${hxSeal(180,72,on,14)}`;

/* CONTAINMENT (the Reactor): a poured concrete bunker, yellow-and-black band, vents, a warning lamp over a round-shouldered door */
HX["z-reactor"]=on=>`${hxShadow}
  <path d="M12 240 V96 Q12 78 30 78 H330 Q348 78 348 96 V240 Z" fill="#B8BCB4" ${hxK()}/>
  ${Array.from({length:6},(_,i)=>`<path d="M14 ${110+i*22} H346" stroke="#9EA29A" stroke-width="1.4"/>`).join("")}
  <rect x="12" y="92" width="336" height="16" fill="#F2C230" ${hxK(0,2)}/>${Array.from({length:22},(_,i)=>`<path d="M${16+i*16} 108 l12 -16 h7 l-12 16 Z" fill="#1E1E22"/>`).join("")}
  ${[44,284].map(x=>`<rect x="${x}" y="132" width="40" height="40" rx="4" fill="#6A706A" ${hxK(0,2.2)}/><circle cx="${x+20}" cy="152" r="15" fill="#4A504A"/>${[0,60,120,180,240,300].map(a=>`<path d="M${x+20} 152 l${(13*Math.cos(a*Math.PI/180)).toFixed(1)} ${(13*Math.sin(a*Math.PI/180)).toFixed(1)}" stroke="#9AA09A" stroke-width="3"/>`).join("")}`).join("")}
  <rect x="104" y="44" width="40" height="36" fill="#9EA29A" ${hxK(0,2.2)}/>${[54,62,70].map(y=>`<path d="M108 ${y} H140" stroke="#6A706A" stroke-width="2"/>`).join("")}
  <rect x="144" y="176" width="72" height="64" fill="#F2C230" ${hxK()}/>${Array.from({length:5},(_,i)=>`<path d="M${146+i*15} 178 l10 0 l-10 14 Z" fill="#1E1E22"/>`).join("")}
  <path d="M158 240 V206 Q158 192 172 192 H188 Q202 192 202 206 V240 Z" fill="#7A8478" ${hxK()}/><circle cx="180" cy="214" r="8" fill="none" stroke="#4A504A" stroke-width="2.4"/><path d="M180 206 V222 M172 214 H188" stroke="#4A504A" stroke-width="2"/>
  <circle cx="180" cy="166" r="7" fill="#B8F07A" ${hxK(0,2)}/>${hxSteps("#8A8E86")}${hxSeal(180,128,on,12)}`;

/* FROSTLINE (the Cavern): a timber lodge under a steep roof heavy with snow, icicles off the eaves, frost on the panes */
HX["z-glacier"]=on=>`${hxShadow}
  <rect x="26" y="122" width="308" height="118" fill="#8A5A3A" ${hxK()}/>${Array.from({length:11},(_,i)=>`<path d="M28 ${132+i*10} H332" stroke="#6A4226" stroke-width="2"/>`).join("")}
  <path d="M0 130 L180 6 L360 130 Z" fill="#5A3A26" ${hxK()}/><path d="M4 124 L180 12 L356 124 L340 132 Q300 120 260 134 Q220 120 180 134 Q140 120 100 134 Q60 120 20 132 Z" fill="#F4F8FC" ${hxK(0,2.2)}/>
  ${Array.from({length:16},(_,i)=>{const x=24+i*20,l=8+((i*7)%4)*5;return`<path d="M${x-3} 130 L${x} ${130+l} L${x+3} 130 Z" fill="#DDF2FF" stroke="#8AB0CC" stroke-width="1"/>`}).join("")}
  <rect x="160" y="40" width="40" height="44" fill="#E2EEF8" ${hxK(0,2)}/><path d="M164 44 H196 V80 H164 Z" fill="#FFE0A0"/><path d="M180 44 V80 M164 62 H196" stroke="${FI}" stroke-width="1.6"/>
  ${[52,108,234,290].map(x=>`${hxWin(x,152,22,32,"#FFE0A0")}<path d="M${x+2} ${180} q8 -6 18 0" stroke="#FFFFFF" stroke-width="3" fill="none" opacity=".8"/>`).join("")}
  ${hxDoor("#4A2E1A",true)}${hxSeal(180,166,on,11)}<path d="M140 240 q40 -14 80 0 Z M10 240 q40 -16 70 0 Z M290 240 q36 -14 64 0 Z" fill="#F4F8FC" ${hxK(0,1.6)}/>`;

/* STARFALL (the Crater): an observatory: a squat round-cornered hall with a big slatted dome and its telescope poking out */
HX["z-crater"]=on=>`${hxShadow}
  <rect x="20" y="118" width="320" height="122" rx="10" fill="#6A5A8A" ${hxK()}/>${Array.from({length:7},(_,i)=>`<path d="M22 ${134+i*15} H338" stroke="#5A4A78" stroke-width="1.4"/>`).join("")}
  <path d="M84 122 Q84 24 180 20 Q276 24 276 122 Z" fill="#C8CCD8" ${hxK()}/>${[-60,-30,0,30,60].map(o=>`<path d="M${180+o*1.5} 122 Q${180+o*1.1} 40 180 20" stroke="#9AA0B0" stroke-width="2" fill="none"/>`).join("")}
  <path d="M168 122 V30 Q180 22 192 30 V122 Z" fill="#2A2440" ${hxK(0,2)}/><path d="M184 54 L238 18" stroke="#B8A8D8" stroke-width="12" stroke-linecap="round"/><path d="M184 54 L238 18" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="240" cy="17" r="7" fill="#2A2440" ${hxK(0,2)}/>
  <rect x="14" y="112" width="332" height="12" rx="4" fill="#4A3E66" ${hxK(0,2)}/>
  ${[50,104,236,290].map(x=>`<circle cx="${x+10}" cy="160" r="16" fill="#2A2440" ${hxK(0,2.4)}/><path d="M${x+10} ${150} l2.4 7.6 l7.6 2.4 l-7.6 2.4 l-2.4 7.6 l-2.4 -7.6 l-7.6 -2.4 l7.6 -2.4 Z" fill="#E8F0FF"/>`).join("")}
  ${hxDoor("#3A2E5A",true,"#B8A8D8")}${hxSteps("#8A7EA8")}${hxSeal(180,162,on,11)}`;

/* ---- putting the hall in its forecourt ---- */
function hallOutside(z){const W=EXP.W,H=EXP.H,on=asData().seals.includes(z),d=document.createElement("div");
  d.className="mapobj hallx hx-"+z;d.style.width=(HB.w*100/W)+"%";d.style.height=((HB.h+1)*100/H)+"%";d.style.left=(HB.x/W*100)+"%";d.style.top=((HB.y-1)/H*100)+"%";d.dataset.base=HB.y+HB.h-1;
  d.innerHTML=`<svg viewBox="0 0 360 240" preserveAspectRatio="none" aria-hidden="true">${HX[z](on)}</svg>`;$("#world").insertBefore(d,$("#player"));
  const[dx,dy]=HB.door;EXP.objs.push({x:dx,y:dy,tile:1,use:()=>hallEnter(z)})}
/* the hall is layered by its front wall, not its roof: walk behind it and it hides you, walk in front and you're in front */
{const _dr=depthRow;depthRow=function(el){if(el.dataset&&el.dataset.base)return+el.dataset.base;return _dr(el)}}
