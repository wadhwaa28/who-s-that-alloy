/* ---- Rustvein Mine, 7 ---- */
/* Latecomer's Mix: 'the latecomer who will be forgiven', forty minutes after the others. A sloth clutching an alarm clock, still yawning. */
addForm("Latecomer's Mix",{n:"#8A7A5A",a:"#E8D8B8",rn:"#3A3A4A",rb:"#B8D0E8",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 40 Q104 30 194 44" stroke="#6A4A2A" stroke-width="10" stroke-linecap="round"/><path d="M60 36 q4 -10 12 -8 M150 38 q4 -10 12 -8" stroke="#5A9A3A" stroke-width="4" fill="none"/>`+fShadow(40,104)+
 pt("armB",126,44,`<path d="M124 44 Q130 66 124 84" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M124 44 Q130 66 124 84" stroke="${P.nd}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M120 40 q4 -6 8 0 M124 40 q4 -6 8 0" stroke="${FI}" stroke-width="2" fill="none"/>`,.4)+
 pt("legB",126,110,`<path d="M124 108 Q138 120 134 134" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M124 108 Q138 120 134 134" stroke="${P.nd}" stroke-width="9" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M84 96 Q80 62 106 58 Q132 62 130 98 Q126 120 106 120 Q86 120 84 96 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${92+i*8} ${70+i%2*6} q2 12 -2 24" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("legF",90,112,`<path d="M90 110 Q80 122 84 134" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M90 110 Q80 122 84 134" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`)+
 pt("armF",86,76,`<path d="M88 72 Q70 82 68 98" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M88 72 Q70 82 68 98" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/><circle cx="64" cy="108" r="12" fill="${P.b}" ${SW}/><circle cx="64" cy="108" r="8.6" fill="#F4F0E4" ${SW2}/><path d="M64 108 V102 M64 108 L68 110" stroke="${FI}" stroke-width="1.6" stroke-linecap="round"/><circle cx="56" cy="96" r="4" fill="${P.b}" ${SW2}/><circle cx="72" cy="96" r="4" fill="${P.b}" ${SW2}/>`)+
 pt("head",100,66,`<ellipse cx="100" cy="58" rx="17" ry="15" fill="${P.ac}" ${SW}/><path d="M86 56 Q92 50 98 58 Q92 64 86 56 Z M104 58 Q110 50 116 56 Q110 64 104 58 Z" fill="${P.nd}"/><path d="M89 57 q3 2 6 0 M107 57 q3 2 6 0" stroke="${FI}" stroke-width="1.8" fill="none"/><ellipse cx="100" cy="62" rx="3" ry="2" fill="${FI}"/>`+
  `<path d="M95 66 L105 66 L104 70 L96 70 Z" fill="${FMOUTH}"/>`+pt("jaw",100,70,`<path d="M95 68 Q100 78 105 68 Q100 72 95 68 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<text x="150" y="80" font-family="monospace" font-size="12" font-weight="bold" fill="${P.ac}">+40</text>`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,110,6)));
FORM_TITLE["Latecomer's Mix"]="Alarm-Clock Sloth";SM("Latecomer's Mix","Fashionably Late","RES","a",90,100,"","Turning up last, but making it count.");

/* Latterlite: twelve interns searched all afternoon; a thirteenth found it straight away. A bloodhound wearing a visitor's lanyard, nose down. */
addForm("Latterlite",{n:"#B8743A",a:"#3A2A20",rn:"#E8E0D0",rb:"#3A5AA8",ra:"#F2C94C"},"slink",(P,g)=>fShadow(72)+
 pt("tail",160,92,`<path d="M158 94 Q174 74 178 60" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M158 94 Q174 74 178 60" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",148,108,34,9,P.nd,P.ndd,.5)+fLeg("legB",112,110,32,9,P.nd,P.ndd,1.3)+
 `<path d="M86 102 Q86 78 120 78 Q156 80 162 100 Q158 118 122 118 Q90 118 86 102 Z" fill="${P.n}" ${SW}/><path d="M100 80 Q130 76 150 88 Q130 96 104 94 Z" fill="${P.ac}" opacity=".7"/>`+
 fLeg("legF",140,110,32,9,P.n,P.ndd,0)+fLeg("legF",100,110,32,9,P.n,P.ndd,.8)+
 pt("head",90,96,`<path d="M92 100 Q80 104 72 116" stroke="${P.n}" stroke-width="20" stroke-linecap="round"/><path d="M40 128 Q36 112 52 104 Q72 100 80 114 Q80 130 64 134 Q48 136 40 128 Z" fill="${P.n}" ${SW}/><ellipse cx="40" cy="128" rx="5" ry="4" fill="${FI}"/>${[0,1].map(i=>`<path d="M${56+i*6} ${110+i*2} q4 4 8 2" stroke="${P.nd}" stroke-width="1.8" fill="none"/>`).join("")}${E2(62,114,3.4,"#6A2A1A")}<path d="M56 112 q6 -4 12 0" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`+
  `<path d="M44 132 L58 134 L56 138 L46 137 Z" fill="${FMOUTH}"/>`+pt("jaw",56,137,`<path d="M58 136 Q50 144 44 136 Q50 140 58 139 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ear",72,106,`<path d="M70 104 Q88 102 86 130 Q84 142 74 138 Q76 122 70 112 Z" fill="${P.ac}" ${SW2}/>`)+
  `<path d="M86 96 L84 120 M94 98 L96 120" stroke="#3A5AA8" stroke-width="2.4"/><rect x="80" y="120" width="20" height="14" rx="2" fill="#F4F0E4" ${SW2}/><text x="84" y="131" font-size="8" font-weight="bold" fill="${FI}">13</text>`)+
 fG(g,1,`<path d="M20 140 q4 -6 8 0 M30 136 q4 -6 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="124" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Latterlite"]="Lanyard Bloodhound";SM("Latterlite","First Place You Look","RES","a",65,100,"crit","It's always in the first place you look, once you finally look there.");

/* Leftover No. 9: snowed in for nine days, they mixed leftovers from every shelf. A wolverine with a stew pot for a helmet and a ladle. */
addForm("Leftover No. 9",{n:"#4A3A30",a:"#C89A6A",rn:"#E8E0D0",rb:"#3A6A8A",ra:"#E8604A"},"stand",(P,g)=>`<ellipse cx="104" cy="146" rx="80" ry="6" fill="#F4F8FC" ${SW2}/>`+fShadow(70)+
 pt("tail",160,104,`<path d="M158 102 Q178 104 182 120 Q170 120 160 112 Z" fill="${P.n}" ${SW}/>`)+
 fLeg("legB",148,116,26,11,P.nd,P.ndd,.5)+fLeg("legB",112,118,24,11,P.nd,P.ndd,1.3)+
 `<path d="M86 110 Q84 82 122 80 Q160 82 164 108 Q160 126 124 126 Q90 126 86 110 Z" fill="${P.n}" ${SW}/><path d="M94 100 Q122 92 158 104" stroke="${P.ac}" stroke-width="9" fill="none" opacity=".75" stroke-linecap="round"/>`+
 fLeg("legF",140,118,24,11,P.n,P.ndd,0)+
 pt("armF",100,112,fOL("M102 110 L88 120 L78 112",P.n,10)+`<path d="M78 112 L60 80" stroke="${P.b}" stroke-width="4" stroke-linecap="round"/><ellipse cx="58" cy="76" rx="9" ry="5" fill="${P.b}" ${SW2} transform="rotate(-30 58 76)"/>`)+
 pt("head",88,96,`<path d="M52 104 Q52 84 74 82 Q94 84 96 102 Q92 116 74 116 Q56 116 52 104 Z" fill="${P.n}" ${SW}/><path d="M56 96 Q74 90 94 98" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".75"/><ellipse cx="52" cy="104" rx="4" ry="3.4" fill="${FI}"/>${E2(70,98,3.6,"#3A2410")}`+
  `<path d="M54 108 L70 110 L68 114 L56 112 Z" fill="${FMOUTH}"/>`+pt("jaw",68,113,`<path d="M70 112 Q62 120 54 112 Q62 116 70 115 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M58 84 Q58 64 78 64 Q98 64 98 84 Z" fill="${P.b}" ${SW}/><path d="M54 84 H102" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M54 84 H102" stroke="${P.d}" stroke-width="3" stroke-linecap="round"/><path d="M98 74 Q108 72 108 80" stroke="${FI}" stroke-width="3" fill="none"/><path d="M62 72 Q78 66 94 72" stroke="${P.ll}" stroke-width="2" fill="none"/>`+pt("ear",90,86,`<circle cx="92" cy="88" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`${[[30,30],[170,20],[150,50],[40,60]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#fff" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="124" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Leftover No. 9"]="Stew-Pot Wolverine";SM("Leftover No. 9","Everything Stew","DRP","a",75,100,"corrode@20","A bit of everything from every shelf. Nobody's quite sure what's in it.");

/* Long Gallery Casting: a safe behind a portrait, and inside, a second, smaller portrait. A ferret stepping out of its own portrait frame. */
addForm("Long Gallery Casting",{n:"#E8D8B8",a:"#5A3A2A",rn:"#3A3A4A",rb:"#8A2A3A",ra:"#F2C94C"},"slink",(P,g)=>fShadow(80)+
 `<rect x="88" y="16" width="92" height="110" fill="#5A3A3A" ${SW}/><rect x="80" y="8" width="108" height="126" fill="none" stroke="${FI}" stroke-width="13"/><rect x="80" y="8" width="108" height="126" fill="none" stroke="#C8A040" stroke-width="9"/>${[[80,8],[188,8],[80,134],[188,134]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="6" fill="#C8A040" ${SW2}/>`).join("")}<rect x="146" y="26" width="24" height="30" fill="#C8A040" ${SW2}/><rect x="150" y="30" width="16" height="22" fill="#3A3A4A"/><circle cx="158" cy="38" r="4" fill="#E8D8B8"/>`+
 pt("tail",160,100,`<path d="M156 100 Q174 96 176 80" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M156 100 Q174 96 176 80" stroke="${P.ac}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",142,108,18,7,P.nd,P.ac,.5)+
 `<path d="M60 108 Q60 92 96 90 Q146 92 158 102 Q156 116 120 118 Q74 118 60 108 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",134,112,18,7,P.n,P.ac,0)+pt("legF",72,112,`<path d="M74 110 L64 130 H52" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M74 110 L64 130 H52" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.8)+
 pt("head",62,98,`<path d="M24 96 Q28 82 46 80 Q64 82 66 96 Q62 108 44 108 Q30 108 24 96 Z" fill="${P.n}" ${SW}/><path d="M36 86 Q48 82 60 90 L58 96 Q48 90 38 94 Z" fill="${P.ac}"/><ellipse cx="24" cy="96" rx="3" ry="2.6" fill="${FI}"/>${E2(48,90,3.6,"#1A1A1A")}`+HMOUTH(28,100,36,P,2.6)+
  pt("ear",58,84,`<circle cx="58" cy="82" r="5" fill="${P.n}" ${SW2}/>`)+`<path d="M54 106 Q46 112 40 106 Q48 114 56 110" stroke="#F4F0E4" stroke-width="4" fill="none"/><path d="M44 108 l4 6" stroke="#F4F0E4" stroke-width="3"/>`)+
 fG(g,1,`<rect x="20" y="124" width="22" height="18" fill="#C8A040" ${SW2}/><rect x="24" y="128" width="14" height="10" fill="#3A3A4A"/>`)+fG(g,2,`<circle cx="112" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Long Gallery Casting"]="Portrait Ferret";SM("Long Gallery Casting","Hidden Safe","RES","s",0,100,"def+1,cure","Always check behind the paintings.");

/* Lost Hat Metal: drawn from the lottery hat the year the hat itself went missing. A field mouse living in the lost hat, peering from under the brim. */
addForm("Lost Hat Metal",{n:"#B89A7A",a:"#E8A0B0",rn:"#3A3A4A",rb:"#5A3A2A",ra:"#5FE0A0"},"perch",(P,g)=>fShadow(60)+
 pt("tail",150,138,`<path d="M146 138 Q170 140 178 124 Q184 112 174 110" stroke="${P.ac}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 `<path d="M60 140 Q56 120 64 100 L70 66 Q104 54 138 66 L144 100 Q152 120 148 140 Z" fill="#3A3A44" ${SW}/><path d="M66 92 Q104 82 142 92 L144 100 Q104 90 64 100 Z" fill="#8A2A3A" ${SW2}/><ellipse cx="104" cy="140" rx="58" ry="7" fill="#2A2A34" ${SW}/>`+
 `<path d="M72 140 Q76 120 98 118 Q118 120 120 140 Z" fill="#1A1A22"/>`+
 [[0,"#F4F0E4",24],[1,"#F2C94C",30]].map(([i,c,y])=>`<g transform="rotate(${i?20:-14} ${140+i*10} ${y})"><rect x="${134+i*10}" y="${y}" width="16" height="10" fill="${c}" ${SW2}/><text x="${136+i*10}" y="${y+8}" font-size="6" font-weight="bold" fill="${FI}">${i?"No.4":"No.9"}</text></g>`).join("")+
 pt("armF",90,136,`<ellipse cx="88" cy="138" rx="5" ry="3.4" fill="${P.ac}" ${SW2}/>`)+pt("armB",110,136,`<ellipse cx="112" cy="138" rx="5" ry="3.4" fill="${P.ac}" ${SW2}/>`,.4)+
 pt("head",98,126,`<path d="M76 136 Q74 116 96 114 Q116 116 118 134 Z" fill="${P.n}" ${SW}/><path d="M76 132 L64 134 Q62 128 68 126 L80 124 Z" fill="${P.n}" ${SW2}/><circle cx="64" cy="131" r="2.4" fill="${P.ac}"/>${E2(86,124,4.2,"#1A1A1A")}${E2(100,122,4,"#1A1A1A")}`+HMOUTH(68,134,74,P,2)+`<path d="M66 130 h-10 M66 132 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",108,114,`<circle cx="110" cy="112" r="8" fill="${P.n}" ${SW2}/><circle cx="110" cy="112" r="4.4" fill="${P.ac}"/>`)+pt("ear",90,112,`<circle cx="88" cy="110" r="7" fill="${P.n}" ${SW2}/><circle cx="88" cy="110" r="3.6" fill="${P.ac}"/>`,.3))+
 fG(g,1,`<text x="24" y="50" font-family="Georgia,serif" font-size="20" font-weight="bold" fill="${P.ac}">?</text>`)+fG(g,2,`<circle cx="104" cy="76" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Lost Hat Metal"]="Hat-Dwelling Mouse";SM("Lost Hat Metal","Draw From The Hat","RES","a",55,100,"multi:1-3","Reach in without looking. You get what you get.");

/* Lucky Guess Mix: cocoa blotted two lines and the crew guessed right. An otter floating in a cocoa mug, marshmallow on its belly. */
addForm("Lucky Guess Mix",{n:"#7A5030",a:"#E8D0B0",rn:"#3A3A4A",rb:"#B8D8E8",ra:"#E8412C"},"swim",(P,g)=>fShadow(60)+
 `<path d="M62 84 L66 140 Q104 150 142 140 L146 84 Z" fill="#E8E4DC" ${SW}/><path d="M146 96 Q172 96 170 116 Q168 132 144 128" stroke="${FI}" stroke-width="12" fill="none"/><path d="M146 96 Q172 96 170 116 Q168 132 144 128" stroke="#E8E4DC" stroke-width="8" fill="none"/>${[0,1,2].map(i=>`<circle cx="${84+i*20}" cy="118" r="5" fill="#E8412C" opacity=".7"/>`).join("")}<path d="M94 132 q-4 10 4 12" stroke="#6A3A1A" stroke-width="4" fill="none" stroke-linecap="round"/>`+
 `<ellipse cx="104" cy="86" rx="42" ry="8" fill="#6A3A1A" ${SW}/>`+
 pt("tail",136,82,`<path d="M134 84 Q154 70 160 52" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M134 84 Q154 70 160 52" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/>`)+
 pt("sway",104,80,`<path d="M70 86 Q72 64 104 62 Q132 64 136 86 Z" fill="${P.n}" ${SW}/><path d="M82 86 Q86 72 104 70 Q120 72 124 86" fill="${P.ac}"/><rect x="96" y="66" width="12" height="10" rx="3" fill="#fff" ${SW2}/>`)+
 pt("armF",86,70,`<path d="M88 74 Q78 66 82 58" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M88 74 Q78 66 82 58" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("head",70,72,`<path d="M42 70 Q44 52 62 50 Q80 52 80 68 Q78 82 62 82 Q46 82 42 70 Z" fill="${P.n}" ${SW}/><path d="M42 72 Q46 64 56 66 Q60 76 52 80 Q44 78 42 72 Z" fill="${P.ac}"/><ellipse cx="44" cy="68" rx="3.4" ry="2.6" fill="${FI}"/>${E2(60,62,3.6,"#1A1A1A")}`+HMOUTH(46,76,54,P,2.6)+`<path d="M44 72 h-10 M44 75 l-8 3" stroke="${P.nd}" stroke-width="1"/>`+pt("ear",72,54,`<circle cx="72" cy="54" r="4" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M40 40 q-4 -8 2 -14 M52 40 q-4 -8 2 -14" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Lucky Guess Mix"]="Cocoa-Mug Otter";SM("Lucky Guess Mix","Educated Guess","RES","a",70,75,"crit","Fill in the blanks and hope. Sometimes the hope is right.");

/* Lumbridge Oarsite: mascot of the 1983 regatta, beating a duck and a seagull. A beaver in a rowing cap, tail shaped like an oar blade. */
addForm("Lumbridge Oarsite",{n:"#8A5A3A",a:"#E8DCC0",rn:"#3A4A6A",rb:"#B8302A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(64)+
 pt("tail",150,124,`<path d="M146 124 L162 124" stroke="${FI}" stroke-width="7"/><path d="M146 124 L162 124" stroke="#C89A60" stroke-width="4"/><path d="M160 116 Q190 112 194 124 Q190 136 160 132 Z" fill="${P.b}" ${SW}/><path d="M166 124 H190" stroke="${P.ac}" stroke-width="4"/>`)+
 pt("legB",130,130,`<ellipse cx="134" cy="140" rx="12" ry="5" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M82 128 Q76 92 108 88 Q140 92 144 126 Q138 142 112 142 Q86 142 82 128 Z" fill="${P.n}" ${SW}/><path d="M94 104 Q110 98 130 104 L128 136 Q110 140 94 134 Z" fill="${P.ac}" ${SW2}/><path d="M98 112 H126" stroke="#B8302A" stroke-width="4"/>`+
 pt("legF",94,132,`<ellipse cx="88" cy="140" rx="12" ry="5" fill="${P.n}" ${SW2}/>`)+
 pt("armF",90,104,fOL("M92 104 Q74 106 70 92",P.n,7)+`<path d="M66 60 L72 120" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M66 60 L72 120" stroke="#C89A60" stroke-width="3" stroke-linecap="round"/><path d="M60 40 Q66 34 70 40 L72 64 L64 66 Z" fill="${P.b}" ${SW2}/>`)+
 pt("head",104,82,`<path d="M80 84 Q78 62 104 60 Q128 62 128 84 Q124 100 104 100 Q84 100 80 84 Z" fill="${P.n}" ${SW}/><ellipse cx="94" cy="88" rx="9" ry="7" fill="${P.ac}"/><ellipse cx="90" cy="84" rx="3.6" ry="2.6" fill="${FI}"/>${E2(98,76,4)}${E2(114,76,4)}`+HMOUTH(88,92,98,P,3)+`<rect x="90" y="95" width="5" height="7" fill="#F2A040" ${SW2}/><rect x="95" y="95" width="5" height="7" fill="#F2A040" ${SW2}/>`+
  `<path d="M84 66 Q104 50 126 66 Z" fill="#B8302A" ${SW2}/><path d="M84 66 L70 70" stroke="#B8302A" stroke-width="5" stroke-linecap="round"/><circle cx="104" cy="56" r="3" fill="#F4F0E4" ${SW2}/>`+pt("ear",124,70,`<circle cx="126" cy="70" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M22 130 L44 130 L40 138 L26 138 Z" fill="#C8A040" ${SW2}/><path d="M33 130 V118" stroke="${FI}" stroke-width="2"/>`)+fG(g,2,`<circle cx="112" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Lumbridge Oarsite"]="Regatta Beaver";SM("Lumbridge Oarsite","Stroke Rate","STR","a",65,100,"spd+1","In, pull, out, return. Faster every time.");


/* Mallowbyte: crossword setters meet beside it to keep spelling arguments down. A tortoise whose shell is a crossword grid, half filled in. */
addForm("Mallowbyte",{n:"#7A8A5A",a:"#F4F0E4",rn:"#E8C8A0",rb:"#3A3A6A",ra:"#E8412C"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",158,124,`<path d="M154 120 L168 124 L154 128 Z" fill="${P.n}" ${SW2}/>`)+
 [[146,.5],[100,0]].map(([x,d])=>pt("legB",x,124,`<path d="M${x-6} 122 L${x-8} 144 H${x+6} L${x+6} 122 Z" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M72 126 Q72 72 114 70 Q156 72 158 126 Z" fill="${P.ac}" ${SW}/><clipPath id="xwC"><path d="M72 126 Q72 72 114 70 Q156 72 158 126 Z"/></clipPath><g clip-path="url(#xwC)">${Array.from({length:8},(_,c)=>Array.from({length:6},(_,r)=>{const b=((c*7+r*3)%5===0);return`<rect x="${72+c*11}" y="${70+r*10}" width="11" height="10" fill="${b?FI:"none"}" stroke="${FI}" stroke-width="1"/>`}).join("")).join("")}<text x="85" y="98" font-size="8" font-weight="bold" fill="${FI}" font-family="monospace">S P E L</text><text x="96" y="108" font-size="8" font-weight="bold" fill="${FI}" font-family="monospace">O</text></g><path d="M72 126 Q72 72 114 70 Q156 72 158 126" fill="none" ${SW}/><path d="M70 126 H160" stroke="${FI}" stroke-width="4"/>`+
 [[134,.5],[88,0]].map(([x,d])=>pt("legF",x,124,`<path d="M${x-6} 122 L${x-8} 145 H${x+6} L${x+6} 122 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",72,116,fOL("M76 118 Q62 116 54 108",P.n,11)+`<path d="M30 104 Q32 90 48 90 Q62 92 62 104 Q58 112 46 112 Q32 112 30 104 Z" fill="${P.n}" ${SW}/>${E2(46,100,4.2)}`+HMOUTH(32,106,40,P,3)+
  `<path d="M54 86 L74 70" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M54 86 L74 70" stroke="#E8C040" stroke-width="2.4" stroke-linecap="round"/><path d="M74 70 l4 -3" stroke="#E8A0B0" stroke-width="3.4" stroke-linecap="round"/>`)+
 fG(g,1,`<text x="160" y="50" font-size="16" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">7↓</text>`)+fG(g,2,`<circle cx="114" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Mallowbyte"]="Crossword Tortoise";SM("Mallowbyte","Seven Down","RES","s",0,100,"tacc-1,ward+1","Seven letters, begins with S, and nobody can agree how to spell it.");

/* Marionettium: puppet makers carve its number inside each puppet's head for luck. A marionette fox hanging from its control bar. */
addForm("Marionettium",{n:"#C86A3A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#6AA85A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="4" fill="#000" opacity=".1"/>`+
 pt("sway",104,10,`<path d="M64 10 H144 M104 2 V18" stroke="#6A4A2A" stroke-width="6" stroke-linecap="round"/>`+
 `<path d="M70 10 L72 70 M104 10 L100 56 M140 10 L140 92 M80 10 L80 120 M128 10 L128 122" stroke="${FI}" stroke-width=".8" opacity=".7"/>`)+
 pt("tail",142,92,`<path d="M138 90 Q164 86 168 108 Q162 116 150 108 Q146 100 140 98 Z" fill="${P.n}" ${SW}/><path d="M160 104 Q166 106 166 110" stroke="${P.ac}" stroke-width="5" fill="none"/>`)+
 pt("legB",126,104,`<rect x="122" y="104" width="8" height="16" rx="3" fill="${P.nd}" ${SW2}/><circle cx="126" cy="122" r="3.4" fill="#C8A060" ${SW2}/><rect x="122" y="124" width="8" height="12" rx="3" fill="${P.nd}" ${SW2}/>`,.5)+
 `<rect x="82" y="80" width="60" height="28" rx="10" fill="${P.n}" ${SW}/><path d="M86 100 Q112 108 138 100" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".8"/>${[88,136].map(x=>`<circle cx="${x}" cy="88" r="3" fill="#C8A060" ${SW2}/>`).join("")}`+
 pt("legF",84,104,`<rect x="78" y="104" width="8" height="16" rx="3" fill="${P.n}" ${SW2}/><circle cx="82" cy="122" r="3.4" fill="#C8A060" ${SW2}/><rect x="78" y="124" width="8" height="12" rx="3" fill="${P.n}" ${SW2}/>`)+
 pt("head",80,70,`<path d="M50 70 Q54 56 72 54 Q90 56 92 70 Q88 84 70 84 Z" fill="${P.n}" ${SW}/><path d="M50 70 L36 74 L50 80 Z" fill="${P.n}" ${SW2}/><circle cx="37" cy="74" r="2.4" fill="${FI}"/><path d="M50 78 Q60 84 70 84" stroke="${P.ac}" stroke-width="5" fill="none"/><circle cx="66" cy="66" r="4.4" fill="#fff" ${SW2}/><circle cx="65" cy="66" r="2" fill="${FI}"/><path d="M60 60 l10 -2" stroke="${FI}" stroke-width="1.6"/>`+
  pt("jaw",48,80,`<path d="M40 78 L56 80 L54 86 L44 82 Z" fill="${P.nd}" ${SW2}/><path d="M56 80 V86" stroke="${FI}" stroke-width="1.4"/>`)+pt("ear",80,56,`<path d="M74 58 L80 40 L88 58 Z" fill="${P.n}" ${SW2}/>`)+`<text x="70" y="76" font-size="5" fill="${P.ndd}">No.69</text>`)+
 fG(g,1,`<path d="M20 130 h40" stroke="#8A2A3A" stroke-width="6"/><path d="M20 130 q20 -20 40 0" fill="#8A2A3A" opacity=".5"/>`)+fG(g,2,`<circle cx="112" cy="94" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Marionettium"]="Marionette Fox";SM("Marionettium","Pull The Strings","RES","s",0,100,"tatk-1,tspd-1","Somebody up there is making all the decisions.");
