/* ---- Tinker's Scrapyard, 7 ---- */
/* Critic's Corner Mix: stacked in the wrong corner and mistaken for modern art. A hanging mobile of fish, balanced arm on arm, slowly turning. */
addForm("Critic's Corner Mix",{n:"#E8604A",a:"#2A2A30",rn:"#3A3A4A",rb:"#3A6AC8",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/><path d="M104 0 V24" stroke="${FI}" stroke-width="1.6"/>`+
 pt("sway",104,24,`<path d="M54 24 H150" stroke="${FI}" stroke-width="3"/><path d="M54 24 V50 M150 24 V60 M120 24 V40" stroke="${FI}" stroke-width="1.4"/><path d="M120 40 H170 M120 40 V70 M170 40 V82" stroke="${FI}" stroke-width="1.4"/><path d="M136 70 L120 70" stroke="${FI}" stroke-width="2"/>`+
  [[54,58,"#F2C94C",1],[150,68,"#3A6AC8",1],[120,78,P.n,1.2],[170,90,"#5AB04A",.8]].map(([x,y,c,s])=>`<g transform="translate(${x} ${y}) scale(${s})"><path d="M-16 0 Q-6 -10 10 -2 L18 -8 L16 0 L18 8 L10 2 Q-6 10 -16 0 Z" fill="${c}" ${SW}/><circle cx="-8" cy="-1" r="2" fill="${FI}"/></g>`).join("")+
  pt("head",104,96,`<g transform="translate(104 110) scale(1.6)"><path d="M-16 0 Q-6 -10 10 -2 L18 -8 L16 0 L18 8 L10 2 Q-6 10 -16 0 Z" fill="${P.n}" ${SW}/></g>${E2(88,108,3.6)}`+HMOUTH(78,112,84,P,2))+`<path d="M104 24 V96" stroke="${FI}" stroke-width="1.4"/>`)+
 fG(g,1,`<rect x="20" y="120" width="34" height="20" fill="#F4F0E4" ${SW2}/><text x="22" y="132" font-size="6" fill="${FI}">'Untitled'</text>`)+fG(g,2,`<circle cx="54" cy="58" r="2.4" fill="${P.ll}"/>`)+fG(g,3,star(30,30,6)));
FORM_TITLE["Critic's Corner Mix"]="Modern-Art Fish Mobile";SM("Critic's Corner Mix","Interpretation","RES","s",0,100,"tacc-1,dodge","What does it mean? Depends who's looking.");

/* Critic's Encore: critics wrote longer reviews of it than of the play. A vulture in a critic's scarf, notebook out, pen poised. */
addForm("Critic's Encore",{n:"#3A3030",a:"#E8B0A0",rn:"#E8D8C8",rb:"#8A2A3A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M60 124 H160" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(44,104)+
 pt("tail",126,110,`<path d="M120 106 L144 126 L132 130 L116 114 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 116 Q76 82 104 76 Q132 82 130 116 Q122 126 104 126 Q88 126 80 116 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",86,98,`<path d="M88 88 Q66 96 66 120 Q80 116 92 104 Z" fill="${P.nd}" ${SW}/><g transform="rotate(-10 70 102)"><rect x="60" y="92" width="18" height="24" fill="#F4F0E4" ${SW2}/><path d="M63 98 h12 M63 102 h12 M63 106 h10 M63 110 h12" stroke="${FI}" stroke-width=".8"/></g>`)+
 pt("legF",104,124,`<path d="M98 124 l-2 4 M104 124 v4 M110 124 l2 4" stroke="${FI}" stroke-width="2.4"/>`)+
 pt("head",100,64,`<path d="M104 80 Q96 66 96 56" stroke="${P.ac}" stroke-width="10" stroke-linecap="round"/><circle cx="94" cy="50" r="11" fill="${P.ac}" ${SW}/>${E2(92,48,3,"#1A1A1A")}<path d="M86 44 l10 2" stroke="${FI}" stroke-width="2"/>`+
  `<path d="M84 52 Q72 54 70 62 L84 58 Z" fill="${FMOUTH}"/>`+pt("beak",78,60,`<path d="M84 58 Q76 64 70 62 Q76 60 84 56 Z" fill="#C8B080" ${SW2}/>`)+`<path d="M84 48 Q70 48 68 60 Q74 56 84 54 Z" fill="#C8B080" ${SW2}/>`+
  `<path d="M90 74 Q104 82 118 74 L120 80 Q104 90 88 80 Z" fill="#8A2A3A" ${SW2}/><path d="M112 82 L118 104" stroke="#8A2A3A" stroke-width="6"/><path d="M96 70 Q104 64 112 72" stroke="#E8E0D0" stroke-width="5" fill="none"/>`)+
 fG(g,1,`${[0,1,2,3,4].map(i=>`<path d="M${150+i*7} 30 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="${i<2?"#F2C94C":"#C8C8D0"}" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Critic's Encore"]="Theatre-Critic Vulture";SM("Critic's Encore","Scathing Review","RES","a",70,100,"tatk-1,tdef-1@30","Two stars. Would not see again.");

/* Crumbite: the delivery van joined a parade by accident and finished to applause. A bear in a bandsman's jacket, beating the big bass drum. */
addForm("Crumbite",{n:"#7A5A3A",a:"#C8302A",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(56)+
 pt("legB",118,130,fOL("M116 124 L120 142 H132",P.nd,12),.5)+
 `<path d="M78 128 Q74 90 104 84 Q134 90 130 128 Q124 142 104 142 Q84 142 78 128 Z" fill="${P.ac}" ${SW}/>${[96,104,112,120].map(y=>`<path d="M90 ${y} h28" stroke="#F2C94C" stroke-width="2.4"/>`).join("")}`+
 `<circle cx="104" cy="118" r="22" fill="#F4F0E4" ${SW}/><circle cx="104" cy="118" r="22" fill="none" stroke="#3A5AA8" stroke-width="5"/><path d="M86 106 L122 130 M86 130 L122 106" stroke="#F2C94C" stroke-width="2"/>`+
 pt("legF",90,130,fOL("M92 124 L88 142 H76",P.nd,12))+
 pt("armF",84,100,fOL("M84 100 Q70 108 72 120",P.n,9)+`<path d="M72 120 L82 104" stroke="#6A4A2A" stroke-width="3"/><circle cx="84" cy="102" r="5" fill="#F4F0E4" ${SW2}/>`)+pt("armB",124,100,fOL("M124 100 Q138 108 136 120",P.n,9),.4)+
 pt("head",104,68,`<circle cx="104" cy="66" r="18" fill="${P.n}" ${SW}/><ellipse cx="104" cy="74" rx="9" ry="7" fill="#C8A080"/><ellipse cx="104" cy="70" rx="3.4" ry="2.6" fill="${FI}"/>${E2(96,62,3.4)}${E2(112,62,3.4)}`+HMOUTH(100,76,108,P,2)+
  pt("ear",88,52,`<circle cx="88" cy="52" r="6" fill="${P.n}" ${SW2}/>`)+pt("ear",120,52,`<circle cx="120" cy="52" r="6" fill="${P.n}" ${SW2}/>`,.3)+`<path d="M90 50 L92 30 H116 L118 50 Z" fill="${P.ac}" ${SW2}/><path d="M92 34 h24" stroke="#F2C94C" stroke-width="3"/><path d="M104 30 Q100 20 106 14" stroke="#F4F0F4" stroke-width="5" stroke-linecap="round" fill="none"/>`)+
 fG(g,1,`${[[30,30,"#E8412C"],[40,50,"#4A8AE8"],[160,30,"#5AB04A"],[170,50,"#F2C94C"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="4" height="7" fill="${c}" transform="rotate(30 ${x} ${y})"/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,90,6)));
FORM_TITLE["Crumbite"]="Bass-Drum Bear";SM("Crumbite","Boom Boom","STR","a",70,100,"tspd-1@30","Every beat lands right in your chest.");

/* Cue Card Special: opera prompters write its number on their cue cards. A mudpuppy peeping out of the prompter's box at the front of the stage. */
addForm("Cue Card Special",{n:"#7A6A5A",a:"#E8604A",rn:"#3A3A4A",rb:"#8A2A3A",ra:"#F2C94C"},"perch",(P,g)=>`<rect x="14" y="128" width="180" height="18" fill="#6A4A2A" ${SW}/><path d="M60 128 Q60 96 104 94 Q148 96 148 128 Z" fill="#3A2A2A" ${SW}/><path d="M64 128 Q64 102 104 100 Q144 102 144 128" fill="#1A1A1A"/>`+
 pt("head",104,112,`<path d="M74 128 Q74 104 104 102 Q134 104 134 128 Z" fill="${P.n}" ${SW}/>${E2(94,114,3.6,"#C8A040")}${E2(114,114,3.6,"#C8A040")}`+HMOUTH(98,122,110,P,2)+
  pt("ear",76,114,`${[0,1,2].map(i=>`<path d="M76 ${110+i*5} Q${64-i*2} ${104+i*6} ${58} ${108+i*7}" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join("")}`)+pt("claw",132,114,`${[0,1,2].map(i=>`<path d="M132 ${110+i*5} Q${144+i*2} ${104+i*6} ${150} ${108+i*7}" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/>`).join("")}`))+
 pt("armF",80,124,`<path d="M80 126 Q66 120 60 108" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M80 126 Q66 120 60 108" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/><g transform="rotate(-14 52 100)"><rect x="40" y="90" width="26" height="18" fill="#F4F0E4" ${SW2}/><text x="42" y="102" font-size="6" font-weight="bold" fill="${FI}">No.313</text></g>`)+
 fG(g,1,`<path d="M150 40 v-14 l8 3 M164 46 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="148" cy="40" r="3" fill="${P.ac}"/><circle cx="162" cy="46" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="104" cy="126" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Cue Card Special"]="Prompt-Box Mudpuppy";SM("Cue Card Special","Prompt","RES","s",0,100,"acc+1,atk+1","Psst! The next line is... this one.");

/* Damascus Steel: swords of it were said to slice silk scarves falling through the air. A swordfish with a rippled, watered-steel blade. */
addForm("Damascus Steel",{n:"#5A6A7A",a:"#E8E4E0",rn:"#3A3A4A",rb:"#B8402A",ra:"#F2C94C"},"swim",(P,g)=>`<ellipse class="shd" cx="110" cy="148" rx="40" ry="3" fill="#000" opacity=".1"/><path d="M14 40 Q30 50 50 44 Q34 56 18 52 Z" fill="#E8A0C0" opacity=".7" ${SW2}/>`+
 pt("tail",164,84,`<path d="M156 84 L184 52 L178 84 L186 116 Z" fill="${P.n}" ${SW}/>`)+
 pt("wingB",120,66,`<path d="M110 70 Q120 34 140 30 Q136 52 128 70 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M74 84 Q80 62 116 62 Q150 66 160 84 Q150 104 116 106 Q82 106 74 84 Z" fill="${P.n}" ${SW}/><path d="M80 90 Q118 104 156 88" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 pt("wingF",108,98,`<path d="M106 100 L94 122 L116 104 Z" fill="${P.nd}" ${SW}/>`)+
 pt("head",80,82,`<path d="M78 78 L14 82 L78 88 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3,4,5,6].map(i=>`<path d="M${70-i*8} 80 q4 3 0 6" stroke="${P.nd}" stroke-width="1" fill="none"/>`).join("")}${E2(88,78,4,"#1A1A1A")}`+pt("jaw",78,92,`<path d="M78 90 L62 92 L78 96 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M24 56 l10 6" stroke="${FI}" stroke-width="1.2"/>`)+fG(g,2,`<circle cx="118" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Damascus Steel"]="Watered-Blade Swordfish";SM("Damascus Steel","Silk Cutter","SCR","a",90,100,"crit","Drop a scarf on the blade. Watch it fall in two.");

/* Dappleford B-Side: filed under Miscellaneous between polka and a box of lost records. A gramophone-horn flower sprite, its petal trumpet playing a B-side. */
addForm("Dappleford B-Side",{n:"#8A5AA8",a:"#2A2A30",rn:"#3A3A4A",rb:"#5A9A3A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50)+
 pt("legB",112,134,`<path d="M108 128 Q116 136 124 140" stroke="#5A9A3A" stroke-width="5" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M104 140 Q100 110 104 84" stroke="#5A9A3A" stroke-width="7" fill="none"/><path d="M104 118 Q84 108 74 116 Q86 126 104 122 Z M104 104 Q124 94 134 102 Q122 112 104 108 Z" fill="#5A9A3A" ${SW2}/>`+
 pt("legF",96,134,`<path d="M100 128 Q92 136 84 140" stroke="#5A9A3A" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("head",104,62,`<path d="M100 86 L72 30 Q104 14 136 30 L108 86 Z" fill="${P.n}" ${SW}/><path d="M84 32 L102 80 M104 22 V82 M124 32 L106 80" stroke="${P.nd}" stroke-width="1.6"/><ellipse cx="104" cy="28" rx="32" ry="10" fill="${P.nd}" ${SW}/><ellipse cx="104" cy="28" rx="20" ry="6" fill="${FI}"/>${E2(96,50,3.6)}${E2(112,50,3.6)}`+HMOUTH(100,60,108,P,2))+
 `<circle cx="104" cy="88" r="5" fill="#C8A040" ${SW2}/>`+
 pt("armF",100,112,`<g transform="rotate(-20 60 120)"><circle cx="60" cy="120" r="16" fill="${P.ac}" ${SW}/><circle cx="60" cy="120" r="10" fill="none" stroke="#5A5A64" stroke-width="1"/><circle cx="60" cy="120" r="4" fill="#C8302A"/><text x="57" y="122" font-size="4" fill="#fff">B</text></g>`)+
 fG(g,1,`<path d="M150 50 v-14 l8 3 M164 56 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="148" cy="50" r="3" fill="${P.ac}"/><circle cx="162" cy="56" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="104" cy="88" r="2" fill="${P.ll}"/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Dappleford B-Side"]="Gramophone-Flower Sprite";SM("Dappleford B-Side","Flip Side","RES","a",60,100,"tatk-1@40","Turn it over. The other side is even stranger.");

/* Dead Air Special: the radio marathon announced three mystery deliveries. An elephant shrew with a microphone for a nose, on air. */
addForm("Dead Air Special",{n:"#B8905A",a:"#3A3A40",rn:"#E8D8C8",rb:"#C8302A",ra:"#5FE0F0"},"stand",(P,g)=>`<rect x="150" y="40" width="34" height="22" rx="3" fill="#3A3A44" ${SW}/><text x="154" y="56" font-size="10" font-weight="bold" fill="#C8302A">ON AIR</text>`+fShadow(60)+
 pt("tail",136,118,`<path d="M132 120 Q160 124 172 116" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 pt("legB",126,118,fOL("M124 116 L130 132 L126 142 H134",P.nd,6),.5)+
 `<path d="M84 116 Q84 92 110 90 Q134 92 136 114 Q132 128 110 128 Q88 128 84 116 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",96,120,fOL("M96 118 L90 132 L94 142 H86",P.n,6))+
 pt("head",90,104,`<path d="M64 106 Q66 88 84 86 Q100 88 102 104 Q98 116 82 116 Z" fill="${P.n}" ${SW}/><circle cx="84" cy="98" r="7" fill="#F4F0E4" ${SW2}/>${E2(84,98,4,"#1A1A1A")}`+
  pt("tongue",64,104,`<path d="M66 104 Q52 100 40 102" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M66 104 Q52 100 40 102" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="34" cy="102" r="8" fill="${P.ac}" ${SW}/>${[0,1,2].map(i=>`<path d="M${28+i*4} 96 v12" stroke="#8A8A94" stroke-width="1"/>`).join("")}`)+HMOUTH(66,110,74,P,1.6)+
  pt("ear",94,88,`<ellipse cx="96" cy="84" rx="7" ry="9" fill="${P.n}" ${SW2}/><ellipse cx="96" cy="84" rx="3.4" ry="5" fill="#E8A0A0"/>`))+
 fG(g,1,`<path d="M20 70 q6 6 0 12 M12 66 q12 10 0 20" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".6"/>`)+fG(g,2,`<circle cx="110" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Dead Air Special"]="On-Air Elephant Shrew";SM("Dead Air Special","Dead Air","RES","s",0,100,"tacc-1,tdraw-1","Silence on the radio is the loudest thing there is.");

/* Dead End Metal: a batch hidden at the maze's dead end nearest the exit. A topiary dragon clipped out of that hedge maze. */
addForm("Dead End Metal",{n:"#4A8A3A",a:"#8A6A4A",rn:"#3A3A4A",rb:"#E8C060",ra:"#E8412C"},"stand",(P,g)=>`<rect x="14" y="118" width="180" height="28" fill="#3A7A2A" ${SW}/>${Array.from({length:12},(_,i)=>`<circle cx="${20+i*16}" cy="120" r="8" fill="#4A8A3A" ${SW2}/>`).join("")}`+fShadow(70)+
 pt("tail",160,98,`${[[160,96,9],[174,88,8],[184,76,7]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.n}" ${SW}/>`).join("")}`)+
 pt("wingB",128,74,`<path d="M124 78 L134 40 L150 58 L162 44 L164 76 Q148 86 132 88 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `${[[96,96,18],[118,92,20],[142,96,16]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.n}" ${SW}/>`).join("")}${Array.from({length:12},(_,i)=>`<path d="M${86+i*5} ${84+(i%3)*8} l2 2" stroke="${P.nd}" stroke-width="1.6"/>`).join("")}`+
 [[140,"legF",0],[100,"legF",.6]].map(([x,c,d])=>pt(c,x,110,`<rect x="${x-6}" y="108" width="12" height="14" rx="4" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",80,80,`<path d="M84 90 L76 70" stroke="${P.n}" stroke-width="16" stroke-linecap="round"/><circle cx="66" cy="62" r="16" fill="${P.n}" ${SW}/><circle cx="48" cy="66" r="9" fill="${P.n}" ${SW}/>${E2(66,56,3.6,"#E8C060")}<path d="M60 44 L62 34 L68 44 M72 46 L78 36 L80 48" fill="${P.n}" ${SW2}/>`+pt("jaw",50,74,`<path d="M40 70 Q48 80 58 74 Z" fill="${FMOUTH}" ${SW2}/>`))+
 fG(g,1,`<path d="M150 40 l20 0 l-4 6 h-12 Z" fill="#B8B8C0" ${SW2}/><path d="M162 40 l10 -12" stroke="#B8B8C0" stroke-width="3"/>`)+fG(g,2,`<circle cx="118" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Dead End Metal"]="Topiary Dragon";SM("Dead End Metal","Dead End","RES","s",0,100,"tspd-1,tacc-1","Left, right, left, and... a wall. Again.");

/* Deepingite: toss a pebble in the fountain before opening its crate. A little fountain imp, water spouting from its mouth. */
addForm("Deepingite",{n:"#7AA8B8",a:"#E8E0D0",rn:"#3A3A4A",rb:"#C8A060",ra:"#F2C94C"},"perch",(P,g)=>`<ellipse cx="104" cy="134" rx="66" ry="12" fill="#B8B8C0" ${SW}/><ellipse cx="104" cy="130" rx="58" ry="8" fill="#9AC8E8" ${SW2}/>${[[80,130],[132,132]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="4" ry="2" fill="#C8A040"/>`).join("")}<rect x="92" y="106" width="24" height="24" fill="#C8C8D0" ${SW}/>`+
 pt("tail",116,96,`<path d="M114 96 Q132 92 136 80 Q138 70 130 70" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M114 96 Q132 92 136 80 Q138 70 130 70" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 `<path d="M88 108 Q86 84 104 80 Q122 84 120 108 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",90,92,fOL("M90 92 Q78 94 76 104",P.n,5))+pt("armB",118,92,fOL("M118 92 Q130 94 130 104",P.n,5),.4)+
 pt("head",104,66,`<circle cx="104" cy="64" r="16" fill="${P.n}" ${SW}/><path d="M92 52 L86 40 L96 48 M116 52 L122 40 L112 48" fill="${P.n}" ${SW2}/>${E2(98,60,3.4)}${E2(110,60,3.4)}<ellipse cx="104" cy="72" rx="4" ry="3" fill="${FMOUTH}" ${SW2}/>`+
  pt("tongue",104,72,`<path d="M104 72 Q90 60 76 44 Q70 36 64 40 Q60 60 66 90 Q70 110 74 128" stroke="#9AD0F0" stroke-width="4" fill="none" stroke-linecap="round" opacity=".85"/>`))+
 fG(g,1,`<ellipse cx="164" cy="138" rx="5" ry="3" fill="#C8C8D0" ${SW2}/><path d="M160 120 q4 -10 8 0" stroke="${P.l}" stroke-width="1.6" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Deepingite"]="Fountain Imp";SM("Deepingite","Make A Wish","DRP","a",60,100,"heal:15","Toss a pebble, make a wish, get splashed.");

/* Didn't-Do-It Metal: the mixer ran all weekend; on Monday there was this and an unsigned note. A labrador with a very guilty face, a mess beside it. */
addForm("Didn't-Do-It Metal",{n:"#E8C890",a:"#3A3A40",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"stand",(P,g)=>`<path d="M20 140 Q30 126 46 132 Q56 120 64 140 Z" fill="#9AA0B0" ${SW2}/>${[[30,124],[50,118],[40,110]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#9AA0B0"/>`).join("")}`+fShadow(80)+
 pt("tail",164,108,`<path d="M160 108 Q172 118 174 132" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M160 108 Q172 118 174 132" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",150,118,24,10,P.n,P.n,.5)+fLeg("legB",120,120,22,10,P.n,P.n,1.3)+
 `<path d="M96 112 Q96 90 128 88 Q160 90 164 110 Q160 128 130 128 Q100 128 96 112 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",142,120,22,10,P.n,P.n,0)+fLeg("legF",108,120,22,10,P.n,P.n,.8)+
 pt("head",96,110,`<path d="M98 112 Q86 116 80 124" stroke="${P.n}" stroke-width="16" stroke-linecap="round"/><path d="M58 128 Q56 110 74 106 Q92 106 94 122 Q92 136 76 138 Q60 138 58 128 Z" fill="${P.n}" ${SW}/><ellipse cx="58" cy="128" rx="4" ry="3.4" fill="${FI}"/>${E2(72,118,3.8,"#3A2410",[.6,-.2])}<path d="M66 112 q6 2 12 -2" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(60,132,70,P,1.6)+
  pt("ear",84,110,`<path d="M82 108 Q96 108 94 126 Q88 130 84 124 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<g transform="rotate(8 170 40)"><rect x="156" y="28" width="28" height="20" fill="#F4F0E4" ${SW2}/><text x="158" y="40" font-size="6" fill="${FI}">wasn't me</text></g>`)+fG(g,2,`<circle cx="130" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,60,6)));
FORM_TITLE["Didn't-Do-It Metal"]="Guilty Labrador";SM("Didn't-Do-It Metal","Wasn't Me","RES","s",0,100,"dodge,tatk-1","Who, me? No. Never. Absolutely not.");
