/* =============== ASSAY MOVES ===============
   Every move belongs to one of ten test classes. The class is the science: it decides which real property of the target the move
   tests, so a Heat move does most to things that melt easily and least to things that don't, whoever is using it.
   Fields: name, class, kind (a attack / s status / g guard), power, accuracy, effects, the real thing it is based on, where it comes from. */
const ACLS={SCR:{n:"Scratch",c:"#C9A24A",d:"Tests hardness. Hard edges cut soft metal."},STR:{n:"Strain",c:"#8C6BB8",d:"Tests toughness. Very soft metal gives, very hard metal cracks."},
 DRP:{n:"Drop",c:"#6A7A8A",d:"Tests mass. Heavy things hit light things hard."},HEA:{n:"Heat",c:"#E8562C",d:"Tests melting point. Things that melt easily suffer most."},
 CUR:{n:"Current",c:"#E0B820",d:"Tests conductivity. Poor conductors heat up when current is forced through them."},PUL:{n:"Pull",c:"#C8315F",d:"Tests magnetism. Only magnetic things can be gripped."},
 QUE:{n:"Quench",c:"#2E9BE0",d:"Tests reactivity. Reactive metal meets water badly."},COR:{n:"Corrode",c:"#6A9A3A",d:"Tests nobility. Noble metals shrug off attack; base metals are eaten."},
 RAD:{n:"Radiate",c:"#7AD040",d:"Tests shielding. Dense metal stops radiation and takes the whole dose; light metal lets most of it pass straight through."},RES:{n:"Resonate",c:"#4AB8C8",d:"Tests stiffness. Stiff, light metal rings itself apart."}};
const MOVES=[];const MV={};
function M(n,c,k,p,acc,fx,sci,src){const m={id:n.toLowerCase().replace(/[^a-z0-9]+/g,"_"),n,c,k,p,acc:acc||100,fx:fx||"",sci,src};if(MV[m.id])return;MOVES.push(m);MV[m.id]=m}
/* ---- the ten classes, four tiers each: everyone's basics ---- */
[["SCR",["Graze","Gouge","Furrow","Stylus Rake"],"Hardness testing: a harder point leaves a groove in a softer surface."],
 ["STR",["Flex","Wrench","Torsion","Yield Point"],"Bend a metal far enough and it either gives for good or snaps."],
 ["DRP",["Tumble","Slam","Drop Forge","Pile Driver"],"Momentum is mass times speed; a heavy blow carries more of it."],
 ["HEA",["Warm Through","Blowtorch","Crucible Blast","Arc Furnace"],"Every metal has a melting point. Get past it and the shape goes."],
 ["CUR",["Static Nip","Live Wire","Short Circuit","Lightning Path"],"Resistance turns current into heat. Good conductors pass it straight through."],
 ["PUL",["Tug","Field Line","Lode Pull","Flux Snap"],"Magnets grip iron, nickel and cobalt, and very little else."],
 ["QUE",["Splash Test","Dunk","Brine Bath","Steam Burst"],"Reactive metals tear water apart, giving off heat and hydrogen."],
 ["COR",["Etch","Pit","Acid Bath","Aqua Regia"],"Base metals give up electrons easily and dissolve; noble ones hold on."],
 ["RAD",["Glow Count","Decay Chain","Ionise","Critical Mass"],"Dense matter stops radiation and soaks up the damage; light matter lets most of it pass through."],
 ["RES",["Tap","Ring Out","Standing Wave","Shatter Note"],"Stiff, light objects ring at high, clean pitches, and can shake themselves apart."]
].forEach(([c,ns,sci])=>ns.forEach((n,i)=>M(n,c,"a",[40,60,80,100][i],[100,100,95,85][i],i===3&&c==="RAD"?"recoil:20":i===3&&c==="HEA"?"molten@30":i===3&&c==="QUE"?"tward-1@30":"",sci,"b:"+c+":"+i)));
/* ---- type moves ---- */
const TM=(t,a)=>a.forEach(x=>M(...x.slice(0,7),"t:"+t));
TM("Radioactive",[["Half-Life","RAD","s",0,90,"irr","Radioactive decay: the dose halves again and again but never quite stops."],["Cherenkov Flash","RAD","a",90,90,"tacc-1@30","The glow in a reactor pool, from particles outrunning light in water."],["Fission Spark","RAD","a",75,100,"recoil:15","Splitting a nucleus releases energy and a little of it comes back at you."],["Daughter Product","RAD","a",50,100,"tdraw-1","Decay leaves new elements behind, each with its own habits."],["Decay Heat","HEA","a",65,100,"","Radioactive fuel stays hot long after the reaction stops."]]);
TM("Liquid",[["Wet Through","COR","a",60,100,"brittle@50","Liquid metal soaks into the grain boundaries of a solid and leaves it brittle."],["Flow Around","STR","g",0,100,"dodge","A liquid can't be cut. It parts and closes again."],["Bead Up","STR","g",0,100,"def+1,ward+1","Surface tension pulls liquid metal into a tight bead."],["Amalgamate","COR","a",80,100,"amalg","Liquid metal dissolves soft precious metals into a paste."],["Pour","DRP","a",50,100,"prio","Liquid goes where it's sent, quickly."]]);
TM("Low-melt",[["Solder Seal","HEA","g",0,100,"heal:30","Low-melting metal flows into cracks and seals them."],["Hot Drip","HEA","a",55,100,"molten@20","A bead of molten metal falls and sticks where it lands."],["Fuse Blow","CUR","g",0,100,"ground","A fuse melts to break the circuit before anything else is hurt."],["Creep","STR","s",0,100,"tspd-2","Soft metal slowly sags under load, a little more every day."],["Casting Rush","DRP","a",65,100,"","Easy-melting metal pours and sets in moments."]]);
TM("Magnetic",[["Domain Snap","PUL","a",75,100,"","Magnetic domains flip into line all at once."],["Curie Point","HEA","s",0,90,"curie","Heat a magnet past its Curie point and its magnetism simply goes."],["Hysteresis Loop","PUL","a",50,100,"drain:50","Every cycle of magnetising loses a little energy as heat."],["Lodestone Grip","PUL","s",0,100,"mag","A strong magnet holds what it catches."],["Eddy Brake","PUL","a",70,100,"eddy","Moving magnets set up currents in conductors that drag against the motion."]]);
TM("Reactive",[["Flash Fire","HEA","a",85,95,"selfoxid@30","Reactive metal burns fiercely once it gets going."],["Fizz Out","QUE","a",70,100,"tward-1@50","A reactive metal fizzing in water, giving off hydrogen."],["Hydrogen Kick","QUE","a",95,90,"recoil:20","Hydrogen from the reaction catches light with a bang."],["Spark Shower","HEA","a",60,100,"oxid@40","Scrape a reactive metal and it throws burning sparks."],["Pyrophoric Flare","HEA","a",105,80,"","Some metal powders catch fire in air on their own."]]);
TM("Precious",[["Tarnish-Proof","COR","g",0,100,"film3","Noble metals stay bright because almost nothing reacts with them."],["Gleam","RES","s",0,100,"tacc-1","A polished surface catches the eye at the wrong moment."],["Noble Calm","COR","g",0,100,"ward+1,heal:10","A noble metal is in no hurry to react to anything."],["Gilt Edge","SCR","a",60,100,"crit","A thin precious layer over a hard edge."],["Bullion Weight","DRP","a",80,95,"","Precious metals are some of the densest there are."]]);
TM("Lightweight",[["Updraft","STR","g",0,100,"spd+2","Light structures get moving with very little push."],["Feather Strike","STR","a",55,100,"prio","Little mass means little to slow it down."],["Dart In","SCR","a",45,100,"prio","Quick in, quick out."],["Skim","DRP","a",25,100,"multi:2-4","A light thing bounces and comes back again."],["Airframe Flex","STR","g",0,100,"dodge","Aircraft frames flex instead of breaking."]]);
TM("Heavy",[["Sheer Mass","DRP","a",100,90,"selfspd-1","Very dense metal is slow to start and hard to stop."],["Gravity Well","DRP","s",0,100,"tspd-2","Weight that drags everything near it down."],["Plumb Line","DRP","a",70,100,"nomiss","A weight on a string always finds true vertical."],["Anvil Fall","DRP","a",115,75,"","Nothing subtle about it."],["Ballast Shift","DRP","g",0,100,"def+2","Moving weight low makes anything harder to tip."]]);
TM("Tough",[["Case Harden","SCR","g",0,100,"def+2","Hardening only the skin of a part keeps the core from snapping."],["Unbowed","STR","g",0,100,"endure","Some metal bends to its limit and still holds."],["Grind","SCR","a",70,100,"brittle@30","A hard abrasive leaves the surface scored and weak."],["Cold Chisel","SCR","a",85,100,"","A chisel hard enough to cut metal without heating it."],["Wear Plate","SCR","g",0,100,"def+1,ward+1","A hard plate bolted where the wear is worst."]]);
TM("Heat-proof",[["Furnace Lining","HEA","g",0,100,"refrac","The lining of a furnace has to outlast everything inside it."],["Afterglow","HEA","a",75,100,"","Metal that can take heat can give it back."],["Thermal Shock","HEA","a",70,100,"brittle@50","Sudden heat makes the outside expand faster than the inside, and it cracks."],["Creep Resist","STR","g",0,100,"def+1,spd+1","Turbine blades are made to keep their shape at red heat for years."],["Hot Blade","SCR","a",80,100,"","An edge that stays hard while it glows."]]);
TM("Conductive",[["Skin Effect","CUR","a",65,100,"","Fast-changing current crowds into the outside of a conductor."],["Ground Out","CUR","g",0,100,"ground","Give current an easy path and it takes it, harmlessly."],["Bus Bar","CUR","a",85,100,"","A thick bar of conductor that can carry a whole building's power."],["Heat Sink","HEA","g",0,100,"refrac","Good conductors carry heat away as fast as they carry current."],["Arc Over","CUR","a",95,85,"","Enough voltage jumps the gap through thin air."]]);
TM("Structural",[["Load Bearing","STR","g",0,100,"def+1,ward+1","Built to carry weight without complaint."],["Rivet Line","STR","a",25,100,"multi:2-5","One rivet after another."],["Girder Swing","DRP","a",80,95,"","A beam swung on a crane chain."],["Weld Bead","HEA","g",0,100,"heal:25","A weld joins two pieces into one."],["Truss Up","STR","g",0,100,"def+2","Triangles don't fold."]]);
TM("Toxic",[["Fume Cloud","COR","s",0,90,"corrode,tacc-1","Toxic metals give off fumes when worked hot."],["Leach","COR","a",60,100,"drain:50","Toxic metals seep out into whatever touches them."],["Taint","COR","s",0,100,"corrode","Contamination that keeps working long after contact."],["Sour Water","QUE","a",55,100,"corrode@40","Water that has sat on toxic metal isn't water any more."],["Heavy Dose","COR","a",85,100,"","Some metals are poisonous in very small amounts."]]);
/* ---- element moves: learned when an alloy has enough of that element in it ---- */
const EM=(e,a)=>a.forEach(x=>M(...x.slice(0,7),"e:"+e));
EM("Fe",[["Bloom Hammer","SCR","a",70,100,"","The first wrought metal was hammered out of a spongy lump called a bloom."],["Work the Bar","STR","a",65,100,"atk+1@50","A smith works a bar hot, and it gets stronger as it goes."]]);
EM("Cu",[["Patina Shell","COR","g",0,100,"patina","A slow surface crust that protects the metal underneath for centuries."],["Wire Draw","CUR","a",70,100,"","Soft, ductile metal pulled through smaller and smaller dies into wire."]]);
EM("Ni",[["Plate Over","COR","g",0,100,"film3,ward+1","Plating a thin layer over a part to keep the weather off it."],["Invar Hold","STR","g",0,100,"nodrop","Some alloys barely grow or shrink with heat at all."]]);
EM("Al",[["Oxide Skin","COR","g",0,100,"film3","A skin of oxide a few atoms thick seals the metal off from the air."],["Thermite Kick","HEA","a",100,85,"recoil:25","Light metal burning against rust gets hot enough to cut steel."]]);
EM("Sn",[["Crackle Bend","RES","a",55,100,"tdef-1@30","Some metals give a little crackle when bent: crystals grinding past each other."],["Pest Rot","COR","a",70,100,"brittle@30","In bitter cold, some metal slowly crumbles to powder."]]);
EM("Ti",[["Spark Grind","SCR","a",65,100,"","Some metals throw bright sparks on a grinding wheel."],["Bone Bond","STR","g",0,100,"heal:25","Bone grows straight onto some implant metals."]]);
EM("Zn",[["Sacrificial Coat","COR","g",0,100,"film3,heal:10","A coating that corrodes first, so the metal beneath doesn't."],["Galvanic Bite","CUR","a",70,100,"galv","Two different metals touching in water make a battery, and one is eaten."]]);
EM("Cr",[["Passivate","COR","g",0,100,"film3,ward+1","A clear film forms on the surface and stops corrosion dead."],["Mirror Plate","COR","g",0,100,"ward+2","A hard, bright plating that shrugs off chemical attack."]]);
EM("Mg",[["Flare Strip","HEA","a",85,95,"tacc-1@50","A strip of reactive metal burns with a dazzling flare."],["Featherframe","STR","g",0,100,"spd+1,def+1","Some of the lightest structural metal there is."]]);
EM("Co",[["Hot Edge","SCR","a",75,100,"","Some cutting tips stay hard even when they're glowing."],["Spin Magnet","PUL","a",70,100,"","Permanent magnets that keep their pull at high temperatures."]]);
EM("Ag",[["Mirror Back","RES","s",0,100,"tacc-1","Mirrors were backed with a bright metal layer."],["Clean Hands","COR","g",0,100,"cure,heal:10","Some metals kill germs on their surface."]]);
EM("Au",[["Leaf Wrap","STR","g",0,100,"def+1,ward+1","Some metals can be beaten into leaf thinner than a soap bubble."],["Untarnished","COR","g",0,100,"film5","Ancient treasure comes out of the ground as bright as it went in."]]);
EM("Nb",[["Cold Superconduct","CUR","a",90,90,"","Cooled far enough, some metals carry current with no resistance at all."],["Anodise","COR","g",0,100,"film3,ward+1","A grown oxide layer, coloured by its own thickness."]]);
EM("W",[["Filament Glow","HEA","a",80,100,"","Light bulb filaments are made of the metal with the highest melting point."],["Dense Penetrator","DRP","a",90,100,"","Very dense metal punches through armour."]]);
EM("Mo",[["Hot Strength","STR","g",0,100,"def+2","Some metals stay strong at temperatures that soften steel."],["Slip Plane","STR","g",0,100,"dodge,spd+1","A sulfide of this metal is a dry lubricant: layers slide over each other."]]);
EM("Zr",[["Cladding","RAD","g",0,100,"sink","Fuel rods are sealed in tubes of a metal that neutrons pass through easily."],["Hydride Crack","STR","a",70,100,"brittle@30","Absorbed hydrogen makes some metals crack."]]);
EM("Pb",[["Radiation Apron","RAD","g",0,100,"sink","Dense, soft metal sheets stop X-rays."],["Soft Smear","SCR","a",40,100,"tspd-1","Very soft metal smears across whatever it touches."]]);
EM("Pt",[["Catalyst Bed","COR","s",0,100,"draw+2","Some metals speed up reactions without being used up."],["Spark Plug","CUR","a",60,100,"crit","Spark plug tips are made of metals that survive millions of sparks."]]);
EM("Mn",[["Impact Harden","STR","g",0,100,"def+1,atk+1","Some steels get harder every time they're hit."]]);
EM("Si",[["Semiconduct","CUR","a",55,100,"spd+1","Some elements conduct only a little, and that little can be controlled."],["Glass Former","STR","g",0,100,"def+1,ward+1","Some elements make glass as easily as metal."]]);
EM("V",[["Grain Refine","STR","g",0,100,"atk+1,def+1","A pinch of the right element keeps a metal's crystals small and strong."]]);
EM("Pd",[["Hydrogen Sponge","QUE","g",0,100,"heal:30,qguard","Some metals soak up many times their own volume of hydrogen."]]);
EM("Bi",[["Hopper Crystal","SCR","a",25,100,"multi:2-4","Some metals grow crystals in hollow, stepped squares."],["Fusible Plug","HEA","g",0,100,"refrac","A plug that melts at a set temperature and lets the water through."]]);
EM("In",[["Squeal","RES","a",55,100,"tdef-1@50","Some soft metals squeal when they're bent."],["Cold Weld","STR","g",0,100,"heal:20,def+1","Very soft, clean metal sticks to itself on contact."]]);
EM("Sb",[["Expand on Cooling","STR","g",0,100,"def+1,ward+1","Type metal swells as it sets, filling every corner of the mould."],["Stibnite Smudge","COR","a",60,100,"tacc-1","Its ore was once ground up as eye make-up."]]);
EM("Ce",[["Flint Strike","HEA","a",70,100,"oxid@50","Lighter flints throw sparks because the metal burns as it's scraped."]]);
EM("Be",[["Stiff Light","RES","a",80,100,"","Some light metals are so stiff they're used in speaker domes."],["Toxic Dust","COR","a",60,100,"corrode@50","Dust from some metals is dangerous to breathe."]]);
EM("U",[["Depleted Penetrator","DRP","a",95,95,"","Very dense metal from spent fuel is used in armour-piercing rounds."],["Fission Tick","RAD","a",70,100,"irr@30","A slow, steady count on the detector."]]);
EM("Ta",[["Capacitor Dump","CUR","a",85,100,"","Tiny capacitors store charge and dump it all at once."],["Body Kind","STR","g",0,100,"heal:20,cure","The body barely notices some metals at all."]]);
EM("Hg",[["Wet the Grain","COR","a",75,100,"brittle@50","A liquid metal running along grain boundaries makes solid metal fall apart."],["Quick Bead","STR","g",0,100,"dodge","Liquid metal skitters away from a fingertip."]]);
EM("Ga",[["Grain Seep","COR","a",70,100,"brittle@50","A metal that melts in your hand can eat straight through a can."],["Melt in Hand","HEA","s",0,100,"tdef-1","It goes soft at body heat."]]);
EM("Ru",[["Hard Shell Plate","SCR","g",0,100,"def+2","A very hard plating for parts that mustn't wear."]]);
EM("K",[["Skitter Burn","QUE","a",80,100,"","Some metals skate across water on a cushion of burning hydrogen."]]);
EM("Na",[["Water Strike","QUE","a",85,100,"recoil:10","A lump of reactive metal in water is a small explosion."]]);
EM("Li",[["Battery Swell","CUR","a",70,100,"","The lightest metal stores a lot of charge for its weight."],["Floats on Oil","STR","g",0,100,"spd+2","The lightest metal floats on oil."]]);
EM("Rb",[["Air Ignite","HEA","a",75,100,"oxid@50","Some metals catch fire on contact with air."]]);
EM("Cs",[["Ice-Cold Blast","QUE","a",100,80,"","Some metals explode on contact even with ice."]]);
EM("Fr",[["Fleeting","RAD","a",90,100,"recoil:25","Some elements last only minutes before decaying away."]]);
EM("Nd",[["Pinch Field","PUL","a",90,100,"","The strongest permanent magnets can pinch a finger hard."]]);
EM("Cd",[["Neutron Swallow","RAD","g",0,100,"sink","Control rods soak up neutrons to slow a reactor down."]]);
EM("Re",[["Turbine Guard","HEA","g",0,100,"def+1,heal:10","Jet turbine blades rely on a rare metal to survive the heat."]]);
EM("Ir",[["Densest Edge","DRP","a",85,100,"nomiss","Among the densest substances known."]]);
EM("Os",[["Nib Point","SCR","a",80,100,"","Fountain pen nibs were tipped with an extremely hard metal."]]);
EM("Rh",[["Mirror Finish","COR","g",0,100,"ward+2","A plating so bright and hard it's used on mirrors and searchlights."]]);
EM("La",[["Lens Clear","RES","s",0,100,"acc+1,crit","Camera lenses with this element bend light more sharply."],["Hydrogen Store","QUE","g",0,100,"heal:25","Some alloys hold hydrogen like a sponge."]]);
EM("Hf",[["Control Rod","RAD","g",0,100,"sink,ward+1","Naval reactors use a metal that swallows neutrons."]]);
EM("Ca",[["Fizz and Settle","QUE","a",60,100,"tdef-1@30","Some metals react with water gently, fizzing slowly."]]);
EM("Th",[["Mantle Glow","HEA","a",70,100,"irr@20","Old gas lamp mantles glowed brightly because of a radioactive oxide."]]);
EM("Y",[["Laser Line","HEA","a",75,100,"nomiss","Many lasers are built around a crystal containing this element."]]);
EM("Po",[["Static Eliminator","RAD","a",80,100,"irr@40","Tiny radioactive sources were used to clear static from film."]]);
EM("Ra",[["Dial Glow","RAD","a",65,100,"tacc-1@50","Watch dials were once painted to glow in the dark with a radioactive paint."]]);
EM("Pu",[["Pit Core","RAD","a",95,90,"recoil:15","A dense core that releases enormous energy when compressed."]]);
EM("B",[["Neutron Catch","RAD","g",0,100,"sink","Some light elements catch neutrons very efficiently."],["Boride Edge","SCR","a",85,100,"","Borides are some of the hardest materials made."]]);
EM("S",[["Sulfide Tarnish","COR","a",55,100,"tward-1","Silverware darkens from traces of sulfur in the air."]]);
EM("As",[["Dope Layer","CUR","s",0,100,"draw+2","A trace of the right impurity changes how a semiconductor behaves."]]);
EM("Tl",[["Poisoner's Dust","COR","a",80,100,"corrode@50","Once called the poisoner's poison: no taste, no smell."]]);
EM("Np",[["Alpha Shower","RAD","a",70,100,"",  "Alpha particles carry a lot of energy over a very short distance."]]);
EM("Am",[["Ion Chamber","RAD","s",0,100,"tacc-1","Smoke detectors use a speck of radioactive metal to sense smoke."]]);
EM("Cm",[["Probe Heater","HEA","a",70,100,"","Space probes kept warm with the heat of radioactive decay."]]);
EM("Bk",[["Short Hold","RAD","a",60,100,"spd+1","Some elements have only been made a few micrograms at a time."]]);
EM("Cf",[["Neutron Source","RAD","a",85,100,"tdef-1@30","A tiny amount of this element is a strong neutron source."]]);
EM("Es",[["Barely There","STR","g",0,100,"dodge","Found first in the debris of a bomb test, and almost never since."]]);
EM("Sm",[["Fixed Field","PUL","a",80,100,"","Some magnets keep their strength even when hot."]]);
EM("Dy",[["Hot Magnet","PUL","g",0,100,"nocurie,draw+1","A pinch of the right element keeps a motor's magnets working when hot."]]);
EM("Tb",[["Magnetostrict","RES","a",75,100,"","Some alloys change shape in a magnetic field and can be used as speakers."]]);
EM("Sc",[["Stiff Swing","DRP","a",70,100,"","Some light alloys are stiff enough for baseball bats."]]);
EM("Se",[["Light Sensitive","RES","s",0,100,"tacc-1,acc+1","Some elements conduct better in light, which is how old photocopiers worked."]]);
EM("Eu",[["Banknote Glow","RAD","s",0,100,"tacc-1","Banknotes glow under ultraviolet light so forgeries can be spotted."]]);
EM("Tm",[["Portable X-Ray","RAD","a",60,100,"","Some rare elements make small, portable X-ray sources."]]);
EM("Yb",[["Atomic Clock","RES","g",0,100,"spd+2","Some of the most precise clocks count the ticks of a single kind of atom."]]);
EM("Lu",[["Scan Crystal","RAD","s",0,100,"crit,acc+1","Medical scanners use crystals that flash when radiation hits them."]]);
EM("Pa",[["Rare Decay","RAD","a",75,100,"","One of the rarest naturally occurring elements."]]);
EM("At",[["Rarest Trace","RAD","a",90,85,"","Less than a gram of this element exists in the whole crust of the Earth at any time."]]);
EM("I",[["Thyroid Block","RAD","g",0,100,"cure,noirr","Tablets taken after a radiation leak protect the body from radioactive forms of this element."]]);
EM("Pr",[["Welder's Glass","RES","s",0,100,"tacc-1","Welders' goggles use a glass made with a rare element to cut the glare."]]);
EM("Gd",[["Neutron Trap","RAD","g",0,100,"sink","Some metals capture neutrons better than anything else."]]);
EM("Fl",[["Island of Stability","STR","g",0,100,"def+2,ward+2","Some superheavy elements might be stable for longer than the rest."]]);
EM("Mc",[["Seconds to Live","RAD","a",110,90,"recoil:30","Some elements exist for less than a second."]]);
EM("Nh",[["Atom at a Time","RAD","a",25,100,"multi:2-5","Some elements have only ever been made one atom at a time."]]);
EM("Lv",[["Gone Again","STR","g",0,100,"dodge,spd+1","Made, measured, and gone within a heartbeat."]]);
EM("Ts",[["Superheavy","DRP","a",100,90,"","Among the heaviest atoms anyone has made."]]);
EM("Rn",[["Basement Gas","RAD","s",0,100,"irr","Radioactive gas seeps up into cellars from the ground."]]);
EM("Ge",[["Transistor","CUR","a",60,100,"spd+1","The first transistors were made from a semiconducting element."]]);
EM("Te",[["Phase Change","HEA","s",0,100,"tdef-1,tward-1","Rewritable discs stored data by melting tiny spots of an alloy."]]);
EM("Sr",[["Road Flare","HEA","a",70,100,"tacc-1@30","Some elements give road flares and fireworks their colour."]]);
EM("Ba",[["Contrast Meal","RAD","g",0,100,"sink","A dense compound swallowed before an X-ray blocks the beam."]]);
EM("Ac",[["Glow in the Dark","RAD","a",70,100,"irr@30","Some elements glow faintly in the dark from their own radioactivity."]]);
EM("Ho",[["Field Focus","PUL","s",0,100,"draw+2","Some elements focus magnetic fields better than any other."]]);
EM("Er",[["Fibre Boost","CUR","a",65,100,"","Optical fibres are boosted by a trace of a rare element."]]);
/* ---- property moves: earned by having an extreme property ---- */
const PM=(rule,a)=>a.forEach(x=>M(...x.slice(0,7),"p:"+rule));
PM("vdense",[["Sheer Weight","DRP","a",95,95,"","The densest metals weigh more than twice as much as steel."]]);
PM("vlight",[["Featherweight","STR","g",0,100,"spd+2,dodge","Some metals weigh less than water."]]);
PM("vhard",[["Unscratchable","SCR","g",0,100,"scrguard","Near the top of the hardness scale, very little can mark it."],["Diamond Point","SCR","a",95,95,"","The hardest tools are tipped with the hardest materials."]]);
PM("vsoft",[["Give Way","STR","g",0,100,"dodge,def+1","Soft metal gives and then settles again."]]);
PM("vhot",[["Refractory Wall","HEA","g",0,100,"refrac,def+1","Refractory metals stay solid where most things have long since melted."],["Furnace Lance","HEA","a",100,90,"","Metal that stays solid at furnace heat makes a fearsome lance."]]);
PM("vcold",[["Stay Molten","HEA","g",0,100,"dodge,heal:15","Liquid at room temperature, and happy to stay that way."]]);
PM("vcond",[["Lossless Line","CUR","a",95,95,"","The best conductors lose almost nothing on the way."]]);
PM("vinsul",[["Resistor","CUR","g",0,100,"ground,def+1","Poor conductors are used to hold current back."]]);
PM("strongmag",[["Saturation","PUL","a",95,90,"","Push a magnet as far as it will go."],["Field Lock","PUL","s",0,100,"mag,tspd-1","Caught in a strong field, it can't get away."]]);
PM("eddyable",[["Induction Ring","CUR","a",80,100,"eddy","A changing field induces current in any conductor close by."]]);
PM("noble",[["Never Rusts","COR","g",0,100,"film5,cure","Noble metals don't corrode in air or water."]]);
PM("basemetal",[["Give Electrons","COR","a",65,100,"galv","Base metals give their electrons up readily, and that can be used."]]);
PM("hotrad",[["Self-Heating","HEA","g",0,100,"heal:20","Very radioactive metal is warm to the touch."]]);
PM("glassy",[["Ringing Clear","RES","a",90,95,"","Hard, light metal rings like a bell."]]);
PM("toughmid",[["Tough Love","STR","g",0,100,"endure,def+1","Not too hard, not too soft: tough enough to take a beating."]]);
PM("multi",[["Many Hands","STR","s",0,100,"atk+1,draw+1","An alloy of many ingredients has many tricks."]]);
PM("pure",[["Single Mind","SCR","s",0,100,"atk+2","Almost one element, with nothing to dilute it."]]);
/* ---- what it was made for: category keywords ---- */
const KW=[];const KM=(keys,a)=>{a.forEach(x=>M(...x.slice(0,7),"k:"+keys[0]));KW.push([keys,a.map(x=>x[0])])};
KM(["bell","organ","loudspeaker","speaker","chime","gong","tuning"],[["Toll","RES","a",80,100,"tdef-1@30","Bell metal is chosen to ring for as long as possible."],["Feedback Howl","RES","a",70,100,"tacc-1@30","A speaker too close to its microphone howls."]]);
KM(["magnet","compass","needle","magnetic"],[["True North","PUL","s",0,100,"acc+2","A compass needle always swings back to north."]]);
KM(["maglev","levitation"],[["Levitate","PUL","g",0,100,"dodge,spd+1","Magnetic trains float above their rails."]]);
KM(["prosthetic","limb","implant","joint"],[["Spring Step","STR","g",0,100,"spd+1,heal:15","Prosthetic limbs store and return energy with every step."]]);
KM(["drone","glider","kayak","bike","bicycle","racing","dart"],[["Slipstream","STR","g",0,100,"spd+2","Built to go fast with as little effort as possible."]]);
KM(["shielding","shield","apron"],[["Shield Wall","RAD","g",0,100,"sink,def+1","Shielding is the whole reason it was made."]]);
KM(["nuclear","radiationdamage","reactor","fuel"],[["Neutron Soak","RAD","a",70,100,"tdraw-1","Built to sit in a reactor and take a pounding."]]);
KM(["induction","cooktop","coil","transformer"],[["Induction Hob","HEA","a",80,100,"eddy","Induction hobs heat the pan by inducing current right in it."]]);
KM(["sensor","test","testing","research","sample","experimental","prototype","precision"],[["Calibrate","CUR","s",0,100,"acc+1,crit","Measure twice."]]);
KM(["computer","simulation","laptop","relay","processor"],[["Model Run","CUR","s",0,100,"acc+2,crit","Run the model before the experiment."]]);
KM(["catalyst","converter"],[["Catalyse","COR","s",0,100,"draw+2","Speed the reaction without being spent."]]);
KM(["pipe","valve","manifold","nozzle","fountain"],[["Pressure Release","QUE","a",75,100,"","A valve opening all at once."]]);
KM(["blade","file","drill","bit","cutting","teeth","spike","pick","iceaxe","saw","knife"],[["Keen Edge","SCR","a",75,100,"crit","Made to cut, and kept sharp."]]);
KM(["trophy","medal","commemorative","jewelry","ceremonial","luxury","coin","crown"],[["Dazzle","RES","s",0,100,"tacc-2","Polished for show, and it shows."]]);
KM(["key","latch","locker","hinge","door","lock"],[["Lock Up","PUL","s",0,100,"mag,def+1","Shut and locked."]]);
KM(["chain","ladder","rung","bridge","strut","frame","bracket","rack","beam"],[["Load Path","STR","g",0,100,"def+2","Weight runs down through the frame to the ground."]]);
KM(["weight","ballast","counterweight","flywheel"],[["Counterweight","DRP","a",85,100,"","A counterweight drops exactly as hard as it's meant to."]]);
KM(["turbine","engine","motor","gearbox","armature"],[["Spin Up","CUR","g",0,100,"spd+1,draw+1","Motors build up speed with every turn."]]);
KM(["furnace","kiln","glassfurnace","afterburner","exhaust","rocket"],[["Afterburn","HEA","a",90,95,"","Fuel sprayed into the hot exhaust for a burst of extra thrust."]]);
KM(["solder","fusible"],[["Fuse Joint","HEA","g",0,100,"heal:30","A solder joint sets in a second."]]);
KM(["watch","clock","spring"],[["Wind Up","STR","s",0,100,"spd+1,atk+1","A wound spring stores energy for later."]]);
KM(["pen","nib","stylus"],[["Signature","SCR","a",60,100,"nomiss","A nib leaves its mark every time."]]);
KM(["mold","mould","quickcast","cast","casting"],[["Recast","HEA","g",0,100,"heal:35,cure","Melt it down and pour it again, good as new."]]);
KM(["housing","casing","shell","liner","coating","cladding","armor","armour"],[["Hard Shell","SCR","g",0,100,"def+2","A shell exists to be hit."]]);
KM(["railway","rail","track"],[["Rail Grind","SCR","a",70,100,"tspd-1@30","Steel on steel, mile after mile."]]);
KM(["satellite","probe","space"],[["Orbit","PUL","g",0,100,"dodge,ward+1","Always falling, never landing."]]);
KM(["fishing","hook","lure"],[["Hook and Line","PUL","s",0,100,"mag","Set the hook and it can't get away."]]);
KM(["garden","playground","outdoor","statue"],[["Weathered","COR","g",0,100,"film3,def+1","Made to stand out in the rain for decades."]]);
KM(["camera","lensgrinding","stainedglass","lens","glass"],[["Flash","RES","s",0,100,"tacc-1","One bright flash and nobody can see for a moment."]]);
KM(["safety","emergency"],[["Fail-Safe","STR","g",0,100,"endure","Designed to fail in the safest possible way."]]);
KM(["resistor","heater","element"],[["Resist","CUR","g",0,100,"ground,heal:10","Resistance is the point."]]);
KM(["mystery","unknown"],[["Unknown Quantity","STR","a",70,100,"anyclass","Nobody knows what it does, including, apparently, itself."]]);
KM(["boat","ship","marine","hull"],[["Salt Proof","QUE","g",0,100,"qguard,film3","Made to live in sea water."]]);
KM(["tool","wrench","hammer","anvil"],[["Right Tool","SCR","a",70,100,"crit","The right tool for the job."]]);
KM(["block","bolt","fitting","nut","rivet"],[["Tighten","STR","s",0,100,"def+1,tspd-1","A quarter turn more."]]);
KM(["cup","mug","kettle","pan"],[["Hot Cup","HEA","a",60,100,"tdef-1@30","Something hot, held a little too long."]]);
/* ---- grade moves: earned by tempering ---- */
[["Work Harden","STR","s",0,100,"atk+2,def-1","Bending metal cold makes it harder and less forgiving.","g:1"],["Annealing Rest","HEA","g",0,100,"heal:40,cure","Heat it gently and let it cool slowly, and the stress goes out of it.","g:1"],
 ["Temper","HEA","g",0,100,"def+1,atk+1,heal:15","Reheating hardened steel trades a little hardness for a lot of toughness.","g:2"],["Quench and Temper","QUE","a",85,100,"tdef-1@40","Hardened in water, then softened just enough.","g:2"],
 ["Masterstroke","SCR","a",110,90,"bestclass","A craftsman's best work, in whatever it does best.","g:3"],["Grain Perfect","STR","g",0,100,"def+2,ward+2","Every crystal in it is exactly where it should be.","g:3"]].forEach(x=>M(...x));
