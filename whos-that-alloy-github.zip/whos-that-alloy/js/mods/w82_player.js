/* =============== WHO YOU ARE: pick a boy or a girl on a new game, change any time at the wardrobe ===============
   The girl keeps every coat, hat, pair of goggles and held sample the boy has. Only the hair changes: a fringe on top, long hair
   down the back past the collar, a lock in front of the ear and a clip. Old saves keep the character they already had. */
const LOOK_KEY="wta_look";
const lookNow=()=>store.get(LOOK_KEY,"boy")==="girl"?"girl":"boy";
const GIRL_HAIR="#6B4424";
const GIRL_BACK=`<path d="M13.2 8.6 Q10 13.6 10.8 20.4 Q11.2 25.2 13.4 26.8 Q15.6 27.6 17.4 25.6 Q15.8 22.4 16.4 18 L26.6 12.4 Q25.6 5.8 20 5.8 Q15.4 5.8 13.2 8.6 Z" fill="${GIRL_HAIR}" stroke="#121B40" stroke-width="1.3" stroke-linejoin="round"/><path d="M12.6 15.4 Q12.4 21 14.2 24.8 M14.6 14.2 Q14.4 19.6 15.6 23.4" stroke="#4A2C14" stroke-width=".6" fill="none" stroke-linecap="round"/>`;
const GIRL_TOP=`<path d="M12.6 12.8 Q11.8 5.2 19.6 5 Q27.6 5 27.9 11.8 Q25.6 8.8 22 9.6 Q20.4 11.2 17.6 10.8 Q14.6 11.2 12.6 12.8 Z" fill="${GIRL_HAIR}" stroke="#121B40" stroke-width="1.3" stroke-linejoin="round"/><path d="M27.6 10.8 Q28.8 15 27.4 19.2 Q26.2 17.4 26.6 13.2 Z" fill="${GIRL_HAIR}" stroke="#121B40" stroke-width=".9" stroke-linejoin="round"/><rect x="22.2" y="6.2" width="3.4" height="1.3" rx=".6" fill="#E8412C" stroke="#121B40" stroke-width=".5" transform="rotate(-18 23.9 6.8)"/>`;
const GIRL_LASH=`<path d="M27.7 12.2 L28.7 11.5 M27.8 13.2 L28.9 13" stroke="#121B40" stroke-width=".55" stroke-linecap="round"/>`;
function girlify(s,c){if(c&&c.id==="shadowkid")return s;
  const L=MINER.split("\n"),head=L[14],hair=L[15];
  const hi=s.indexOf(head);if(hi<0)return s;
  s=s.slice(0,hi)+GIRL_BACK+"\n"+s.slice(hi);
  /* bare-headed coats keep MINER's hair line: swap it for the fringe. Hatted coats: the hat stays, the fringe lock shows under it */
  if(s.includes(hair))s=s.replace(hair,GIRL_TOP);
  else{const at=s.indexOf(head)+head.length;s=s.slice(0,at)+`\n<path d="M27.6 10.8 Q28.8 15 27.4 19.2 Q26.2 17.4 26.6 13.2 Z" fill="${GIRL_HAIR}" stroke="#121B40" stroke-width=".9" stroke-linejoin="round"/>`+s.slice(at)}
  const e=s.lastIndexOf("</svg>");return e>=0?s.slice(0,e)+GIRL_LASH+s.slice(e):s}
{const _ps=playerSVG;playerSVG=function(c){const coat=c||coatNow(),s=_ps(c);return lookNow()==="girl"?girlify(s,coat):s}}
/* a preview of either look in the current coat, regardless of which is chosen */
function lookPreview(k){const was=store.get(LOOK_KEY,"boy");store.set(LOOK_KEY,k);const s=playerSVG();store.set(LOOK_KEY,was);return s}
function lookSet(k){store.set(LOOK_KEY,k);sfx("sel");coatRefresh()}

/* ---- new game: who are you? ---- */
function lookPicker(done){const o=document.createElement("div");o.className="tut-offer look-offer";
  o.innerHTML=`<div class="tut-bub mid"><div class="tut-face">${marlowSVG()}</div><div class="tut-body"><b>BEFORE YOU START</b><p>The new assistant! Come in, come in. Which one of these is you? You can change your mind at the wardrobe any time.</p>
    <div class="look-pick">${["boy","girl"].map(k=>`<button class="look-opt" data-look="${k}"><span class="coatpv">${lookPreview(k)}</span><b>${k.toUpperCase()}</b></button>`).join("")}</div></div></div>`;
  document.body.appendChild(o);o.querySelectorAll("[data-look]").forEach(b=>b.onclick=()=>{lookSet(b.dataset.look);o.remove();done()})}
{const sb=$("#startbtn"),old=sb.onclick;sb.onclick=e=>{
  if(store.get(LOOK_KEY,null)==null){
    /* an old save (it already got through the tutorial, or has things registered) keeps the character it had */
    const old2=store.get("wta_tut",0)||(typeof S!=="undefined"&&S.caught&&S.caught.size);
    if(old2){store.set(LOOK_KEY,"boy");old(e);return}
    auInit&&auInit();lookPicker(()=>old(e));return}
  old(e)}}

/* ---- the wardrobe: a mirror on the inside of the door ---- */
{const _ow=openWardrobe;openWardrobe=function(){_ow();const m=$("#wardrobe");if(!m)return;const list=m.querySelector(".bag-list");if(!list||list.querySelector(".look-row"))return;
  const cur=lookNow();
  list.insertAdjacentHTML("afterbegin",`<div class="look-row"><p class="bag-empty">The mirror on the inside of the door. Who's looking back?</p><div class="look-pick">${["boy","girl"].map(k=>`<button class="look-opt${k===cur?" on":""}" data-look="${k}" ${k===cur?"disabled":""}><span class="coatpv">${lookPreview(k)}</span><b>${k.toUpperCase()}</b></button>`).join("")}</div></div>`);
  list.querySelectorAll(".look-row [data-look]").forEach(b=>b.onclick=()=>{lookSet(b.dataset.look);openWardrobe();say0("You check the mirror. Yes. That's you.")})}}
