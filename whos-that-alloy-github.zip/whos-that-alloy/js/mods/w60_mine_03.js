/* ---- Rustvein Mine, 3 ---- */
/* Crane No. 1: 'I was made before I was planned.' A goat that poses riddles, horns curled into question marks. */
addForm("Crane No. 1",{n:"#E8E0D0",a:"#3A3A4A",rn:"#6A4A3A",rb:"#B8D8E8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(68)+
 pt("tail",150,92,`<path d="M148 92 Q160 80 164 86 Q158 94 150 98 Z" fill="${P.n}" ${SW2}/>`)+
 fLeg("legB",142,108,34,6,P.nd,P.ac,.5)+fLeg("legB",108,110,32,6,P.nd,P.ac,1.3)+
 `<path d="M90 100 Q88 78 118 76 Q150 78 154 98 Q150 116 120 116 Q94 116 90 100 Z" fill="${P.n}" ${SW}/>${[100,112,124,136].map(x=>`<path d="M${x} 104 q2 8 -2 12" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 fLeg("legF",134,110,32,6,P.n,P.ac,0)+fLeg("legF",100,110,32,6,P.n,P.ac,.8)+
 pt("head",92,86,`<path d="M88 92 Q84 76 74 70" stroke="${FI}" stroke-width="20" fill="none" stroke-linecap="round"/><path d="M88 92 Q84 76 74 70" stroke="${P.n}" stroke-width="16" fill="none" stroke-linecap="round"/>`+
  `<path d="M52 70 Q54 54 70 52 Q86 54 86 70 Q82 80 68 82 Q54 82 52 70 Z" fill="${P.n}" ${SW}/>${E2(66,64,4,"#C8A020")}<path d="M62 64 h8" stroke="${FI}" stroke-width="1.6"/>`+HMOUTH(52,74,60,P,3)+
  pt("jaw",58,82,`<path d="M54 80 Q52 98 60 100 Q62 90 62 82 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M70 52 Q72 30 88 30 Q100 32 98 44 Q96 52 88 52 Q84 54 84 60" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M70 52 Q72 30 88 30 Q100 32 98 44 Q96 52 88 52 Q84 54 84 60" stroke="${P.ac}" stroke-width="5" fill="none" stroke-linecap="round"/><circle cx="84" cy="68" r="3" fill="${P.ac}" ${SW2}/>`+
  pt("ear",76,58,`<path d="M76 58 Q92 56 96 62 Q88 66 78 64 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<text x="24" y="46" font-family="Georgia,serif" font-size="22" font-weight="bold" fill="${P.ac}">?</text>`)+fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(144,40,6)));
FORM_TITLE["Crane No. 1"]="Riddle Goat";SM("Crane No. 1","Unsolved","RES","s",0,100,"tacc-1,tspd-1","A question with no answer is very hard to stop thinking about.");

/* Crayon Map Metal: a child's crayon map led to the garden shed. A dragon drawn in crayon: wobbly scribble outline, X on its flank. */
addForm("Crayon Map Metal",{n:"#5AB04A",a:"#E8412C",rn:"#E8C040",rb:"#8A4AC8",ra:"#4A8AE8"},"stand",(P,g)=>fShadow(70)+
 pt("tail",150,108,`<path d="M146 104 Q176 110 184 92 Q190 80 180 76 L188 70 L176 72" stroke="${P.nd}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("wingB",126,84,`<path d="M124 86 L134 44 L150 62 L162 48 L166 76 Q150 88 132 92 Z" fill="${P.nd}" stroke="${P.ndd}" stroke-width="3" stroke-linejoin="round"/>`,.4)+
 [[142,.5],[108,1.3]].map(([x,d])=>pt("legB",x,112,`<path d="M${x-5} 110 L${x-6} 140 L${x+8} 140" stroke="${P.nd}" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,d)).join("")+
 `<path d="M86 104 Q86 80 118 80 Q150 82 154 104 Q148 120 118 120 Q90 120 86 104 Z" fill="${P.n}" stroke="${P.nd}" stroke-width="4"/><path d="M90 102 Q88 84 118 83 M100 116 Q130 122 150 108" stroke="${P.ndd}" stroke-width="2" fill="none"/>`+
 `<path d="M116 94 l10 12 M126 94 l-10 12" stroke="${P.ac}" stroke-width="4" stroke-linecap="round"/>${[[96,92],[104,108],[136,96],[142,110]].map(([x,y])=>`<path d="M${x} ${y} l6 -2" stroke="${P.ndd}" stroke-width="2.4" stroke-linecap="round"/>`).join("")}`+
 [[132,0],[96,.8]].map(([x,d])=>pt("legF",x,114,`<path d="M${x-5} 112 L${x-6} 142 L${x+8} 142" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${x-5} 112 L${x-6} 142" stroke="${P.ndd}" stroke-width="2" fill="none"/>`,d)).join("")+
 pt("wingF",112,84,`<path d="M110 86 L104 40 L120 56 L130 40 L134 74 Q122 86 112 90 Z" fill="${P.n}" stroke="${P.nd}" stroke-width="3" stroke-linejoin="round"/>`)+
 pt("head",88,90,`<path d="M90 96 L76 70" stroke="${P.n}" stroke-width="14" stroke-linecap="round"/><path d="M48 66 Q50 50 70 50 Q86 52 86 66 Q84 76 70 78 L50 74 Z" fill="${P.n}" stroke="${P.nd}" stroke-width="4" stroke-linejoin="round"/>`+
  `<circle cx="68" cy="60" r="5" fill="#fff" stroke="${FI}" stroke-width="2"/><circle cx="66" cy="60" r="2.4" fill="${FI}"/>`+pt("jaw",64,76,`<path d="M50 74 L72 78 L66 86 L52 80 Z" fill="${P.nd}" stroke="${P.ndd}" stroke-width="2"/><path d="M56 78 l2 3 l2 -3 l2 3" stroke="#fff" stroke-width="1.6" fill="none"/>`)+
  `<path d="M70 50 L72 38 L78 48 L82 36 L84 50" stroke="${P.ac}" stroke-width="3" fill="none" stroke-linejoin="round"/>`)+
 fG(g,1,`<path d="M18 122 q8 -10 16 0 q8 10 16 0" stroke="${P.ac}" stroke-width="3" stroke-dasharray="4 4" fill="none"/>`)+fG(g,2,`<circle cx="121" cy="100" r="3" fill="#fff" ${SW2}/>`)+fG(g,3,star(150,26,6)));
FORM_TITLE["Crayon Map Metal"]="Scribbled Dragon";SM("Crayon Map Metal","X Marks It","STR","a",70,100,"crit","Dig exactly where the map says. It's always closer than you thought.");

/* Crumleyite: delivered to the wrong bakery. A pug in an oven mitt, a loaf balanced on its head. */
addForm("Crumleyite",{n:"#D8B890",a:"#3A2A24",rn:"#4A4A5A",rb:"#E8A0B0",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(60)+
 pt("tail",142,100,`<path d="M140 98 Q154 86 148 80 Q140 82 144 90" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M140 98 Q154 86 148 80 Q140 82 144 90" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",130,114,26,9,P.nd,P.ndd,.5)+
 `<path d="M84 110 Q80 84 110 82 Q144 84 146 108 Q142 124 112 124 Q86 124 84 110 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",122,116,24,9,P.n,P.ndd,0)+
 pt("armF",92,112,`<path d="M96 108 Q84 120 74 120" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M68 108 Q60 112 62 126 Q66 140 82 138 Q92 136 88 124 L86 112 Z" fill="#C83A3A" ${SW}/><path d="M64 116 l6 0 M64 122 l6 0 M66 128 l6 0" stroke="#F4F0E4" stroke-width="2"/><path d="M84 116 Q94 108 92 100" stroke="#C83A3A" stroke-width="7" stroke-linecap="round"/>`)+
 pt("head",86,82,`<path d="M58 84 Q56 64 80 60 Q104 62 104 84 Q102 102 80 104 Q60 102 58 84 Z" fill="${P.n}" ${SW}/><path d="M62 88 Q64 76 78 76 Q90 78 90 90 Q86 100 74 100 Q64 98 62 88 Z" fill="${P.ac}"/><path d="M66 74 q6 -4 12 0 M84 72 q4 -4 10 0" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
  `${E2(68,80,5,"#3A2410",[-.3,-.2])}${E2(88,78,5,"#3A2410",[-.3,-.2])}<ellipse cx="72" cy="88" rx="4" ry="2.6" fill="${FI}"/>`+HMOUTH(68,94,80,P,3)+
  pt("ear",62,66,`<path d="M64 64 Q52 60 52 74 Q58 76 66 70 Z" fill="${P.ac}" ${SW2}/>`)+pt("ear",98,66,`<path d="M96 64 Q108 58 110 72 Q104 74 96 70 Z" fill="${P.ac}" ${SW2}/>`,.3)+
  `<path d="M62 60 Q60 42 80 40 Q102 40 100 60 Z" fill="#D8A050" ${SW}/>${[70,80,90].map(x=>`<path d="M${x} 46 l4 8" stroke="#A86A20" stroke-width="2.4" stroke-linecap="round"/>`).join("")}`)+
 fG(g,1,`<path d="M150 60 q-4 -8 2 -14 M160 62 q-4 -8 2 -14" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="114" cy="106" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(132,40,6)));
FORM_TITLE["Crumleyite"]="Oven-Mitt Pug";SM("Crumleyite","Fresh Out The Oven","DRP","a",75,100,"molten@20","Mind your fingers. The tray is still hot.");

/* Crumpetite: the market gave it a licence, a stall number and a birthday. A vole wearing a paper party hat, cake candle on its back. */
addForm("Crumpetite",{n:"#9A6A4A",a:"#F2C94C",rn:"#5A6A8A",rb:"#E8B0C8",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(60,104)+
 pt("tail",150,124,`<path d="M148 124 Q168 128 176 120" stroke="#E8A0B0" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 [[138,.5],[96,1.2]].map(([x,d])=>pt("legB",x,130,`<ellipse cx="${x}" cy="140" rx="8" ry="5" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M72 120 Q72 92 112 90 Q152 92 154 122 Q150 140 112 140 Q76 140 72 120 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${88+i*10} ${100+i%2*4} q4 4 8 0" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 `<ellipse cx="118" cy="92" rx="14" ry="5" fill="#F4E0C8" ${SW2}/><rect x="115" y="72" width="6" height="20" fill="#E8B0C8" ${SW2}/><path d="M118 72 Q114 64 118 58 Q122 64 118 72 Z" fill="#F2A040" ${SW2}/>`+
 [[124,0],[84,.7]].map(([x,d])=>pt("legF",x,132,`<ellipse cx="${x}" cy="142" rx="8" ry="5" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",78,118,`<path d="M42 118 Q44 98 66 96 Q86 98 88 116 Q84 132 64 132 Q48 132 42 118 Z" fill="${P.n}" ${SW}/><circle cx="42" cy="118" r="3.6" fill="#E8A0B0" ${SW2}/>${E2(58,112,4)}`+HMOUTH(46,124,54,P,3)+`<path d="M42 120 h-10 M42 122 l-9 4" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",72,102,`<circle cx="72" cy="102" r="7" fill="${P.n}" ${SW2}/><circle cx="72" cy="102" r="3.6" fill="#E8A0B0"/>`)+
  `<path d="M54 98 L62 70 L74 98 Z" fill="${P.ac}" ${SW2}/><path d="M57 88 L70 90 M60 78 L66 80" stroke="#E8412C" stroke-width="2.4"/><circle cx="62" cy="70" r="3" fill="#E8412C" ${SW2}/>`)+
 fG(g,1,`${[[24,60,"#E8412C"],[34,50,"#4A8AE8"],[160,50,"#5AB04A"],[172,64,"#F2C94C"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="4" height="7" fill="${c}" transform="rotate(30 ${x} ${y})"/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="126" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Crumpetite"]="Birthday Vole";SM("Crumpetite","Make A Wish","RES","s",0,100,"heal:40","Close your eyes, blow out the candle, and don't tell anyone what you asked for.");

/* Curtain Jam Special: the curtain always jams once, during the saddest scene. A spider hanging from a fly-rope, curtain bunched in its legs. */
addForm("Curtain Jam Special",{n:"#3A2A3A",a:"#B8302A",rn:"#E8D8C0",rb:"#3A6A4A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M104 0 V54" stroke="#C8A060" stroke-width="5"/><path d="M104 0 V54" stroke="#8A6030" stroke-width="2" stroke-dasharray="3 3"/>`+
 `<path d="M140 10 Q132 60 148 110 Q166 112 178 104 Q164 60 176 10 Z" fill="${P.ac}" ${SW}/>${[148,156,166].map(x=>`<path d="M${x} 12 Q${x-4} 60 ${x+2} 106" stroke="#7A1A1A" stroke-width="2" fill="none"/>`).join("")}<path d="M138 10 H180" stroke="${P.b}" stroke-width="6" stroke-linecap="round"/>`+
 `<ellipse class="shd" cx="104" cy="148" rx="20" ry="3" fill="#000" opacity=".1"/>`+
 [0,1,2,3].map(i=>pt("legB",104,80,`<path d="M${108} ${78+i*4} Q${130+i*4} ${60+i*14} ${140+i*2} ${80+i*16}" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M${108} ${78+i*4} Q${130+i*4} ${60+i*14} ${140+i*2} ${80+i*16}" stroke="${P.nd}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`,i*.2)).join("")+
 `<ellipse cx="104" cy="70" rx="16" ry="18" fill="${P.n}" ${SW}/><path d="M96 62 l8 6 l8 -6 M98 74 l6 4 l6 -4" stroke="${P.ac}" stroke-width="2" fill="none"/>`+
 [0,1,2,3].map(i=>pt("legF",100,82,`<path d="M${100} ${80+i*4} Q${78-i*4} ${62+i*14} ${66-i*2} ${82+i*16}" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M${100} ${80+i*4} Q${78-i*4} ${62+i*14} ${66-i*2} ${82+i*16}" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`,i*.2)).join("")+
 pt("head",104,94,`<circle cx="104" cy="96" r="12" fill="${P.n}" ${SW}/>${E2(98,94,3.4,"#B8302A")}${E2(110,94,3.4,"#B8302A")}<circle cx="96" cy="100" r="1.6" fill="${P.ac}"/><circle cx="112" cy="100" r="1.6" fill="${P.ac}"/><path d="M100 104 L98 112 M108 104 L110 112" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`+pt("jaw",104,105,`<path d="M101 104 Q104 109 107 104 Z" fill="${FMOUTH}"/>`)+`<path d="M96 104 Q94 108 92 108" stroke="#7AB8E8" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<path d="M30 140 q10 -14 20 0" stroke="#F2C94C" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="70" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(40,30,6)));
FORM_TITLE["Curtain Jam Special"]="Fly-Rope Spider";SM("Curtain Jam Special","Jammed Curtain","RES","s",0,100,"tspd-2","Halfway down, and it won't go one inch further.");

/* Deckhand's Silence: he refused to discuss what he saw. A clam that will not open its mouth, a padlock on its hinge. */
addForm("Deckhand's Silence",{n:"#B8A8B8",a:"#E8C060",rn:"#2A3A5A",rb:"#E8D8C8",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(54)+
 pt("tongue",68,122,`<path d="M74 128 Q56 130 46 140 Q60 144 76 136 Z" fill="#E8A0A0" ${SW2}/>`)+
 `<path d="M60 124 Q64 140 104 142 Q144 140 148 124 Z" fill="${P.nd}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${104} 142 L${72+i*16} 126" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`+
 pt("jaw",148,122,`<path d="M58 124 Q56 80 104 72 Q152 80 150 124 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M104 120 L${66+i*15} ${96-Math.sin((i+.5)/6*Math.PI)*20}" stroke="${P.nd}" stroke-width="2"/>`).join("")}${[0,1,2].map(i=>`<path d="M${68+i*4} ${112-i*12} Q104 ${102-i*14} ${140-i*4} ${112-i*12}" stroke="${P.nl}" stroke-width="1.6" fill="none"/>`).join("")}`)+
 `<path d="M60 124 H148" stroke="${FI}" stroke-width="4"/>`+
 pt("head",104,110,`${E2(88,106,5,"#2A3A5A",[-.5,.2])}${E2(118,106,5,"#2A3A5A",[-.5,.2])}<path d="M82 98 l12 4 M124 98 l-12 4" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("claw",104,124,`<rect x="96" y="122" width="16" height="13" rx="2" fill="${P.ac}" ${SW2}/><path d="M99 122 Q99 112 104 112 Q109 112 109 122" stroke="${FI}" stroke-width="5" fill="none"/><path d="M99 122 Q99 112 104 112 Q109 112 109 122" stroke="${P.ll}" stroke-width="2.6" fill="none"/><circle cx="104" cy="128" r="2" fill="${FI}"/>`)+
 fG(g,1,`<path d="M20 120 q6 -6 12 0 q6 6 12 0" stroke="#7AB8E8" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="150" cy="140" r="4" fill="#F4F0F8" ${SW2}/>`)+fG(g,3,star(104,44,6)));
FORM_TITLE["Deckhand's Silence"]="Padlocked Clam";SM("Deckhand's Silence","Say Nothing","RES","s",0,100,"def+1,ward+1","No comment. Not now, not ever.");

/* Discrepancium: a crate that didn't exist kept turning up in the stock count. A lemming carrying a tally board, counting itself wrong. */
addForm("Discrepancium",{n:"#C89A6A",a:"#3A2A20",rn:"#E8D8C0",rb:"#4A6AA8",ra:"#E8412C"},"stand",(P,g)=>fShadow(60)+
 pt("tail",142,110,`<path d="M140 110 l10 -2" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 fLeg("legB",126,122,18,8,P.nd,P.ndd,.5)+
 `<path d="M80 116 Q76 84 108 80 Q142 84 144 114 Q140 132 110 132 Q82 132 80 116 Z" fill="${P.n}" ${SW}/><path d="M92 88 Q110 80 128 90 Q118 100 104 96 Z" fill="${P.ac}"/><path d="M96 124 Q112 132 132 122" stroke="${P.nll}" stroke-width="6" fill="none" opacity=".6"/>`+
 fLeg("legF",100,124,18,8,P.n,P.ndd,0)+
 pt("armF",88,102,`<path d="M90 104 Q74 98 66 90" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M90 104 Q74 98 66 90" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><g transform="rotate(-14 58 80)"><rect x="40" y="58" width="32" height="40" rx="3" fill="#B88A50" ${SW2}/><rect x="44" y="64" width="24" height="30" fill="#F4F0E4"/><path d="M48 70 v8 M51 70 v8 M54 70 v8 M57 70 v8 M46 76 l14 -4" stroke="${FI}" stroke-width="1.4"/><path d="M48 84 v6 M51 84 v6 M54 84 v6" stroke="${FI}" stroke-width="1.4"/><text x="58" y="91" font-size="8" font-weight="bold" fill="${P.ac}">?</text></g>`)+
 pt("head",96,82,`<path d="M74 78 Q74 58 96 56 Q118 58 118 78 Q114 94 96 94 Q78 94 74 78 Z" fill="${P.n}" ${SW}/><path d="M80 64 Q96 50 114 64 Q104 66 96 64 Q88 64 80 64 Z" fill="${P.ac}"/><circle cx="76" cy="80" r="3" fill="${FI}"/>${E2(88,72,4.4,"#3A2410",[.4,-.6])}${E2(104,72,4.4,"#3A2410",[.4,-.6])}`+HMOUTH(80,86,88,P,3)+
  pt("ear",108,60,`<ellipse cx="110" cy="60" rx="5" ry="4" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<text x="150" y="60" font-family="monospace" font-size="16" font-weight="bold" fill="${P.ac}">+1?</text>`)+fG(g,2,`<circle cx="110" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(140,30,6)));
FORM_TITLE["Discrepancium"]="Stocktake Lemming";SM("Discrepancium","Miscount","RES","s",0,100,"tacc-1,tdef-1","There's one more than there should be. Or one fewer. Count again.");

/* Double Pay Metal: the porters wanted double to carry it past the pass. A shaggy yak with a pack frame and a crate twice its size. */
addForm("Double Pay Metal",{n:"#4A3A30",a:"#E8DCC0",rn:"#C8B8A0",rb:"#3A5A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(80)+
 pt("tail",170,96,fOL("M166 96 Q182 106 178 126",P.n,4)+`<path d="M174 120 Q184 128 176 136 Q170 128 174 120 Z" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",156,116,28,11,P.nd,P.ndd,.5)+fLeg("legB",112,118,26,11,P.nd,P.ndd,1.3)+
 `<rect x="98" y="34" width="56" height="46" rx="3" fill="#B88A50" ${SW}/><path d="M98 50 H154 M98 66 H154 M112 34 V80 M140 34 V80" stroke="#8A6030" stroke-width="2"/><path d="M106 44 l8 0 M146 74 l-6 -2" stroke="${FI}" stroke-width="2"/><path d="M120 76 L110 92 M140 76 L148 92" stroke="#6A4A2A" stroke-width="4"/>`+
 `<path d="M86 106 Q82 74 124 74 Q166 74 170 104 Q168 132 128 130 Q88 130 86 106 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${90+i*10} ${120+(i%2)*4} l-2 12 l4 -6 l2 8" stroke="${P.ndd}" stroke-width="2" fill="none"/>`).join("")}`+
 fLeg("legF",146,120,24,11,P.n,P.ndd,0)+fLeg("legF",98,120,24,11,P.n,P.ndd,.8)+
 pt("head",90,96,`<path d="M52 102 Q50 82 70 78 Q92 80 94 100 Q92 116 74 118 Q54 116 52 102 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${58+i*8} ${108} l-1 12" stroke="${P.ndd}" stroke-width="2"/>`).join("")}<path d="M52 104 Q56 98 62 100 Q62 110 54 110 Z" fill="${P.nl}"/>${E2(66,92,3.6)}`+HMOUTH(54,108,62,P,3)+
  `<path d="M70 80 Q58 72 56 60 Q64 66 74 72 Z" fill="${P.ac}" ${SW2}/><path d="M84 80 Q92 66 104 64 Q98 74 90 84 Z" fill="${P.ac}" ${SW2}/>`+pt("ear",80,84,`<path d="M80 84 Q90 84 94 88 Q88 92 80 90 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 L36 112 L52 140 Z" fill="#E8E8F0" ${SW2}/><path d="M30 122 L36 112 L42 122 Z" fill="#fff"/>`)+fG(g,2,`<circle cx="126" cy="114" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(126,18,6)));
FORM_TITLE["Double Pay Metal"]="Pack Yak";SM("Double Pay Metal","Heavy Load","STR","a",90,90,"selfspd-1","Carrying twice the weight is hard. Getting hit by it is harder.");

/* Dresser Metal: a wedding gift with no card, kept on the dresser. A dresser that turns out to be alive: drawers for a mouth, knobs for eyes. */
addForm("Dresser Metal",{n:"#8A5A3A",a:"#F2C94C",rn:"#C8D8E8",rb:"#5A3A6A",ra:"#5FE0A0"},"stand",(P,g)=>fShadow(54)+
 pt("legB",136,132,`<path d="M132 130 Q134 140 140 144" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M132 130 Q134 140 140 144" stroke="${P.nd}" stroke-width="4.4" fill="none" stroke-linecap="round"/>`,.5)+
 `<path d="M68 40 H140 L142 132 H66 Z" fill="${P.n}" ${SW}/><path d="M62 40 H146 L144 32 H64 Z" fill="${P.nd}" ${SW}/><path d="M140 40 L148 36 L148 128 L142 132 Z" fill="${P.ndd}" ${SW2}/>`+
 `<ellipse cx="104" cy="22" rx="16" ry="10" fill="#E8E8F0" ${SW2}/><path d="M92 24 Q104 6 116 24" fill="#F4F0F8" ${SW2}/><path d="M96 18 l4 -6 M108 18 l4 -6" stroke="#E89AB0" stroke-width="2.4"/>`+
 pt("head",104,64,`<rect x="74" y="46" width="60" height="30" rx="3" fill="${P.nl}" ${SW2}/>${E2(92,61,6,"#3A2410")}${E2(118,61,6,"#3A2410")}<path d="M84 52 l12 4 M126 52 l-12 4" stroke="${FI}" stroke-width="2"/>`)+
 `<rect x="74" y="82" width="60" height="14" rx="2" fill="${P.nl}" ${SW2}/><rect x="74" y="98" width="60" height="5" fill="${FMOUTH}"/>`+
 pt("jaw",104,104,`<rect x="72" y="100" width="64" height="26" rx="3" fill="${P.nl}" ${SW2}/>${[80,88,96,104,112,120,128].map(x=>`<path d="M${x} 100 l3 6 l3 -6" fill="#F4F0E4" ${SW2}/>`).join("")}<circle cx="104" cy="116" r="3.4" fill="${P.ac}" ${SW2}/>`)+
 `<circle cx="104" cy="89" r="3.4" fill="${P.ac}" ${SW2}/>`+
 pt("legF",76,132,`<path d="M74 130 Q72 140 66 144" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M74 130 Q72 140 66 144" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M162 140 l6 -14 l6 14 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="124" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Dresser Metal"]="Dresser Mimic";SM("Dresser Metal","Drawer Snap","SCR","a",80,95,"tdef-1@30","You only meant to look for a sock.");

/* Duck Pond No. 1: its factory appeared on maps as a duck pond. A wooden decoy duck with a factory chimney rising from its back. */
addForm("Duck Pond No. 1",{n:"#3A6A4A",a:"#E8A040",rn:"#E8DCC0",rb:"#4A4A8A",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 132 Q50 124 104 130 Q150 136 192 128 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 `<rect x="126" y="34" width="16" height="56" fill="#B85A3A" ${SW}/>${[46,58,70].map(y=>`<path d="M126 ${y} h16" stroke="#7A3A20" stroke-width="1.6"/>`).join("")}<rect x="122" y="30" width="24" height="8" fill="#7A3A20" ${SW2}/>`+
 pt("slow",134,24,`<circle cx="134" cy="20" r="6" fill="#C8C8D0" opacity=".8"/><circle cx="144" cy="10" r="8" fill="#C8C8D0" opacity=".6"/><circle cx="158" cy="4" r="9" fill="#C8C8D0" opacity=".4"/>`)+
 pt("tail",160,108,`<path d="M156 100 L178 92 L172 112 Z" fill="${P.b}" ${SW}/>`)+
 `<path d="M64 112 Q66 88 112 86 Q156 88 164 106 Q160 132 112 134 Q70 132 64 112 Z" fill="${P.b}" ${SW}/><path d="M94 96 Q120 88 146 98 Q136 116 108 114 Q96 110 94 96 Z" fill="${P.d}" ${SW2}/><path d="M104 100 Q120 96 136 102" stroke="${P.dd}" stroke-width="2" fill="none"/><path d="M70 118 Q110 128 158 116" stroke="${P.l}" stroke-width="3" fill="none" opacity=".6"/>`+
 pt("head",74,96,`<path d="M74 100 Q70 82 70 76" stroke="${P.n}" stroke-width="16" stroke-linecap="round"/><circle cx="66" cy="66" r="15" fill="${P.n}" ${SW}/><path d="M64 84 Q74 90 82 84" stroke="#F4F0E4" stroke-width="4" fill="none"/>${E2(62,62,4)}`+
  `<path d="M52 64 L36 66 L52 70 Z" fill="${FMOUTH}"/>`+pt("beak",52,70,`<path d="M52 70 L36 70 Q38 76 52 74 Z" fill="${P.ac}" ${SW2}/>`)+`<path d="M52 62 Q40 60 34 66 L52 68 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M20 140 q6 -4 12 0 M180 140 q6 -4 12 0" stroke="#fff" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="120" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(90,30,6)));
FORM_TITLE["Duck Pond No. 1"]="Chimney Decoy Duck";SM("Duck Pond No. 1","Cover Story","RES","s",0,100,"dodge,def+1","Nothing to see here. Just a pond. With ducks.");
