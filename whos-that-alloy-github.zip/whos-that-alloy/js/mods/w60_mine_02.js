/* ---- Rustvein Mine, 2 ---- */
/* Brindlecombite: signed to a two-year contract with no act. So it is the act: a rabbit coming up out of a top hat. */
addForm("Brindlecombite",{n:"#F4F0E4",a:"#B8302A",rn:"#4A3A3A",rb:"#7A5AA8",ra:"#F2C94C"},"hop",(P,g)=>fShadow(54,104)+
 `<path d="M74 140 Q72 120 76 104 H132 Q136 120 134 140 Z" fill="${FI}" ${SW}/><path d="M78 108 H130" stroke="${P.ac}" stroke-width="7"/><ellipse cx="104" cy="104" rx="38" ry="8" fill="#2A2A3A" ${SW}/><ellipse cx="104" cy="104" rx="28" ry="5" fill="#000"/>`+
 pt("armB",120,96,`<path d="M118 96 Q130 96 132 104" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M118 96 Q130 96 132 104" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.4)+
 `<path d="M84 104 Q82 74 104 70 Q126 74 124 104 Z" fill="${P.n}" ${SW}/><path d="M96 104 Q96 86 104 84 Q112 86 112 104" fill="${P.nll}"/>`+
 pt("armF",88,96,`<path d="M90 96 Q78 96 76 104" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M90 96 Q78 96 76 104" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("head",102,70,`<circle cx="102" cy="58" r="16" fill="${P.n}" ${SW}/><ellipse cx="100" cy="64" rx="5" ry="3.6" fill="${P.nll}"/><path d="M98 62 l2 2 l2 -2 Z" fill="#E89AA8"/>${E2(94,54,4.4,"#C84A5A")}${E2(108,54,4.4,"#C84A5A")}<path d="M88 64 h-10 M88 67 l-9 3 M112 64 h10 M112 67 l9 3" stroke="${P.nd}" stroke-width="1"/>`+
  HMOUTH(97,66,103,P,3)+
  pt("ear",94,44,`<path d="M96 44 Q82 12 90 4 Q100 12 100 44 Z" fill="${P.n}" ${SW2}/><path d="M94 38 Q88 18 91 12" stroke="#E8A0B0" stroke-width="3" fill="none"/>`)+pt("ear",110,44,`<path d="M106 44 Q112 14 124 10 Q126 22 112 46 Z" fill="${P.n}" ${SW2}/><path d="M110 38 Q116 22 121 16" stroke="#E8A0B0" stroke-width="3" fill="none"/>`,.4))+
 fG(g,1,`<path d="M150 136 l14 -20" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M160 122 l4 -6" stroke="#F4F0E4" stroke-width="4" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Brindlecombite"]="Top-Hat Rabbit";SM("Brindlecombite","Ta-Da","STR","s",0,100,"tacc-1,spd+1","Every act needs a moment where the audience gasps. This is that moment.");

/* Capital Audit No. 9: the auditors left with a certificate and mild confusion. A crow in spectacles with a clipboard tucked under one wing. */
addForm("Capital Audit No. 9",{n:"#2A2A3A",a:"#E8DCC0",rn:"#E8E4DA",rb:"#3A6A4A",ra:"#E8412C"},"stand",(P,g)=>fShadow(62,108)+
 pt("tail",142,106,`<path d="M136 100 L172 120 L168 128 L134 112 Z" fill="${P.nd}" ${SW}/><path d="M140 106 L168 122" stroke="${P.ndd}" stroke-width="1.6"/>`)+
 fLeg("legB",112,118,24,4,"#3A3A3A","#3A3A3A",.5)+
 `<path d="M80 104 Q80 74 108 72 Q138 76 142 104 Q134 122 108 122 Q84 120 80 104 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,90,`<path d="M100 84 Q130 80 148 104 Q130 112 104 108 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${116+i*10} ${92+i*3} l10 12" stroke="${P.ndd}" stroke-width="1.6"/>`).join("")}<g transform="rotate(-10 106 100)"><rect x="92" y="94" width="24" height="30" rx="2" fill="#B88A50" ${SW2}/><rect x="96" y="100" width="16" height="20" fill="#F4F0E4"/><path d="M98 104 h12 M98 108 h12 M98 112 h8" stroke="#6A6A7A" stroke-width="1"/><path d="M99 116 l3 3 l6 -7" stroke="${P.ac}" stroke-width="1.6" fill="none"/><rect x="100" y="91" width="8" height="5" rx="1" fill="${P.b}" ${SW2}/></g>`)+
 fLeg("legF",96,118,24,4,"#3A3A3A","#3A3A3A",0)+
 pt("head",84,76,`<circle cx="80" cy="66" r="16" fill="${P.n}" ${SW}/><path d="M66 62 L44 68 L64 70 Z" fill="${FMOUTH}"/>`+pt("beak",64,70,`<path d="M64 70 L46 70 L64 75 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M66 60 L42 67 L66 68 Z" fill="${P.nd}" ${SW2}/>`+
  `${E2(74,62,4.2,"#2A2A3A")}${E2(86,62,4,"#2A2A3A")}<circle cx="74" cy="62" r="6.4" fill="none" stroke="${P.b}" stroke-width="2"/><circle cx="87" cy="62" r="6" fill="none" stroke="${P.b}" stroke-width="2"/><path d="M80 62 h1 M93 62 l4 -2" stroke="${P.b}" stroke-width="2"/>`+
  `<path d="M76 50 q4 -8 10 -6 q-2 4 -4 6" fill="${P.n}" ${SW2}/>`)+
 fG(g,1,`<rect x="22" y="124" width="22" height="16" rx="1" fill="#F4F0E4" ${SW2}/><path d="M26 130 h14 M26 134 h10" stroke="#8A8A9A" stroke-width="1"/>`)+fG(g,2,`<circle cx="124" cy="112" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Capital Audit No. 9"]="Auditor Crow";SM("Capital Audit No. 9","Cross-Check","RES","a",65,100,"crit","Count it twice and the mistake usually shows itself.");

/* Case File Metal: the court case has its own room now. A hermit crab living in a filing-cabinet drawer instead of a shell. */
addForm("Case File Metal",{n:"#D8603A",a:"#E8DCC0",rn:"#3A5A8A",rb:"#E8E0C0",ra:"#5FE0A0"},"crawl",(P,g)=>fShadow(64)+
 `<path d="M98 82 L168 76 L170 132 L100 136 Z" fill="${P.b}" ${SW}/><path d="M98 82 L108 74 L176 70 L168 76 Z" fill="${P.l}" ${SW2}/><path d="M168 76 L176 70 L178 126 L170 132 Z" fill="${P.d}" ${SW2}/>${[[110,86],[124,82],[138,84],[152,80]].map(([x,y])=>`<rect x="${x}" y="${y-12}" width="12" height="16" fill="#F4F0E4" ${SW2} transform="rotate(${(x%7)-3} ${x} ${y})"/>`).join("")}<rect x="118" y="104" width="30" height="10" rx="2" fill="${P.d}" ${SW2}/><rect x="126" y="112" width="14" height="5" rx="2" fill="${P.ll}" ${SW2}/><rect x="122" y="92" width="20" height="8" fill="#F4F0E4" ${SW2}/>`+
 [[96,"legB",.5],[88,"legB",1]].map(([x,c,d],i)=>pt(c,x,124,fOL(`M${x} 124 Q${x-10} ${118-i*4} ${x-16} 140`,P.nd,5),d)).join("")+
 `<path d="M70 126 Q72 104 96 100 Q106 112 100 132 Q84 136 70 126 Z" fill="${P.n}" ${SW}/>`+
 [[84,"legF",0],[76,"legF",.8]].map(([x,c,d],i)=>pt(c,x,128,fOL(`M${x} 128 Q${x-14} ${124+i*2} ${x-20} 144`,P.n,5),d)).join("")+
 pt("claw",70,110,fOL("M76 112 Q64 112 56 100",P.n,6)+`<path d="M34 90 Q36 80 52 82 Q62 86 60 96 Q54 104 40 100 Z" fill="${P.n}" ${SW}/>`+pt("claw2",42,90,`<path d="M42 90 Q34 84 30 88 Q34 94 44 94 Z" fill="${P.nd}" ${SW2}/>`))+
 pt("head",80,104,`<path d="M80 102 L76 80" stroke="${FI}" stroke-width="3"/><path d="M88 102 L90 78" stroke="${FI}" stroke-width="3"/>${E2(76,78,4.6)}${E2(90,76,4.6)}`+pt("ant",84,98,`<path d="M84 98 Q70 70 50 64" stroke="${P.ac}" stroke-width="1.8" fill="none"/><path d="M86 98 Q76 66 66 54" stroke="${P.ac}" stroke-width="1.8" fill="none"/>`)+HMOUTH(70,106,78,P,3))+
 fG(g,1,`<rect x="18" y="128" width="18" height="12" fill="#F4F0E4" ${SW2} transform="rotate(-12 18 128)"/>`)+fG(g,2,`<circle cx="134" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(140,40,6)));
FORM_TITLE["Case File Metal"]="Filing Hermit Crab";SM("Case File Metal","Adjourned","RES","s",0,100,"def+1,ward+1","The matter will be revisited at a later date. Possibly much later.");

/* Checkers Mix: Rennick plays checkers against an empty chair. It isn't empty. A small sheet-ghost in a checked cloth, holding a crowned piece. */
addForm("Checkers Mix",{n:"#F4F0E4",a:"#B8302A",rn:"#2A2A3A",rb:"#C8E8F0",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="26" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",104,120,`<path d="M70 104 Q68 128 74 132 Q80 124 86 134 Q92 124 98 136 Q104 124 110 134 Q116 124 122 132 Q130 126 134 132 Q140 120 138 104 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M70 108 Q66 52 104 44 Q142 52 138 108 Z" fill="${P.n}" ${SW}/>`+
 `<clipPath id="ckC"><path d="M70 108 Q66 52 104 44 Q142 52 138 108 Z"/></clipPath><g clip-path="url(#ckC)" opacity=".85">${[0,1,2,3,4,5].map(r=>[0,1,2,3,4,5].map(c=>(r+c)%2?`<rect x="${68+c*12}" y="${44+r*12}" width="12" height="12" fill="${P.ac}"/>`:"").join("")).join("")}</g><path d="M70 108 Q66 52 104 44 Q142 52 138 108" fill="none" ${SW}/>`+
 pt("head",104,70,`<ellipse cx="94" cy="72" rx="7" ry="9" fill="${FI}"/><ellipse cx="116" cy="72" rx="7" ry="9" fill="${FI}"/><circle cx="92" cy="69" r="2.4" fill="#fff"/><circle cx="114" cy="69" r="2.4" fill="#fff"/><ellipse cx="105" cy="90" rx="5" ry="3" fill="${FI}"/>`+pt("jaw",105,90,`<ellipse cx="105" cy="92" rx="4" ry="3" fill="${FMOUTH}"/>`))+
 pt("armF",72,94,`<path d="M74 92 Q54 94 46 84" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M74 92 Q54 94 46 84" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/><ellipse cx="40" cy="78" rx="11" ry="4" fill="${FI}"/><ellipse cx="40" cy="74" rx="11" ry="4" fill="#2A2A3A" ${SW2}/><path d="M34 72 l2 -6 l4 4 l4 -4 l2 6 Z" fill="#F2C94C" ${SW2}/>`)+
 pt("armB",136,94,`<path d="M134 92 Q152 90 156 100" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M134 92 Q152 90 156 100" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`,.4)+
 fG(g,1,`<ellipse cx="160" cy="140" rx="9" ry="3.4" fill="${P.ac}" ${SW2}/><ellipse cx="174" cy="142" rx="9" ry="3.4" fill="#2A2A3A" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(146,30,6)));
FORM_TITLE["Checkers Mix"]="Checkered Sheet Ghost";SM("Checkers Mix","Double Jump","SCR","a",40,100,"multi:2-2","Jump one piece, then jump another. That's two for the price of one.");

/* Checkmatex: an old mainframe lost every game but printed this recipe. A chess knight on stubby legs, a paper printout trailing from its mouth. */
addForm("Checkmatex",{n:"#2A2A3A",a:"#E8DCC0",rn:"#F4F0E4",rb:"#B88A5A",ra:"#5FE0F0"},"hop",(P,g)=>fShadow(70)+
 fLeg("legB",120,126,18,9,P.nd,P.ndd,.5)+
 `<path d="M76 130 H140 L136 120 H80 Z" fill="${P.b}" ${SW}/><ellipse cx="108" cy="132" rx="36" ry="7" fill="${P.d}" ${SW}/>`+
 `<path d="M86 120 Q84 100 92 92 L80 86 Q70 82 70 72 L78 60 Q82 42 104 36 L112 30 L116 40 Q136 52 132 86 Q130 104 132 120 Z" fill="${P.n}" ${SW}/><path d="M112 40 Q120 46 124 60 Q126 84 122 112" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/>${[0,1,2,3,4].map(i=>`<path d="M${114+i*3} ${42+i*10} l8 -4" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>`).join("")}`+
 fLeg("legF",94,126,18,9,P.n,P.ndd,0)+
 pt("head",86,70,`${E2(94,58,4.4,"#5FE0F0")}<path d="M88 52 l10 -2" stroke="${FI}" stroke-width="2"/><circle cx="74" cy="70" r="2" fill="${FI}"/>`+pt("jaw",78,80,`<path d="M80 80 L70 76 L68 82 Q74 88 88 88 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("tongue",72,80,`<path d="M72 80 Q60 86 62 100 Q50 110 56 126" stroke="${FI}" stroke-width="10" fill="none"/><path d="M72 80 Q60 86 62 100 Q50 110 56 126" stroke="#F4F0E4" stroke-width="8" fill="none"/><path d="M62 92 l-6 0 M58 104 l-6 0 M54 116 l-6 0" stroke="#7A9AC8" stroke-width="1"/>`)+pt("ear",108,38,`<path d="M106 40 L104 22 L116 34 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M28 136 h14 v-6 h-14 Z M30 130 l2 -6 h6 l2 6" fill="#F4F0E4" ${SW2}/>`)+fG(g,2,`<circle cx="108" cy="126" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,36,6)));
FORM_TITLE["Checkmatex"]="Printout Knight";SM("Checkmatex","L-Shaped Leap","SCR","a",75,95,"prio","Two forward and one across. Nothing else on the board moves like it.");

/* Checkup Metal: the dentist still sends checkup reminders. A walking molar on its own roots, toothbrush over one shoulder. */
addForm("Checkup Metal",{n:"#F4F0E4",a:"#5FB8E0",rn:"#E8D8A0",rb:"#3A4A8A",ra:"#E8604A"},"stand",(P,g)=>fShadow(60)+
 pt("legB",116,118,`<path d="M110 114 Q118 130 116 144 L126 144 Q126 128 122 112 Z" fill="${P.nd}" ${SW}/>`,.5)+
 `<path d="M74 66 Q72 46 88 46 Q96 46 100 54 Q104 46 112 46 Q118 46 122 54 Q128 46 136 48 Q148 54 142 76 Q140 100 134 112 Q104 124 80 112 Q72 90 74 66 Z" fill="${P.n}" ${SW}/><path d="M80 66 Q82 54 90 54" stroke="#fff" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M128 96 Q130 84 136 76" stroke="${P.nd}" stroke-width="3" fill="none"/>`+
 pt("legF",88,116,`<path d="M82 110 Q86 128 80 144 L92 144 Q96 128 96 114 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",104,80,`${E2(92,78,5,"#3A6AA8")}${E2(114,78,5,"#3A6AA8")}<ellipse cx="86" cy="90" rx="5" ry="3" fill="#F2A0B0" opacity=".6"/><ellipse cx="122" cy="90" rx="5" ry="3" fill="#F2A0B0" opacity=".6"/>`+HMOUTH(96,92,112,P,5))+
 pt("armB",140,84,fOL("M140 84 Q156 80 158 66",P.n,6),.4)+pt("armF",76,86,fOL("M76 86 Q60 84 58 70",P.n,6)+`<g transform="rotate(-30 58 64)"><rect x="54" y="20" width="7" height="56" rx="3" fill="${P.ac}" ${SW2}/><rect x="52" y="14" width="11" height="14" rx="2" fill="#F4F0E4" ${SW2}/>${[0,1,2,3].map(i=>`<path d="M${53+i*3} 14 v-5" stroke="#fff" stroke-width="2" stroke-linecap="round"/>`).join("")}</g>`)+
 fG(g,1,`<path d="M160 120 q6 -6 12 0 q-6 6 -12 0 Z" fill="#fff" ${SW2}/><path d="M168 108 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="#fff" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(104,26,6)));
FORM_TITLE["Checkup Metal"]="Walking Molar";SM("Checkup Metal","Floss","SCR","a",60,100,"cure","Get in between the gaps. Everything feels better afterwards.");

/* Coaster Metal: the last copy of the recipe was being used as a coaster. A skate (the flat fish), round as a coaster, mug ring on its back. */
addForm("Coaster Metal",{n:"#C8A070",a:"#6A3A20",rn:"#3A5A6A",rb:"#E8D0B0",ra:"#E8412C"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="50" ry="4" fill="#000" opacity=".1"/>`+
 pt("tail",150,104,`<path d="M146 100 Q170 106 192 98" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M146 100 Q170 106 192 98" stroke="${P.nd}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M176 102 l6 -8 l2 8 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("wingB",104,94,`<path d="M104 70 Q150 58 160 98 Q140 104 104 104 Z" fill="${P.nd}" ${SW}/>`,.4)+
 `<path d="M48 98 Q56 60 104 62 Q148 64 152 100 Q130 124 104 122 Q66 124 48 98 Z" fill="${P.n}" ${SW}/>`+
 `<ellipse cx="114" cy="92" rx="22" ry="14" fill="none" stroke="${P.ac}" stroke-width="4" opacity=".55"/><ellipse cx="114" cy="92" rx="22" ry="14" fill="none" stroke="${P.ac}" stroke-width="1.6" opacity=".7" stroke-dasharray="20 8"/>${[[80,82],[136,108],[90,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="${P.nl}"/>`).join("")}`+
 pt("wingF",66,98,`<path d="M66 82 Q34 82 22 108 Q46 116 72 108 Z" fill="${P.n}" ${SW}/><path d="M60 92 Q42 96 32 106" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`)+
 pt("head",62,90,`${E2(66,80,4)}${E2(78,76,3.8)}<path d="M54 98 Q50 104 54 108" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(58,104,68,P,3))+
 fG(g,1,`<path d="M28 60 q6 -6 12 0 M24 70 q4 -4 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="114" cy="92" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(104,36,6)));
FORM_TITLE["Coaster Metal"]="Mug-Ring Skate";SM("Coaster Metal","Ring Stain","SCR","s",0,90,"corrode","Leave something on the table long enough and it leaves its mark.");

/* Cometon: named after a comet whose digits were misread. A comet with a face, its tail made of loose numbers. */
addForm("Cometon",{n:"#E8E0C8",a:"#5FE0F0",rn:"#2A2A4A",rb:"#E8A060",ra:"#E8604A"},"hover",(P,g)=>`<ellipse class="shd" cx="70" cy="150" rx="20" ry="3" fill="#000" opacity=".08"/>`+
 pt("tail",88,80,`<path d="M80 64 Q130 40 194 30 Q150 60 190 64 Q140 76 196 96 Q130 96 82 100 Z" fill="${P.ac}" opacity=".35"/><path d="M84 70 Q130 56 184 46 Q140 70 186 80 Q130 88 84 94 Z" fill="${P.nl}" ${SW2} opacity=".9"/>${["7","1","3","8"].map((t,i)=>`<text x="${120+i*16}" y="${70+(i%2)*10}" font-family="monospace" font-size="${12-i}" font-weight="bold" fill="${P.d}" transform="rotate(-8 ${120+i*16} 70)">${t}</text>`).join("")}`)+
 `<path d="M44 82 Q44 58 70 56 Q94 60 94 82 Q92 106 70 108 Q46 106 44 82 Z" fill="${P.n}" ${SW}/>${[[58,70,4],[80,96,3],[60,96,2.6]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.nd}" ${SW2}/>`).join("")}`+
 pt("head",68,82,`${E2(62,80,5,"#3A6AA8",[-.6,-.2])}${E2(78,78,5,"#3A6AA8",[-.6,-.2])}`+HMOUTH(62,92,74,P,4))+
 fG(g,1,`<path d="M30 40 l2 -6 l2 6 l6 2 l-6 2 l-2 6 l-2 -6 l-6 -2 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="160" cy="120" r="2" fill="${P.ac}"/><circle cx="20" cy="120" r="2" fill="${P.ac}"/>`)+fG(g,3,star(40,24,6)));
FORM_TITLE["Cometon"]="Misread Comet";SM("Cometon","Perihelion","DRP","a",90,85,"recoil:20","The closest pass to the sun is the fastest part of the orbit.");

/* Consonantium: Biscuit the cat walked across the ordering terminal. A cat mid-stride across a keyboard, keys under its paws. */
addForm("Consonantium",{n:"#E89A4A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8B8C8",ra:"#5FE0A0"},"stand",(P,g)=>`<path d="M20 132 L184 132 L190 146 L14 146 Z" fill="#3A3A4A" ${SW}/>${[0,1,2,3,4,5,6,7,8,9].map(i=>`<rect x="${22+i*16}" y="134" width="13" height="8" rx="1.6" fill="#E8E8EE" ${SW2}/>`).join("")}`+
 pt("tail",152,98,fOL("M150 98 Q176 92 176 70 Q176 54 166 52",P.n,8)+`<path d="M170 60 Q176 58 174 54" stroke="${P.nd}" stroke-width="5" fill="none"/>`)+
 fLeg("legB",142,110,22,8,P.nd,P.ac,.5)+fLeg("legB",104,112,20,8,P.nd,P.ac,1.3)+
 `<path d="M84 104 Q84 84 114 84 Q148 84 154 104 Q150 118 118 118 Q88 118 84 104 Z" fill="${P.n}" ${SW}/>${[100,116,132].map(x=>`<path d="M${x} 86 Q${x+4} 96 ${x} 104" stroke="${P.nd}" stroke-width="3" fill="none"/>`).join("")}<path d="M94 112 Q118 120 144 112" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".8"/>`+
 fLeg("legF",134,112,20,8,P.n,P.ac,0)+pt("legF",94,110,fOL("M94 110 L80 118 L74 128",P.n,8)+`<ellipse cx="72" cy="130" rx="6" ry="4" fill="${P.ac}" ${SW2}/><rect x="62" y="133" width="16" height="9" rx="1.6" fill="#B8C8E8" ${SW2}/>`,.8)+
 pt("head",88,90,`<path d="M58 88 Q58 70 76 68 Q94 70 96 88 Q92 102 76 102 Q60 102 58 88 Z" fill="${P.n}" ${SW}/><path d="M60 92 Q66 96 74 94 Q70 102 62 100 Z" fill="${P.ac}"/>${E2(68,84,4.4,"#4AA84A")}${E2(84,82,4.4,"#4AA84A")}<path d="M64 92 l2 2 l2 -2 Z" fill="#E89AA8"/>`+HMOUTH(62,95,70,P,3)+`<path d="M58 92 h-10 M58 95 l-9 3" stroke="${P.nd}" stroke-width="1"/>`+
  pt("ear",66,70,`<path d="M62 72 L64 54 L74 68 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",84,70,`<path d="M80 68 L92 54 L92 72 Z" fill="${P.nd}" ${SW2}/>`,.4))+
 fG(g,1,`<text x="30" y="40" font-family="monospace" font-size="14" font-weight="bold" fill="${FI}">kjjjhh</text>`)+fG(g,2,`<circle cx="118" cy="100" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(118,60,6)));
FORM_TITLE["Consonantium"]="Keyboard Cat";SM("Consonantium","Keysmash","STR","a",15,100,"multi:2-5","Every key at once, and the computer has to make sense of it.");

/* Corinthian Bronze: born when Corinth burned and its treasures ran together. A lying sphinx with a body like a painted amphora. */
addForm("Corinthian Bronze",{n:"#C8703A",a:"#2A1A14",rn:"#E8E4D8",rb:"#2A5A8A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(80)+
 pt("tail",166,120,fOL("M162 122 Q184 126 184 108 Q184 100 178 100",P.n,6)+`<path d="M174 96 Q182 92 184 100 Q178 104 174 96 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M84 128 Q82 98 120 96 Q162 98 168 126 Q164 138 126 138 Q88 138 84 128 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M96 104 Q126 98 160 108" stroke="${P.ac}" stroke-width="3" fill="none"/><path d="M90 124 Q126 132 164 124" stroke="${P.ac}" stroke-width="3" fill="none"/>${[0,1,2,3,4].map(i=>`<path d="M${102+i*12} 110 l4 6 l4 -6 l4 6" stroke="${P.ac}" stroke-width="1.8" fill="none"/>`).join("")}<path d="M108 116 q8 -4 12 2 q6 -6 12 0" stroke="${P.ac}" stroke-width="1.8" fill="none"/>`+
 pt("wingB",130,100,`<path d="M126 102 Q140 70 168 60 Q160 80 166 84 Q150 92 150 102 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${142+i*6} ${92-i*8} l14 -6" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`,.4)+
 [[96,0],[118,.6]].map(([x,d])=>pt("legF",x,128,`<path d="M${x+6} 124 L${x-14} 136 Q${x-20} 142 ${x-10} 144 L${x+10} 140 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",88,100,`<path d="M70 108 Q62 88 66 70 L102 70 Q106 88 98 108 Z" fill="${P.ac}" ${SW}/><path d="M74 108 Q70 84 84 70 Q98 84 94 108 Z" fill="#2A2A3A"/>${[78,84,90].map(x=>`<path d="M${x} 74 V106" stroke="${P.b}" stroke-width="1.4"/>`).join("")}`+
  `<path d="M72 82 Q72 64 86 62 Q100 64 100 82 Q98 98 86 100 Q72 98 72 82 Z" fill="${P.n}" ${SW}/>${E2(80,78,4,"#2A2A3A")}${E2(92,78,4,"#2A2A3A")}<path d="M76 74 h8 M88 74 h8" stroke="${P.ac}" stroke-width="1.6"/>`+HMOUTH(80,90,92,P,3)+`<path d="M86 100 L84 108 L88 108 Z" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<path d="M20 140 q4 -20 12 -20 q8 0 12 20 Z" fill="${P.n}" ${SW2}/><path d="M26 126 h12" stroke="${P.ac}" stroke-width="2"/>`)+fG(g,2,`<circle cx="126" cy="122" r="3" fill="${P.b}" ${SW2}/>`)+fG(g,3,star(140,40,6)));
FORM_TITLE["Corinthian Bronze"]="Amphora Sphinx";SM("Corinthian Bronze","Riddle Of Corinth","RES","a",80,90,"tacc-1@40","Answer it wrong and you are part of the treasure now.");
