/* =============== HAND-DRAWN FORMS, the rest of the register ===============
   A few small conveniences for drawing; every creature below is still drawn by hand. */
const E2=(x,y,r,ir,lk)=>fE(x,y,r,{iris:ir||"#3A2410",look:lk||[-.4,0]});
const BOD=(cx,cy,rx,ry,c,hump)=>`<path d="${fgBody(cx,cy,rx,ry,hump||0)}" fill="${c}" ${SW}/>`;
const OVAL=(cx,cy,rx,ry,c,sw)=>`<path d="${fgEll(cx,cy,rx,ry)}" fill="${c}" ${sw||SW}/>`;
const SHINE=(d,c,w)=>`<path d="${d}" stroke="${c}" stroke-width="${w||3}" fill="none" stroke-linecap="round" opacity=".75"/>`;
/* an open mouth with a jaw that drops: (corner x,y) toward the front tip x */
const HMOUTH=(x0,y,x1,P,h)=>{h=h||5;return`<path d="M${x0} ${y} L${x1} ${y+1} L${x1+2} ${y+h} L${x0} ${y+h} Z" fill="${FMOUTH}"/>`+pt("jaw",x0,y+h*.8,`<path d="M${x0} ${y+h*.6} Q${(x0+x1)/2} ${y+h*2.2} ${x1} ${y+h*.5} Q${(x0+x1)/2} ${y+h*1.3} ${x0} ${y+h*1.1} Z" fill="${P.nd}" ${SW2}/>`)};
const GRADE=(g,P,x,y)=>fG(g,1,`<path d="M${x-8} ${y} l-6 -3 M${x-8} ${y+6} l-7 0" stroke="${P.l}" stroke-width="2" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="${x+30}" cy="${y-30}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(x+50,Math.max(16,y-90),6));
