/* ---- the same off-screen rule for everything standing on the map ----
   Map tiles already pause their animations when they're outside the camera. Lanterns, bunting, bats, haunts, shadow people and
   every other piece placed ON the map didn't, so hundreds of flickers nobody could see were being redrawn every frame.
   Anything outside the view (plus a margin) now holds still and carries on the instant it scrolls back in. Nothing on screen changes. */
const OFFV={tm:0,last:0,prev:null};
/* worked out from map squares, using where the camera is heading AND where it was, so nothing pops in during the camera's glide */
function offvSync(){const w=$("#world");if(!w||S.phase!=="explore"||!EXP.W)return;OFFV.last=performance.now();const v=chunkView();if(!v)return;
  const p=OFFV.prev||v,M=2.5,x0=Math.min(p[0],v[0])-M,y0=Math.min(p[1],v[1])-M,x1=Math.max(p[2],v[2])+M,y1=Math.max(p[3],v[3])+M;OFFV.prev=v;
  const W=EXP.W,H=EXP.H;
  for(const el of w.children){if(el.id==="map"||el.id==="player"||el.tagName==="CANVAS"||el.tagName==="IMG")continue;const st=el.style;
    if(!st.left.endsWith("%")||!st.top.endsWith("%")){if(el.classList.contains("offv"))el.classList.remove("offv");continue}
    const ex=parseFloat(st.left)/100*W,ey=parseFloat(st.top)/100*H,ew=st.width.endsWith("%")?parseFloat(st.width)/100*W:1,eh=st.height.endsWith("%")?parseFloat(st.height)/100*H:1;
    /* generous: tall things and things that overhang their square still count as on screen */
    const off=ex+ew+1<x0||ex-1>x1||ey+eh+1<y0||ey-2>y1;
    if(off!==el.classList.contains("offv")){el.classList.toggle("offv",off);if(el._smil!==0){if(el._smil===undefined)el._smil=el.querySelector("animate,animateTransform,animateMotion")?1:0;
      if(el._smil)el.querySelectorAll("svg").forEach(s=>off?s.pauseAnimations&&s.pauseAnimations():s.unpauseAnimations&&s.unpauseAnimations())}}}
  clearTimeout(OFFV.pt);OFFV.pt=setTimeout(()=>{OFFV.prev=null},400)}
{const _c=cam;cam=function(instant){_c(instant);clearTimeout(OFFV.tm);offvSync();/* once the camera glide has finished */OFFV.tm=setTimeout(offvSync,260)}}
{const _se=startExplore;startExplore=function(){OFFV.prev=null;_se();offvSync();setTimeout(offvSync,50)}}
/* things that walk about (haunts, shadow people, the stalker) get re-checked a few times a second */
setInterval(()=>{if(!document.hidden&&performance.now()-OFFV.last>380)offvSync()},400);
/* ---- Lantern Night dusk, same light, drawn smarter ----
   The dusk was one map-sized sheet holding every lamp's glow AND the light around you, so each step repainted the whole map's worth of
   gradients. The lamps now sit on a sheet that is painted once; your own light is a small separate glow that just slides along with you.
   Both are blended together exactly as before, so the picture is identical. */
lntDusk=function(){let n=$("#lnt-dusk");const z=EXP.zone&&EXP.zone.cls;if(!lntOn()||!z||!DUSK[z]||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on)){if(n)n.remove();return}
  const wr=$("#mapwrap"),wd=$("#world");if(!wr||!wd)return;
  if(!n||n.parentNode!==wr){if(n)n.remove();n=document.createElement("div");n.id="lnt-dusk";n.className="dk-out";n.innerHTML='<div class="dk-world"><i class="dk-base"></i><i class="dk-me"></i></div>';wd.after(n)}const W=EXP.W,H=EXP.H,L=[],lit=lntLit();
  const at=(x,y,r,c)=>L.push(`radial-gradient(circle calc(var(--tp,40px)*${r}) at ${((x+.5)/W*100).toFixed(2)}% ${((y+.5)/H*100).toFixed(2)}%,${c} 0,${c.replace(/[\d.]+\)$/,"0)")} 100%)`);
  (ZD[z]||[]).forEach(o=>{const key=z+":"+o.x+","+o.y;if(o.light){if(lit.has(key))at(o.x,o.y-.3,2.2,"rgba(255,232,190,1)")}else if(!o.dark)at(o.x+((o.w||1)-1)/2,o.y,1.3,"rgba(255,226,186,.85)")});
  (LNT_DECOR[z]||[]).forEach(([k,x,y,s])=>{if(k==="trail"&&lntTrail()>s)at(x,y-1,2.4,"rgba(255,232,190,1)")});
  (SHOW[z]||[]).forEach(o=>at(o.x,o.y-1.2,2.8,o.c||"rgba(255,226,180,1)"));
  document.querySelectorAll("#world .dress.dr-g").forEach(e=>{const x=parseFloat(e.style.left)/100*W,y=parseFloat(e.style.top)/100*H,w=parseFloat(e.style.width)/100*W;at(x+w/2-.5,y+.4,Math.max(1.4,w*.55),"rgba(255,226,180,.8)")});
  document.querySelectorAll("#world .dress.dr-t").forEach((e,i)=>{if(i%2)return;const x=parseFloat(e.style.left)/100*W,y=parseFloat(e.style.top)/100*H;at(x,y-.2,1.1,"rgba(255,220,170,.75)")});
  const bg=`${L.length?L.join(",")+",":""}${DUSK[z]}`,b=n.querySelector(".dk-base");if(b.style.background!==bg)b.style.background=bg;lntDuskPlayer()};
/* the dusk sits over the camera's view only (blending a whole map's worth of dusk every frame was the single most expensive thing on screen);
   inside it, the dusk sheet moves with the map exactly as the map moves, glide and all */
function duskFollow(){const n=$("#lnt-dusk"),w=$("#world");if(!n||!w)return;const d=n.querySelector(".dk-world");if(!d)return;
  const ww=w.offsetWidth+"px",wh=w.offsetHeight+"px";if(d.style.width!==ww)d.style.width=ww;if(d.style.height!==wh)d.style.height=wh;const tp=w.style.getPropertyValue("--tp");if(tp&&d.style.getPropertyValue("--tp")!==tp)d.style.setProperty("--tp",tp);
  const tr=w.classList.contains("snap")?"none":getComputedStyle(w).transition;if(d.style.transition!==tr)d.style.transition=tr;if(d.style.transform!==w.style.transform)d.style.transform=w.style.transform}
lntDuskPlayer=function(){const n=$("#lnt-dusk"),w=$("#world");if(!n||!w||!EXP.W)return;duskFollow();const me=n.querySelector(".dk-me");if(!me)return;const tp=w.offsetWidth/EXP.W,r=tp*2.2;
  me.style.width=me.style.height=(2*r)+"px";me.style.transform=`translate(${((EXP.x+.5)*tp-r).toFixed(1)}px,${((EXP.y+.5)*tp-r).toFixed(1)}px)`};
{const _c=cam;cam=function(i){_c(i);lntDuskPlayer()}}
addEventListener("resize",()=>lntDuskPlayer());

/* Hollowmere's night, split the same way: the lamps' pools on one sheet painted once (repainted only when a lamp gutters or is lit), your light sliding over it */
lntNight=function(){let n=$("#lnt-night");if(!inHollow()){if(n)n.remove();return}if(!n){n=document.createElement("div");n.id="lnt-night";n.innerHTML='<i class="dk-base"></i><i class="dk-me"></i>';$("#world").appendChild(n)}
  const W=EXP.W,H=EXP.H,lit=lntLit(),L=[];let li=0;const at=(x,y,r,c)=>{const dim=li++===HM_DIM;if(dim){r*=.45;c=c.replace(/,[\d.]+\)$/,",.5)")}L.push(`radial-gradient(circle calc(var(--tp,40px)*${r}) at ${((x+.5)/W*100).toFixed(2)}% ${((y+.5)/H*100).toFixed(2)}%,${c} 0,${c.replace(/[\d.]+\)$/,"0)")} 100%)`)};
  at(17,11.6,4.2,"rgba(255,206,140,1)");[[17,7],[12,11],[23,11]].forEach(([x,y])=>at(x,y-.6,2.1,"rgba(255,220,160,1)"));
  HM_COTS.forEach(([x,y,v])=>{const dx=[3,4,3,5][v],wx=dx<4?5.5:1.5;[wx,wx+1.2].forEach(o=>at(x+o,y+1.8,1.4,"rgba(255,206,140,.95)"));at(x+dx+1.6,y+2.6,1,"rgba(255,190,110,.9)")});
  (LNT_DECOR["z-hollow"]||[]).forEach(([k,x,y,s])=>{const key="z-hollow:"+x+","+y;if(k==="neep"&&lit.has(key)&&!lntSnuffed(key))at(x,y,1.3,"rgba(255,190,110,.95)");if(k==="trail"&&lntTrail()>s)at(x,y-1,2,"rgba(255,220,160,1)");if(k==="cand"&&!new Set(store.get("wta_lnt_cand",[])).has(key))at(x,y,.9,"rgba(255,206,140,.9)");if(k==="wisp")at(x,y,1.1,"rgba(170,255,170,.7)");if(k==="pot")at(x,y,1,"rgba(170,255,140,.7)");if(k==="strg"&&new Set(store.get("wta_lnt_str",[])).has(key))at(x+1.5,y+.6,1.6,"rgba(255,190,120,.9)")});
  at(36,22,1.4,"rgba(200,170,255,.8)");if(typeof hmXLights==="function")hmXLights().forEach(q=>at(...q));
  {const bg=`${L.join(",")},#2E3056`,b=n.querySelector(".dk-base");if(b.style.background!==bg)b.style.background=bg}lntPlayerLight()};
lntPlayerLight=function(){const n=$("#lnt-night"),w=$("#world");if(!n||!w||!EXP.W)return;const me=n.querySelector(".dk-me");if(!me)return;const tp=w.offsetWidth/EXP.W,r=tp*1.7;
  me.style.width=me.style.height=(2*r)+"px";me.style.transform=`translate(${((EXP.x+.5)*tp-r).toFixed(1)}px,${((EXP.y+.5)*tp-r).toFixed(1)}px)`};
{const _c=cam;cam=function(i){_c(i);lntPlayerLight()}}
addEventListener("resize",()=>lntPlayerLight());
/* ---- Hollowmere's cottage windows ----
   The windows' glow changed their fill colour, which made the browser redraw the whole cottage every frame. Now the same three colours
   sit stacked in the window and fade into one another on the same timing, so the window goes through exactly the same colours. */
if(typeof hmCottage==="function"){const _hc=hmCottage;hmCottage=function(v){const s=_hc.apply(this,arguments);if(typeof s!=="string")return s;
  return s.replace(/<rect x="([\d.-]+)" y="([\d.-]+)" width="([\d.]+)" height="([\d.]+)" fill="#FFC870" class="hm-win" stroke="([^"]+)" stroke-width="([\d.]+)"\/>/g,(m,x,y,w,h,st,sw)=>
    `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#FFC870"/><rect class="hm-winA" x="${x}" y="${y}" width="${w}" height="${h}" fill="#FFB24A"/><rect class="hm-winB" x="${x}" y="${y}" width="${w}" height="${h}" fill="#FFD890"/><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="none" stroke="${st}" stroke-width="${sw}"/>`)}}
/* ---- shadow people glide on the graphics card ----
   They used to slide by animating their map position, which re-lays-out the page every frame they move. They now jump to the new square
   instantly and are drawn sliding there from where they were, same 1.1 s ease, picked up smoothly even if they change course mid-step. */
if(typeof shdMove==="function"){shdMove=function(s,x,y,inst){const d=s.el,w=$("#world");const ox=s.x,oy=s.y;s.x=x;s.y=y;
  let cx=0,cy=0;if(!inst&&w&&EXP.W&&ox!=null&&d.isConnected){const tp=w.offsetWidth/EXP.W,cur=(getComputedStyle(d).translate||"").split(" ");
    cx=(ox-x)*tp+(parseFloat(cur[0])||0);cy=(oy-y)*tp+(parseFloat(cur[1])||0)}
  d.style.width=(100/EXP.W)+"%";d.style.height=(250/EXP.H)+"%";d.style.left=(x/EXP.W*100)+"%";d.style.top=((y-1.5)/EXP.H*100)+"%";d.style.zIndex=String(11+2*y);
  d.style.transition="opacity 1s,filter 1s,transform 1s,translate 0s";d.style.translate=inst?"0px 0px":`${cx.toFixed(1)}px ${cy.toFixed(1)}px`;void d.offsetWidth;
  d.style.transition="";if(!inst)d.style.translate="0px 0px"}}
/* the sparkle-and-water canvas rests while an Assay covers the map */
{const _sd=spkDraw;spkDraw=function(now){if(typeof AS!=="undefined"&&AS.on&&S.phase==="explore"){requestAnimationFrame(spkDraw);return}return _sd(now)}}
/* lit neep faces flickered by changing their fill colour (a repaint every frame). The same three colours are now stacked and faded
   into each other on the same timing; the cauldron's brew brightening is the same trick with a pre-brightened copy. */
function fxBright(hex,k){const n=parseInt(hex.slice(1),16),c=[(n>>16)&255,(n>>8)&255,n&255].map(v=>Math.min(255,Math.round(v*k)));return"#"+c.map(v=>v.toString(16).padStart(2,"0")).join("")}
function fxPass(root){if(!root)return;
  root.querySelectorAll(".lnt.neep.lit .lnt-face:not([data-fx])").forEach(g=>{g.dataset.fx=1;g.classList.add("fxd");
    [["#FFA62A","lnt-faceA"],["#FFD86A","lnt-faceB"]].forEach(([c,k])=>{const q=g.cloneNode(true);q.removeAttribute("data-fx");q.setAttribute("class",k);q.setAttribute("fill",c);if(q.hasAttribute("stroke"))q.setAttribute("stroke",c);
      q.querySelectorAll("[fill]").forEach(e=>{if(e.getAttribute("fill")!=="none")e.setAttribute("fill",c)});g.parentNode.insertBefore(q,(k==="lnt-faceA"?g:g.nextSibling).nextSibling)})});
  root.querySelectorAll(".lnt.pot .lnt-brew:not([data-fx])").forEach(e=>{e.dataset.fx=1;e.classList.add("fxd");const c=e.getAttribute("fill")||"";if(!/^#[0-9a-f]{6}$/i.test(c))return;
    const q=e.cloneNode(true);q.removeAttribute("data-fx");q.setAttribute("class","lnt-brewG");q.setAttribute("fill",fxBright(c,1.35));e.after(q)})}
/* run when the map is laid out, and whenever a neep is lit or a cauldron changes (both go through lntFlash) */
{const _wp=worldPlace;worldPlace=function(){_wp();fxPass($("#world"))}}
if(typeof lntFlash==="function"){const _lf=lntFlash;lntFlash=function(el,cls,ms){_lf(el,cls,ms);fxPass(el&&el.parentNode||$("#world"))}}
/* the page knows an Assay is up by a class set when it opens and cleared the moment its screen is hidden again */
{const _as=asStart;asStart=function(foe,done){const r=_as(foe,done);const el=$("#assay");if(el&&!el.hidden&&!AS.sim){document.body.classList.add("as-open");
  if(!el.__obs){el.__obs=new MutationObserver(()=>{document.body.classList.toggle("as-open",!el.hidden)});el.__obs.observe(el,{attributes:true,attributeFilter:["hidden"]})}}return r}}
/* ---- the void hole's stars and spiral, without the clipping ----
   They used to spin freely and be cut off at the hole's ragged edge, which makes the browser redraw the whole hole every frame.
   Now they orbit inside the hole's own oval (a circle squashed to the hole's shape), so nothing ever needs cutting off: the same
   stars, the same spiral arms, the same speeds, and the graphics card turns them on its own. */
voidSVG=function(w,h,id,edge){const cx=w/2,cy=h/2+2,rx=w/2-10,ry=h/2-9;let st="";const R=mulberry(id.length*31+7);
  for(let i=0;i<34;i++){const a=R()*6.283,r=Math.sqrt(R());st+=`<circle cx="${(Math.cos(a)*.8*r).toFixed(3)}" cy="${(Math.sin(a)*.8*r).toFixed(3)}" r="${((.4+R()*1.1)/rx).toFixed(4)}" fill="#E8E0FF" opacity="${(.3+R()*.7).toFixed(2)}"/>`}
  const lip=Array.from({length:22},(_,i)=>{const a=i/22*6.283,k=.86+R()*.28;return`${(cx+Math.cos(a)*rx*k).toFixed(1)},${(cy+Math.sin(a)*ry*k).toFixed(1)}`}).join(" ");
  return`<defs><radialGradient id="${id}g" cx=".5" cy=".55" r=".55"><stop offset="0" stop-color="#000"/><stop offset=".55" stop-color="#0A0618"/><stop offset=".85" stop-color="#241640"/><stop offset="1" stop-color="#3A2660"/></radialGradient></defs>
   <polygon points="${lip}" fill="url(#${id}g)"/>
   <g transform="translate(${cx} ${cy}) scale(${rx} ${ry})"><g class="hole-stars" style="transform-origin:0 0">${st}</g>
    <g class="hole-spiral" style="transform-origin:0 0">${[0,1,2].map(i=>`<path d="M0 0 q.3 -.5 .7 -.2" transform="rotate(${i*120})" stroke="#8A6AE8" stroke-width="1.4" vector-effect="non-scaling-stroke" fill="none" opacity=".35"/>`).join("")}</g></g>
   <circle class="hole-deep" cx="${cx}" cy="${cy+2}" r="3" fill="#FFB43A" opacity=".6"/>
   <polygon points="${lip}" fill="none" stroke="${edge}" stroke-width="2.4" stroke-linejoin="round"/>`};
/* the tutorial's practice sample is never a free registry: if it's a threat, winning the practice round doesn't register it */
{const _w=win;win=function(){const r=S.r,n=r&&r.a&&r.a.name,tut=typeof TUT!=="undefined"&&TUT.on&&r&&r.a&&r.a.threat,had=n&&S.caught.has(n),dx=n&&S.dex[n]?JSON.stringify(S.dex[n]):null;_w();
  if(tut&&!had){S.caught.delete(n);store.set("wta_caught2",[...S.caught]);if(dx)S.dex[n]=JSON.parse(dx);else delete S.dex[n];if(typeof saveDex==="function")saveDex()}}}
