/* ---- Rustvein Mine, 5 ---- */
/* Gnomonite: engraved under the gnomon, where only an ant could read it. A big ant carrying the sundial's gnomon on its back. */
addForm("Gnomonite",{n:"#8A3A2A",a:"#E8C060",rn:"#2A2A3A",rb:"#5A8A4A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 `<path d="M60 102 L150 70 L150 104 Z" fill="${P.b}" ${SW}/><path d="M66 102 L146 74" stroke="${P.ll}" stroke-width="2"/>${[0,1,2,3].map(i=>`<path d="M${84+i*16} ${96-i*5.6} l2 6" stroke="${P.dd}" stroke-width="1.6"/>`).join("")}<text x="112" y="98" font-size="5" fill="${P.dd}" transform="rotate(-19 112 98)">FORMULA</text>`+
 [0,1,2].map(i=>pt("legB",112+i*2,118,`<path d="M${112+i*2} 118 L${124+i*14} ${104+i*2} L${132+i*14} 142" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${112+i*2} 118 L${124+i*14} ${104+i*2} L${132+i*14} 142" stroke="${P.nd}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>`,i*.3)).join("")+
 `<ellipse cx="148" cy="118" rx="24" ry="17" fill="${P.n}" ${SW}/><path d="M132 112 Q148 106 166 114" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/><ellipse cx="112" cy="116" rx="11" ry="9" fill="${P.n}" ${SW}/>`+
 [0,1,2].map(i=>pt("legF",106-i*2,120,`<path d="M${108-i*2} 120 L${92-i*12} ${104+i*2} L${80-i*12} 142" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${108-i*2} 120 L${92-i*12} ${104+i*2} L${80-i*12} 142" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>`,i*.3+.15)).join("")+
 pt("head",88,112,`<circle cx="80" cy="110" r="14" fill="${P.n}" ${SW}/>${E2(76,106,4.6,"#1A1A1A")}`+pt("jaw",68,118,`<path d="M70 116 Q58 118 56 124 Q64 124 70 120 Z" fill="${P.nd}" ${SW2}/><path d="M72 120 Q62 128 64 132 Q70 128 74 122 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ant",80,98,`<path d="M80 98 L74 80 L60 74" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M84 98 L86 78 L76 66" stroke="${FI}" stroke-width="2.4" fill="none"/>`))+
 fG(g,1,`<circle cx="30" cy="40" r="10" fill="none" stroke="${P.ac}" stroke-width="2"/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${30+Math.cos(i*.785)*13} ${40+Math.sin(i*.785)*13} l${Math.cos(i*.785)*5} ${Math.sin(i*.785)*5}" stroke="${P.ac}" stroke-width="2"/>`).join("")}`)+fG(g,2,`<circle cx="148" cy="118" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Gnomonite"]="Sundial Ant";SM("Gnomonite","Noon Shadow","DRP","a",70,100,"","At midday the shadow is shortest, and nothing is hidden.");

/* Grievite: worked out while waiting in a very long line. A heron standing in the queue on one leg, ticket in its beak. */
addForm("Grievite",{n:"#8A9AB0",a:"#2A2A3A",rn:"#E8D8C8",rb:"#7A4A3A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,110)+
 `<path d="M150 30 V146 M178 30 V146" stroke="#C8A040" stroke-width="4"/><path d="M150 50 Q164 56 178 50" stroke="#B8302A" stroke-width="5" fill="none"/><circle cx="150" cy="30" r="4" fill="#C8A040" ${SW2}/><circle cx="178" cy="30" r="4" fill="#C8A040" ${SW2}/>`+
 pt("legB",108,104,`<path d="M108 104 L112 120 L100 118" stroke="${FI}" stroke-width="4.4" fill="none" stroke-linejoin="round"/><path d="M108 104 L112 120 L100 118" stroke="#C8A060" stroke-width="2.4" fill="none" stroke-linejoin="round"/>`,.5)+
 pt("tail",128,96,`<path d="M124 92 L146 106 L140 110 L122 100 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M84 90 Q88 70 110 70 Q130 74 132 96 Q124 108 106 106 Q88 104 84 90 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${100+i*7} ${80+i*2} q4 10 0 22" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("legF",104,104,`<path d="M104 104 L104 144" stroke="${FI}" stroke-width="4.4"/><path d="M104 104 L104 144" stroke="#C8A060" stroke-width="2.4"/><path d="M92 144 h22 M104 144 l-8 -4" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 pt("head",88,74,`<path d="M90 80 Q76 70 82 54 Q88 40 80 30" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M90 80 Q76 70 82 54 Q88 40 80 30" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`+
  `<ellipse cx="78" cy="26" rx="10" ry="8" fill="${P.n}" ${SW}/><path d="M76 20 Q90 14 98 18" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${E2(74,24,3.2,"#E8C040")}<path d="M68 24 L36 26 L68 28 Z" fill="${FMOUTH}"/>`+pt("beak",68,28,`<path d="M68 28 L38 28 L68 31 Z" fill="#E8B040" ${SW2}/>`)+`<path d="M68 22 L34 26 L68 26 Z" fill="#E8B040" ${SW2}/><g transform="rotate(10 44 32)"><rect x="40" y="28" width="16" height="11" fill="#F4E0A0" ${SW2}/><text x="42" y="37" font-size="7" font-weight="bold" fill="${FI}">87</text></g>`)+
 fG(g,1,`<rect x="20" y="40" width="24" height="16" rx="2" fill="${FI}"/><text x="23" y="52" font-size="10" font-weight="bold" fill="#E8412C" font-family="monospace">12</text>`)+fG(g,2,`<circle cx="108" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(120,24,6)));
FORM_TITLE["Grievite"]="Queueing Heron";SM("Grievite","Take A Number","RES","s",0,100,"def+1,ward+1","You'll be seen eventually. Probably.");


/* Headlamp Blend: finished by headlamp in a thunderstorm. A mole wearing a miner's headlamp, counting between the rumbles. */
addForm("Headlamp Blend",{n:"#3A3A44",a:"#E8A0A8",rn:"#E8D8C0",rb:"#6A4A2A",ra:"#5FE0F0"},"crawl",(P,g)=>`<path d="M14 140 Q50 128 80 140 L80 150 H14 Z" fill="#8A6A4A" ${SW}/>`+fShadow(64,104)+
 `<path d="M44 76 L4 54 L4 108 Z" fill="#F2E080" opacity=".4"/>`+
 pt("tail",156,122,`<path d="M152 122 l14 2" stroke="${P.ac}" stroke-width="4" stroke-linecap="round"/>`)+
 [[138,.5],[100,1.2]].map(([x,d])=>pt("legB",x,132,`<path d="M${x-6} 128 l-4 14 h14 l-2 -14 Z" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 `<path d="M70 118 Q72 88 112 86 Q152 88 158 118 Q154 138 112 138 Q74 138 70 118 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${90+i*14} ${94+i%2*4} q4 4 8 0" stroke="${P.nl}" stroke-width="1.4" fill="none" opacity=".6"/>`).join("")}`+
 pt("legF",82,128,`<path d="M84 124 Q66 128 60 140 Q70 146 88 138 Z" fill="${P.ac}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${62+i*4} ${140+i%2} l-2 4" stroke="${FI}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",74,110,`<path d="M42 106 Q46 88 66 88 Q82 90 82 106 Q78 120 62 120 Z" fill="${P.n}" ${SW}/><path d="M42 106 Q34 108 30 112 Q36 118 46 114" fill="${P.ac}" ${SW2}/><circle cx="31" cy="112" r="3" fill="#C85A6A"/>`+HMOUTH(40,116,48,P,2.4)+`<path d="M58 100 q3 -2 6 0" stroke="${FI}" stroke-width="2" fill="none"/>`+
  `<path d="M50 86 Q64 76 80 86" stroke="#E8C040" stroke-width="5" fill="none"/><rect x="44" y="76" width="12" height="12" rx="3" fill="${P.b}" ${SW2}/><circle cx="44" cy="82" r="4.4" fill="#FFF8C0" ${SW2}/>`)+
 fG(g,1,`<text x="156" y="44" font-family="monospace" font-size="16" font-weight="bold" fill="${P.ac}">3..</text><path d="M178 20 l-8 12 h6 l-6 12" stroke="#F2C94C" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="114" cy="112" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Headlamp Blend"]="Headlamp Mole";SM("Headlamp Blend","Count The Seconds","DRP","a",70,100,"irr@30","One... two... three... and then the thunder.");

/* Hedgehog Blend: five sleepy hedgehogs hibernated in the packing straw. One hedgehog, waking up in a nest of straw, still yawning. */
addForm("Hedgehog Blend",{n:"#8A6A4A",a:"#E8D8B8",rn:"#3A3A4A",rb:"#C8A0D0",ra:"#E8604A"},"crawl",(P,g)=>`<ellipse cx="104" cy="138" rx="66" ry="12" fill="#E8C870" ${SW}/>${[0,1,2,3,4,5,6,7,8,9,10].map(i=>`<path d="M${44+i*12} ${136+i%3*2} l${i%2?10:-10} -6" stroke="#B8902A" stroke-width="2" stroke-linecap="round"/>`).join("")}`+
 pt("sway",116,104,`<path d="M74 120 Q70 80 112 72 Q154 76 160 116 Q150 132 112 132 Q80 132 74 120 Z" fill="${P.n}" ${SW}/>${Array.from({length:22},(_,i)=>{const a=-2.9+i*.13,x=114+Math.cos(a)*44,y=118+Math.sin(a)*44;return`<path d="M${x-Math.cos(a)*10} ${y-Math.sin(a)*10} L${x+Math.cos(a)*6} ${y+Math.sin(a)*6}" stroke="${P.nd}" stroke-width="3" stroke-linecap="round"/>`}).join("")}`)+
 pt("legF",88,130,`<ellipse cx="86" cy="134" rx="7" ry="4" fill="${P.ac}" ${SW2}/>`)+
 pt("head",76,112,`<path d="M40 116 Q44 98 66 96 Q84 98 86 114 Q80 128 62 128 Q46 128 40 116 Z" fill="${P.ac}" ${SW}/><circle cx="40" cy="116" r="3.4" fill="${FI}"/><path d="M58 106 q4 2 8 0" stroke="${FI}" stroke-width="2" fill="none"/><ellipse cx="70" cy="114" rx="4" ry="2.4" fill="#F2A0B0" opacity=".6"/>`+
  `<path d="M46 120 L58 118 L56 124 L48 124 Z" fill="${FMOUTH}"/>`+pt("jaw",56,122,`<path d="M58 121 Q52 132 46 122 Q52 126 58 125 Z" fill="${P.ac}" ${SW2}/>`)+pt("ear",74,98,`<circle cx="74" cy="98" r="4" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<text x="24" y="70" font-family="Georgia,serif" font-size="14" font-weight="bold" fill="${P.ac}">z</text><text x="34" y="58" font-family="Georgia,serif" font-size="11" font-weight="bold" fill="${P.ac}">z</text>`)+fG(g,2,`<circle cx="114" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Hedgehog Blend"]="Straw-Nest Hedgehog";SM("Hedgehog Blend","Curl Up","RES","s",0,100,"def+2","Roll up tight and let the winter go past.");

/* Holiday Shift Metal: one mixer worked alone on a public holiday without noticing. A badger in a hard hat with a lunch tin, alone at work. */
addForm("Holiday Shift Metal",{n:"#5A5A64",a:"#F4F0E4",rn:"#C8B8A0",rb:"#3A5A3A",ra:"#E8412C"},"stand",(P,g)=>fShadow(70)+
 pt("tail",160,106,`<path d="M158 104 l12 4 l-10 6 Z" fill="${P.n}" ${SW2}/>`)+
 fLeg("legB",148,118,24,10,P.nd,FI,.5)+fLeg("legB",112,120,22,10,P.nd,FI,1.3)+
 `<path d="M86 112 Q84 86 122 84 Q160 86 164 110 Q160 128 124 128 Q90 128 86 112 Z" fill="${P.n}" ${SW}/><path d="M96 90 Q122 80 156 92" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".5"/>`+
 fLeg("legF",138,120,22,10,P.nd,FI,0)+
 pt("armF",98,112,fOL("M100 112 L88 126",FI,10)+`<rect x="70" y="124" width="28" height="18" rx="3" fill="#C83A2A" ${SW}/><path d="M76 124 Q84 114 92 124" stroke="${FI}" stroke-width="3" fill="none"/><path d="M72 132 h24" stroke="#8A1A1A" stroke-width="2"/>`)+
 pt("head",88,96,`<path d="M50 104 Q50 82 74 80 Q96 82 98 100 Q94 114 74 114 Q56 114 50 104 Z" fill="${P.ac}" ${SW}/><path d="M56 92 Q72 86 96 96 L96 104 Q76 96 58 100 Z" fill="${FI}"/><path d="M60 82 Q76 78 96 88 L96 92 Q76 86 62 88 Z" fill="${FI}"/><ellipse cx="50" cy="104" rx="4" ry="3.4" fill="${FI}"/>${E2(72,96,3.6,"#3A2410")}`+HMOUTH(54,108,62,P,3)+
  pt("ear",86,82,`<circle cx="88" cy="82" r="5" fill="${P.ac}" ${SW2}/>`)+`<path d="M58 80 Q60 62 78 60 Q96 62 98 80 Z" fill="#F2C94C" ${SW}/><path d="M54 80 H102" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M54 80 H102" stroke="#F2C94C" stroke-width="2.4" stroke-linecap="round"/><path d="M78 60 V78" stroke="#C89A20" stroke-width="3"/>`)+
 fG(g,1,`<rect x="160" y="30" width="26" height="22" rx="2" fill="#F4F0E4" ${SW2}/><rect x="160" y="30" width="26" height="7" fill="#C83A3A"/><text x="165" y="49" font-size="11" font-weight="bold" fill="#C83A3A">25</text>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Holiday Shift Metal"]="Lone-Shift Badger";SM("Holiday Shift Metal","Overtime","STR","a",60,100,"atk+1","Nobody else is here, so it might as well get on with it.");

/* Housewarming Metal: couples hide a sample in the new house for the first guest to find. A little cottage that walks, door for a mouth, a hiding sample in its attic. */
addForm("Housewarming Metal",{n:"#E8D8B8",a:"#B8402A",rn:"#3A4A5A",rb:"#7AA8D8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(58)+
 pt("legB",124,128,`<path d="M122 126 L126 144 H136" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M122 126 L126 144 H136" stroke="${P.nd}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 `<rect x="70" y="70" width="70" height="60" fill="${P.n}" ${SW}/>${[78,90,102,114,126].map((y,i)=>`<path d="M70 ${y} H140" stroke="${P.nd}" stroke-width="1.2" opacity=".5"/>`).join("")}`+
 `<rect x="118" y="34" width="12" height="26" fill="${P.ac}" ${SW2}/>`+pt("slow",124,30,`<circle cx="126" cy="24" r="5" fill="#C8C8D0" opacity=".7"/><circle cx="134" cy="14" r="7" fill="#C8C8D0" opacity=".5"/>`)+
 pt("ear",104,60,`<path d="M62 74 L105 36 L148 74 Z" fill="${P.ac}" ${SW}/>${[0,1,2].map(i=>`<path d="M${74+i*6} ${66-i*8} H${136-i*6}" stroke="#8A2A1A" stroke-width="1.6"/>`).join("")}<circle cx="105" cy="58" r="6" fill="#F4E8C0" ${SW2}/><circle cx="105" cy="58" r="2.4" fill="${P.b}"/>`)+
 pt("head",104,90,`<rect x="78" y="80" width="18" height="16" fill="#C8E8F8" ${SW2}/><rect x="114" y="80" width="18" height="16" fill="#C8E8F8" ${SW2}/>${E2(87,88,4.6)}${E2(123,88,4.6)}<path d="M78 80 L74 76 M96 80 L100 76 M114 80 L110 76 M132 80 L136 76" stroke="${FI}" stroke-width="1.6" opacity="0"/>`)+
 `<path d="M96 130 V108 Q105 100 114 108 V130 Z" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",96,118,`<path d="M96 130 V108 Q100 104 104 104 L102 130 Z" fill="#6A4A2A" ${SW2}/><circle cx="100" cy="118" r="1.6" fill="#F2C94C"/>`)+
 `<rect x="60" y="130" width="90" height="6" fill="#B88A50" ${SW2}/><text x="88" y="135" font-size="5" font-weight="bold" fill="${FI}">WELCOME</text>`+
 pt("legF",84,130,`<path d="M86 128 L82 144 H72" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M86 128 L82 144 H72" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 fG(g,1,`<path d="M30 130 q4 -18 10 -18 q6 0 6 10 q-6 10 -16 8 Z" fill="#5AB04A" ${SW2}/>`)+fG(g,2,`<circle cx="105" cy="58" r="2" fill="${P.ll}"/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Housewarming Metal"]="Walking Cottage";SM("Housewarming Metal","Warm Welcome","RES","s",0,100,"heal:25,tatk-1","Come in, come in. Shoes off. Kettle's on.");

/* Index Card Blend: a random-number machine picked the ingredients. A ladybird whose spots are dice pips, rolling as it goes. */
addForm("Index Card Blend",{n:"#F4F0E4",a:"#2A2A3A",rn:"#B8302A",rb:"#3A6AA8",ra:"#5FE0A0"},"crawl",(P,g)=>fShadow(60,104)+
 [0,1,2].map(i=>pt("legB",110+i*12,128,`<path d="M${110+i*12} 128 L${116+i*14} 144" stroke="${FI}" stroke-width="3.4"/>`,i*.3)).join("")+
 `<path d="M68 128 Q66 80 112 78 Q158 80 156 128 Z" fill="${P.n}" ${SW}/><path d="M112 78 V128" stroke="${FI}" stroke-width="3"/>`+
 `<g transform="rotate(-8 88 104)"><rect x="76" y="92" width="24" height="24" rx="4" fill="${P.nl}" ${SW2}/>${[[82,98],[94,110],[88,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.ac}"/>`).join("")}</g><g transform="rotate(10 134 104)"><rect x="122" y="92" width="24" height="24" rx="4" fill="${P.nl}" ${SW2}/>${[[128,98],[140,98],[128,110],[140,110],[134,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.ac}"/>`).join("")}</g><rect x="102" y="84" width="20" height="10" rx="3" fill="${P.nl}" ${SW2}/><circle cx="112" cy="89" r="2.4" fill="${P.ac}"/>`+
 [0,1,2].map(i=>pt("legF",84+i*12,130,`<path d="M${84+i*12} 130 L${76+i*12} 145" stroke="${FI}" stroke-width="3.4"/>`,i*.3+.15)).join("")+
 pt("head",68,114,`<path d="M44 118 Q44 100 62 98 Q76 100 76 118 Z" fill="${P.ac}" ${SW}/><ellipse cx="54" cy="104" rx="5" ry="4" fill="#F4F0E4"/><ellipse cx="70" cy="104" rx="3" ry="4" fill="#F4F0E4"/>${E2(54,110,4)}`+HMOUTH(46,116,52,P,2)+
  pt("ant",54,100,`<path d="M54 100 Q48 84 36 82" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="36" cy="82" r="2.6" fill="${FI}"/><path d="M60 98 Q60 82 52 74" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="52" cy="74" r="2.6" fill="${FI}"/>`))+
 fG(g,1,`<g transform="rotate(20 30 136)"><rect x="22" y="128" width="16" height="16" rx="3" fill="#fff" ${SW2}/><circle cx="30" cy="136" r="2" fill="${FI}"/></g>`)+fG(g,2,`<circle cx="112" cy="120" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Index Card Blend"]="Dice Ladybird";SM("Index Card Blend","Roll Of The Dice","RES","a",50,100,"multi:1-6","It could be one. It could be six. Nobody decides but the dice.");

/* Interpretite: declarations to a guard who couldn't read were made by interpretive dance. A crane (the bird) mid-dance, wings flung wide. */
addForm("Interpretite",{n:"#F4F0E4",a:"#2A2A3A",rn:"#4A4A5A",rb:"#E8C8A0",ra:"#E8412C"},"stand",(P,g)=>fShadow(46,112)+
 pt("wingB",108,72,`<path d="M108 74 Q130 30 178 22 Q166 40 172 46 Q156 50 160 60 Q140 66 126 86 Z" fill="${P.n}" ${SW}/><path d="M160 26 Q170 30 176 24 L172 46 Q166 40 160 44 Z" fill="${P.ac}"/>`,.3)+
 pt("tail",128,96,`<path d="M124 92 Q146 96 152 112 Q140 112 126 104 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",112,108,`<path d="M112 106 L134 118 L150 112" stroke="${FI}" stroke-width="4.4" fill="none" stroke-linejoin="round"/><path d="M112 106 L134 118 L150 112" stroke="#4A4A4A" stroke-width="2.4" fill="none" stroke-linejoin="round"/>`)+
 `<path d="M88 90 Q92 70 112 72 Q130 76 128 98 Q118 110 104 108 Q88 104 88 90 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",104,108,`<path d="M104 106 L104 144" stroke="${FI}" stroke-width="4.4"/><path d="M104 106 L104 144" stroke="#4A4A4A" stroke-width="2.4"/><path d="M94 144 h20" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`,.0)+
 pt("wingF",96,80,`<path d="M96 80 Q70 50 24 58 Q38 70 32 76 Q50 80 48 88 Q70 92 92 94 Z" fill="${P.n}" ${SW}/><path d="M28 58 Q34 66 30 74 L48 88 Q40 80 36 70 Z" fill="${P.ac}"/>`)+
 pt("head",96,72,`<path d="M98 80 Q84 60 92 40 Q96 30 90 24" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M98 80 Q84 60 92 40 Q96 30 90 24" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M92 50 Q88 42 92 36" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
  `<ellipse cx="88" cy="20" rx="9" ry="7" fill="${P.n}" ${SW}/><circle cx="90" cy="14" r="4" fill="#E8412C" ${SW2}/>${E2(86,20,3)}<path d="M80 20 L62 22 L80 24 Z" fill="${FMOUTH}"/>`+pt("beak",80,24,`<path d="M80 24 L64 24 L80 26 Z" fill="#8A8A6A" ${SW2}/>`)+`<path d="M80 18 L60 21 L80 22 Z" fill="#8A8A6A" ${SW2}/>`)+
 fG(g,1,`<path d="M20 130 q10 -14 20 0 q10 14 20 0" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="108" cy="92" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,70,6)));
FORM_TITLE["Interpretite"]="Interpretive Crane";SM("Interpretite","Express Yourself","RES","a",65,100,"tacc-1@50","It's hard to say exactly what it means, but you felt it.");

/* Interview Chair Blend: found waiting on a chair, as if expecting an interview. An owl in a tie, sitting very straight on a chair. */
addForm("Interview Chair Blend",{n:"#8A6A4A",a:"#E8DCC8",rn:"#3A3A4A",rb:"#B8C8D8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(56)+
 `<path d="M130 40 V144 M134 40 V144" stroke="${FI}" stroke-width="2"/><rect x="126" y="40" width="10" height="70" rx="3" fill="#8A5A30" ${SW}/><rect x="70" y="106" width="66" height="10" rx="2" fill="#8A5A30" ${SW}/><path d="M76 116 V144 M130 116 V144" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M76 116 V144 M130 116 V144" stroke="#8A5A30" stroke-width="4.4" stroke-linecap="round"/>`+
 `<path d="M80 106 Q76 66 104 60 Q130 66 126 106 Z" fill="${P.n}" ${SW}/><path d="M90 104 Q88 80 104 76 Q118 80 116 104 Z" fill="${P.ac}"/>${[0,1,2,3].map(i=>`<path d="M${94+i*6} ${86+i%2*8} q2 3 4 0" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 `<path d="M100 76 L108 76 L106 80 L110 100 L104 106 L98 100 L102 80 Z" fill="#B8302A" ${SW2}/>`+
 pt("legF",96,108,`<path d="M94 106 l-2 8 M98 106 v8 M102 106 l2 8" stroke="#E8B040" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("wingF",84,84,`<path d="M84 74 Q70 88 76 104 Q86 100 88 86 Z" fill="${P.nd}" ${SW2}/>`)+pt("wingB",124,84,`<path d="M124 74 Q136 88 130 104 Q122 100 120 86 Z" fill="${P.nd}" ${SW2}/>`,.4)+
 pt("head",104,54,`<path d="M78 56 Q76 30 104 28 Q132 30 130 56 Q126 72 104 72 Q82 72 78 56 Z" fill="${P.n}" ${SW}/><circle cx="94" cy="50" r="10" fill="${P.ac}" ${SW2}/><circle cx="114" cy="50" r="10" fill="${P.ac}" ${SW2}/>${E2(94,50,5.4,"#E8A020",[0,0])}${E2(114,50,5.4,"#E8A020",[0,0])}`+
  `<path d="M100 58 L108 58 L104 66 Z" fill="${FMOUTH}"/>`+pt("beak",104,62,`<path d="M101 60 L107 60 L104 66 Z" fill="#E8B040" ${SW2}/>`)+`<path d="M100 56 L108 56 L104 62 Z" fill="#E8B040" ${SW2}/>`+
  pt("ear",84,30,`<path d="M84 34 L80 20 L92 30 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",124,30,`<path d="M124 34 L128 20 L116 30 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<rect x="24" y="120" width="28" height="20" rx="2" fill="#F4F0E4" ${SW2}/><path d="M28 126 h20 M28 130 h20 M28 134 h12" stroke="#8A8A9A" stroke-width="1"/>`)+fG(g,2,`<circle cx="104" cy="94" r="2.6" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Interview Chair Blend"]="Interviewee Owl";SM("Interview Chair Blend","Firm Handshake","STR","a",60,100,"tatk-1@50","Look them in the eye and don't let go too soon.");
