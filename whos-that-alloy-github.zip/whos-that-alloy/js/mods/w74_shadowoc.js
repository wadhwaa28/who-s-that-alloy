/* ---- Lantern Night: the event alloys don't melt when they Overclock, they go to shadow ----
   Only the thirteen non-threat Hollowmere alloys. Same rig, same cry, but the body becomes smoke:
   near-black with a faint hue left in it, a soft dark halo, pale eyes and teeth, wisps lifting off where it would drip. */
(function(){if(document.getElementById("socDefs"))return;const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.id="socDefs";s.setAttribute("aria-hidden","true");s.style.cssText="position:absolute;width:0;height:0;overflow:hidden";
  const F=(id,halo,rim)=>`<filter id="${id}" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
    <feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="3" result="n"/>
    <feDisplacementMap in="SourceGraphic" in2="n" scale="2.6" xChannelSelector="R" yChannelSelector="G" result="g"/>
    <feTurbulence type="fractalNoise" baseFrequency=".045 .07" numOctaves="2" seed="11" result="m"/>
    <feMorphology in="SourceAlpha" operator="dilate" radius="2.6" result="dl"/><feGaussianBlur in="dl" stdDeviation="2.6" result="db"/>
    <feDisplacementMap in="db" in2="m" scale="16" xChannelSelector="G" yChannelSelector="R" result="dd"/>
    <feFlood flood-color="${halo}" flood-opacity=".78"/><feComposite in2="dd" operator="in" result="halo"/>
    <feMorphology in="SourceAlpha" operator="erode" radius="1.6" result="e"/><feOffset in="e" dx="-2" dy="-2.6" result="eu"/>
    <feComposite in="e" in2="eu" operator="out" result="rA"/><feGaussianBlur in="rA" stdDeviation="1" result="rB"/>
    <feFlood flood-color="${rim}" flood-opacity=".55"/><feComposite in2="rB" operator="in" result="rim"/>
    <feMerge><feMergeNode in="halo"/><feMergeNode in="g"/><feMergeNode in="rim"/></feMerge></filter>`;
  s.innerHTML=`<defs>${F("socF","#05030B","#B58CFF")}${F("socFR","#020814","#7AE8FF")}${F("socFB","#000000","#26262B")}
    <radialGradient id="socFog" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#05030B" stop-opacity=".7"/><stop offset=".6" stop-color="#05030B" stop-opacity=".3"/><stop offset="1" stop-color="#05030B" stop-opacity="0"/></radialGradient>
    <filter id="socGlow" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="1.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>`;
  (document.body||document.documentElement).appendChild(s)})();

/* the palette: a body that keeps a ghost of its own hue, eyes that glow. Radiant goes deep indigo with cyan light. */
function socPal(rad,base){return rad?{dark:"#03060F",light:mixHex("#1E3358",base,.12),line:"#010208",eye:"#E6FBFF",iris:"#5FE3FF",glow:"#7AE8FF",tong:"#173A5C",gut:"#02040A"}
  :{dark:"#05040A",light:mixHex("#2E2541",base,.14),line:"#020105",eye:"#F3EDFF",iris:"#A57BFF",glow:"#C9A6FF",tong:"#3D2357",gut:"#030208"}}
function shadowize(svg,S){const memo={},U=x=>x.toUpperCase();
  const pale=new Set(["#FFFFFF"]);
  const body=(c,glow)=>{const C=U(c);if(glow)return S.glow;if(C===U(FI))return S.line;if(C===U(FMOUTH))return S.gut;if(C===U(FTONGUE))return S.tong;if(pale.has(C))return S.eye;
    if(memo[C])return memo[C];const t=.05+.95*lumOf(C);return memo[C]=mixHex(S.dark,S.light,t)};
  const eye=c=>{const C=U(c);if(C===U(FI))return S.line;if(C==="#FFFFFF")return S.eye;return S.iris};
  return svg.split(/(<g class="eye"[\s\S]*?<\/g>)/).map((seg,i)=>i%2
    ?seg.replace('<g class="eye"','<g class="eye soc-eye" filter="url(#socGlow)"').replace(/(fill|stroke)="(#[0-9A-Fa-f]{6})"/g,(m,k,c)=>`${k}="${eye(c)}"`)
    :seg.replace(/<[a-zA-Z]+\b[^>]*>/g,tag=>{const glow=/class="[^"]*p-glow/.test(tag);return tag.replace(/(fill|stroke)="(#[0-9A-Fa-f]{6})"/g,(m,k,c)=>`${k}="${body(c,glow)}"`)})).join("")}
/* where molten metal would drip, smoke lifts off instead; where a drop would fall, a mote rises */
function socBits(name,S){const A=(typeof MOLTEN_AT!=="undefined"&&MOLTEN_AT[name])||null;if(!A)return"";let s="";
  const wisp=(x,y,h,w,k)=>`<path d="M${x} ${y} C${x-w} ${y-h*.3} ${x+w} ${y-h*.55} ${x-w*.4} ${y-h*.8} S${x+w*.6} ${y-h} ${x} ${y-h*1.15}" stroke="${k}" stroke-width="${(w*.9).toFixed(1)}" fill="none" stroke-linecap="round"/>`;
  (A.d||[]).forEach(([x,y],i)=>{const h=[22,30,18,26][i%4],w=[4.2,5,3.6,4.6][i%4];
    s+=`<g class="soc-wisp" style="--dl:${(i*.63).toFixed(2)}s;--wx:${i%2?3:-3}px">${wisp(x,y,h,w,S.dark)}${wisp(x+1,y-2,h*.8,w*.45,S.light)}</g>`});
  if(A.f){const[x,y]=A.f;s+=`<circle class="soc-mote" cx="${x}" cy="${y-6}" r="1.7" fill="${S.glow}" style="--dl:.4s"/><circle class="soc-mote" cx="${x+9}" cy="${y-14}" r="1.2" fill="${S.glow}" style="--dl:1.6s"/>`}
  if(A.c){const[x,y]=A.c;s+=`<path class="p-glow soc-seam" d="M${x-7} ${y-2} Q${x} ${y+4} ${x+8} ${y-1}" stroke="${S.glow}" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".55"/>`}
  return s}
/* Gutterwick's Radiant: not a child playing at being a shadow person, but the real thing. Pitch black all through, no colour
   anywhere in it, no light at its edges, and nothing showing but white pinprick eyes and white teeth. */
const SOC_PITCH={dark:"#000000",light:"#0A0A0C",line:"#000000",eye:"#FFFFFF",iris:"#FFFFFF",glow:"#141418",tong:"#000000",gut:"#000000",pitch:1};
function socWrap(svg,name,S,rad){
  svg=svg.replace('class="cr-body L-','class="cr-body shadowform L-').replace('<g class="ib">',`<g class="ib"><g class="soc" filter="url(#${S.pitch?"socFB":rad?"socFR":"socF"})">`);
  svg=svg.replace(/(<svg[^>]*>)/,`$1<ellipse class="soc-fog" cx="100" cy="146" rx="70" ry="13" fill="url(#socFog)"/>`);
  const k=svg.lastIndexOf("</g></g></g></svg>");if(k<0)return svg;
  return svg.slice(0,k)+"</g>"+socBits(name,S)+svg.slice(k)}
function shadowAll(){if(typeof LNT_ALLOYS==="undefined")return;
  [...LNT_ALLOYS.filter(o=>!o.threat),{name:typeof GW_NAME!=="undefined"?GW_NAME:"Gutterwick"}].forEach(o=>{const name=o.name,fn=FORM_FN[name],R=FORM_R[name];if(!fn||!R)return;const loco=FORM_LOCO[name]||"stand";
    const cache=new Map();const nf=(a,g,rad)=>{const k=g+"|"+(rad?1:0)+"|"+a.color;if(cache.has(k))return cache.get(k);
      const P=fPal(a,rad,R),S=rad&&name===(typeof GW_NAME!=="undefined"?GW_NAME:"Gutterwick")?SOC_PITCH:socPal(!!rad,rad?R.rb:a.color),v=socWrap(shadowize(fWrap(fn(P,g,!!rad),g,loco),S),name,S,!!rad);cache.set(k,v);return v};
    nf.molten=1;nf.shadow=1;BATTLE_FORMS[name]=nf})}
shadowAll();
/* ---- Overclocking INTO a shadow isn't heating up: it's going dark ----
   For the Hollowmere alloys the morph runs differently: the sample darkens and smokes, smoke swells up round it and a pair of eyes
   opens in it, the gauge burns violet, the burst is a pulse of dark instead of a flash of light, and the shadow form condenses out of
   the smoke. Cooling back down, the form comes apart in wisps instead of steam. */
{const _om=ocMorph;ocMorph=function(host,from,to,o){const pr=_om(host,from,to,o);const x=host&&host.querySelector(".ocx");
  if(x&&/shadowform/.test(String(from)+String(to))){x.classList.add("sh");const up=x.classList.contains("up");
    x.querySelectorAll(".oc-steam").forEach(e=>e.remove());
    x.insertAdjacentHTML("beforeend",up?`<div class="sh-smoke">${[[30,62,0],[52,66,.08],[70,60,.16],[42,48,.24],[60,44,.3],[50,56,.12]].map(([l,t,d])=>`<i style="left:${l}%;top:${t}%;animation-delay:${d}s"></i>`).join("")}</div><div class="sh-eyes"><b></b><b></b></div>`
      :`<div class="sh-wisps">${[[34,0],[46,.08],[58,.16],[66,.06],[40,.2],[54,.26]].map(([l,d])=>`<i style="left:${l}%;animation-delay:${d}s"></i>`).join("")}</div>`)}
  return pr}}
