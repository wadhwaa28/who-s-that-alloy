/* =============== POSSESSED SAMPLES ===============
   The Gutterwick was an unidentified sample that one especially erratic shadow person got into. It wasn't the last. While Lantern Night
   is on, the shadows that come up out of every shadow in the country have started getting into samples too: one encounter in twelve in
   Hollowmere (where half the time a shadow has dragged it in from somewhere else, and half the time it's got into one of Hollowmere's own), one in
   twenty-four anywhere else. A possessed sample is dark, smoking, and looks back at you. Identify it and the shadow lets go: you register
   the ordinary alloy, and a trace of the shadow is left on your fingers. Gather a hundred traces, and register the one they all followed,
   and you'll have earned something to wear. */
const POS={next:false};
const posTraces=()=>store.get("wta_shd_trace",0);
const POS_CAN=a=>a&&!a.threat&&(a.event==="lantern"||(!a.event&&!a.quest));
{const _en=encounter;encounter=function(){POS.next=false;
  if(typeof lntOn==="function"&&lntOn()&&S.phase==="explore"&&(!EXP.storyAlloy||posLntStory())&&!EXP.duel&&!EXP.trial&&!EXP.questAlloy&&!(typeof TUT!=="undefined"&&TUT.on)&&EXP.zone&&!EXP.zone.special)
    POS.next=window.__posForce||Math.random()<(inHollow()?1/12:1/24);
  _en()}}
function posLntStory(){const n=EXP.storyAlloy&&EXP.storyAlloy.name,a=n&&ALLOYS.find(x=>x.name===n);return !!(a&&a.event==="lantern"&&!a.threat)}
/* in Hollowmere, half the time the possessed one is something dragged in from outside */
{const _pa=pickAlloy;pickAlloy=function(kind,used){if(POS.next&&!EXP.storyAlloy&&typeof inHollow==="function"&&inHollow()&&Math.random()<.5){
    const pool=ALLOYS.filter(a=>POS_CAN(a)&&a.rar!=="legendary"&&!used.has(a.name));let tot=pool.reduce((t,a)=>t+((RARITY[a.rar]||{}).w||1),0),r=Math.random()*tot;
    for(const a of pool){r-=((RARITY[a.rar]||{}).w||1);if(r<=0)return a}if(pool.length)return pool[pool.length-1]}
  return _pa(kind,used)}}
{const _sr=startRound;startRound=function(){const was=POS.next;try{_sr()}finally{POS.next=false}
  if(was&&S.r&&POS_CAN(S.r.a)){S.r.possessed=1;{const sp=$("#specimen");if(sp)posFx(sp)}setTimeout(()=>{const sp=$("#specimen");if(sp&&S.r&&S.r.possessed)posFx(sp)},120);setTimeout(()=>{if(S.r&&S.r.possessed&&S.r.stage!=="done")say(inHollow()&&S.r.a.event!=="lantern"?"A shadow has dragged this one in from somewhere else, and it's still inside it. It's looking at you.":"Something else is in this sample. It's looking at you.")},3500)}}}
/* what a possessed sample looks like: the dark has got into it, it smokes, and two pinprick eyes and a grin look out of it */
function posFx(host){const svg=host&&host.querySelector("svg");if(!svg||svg.querySelector(".posfx"))return;const U="ps"+(posFx.n=(posFx.n||0)+1);
  svg.style.overflow="visible";
  svg.insertAdjacentHTML("beforeend",`<g class="posfx" pointer-events="none"><defs><radialGradient id="${U}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#05040A" stop-opacity=".82"/><stop offset=".6" stop-color="#0A0814" stop-opacity=".55"/><stop offset="1" stop-color="#0A0814" stop-opacity="0"/></radialGradient></defs>
   <ellipse cx="150" cy="150" rx="78" ry="70" fill="url(#${U})"/>
   ${[[124,96,0],[150,88,1.2],[176,98,2.3],[140,92,3.1]].map(([x,y,d])=>`<path class="pos-wisp" style="animation-delay:-${d}s" d="M${x} ${y} q-6 -10 0 -20 q6 -9 0 -18" stroke="#0E0A1A" stroke-width="6" fill="none" stroke-linecap="round"/>`).join("")}
   <g filter="url(#shdG)" class="pos-seyes"><circle cx="139" cy="140" r="2.6" fill="#FFFFFF"/><circle cx="161" cy="140" r="2.6" fill="#FFFFFF"/></g>
   <g class="pos-grin"><path d="M131 152 Q150 168 169 152 Q150 176 131 152 Z" fill="#05040A"/><path d="M133 153 Q150 166 167 153 Q150 172 133 153 Z" fill="#EEEAF2"/>${Array.from({length:7},(_,k)=>`<path d="M${136+k*4.6} ${155+Math.sin((k+.5)/7*Math.PI)*5} V${158+Math.sin((k+.5)/7*Math.PI)*8}" stroke="#05040A" stroke-width="1"/>`).join("")}</g></g>`)}
{const _rs=renderStage;renderStage=function(){_rs.apply(this,arguments);if(S.r&&S.r.possessed&&S.r.stage!=="done"){const sp=$("#specimen");if(sp)posFx(sp)}else{document.querySelectorAll("#specimen .posfx").forEach(e=>e.remove())}}}
/* identified: the shadow lets go, and leaves a trace */
{const _w=win;win=function(){const r=S.r,pos=r&&r.possessed;_w();if(pos&&r){r.possessed=0;document.querySelectorAll("#specimen .posfx").forEach(e=>e.remove());
    const n=posTraces()+1;store.set("wta_shd_trace",n);setTimeout(()=>say(`The shadow lets go of it and slides off into the nearest shadow. A trace of it stays on your fingers. (Traces of shadow: ${n})`),900)}
  shdCoatCheck()}}
{const _l=lose;lose=function(ran){const r=S.r,pos=r&&r.possessed;_l(ran);if(pos&&r){r.possessed=0;setTimeout(()=>say("The shadow takes the sample with it, down into the dark."),900)}}}
/* ---- the coat: somebody trying very, very hard to be a shadow person ---- */
function shdCoatCheck(){if(store.get("wta_coat_shd",0)||posTraces()<100||!S.caught.has(typeof GW_NAME!=="undefined"?GW_NAME:"Gutterwick"))return;store.set("wta_coat_shd",1);if(typeof coatCheck==="function")coatCheck()}
COATS.push({id:"shadowkid",name:"Shadow Getup",desc:"Black from head to foot: a smooth hood with no face, two painted eyes that catch the light, a thin white grin, sleeves so long they drag along the floor behind you, and a ragged hem that trails off like a shadow's does. In a dark room you'd walk right past it. The flask gives you away.",
  how:"Earned by gathering a hundred traces of shadow, and registering the one they all followed.",cut:"jacket",body:"#0A090E",sleeve:"#0A090E",cuff:"#0A090E",open:()=>!!store.get("wta_coat_shd",0),
  /* a haze of dark round the whole figure, and the ragged hem running down like a shadow's legs do */
  back:`<ellipse cx="20" cy="22" rx="14" ry="17" fill="#0A090E" opacity=".16"/><ellipse cx="20" cy="22" rx="11" ry="14.6" fill="#0A090E" opacity=".14"/>
`,
  detail:`<path d="M13 23 Q20 25.4 27 23 M12.6 27 Q20 29.4 27.4 27 M12.4 31 Q20 33.2 27.6 31" stroke="#1A1820" stroke-width=".55" fill="none"/>`,
  /* long gloved fingers on the free hand, and round the flask */
  /* the hood: smooth, faceless, and a grin and two eyes that really are quite good */
  hat:`<path d="M12.2 14.4 Q11.6 4.8 20 4.4 Q28.4 4.8 27.8 14.4 Q27.6 20 24.6 21.8 L15.4 21.8 Q12.4 20 12.2 14.4 Z" fill="#0A090E" stroke="#121B40" stroke-width="1"/>
   <path d="M14 7.6 Q16 5.6 19 5.2" stroke="#2A2832" stroke-width=".6" fill="none" stroke-linecap="round"/>
   <circle cx="18.6" cy="12.6" r="1.35" fill="#F6F2FF" opacity=".2"/><circle cx="24" cy="12.6" r="1.35" fill="#F6F2FF" opacity=".2"/>
   <circle cx="18.6" cy="12.6" r=".85" fill="#FFFFFF"/><circle cx="24" cy="12.6" r=".85" fill="#FFFFFF"/>
   <path d="M15.2 14.6 Q21.2 20.4 27.2 14.4 Q21.2 18.4 15.2 14.6 Z" fill="#F6F2FF" opacity=".22"/>
   <path d="M15.8 14.9 Q16.4 15.9 16.8 15.6 Q21.2 19.4 25.6 15.4 Q26 15.8 26.6 14.7 Q21.2 18.2 15.8 14.9 Z" fill="#FFFFFF"/>`});
/* the sleeves, far too long: the left one runs down past where your hand should be and crumples on the floor behind you; the right
   one's cuff has swallowed the neck of your flask, and the rest of it hangs down to the floor and drags along behind */
const SHD_BACKSLEEVE=`<path d="M34 27.6 Q36.6 31 36 33.4 Q35.4 34.6 32.6 34.9 Q24 35.2 14 35.1 Q8 35 4.4 34.6" stroke="#121B40" stroke-width="3.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
   <path d="M34 27.6 Q36.6 31 36 33.4 Q35.4 34.6 32.6 34.9 Q24 35.2 14 35.1 Q8 35 4.4 34.6" stroke="#0A090E" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
   <path d="M5.4 33.8 Q3.2 33.6 2.8 34.8 Q3.8 35.8 5.6 35.4" fill="#0A090E" stroke="#121B40" stroke-width=".55" stroke-linejoin="round"/>
   <path d="M9 35.2 Q10 35.9 11 35.3 M28 35.4 Q29 36 30 35.4" stroke="#2A2832" stroke-width=".35" fill="none"/>`;
const SHD_SLEEVES=(()=>{const sl=(d,w)=>`<path d="${d}" stroke="#121B40" stroke-width="${w+1.6}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="#0A090E" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  return`<g class="shd-sleeves">${sl("M11.6 22.8 Q8.6 28 8.6 33 Q8.4 36.8 6.6 38.4 Q4.6 39.4 1.8 39.2",2.4)}
   <path d="M3 38.2 Q.6 38.2 .2 39.6 Q1.4 40.8 3.4 40.2" fill="#0A090E" stroke="#121B40" stroke-width=".6" stroke-linejoin="round"/>
   <path d="M9.6 26.4 Q8.6 27.4 9.2 28.4 M8.6 30.6 Q9.6 31.6 8.8 32.8 M5.8 38 Q5 39.2 6.2 39.6" stroke="#2A2832" stroke-width=".4" fill="none"/>
   ${sl("M28.4 22.8 Q31.6 24.2 32.6 26.6",2.4)}
   <path d="M30.6 25.6 Q32.4 24 34.4 25.4 L34.6 27.4 Q32.6 28.4 30.6 27.6 Z" fill="#0A090E" stroke="#121B40" stroke-width=".7" stroke-linejoin="round"/>
</g>`})();
/* the getup covers the whole of you: no face, no glasses, black hands and feet (only the flask is still yours) */
{const _ps=playerSVG;playerSVG=function(c){const coat=c||coatNow(),out=_ps(c);if(!coat||coat.id!=="shadowkid")return out;const L=out.split("\n");
  return L.map(l=>{if(/<circle cx="20" cy="13\.5" r="7\.2"/.test(l))return l.replace(/fill="#[0-9A-Fa-f]{6}"/,'fill="#0A090E"');
    if(/M12\.8 13 L27\.4 13|cx="19\.6" cy="13\.4" r="2\.6"|cx="18\.9" cy="12\.6" r="\.7"|M21\.5 17\.6 Q23 18\.6 24\.4 17\.6/.test(l))return l.includes("</svg>")?"</svg>":"";
    /* the arms are the sleeves now: drawn by the getup itself (below), so the ordinary arm strokes go */
    if(/d="M11\.5 23 Q9 28 10 32"|d="M28\.5 23 Q31\.5 25 32 28"|M10\.05 30\.6 L10\.05 31\.8|M31\.5 26\.6 L31\.9 27\.7/.test(l))return"";
    /* hands are lost somewhere inside the sleeves */
    if(/<circle cx="10\.2" cy="32\.4"|<circle cx="32" cy="28" r="1\.8"/.test(l))return"";
    /* the legs: black, with a thin outline so you can see the trailing sleeve go behind them */
    if(/<rect x="1[34]\.5" y="3[15](\.5)?"|<rect x="2[01](\.5)?" y="3[15](\.5)?"/.test(l))return l.replace(/fill="#[0-9A-Fa-f]{6}"/g,'fill="#0A090E" stroke="#3A3848" stroke-width=".5"');
    return l}).map((l,i)=>i===0?l+"\n"+SHD_BACKSLEEVE:l).join("\n").replace("</svg>",SHD_SLEEVES+"</svg>")}}
/* the journal keeps count while Lantern Night is on */
{const _jo=journalObjectives;journalObjectives=function(){const J=_jo(),n=posTraces();if(n>0||(typeof lntOn==="function"&&lntOn()&&lntF("hm")))J.push(`<div class="bag-item key obj"><b>TRACES OF SHADOW: ${n}</b><p>${n?"Left on your fingers each time a shadow let go of a sample you identified.":"Shadows have started getting into samples. Identify a possessed one and the shadow has to let go."}</p></div>`);return J}}
