/* ---- Shipwreck Coast, 6 ---- */
/* Muleteer's Metal: every plane grounded, so it went by mule over the pass, collecting a receipt at every stop. A mule trailing a long, long receipt. */
addForm("Muleteer's Metal",{n:"#8A6A5A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(74)+
 pt("tail",160,94,fOL("M158 94 Q168 106 166 124",P.n,3)+`<path d="M162 120 l4 10 l4 -10" fill="${P.nd}" ${SW2}/>`)+
 fLeg("legB",148,108,34,8,P.nd,P.ndd,.5)+fLeg("legB",116,110,32,8,P.nd,P.ndd,1.3)+
 `<path d="M88 100 Q88 78 122 76 Q156 78 160 98 Q156 116 124 116 Q92 116 88 100 Z" fill="${P.n}" ${SW}/><path d="M104 78 L144 78 L146 102 L102 102 Z" fill="#8A5A2A" ${SW}/><path d="M104 90 h42" stroke="#6A3A1A" stroke-width="2"/>`+
 `<path d="M138 82 Q170 60 182 82 Q190 110 172 130 Q160 140 150 138" fill="none" stroke="${FI}" stroke-width="10"/><path d="M138 82 Q170 60 182 82 Q190 110 172 130 Q160 140 150 138" fill="none" stroke="${P.ac}" stroke-width="8"/>${[0,1,2,3,4,5].map(i=>`<path d="M${150+i*6} ${74+i*10} l6 2" stroke="#8A8A9A" stroke-width="1"/>`).join("")}`+
 fLeg("legF",140,110,32,8,P.n,P.ndd,0)+fLeg("legF",100,110,32,8,P.n,P.ndd,.8)+
 pt("head",92,90,`<path d="M96 96 Q84 86 78 74" stroke="${P.n}" stroke-width="16" stroke-linecap="round"/><path d="M48 84 Q46 66 66 64 Q86 66 86 82 Q82 96 66 96 Q52 96 48 84 Z" fill="${P.n}" ${SW}/><path d="M48 88 Q50 80 60 82 Q62 92 52 94 Z" fill="${P.nd}"/>${E2(66,76,3.6)}`+HMOUTH(50,90,58,P,2)+
  pt("ear",74,64,`<path d="M70 66 Q66 40 76 36 Q84 48 80 68 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",82,66,`<path d="M78 66 Q84 40 96 38 Q98 52 86 70 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M20 140 L36 112 L52 140 Z" fill="#E8E8F0" ${SW2}/>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Muleteer's Metal"]="Receipt-Trailing Mule";SM("Muleteer's Metal","Over The Pass","STR","a",80,95,"","Slow, sure, and receipted at every stop.");

/* Mystery Crate Metal: lost at sea a decade, then auctioned as 'mystery crate, do not open'. A sea turtle with that crate barnacled to its shell. */
addForm("Mystery Crate Metal",{n:"#5A8A6A",a:"#E8D8B0",rn:"#3A3A4A",rb:"#B88A50",ra:"#5FE0F0"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 pt("tail",158,104,`<path d="M152 102 L168 106 L152 112 Z" fill="${P.n}" ${SW2}/>`)+
 pt("wingB",132,104,`<path d="M130 106 Q152 118 160 136 Q140 132 126 114 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M64 104 Q68 70 112 68 Q154 70 158 104 Q150 118 112 120 Q72 118 64 104 Z" fill="#8A6A3A" ${SW}/>${[[88,88],[112,80],[136,88],[100,104],[126,104]].map(([x,y])=>`<path d="M${x-9} ${y} l4 -7 h10 l4 7 l-4 7 h-10 Z" fill="#6A4A2A" ${SW2}/>`).join("")}<rect x="96" y="44" width="34" height="28" fill="#B88A50" ${SW}/><path d="M96 58 h34 M113 44 v28" stroke="#8A6030" stroke-width="2"/><text x="98" y="54" font-size="5" font-weight="bold" fill="${FI}">DO NOT</text>${[[94,70],[132,66],[100,46],[128,72]].map(([x,y])=>`<path d="M${x-4} ${y} l4 -6 l4 6 Z" fill="#E8E0D0" ${SW2}/>`).join("")}`+
 pt("wingF",86,108,`<path d="M88 108 Q66 120 50 140 Q72 138 92 118 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",62,96,`<path d="M66 100 L50 96" stroke="${P.n}" stroke-width="14" stroke-linecap="round"/><path d="M24 92 Q26 80 42 80 Q56 82 56 94 Q52 104 40 104 Q28 104 24 92 Z" fill="${P.n}" ${SW}/>${[[36,86],[44,84]].map(([x,y])=>`<path d="M${x-3} ${y} l3 -3 l3 3 l-3 3 Z" fill="${P.nd}"/>`).join("")}${E2(40,90,3.4)}`+HMOUTH(26,96,34,P,2))+
 fG(g,1,`<circle cx="30" cy="40" r="4" fill="#E8F4F8" ${SW2}/><circle cx="20" cy="54" r="2.6" fill="#E8F4F8" ${SW2}/>`)+fG(g,2,`<circle cx="112" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Mystery Crate Metal"]="Crate-Carrying Sea Turtle";SM("Mystery Crate Metal","Do Not Open","RES","s",0,100,"def+2","Ten years at sea and it's still sealed.");

/* Never-Found Metal: on every scavenger-hunt list, never found. A leaf-tailed gecko so well hidden it's nearly a dead leaf. */
addForm("Never-Found Metal",{n:"#A8804A",a:"#6A4A2A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#E8412C"},"crawl",(P,g)=>`<path d="M14 140 Q104 130 194 142" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(70)+
 pt("tail",150,114,`<path d="M144 112 Q170 96 190 112 Q170 132 146 120 Z" fill="${P.n}" ${SW}/><path d="M146 116 Q168 112 188 112" stroke="${P.ac}" stroke-width="1.6" fill="none"/>${[156,166,176].map(x=>`<path d="M${x} ${114} l-4 -8 M${x} 114 l-4 8" stroke="${P.ac}" stroke-width="1"/>`).join("")}<path d="M160 100 l4 -4 M176 124 l3 4" stroke="${FI}" stroke-width="1.6"/>`)+
 [[138,"legB",.5],[100,"legB",1.3]].map(([x,c,d])=>pt(c,x,124,fOL(`M${x} 122 L${x+8} 134`,P.nd,5)+`<path d="M${x+4} 136 h10" stroke="${P.nd}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M74 118 Q78 102 112 100 Q144 102 148 116 Q142 128 112 128 Q80 128 74 118 Z" fill="${P.n}" ${SW}/>${[[90,110],[110,106],[130,112],[100,120],[124,122]].map(([x,y])=>`<path d="M${x} ${y} l6 -3" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}<path d="M76 118 Q112 98 146 116" stroke="${P.ac}" stroke-width="1.2" fill="none" stroke-dasharray="2 3"/>`+
 [[128,"legF",0],[88,"legF",.8]].map(([x,c,d])=>pt(c,x,126,fOL(`M${x} 124 L${x-8} 136`,P.n,5)+`<path d="M${x-14} 138 h10" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 pt("head",76,110,`<path d="M40 112 Q44 98 62 96 Q80 98 82 110 Q76 122 60 122 Z" fill="${P.n}" ${SW}/><path d="M44 104 Q36 100 34 108 M62 96 Q58 90 64 88" stroke="${P.ac}" stroke-width="1.6" fill="none"/>${E2(60,104,4.4,"#C8A040")}`+HMOUTH(42,114,52,P,2))+
 fG(g,1,`<rect x="160" y="30" width="26" height="30" fill="#F4F0E4" ${SW2}/>${[36,42,48,54].map((y,i)=>`<path d="M164 ${y} l2 2 l3 -4" stroke="${i==3?"#C8302A":"#3A8A3A"}" stroke-width="1.4" fill="none"/><path d="M172 ${y} h10" stroke="#8A8A9A" stroke-width="1"/>`).join("")}`)+fG(g,2,`<circle cx="112" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Never-Found Metal"]="Leaf-Tailed Gecko";SM("Never-Found Metal","Hide In Plain Sight","RES","s",0,100,"dodge,spd+1","It was right in front of you the whole time.");

/* Nine-Tag Blend: tags from nine airship lines that never flew there. A suitcase on legs, plastered with luggage tags. */
addForm("Nine-Tag Blend",{n:"#8A4A3A",a:"#F4E8C0",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(58)+
 pt("legB",126,128,fOL("M124 124 L130 142 H140",P.nd,7),.5)+
 `<rect x="66" y="60" width="78" height="66" rx="8" fill="${P.n}" ${SW}/><path d="M66 74 H144 M66 112 H144" stroke="${P.nd}" stroke-width="3"/><rect x="92" y="48" width="26" height="14" rx="4" fill="none" stroke="${FI}" stroke-width="5"/><rect x="92" y="48" width="26" height="14" rx="4" fill="none" stroke="#6A3A2A" stroke-width="3"/>${[[74,80,-10,"#F4E8C0"],[124,82,8,"#C8E0F0"],[80,98,6,"#F2C94C"],[128,104,-6,"#E8B0C0"],[100,108,4,"#C8E8C0"]].map(([x,y,r,c])=>`<g transform="rotate(${r} ${x} ${y})"><rect x="${x}" y="${y}" width="16" height="10" rx="2" fill="${c}" ${SW2}/><path d="M${x+3} ${y+4} h10" stroke="#6A6A7A" stroke-width="1"/></g>`).join("")}`+
 pt("legF",84,128,fOL("M86 124 L80 142 H70",P.n,7))+
 pt("head",106,88,`${E2(96,88,4.6)}${E2(116,88,4.6)}`+HMOUTH(100,98,112,P,2.4))+
 pt("armF",68,94,fOL("M68 94 Q54 96 52 108",P.n,5))+pt("armB",144,94,fOL("M144 94 Q158 90 160 78",P.n,5),.4)+
 fG(g,1,`<path d="M20 50 l10 -4 l10 4 l-10 4 Z" fill="#E8E8F0" ${SW2}/><ellipse cx="30" cy="50" rx="14" ry="5" fill="none" stroke="${FI}" stroke-width="1"/>`)+fG(g,2,`<circle cx="106" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Nine-Tag Blend"]="Walking Suitcase";SM("Nine-Tag Blend","Excess Baggage","STR","a",75,100,"selfspd-1","Nine airlines' worth of luggage, all landing at once.");

/* Oddburine: opened a week after the attic clear-out, once everyone calmed down. A dusty rocking horse from that attic, cobwebs and all, rocking on its own. */
addForm("Oddburine",{n:"#E8DCC8",a:"#B8302A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"hop",(P,g)=>fShadow(72)+
 pt("sway",108,120,`<path d="M40 130 Q104 158 176 128" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M40 130 Q104 158 176 128" stroke="#8A5A2A" stroke-width="6" fill="none" stroke-linecap="round"/>`+
  [[72,0],[90,.2],[124,.3],[142,.1]].map(([x,d])=>`<path d="M${x} ${112} L${x+(x<104?-6:6)} ${138}" stroke="${FI}" stroke-width="8" stroke-linecap="round"/><path d="M${x} ${112} L${x+(x<104?-6:6)} ${138}" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/>`).join("")+
  `<path d="M60 104 Q62 84 104 82 Q146 84 150 104 Q146 118 104 118 Q64 118 60 104 Z" fill="${P.n}" ${SW}/>${[[80,92],[100,98],[124,90],[138,104],[86,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.ac}" opacity=".8"/>`).join("")}<path d="M90 84 Q104 76 118 84 L116 98 Q104 102 92 98 Z" fill="#B8302A" ${SW2}/>`+
  pt("tail",150,98,`<path d="M148 96 Q170 92 176 110 Q164 108 152 104 Z" fill="#6A4A2A" ${SW}/>`)+
  pt("head",68,86,`<path d="M72 92 L60 56 Q56 46 44 50 L32 62 Q30 70 38 70 L52 66 L66 98 Z" fill="${P.n}" ${SW}/><path d="M64 54 Q76 62 78 88 Q70 76 66 64 Z" fill="#6A4A2A" ${SW2}/><circle cx="48" cy="58" r="3.4" fill="${FI}"/><path d="M34 66 l8 -2" stroke="${FI}" stroke-width="1.6"/>`+pt("ear",56,48,`<path d="M54 50 L56 38 L62 50 Z" fill="${P.n}" ${SW2}/>`)+pt("jaw",38,68,`<path d="M36 68 Q34 74 42 72 Z" fill="${P.nd}" ${SW2}/>`)))+
 `<path d="M14 14 L44 14 L14 44 Z" fill="none" stroke="#C8C8D0" stroke-width="1"/><path d="M14 24 L34 14 M14 34 L24 14 M20 14 Q24 24 14 30" stroke="#C8C8D0" stroke-width="1" fill="none"/>`+
 fG(g,1,`<path d="M170 20 L194 20 L194 44 Z" fill="none" stroke="#C8C8D0" stroke-width="1"/>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,60,6)));
FORM_TITLE["Oddburine"]="Attic Rocking Horse";SM("Oddburine","Rock And Roll","STR","a",60,100,"multi:1-2,tacc-1@20","Backwards, forwards, backwards. Nobody's touching it.");

/* Onsleyite: calligraphers copy it out once a year, slower and fancier each time. A brushtail possum painting the recipe with the tip of its own tail. */
addForm("Onsleyite",{n:"#8A8A92",a:"#2A2A30",rn:"#E8D8C8",rb:"#B8402A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="20" y="124" width="70" height="20" fill="#F4F0E4" ${SW2}/><path d="M28 134 q6 -8 12 0 q4 6 8 -2 q6 -8 10 2 q4 6 10 -4" stroke="${FI}" stroke-width="2.4" fill="none"/>`+fShadow(60,110)+
 pt("tail",128,118,`<path d="M124 118 Q150 120 152 96 Q150 70 120 74 Q96 80 82 120" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M124 118 Q150 120 152 96 Q150 70 120 74 Q96 80 82 120" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/><path d="M92 98 Q86 110 82 124" stroke="${P.ac}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M82 124 l-2 6" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("legB",120,130,fOL("M120 126 L126 142 H134",P.nd,8),.5)+
 `<path d="M98 128 Q94 100 116 96 Q136 100 136 128 Q130 142 116 142 Q102 142 98 128 Z" fill="${P.n}" ${SW}/><path d="M106 128 Q116 136 128 128 Q126 112 116 110 Q108 112 106 128 Z" fill="#E8E0D0"/>`+
 pt("legF",104,130,fOL("M106 126 L100 142 H90",P.n,8))+
 pt("head",114,86,`<path d="M94 88 Q94 68 114 66 Q134 68 134 88 Q130 102 114 102 Q98 102 94 88 Z" fill="${P.n}" ${SW}/><ellipse cx="96" cy="90" rx="3.6" ry="3" fill="#E8A0A0" ${SW2}/>${E2(106,82,4.4,"#1A1A1A")}${E2(120,82,4.2,"#1A1A1A")}`+HMOUTH(100,94,108,P,2)+
  pt("ear",104,68,`<path d="M100 70 Q98 54 108 54 Q112 62 110 70 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",126,70,`<path d="M122 68 Q126 54 134 56 Q134 66 128 72 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M160 120 h20 v16 h-20 Z" fill="${FI}"/><ellipse cx="170" cy="120" rx="10" ry="3" fill="#3A3A44" ${SW2}/>`)+fG(g,2,`<circle cx="116" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Onsleyite"]="Calligrapher Possum";SM("Onsleyite","Flourish","RES","a",65,100,"acc+1","A little slower, a little fancier, every single year.");

/* Orichalcum: Plato's metal on the walls of Atlantis. A hippocampus, the horse-fronted, fish-tailed steed of the sea, Atlantean crest on its brow. */
addForm("Orichalcum",{n:"#E8A040",a:"#5AB0C8",rn:"#3A3A4A",rb:"#E8E0D0",ra:"#E8412C"},"swim",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#7AB8E8" opacity=".35"/>`+
 pt("tail",140,108,`<path d="M110 110 Q140 128 160 116 Q178 104 172 86 Q186 84 192 94 Q190 72 172 72 Q160 96 140 104 Z" fill="${P.n}" ${SW}/>${[124,136,148,158].map(x=>`<path d="M${x-4} ${116-(x-124)*.3} q4 4 8 0" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}<path d="M172 72 L186 66 L182 80" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M72 112 Q66 80 92 72 Q118 70 122 98 Q122 118 104 122 Q82 124 72 112 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",80,108,`<path d="M82 106 Q64 112 58 124 Q66 132 72 124" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M82 106 Q64 112 58 124 Q66 132 72 124" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+pt("legB",94,112,`<path d="M96 110 Q84 120 84 132" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M96 110 Q84 120 84 132" stroke="${P.nd}" stroke-width="5" fill="none" stroke-linecap="round"/>`,.5)+
 pt("head",84,74,`<path d="M88 82 L80 52 Q78 42 66 44 L52 56 Q48 64 56 66 L70 62 L82 90 Z" fill="${P.n}" ${SW}/><path d="M80 48 Q96 52 100 80 Q92 70 86 62 Z" fill="${P.ac}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${84+i*4} ${52+i*8} q8 0 10 6" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")}<circle cx="64" cy="52" r="3.4" fill="${FI}"/>`+pt("jaw",56,64,`<path d="M54 64 Q50 72 58 70 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M66 44 L68 32 L74 40 L80 30 L82 42 Z" fill="${P.b}" ${SW2}/><circle cx="74" cy="40" r="2" fill="${P.ac}"/>`)+
 fG(g,1,`<path d="M20 120 V96 L28 90 L36 96 V120 M44 120 V96 L52 90 L60 96 V120" stroke="${P.b}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="98" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,30,6)));
FORM_TITLE["Orichalcum"]="Atlantean Hippocampus";SM("Orichalcum","Sunken Kingdom","DRP","a",90,90,"","The tide comes in over the walls of Atlantis.");

/* Overboard Metal: it slipped over the side of a balloon above Marram Fen. A dandelion-clock sprite drifting under its own seed parachutes. */
addForm("Overboard Metal",{n:"#E8E4D8",a:"#E8C040",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#5FE0A0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="26" ry="3" fill="#000" opacity=".1"/>`+
 pt("slow",104,52,Array.from({length:18},(_,i)=>{const a=-3.14+i/17*3.14,x=104+Math.cos(a)*44,y=72+Math.sin(a)*44;return`<path d="M104 72 L${x} ${y}" stroke="#C8C8C0" stroke-width="1"/><path d="M${x} ${y} m-5 -2 l5 2 l5 -2 M${x} ${y} l-4 -5 M${x} ${y} l4 -5" stroke="${P.n}" stroke-width="1.2" fill="none"/>`}).join(""))+
 `<circle cx="104" cy="82" r="16" fill="${P.n}" ${SW}/>`+
 pt("head",104,84,`${E2(98,82,3.6)}${E2(110,82,3.6)}`+HMOUTH(100,90,108,P,2))+
 pt("tail",104,100,`<path d="M104 98 V136" stroke="#5A9A3A" stroke-width="3"/><path d="M104 120 Q114 112 120 116 Q112 124 104 124 Z" fill="#5A9A3A" ${SW2}/>`)+
 pt("wingF",60,40,`${[[40,30],[164,40],[30,110],[174,100]].map(([x,y])=>`<path d="M${x} ${y} v10" stroke="#C8C8C0" stroke-width="1"/><path d="M${x-5} ${y-2} l5 2 l5 -2 M${x} ${y} l-4 -5 M${x} ${y} l4 -5" stroke="${P.n}" stroke-width="1.2" fill="none"/>`).join("")}`)+
 fG(g,1,`<path d="M150 136 q8 -8 16 0 q-8 6 -16 0 Z" fill="#B88A50" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="74" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Overboard Metal"]="Dandelion-Clock Sprite";SM("Overboard Metal","Drift Away","RES","s",0,100,"spd+1,dodge","One puff and it's gone over the fen.");

/* Overrulium: robots flagged it 212 times; humans overruled them 212 times. An eagle in a judge's wig, gavel raised. */
addForm("Overrulium",{n:"#5A3A2A",a:"#F4F0F4",rn:"#E8D8C8",rb:"#3A3A6A",ra:"#E8412C"},"stand",(P,g)=>`<rect x="20" y="118" width="70" height="26" fill="#6A4A2A" ${SW}/>`+fShadow(54,110)+
 pt("tail",136,104,`<path d="M130 100 L156 118 L146 124 L126 110 Z" fill="${P.ac}" ${SW}/>`)+
 pt("legB",116,118,`<path d="M116 116 L118 138" stroke="#E8B040" stroke-width="5"/><path d="M110 142 l8 -4 l8 4" stroke="${FI}" stroke-width="2.4" fill="none"/>`,.5)+
 `<path d="M84 106 Q84 76 108 72 Q132 76 134 106 Q126 122 108 122 Q90 122 84 106 Z" fill="${P.n}" ${SW}/><path d="M92 82 L108 100 L124 82" stroke="#F4F0F4" stroke-width="5" fill="none"/><path d="M100 84 Q108 76 116 84 L114 120 Q108 124 102 120 Z" fill="${FI}"/>`+
 pt("legF",100,118,`<path d="M100 116 L98 138" stroke="#E8B040" stroke-width="5"/><path d="M90 142 l8 -4 l8 4" stroke="${FI}" stroke-width="2.4" fill="none"/>`)+
 pt("wingF",86,92,`<path d="M88 90 Q70 84 62 70" stroke="${P.nd}" stroke-width="9" stroke-linecap="round"/><g transform="rotate(-30 58 64)"><rect x="40" y="56" width="24" height="12" rx="3" fill="#8A5A2A" ${SW}/><path d="M52 68 V90" stroke="#8A5A2A" stroke-width="4"/></g>`)+
 pt("head",104,64,`<circle cx="104" cy="58" r="15" fill="${P.ac}" ${SW}/>${E2(98,56,3.6,"#E8A020")}<path d="M92 50 l10 4" stroke="${FI}" stroke-width="2.4"/>`+
  `<path d="M92 62 L80 66 L90 70 Z" fill="${FMOUTH}"/>`+pt("beak",88,70,`<path d="M92 68 Q82 72 80 68 Q84 74 92 72 Z" fill="#E8B040" ${SW2}/>`)+`<path d="M94 58 Q80 58 78 68 Q84 64 92 64 Z" fill="#E8B040" ${SW2}/>`+
  `<path d="M90 50 Q90 34 104 34 Q120 34 120 50 Q124 62 122 76 Q118 64 116 50 Q110 44 104 44 Q96 44 92 50 Z" fill="#E8E4DC" ${SW}/>${[0,1,2].map(i=>`<circle cx="${120}" cy="${56+i*7}" r="3.4" fill="#E8E4DC" ${SW2}/>`).join("")}`)+
 fG(g,1,`<text x="150" y="40" font-size="10" font-weight="bold" fill="${P.ac}">212</text><path d="M150 46 h24" stroke="#C8302A" stroke-width="2"/>`)+fG(g,2,`<circle cx="108" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Overrulium"]="Gavel Eagle";SM("Overrulium","Overruled","RES","s",0,100,"cure,tatk-1","Objection noted. And dismissed.");
