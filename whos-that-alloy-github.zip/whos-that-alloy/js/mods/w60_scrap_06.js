/* ---- Tinker's Scrapyard, 6 ---- */
/* Clipboardite: inspectors came to shut the lab and left with the recipe on their clipboard. A hippo in a hard hat and hi-vis vest, clipboard in hand. */
addForm("Clipboardite",{n:"#9A8A9A",a:"#E8E040",rn:"#3A3A4A",rb:"#E8604A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(78)+
 pt("tail",164,98,`<path d="M162 100 l10 4" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 fLeg("legB",150,116,24,14,P.nd,P.ndd,.5)+fLeg("legB",116,118,22,14,P.nd,P.ndd,1.3)+
 `<path d="M80 106 Q78 74 122 72 Q164 74 166 104 Q162 124 124 124 Q84 124 80 106 Z" fill="${P.n}" ${SW}/><path d="M96 78 L150 78 L152 118 L94 118 Z" fill="${P.ac}" ${SW2}/><path d="M96 98 H152 M96 108 H152" stroke="#C8C8D0" stroke-width="4"/>`+
 fLeg("legF",142,118,22,14,P.n,P.ndd,0)+fLeg("legF",100,118,22,14,P.n,P.ndd,.8)+
 pt("armF",96,100,`<g transform="rotate(-10 72 96)"><rect x="60" y="84" width="22" height="28" rx="2" fill="#B88A50" ${SW2}/><rect x="63" y="90" width="16" height="19" fill="#F4F0E4"/><path d="M65 94 h12 M65 98 h12 M65 102 h8" stroke="#6A6A7A" stroke-width="1"/><rect x="66" y="82" width="10" height="4" fill="${P.b}" ${SW2}/></g>`)+
 pt("head",80,92,`<path d="M40 98 Q38 72 64 70 Q90 72 92 96 Q90 114 66 114 Q42 114 40 98 Z" fill="${P.n}" ${SW}/><ellipse cx="46" cy="98" rx="10" ry="12" fill="${P.nd}" ${SW2}/><ellipse cx="44" cy="92" rx="2.6" ry="2" fill="${FI}"/><ellipse cx="44" cy="100" rx="2.6" ry="2" fill="${FI}"/>${E2(66,84,3.6)}`+
  `<path d="M38 106 L60 108 L58 112 L40 110 Z" fill="${FMOUTH}"/>`+pt("jaw",54,111,`<path d="M58 110 Q46 122 38 108 Q46 116 58 113 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",80,74,`<ellipse cx="80" cy="72" rx="4" ry="5" fill="${P.n}" ${SW2}/>`)+
  `<path d="M50 72 Q50 52 68 52 Q86 52 86 72 Z" fill="#F2C94C" ${SW}/><path d="M44 72 H92" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M44 72 H92" stroke="#F2C94C" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M170 30 l12 0 l-6 10 Z" fill="${P.ac}" ${SW2}/><text x="174" y="38" font-size="7" font-weight="bold" fill="${FI}">!</text>`)+fG(g,2,`<circle cx="124" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Clipboardite"]="Safety-Inspector Hippo";SM("Clipboardite","Shut It Down","RES","s",0,100,"tatk-1,tspd-1","Under review, pending inspection, please stand back.");

/* Clockface Casting: every clock at the works stopped at 2:17. A barn owl whose round face is a clock stuck at 2:17. */
addForm("Clockface Casting",{n:"#D8B880",a:"#F4F0E4",rn:"#3A3A4A",rb:"#8A6A4A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 124 H194" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",116,114,`<path d="M110 112 L118 128 L102 128 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M80 116 Q78 80 104 76 Q130 80 128 116 Q120 126 104 126 Q88 126 80 116 Z" fill="${P.n}" ${SW}/><path d="M90 100 Q104 92 118 100 L116 120 Q104 124 92 120 Z" fill="${P.ac}"/>${[[98,104],[110,106],[104,114]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.4" fill="${P.nd}"/>`).join("")}`+
 pt("wingF",84,96,`<path d="M86 86 Q72 100 76 120 Q86 114 88 100 Z" fill="${P.nd}" ${SW}/>`)+pt("wingB",124,96,`<path d="M122 86 Q136 100 132 120 Q122 114 120 100 Z" fill="${P.nd}" ${SW}/>`,.4)+
 pt("legF",104,124,`<path d="M98 124 l-2 4 M104 124 v4 M110 124 l2 4" stroke="${FI}" stroke-width="2.4"/>`)+
 pt("head",104,58,`<path d="M78 58 Q78 32 104 30 Q130 32 130 58 Q126 80 104 82 Q82 80 78 58 Z" fill="${P.n}" ${SW}/><path d="M84 58 Q84 38 104 36 Q124 38 124 58 Q122 76 104 78 Q86 76 84 58 Z" fill="${P.ac}" ${SW2}/>${[0,1,2,3,4,5,6,7,8,9,10,11].map(i=>{const a=i/12*6.283;return`<path d="M${104+Math.sin(a)*17} ${58-Math.cos(a)*18} L${104+Math.sin(a)*19} ${58-Math.cos(a)*20}" stroke="${FI}" stroke-width="1.4"/>`}).join("")}${E2(96,54,3.6,"#1A1A1A")}${E2(112,54,3.6,"#1A1A1A")}<path d="M104 58 L110 52 M104 58 L106 66" stroke="#8A6A4A" stroke-width="1.8" stroke-linecap="round"/>`+
  `<path d="M101 62 L107 62 L104 70 Z" fill="${FMOUTH}"/>`+pt("beak",104,66,`<path d="M102 64 L106 64 L104 70 Z" fill="#C8A060" ${SW2}/>`))+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">2:17</text>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Clockface Casting"]="Stopped-Clock Barn Owl";SM("Clockface Casting","Time Stands Still","RES","s",0,100,"tspd-2","Every hand stops at 2:17, and so does everything else.");

/* Coastliner Metal: ticket inspectors bet on who'll first see its crate change trains. A caterpillar built like a little coastal steam train. */
addForm("Coastliner Metal",{n:"#3A6A4A",a:"#C8302A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"crawl",(P,g)=>`<path d="M14 144 H194" stroke="#6A4A2A" stroke-width="4"/>${[20,40,60,80,100,120,140,160,180].map(x=>`<path d="M${x} 140 v8" stroke="#6A4A2A" stroke-width="3"/>`).join("")}`+fShadow(80)+
 Array.from({length:4},(_,i)=>{const x=150-i*24;return pt(i%2?"legB":"legF",x,128,`<circle cx="${x-6}" cy="136" r="5" fill="${FI}"/><circle cx="${x+6}" cy="136" r="5" fill="${FI}"/><circle cx="${x-6}" cy="136" r="2" fill="${P.b}"/><circle cx="${x+6}" cy="136" r="2" fill="${P.b}"/>`,i*.2)+`<rect x="${x-11}" y="106" width="22" height="26" rx="4" fill="${i%2?P.n:P.ac}" ${SW}/><rect x="${x-6}" y="110" width="12" height="8" fill="#F2E080" ${SW2}/>`}).join("")+
 pt("slow",56,74,`<circle cx="56" cy="74" r="7" fill="#E8E8F0" opacity=".8"/><circle cx="48" cy="62" r="9" fill="#E8E8F0" opacity=".6"/><circle cx="38" cy="48" r="11" fill="#E8E8F0" opacity=".4"/>`)+
 pt("head",60,114,`<rect x="36" y="100" width="40" height="34" rx="8" fill="${P.n}" ${SW}/><rect x="52" y="82" width="10" height="20" fill="${FI}"/><path d="M36 128 L24 136 L36 134 Z" fill="${P.b}" ${SW2}/>${E2(48,112,4.2)}${E2(64,112,4.2)}`+HMOUTH(48,122,64,P,2.4)+pt("ant",44,100,`<path d="M42 100 L36 88 M48 100 L50 88" stroke="${FI}" stroke-width="2"/>`))+
 fG(g,1,`<rect x="160" y="30" width="26" height="14" rx="2" fill="#F4F0E4" ${SW2}/><circle cx="168" cy="37" r="2.4" fill="none" stroke="${FI}" stroke-width="1.2"/>`)+fG(g,2,`<circle cx="102" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,60,6)));
FORM_TITLE["Coastliner Metal"]="Steam-Train Caterpillar";SM("Coastliner Metal","All Aboard","STR","a",70,100,"spd+1@40","Chuff, chuff, chuff, all the way down the coast.");

/* Copier Room Blend: the procedure was photocopied upside down, so they did it backwards. An upside-down jellyfish, the real one that lies on its back. */
addForm("Copier Room Blend",{n:"#C8B890",a:"#7AB8A8",rn:"#3A3A4A",rb:"#E8A0C0",ra:"#F2C94C"},"ooze",(P,g)=>`<path d="M14 140 Q104 130 194 142 V150 H14 Z" fill="#E8D8B0" ${SW2}/>`+fShadow(60)+
 `<path d="M60 138 Q60 110 104 106 Q148 110 148 138 Z" fill="${P.n}" ${SW}/>${Array.from({length:8},(_,i)=>`<path d="M${68+i*10} 136 Q${70+i*10} 120 ${78+i*8} 112" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 Array.from({length:8},(_,i)=>{const a=-2.8+i*.37,x=104+Math.cos(a)*30,y=104+Math.sin(a)*24;return pt(i%2?"legB":"legF",x,y,`<path d="M104 106 Q${104+Math.cos(a)*16} ${104+Math.sin(a)*14} ${x} ${y}" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M104 106 Q${104+Math.cos(a)*16} ${104+Math.sin(a)*14} ${x} ${y}" stroke="${P.ac}" stroke-width="3.4" fill="none" stroke-linecap="round"/>${[0,1,2].map(k=>`<circle cx="${x+Math.cos(a+k)*4}" cy="${y+Math.sin(a+k)*4}" r="3.4" fill="${P.ac}" ${SW2}/>`).join("")}`,i*.12)}).join("")+
 pt("head",104,124,`${E2(94,124,3.6)}${E2(114,124,3.6)}`+HMOUTH(100,130,108,P,2))+
 fG(g,1,`<g transform="rotate(180 34 44)"><rect x="20" y="34" width="28" height="20" fill="#F4F0E4" ${SW2}/><text x="22" y="46" font-size="7" font-weight="bold" fill="${FI}">STEP 1</text></g>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Copier Room Blend"]="Upside-Down Jellyfish";SM("Copier Room Blend","Last Step First","RES","a",60,100,"tacc-1,tspd-1@30","Start at the end, finish at the start. It works, somehow.");

/* Cornerstonite: a hollow in the reading-room cornerstone exactly its size. A mason bee, the bee that builds in mortar, packing the joint shut. */
addForm("Cornerstonite",{n:"#5A4A3A",a:"#E8A040",rn:"#3A3A4A",rb:"#B8B0A0",ra:"#5FE0F0"},"hover",(P,g)=>`<rect x="110" y="70" width="84" height="76" fill="#C8B8A0" ${SW}/>${[90,110,130].map(y=>`<path d="M110 ${y} H194" stroke="#9A8A70" stroke-width="2"/>`).join("")}<path d="M150 70 V90 M130 90 V110 M170 90 V110 M150 110 V130 M130 130 V146 M170 130 V146" stroke="#9A8A70" stroke-width="2"/><rect x="134" y="94" width="20" height="12" fill="#3A2A1A"/><text x="114" y="142" font-size="8" font-weight="bold" fill="#8A7A60">MCMXII</text>`+
 `<ellipse class="shd" cx="80" cy="148" rx="24" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",88,74,`<ellipse cx="96" cy="58" rx="10" ry="20" fill="#E8F4F8" opacity=".75" ${SW2} transform="rotate(30 96 58)"/>`,.2)+
 pt("tail",108,96,`<path d="M100 92 Q122 90 124 100 Q122 110 100 106 Z" fill="${P.n}" ${SW}/>${[106,114].map(x=>`<path d="M${x} 92 v14" stroke="${P.ac}" stroke-width="3"/>`).join("")}`)+
 `<ellipse cx="86" cy="96" rx="16" ry="12" fill="${P.n}" ${SW}/><path d="M74 90 Q86 84 98 90" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 pt("wingF",80,74,`<ellipse cx="74" cy="56" rx="10" ry="20" fill="#E8F4F8" opacity=".8" ${SW2} transform="rotate(-20 74 56)"/>`)+
 [[78,"legF",0],[88,"legB",.3]].map(([x,c,d])=>pt(c,x,106,`<path d="M${x} 106 L${x-4} 118 L${x} 124" stroke="${FI}" stroke-width="2" fill="none"/>`,d)).join("")+
 pt("head",64,92,`<circle cx="62" cy="92" r="11" fill="${P.n}" ${SW}/>${E2(58,88,3.6,"#1A1A1A")}`+pt("jaw",54,100,`<path d="M54 98 l-4 4 M58 100 l-2 5" stroke="${FI}" stroke-width="2"/>`)+pt("ant",62,82,`<path d="M58 82 Q50 66 42 66 M64 82 Q66 66 74 62" stroke="${FI}" stroke-width="1.6" fill="none"/>`)+`<circle cx="48" cy="104" r="4" fill="#9A8A70" ${SW2}/>`)+
 fG(g,1,`<path d="M20 120 h20 v20 h-20 Z" fill="#C8B8A0" ${SW2}/>`)+fG(g,2,`<circle cx="86" cy="98" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Cornerstonite"]="Mortar Mason Bee";SM("Cornerstonite","Lay The Cornerstone","RES","s",0,100,"def+2","One stone set properly, and everything else stands on it.");

/* Countdown Mix: you open its storeroom by counting down from 100. A snail whose shell is a combination dial, counting down. */
addForm("Countdown Mix",{n:"#B8A890",a:"#2A2A30",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",146,132,`<path d="M140 132 Q160 134 172 136" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 `<path d="M44 136 Q46 124 70 122 L146 126 Q158 130 156 136 Z" fill="${P.n}" ${SW}/>`+
 `<circle cx="112" cy="96" r="32" fill="${P.b}" ${SW}/>`+pt("spin",112,96,`<circle cx="112" cy="96" r="26" fill="${P.d}" ${SW2}/>${Array.from({length:20},(_,i)=>{const a=i/20*6.283;return`<path d="M${112+Math.sin(a)*22} ${96-Math.cos(a)*22} L${112+Math.sin(a)*26} ${96-Math.cos(a)*26}" stroke="${P.ll}" stroke-width="${i%5?1:2.4}"/>`}).join("")}<circle cx="112" cy="96" r="10" fill="${P.b}" ${SW2}/><path d="M112 96 V84" stroke="${FI}" stroke-width="3"/>`)+`<path d="M112 60 l-4 -6 h8 Z" fill="${P.ac}" ${SW2}/>`+
 pt("head",58,118,`<path d="M58 124 Q54 106 60 96" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M58 124 Q54 106 60 96" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`+HMOUTH(48,114,56,P,2)+pt("ant",60,94,`<path d="M58 96 L50 74 M62 96 L66 74" stroke="${FI}" stroke-width="2.6"/>${E2(50,72,3.6)}${E2(66,72,3.6)}`))+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">100..99</text>`)+fG(g,2,`<circle cx="112" cy="130" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Countdown Mix"]="Combination-Dial Snail";SM("Countdown Mix","Countdown","RES","s",0,100,"spd+1,acc+1","Ninety-nine, ninety-eight... and click.");

/* Crackerjack Mix: a 1952 cracker joke asks what its crate said to the postman; the answer was never printed. A reindeer in a paper cracker crown, cracker in its teeth. */
addForm("Crackerjack Mix",{n:"#8A6A4A",a:"#E8D8C0",rn:"#3A3A4A",rb:"#C8302A",ra:"#F2C94C"},"stand",(P,g)=>fShadow(70)+
 pt("tail",156,92,`<path d="M154 92 Q164 86 166 94 Q160 100 154 98 Z" fill="${P.ac}" ${SW2}/>`)+
 fLeg("legB",144,106,34,8,P.nd,P.ndd,.5)+fLeg("legB",114,108,32,8,P.nd,P.ndd,1.3)+
 `<path d="M88 100 Q88 78 120 76 Q152 78 156 98 Q152 114 122 114 Q92 114 88 100 Z" fill="${P.n}" ${SW}/><path d="M90 104 Q120 116 152 104" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 fLeg("legF",136,108,32,8,P.n,P.ndd,0)+fLeg("legF",100,108,32,8,P.n,P.ndd,.8)+
 pt("head",92,86,`<path d="M96 92 Q86 78 82 68" stroke="${P.n}" stroke-width="14" stroke-linecap="round"/><path d="M54 70 Q56 56 74 56 Q88 58 88 70 Q84 80 72 80 L58 78 Z" fill="${P.n}" ${SW}/><circle cx="55" cy="72" r="4" fill="#C8302A" ${SW2}/>${E2(72,64,3.4,"#1A1A1A")}`+
  `<path d="M58 76 L70 78 L68 82 L60 80 Z" fill="${FMOUTH}"/>`+pt("jaw",66,81,`<path d="M70 80 Q62 86 58 80 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(-10 52 84)"><rect x="40" y="80" width="26" height="8" fill="#5AB04A" ${SW2}/><path d="M40 80 l-6 -2 v12 l6 -2 M66 80 l6 -2 v12 l-6 -2" fill="#5AB04A" ${SW2}/><path d="M48 80 v8 M58 80 v8" stroke="#F2C94C" stroke-width="2"/></g>`)+
  pt("ant",76,54,`<path d="M74 56 L66 36 L58 32 M68 42 L60 44 M80 56 L90 38 L98 34 M88 42 L96 44" stroke="#6A4A2A" stroke-width="4" fill="none" stroke-linecap="round"/>`)+`<path d="M64 56 L68 46 L72 54 L76 44 L80 54 L84 46 L86 56 Z" fill="#E8604A" ${SW2}/>`)+
 fG(g,1,`<rect x="160" y="30" width="28" height="20" fill="#F4F0E4" ${SW2}/><text x="162" y="42" font-size="6" fill="${FI}">Q: what did...</text>`)+fG(g,2,`<circle cx="122" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Crackerjack Mix"]="Cracker-Crowned Reindeer";SM("Crackerjack Mix","Pull The Cracker","STR","a",65,100,"tacc-1@50","Snap! And a terrible joke falls out.");

/* Cranite: a polite figure in a bowler hat asks the watchman each night whether it's ready. That figure: a tall, thin shadow in a bowler hat, very courteous. */
addForm("Cranite",{n:"#2A2A3A",a:"#E8D8A0",rn:"#E8D8C8",rb:"#5A5A7A",ra:"#F2C94C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="4" fill="#000" opacity=".25"/>`+
 pt("tail",104,128,`<path d="M88 112 Q84 138 96 140 Q104 148 112 140 Q124 138 120 112 Z" fill="${P.n}" opacity=".85" ${SW}/>`)+
 `<path d="M86 116 Q80 72 104 62 Q128 72 122 116 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",88,80,`<path d="M88 80 Q70 86 64 102" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M88 80 Q70 86 64 102" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/>`)+
 pt("armB",120,80,`<path d="M120 80 Q140 72 146 54" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M120 80 Q140 72 146 54" stroke="${P.n}" stroke-width="4.4" fill="none" stroke-linecap="round"/>`,.4)+
 pt("head",104,48,`<ellipse cx="104" cy="48" rx="13" ry="15" fill="${P.n}" ${SW}/><ellipse cx="98" cy="48" rx="3" ry="2" fill="${P.ac}"/><ellipse cx="110" cy="48" rx="3" ry="2" fill="${P.ac}"/>`+pt("jaw",104,56,`<path d="M100 56 q4 3 8 0" stroke="${P.ac}" stroke-width="1.4" fill="none"/>`)+
  pt("ear",104,32,`<g transform="rotate(-8 104 32)"><ellipse cx="104" cy="34" rx="18" ry="4" fill="${FI}"/><path d="M92 34 Q92 16 104 16 Q116 16 116 34 Z" fill="${FI}"/><path d="M92 30 h24" stroke="#6A6A8A" stroke-width="2"/></g>`))+
 fG(g,1,`<text x="20" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">is it ready?</text>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Cranite"]="Bowler-Hatted Shadow";SM("Cranite","Polite Enquiry","RES","s",0,100,"tacc-1,tspd-1","Terribly sorry to bother you. Is it ready yet?");

/* Crashex: whenever the inventory system crashes, the last line is its code. A moth taped into a logbook, the first ever computer 'bug'. */
addForm("Crashex",{n:"#8A7A6A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8412C"},"hover",(P,g)=>`<rect x="20" y="40" width="168" height="104" fill="${P.ac}" ${SW}/>${[56,68,80,92,104,116,128].map(y=>`<path d="M26 ${y} H182" stroke="#9AB8E8" stroke-width="1"/>`).join("")}<text x="28" y="54" font-size="7" fill="${FI}" font-family="monospace">15:45 Relay #70</text><text x="28" y="136" font-size="7" fill="${FI}" font-family="monospace">first actual case of bug</text><rect x="70" y="72" width="16" height="8" fill="#F4E8A0" opacity=".8" transform="rotate(-20 78 76)"/><rect x="120" y="72" width="16" height="8" fill="#F4E8A0" opacity=".8" transform="rotate(20 128 76)"/>`+
 pt("wingB",112,92,`<path d="M108 92 Q140 64 150 84 Q148 104 112 102 Z" fill="${P.nd}" ${SW}/>`,.2)+
 `<path d="M100 82 Q104 76 108 82 L108 112 Q104 118 100 112 Z" fill="${P.n}" ${SW}/>${[90,98,106].map(y=>`<path d="M100 ${y} h8" stroke="${P.nd}" stroke-width="1.4"/>`).join("")}`+
 pt("wingF",100,92,`<path d="M100 92 Q68 64 58 84 Q60 104 96 102 Z" fill="${P.n}" ${SW}/><circle cx="74" cy="86" r="5" fill="none" stroke="${P.nd}" stroke-width="1.6"/>`)+
 pt("head",104,76,`<circle cx="104" cy="74" r="7" fill="${P.n}" ${SW}/>${E2(101,72,2.4,"#1A1A1A")}${E2(108,72,2.4,"#1A1A1A")}`+pt("ant",104,66,`<path d="M101 66 Q94 56 86 56 M107 66 Q114 56 122 56" stroke="${FI}" stroke-width="1.4" fill="none"/>`))+
 fG(g,1,`<text x="150" y="30" font-size="9" font-weight="bold" fill="#C8302A" font-family="monospace">ERR</text>`)+fG(g,2,`<circle cx="104" cy="98" r="2.4" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,26,6)));
FORM_TITLE["Crashex"]="Logbook Bug Moth";SM("Crashex","System Crash","RES","a",65,100,"irr@30","Something got into the works. Everything stops.");

/* Crate 89 Special: crate 88 was chairs, 89 was this; the movers disagreed. A gopher spinning round and round on an office swivel chair. */
addForm("Crate 89 Special",{n:"#B8804A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#3A3A44",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(60)+
 `<path d="M104 120 V136" stroke="${FI}" stroke-width="6"/>${[-28,-14,0,14,28].map(d=>`<path d="M104 136 L${104+d} 142" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><circle cx="${104+d}" cy="143" r="3" fill="${FI}"/>`).join("")}`+
 pt("spin",104,104,`<rect x="74" y="108" width="60" height="12" rx="5" fill="#3A3A44" ${SW}/><rect x="120" y="70" width="12" height="44" rx="5" fill="#3A3A44" ${SW}/>`)+
 pt("tail",120,108,`<path d="M118 106 l10 -2" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`)+
 `<path d="M82 108 Q80 82 102 78 Q124 82 122 108 Z" fill="${P.n}" ${SW}/><path d="M90 108 Q90 92 102 90 Q114 92 114 108" fill="${P.ac}"/>`+
 pt("armF",88,94,fOL("M88 94 Q76 92 72 82",P.n,6))+pt("armB",118,94,fOL("M118 94 Q130 88 132 76",P.n,6),.4)+
 pt("head",100,66,`<path d="M80 66 Q80 46 100 44 Q120 46 120 66 Q116 80 100 80 Q84 80 80 66 Z" fill="${P.n}" ${SW}/><ellipse cx="94" cy="72" rx="8" ry="6" fill="${P.ac}"/><circle cx="88" cy="68" r="2.6" fill="${FI}"/>${E2(94,60,3.6,"#1A1A1A",[.4,-.4])}${E2(108,58,3.6,"#1A1A1A",[.4,-.4])}`+HMOUTH(88,76,96,P,2)+`<rect x="90" y="79" width="4" height="5" fill="#fff" ${SW2}/><rect x="94" y="79" width="4" height="5" fill="#fff" ${SW2}/>`+pt("ear",114,48,`<circle cx="114" cy="48" r="4" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 60 a14 6 0 1 0 28 0" stroke="${P.ac}" stroke-width="2" fill="none"/><path d="M58 60 l-2 -5 l-3 4" stroke="${P.ac}" stroke-width="2" fill="none"/><text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}">89</text>`)+fG(g,2,`<circle cx="102" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Crate 89 Special"]="Swivel-Chair Gopher";SM("Crate 89 Special","Spin Round","STR","a",55,100,"tacc-1@40,multi:1-2","Wheeee. Again. Wheeee.");
