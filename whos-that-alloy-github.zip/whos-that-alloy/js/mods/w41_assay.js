/* =============== ASSAYS: the Sample Case and the battle ===============
   Registered alloys can be carried in a Sample Case and set against other researchers' samples. Nothing here is a made-up number:
   every stat comes from the alloy's real density, hardness, melting point, conductivity and magnetism, and every move tests one real
   property of its target. Outside an Assay a sample is a rod or a vial; inside one it wakes up. */
const GRADES=["Raw","Worked","Tempered","Masterwork"],GRADE_XP=[0,60,200,500],GRADE_MUL=[1,1.08,1.16,1.25];
const AS={on:false};
function asData(){const d=store.get("wta_assay",null)||{};d.case=d.case||[];d.rad=d.rad||{};d.xp=d.xp||{};d.hp=d.hp||{};d.seals=d.seals||[];d.beat=d.beat||{};d.eq=d.eq||{};return d}
function asSave(d){store.set("wta_assay",d)}
const alloyByName=n=>ALLOYS.find(a=>a.name===n);
function gradeOf(xp){let g=0;for(let i=0;i<4;i++)if(xp>=GRADE_XP[i])g=i;return g}
function caseSlots(){return Math.min(6,3+Math.floor(asData().seals.length/2))}
function obeyGrade(){return Math.min(3,1+Math.floor(asData().seals.length/3))}
/* ---- what an alloy is, in numbers it never shows ---- */
function aSum(a,els){const w=frac(a);return els.reduce((s,e)=>s+(w[e]||0),0)}
function aReact(a){return aSum(a,["Li","Na","K","Rb","Cs","Fr"])+aSum(a,["Ca","Sr","Ba","Ra"])*.6+aSum(a,["La","Ce","Pr","Nd","Sm","Eu"])*.5+aSum(a,["U","Pu","Np","Th"])*.3+aSum(a,["Mg"])*.25}
function aNoble(a){return Math.min(1,aSum(a,["Au","Pt","Pd","Ir","Os","Rh","Ru"])+.7*aSum(a,["Ag"])+.55*aSum(a,["Cr","Ti","Ta","Nb","Zr"])+.35*aSum(a,["Ni","Mo","W","Sn"]))}
function aTox(a){return aSum(a,["Tl","As","Hg","Cd","Po"])+.8*aSum(a,["Be"])+.6*aSum(a,["Pb"])+.4*aSum(a,["Sb"])}
const hasT=(a,t)=>(a.types||[]).includes(t);
function aAff(a){const h=a.hard||0,d=a.d||1,mp=a.mp,c=a.cond||0,cat=(a.cat||"").toLowerCase();return{
  SCR:h/5,STR:1-Math.abs(h-4.5)/6+(hasT(a,"Structural")?.3:0),DRP:d/9,HEA:Math.max(0,mp)/1500+(hasT(a,"Reactive")?.5:0)+(hasT(a,"Heat-proof")?.3:0),
  CUR:c/30,PUL:(a.mag||0)*.6,QUE:aReact(a)*2+(hasT(a,"Liquid")?.6:0),COR:aTox(a)*2+(aSum(a,["Hg","Ga"])>=.1?.8:0)+(aSum(a,["Zn","Cd"])>=.2?.5:0),
  RAD:hasT(a,"Radioactive")?1.2:0,RES:(h/6)*(1-Math.min(d,24)/25)+(/bell|organ|speaker|chime/.test(cat)?.6:0)}}
function topClasses(a){const f=aAff(a);let L=Object.entries(f).sort((x,y)=>y[1]-x[1]);let k=L.filter(([c,v])=>v>=.55).slice(0,4).map(x=>x[0]);if(k.length<2)k=L.slice(0,2).map(x=>x[0]);return k}
/* Every alloy gets the same overall budget; its properties only decide where that budget goes. A hard alloy bites harder but has
   less to fall back on; a soft, heavy one soaks up punishment; a light one is quick. Rarity adds a little on top. */
const RAR_MUL={common:1,uncommon:1.02,rare:1.05,legendary:1.09};
function aStats(a,g){const d=Math.min(a.d||1,24),h=a.hard||0,nt=(a.types||[]).length,m=GRADE_MUL[g]*(RAR_MUL[a.rar]||1);
  const raw={max:1+.012*d+(h<2.5?.25:0),atk:.55+.11*h,def:.6+.08*h+.015*d,draw:.7+.08*nt+(a.cond||0)/110+(a.mag||0)*.12+(hasT(a,"Radioactive")?.2:0)+(hasT(a,"Reactive")?.2:0)+aTox(a)*.4,
    ward:.65+Math.max(0,Math.min(3400,a.mp))/3200+aNoble(a)*.4+(a.mp<350?.25:0),spd:Math.max(.45,1.55-d/13)+(hasT(a,"Lightweight")?.2:0)};
  const K=5.5/(Object.values(raw).reduce((x,y)=>x+y,0)-raw.spd*.5),base={max:165,atk:62,def:62,draw:62,ward:62,spd:70},o={};
  for(const k in raw)o[k]=base[k]*raw[k]*K*m;o.max=Math.round(o.max);return o}
/* ---- which moves an alloy can learn, and when ---- */
const PROP_RULES={vdense:a=>a.d>=15,vlight:a=>a.d<2.2,vhard:a=>a.hard>=7.5,vsoft:a=>a.hard<=1.5&&a.mp>=25,vhot:a=>a.mp>=2400,vcold:a=>a.mp<25,vcond:a=>a.cond>=55,vinsul:a=>a.cond<=1.2,
  strongmag:a=>a.mag===2,eddyable:a=>a.cond>=30,noble:a=>aNoble(a)>=.7,basemetal:a=>aNoble(a)<=.08&&aReact(a)<.3,hotrad:a=>hasT(a,"Radioactive")&&aSum(a,["Po","Ra","Pu","Cm","Am","Cf","Fr","At","Ac"])>=.15,
  glassy:a=>a.hard>=5.5&&a.d<5,toughmid:a=>a.hard>=3.5&&a.hard<=5.5&&hasT(a,"Structural"),multi:a=>a.comp.length>=5,pure:a=>a.comp[0][1]>=92};
function learnset(a){if(learnset.c[a.name])return learnset.c[a.name];const out=[],add=(id,g)=>{if(!MV[id])return;const o=out.find(x=>x.id===id);if(o)o.g=Math.min(o.g,g);else out.push({id,g})};
  const cls=topClasses(a);MOVES.forEach(m=>{const s=m.src.split(":");
    if(s[0]==="b"&&cls.includes(s[1]))add(m.id,+s[2]);
    else if(s[0]==="t"){const i=(a.types||[]).indexOf(s[1]);if(i>=0)add(m.id,i===0?0:1)}
    else if(s[0]==="e"){const p=(a.comp.find(c=>c[0]===s[1])||[0,0])[1];if(p>=25)add(m.id,0);else if(p>=5)add(m.id,1)}
    else if(s[0]==="p"){if(PROP_RULES[s[1]]&&PROP_RULES[s[1]](a))add(m.id,2)}
    else if(s[0]==="g")add(m.id,+s[1])});
  const cat=String(a.cat||"").toLowerCase()+" "+String(a.uses||"").toLowerCase().split(/[,;]/)[0];
  KW.forEach(([keys,ids])=>{if(keys.some(k=>new RegExp("\\b"+k).test(cat)))ids.forEach(n=>add(n.toLowerCase().replace(/[^a-z0-9]+/g,"_"),0))});
  return learnset.c[a.name]=out}
learnset.c={};
function movesAt(a,g){return learnset(a).filter(x=>x.g<=g).map(x=>MV[x.id])}
function autoEquip(a,g){const L=movesAt(a,g),cls=topClasses(a),pick=[],atk=L.filter(m=>m.k==="a");
  const best=c=>atk.filter(m=>m.c===c&&!pick.includes(m)).sort((x,y)=>y.p*y.acc-x.p*x.acc)[0];
  cls.forEach(c=>{const m=best(c);if(m&&pick.length<3)pick.push(m)});
  const sup=L.filter(m=>m.k!=="a").sort((x,y)=>(y.src[0]==="g")-(x.src[0]==="g"))[0];if(sup)pick.push(sup);
  atk.filter(m=>!pick.includes(m)).sort((x,y)=>y.p*y.acc-x.p*x.acc).forEach(m=>{if(pick.length<4)pick.push(m)});
  L.filter(m=>!pick.includes(m)).forEach(m=>{if(pick.length<4)pick.push(m)});return pick.slice(0,4).map(m=>m.id)}
/* ---- how hard a test lands, from the real numbers ---- */
const PHYS={SCR:1,STR:1,DRP:1,RES:1};
const clamp2=(v,a,b)=>Math.max(a,Math.min(b,v));
function asEff(c,A,D){const a=A.a,d=D.a;switch(c){
  case"SCR":return clamp2(1+((a.hard||0)-(d.hard||0))*.17,.45,1.9);
  case"STR":return hasT(d,"Liquid")?.4:clamp2(.45+.19*(d.hard||0),.5,1.9);
  case"DRP":return clamp2(Math.pow((a.d||1)/(d.d||1),.4),.6,1.7);
  case"HEA":return clamp2(1.8-d.mp/1500,.4,1.9);
  case"CUR":return clamp2(1.8-(d.cond||0)/35,.4,1.8);
  case"PUL":return D.curie?.35:d.mag===2?2:d.mag===1?1.3:.35;
  case"QUE":return clamp2(.6+2.2*aReact(d)+(hasT(d,"Liquid")?.2:0),.5,2);
  case"COR":return clamp2(1.6-1.4*aNoble(d),.35,1.8);
  case"RAD":return clamp2(.55+(d.d||1)/14,.5,1.7);
  case"RES":return hasT(d,"Liquid")?.4:clamp2(.6+(d.hard||0)/6-(d.d||1)/25,.4,1.8)}return 1}
function effWord(e){return e>=1.6?"It bit deep.":e>=1.15?"It found a weak spot.":e<=.6?"It barely left a mark.":e<=.85?"It didn't do much.":""}
/* ---- a sample in an Assay ---- */
function mkMon(a,g,moves,hpFrac){const s=aStats(a,g);const m={a,g,s,hp:Math.max(0,Math.round(s.max*(hpFrac==null?1:hpFrac))),st:{atk:0,def:0,spd:0,draw:0,ward:0,acc:0},crit:0,fx:{},moves:moves||autoEquip(a,g),aff:aAff(a),cls:topClasses(a)};return m}
const stg=v=>v>=0?(2+v)/2:2/(2-v);
function fxParse(s){return s?s.split(",").filter(Boolean).map(t=>{const[k,ch]=t.split("@");return{k,ch:ch?+ch:100}}):[]}
const sleep=ms=>AS.sim?Promise.resolve():new Promise(r=>{AS.skip=r;setTimeout(r,AS.fast?ms/3:ms)});
async function asSay(t,ms){const L=$("#as-log");if(!L)return;L.textContent=t;await sleep(ms||900)}
function monName(m,side){return(side==="o"?(AS.B.foe.trainer?"The opposing ":"The wild "):"")+m.a.name}
function asDraw(){const B=AS.B;if(!B||!$("#as-p"))return;["p","o"].forEach(sd=>{const m=B[sd].team[B[sd].act],box=$("#as-"+sd);if(!m||!box)return;
  box.querySelector(".as-name").textContent=m.a.name;box.querySelector(".as-grade").textContent=GRADES[m.g].toUpperCase();
  const f=m.hp/m.s.max;const bar=box.querySelector(".as-bar i");bar.style.width=(f*100).toFixed(1)+"%";bar.className=f>.5?"ok":f>.2?"mid":"low";
  box.querySelector(".as-hp").textContent=sd==="p"?`${m.hp} / ${m.s.max}`:"";
  const ss=[];if(m.fx.brittle)ss.push("BRITTLE");if(m.fx.corrode)ss.push("CORRODING");if(m.fx.irr)ss.push("IRRADIATED");if(m.fx.oxid)ss.push("OXIDISED");if(m.fx.mag)ss.push("HELD");if(m.fx.molten)ss.push("SOFTENED");
  box.querySelector(".as-st").textContent=ss.join(" · ");
  const fm=box.querySelector(".as-form"),oc=!!(m.ocd&&hasForm(m.a)),fk=asKey(m);if(fm.dataset.n!==fk&&!fm._morph){fm.dataset.n=fk;fm.classList.remove("faint");fm.innerHTML=oc?battleForm(m.a,m.g,m.rad):ocSpec(m.a,m.g);fm.classList.toggle("flip",!oc);fm.classList.toggle("rad",!!m.rad);fm.style.setProperty("--gl",m.a.color)}});
  $("#as-dots-p").innerHTML=B.p.team.map(m=>`<i class="${m.hp>0?"":"out"}"></i>`).join("");$("#as-dots-o").innerHTML=B.o.team.map(m=>`<i class="${m.hp>0?"":"out"}"></i>`).join("")}
/* the battle form. Each alloy is getting its own; until its design is finished, the sample itself stands in, awake. */
const hasForm=a=>typeof BATTLE_FORMS!=="undefined"&&!!BATTLE_FORMS[a.name];
function battleForm(a,g,rad){return hasForm(a)?`<div class="as-bf g${g}${rad?" rad":""}"><div class="as-flip">${BATTLE_FORMS[a.name](a,g,!!rad)}</div></div>`:`<div class="as-temp g${g}">${specimenSVG(a)}</div>`}
function radOwned(a){return !!(recOf(a).rad)}
function radOn(a){const d=asData();return radOwned(a)&&!!(d.rad&&d.rad[a.name])}
function asMenu(){const B=AS.B,m=B.p.team[B.p.act],el=$("#as-menu");if(!el)return;
  el.innerHTML=`<div class="as-moves">${m.moves.map((id,i)=>{const mv=MV[id];if(!mv)return"";const C=ACLS[mv.c];return`<button class="as-mv" data-i="${i}" style="--c:${C.c}"><b>${mv.n}</b><span>${C.n.toUpperCase()} · ${mv.k==="a"?"PWR "+mv.p:mv.k==="g"?"GUARD":"STATUS"}</span></button>`}).join("")}</div>
   <div class="as-opts"><button class="btn as-sw">SWITCH</button><button class="btn as-cc">CONCEDE</button></div>`;
  el.querySelectorAll(".as-mv").forEach(b=>b.onclick=()=>asTurn({mv:m.moves[+b.dataset.i]}));
  el.querySelector(".as-sw").onclick=()=>asSwitchMenu(false);el.querySelector(".as-cc").onclick=()=>{asMenuOff();asEnd(false,true)};
  el.querySelectorAll(".as-mv").forEach(b=>{const mv=MV[m.moves[+b.dataset.i]];b.title=ACLS[mv.c].d+"\n"+mv.sci})}
function asMenuOff(){const el=$("#as-menu");if(el)el.innerHTML=""}
function asSwitchMenu(forced){const B=AS.B,el=$("#as-menu");const cur=B.p.team[B.p.act];
  if(!forced&&cur.fx.mag){asSay(`${cur.a.name} is held fast. It can't be switched out.`,1);return}
  el.innerHTML=`<div class="as-swl">${B.p.team.map((m,i)=>`<button class="as-swb" data-i="${i}" ${m.hp<=0||i===B.p.act?"disabled":""}>${m.a.name}<span>${GRADES[m.g]} · ${Math.round(m.hp/m.s.max*100)}%</span></button>`).join("")}</div>${forced?"":`<div class="as-opts"><button class="btn as-bk">BACK</button></div>`}`;
  el.querySelectorAll(".as-swb").forEach(b=>b.onclick=()=>forced?AS.pickNext(+b.dataset.i):asTurn({sw:+b.dataset.i}));const bk=el.querySelector(".as-bk");if(bk)bk.onclick=asMenu}
function aiPick(B){const o=B.o.team[B.o.act],p=B.p.team[B.p.act];let best=null,bs=-1;
  o.moves.forEach(id=>{const m=MV[id];if(!m)return;let sc;
    if(m.k==="a"){const e=asEff(m.c,o,p);sc=m.p*e*(m.acc/100)*(o.cls.includes(m.c)?1.2:1)*(/multi/.test(m.fx)?2.5:1)}
    else{sc=25;if(/heal/.test(m.fx))sc=o.hp/o.s.max<.45?90:5;if(/def\+|ward\+|film|sink|refrac|ground|dodge|endure/.test(m.fx))sc=o.hp/o.s.max>.6?(B.turn<3?55:20):10;
      if(/irr|corrode|mag/.test(m.fx))sc=(p.fx.irr||p.fx.corrode||p.fx.mag)?5:45;if(/atk\+|draw\+/.test(m.fx))sc=B.turn<3&&o.hp/o.s.max>.7?60:15}
    sc*=.8+Math.random()*(B.foe.smart?.3:.6);if(sc>bs){bs=sc;best=id}});return best}
function asCanAct(m){return m&&m.hp>0}
async function asTurn(choice){const B=AS.B;if(!B||B.busy)return;B.busy=true;asMenuOff();B.turn++;
  const P=B.p,O=B.o;let pm=P.team[P.act],om=O.team[O.act];
  const oc={mv:aiPick(B)};
  /* switching always happens first */
  if(choice.sw!=null){await asSay(`${pm.a.name}, come back.`,700);await asCool("p");P.act=choice.sw;pm=P.team[P.act];asDraw();await asSay(`Go, ${pm.a.name}!`,800);await asOC("p")}
  const acts=[];if(choice.mv)acts.push({side:"p",mv:choice.mv});acts.push({side:"o",mv:oc.mv});
  const pri=a=>/prio/.test(MV[a.mv].fx)?1:0,spd=s=>{const m=B[s].team[B[s].act];return m.s.spd*stg(m.st.spd)};
  acts.sort((x,y)=>pri(y)-pri(x)||spd(y.side)-spd(x.side)||Math.random()-.5);
  acts.forEach(ac=>ac.mon=B[ac.side].team[B[ac.side].act]);
  for(const ac of acts){if(B[ac.side].team[B[ac.side].act]!==ac.mon)continue;const me=B[ac.side].team[B[ac.side].act],them=B[ac.side==="p"?"o":"p"].team[B[ac.side==="p"?"o":"p"].act];
    if(!asCanAct(me)||!asCanAct(them))continue;await asUse(ac.side,me,them,MV[ac.mv]);asDraw();if(await asFaints())return}
  /* end of the turn: what keeps working */
  for(const sd of["p","o"]){const m=B[sd].team[B[sd].act];if(!m||m.hp<=0)continue;await asTick(sd,m);asDraw()}
  if(await asFaints())return;B.busy=false;asMenu()}
async function asTick(sd,m){const F=m.fx,nm=m.a.name;
  if(F.corrode){const d=Math.max(1,Math.round(m.s.max/12));m.hp=Math.max(0,m.hp-d);await asSay(`${nm} is still corroding.`,700);if(--F.corrode<=0)delete F.corrode}
  if(F.irr){const d=Math.max(1,Math.round(m.s.max*F.irr));m.hp=Math.max(0,m.hp-d);await asSay(`${nm} takes the dose.`,700);F.irr/=2;if(F.irr<1/64)delete F.irr}
  if(F.patina&&F.patina>0){m.st.def=Math.min(6,m.st.def+1);F.patina--}
  ["oxid","mag","sink","refrac","ground","film","qguard","nodrop","noirr","brittle","scrguard"].forEach(k=>{if(F[k]>0){F[k]--;if(!F[k])delete F[k]}})}
async function asFaints(){const B=AS.B;
  for(const sd of["o","p"]){const T=B[sd],m=T.team[T.act];if(m.hp>0)continue;
    sfx("miss");if(m.ocd){asSay(`${m.a.name} folds back into its ${m.a.form==="vial"?"vial":"rod"}.`,0);await asCool(sd);asAnim(sd,"faint",0);await sleep(500)}else{asAnim(sd,"faint",0);await asSay(`${m.a.name} folds back into its ${m.a.form==="vial"?"vial":"rod"}.`,1000)}
    if(sd==="o"){const gain=12+6*m.g+(B.foe.leader?10:0);asGiveXp(B.p.team[B.p.act],gain);
      const nx=T.team.findIndex(q=>q.hp>0);if(nx<0){await asEnd(true);return true}
      T.act=nx;asDraw();await asSay(`${B.foe.n} sends out ${T.team[nx].a.name}.`,1000);await asOC("o")}
    else{const nx=T.team.findIndex(q=>q.hp>0);if(nx<0){await asEnd(false);return true}
      if(AS.sim)T.act=nx;else await new Promise(r=>{AS.pickNext=i=>{T.act=i;r()};asSwitchMenu(true)});asDraw();await asSay(`Go, ${T.team[T.act].a.name}!`,800);await asOC("p")}}
  return false}
function asGiveXp(m,n){const d=asData();const k=m.a.name;const was=gradeOf(d.xp[k]||0);d.xp[k]=(d.xp[k]||0)+n;asSave(d);m.xpGain=(m.xpGain||0)+n;
  const now=gradeOf(d.xp[k]);if(now>was)AS.B.ups.push([k,now])}
async function asUse(side,me,them,mv){const B=AS.B,nm=(side==="o"?"The opposing ":"")+me.a.name;
  if(me.fx.molten){delete me.fx.molten;await asSay(`${nm} is too soft to do anything this turn.`,900);return}
  if(side==="p"&&me.g>obeyGrade()&&Math.random()<.25){await asSay(`${me.a.name} won't take orders from you yet. It ignores you.`,1100);return}
  let c=mv.c;const F=fxParse(mv.fx),has=k=>F.some(f=>f.k===k);
  if(has("anyclass"))c=Object.keys(ACLS)[Math.random()*10|0];if(has("bestclass"))c=me.cls[0];
  asAnim(side,"atk-"+side,450);await asSay(`${nm} used ${mv.n}!`,750);
  if(mv.k==="a"){
    const accv=mv.acc*stg(me.st.acc);if(!has("nomiss")&&Math.random()*100>accv){sfx("miss");await asSay("It missed.",700);return}
    if(them.fx.dodge){delete them.fx.dodge;sfx("miss");await asSay(`${them.a.name} wasn't there.`,700);return}
    if(c==="COR"&&them.fx.film){them.fx.film--;if(!them.fx.film)delete them.fx.film;sfx("click");await asSay(`The surface film took it. Nothing got through.`,900);return}
    if(c==="RAD"&&them.fx.sink){sfx("click");await asSay(`It was soaked up before it reached anything.`,900);return}
    if(c==="CUR"&&them.fx.ground){sfx("click");await asSay(`The current ran harmlessly to ground.`,900);return}
    if(c==="QUE"&&them.fx.qguard){sfx("click");await asSay(`The water did nothing to it.`,900);return}
    const mt=has("multi")?F.find(f=>f.k.startsWith("multi")):null,mf=(mv.fx.match(/multi:(\d)-(\d)/)||[]);const hits=mf.length?(+mf[1]+(Math.random()*(+mf[2]-+mf[1]+1)|0)):1;
    const e=asEff(c,me,them);let tot=0;
    for(let h=0;h<hits&&them.hp>0;h++){
      const phys=PHYS[c],A=phys?me.s.atk*stg(me.st.atk):me.s.draw*stg(me.st.draw)*(me.fx.oxid?.8:1),D=phys?them.s.def*stg(them.st.def):them.s.ward*stg(them.st.ward);
      let dmg=(mv.p*A/D*.45+2)*e*(me.cls.includes(c)?1.2:1)*(.88+Math.random()*.12);
      const crit=Math.random()<(has("crit")?.25:1/16)+me.crit*.08;if(crit)dmg*=1.5;
      if(them.fx.brittle&&(c==="SCR"||c==="DRP"||c==="STR"))dmg*=1.5;
      if(c==="HEA"&&them.fx.refrac)dmg*=.5;if(c==="SCR"&&them.fx.scrguard)dmg*=.5;
      if(has("eddy")&&(them.a.cond||0)>=25)dmg*=1.6;if(has("amalg")&&hasT(them.a,"Precious"))dmg*=1.5;if(has("galv"))dmg*=1+Math.abs(aNoble(me.a)-aNoble(them.a))*.8;
      dmg=Math.max(1,Math.round(dmg));
      if(them.hp-dmg<=0&&them.fx.endure){dmg=them.hp-1;delete them.fx.endure;them.endured=1}
      them.hp=Math.max(0,them.hp-dmg);tot+=dmg;sfx({SCR:"scratch",STR:"clunk",DRP:"thud",HEA:"sizzle",CUR:"spark",PUL:"clack",QUE:"splash",COR:"fizz",RAD:"beep",RES:"plunk"}[c]||"thud");
      asHit(side==="p"?"o":"p");asDraw();if(crit)await asSay("A perfect strike.",600);if(hits>1)await sleep(250)}
    if(hits>1)await asSay(`It hit ${hits} times.`,700);
    const w=effWord(e);if(w)await asSay(w,800);
    if(them.endured){delete them.endured;await asSay(`${them.a.name} held together by a thread.`,900)}
    const dr=mv.fx.match(/drain:(\d+)/);if(dr&&tot){me.hp=Math.min(me.s.max,me.hp+Math.round(tot*dr[1]/100));await asSay(`${me.a.name} drew some of it back into itself.`,700)}
    const rc=mv.fx.match(/recoil:(\d+)/);if(rc&&tot){me.hp=Math.max(0,me.hp-Math.max(1,Math.round(tot*rc[1]/100)));await asSay(`${me.a.name} took some of it back.`,700)}
    if(c==="HEA"&&them.hp>0&&them.a.mp<350&&(has("molten")?Math.random()<.3:false)){them.fx.molten=1;await asSay(`${them.a.name} has gone soft in the heat.`,800)}}
  /* effects, to the user or the target */
  for(const f of F){if(f.ch<100&&Math.random()*100>=f.ch)continue;const k=f.k.split(":")[0];let tgt=null,msg=null;
    let mm=k.match(/^(t?)(self)?(atk|def|spd|draw|ward|acc)([+-]\d)$/);
    if(mm){const who=mm[1]?them:me,st=mm[3],v=+mm[4];if(who===them&&them.hp<=0)continue;if(who===them&&them.fx.nodrop&&v<0){await asSay(`${them.a.name} doesn't budge.`,700);continue}
      who.st[st]=clamp2(who.st[st]+v,-6,6);await asSay(`${who.a.name}'s ${({atk:"bite",def:"guard",spd:"speed",draw:"energy",ward:"resistance",acc:"aim"})[st]} ${v>0?"rose":"fell"}${Math.abs(v)>1?" sharply":""}.`,700);continue}
    if(k.startsWith("selfspd")){me.st.spd=clamp2(me.st.spd-1,-6,6);continue}
    if(k==="selfoxid"){me.fx.oxid=3;await asSay(`${me.a.name} is scaled over from its own fire.`,700);continue}
    if(them.hp>0)switch(k){
      case"brittle":if(!them.fx.brittle){them.fx.brittle=3;await asSay(`${them.a.name} has gone brittle.`,700)}break;
      case"corrode":if(!them.fx.corrode&&!them.fx.film){them.fx.corrode=4;await asSay(`${them.a.name} has started to corrode.`,700)}break;
      case"irr":if(!them.fx.irr&&!them.fx.noirr&&!them.fx.sink){them.fx.irr=1/8;await asSay(`${them.a.name} has taken a dose.`,700)}break;
      case"oxid":if(!them.fx.oxid){them.fx.oxid=3;await asSay(`${them.a.name} is scaled over.`,700)}break;
      case"mag":if(!them.fx.mag&&them.a.mag>0){them.fx.mag=3;await asSay(`${them.a.name} is held fast.`,700)}else if(them.a.mag===0&&mv.k!=="a")await asSay(`Nothing to grip. ${them.a.name} isn't magnetic.`,800);break;
      case"curie":if(!them.curie&&them.a.mag>0){them.curie=1;await asSay(`${them.a.name} lost its magnetism in the heat.`,800)}else if(mv.k!=="a")await asSay("It had no effect.",700);break;
      case"molten":break;}
    switch(k){
      case"heal":{const n=+((mv.fx.match(/heal:(\d+)/)||[])[1]||0);if(n){const b=me.hp;me.hp=Math.min(me.s.max,me.hp+Math.round(me.s.max*n/100));if(me.hp>b)await asSay(`${me.a.name} pulled itself back together.`,700)}break}
      case"film3":case"film5":me.fx.film=k==="film5"?5:3;await asSay(`A protective film forms over ${me.a.name}.`,700);break;
      case"patina":me.fx.patina=3;me.fx.film=2;await asSay(`A crust begins to form over ${me.a.name}.`,700);break;
      case"sink":me.fx.sink=3;await asSay(`${me.a.name} is ready to soak up radiation.`,700);break;
      case"refrac":me.fx.refrac=3;await asSay(`${me.a.name} braces against the heat.`,700);break;
      case"ground":me.fx.ground=2;await asSay(`${me.a.name} is grounded.`,700);break;
      case"qguard":me.fx.qguard=2;break;
      case"scrguard":me.fx.scrguard=3;await asSay(`${me.a.name}'s surface hardens.`,700);break;
      case"dodge":me.fx.dodge=1;await asSay(`${me.a.name} gets ready to slip aside.`,700);break;
      case"endure":if(!me.endUsed){me.fx.endure=1;me.endUsed=1;await asSay(`${me.a.name} braces to hold together.`,700)}break;
      case"cure":["brittle","corrode","irr","oxid","mag","molten"].forEach(x=>delete me.fx[x]);break;
      case"nodrop":me.fx.nodrop=3;break;case"noirr":me.fx.noirr=4;delete me.fx.irr;break;
      case"nocurie":delete me.curie;break;
      case"crit":if(mv.k!=="a"){me.crit=Math.min(3,me.crit+1);await asSay(`${me.a.name} is focusing.`,700)}break}}}
function asAnim(sd,k,ms){const f=document.querySelector(`#as-${sd} .as-form`);if(!f)return;f.classList.remove(k);void f.offsetWidth;f.classList.add(k);if(ms)setTimeout(()=>f.classList.remove(k),ms)}
function asHit(sd){const f=document.querySelector(`#as-${sd} .as-form`);if(!f)return;f.classList.remove("hit");void f.offsetWidth;f.classList.add("hit")}
/* ---- starting and finishing an Assay ---- */
function asTeamFromCase(){const d=asData();return d.case.map(n=>alloyByName(n)).filter(Boolean).map(a=>{const g=gradeOf(d.xp[a.name]||0);const eq=(d.eq[a.name]||[]).filter(id=>MV[id]&&movesAt(a,g).some(m=>m.id===id));const m=mkMon(a,g,eq.length?eq:autoEquip(a,g),d.hp[a.name]);m.rad=radOn(a);return m})}
function asStart(foe,done){const team=asTeamFromCase();
  if(!team.length){talk("",["Your Sample Case is empty. Open the CASE and choose which registered samples to carry."]);done&&done(null);return}
  if(!team.some(m=>m.hp>0)){talk("",["Every sample in your case is spent. Rest them at a bench first."]);done&&done(null);return}
  const ot=foe.team.map(([n,g])=>{const a=alloyByName(n);return a&&mkMon(a,g)}).filter(Boolean);
  AS.B={p:{team,act:team.findIndex(m=>m.hp>0)},o:{team:ot,act:0},foe,turn:0,busy:true,ups:[],done};AS.on=true;EXP.busy=true;EXP.path=null;
  AS.prevTrack=AU.want;startTrack(foe.leader?"assay_leader":"assay");
  let el=$("#assay");if(!el){el=document.createElement("div");el.id="assay";document.body.appendChild(el)}
  el.className="assay "+(EXP.zone?EXP.zone.cls:"");el.hidden=false;
  el.innerHTML=`<div class="as-wrap"><div class="as-top"><b>ASSAY</b><span>${foe.title?foe.title.toUpperCase()+" ":""}${foe.n.toUpperCase()}</span></div>
   <div class="as-field"><div class="as-side as-o" id="as-o"><div class="as-plate"><div class="as-nl"><b class="as-name"></b><span class="as-grade"></span></div><div class="as-bar"><i></i></div><div class="as-hp"></div><div class="as-st"></div><div class="as-dots" id="as-dots-o"></div></div><div class="as-form"></div></div>
   <div class="as-side as-p" id="as-p"><div class="as-form"></div><div class="as-plate"><div class="as-nl"><b class="as-name"></b><span class="as-grade"></span></div><div class="as-bar"><i></i></div><div class="as-hp"></div><div class="as-st"></div><div class="as-dots" id="as-dots-p"></div></div></div></div>
   <div class="as-log" id="as-log"></div><div class="as-menu" id="as-menu"></div></div>`;
  el.querySelector("#as-log").onclick=()=>AS.skip&&AS.skip();
  (async()=>{asDraw();await asSay(`${foe.n} wants to settle this with an Assay.`,1100);await asSay(`${foe.n} sends out ${ot[0].a.name}.`,900);await asOC("o");await asSay(`Go, ${AS.B.p.team[AS.B.p.act].a.name}!`,900);await asOC("p");AS.B.busy=false;asMenu()})()}
async function asEnd(won,conceded){const B=AS.B;if(!B)return;asMenuOff();
  const d=asData();B.p.team.forEach(m=>{d.hp[m.a.name]=m.hp/m.s.max});
  if(won){B.p.team.forEach(m=>{if(m.hp>0){d.xp[m.a.name]=(d.xp[m.a.name]||0)+8}});sfx("right");await asSay(`You won the Assay against ${B.foe.n}.`,1200)}
  else{await asSay(conceded?"You concede the Assay.":"Your case is spent. You lost the Assay.",1300)}
  asSave(d);
  for(const[k,g]of B.ups){await asSay(`${k} is ${["","now Worked","now Tempered","a Masterwork"][g]}.`,1200)}
  const gained=B.p.team.filter(m=>m.xpGain).map(m=>m.a.name);if(gained.length)await asSay(`Tempered by the Assay: ${gained.join(", ")}.`,1000);
  if(AS.sim){AS.B=null;B.done&&B.done(!!won);return}
  $("#assay").hidden=true;AS.on=false;AS.B=null;EXP.busy=false;startTrack(typeof zoneTrack==="function"&&S.phase==="explore"?zoneTrack():AS.prevTrack||"explore");
  B.done&&B.done(!!won)}
function asHealAll(){const d=asData();d.hp={};asSave(d)}
{const _st=step;step=function(dx,dy){if(AS.on)return false;return _st(dx,dy)}}
{const _nr=newRun;newRun=function(){asHealAll();return _nr.apply(this,arguments)}}
/* ---- the Sample Case ---- */
function openCase(){const m=modal("samplecase","SAMPLE CASE"),d=asData(),L=m.querySelector(".bag-list"),slots=caseSlots();
  const row=(a,i)=>{const g=gradeOf(d.xp[a.name]||0),hp=d.hp[a.name]==null?1:d.hp[a.name],eq=(d.eq[a.name]&&d.eq[a.name].length?d.eq[a.name]:autoEquip(a,g));
    return`<div class="bag-item cs-row"><div class="cs-ic">${specimenSVG(a)}</div><div><b>${a.name}</b><p>${GRADES[g]} · ${hp<=0?"spent":Math.round(hp*100)+"% sound"} · ${eq.map(id=>MV[id]?MV[id].n:"").join(", ")}</p></div><div class="cs-btns">${radOwned(a)?`<button class="btn cs-rad${(d.rad||{})[a.name]?" on":""}" data-n="${a.name}">${(d.rad||{})[a.name]?"RADIANT":"STANDARD"}</button>`:""}<button class="btn cs-mv" data-n="${a.name}">MOVES</button><button class="btn cs-rm" data-i="${i}">REMOVE</button></div></div>`};
  const inCase=d.case.map(alloyByName).filter(Boolean);
  L.innerHTML=`<p class="bag-empty">Carry up to ${slots} registered samples. More room comes with Assay Seals. Contained threats can't be signed out.</p>`+inCase.map(row).join("")+
   (inCase.length<slots?`<h5 class="bag-h">ADD A SAMPLE</h5><input class="cs-q" placeholder="Search your register" aria-label="Search your register"><div class="cs-add"></div>`:"");
  const fill=q=>{const box=L.querySelector(".cs-add");if(!box)return;const ok=ALLOYS.filter(a=>S.caught.has(a.name)&&!a.threat&&!d.case.includes(a.name)&&(!q||a.name.toLowerCase().includes(q)));
    box.innerHTML=ok.length?ok.slice(0,60).map(a=>`<button class="cs-pick" data-n="${a.name}">${a.name}<span>${GRADES[gradeOf(d.xp[a.name]||0)]}</span></button>`).join("")+(ok.length>60?`<p class="bag-empty">${ok.length-60} more. Search to narrow it down.</p>`:""):`<p class="bag-empty">${S.caught.size?"Nothing else in your register can go in the case.":"Register some alloys out in the field first."}</p>`;
    box.querySelectorAll(".cs-pick").forEach(b=>b.onclick=()=>{const D=asData();if(D.case.length>=caseSlots())return;D.case.push(b.dataset.n);asSave(D);sfx("sel");openCase()})};
  fill("");const q=L.querySelector(".cs-q");if(q)q.oninput=()=>fill(q.value.trim().toLowerCase());
  L.querySelectorAll(".cs-rm").forEach(b=>b.onclick=()=>{const D=asData();D.case.splice(+b.dataset.i,1);asSave(D);openCase()});
  L.querySelectorAll(".cs-mv").forEach(b=>b.onclick=()=>openMoves(b.dataset.n));L.querySelectorAll(".cs-rad").forEach(b=>b.onclick=()=>{const D=asData();D.rad=D.rad||{};D.rad[b.dataset.n]=!D.rad[b.dataset.n];asSave(D);sfx("sel");openCase()});m.hidden=false}
function openMoves(n){const a=alloyByName(n);if(!a)return;const m=modal("samplemoves","MOVES"),d=asData(),g=gradeOf(d.xp[n]||0),L=m.querySelector(".bag-list");
  let eq=(d.eq[n]&&d.eq[n].length?d.eq[n]:autoEquip(a,g)).slice();const all=learnset(a).slice().sort((x,y)=>x.g-y.g);
  const draw=()=>{L.innerHTML=`<p class="bag-empty"><b>${n}</b>, ${GRADES[g]}. Pick up to four moves. Tempering in Assays unlocks the rest.</p>`+all.map(x=>{const mv=MV[x.id],C=ACLS[mv.c],on=eq.includes(x.id),lock=x.g>g;
     return`<button class="mv-row${on?" on":""}${lock?" lock":""}" data-id="${x.id}" ${lock?"disabled":""} style="--c:${C.c}"><b>${mv.n}</b><span>${C.n.toUpperCase()} · ${mv.k==="a"?"PWR "+mv.p:mv.k==="g"?"GUARD":"STATUS"}${lock?" · "+GRADES[x.g].toUpperCase():""}</span><em>${mv.sci}</em></button>`}).join("");
    L.querySelectorAll(".mv-row:not(.lock)").forEach(b=>b.onclick=()=>{const id=b.dataset.id;if(eq.includes(id)){if(eq.length>1)eq=eq.filter(x=>x!==id)}else if(eq.length<4)eq.push(id);else{eq.shift();eq.push(id)}
      const D=asData();D.eq[n]=eq;asSave(D);sfx("sel");draw()})};
  draw();m.hidden=false;const bk=m.querySelector(".bag-top .btn");bk.onclick=()=>{m.hidden=true;openCase()}}
{const a=$(".audio");if(a){const b=document.createElement("button");b.className="aubtn";b.id="casebtn";b.textContent="CASE";b.onclick=openCase;a.prepend(b)}}
/* ---- music ---- */
TRACKS["assay"]={base:"battle",bpm:150,swing:.08,lead:{type:"square",vol:.08,stac:true},parts:[{k:"chug",type:"sawtooth",vol:.03,oct:3},{k:"arp",type:"pulse",vol:.022,oct:5}],bass:{s:"octave",vol:.26},drum:"k h s h k k s h",fill:"k s k s s s c c"};
TRACKS["assay_leader"]={base:"battle",bpm:160,swing:0,lead:{type:"sawtooth",vol:.07,stac:true},parts:[{k:"power",type:"square",vol:.04,oct:3},{k:"ostinato",type:"triangle",vol:.05,oct:5},{k:"counter",type:"pulse",vol:.03,oct:5}],bass:{s:"root8",type:"square",vol:.13},drum:"k . s k k k s .",fill:"k k s s k s c c"};
