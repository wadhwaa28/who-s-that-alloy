/* =============== LANTERN NIGHT, ROUND FIVE: SHADOW PEOPLE ===============
   The stalker is redrawn as one of them: far too tall, far too thin, arms down past its knees, long fingers, two pale empty eyes and a grin.
   Every part moves on its own: it sways, its head twitches, its fingers flex, smoke comes off it. And now it has company. */
/* one shared filter makes every shadow's edges smoky */
(function(){if($("#shade-defs"))return;const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.id="shade-defs";s.setAttribute("width","0");s.setAttribute("height","0");s.style.position="absolute";
  s.innerHTML=`<defs><filter id="shdF" x="-40%" y="-20%" width="180%" height="140%"><feTurbulence type="fractalNoise" baseFrequency="1.1" numOctaves="2" seed="7" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="2.2" xChannelSelector="R" yChannelSelector="G" result="d"/><feGaussianBlur in="d" stdDeviation=".45"/></filter>
   <filter id="shdG" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="1.1" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
   <radialGradient id="shdFog" cx=".5" cy=".9" r=".6"><stop offset="0" stop-color="#06050C" stop-opacity=".55"/><stop offset="1" stop-color="#06050C" stop-opacity="0"/></radialGradient></defs>`;document.body.appendChild(s)})();
/* ---- shadow people, drawn as what they are: solid dark that softens at the edges like ink in water, too tall or too stooped,
   legs that run down into the ground, long clawed fingers, pinprick eyes, and grins with far too many teeth. Six kinds, each
   its own body: the gaunt one, the stooped tattered one, the heavy blurred one, the smooth grinning one, the one whose lower half
   is tendrils, and the one that's just a silhouette with eyes. The rig (body, legs, arms, hands, head, face) is kept so they move. */
(function(){const d=$("#shade-defs");if(!d||d.querySelector("#shdInk"))return;d.querySelector("defs").insertAdjacentHTML("beforeend",
  `<filter id="shdInk" x="-40%" y="-20%" width="180%" height="140%"><feGaussianBlur in="SourceGraphic" stdDeviation=".45" result="d"/>
    <feGaussianBlur in="SourceAlpha" stdDeviation="1.8" result="b"/><feFlood flood-color="#050409" flood-opacity=".6"/><feComposite in2="b" operator="in" result="halo"/><feMerge><feMergeNode in="halo"/><feMergeNode in="d"/></feMerge></filter>
   <filter id="shdBlur" x="-50%" y="-30%" width="200%" height="160%"><feGaussianBlur in="SourceGraphic" stdDeviation="1.2" result="s"/>
    <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="b"/><feFlood flood-color="#050409" flood-opacity=".5"/><feComposite in2="b" operator="in" result="halo"/><feMerge><feMergeNode in="halo"/><feMergeNode in="s"/></feMerge></filter>
   <linearGradient id="shdDrip" gradientUnits="userSpaceOnUse" x1="0" y1="60" x2="0" y2="100"><stop offset="0" stop-color="#050409"/><stop offset=".7" stop-color="#050409" stop-opacity=".85"/><stop offset="1" stop-color="#050409" stop-opacity="0"/></linearGradient>`)})();
const SB="#050409";
/* white pinprick eyes */
const shEyes=(a,b,r)=>`<g filter="url(#shdG)" class="sh-eyes"><circle cx="${a[0]}" cy="${a[1]}" r="${r||.65}" fill="#F6F2FF"/><circle cx="${b[0]}" cy="${b[1]}" r="${r||.65}" fill="#F6F2FF"/></g>`;
/* a row of big white teeth in a dark mouth */
const shTeeth=(x,y,w,h,n)=>{const cx=x+w/2,up=t=>y+h*.18-Math.sin(Math.PI*t)*h*.22,lo=t=>y+h*.18+Math.sin(Math.PI*t)*h*.95;
  let t=`<g class="sh-grin" style="transform-origin:${cx}px ${y+h/2}px"><path d="M${x-.5} ${y+h*.1} Q${cx} ${y-h*.4} ${x+w+.5} ${y+h*.1} Q${cx} ${y+h*1.5} ${x-.5} ${y+h*.1} Z" fill="#0A0814"/><path d="M${x} ${y+h*.18} Q${cx} ${y-h*.26} ${x+w} ${y+h*.18} Q${cx} ${y+h*1.36} ${x} ${y+h*.18} Z" fill="#EEEAF2"/>`;
  t+=`<path d="M${x+.3} ${y+h*.3} Q${cx} ${y+h*.62} ${x+w-.3} ${y+h*.3}" stroke="${SB}" stroke-width=".3" fill="none"/>`;
  for(let i=1;i<n;i++){const f=i/n,X=(x+w*f).toFixed(2);t+=`<path d="M${X} ${up(f).toFixed(2)} L${(x+w*f+(f-.5)*.3).toFixed(2)} ${(lo(f)-.1).toFixed(2)}" stroke="${SB}" stroke-width=".32"/>`}return t+`</g>`};
/* long jointed fingers fanning from a wrist */
const shClaw=(x,y,dir,len,spread)=>[-2,-1,0,1,2].map(i=>{const a=(90+i*(spread||11)-dir*8)*Math.PI/180,l=len*(1-Math.abs(i)*.08),mx=x+Math.cos(a)*l*.5+dir*.6,my=y+Math.sin(a)*l*.5,ex=x+Math.cos(a)*l+dir*1.2,ey=y+Math.sin(a)*l;
  return`<path d="M${x} ${y} L${mx.toFixed(1)} ${my.toFixed(1)} Q${(ex+dir*.6).toFixed(1)} ${(my+l*.3).toFixed(1)} ${ex.toFixed(1)} ${ey.toFixed(1)}" stroke="${SB}" stroke-width="${(.85-Math.abs(i)*.08).toFixed(2)}" fill="none" stroke-linecap="round"/>`}).join("");
/* ink running down to the ground from a point */
const shStreaks=(x0,x1,y,n,seed)=>{const R=mulberry(seed||7);let s="";for(let i=0;i<n;i++){const x=x0+(x1-x0)*R(),l=6+R()*(99-y);s+=`<path d="M${x.toFixed(1)} ${y} q${((R()-.5)*1.6).toFixed(1)} ${(l/2).toFixed(1)} ${((R()-.5)*1.2).toFixed(1)} ${l.toFixed(1)}" stroke="url(#shdDrip)" stroke-width="${(.5+R()*1.1).toFixed(1)}" fill="none" stroke-linecap="round"/>`}return s};
/* torn strands hanging off an edge */
const shFringe=(pts,seed)=>{const R=mulberry(seed||3);return pts.map(([x,y,l])=>`<path d="M${x} ${y} q${((R()-.5)*2).toFixed(1)} ${(l*.5).toFixed(1)} ${((R()-.5)*1.6).toFixed(1)} ${l}" stroke="${SB}" stroke-width="${(.4+R()*.7).toFixed(1)}" fill="none" stroke-linecap="round" opacity="${(.6+R()*.4).toFixed(2)}"/>`).join("")};
const shWisps=()=>"";
const shLimb=(cls,ox,oy,body)=>`<g class="${cls}" style="transform-origin:${ox}px ${oy}px">${body}</g>`;
const SHADE_ART={
 /* too tall and too thin; small head out in front on a long neck; arms down past the knees; the grin is all teeth */
 gaunt:()=>({f:"shdInk",body:`<path d="M13.6 22 Q12.6 34 15.2 46 L16 55 L24 55 L24.6 46 Q27.4 34 26.6 22 Q20 18.6 13.6 22 Z" fill="${SB}"/><path d="M19 21 Q19.4 16 20.6 12.4" stroke="${SB}" stroke-width="2.6" stroke-linecap="round" fill="none"/>`,
   legL:shLimb("sh-legL",17,54,`<path d="M15.4 54 L18.6 54 L17.6 74 L18 97 L15.6 97 L15 74 Z" fill="url(#shdDrip)"/>${shStreaks(14.6,18.4,80,5,4)}`),
   legR:shLimb("sh-legR",23,54,`<path d="M21.6 54 L24.8 54 L25.6 74 L24.4 97 L22.2 97 L22.8 74 Z" fill="url(#shdDrip)"/>${shStreaks(21.8,25.2,80,5,9)}`),
   armL:shLimb("sh-armL",14,23,`<path d="M14 22.6 Q10.4 34 10 47 Q9.8 60 10.8 73" stroke="${SB}" stroke-width="2.1" fill="none" stroke-linecap="round"/><g class="sh-handL" style="transform-origin:10.8px 73px">${shClaw(10.8,73,-1,13,10)}</g>`),
   armR:shLimb("sh-armR",26,23,`<path d="M26 22.6 Q29.8 34 30 47 Q30.4 60 29.2 72" stroke="${SB}" stroke-width="2.1" fill="none" stroke-linecap="round"/><g class="sh-handR" style="transform-origin:29.2px 72px">${shClaw(29.2,72,1,13,10)}</g>`),
   head:[21.4,13],headPath:`<ellipse cx="21.6" cy="8.4" rx="3.7" ry="5" fill="${SB}" transform="rotate(8 21.6 8.4)"/>`,
   face:shEyes([20.3,7.2],[23.2,7.6],.55)+shTeeth(18.8,9.8,5.6,2.6,7),wisps:[[20,4],[16,22],[25,22]]}),
 /* bent nearly double, ragged all over, one long arm reaching out with its claws open */
 stoop:()=>({f:"shdInk",body:`<path d="M10 30 Q14 18 24 20 Q31 24 30 36 Q30 50 28 62 L14 64 Q12 50 10 30 Z" fill="${SB}"/>${shFringe([[14,62,30],[16,63,34],[18,64,33],[20,64,35],[22,63,34],[24,63,32],[26,62,33],[28,60,31],[12,56,20],[29,50,22],[30,40,14]],12)}`,
   legL:shLimb("sh-legL",17,62,`<path d="M15.6 60 L18.6 60 L18 96 L15.6 96 Z" fill="url(#shdDrip)"/>`),legR:shLimb("sh-legR",24,62,`<path d="M22.8 60 L25.8 60 L25.6 96 L23 96 Z" fill="url(#shdDrip)"/>`),
   armL:shLimb("sh-armL",12,30,`<path d="M12 30 Q5 30 -2 25 Q-6 22 -8 18" stroke="${SB}" stroke-width="2.4" fill="none" stroke-linecap="round"/>${shFringe([[0,25,9],[3,28,11],[6,29,12],[9,30,10],[-4,22,7]],21)}<g class="sh-handL" style="transform-origin:-8px 18px">${shClaw(-8,18,-1,9,16).replace(/M(-?[\d.]+) (-?[\d.]+) L/g,(m,a,b)=>`M${a} ${b} L`)}</g>`),
   armR:shLimb("sh-armR",28,32,`<path d="M28 32 Q32 46 30 64 Q29.6 70 30.4 76" stroke="${SB}" stroke-width="2.2" fill="none" stroke-linecap="round"/>${shFringe([[31,46,12],[31,56,12],[30.6,64,10]],33)}<g class="sh-handR" style="transform-origin:30.4px 76px">${shClaw(30.4,76,1,10,10)}</g>`),
   head:[12,28],headPath:`<path d="M12 27 Q9 26 8.6 22 Q8.6 17.6 12.4 17.4 Q16 17.6 16 21.6 Q15.6 25.6 12 27 Z" fill="${SB}"/>${shFringe([[9,24,6],[10.4,26,7],[14.4,25,6]],41)}`,
   face:shEyes([10.8,21],[13.6,21.2],.55)+shTeeth(10,23,4.4,2,5),wisps:[[13,16],[24,20]]}),
 /* heavy and broad, so soft at the edges it hardly has any; a small head and a grin right across it */
 hulk:()=>({f:"shdBlur",body:`<path d="M6 34 Q6 24 14 22 L26 22 Q34 24 34 34 Q35 52 31 68 L9 68 Q5 52 6 34 Z" fill="${SB}"/>`,
   legL:shLimb("sh-legL",14,66,`<path d="M9.6 64 L18.6 64 L18 97 L10 97 Z" fill="url(#shdDrip)"/>`),legR:shLimb("sh-legR",26,66,`<path d="M21.4 64 L30.4 64 L30 97 L22 97 Z" fill="url(#shdDrip)"/>`),
   armL:shLimb("sh-armL",8,28,`<path d="M8 28 Q2 44 3 62 Q3.4 68 4.4 72" stroke="${SB}" stroke-width="5" fill="none" stroke-linecap="round"/><g class="sh-handL" style="transform-origin:4.4px 72px">${shClaw(4.4,72,-1,7,12)}</g>`),
   armR:shLimb("sh-armR",32,28,`<path d="M32 28 Q38 44 37 62 Q36.6 68 35.6 72" stroke="${SB}" stroke-width="5" fill="none" stroke-linecap="round"/><g class="sh-handR" style="transform-origin:35.6px 72px">${shClaw(35.6,72,1,7,12)}</g>`),
   head:[20,22],headPath:`<ellipse cx="20" cy="17" rx="6.4" ry="7" fill="${SB}"/>`,
   face:`<g filter="url(#shdG)" class="sh-eyes"><circle cx="17.4" cy="15" r=".8" fill="#FFE8E0"/><circle cx="22.6" cy="15" r=".8" fill="#FFE8E0"/></g>`+shTeeth(14.4,18,11.2,3.4,10),wisps:[[20,9],[10,24],[30,24]]}),
 /* smooth and tall, broad across the shoulders, and the face is nothing but a white crescent grin and two white crescent eyes */
 slender:()=>({f:"shdInk",body:`<path d="M9 25 Q10 22 15 21.4 L25 21.4 Q30 22 31 25 Q30.6 34 27 42 Q25 50 24.6 56 L15.4 56 Q15 50 13 42 Q9.4 34 9 25 Z" fill="${SB}"/><path d="M18 21 V16 M22 21 V16" stroke="${SB}" stroke-width="2.6"/>`,
   legL:shLimb("sh-legL",17,55,`<path d="M15.2 54 L19.4 54 L18.6 76 L18.4 97 L15.6 97 L15.4 76 Z" fill="url(#shdDrip)"/>`),legR:shLimb("sh-legR",23,55,`<path d="M20.6 54 L24.8 54 L24.6 76 L24.4 97 L21.6 97 L21.4 76 Z" fill="url(#shdDrip)"/>`),
   armL:shLimb("sh-armL",10,25,`<path d="M10 25 Q7 38 7.4 50 Q7.6 58 8.6 66" stroke="${SB}" stroke-width="2.8" fill="none" stroke-linecap="round"/><g class="sh-handL" style="transform-origin:8.6px 66px">${shClaw(8.6,66,-1,7,12)}</g>`),
   armR:shLimb("sh-armR",30,25,`<path d="M30 25 Q33 38 32.6 50 Q32.4 58 31.4 66" stroke="${SB}" stroke-width="2.8" fill="none" stroke-linecap="round"/><g class="sh-handR" style="transform-origin:31.4px 66px">${shClaw(31.4,66,1,7,12)}</g>`),
   head:[20,16],headPath:`<ellipse cx="20" cy="10" rx="5.2" ry="6.6" fill="${SB}"/>`,
   face:`<g filter="url(#shdG)"><g class="sh-eyes"><path d="M15.6 8.6 Q17.4 6.6 19 9 Q17.4 8.2 15.6 8.6 Z M24.4 8.6 Q22.6 6.6 21 9 Q22.6 8.2 24.4 8.6 Z" fill="#F6F2FF"/></g><path class="sh-grin" style="transform-origin:20px 12.6px" d="M15.4 11 Q20 17.4 24.6 11 Q20 14 15.4 11 Z" fill="#F6F2FF"/></g>`,wisps:[[20,3]]}),
 /* thin above the waist; below it, it has come apart into tendrils that curl across the ground */
 tendril:()=>({f:"shdInk",body:`<path d="M13.6 24 Q12.6 36 15 48 L16 56 L24 56 L25 48 Q27.4 36 26.4 24 Q20 20.6 13.6 24 Z" fill="${SB}"/><path d="M19.2 23 Q19.6 18 20.4 14" stroke="${SB}" stroke-width="2.4" stroke-linecap="round" fill="none"/>`,
   legL:shLimb("sh-legL",18,56,[[-14,92,-18,96,"3.2"],[-6,98,-12,90,"2.8"],[2,90,-4,99,"2.6"]].map(([a,b,c,d,w])=>`<path d="M17.4 55 Q${17+a*.2} 76 ${17+a*.6} ${b-6} Q${17+a} ${b} ${17+c} ${d} Q${17+c*1.2} ${d-4} ${17+c*.9} ${d-7}" stroke="${SB}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`).join("")),
   legR:shLimb("sh-legR",22,56,[[14,92,18,96,"3.2"],[6,98,12,90,"2.8"],[-2,90,4,99,"2.6"]].map(([a,b,c,d,w])=>`<path d="M22.6 55 Q${23+a*.2} 76 ${23+a*.6} ${b-6} Q${23+a} ${b} ${23+c} ${d} Q${23+c*1.2} ${d-4} ${23+c*.9} ${d-7}" stroke="${SB}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`).join("")),
   armL:shLimb("sh-armL",14,25,`<path d="M14 24.6 Q10.6 36 10.6 48 Q10.8 56 11.6 64" stroke="${SB}" stroke-width="2" fill="none" stroke-linecap="round"/><g class="sh-handL" style="transform-origin:11.6px 64px">${shClaw(11.6,64,-1,10,9)}</g>`),
   armR:shLimb("sh-armR",26,25,`<path d="M26 24.6 Q29.4 36 29.4 48 Q29.2 56 28.4 64" stroke="${SB}" stroke-width="2" fill="none" stroke-linecap="round"/><g class="sh-handR" style="transform-origin:28.4px 64px">${shClaw(28.4,64,1,10,9)}</g>`),
   head:[20.4,15],headPath:`<path d="M20.6 15.6 Q16.6 15 16.4 9.4 Q16.6 3.6 20.6 3.4 Q24.6 3.6 24.8 9.4 Q24.6 15 20.6 15.6 Z" fill="${SB}"/>`,
   face:`<g filter="url(#shdG)" class="sh-eyes"><circle cx="18.8" cy="7.6" r=".9" fill="none" stroke="#F6F2FF" stroke-width=".45"/><circle cx="22.4" cy="7.6" r=".9" fill="none" stroke="#F6F2FF" stroke-width=".45"/></g>`+shTeeth(18.4,10.4,4.4,3.8,6),wisps:[[20,2]]}),
 /* a plain dark figure standing a little too still, and two white points where its eyes would be */
 watch:()=>({f:"shdBlur",body:`<path d="M11 30 Q12 26 16 25 L24 25 Q28 26 29 30 Q29.4 44 26.6 56 L13.4 56 Q10.6 44 11 30 Z" fill="${SB}"/><path d="M18.4 25 V21 M21.6 25 V21" stroke="${SB}" stroke-width="2.4"/>`,
   legL:shLimb("sh-legL",17,55,`<path d="M13.6 54 L19.4 54 L18.6 97 L14.6 97 Z" fill="url(#shdDrip)"/>`),legR:shLimb("sh-legR",23,55,`<path d="M20.6 54 L26.4 54 L25.4 97 L21.4 97 Z" fill="url(#shdDrip)"/>`),
   armL:shLimb("sh-armL",12,29,`<path d="M12 29 Q9.6 42 10 58" stroke="${SB}" stroke-width="3" fill="none" stroke-linecap="round"/><g class="sh-handL" style="transform-origin:10px 58px"><ellipse cx="10" cy="60" rx="1.6" ry="2.4" fill="${SB}"/></g>`),
   armR:shLimb("sh-armR",28,29,`<path d="M28 29 Q30.4 42 30 58" stroke="${SB}" stroke-width="3" fill="none" stroke-linecap="round"/><g class="sh-handR" style="transform-origin:30px 58px"><ellipse cx="30" cy="60" rx="1.6" ry="2.4" fill="${SB}"/></g>`),
   head:[20,21],headPath:`<ellipse cx="20" cy="16" rx="4.6" ry="5.4" fill="${SB}"/>`,face:shEyes([18.2,15.4],[21.8,15.4],.7),wisps:[]})};
function shadeSVG(o){o=o||{};const k=SHADE_ART[o.t]?o.t:"gaunt",A=SHADE_ART[k](),[hx,hy]=A.head;
  return`<svg viewBox="0 0 40 100" aria-hidden="true" style="overflow:visible;width:100%;height:100%" class="shk-${k}"><ellipse cx="20" cy="99" rx="${k==="tendril"?16:k==="hulk"?14:10}" ry="2.8" fill="url(#shdFog)"/>
  <g class="sh-body" style="transform-origin:20px 99px"><g filter="url(#${A.f})">${A.legL}${A.legR}${A.body}${A.armL}${A.armR}<g class="sh-head" style="transform-origin:${hx}px ${hy}px">${A.headPath}</g></g>
   <g class="sh-head sh-face" style="transform-origin:${hx}px ${hy}px">${A.face}</g>${shWisps(A.wisps)}</g></svg>`}
const SHADE_KINDS=[{t:"gaunt"},{t:"stoop"},{t:"hulk"},{t:"slender"},{t:"tendril"},{t:"watch"}];
/* ---------------- the stalker, redrawn and re-rigged ---------------- */
const STK_SVG2=shadeSVG({t:"gaunt"});
stkEl=function(){if(STK.el&&STK.el.isConnected)return STK.el;const d=document.createElement("div");d.className="lnt-stalker";d.innerHTML=`<div class="stk-in">${STK_SVG2}</div><div class="stk-hand">${stkHandSVG()}</div>`;$("#world").appendChild(d);STK.el=d;return d};
function stkHandSVG(){return`<svg viewBox="0 0 20 30" aria-hidden="true" style="overflow:visible;width:100%;height:100%"><g filter="url(#shdF)">${[0,1,2,3].map(i=>`<path class="stk-fing" style="animation-delay:-${i*.25}s;transform-origin:2px ${8+i*4}px" d="M2 ${8+i*4} q6 -2 9 ${1+i} q3 1 2 4" stroke="#05040A" stroke-width="1.3" fill="none" stroke-linecap="round"/>`).join("")}<path d="M-6 10 Q0 12 2 20" stroke="#05040A" stroke-width="3" fill="none"/></g></svg>`}
stkPlace=function(c){const d=stkEl(),W=EXP.W,H=EXP.H;STK.cover=c;STK.side=EXP.x<c.x?-1:1;STK.wall=c.wall;
  d.style.width=(100/W)+"%";d.style.height=(250/H)+"%";d.style.left=(c.x/W*100)+"%";d.style.top=((c.y-1.5)/H*100)+"%";d.style.zIndex=c.wall?"200":String(9+2*c.y);
  d.className="lnt-stalker "+(c.wall?"wall":"prop")+(STK.side<0?" left":" right");d.style.setProperty("--jx","0");d.style.setProperty("--jy","0")};
stkJump=(function(_j){return function(){const c=STK.cover;if(c){const d=stkEl();d.style.setProperty("--jx",(EXP.x-c.x)*100+"%");d.style.setProperty("--jy",(EXP.y-c.y)*40+"%")}_j();if(STK.el&&c){STK.el.style.setProperty("--jx",(EXP.x-c.x)*100+"%");STK.el.style.setProperty("--jy",(EXP.y-c.y)*40+"%")}}})(stkJump);

/* ---------------- SHADOW PEOPLE ----------------
   They don't come in crowds. They exist, one here, one there, and any shadow at all will do as a door into the world: the shadow under
   a lantern, under a cart, at the foot of a wall, under somebody standing talking to you. One climbs up out of a shadow, looks about,
   and goes and gets into something: a person or a thing. While it's in there, that person or thing isn't quite itself. Then it climbs
   out again and goes back down into another shadow. Get close while one is up and about and it simply sinks back where it came from.
   In Hollowmere they're dangerous: two or three of them, well apart, rising out of the dark corners and closing in on you through the
   dark. Stand in the light and they leave you alone, and go and get into something else instead. */
const SHD={list:[],iv:null,cool:0,grabCool:0,said:false,next:0,poss:[]};
function shdNew(x,y,k){const d=document.createElement("div");d.className="lnt-shade";d.innerHTML=`<i class="sh-pool"></i>`+shadeSVG(SHADE_KINDS[k%SHADE_KINDS.length]);d.style.setProperty("--sd","-"+((x*7+y*3+k)%9)*.5+"s");$("#world").appendChild(d);
  const s={x,y,k,el:d,t:Math.random()*1.4,gone:false,mode:"look",wait:2+Math.random()*2};shdMove(s,x,y,true);SHD.list.push(s);shdRise(s);return s}
function shdMove(s,x,y,inst){s.x=x;s.y=y;const d=s.el;if(inst)d.style.transition="none";d.style.width=(100/EXP.W)+"%";d.style.height=(250/EXP.H)+"%";d.style.left=(x/EXP.W*100)+"%";d.style.top=((y-1.5)/EXP.H*100)+"%";d.style.zIndex=String(11+2*y);if(inst){void d.offsetWidth;d.style.transition=""}}
/* climbing up out of a shadow, and going back down into one */
function shdRise(s){s.gone=false;s.el.classList.remove("sink","fade");void s.el.offsetWidth;s.el.classList.add("rise");clearTimeout(s.rt);s.rt=setTimeout(()=>s.el.classList.remove("rise"),1500)}
function shdSink(s,after){if(s.gone)return;s.gone=true;s.el.classList.remove("rise");s.el.classList.add("sink");clearTimeout(s.rt);s.rt=setTimeout(()=>{after&&after()},1200)}
function shdVanish(s,ms){shdSink(s);s.back=ms||8000}
function shdDark(x,y){return inHollow()?!hmLightAt(x,y):true}
function shdClear(){SHD.list.forEach(s=>{clearTimeout(s.rt);s.el.remove()});SHD.list=[];clearInterval(SHD.iv);SHD.iv=null;SHD.poss.slice().forEach(shdUnpossess)}
/* every shadow on the map that something could come up out of */
function shdSources(){const W=EXP.W,H=EXP.H,out=[],seen=new Set;const ok=(x,y)=>x>0&&y>0&&x<W-1&&y<H-1&&canWalk(tileAt(x,y))&&!thingsAt(x,y).length&&!(x===EXP.x&&y===EXP.y)&&!SHD.list.some(o=>!o.gone&&o.x===x&&o.y===y);
  const add=(x,y,src,what)=>{const k=x+","+y;if(seen.has(k)||!ok(x,y))return;seen.add(k);out.push({x,y,src,what})};
  (EXP.npcs||[]).forEach(p=>{if(!p.el)return;add(p.x,p.y+1,"npc",p);add(p.x-1,p.y,"npc",p);add(p.x+1,p.y,"npc",p)});
  document.querySelectorAll("#world>.mapobj").forEach(e=>{if(e.classList.contains("lnt-shade")||e.classList.contains("hallx"))return;const x=Math.round(parseFloat(e.style.left)/100*W),y=Math.round(parseFloat(e.style.top)/100*H),h=Math.max(1,Math.round(parseFloat(e.style.height)/100*H));if(isNaN(x)||isNaN(y))return;add(x,y+h,"obj",e);add(x-1,y+h-1,"obj",e)});
  for(let y=1;y<H-1;y++)for(let x=1;x<W-1;x++)if(tileAt(x,y-1)==="#"&&(x*7+y*3)%4===0)add(x,y,"wall",null);
  return inHollow()?out.filter(s=>shdDark(s.x,s.y)):out}
const shdDist=(a,b)=>Math.abs(a.x-b.x)+Math.abs(a.y-b.y);
/* things a shadow can get into: people, and the things standing about */
function shdTargets(){const out=[];(EXP.npcs||[]).forEach(p=>{if(p.el&&!p.possessed&&!p.gymHand&&!p.gymLeader)out.push({el:p.el,npc:p,x:p.x,y:p.y})});
  document.querySelectorAll("#world>.mapobj").forEach(e=>{if(e.classList.contains("lnt-shade")||e.classList.contains("hallx")||e.classList.contains("possessed")||e.classList.contains("offv"))return;const W=EXP.W,H=EXP.H,x=Math.round(parseFloat(e.style.left)/100*W),y=Math.round(parseFloat(e.style.top)/100*H);if(!isNaN(x)&&!isNaN(y)&&parseFloat(e.style.width)/100*W<=2.5)out.push({el:e,x,y})});return out}
function shdPossess(t){t.el.classList.add("possessed");if(!t.el.querySelector(".pos-eyes"))t.el.insertAdjacentHTML("beforeend",`<i class="pos-eyes"><b></b><b></b></i>`);if(t.npc)t.npc.possessed=1;SHD.poss.push(t)}
function shdUnpossess(t){t.el.classList.remove("possessed");const e=t.el.querySelector(".pos-eyes");if(e)e.remove();if(t.npc)t.npc.possessed=0;SHD.poss=SHD.poss.filter(q=>q!==t)}
/* a walk through the map, keeping to the dark in Hollowmere */
function shdPathTo(s,tx,ty,near){const W=EXP.W,key=(x,y)=>y*W+x,prev=new Map([[key(s.x,s.y),-1]]),q=[[s.x,s.y]];let goal=null;
  for(let i=0;i<q.length&&i<1600;i++){const[x,y]=q[i];if(Math.abs(x-tx)+Math.abs(y-ty)<=(near||0)){goal=[x,y];break}for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(prev.has(key(nx,ny))||!canWalk(tileAt(nx,ny))||!shdDark(nx,ny)||(nx===EXP.x&&ny===EXP.y)||SHD.list.some(o=>o!==s&&!o.gone&&o.x===nx&&o.y===ny))continue;prev.set(key(nx,ny),key(x,y));q.push([nx,ny])}}
  if(!goal)return null;let k=key(goal[0],goal[1]),p=[];while(k!==-1){p.unshift([k%W,Math.floor(k/W)]);k=prev.get(k)}return p}
function shdStep(s){const p=shdPathTo(s,EXP.x,EXP.y,1);if(p&&p.length>1)shdMove(s,p[1][0],p[1][1])}
/* a new one comes up, well away from you and from any of the others */
function shdEmerge(k,minD){const src=shdSources().filter(o=>shdDist(o,EXP)>=minD&&shdDist(o,EXP)<=(inHollow()?40:16)&&SHD.list.every(q=>q.gone||shdDist(q,o)>=6));if(!src.length)return null;const o=src[Math.random()*src.length|0];return shdNew(o.x,o.y,k)}
function shdStart(){shdClear();if(!lntOn()||!EXP.zone||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on)||!(inHollow()||lntF("hm")))return;
  SHD.next=inHollow()?6:8+Math.random()*12;if(inHollow()){const n=lntF("gwOn")?3:2;for(let i=0;i<n;i++)shdEmerge(i*2+(Math.random()*2|0),8)}SHD.iv=setInterval(shdTick,400)}
function shdOnce(){if(SHD.said||lntF("shdSeen"))return;SHD.said=true;lntSet("shdSeen",1);say0("Something just stood up out of a shadow, looked round, and walked off as if it had every right to be here.")}
/* one out-of-Hollowmere shadow, going about its business */
function shdWander(s,dt){const d=shdDist(s,EXP);
  if(!s.gone&&s.mode!=="in"&&d<=3){shdSink(s,()=>{s.el.remove();SHD.list=SHD.list.filter(q=>q!==s)});SHD.next=25+Math.random()*25;return}
  if(s.gone)return;s.t+=dt;
  if(s.mode==="look"){if(s.t<s.wait)return;s.t=0;if(d<=10)shdOnce();const T=shdTargets().filter(t=>shdDist(t,s)<=12&&shdDist(t,EXP)>=3);
    if(T.length&&Math.random()<.85){s.tgt=T[Math.random()*T.length|0];s.mode="go"}else{s.mode="leave"}return}
  if(s.mode==="go"){if(s.t<.8)return;s.t=0;const t=s.tgt;if(!t||!t.el.isConnected){s.mode="leave";return}
    if(shdDist(s,t)<=1){/* it goes down into the thing's shadow, and the thing isn't itself for a while */shdSink(s,()=>{shdPossess(t);s.mode="in";s.inFor=18+Math.random()*16;s.t=0});return}
    const p=shdPathTo(s,t.x,t.y,1);if(!p||p.length<2){s.mode="leave";return}shdMove(s,p[1][0],p[1][1]);return}
  if(s.mode==="leave"){if(s.t<.8)return;s.t=0;if(!s.home){const src=shdSources().filter(o=>o.src==="wall"&&shdDist(o,s)<=10&&shdDist(o,s)>=3);s.home=src.length?src[Math.random()*src.length|0]:{x:s.x,y:s.y}}
    if(shdDist(s,s.home)===0){shdSink(s,()=>{s.el.remove();SHD.list=SHD.list.filter(q=>q!==s)});SHD.next=30+Math.random()*40;return}
    const p=shdPathTo(s,s.home.x,s.home.y,0);if(!p||p.length<2){s.home={x:s.x,y:s.y};return}shdMove(s,p[1][0],p[1][1])}}
/* the possessed thing lets it go again: it climbs back out next to it */
function shdOut(s,dt){if(s.mode!=="in")return false;s.t+=dt;if(s.t<s.inFor&&s.tgt&&s.tgt.el.isConnected)return true;
  const t=s.tgt;if(t)shdUnpossess(t);const spots=t?[[0,1],[1,0],[-1,0],[0,-1]].map(([dx,dy])=>[t.x+dx,t.y+dy]).filter(([x,y])=>canWalk(tileAt(x,y))&&!thingsAt(x,y).length&&!(x===EXP.x&&y===EXP.y)&&shdDark(x,y)):[];
  if(!spots.length||(t&&shdDist(t,EXP)<=2)){s.el.remove();SHD.list=SHD.list.filter(q=>q!==s);SHD.next=30+Math.random()*30;return true}
  shdMove(s,spots[0][0],spots[0][1],true);shdRise(s);s.mode=inHollow()?"hunt":"leave";s.home=null;s.t=0;return true}
function shdTick(){if(!lntOn()||!EXP.zone||S.phase!=="explore"){return}const paused=(DLG.open&&!STK.held)||(typeof CS!=="undefined"&&CS.on)||document.hidden||$("#lnt-mg")||document.querySelector(".modal:not([hidden])");if(paused)return;const dt=.4;
  SHD.grabCool=Math.max(0,SHD.grabCool-dt);SHD.next-=dt;
  if(!inHollow()){/* elsewhere: one at a time, now and then */
    if(!SHD.list.length&&SHD.next<=0){const s=shdEmerge(Math.random()*6|0,6);SHD.next=s?999:10}
    SHD.list.slice().forEach(s=>{if(!shdOut(s,dt))shdWander(s,dt)});return}
  /* Hollowmere: two or three of them, each on its own */
  const live=SHD.list.filter(s=>!s.gone||s.mode==="in").length,want=lntF("gwOn")?3:2;
  if(live<want&&SHD.next<=0){shdEmerge(SHD.list.length+(Math.random()*6|0),8);SHD.next=6+Math.random()*6}
  const lit=hmLightAt(EXP.x,EXP.y);
  SHD.list.slice().forEach(s=>{if(shdOut(s,dt))return;const d=shdDist(s,EXP);
    if(s.gone){if(s.back!=null&&(s.back-=dt*1000)<=0){s.el.remove();SHD.list=SHD.list.filter(q=>q!==s)}return}
    if(s.mode==="look"){s.t+=dt;if(s.t<s.wait)return;s.t=0;if(!lit)s.mode="hunt";else{s.t=s.wait;shdWander(s,dt);return}}
    else if(s.mode==="leave"&&!lit)s.mode="hunt";
    else if(s.mode==="go"||s.mode==="leave"){shdWander(s,dt);return}
    if(!shdDark(s.x,s.y)){shdVanish(s,4000);return}
    /* you're in the light: it gives up on you and goes and gets into something instead */
    if(lit){const T=shdTargets().filter(t=>shdDist(t,s)<=10&&shdDist(t,EXP)>=3);if(T.length&&Math.random()<.3){s.tgt=T[Math.random()*T.length|0];s.mode="go";s.t=0}else if(d<=3)shdVanish(s,4000);return}
    s.t+=dt;const still=STK.still>=1.4||STK.held;if(s.t<(still?.9:1.6))return;s.t=0;
    if(d<=1){if(!SHD.grabCool&&!STK.held){SHD.grabCool=9;s.el.classList.add("grab");STK.held=1;EXP.busy=true;clearInterval(EXP.timer);EXP.path=null;hmShake();if(gate("shdgrab",1500))sfx("alert");
        say0(!lntF("shdGrab")?"A shadow with long, cold fingers takes hold of you, and doesn't let go. You can't move. Something behind you is very pleased about that.":"The shadows have you. Hold on.");lntSet("shdGrab",1);
        setTimeout(()=>{STK.held=0;EXP.busy=false;s.el.classList.remove("grab");shdVanish(s,4000);
          /* now and then, the shadow that has hold of you is the one carrying something */
          if(inHollow()&&lntF("gwOn")&&!lntGot(GW_NAME)&&!EXP.storyAlloy&&!DLG.open&&S.phase==="explore"&&Math.random()<.15)storyFight(GW_NAME,{intro:"The shadow lets go, but it's left something in your hands: a vial, cold as a grave, with a pair of eyes opening inside. LIGHTS OUT!"})},2200)}return}
    if(d<=2&&!still)return;shdStep(s)})}
/* talking to somebody with a shadow in them */
const SHD_POS_LINES=["...","(They look at you a beat too long, and smile with far too many teeth.)","(Their voice comes out a fraction after their mouth moves.) Hello. Hello. Hello.","(They tilt their head right over, the way nobody's neck should go.) Are you lost?","(Their shadow isn't doing what they're doing.)"];
{const _tt=talkTo;talkTo=function(p){if(p&&p.possessed){const L=SHD_POS_LINES[Math.random()*SHD_POS_LINES.length|0];talk(p.n,[L,"...Sorry. Where was I? I came over all cold for a second."],()=>{});return}_tt(p)}}
{const _wp=worldPlace;worldPlace=function(){_wp();shdStart()}}
{const _en=encounter;encounter=function(){shdClear();_en()}}

/* =============== LANTERN NIGHT EVENING ON EVERY MAP ===============
   Every map is at dusk while Lantern Night is on, so the lanterns, garlands and candles actually light things up: each one throws its own
   pool of warm light. Each map gets its own evening colour. */
const DUSK={"z-mine":"#9890B4","z-scrap":"#A49CC0","z-wreck":"#94A6C8","z-volcano":"#B496A8","z-glacier":"#9CB2D8","z-vault":"#A498C0","z-reactor":"#96AEA8","z-crater":"#9894C8","z-quill":"#AEAAD0","z-slag":"#9894AC"};
function lntDusk(){let n=$("#lnt-dusk");const z=EXP.zone&&EXP.zone.cls;if(!lntOn()||!z||!DUSK[z]||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on)){if(n)n.remove();return}
  if(!n){n=document.createElement("div");n.id="lnt-dusk";$("#world").appendChild(n)}const W=EXP.W,H=EXP.H,L=[],lit=lntLit();
  const at=(x,y,r,c)=>L.push(`radial-gradient(circle calc(var(--tp,40px)*${r}) at ${((x+.5)/W*100).toFixed(2)}% ${((y+.5)/H*100).toFixed(2)}%,${c} 0,${c.replace(/[\d.]+\)$/,"0)")} 100%)`);
  (ZD[z]||[]).forEach(o=>{const key=z+":"+o.x+","+o.y;if(o.light){if(lit.has(key))at(o.x,o.y-.3,2.2,"rgba(255,232,190,1)")}else if(!o.dark)at(o.x+((o.w||1)-1)/2,o.y,1.3,"rgba(255,226,186,.85)")});
  (LNT_DECOR[z]||[]).forEach(([k,x,y,s])=>{if(k==="trail"&&lntTrail()>s)at(x,y-1,2.4,"rgba(255,232,190,1)")});
  (SHOW[z]||[]).forEach(o=>at(o.x,o.y-1.2,2.8,o.c||"rgba(255,226,180,1)"));
  document.querySelectorAll("#world .dress.dr-g").forEach(e=>{const x=parseFloat(e.style.left)/100*W,y=parseFloat(e.style.top)/100*H,w=parseFloat(e.style.width)/100*W;at(x+w/2-.5,y+.4,Math.max(1.4,w*.55),"rgba(255,226,180,.8)")});
  document.querySelectorAll("#world .dress.dr-t").forEach((e,i)=>{if(i%2)return;const x=parseFloat(e.style.left)/100*W,y=parseFloat(e.style.top)/100*H;at(x,y-.2,1.1,"rgba(255,220,170,.75)")});
  n.style.background=`radial-gradient(circle calc(var(--tp,40px)*2.2) at var(--px,50%) var(--py,50%),rgba(240,236,255,.9) 0,rgba(240,236,255,0) 100%),${L.join(",")},${DUSK[z]}`;lntDuskPlayer()}
function lntDuskPlayer(){const n=$("#lnt-dusk");if(!n)return;n.style.setProperty("--px",((EXP.x+.5)/EXP.W*100).toFixed(2)+"%");n.style.setProperty("--py",((EXP.y+.5)/EXP.H*100).toFixed(2)+"%")}
{const _pp=placePlayer;placePlayer=function(i){_pp(i);lntDuskPlayer()}}
{const _lf=lntFlash;lntFlash=function(el,cls,ms){_lf(el,cls,ms);if(cls==="catch"&&!inHollow())setTimeout(lntDusk,60)}}

/* =============== SHOWPIECES: two proper installations on every map, each made from what that place has ===============
   They stand on one tile and rise well above it. */
const SHOW={};const show=(z,x,y,svg,use,c)=>(SHOW[z]=SHOW[z]||[]).push({x,y,svg,use,c});
const SG=(x,y,r,c)=>`<circle class="dr-glow" cx="${x}" cy="${y}" r="${r}" fill="${c}" opacity=".3"/>`;
const SF=(x,y,s,c,d)=>`<path class="lnt-flame" style="animation-delay:-${d||0}s" d="M${x} ${y-6*s} Q${x+2.4*s} ${y-2.4*s} ${x} ${y} Q${x-2.4*s} ${y-2.4*s} ${x} ${y-6*s} Z" fill="${c||"#FFB43A"}"/>`;
const TINL=(x,y,s)=>`<g transform="translate(${x} ${y}) scale(${s||1})"><path d="M0 -6 V0" stroke="#3A3A40" stroke-width=".6"/>${SG(0,6,7,"#FFC870")}<path d="M-4 0 H4 L4.6 11 Q0 12.4 -4.6 11 Z" fill="#7A7A82" stroke="#1E1E24" stroke-width=".7"/>${[[-1.6,3.6],[1.6,3.6],[-1.2,7],[0,7.6],[1.2,7]].map(([a,b],i)=>`<circle cx="${a}" cy="${b}" r="${i<2?.8:.5}" fill="#FFD27A"/>`).join("")}</g>`;
/* RUSTVEIN: a pit-prop frame hung with tin lanterns, and a pyramid of carved, lit ore */
show("z-mine",16,19,`<ellipse cx="20" cy="38" rx="16" ry="2.4" fill="#000" opacity=".3"/><path d="M4 38 V-34 M36 38 V-34" stroke="#5A3E26" stroke-width="3.4"/><path d="M1 -34 H39" stroke="#6A4A2E" stroke-width="4"/><path d="M4 -24 L14 -34 M36 -24 L26 -34" stroke="#5A3E26" stroke-width="2"/>
  ${[[8,-30,.9],[15,-30,1.1],[22,-30,1],[30,-30,1.2],[12,-12,.8],[27,-14,.9]].map(([x,y,s])=>TINL(x,y+(s>1?4:0),s)).join("")}<path d="M4 -10 Q20 -2 36 -10" stroke="#6A4A2A" stroke-width="1" fill="none"/>${TINL(20,-6,1)}
  <path d="M6 -32 L14 -32 M6 -32 L6 -24 M6 -32 L12 -26" stroke="#D8D4CC" stroke-width=".5" opacity=".7"/><path d="M30 38 L36 18 M33 18 L39 21" stroke="#3A3A40" stroke-width="1.6"/>`,"Foreman Dray's pit-prop frame, hung with Nettie's tin lanterns. Every one has a face punched into it, and every face is different.");
show("z-mine",27,22,`<ellipse cx="20" cy="38" rx="17" ry="2.4" fill="#000" opacity=".3"/>`+[[4,32],[3,24],[2,16],[1,8]].map(([n,y],r)=>Array.from({length:n},(_,i)=>{const x=20+(i-(n-1)/2)*9,c=["#B87333","#8A8A92","#C8A040","#6A6A72"][(r+i)%4];return`<path d="M${x-5} ${y+6} L${x-4.4} ${y-1} L${x} ${y-3.6} L${x+4.6} ${y-1} L${x+5} ${y+6} Z" fill="${c}" stroke="#1E1E24" stroke-width=".7"/><g class="lnt-orefc" style="animation-delay:-${(r*3+i)*.3}s"><path d="M${x-2.6} ${y+.6} l1.2 -1.4 l.8 1.8 Z M${x+.6} ${y+1} l.8 -1.8 l1.2 1.4 Z" fill="#FFC870"/><path d="M${x-2} ${y+3} q2 1.6 4 0" stroke="#FFC870" stroke-width=".8" fill="none"/></g>`}).join("")).join("")+SG(20,22,18,"#FFC870"),"A pyramid of ore, ten lumps high, every lump carved with its own face and lit from inside. The copper ones glow warmest.");
/* SCRAPYARD: a tower of oil-drum lanterns, and a pipe tree hung with salvaged bulbs */
show("z-scrap",25,14,`<ellipse cx="20" cy="38" rx="14" ry="2.4" fill="#000" opacity=".3"/>`+[[24,"#4A6A5A"],[6,"#8A3A2A"],[-12,"#3A4A7A"]].map(([y,c],i)=>`<rect x="9" y="${y}" width="22" height="16" rx="2" fill="${c}" stroke="#14141A" stroke-width="1"/><path d="M9 ${y+3} H31 M9 ${y+13} H31" stroke="#14141A" stroke-width=".8" opacity=".6"/><g fill="#FFB43A"><path d="M13 ${y+8} l3 -2.4 l1 3.4 Z M27 ${y+8} l-3 -2.4 l-1 3.4 Z"/><path d="M13 ${y+11} q7 ${4-i} 14 0 q-7 2 -14 0 Z"/></g>${SG(20,y+8,10,"#FFB43A")}`).join("")+`<ellipse cx="20" cy="-12" rx="13" ry="3" fill="#C8C8D0" stroke="#3A3A42" stroke-width=".8"/><path d="M20 -15 V-28" stroke="#3A3A42" stroke-width="1"/><circle class="dr-bulb" cx="20" cy="-29" r="2.2" fill="#E8412C"/>`,"Alf and Bolt's drum tower: three oil drums stacked and welded, each with a different face cut into it by torch, a hubcap hat, and a red bulb on an aerial.","rgba(255,200,140,1)");
show("z-scrap",7,21,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/><path d="M20 38 V-6 M20 4 Q8 -2 4 -14 M20 -2 Q32 -8 36 -20 M20 -6 Q16 -18 18 -30 M20 14 Q30 10 34 2" stroke="#5A5A62" stroke-width="2.6" fill="none" stroke-linecap="round"/>`+[[4,-14],[8,-6],[36,-20],[30,-12],[18,-30],[22,-20],[34,2],[28,8],[12,4]].map(([x,y],i)=>`<path d="M${x} ${y} v2" stroke="#1E1E24" stroke-width=".6"/><ellipse class="dr-bulb" style="animation-delay:-${i*.27}s" cx="${x}" cy="${y+4.4}" rx="2.2" ry="3" fill="${["#FF5A3A","#F2C94C","#5AE86A","#5AA8FF","#C86AE8"][i%5]}"/>`).join(""),"A tree made of bent pipe, hung all over with bulbs Bolt has salvaged and rewired. They twinkle out of time with each other, on purpose.","rgba(255,230,200,1)");
/* COVE: a lantern mast, and a pyramid of glass floats */
show("z-wreck",10,13,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/><path d="M20 38 V-44" stroke="#6A4A2A" stroke-width="3"/><path d="M4 -34 H36 M8 -12 H32" stroke="#6A4A2A" stroke-width="2.2"/><path d="M20 -44 L4 -34 M20 -44 L36 -34 M4 -34 L8 -12 M36 -34 L32 -12 M8 -12 L20 38 M32 -12 L20 38" stroke="#8A7A5A" stroke-width=".6"/>
  <path d="M8 -32 Q20 -26 32 -32 L30 -14 Q20 -10 10 -14 Z" fill="#E8DCC0" opacity=".8" stroke="#8A7A5A" stroke-width=".6"/><path d="M16 -24 Q20 -28 24 -24 Q22 -20 20 -21 Q18 -20 16 -24 Z M18 -20 V-17 M22 -20 V-17" fill="#2A2A30" stroke="#2A2A30" stroke-width=".8"/>
  ${[[4,-32,"#9AF0B8"],[36,-32,"#FF8A8A"],[8,-10,"#9AF0B8"],[32,-10,"#FF8A8A"]].map(([x,y,c])=>`<path d="M${x} ${y} v3" stroke="#3A2A0A" stroke-width=".6"/>${SG(x,y+8,7,c)}<path d="M${x-3} ${y+3} H${x+3} L${x+2.4} ${y+12} H${x-2.4} Z" fill="${c}" stroke="#3A2A0A" stroke-width=".7"/>`).join("")}<path d="M20 -44 L28 -41 L20 -38 Z" fill="#14121A"/>`,"Captain Fenn has rigged a spare mast on the beach, dressed overall: a sail with a painted grin, and a green lantern and a red one on every yard.","rgba(200,255,220,1)");
show("z-wreck",26,15,`<ellipse cx="20" cy="38" rx="16" ry="2.4" fill="#000" opacity=".3"/>`+[[4,31],[3,23],[2,15],[1,7]].map(([n,y],r)=>Array.from({length:n},(_,i)=>{const x=20+(i-(n-1)/2)*8.6,c=["#5AC8A8","#5A8AE8","#7AE8C8"][(r+i)%3];return`${SG(x,y,6,c)}<circle cx="${x}" cy="${y}" r="4.2" fill="${c}" opacity=".85" stroke="#2A3A4A" stroke-width=".7"/><path d="M${x-4} ${y} H${x+4} M${x} ${y-4.2} V${y+4.2}" stroke="#8A7A5A" stroke-width=".5"/><circle cx="${x-1.4}" cy="${y-1.6}" r="1" fill="#F4FFFF" opacity=".8"/>`}).join("")).join(""),"The Moss twins' pyramid of old glass fishing floats in netting, each with a tea light inside. It glows like the bottom of the sea.","rgba(170,255,230,1)");
/* CALDERA: an obsidian obelisk hung with ember lanterns, and a cairn full of votives */
show("z-volcano",22,16,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".35"/><path d="M12 38 L15 -30 L20 -44 L25 -30 L28 38 Z" fill="#1A1418" stroke="#08060A" stroke-width="1"/><path d="M17 30 L19 10 L17 -8 L20 -26 M23 34 L21 16 L24 0" stroke="#FF7A2A" stroke-width="1.2" fill="none" class="dr-bulb"/><path d="M15 -20 L4 -14 M25 -20 L36 -14" stroke="#3A3A42" stroke-width="1.2"/>
  ${[[4,-14],[36,-14]].map(([x,y])=>`<path d="M${x} ${y} v4" stroke="#3A3A42" stroke-width=".6"/>${SG(x,y+10,8,"#FF8A3A")}<path d="M${x-3} ${y+4} L${x} ${y+16} L${x+3} ${y+4} Z" fill="#FF8A2A" stroke="#3A0A04" stroke-width=".6"/>`).join("")}`,"Juno's obelisk: a single spire of obsidian with caldera fire showing through its cracks, and ember lanterns hung from its arms on chains.","rgba(255,170,120,1)");
show("z-volcano",6,19,`<ellipse cx="20" cy="38" rx="17" ry="2.4" fill="#000" opacity=".35"/><path d="M3 38 Q4 22 10 18 Q8 6 16 0 Q18 -10 24 -10 Q30 -4 30 4 Q36 12 34 22 Q38 30 37 38 Z" fill="#2E2428" stroke="#0E080A" stroke-width="1"/>`+[[9,30],[16,32],[24,31],[31,30],[12,22],[20,24],[28,22],[16,12],[24,12],[20,3],[24,-2]].map(([x,y],i)=>`<path d="M${x-2.6} ${y} Q${x} ${y-4} ${x+2.6} ${y} Z" fill="#0A0606"/><rect x="${x-.8}" y="${y-2.6}" width="1.6" height="2.6" fill="#E8DCC0"/>${SF(x,y-2.6,.5,i%2?"#FFB43A":"#FF8A2A",i*.17)}`).join("")+SG(20,16,18,"#FFA040"),"Brother Ashlin's cairn, every niche in it holding a lit votive. From a distance it looks like the rock is full of sparks.","rgba(255,190,140,1)");
/* CAVERN: a tower of carved ice lanterns, and a pyramid of frosted neeps */
show("z-glacier",11,6,`<ellipse cx="20" cy="38" rx="14" ry="2.2" fill="#000" opacity=".2"/>`+[[22,13],[6,11],[-8,9],[-20,7]].map(([y,w],i)=>`<rect x="${20-w}" y="${y}" width="${w*2}" height="${i===0?16:14}" rx="1.4" fill="#D8F4FF" opacity=".72" stroke="#5A8AA8" stroke-width=".8"/><path d="M${20-w+2} ${y+3} Q${20-w+4} ${y+8} ${20-w+2} ${y+12}" stroke="#FFFFFF" stroke-width=".8" fill="none" opacity=".7"/>${SG(20,y+7,w,"#BFE8FF")}${SF(20,y+10,.8,"#FFC870",i*.3)}`).join("")+`<path d="M12 -20 l-1 4 M28 -20 l1 4 M14 -6 l-.6 3 M26 -6 l.6 3" stroke="#E8F8FF" stroke-width="1.2"/>`,"Dr. Holm's tower of ice lanterns, four blocks high, each frozen round its own candle. The whole thing glows blue from the inside.","rgba(200,235,255,1)");
show("z-glacier",28,22,`<ellipse cx="20" cy="38" rx="16" ry="2.2" fill="#000" opacity=".2"/>`+[[3,30],[2,19],[1,8]].map(([n,y],r)=>Array.from({length:n},(_,i)=>{const x=20+(i-(n-1)/2)*11;return`<path d="M${x-5.4} ${y+2} Q${x-6} ${y-5} ${x} ${y-6} Q${x+6} ${y-5} ${x+5.4} ${y+2} Q${x+5} ${y+6} ${x} ${y+6} Q${x-5} ${y+6} ${x-5.4} ${y+2} Z" fill="#E8F0F8" stroke="#5A7A98" stroke-width=".7"/><g fill="#FFC870"><path d="M${x-3} ${y-1} l1.4 -1.6 l.8 2 Z M${x+3} ${y-1} l-1.4 -1.6 l-.8 2 Z M${x-2.6} ${y+2} q2.6 2 5.2 0 q-2.6 .8 -5.2 0 Z"/></g><path d="M${x-4} ${y+5} l-.6 2.4 M${x+3} ${y+5.4} l.4 2.2" stroke="#D8F4FF" stroke-width=".8"/>`}).join("")).join("")+SG(20,20,16,"#FFD08A"),"Coach Brandt's pyramid of neeps, left out overnight to frost over. Every one has icicles hanging off its chin.","rgba(255,236,210,1)");
/* VAULT: a great gilt candelabra tree, and neeps on a velvet plinth */
show("z-vault",33,11,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/><path d="M12 38 H28 L25 32 H15 Z" fill="#C8A040" stroke="#5A4012" stroke-width=".9"/><path d="M20 32 V-30" stroke="#C8A040" stroke-width="2.4"/>${[[-20,14],[-6,11],[8,8]].map(([y,w])=>`<path d="M20 ${y} Q${20-w} ${y} ${20-w} ${y-8} M20 ${y} Q${20+w} ${y} ${20+w} ${y-8}" stroke="#C8A040" stroke-width="1.8" fill="none"/>`).join("")}
  ${[[6,-28],[34,-28],[9,-14],[31,-14],[12,0],[28,0],[20,-36]].map(([x,y],i)=>`<rect x="${x-1.4}" y="${y}" width="2.8" height="7" fill="#F2EAD4"/><path d="M${x-3} ${y+7} H${x+3}" stroke="#C8A040" stroke-width="1.4"/>${SF(x,y,.8,"#FFB43A",i*.2)}`).join("")}${SG(20,-14,20,"#FFE08A")}<path d="M15 -4 Q20 -8 25 -4 Q20 0 15 -4 Z" fill="#14081E"/>`,"Chronicler Vell's candelabra tree: seven candles on gilded branches, tied with black silk. It takes him an hour to light, and he enjoys every minute.","rgba(255,236,190,1)");
show("z-vault",10,12,`<ellipse cx="20" cy="38" rx="16" ry="2.2" fill="#000" opacity=".3"/><rect x="4" y="22" width="32" height="16" fill="#C8A040" stroke="#5A4012" stroke-width="1"/><path d="M2 22 H38 L36 14 H4 Z" fill="#3A1A4A" stroke="#14081E" stroke-width=".8"/><path d="M4 14 Q8 26 6 30 M36 14 Q32 26 34 30" stroke="#3A1A4A" stroke-width="3" fill="none"/>
  ${[[11,8],[20,8],[29,8],[15,-1],[25,-1],[20,-10]].map(([x,y],i)=>`<path d="M${x-5} ${y+3} Q${x-5.4} ${y-4} ${x} ${y-5} Q${x+5.4} ${y-4} ${x+5} ${y+3} Q${x+4} ${y+6} ${x} ${y+6} Q${x-4} ${y+6} ${x-5} ${y+3} Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width=".7"/><path d="M${x-3} ${y-3.4} Q${x} ${y-5.4} ${x+3} ${y-3.4}" stroke="#C8A040" stroke-width="1.2" fill="none"/><g fill="#FFC24A"><path d="M${x-2.6} ${y} l1.2 -1.4 l.8 1.8 Z M${x+2.6} ${y} l-1.2 -1.4 l-.8 1.8 Z M${x-2.4} ${y+2.4} q2.4 1.8 4.8 0 q-2.4 .7 -4.8 0 Z"/></g>`).join("")}${SG(20,2,16,"#FFC870")}`,"Hettie Marsh's display: six neeps on a velvet-draped plinth, each one's crown edged in gold leaf. The best carving in the county, she says. She's right.","rgba(255,226,180,1)");
/* REACTOR: a rack of glowing paint jars, and barrel-lanterns */
show("z-reactor",20,21,`<ellipse cx="20" cy="38" rx="14" ry="2.2" fill="#000" opacity=".3"/><path d="M7 38 V-26 M33 38 V-26" stroke="#5A6068" stroke-width="2"/>${[30,14,-2,-18].map(y=>`<path d="M6 ${y} H34" stroke="#5A6068" stroke-width="2"/>`).join("")}
  ${[[11,30],[20,30],[29,30],[14,14],[25,14],[11,-2],[20,-2],[29,-2],[16,-18],[24,-18]].map(([x,y],i)=>`${SG(x,y-5,6,"#9AFF6A")}<rect x="${x-3}" y="${y-10}" width="6" height="2" fill="#8A8A92"/><path d="M${x-3.4} ${y-8} H${x+3.4} V${y-1} Q${x+3.4} ${y} ${x+2} ${y} H${x-2} Q${x-3.4} ${y} ${x-3.4} ${y-1} Z" fill="${["#B8FF8A","#8AFFD8","#E8FF8A"][i%3]}" opacity=".85"/><circle class="lnt-glw" style="animation-delay:-${i*.3}s" cx="${x-1}" cy="${y-5}" r=".8" fill="#FFFFFF"/>`).join("")}`,"Janitor Lu's rack of glowing paint, every jar a slightly different green, all labelled ONLY PAINT in Inspector Pratt's handwriting.","rgba(200,255,170,1)");
show("z-reactor",35,9,`<ellipse cx="20" cy="38" rx="16" ry="2.4" fill="#000" opacity=".3"/>`+[[9,18],[29,18],[19,0]].map(([x,y],i)=>`<rect x="${x-8}" y="${y}" width="16" height="20" rx="2" fill="#E8C040" stroke="#5A4012" stroke-width="1"/><path d="M${x-8} ${y+4} H${x+8} M${x-8} ${y+16} H${x+8}" stroke="#5A4012" stroke-width=".8"/><g fill="#2A3A1A"><path d="M${x-5} ${y+9} l2.4 -2 l1 2.6 Z M${x+5} ${y+9} l-2.4 -2 l-1 2.6 Z"/><path d="M${x-5} ${y+12} q5 4 10 0 q-5 1.6 -10 0 Z"/></g>${SG(x,y+10,9,"#B8FF8A")}<g fill="#B8FF8A" opacity=".85"><path d="M${x-5} ${y+9} l2.4 -2 l1 2.6 Z M${x+5} ${y+9} l-2.4 -2 l-1 2.6 Z"/></g>`).join(""),"Three yellow drums carved into faces and lit from inside with glow paint. Inspector Pratt has checked: they are only drums.","rgba(220,255,180,1)");
/* CRATER: a cluster of star-lantern poles, and a great paper moon */
show("z-crater",18,17,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/>${[[10,-20,1],[20,-36,1.3],[30,-14,.9]].map(([x,y,s],i)=>`<path d="M${x} 38 V${y}" stroke="#4A3A2A" stroke-width="1.4"/>${SG(x,y-6,10*s,"#FFE8A0")}<path transform="translate(${x} ${y-7}) scale(${s})" d="M0 -8 L2.4 -2.4 L8 -2 L3.6 1.6 L5 7.4 L0 4.2 L-5 7.4 L-3.6 1.6 L-8 -2 L-2.4 -2.4 Z" fill="#FFE8A0" stroke="#8A7A4A" stroke-width=".8"/>`).join("")}`,"Grandmother Nell's star lanterns, the tallest of them higher than the hut roof. Forty years she's been hanging these.","rgba(255,240,200,1)");
show("z-crater",34,9,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/><path d="M6 38 L20 -10 L34 38" stroke="#4A3A2A" stroke-width="1.6" fill="none"/>${SG(20,-24,18,"#F4E8B0")}<circle cx="20" cy="-24" r="13" fill="#F4E8B0" stroke="#8A7A4A" stroke-width="1"/><circle cx="15" cy="-28" r="2.4" fill="#D8C890"/><circle cx="24" cy="-20" r="3" fill="#D8C890"/><circle cx="22" cy="-31" r="1.4" fill="#D8C890"/>
  ${[[8,-6],[32,-4],[14,6],[28,10]].map(([x,y],i)=>`<path d="M${x} ${y-10} V${y}" stroke="#C8C0A0" stroke-width=".4"/><path class="dr-bulb" style="animation-delay:-${i*.4}s" transform="translate(${x} ${y+3}) scale(.3)" d="M0 -10 L3 -3 L10 -3 L4.4 1.6 L6.4 9 L0 4.6 L-6.4 9 L-4.4 1.6 L-10 -3 L-3 -3 Z" fill="#FFE8A0"/>`).join("")}`,"Mr. Pennyworth's moon lantern: a great paper moon on a frame, lit from inside, with four little stars turning on threads beneath it.","rgba(255,244,210,1)");
/* INSTITUTE: a tower of books with candles at every level, and a pyramid of specimen jars */
show("z-quill",32,27,`<ellipse cx="20" cy="38" rx="12" ry="2.2" fill="#000" opacity=".3"/>`+[[32,"#8A2A2A",13],[26,"#2A4A6A",12],[20,"#3A5A2A",14],[14,"#6A4A2A",11],[8,"#4A2A5A",12],[2,"#8A2A2A",10],[-4,"#2A4A6A",11],[-10,"#6A4A2A",9]].map(([y,c,w],i)=>`<rect x="${20-w+(i%2?1.4:-1.4)}" y="${y}" width="${w*2}" height="6" fill="${c}" stroke="#14121A" stroke-width=".6"/><path d="M${20-w+(i%2?1.4:-1.4)+1} ${y+1.4} H${20+w+(i%2?1.4:-1.4)-1}" stroke="#F4ECD8" stroke-width=".8"/>`).join("")
  +[[8,32],[32,20],[9,8],[31,-4],[20,-16]].map(([x,y],i)=>`<rect x="${x-1.2}" y="${y-6}" width="2.4" height="6" fill="#F2EAD4"/><path d="M${x+1.2} ${y-5} q.8 2 0 3.4" stroke="#F2EAD4" stroke-width="1.2" fill="none"/>${SF(x,y-6,.7,"#FFB43A",i*.25)}`).join("")+SG(20,4,18,"#FFD08A"),"Mrs. Gale's book tower: every volume the Institute has ever declared lost, stacked up and lit with candles at every level. She dusts it twice a day.","rgba(255,230,190,1)");
show("z-quill",14,7,`<ellipse cx="20" cy="38" rx="16" ry="2.2" fill="#000" opacity=".3"/>`+[[3,28],[2,14],[1,0]].map(([n,y],r)=>Array.from({length:n},(_,i)=>{const x=20+(i-(n-1)/2)*11;return`${SG(x,y+4,7,"#FFE8C0")}<rect x="${x-4.4}" y="${y-4}" width="8.8" height="2" fill="#3A3A44"/><path d="M${x-4} ${y-2} H${x+4} V${y+9} Q${x+4} ${y+10} ${x+3} ${y+10} H${x-3} Q${x-4} ${y+10} ${x-4} ${y+9} Z" fill="#E8F4F0" opacity=".55" stroke="#4A5A6A" stroke-width=".6"/>${(r+i)%2?`<path d="M${x-2} ${y+8} Q${x-2.4} ${y+2} ${x} ${y+1} Q${x+2.4} ${y+2} ${x+2} ${y+8} L${x+1} ${y+7} L${x} ${y+8.4} L${x-1} ${y+7} Z" fill="#F4F2EC" opacity=".9"/><circle cx="${x-.8}" cy="${y+3.6}" r=".4" fill="#14141C"/><circle cx="${x+.8}" cy="${y+3.6}" r=".4" fill="#14141C"/>`:`<rect x="${x-.8}" y="${y+3}" width="1.6" height="5" fill="#F2EAD4"/>${SF(x,y+3,.5,"#FFB43A",i*.3)}`}`}).join("")).join(""),"Quartermaster Hobbs' pyramid of specimen jars: candles in some, small labelled ghosts in the others. All of it inventoried.","rgba(255,240,215,1)");
/* place them: they stand on their tile */
{const _ls=lntStamp;lntStamp=function(cls,M){M=_ls(cls,M);if(!lntOn())return M;(SHOW[cls]||[]).forEach(o=>{const r=M[o.y];if(!r||r[o.x]==="¤")return;LNT_UNDER[cls+":"+o.x+","+o.y]=r[o.x];M[o.y]=r.slice(0,o.x)+"¤"+r.slice(o.x+1)});return M}}
{const _ld=lntDecorate;lntDecorate=function(){_ld();const z=EXP.zone&&EXP.zone.cls;if(!lntOn()||!z||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;
  (SHOW[z]||[]).forEach(o=>{const el=lntEl("mapobj lnt show",o.x,o.y,`<svg viewBox="0 0 40 40" aria-hidden="true" style="overflow:visible">${o.svg}</svg>`);EXP.objs.push({x:o.x,y:o.y,el,use:()=>{lntFlash(el,"poke",1200);talk("",[o.use])}})});
  setTimeout(lntDusk,30)}}
/* the kirkyard's east gate was blocked by a gravestone: move the stone one row down so the gate opens onto the kirkyard */
{const M=MAPS["z-hollow"],s=(y,x,c)=>{M[y]=M[y].slice(0,x)+c+M[y].slice(x+1)};if(M[12][8]==="G"){s(12,8,".");s(13,7,"G")}HOLLOW_ZONE.map=M.slice()}
