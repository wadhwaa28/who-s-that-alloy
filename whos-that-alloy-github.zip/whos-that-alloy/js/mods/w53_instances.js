/* =============== SAMPLES ARE INDIVIDUALS ===============
   Every time you register an alloy you get a new sample of it, and no two samples are quite alike. Each one is born with its own temper
   (a little stronger here, a little quicker there) and its own set of moves, drawn from what that alloy can learn. You don't choose its
   moves: it learns new ones by itself as it's tempered in Assays. And each alloy can only ever learn its own particular moves, including
   one that belongs to it and nothing else. */

/* ---- signature moves: one per alloy, written with its form ---- */
const SIG={};
function SM(alloy,n,c,k,p,acc,fx,sci){SIG[alloy]=n;M(n,c,k,p,acc,fx,sci,"s:"+alloy)}

/* ---- each alloy's own, narrower learnset ---- */
const _ls0=learnset;
learnset=function(a){if(learnset.c2[a.name])return learnset.c2[a.name];
  const all=_ls0(a),r=fgRng(fgHash("learn:"+a.name)),keep=[],seen=new Set(),add=x=>{if(x&&!seen.has(x.id)){seen.add(x.id);keep.push(x)}};
  const src=x=>MV[x.id].src.split(":");
  /* one plain move per test class it's good at, so it can always fight; which tier it starts with differs alloy to alloy */
  const basic=all.filter(x=>src(x)[0]==="b");const cls=[...new Set(basic.map(x=>MV[x.id].c))];
  cls.forEach(c=>{const L=basic.filter(x=>MV[x.id].c===c).sort((p,q)=>p.g-q.g);if(!L.length)return;add({...L[0],g:0});const t=L[1+Math.floor(r()*(L.length-1))];if(t&&r()<.7)add(t)});
  /* a few of the special ones, chosen per alloy */
  const special=all.filter(x=>src(x)[0]!=="b");
  const pri={k:4,p:3,e:2,t:1,g:0};special.sort((p,q)=>(pri[src(q)[0]]||0)-(pri[src(p)[0]]||0)||r()-.5);
  const cap=4+Math.floor(r()*4);special.forEach(x=>{if(keep.length<cls.length+cap&&(src(x)[0]==="k"||src(x)[0]==="p"||r()<.62))add(x)});
  /* its own move */
  const sid=SIG[a.name]&&MV[SIG[a.name].toLowerCase().replace(/[^a-z0-9]+/g,"_")];if(sid)add({id:sid.id,g:1});
  if(!keep.some(x=>x.g===0))keep[0].g=0;
  return learnset.c2[a.name]=keep};
learnset.c2={};learnset.c={};

/* ---- the samples themselves ---- */
const STAT_KEYS=["max","atk","def","draw","ward","spd"];
let instSeq=0;
function newInst(name,rad,xp){const d=asData(),id="s"+Date.now().toString(36)+(instSeq++).toString(36)+Math.floor(Math.random()*1296).toString(36);
  const r=Math.random,iv={};STAT_KEYS.forEach(k=>iv[k]=Math.floor(r()*16));
  const a=alloyByName(name),g=gradeOf(xp||0),pool=movesAt(a,g).map(m=>m.id);
  /* it wakes up knowing up to four of the moves it could know, chosen by chance, with at least one that does damage */
  const shuffled=pool.slice().sort(()=>r()-.5),atk=shuffled.filter(id=>MV[id].k==="a"),mv=[];if(atk.length)mv.push(atk[0]);
  shuffled.forEach(id=>{if(mv.length<4&&!mv.includes(id))mv.push(id)});
  const s={id,n:name,iv,xp:xp||0,hp:1,rad:!!rad,mv,born:Date.now()};d.inst[id]=s;asSave(d);return s}
const _asData0=asData;
asData=function(){const d=_asData0();d.inst=d.inst||{};
  /* old saves: every alloy you'd registered becomes one sample, keeping its tempering and condition */
  if(!d.instMig){d.instMig=1;const old=d.case.slice();d.case=[];
    (typeof S!=="undefined"&&S.caught?[...S.caught]:[]).forEach(n=>{const a=alloyByName(n);if(!a||a.threat)return;
      const r=fgRng(fgHash("mig:"+n)),iv={};STAT_KEYS.forEach(k=>iv[k]=Math.floor(r()*16));const g=gradeOf(d.xp[n]||0),pool=movesAt(a,g).map(m=>m.id);
      const eq=(d.eq[n]||[]).filter(id=>pool.includes(id)),mv=eq.length?eq:autoEquip(a,g).filter(id=>pool.includes(id));
      const id="m"+fgHash(n).toString(36);d.inst[id]={id,n,iv,xp:d.xp[n]||0,hp:d.hp[n]==null?1:d.hp[n],rad:!!(d.rad[n]&&radOwned(a)),mv:mv.slice(0,4),born:0};if(old.includes(n))d.case.push(id)});
    store.set("wta_assay",d)}
  /* a case that still names an alloy rather than a sample gets that alloy's sample */
  if(d.case.some(id=>!d.inst[id]&&alloyByName(id))){d.case=d.case.map(id=>{if(d.inst[id])return id;const a=alloyByName(id);if(!a||a.threat)return null;
      const mid="m"+fgHash(id).toString(36);if(!d.inst[mid]){const r=fgRng(fgHash("mig:"+id)),iv={};STAT_KEYS.forEach(k=>iv[k]=Math.floor(r()*16));const g=gradeOf(d.xp[id]||0);
        d.inst[mid]={id:mid,n:id,iv,xp:d.xp[id]||0,hp:1,rad:false,mv:autoEquip(a,g).slice(0,4),born:0}}return mid}).filter(Boolean);store.set("wta_assay",d)}
  d.case=d.case.filter(id=>d.inst[id]);return d};
const instOf=id=>asData().inst[id];
function instStats(s){const a=alloyByName(s.n),b=aStats(a,gradeOf(s.xp));STAT_KEYS.forEach(k=>{b[k]=b[k]*(1+(s.iv[k]-7.5)/75)});b.max=Math.round(b.max);return b}
const IV_WORD=v=>v>=14?"exceptional":v>=11?"strong":v>=6?"sound":v>=3?"middling":"weak";
const STAT_NAME={max:"Integrity",atk:"Bite",def:"Hold",draw:"Draw",ward:"Ward",spd:"Speed"};

/* ---- registering an alloy gives you a sample of it ---- */
{const _w=win;win=function(){const r=S.r;_w();if(!r||!r.won||!r.a||r.a.threat||r.tut)return;const s=newInst(r.a.name,!!r.radiant);
  setTimeout(()=>{const best=STAT_KEYS.slice().sort((p,q)=>s.iv[q]-s.iv[p])[0];say0(`You've a new sample of ${r.a.name.toUpperCase()}${s.rad?" (radiant)":""}. Its ${STAT_NAME[best].toLowerCase()} is ${IV_WORD(s.iv[best])}. It knows ${s.mv.map(id=>MV[id].n).join(", ")}.`)},5200)}}

/* ---- in an Assay ---- */
asTeamFromCase=function(){const d=asData();return d.case.map(id=>d.inst[id]).filter(Boolean).map(s=>{const a=alloyByName(s.n);if(!a)return null;const g=gradeOf(s.xp);
  const m=mkMon(a,g,s.mv.filter(id=>MV[id]),s.hp);m.s=instStats(s);m.hp=Math.max(0,Math.round(m.s.max*(s.hp==null?1:s.hp)));m.inst=s.id;m.rad=s.rad;return m}).filter(Boolean)};
/* opposing samples are individuals too */
{const _mk=mkMon;mkMon=function(a,g,moves,hpFrac){const m=_mk(a,g,moves,hpFrac);if(moves)return m;
  const r=Math.random,pool=movesAt(a,g).map(x=>x.id).sort(()=>r()-.5),atk=pool.filter(id=>MV[id].k==="a"),mv=atk.length?[atk[0]]:[];pool.forEach(id=>{if(mv.length<4&&!mv.includes(id))mv.push(id)});
  m.moves=mv;STAT_KEYS.forEach(k=>{m.s[k]=m.s[k]*(1+(Math.floor(r()*16)-7.5)/75)});m.s.max=Math.round(m.s.max);m.hp=Math.round(m.s.max*(hpFrac==null?1:hpFrac));return m}}
/* tempering, and learning on its own */
asGiveXp=function(m,n){if(!m.inst)return;const d=asData(),s=d.inst[m.inst];if(!s)return;const was=gradeOf(s.xp);s.xp+=n;m.xpGain=(m.xpGain||0)+n;const now=gradeOf(s.xp);
  if(now>was){AS.B.ups.push([s.n,now]);const a=alloyByName(s.n),L=learnset(a),isSig=id=>SIG[s.n]&&MV[id].n===SIG[s.n];
    let fresh=L.filter(x=>x.g>was&&x.g<=now&&!s.mv.includes(x.id)).map(x=>x.id);if(!fresh.length)fresh=L.filter(x=>x.g<=now&&!s.mv.includes(x.id)).map(x=>x.id);
    if(fresh.length){const pick=fresh.find(isSig)||fresh[Math.floor(Math.random()*fresh.length)];AS.B.learned=AS.B.learned||[];
      if(s.mv.length<4){s.mv.push(pick);AS.B.learned.push([s.n,null,MV[pick].n])}
      else{const val=id=>isSig(id)?1e9:(MV[id].k==="a"?MV[id].p*MV[id].acc/100:45),atkN=s.mv.filter(id=>MV[id].k==="a").length;
        const cand=s.mv.filter(id=>!isSig(id)&&!(MV[id].k==="a"&&atkN<=1&&MV[pick].k!=="a")).sort((x,y)=>val(x)-val(y));
        if(cand.length&&val(pick)>=val(cand[0])*.8){const drop=cand[0];s.mv[s.mv.indexOf(drop)]=pick;AS.B.learned.push([s.n,MV[drop].n,MV[pick].n])}}}}
  asSave(d)};
{const _ae=asEnd;asEnd=async function(won,conceded){const B=AS.B;if(B&&!AS.sim){const d=asData();B.p.team.forEach(m=>{if(m.inst&&d.inst[m.inst]){d.inst[m.inst].hp=m.hp/m.s.max;if(won&&m.hp>0)d.inst[m.inst].xp+=8}});asSave(d)}
  const L=B&&B.learned;await _ae(won,conceded);if(L&&L.length&&!AS.sim)setTimeout(()=>say0(L.map(([n,o,p])=>o?`${n} forgot ${o} and learned ${p}.`:`${n} learned ${p}.`).join(" ")),300)}}
/* the old per-alloy records are no longer what an Assay reads */
asHealAll=function(){const d=asData();Object.values(d.inst).forEach(s=>s.hp=1);asSave(d)};
radOn=function(a){return false};

/* ---- the Sample Case ---- */
const IV_BAR=v=>`<i class="iv" style="--v:${(v/15*100).toFixed(0)}%"></i>`;
openCase=function(){const m=modal("samplecase","SAMPLE CASE"),d=asData(),L=m.querySelector(".bag-list"),slots=caseSlots();
  const row=(s,i)=>{const a=alloyByName(s.n),g=gradeOf(s.xp);
    return`<div class="bag-item cs-row"><div class="cs-ic">${specimenSVG(a)}</div><div><b>${s.n}${s.rad?" ✦":""}</b><p>${GRADES[g]} · ${s.hp<=0?"spent":Math.round(s.hp*100)+"% sound"} · ${s.mv.map(id=>MV[id]?MV[id].n:"").join(", ")}</p></div><div class="cs-btns"><button class="btn cs-info" data-id="${s.id}">DETAILS</button><button class="btn cs-rm" data-i="${i}">REMOVE</button></div></div>`};
  const inCase=d.case.map(id=>d.inst[id]).filter(Boolean);
  L.innerHTML=`<p class="bag-empty">Carry up to ${slots} samples. Every registration gives you a new sample, and no two are alike. More room comes with Assay Seals.</p>`+inCase.map(row).join("")+
   (inCase.length<slots?`<h5 class="bag-h">ADD A SAMPLE</h5><input class="cs-q" placeholder="Search your samples" aria-label="Search your samples"><div class="cs-add"></div>`:"");
  const fill=q=>{const box=L.querySelector(".cs-add");if(!box)return;const ok=Object.values(d.inst).filter(s=>!d.case.includes(s.id)&&(!q||s.n.toLowerCase().includes(q))).sort((x,y)=>x.n<y.n?-1:x.n>y.n?1:y.xp-x.xp);
    box.innerHTML=ok.length?ok.slice(0,60).map(s=>`<button class="cs-pick" data-id="${s.id}">${s.n}${s.rad?" ✦":""}<span>${GRADES[gradeOf(s.xp)]} · ${STAT_KEYS.reduce((t,k)=>t+s.iv[k],0)}/90</span></button>`).join("")+(ok.length>60?`<p class="bag-empty">${ok.length-60} more. Search to narrow it down.</p>`:""):`<p class="bag-empty">${Object.keys(d.inst).length?"Every sample you have is already in the case.":"Register some alloys out in the field first. Each one gives you a sample."}</p>`;
    box.querySelectorAll(".cs-pick").forEach(b=>b.onclick=()=>{const D=asData();if(D.case.length>=caseSlots())return;D.case.push(b.dataset.id);asSave(D);sfx("sel");openCase()})};
  fill("");const q=L.querySelector(".cs-q");if(q)q.oninput=()=>fill(q.value.trim().toLowerCase());
  L.querySelectorAll(".cs-rm").forEach(b=>b.onclick=()=>{const D=asData();D.case.splice(+b.dataset.i,1);asSave(D);openCase()});
  L.querySelectorAll(".cs-info").forEach(b=>b.onclick=()=>openSample(b.dataset.id));m.hidden=false};
/* a sample's record card: read it, don't edit it */
function openSample(id){const s=instOf(id);if(!s)return;const a=alloyByName(s.n),g=gradeOf(s.xp),st=instStats(s),m=modal("sampleinfo","SAMPLE"),L=m.querySelector(".bag-list");
  const known=learnset(a).slice().sort((x,y)=>x.g-y.g);
  L.innerHTML=`<p class="bag-empty"><b>${s.n}${s.rad?" ✦ radiant":""}</b>. ${GRADES[g]}, ${s.xp} tempering. Registered ${s.born?new Date(s.born).toLocaleDateString():"before records began"}.</p>
   <h5 class="bag-h">TEMPER</h5><div class="iv-grid">${STAT_KEYS.map(k=>`<span>${STAT_NAME[k]}</span>${IV_BAR(s.iv[k])}<em>${Math.round(st[k])} · ${IV_WORD(s.iv[k])}</em>`).join("")}</div>
   <h5 class="bag-h">KNOWS</h5>${s.mv.map(id=>{const mv=MV[id],C=ACLS[mv.c];return`<div class="mv-row on" style="--c:${C.c}"><b>${mv.n}${SIG[s.n]===mv.n?" ✦":""}</b><span>${C.n.toUpperCase()} · ${mv.k==="a"?"PWR "+mv.p:mv.k==="g"?"GUARD":"STATUS"}</span><em>${mv.sci}</em></div>`}).join("")}
   <h5 class="bag-h">WHAT ${s.n.toUpperCase()} CAN LEARN</h5><p class="bag-empty">It learns by itself as it's tempered: Worked, Tempered, Masterwork.</p>${known.map(x=>{const mv=MV[x.id],C=ACLS[mv.c],k=s.mv.includes(x.id);return`<div class="mv-row${k?" on":""}${x.g>g?" lock":""}" style="--c:${C.c}"><b>${mv.n}${SIG[s.n]===mv.n?" ✦":""}</b><span>${C.n.toUpperCase()} · ${GRADES[x.g].toUpperCase()}</span></div>`}).join("")}`;
  m.hidden=false;const bk=m.querySelector(".bag-top .btn");bk.onclick=()=>{m.hidden=true;openCase()}}
openMoves=function(){};
/* the dex shows its best sample's grade */
{const _gx=gradeOf;window.bestGradeOf=n=>{const d=asData();let b=0;Object.values(d.inst).forEach(s=>{if(s.n===n)b=Math.max(b,_gx(s.xp))});return b}}
