/* ---- birds that perch, hop and strut ---- */
FGP.bird={hab:{"z-mine":1,"z-scrap":2.5,"z-volcano":1.2,"z-glacier":2.5,"z-vault":3,"z-crater":1.5,"z-reactor":1,"z-wreck":2},loco:o=>o.perch?"perch":"hop",want:tr=>tr.light?1.6:tr.heavy?.6:1,
 kinds:{song:["Finch","Sparrow","Robin","Warbler","Bunting","Lark","Thrush","Starling","Siskin","Linnet","Pipit","Dunnock","Chat","Shrike","Wagtail","Nuthatch"],corvid:["Crow","Rook","Jackdaw","Jay","Chough","Nutcracker","Treepie"],
  parrot:["Macaw","Parakeet","Lory","Kea","Cockatiel","Conure","Kakapo","Amazon","Rosella"],raptor:["Hawk","Kite","Harrier","Buzzard","Osprey","Eagle","Owl","Owlet","Falconet","Goshawk","Caracara"],
  game:["Quail","Grouse","Partridge","Turkey","Francolin","Ptarmigan Chick","Guineafowl","Capercaillie"],sea:["Tern","Auk","Petrel","Skua","Shearwater","Frigatebird","Guillemot","Kittiwake"],
  myth:["Roc","Simurgh","Thunderbird","Caladrius","Ziz","Alkonost","Sirin","Hraesvelgr"]},
 gen(r,tr,a){const kind=fgW(r,{song:4,corvid:2,parrot:a.hab==="z-vault"?3:1.5,raptor:2.5,game:1.6,sea:a.hab==="z-wreck"?4:1,myth:a.rar==="legendary"?6:a.rar==="rare"?1.5:.4});
  const o={kind,sp:fgPick(r,this.kinds[kind])};o.br=R1(({song:20,corvid:24,parrot:24,raptor:27,game:28,sea:24,myth:30}[kind])*(.9+r()*.2));o.hr=R1(o.br*(kind==="raptor"&&/Owl/.test(o.sp)?.72:.55)*(.9+r()*.2));
  o.beak=fgPick(r,{song:["cone","thin","cone"],corvid:["dagger","dagger","thin"],parrot:["hook","hookbig"],raptor:["hook","hooksm"],game:["cone","hooksm"],sea:["dagger","thin","hookbig"],myth:["hook","dagger","hookbig"]}[kind]);
  o.tail=fgPick(r,{song:["fan","forked","short","wedge"],corvid:["wedge","fan"],parrot:["streamer","wedge"],raptor:["fan","short","wedge"],game:["fan","short","bustle"],sea:["forked","short","wedge"],myth:["streamer","plume","forked"]}[kind]);
  o.crest=fgPick(r,{song:["none","none","tuft"],corvid:["none","tuft"],parrot:["none","fan","tuft"],raptor:["none","ears","tuft"],game:["none","plume","tuft"],sea:["none","tuft"],myth:["fan","plume","tuft"]}[kind]);if(/Owl/.test(o.sp))o.crest="ears";
  o.perch=r()<.55;o.wingUp=r()<.3;o.pat=tr.mag&&r()<.4?"filings":fgPick(r,["none","spots","bands","patch","scales","none"]);o.leg=R1(8+r()*8);o.mask=r()<.3;o.bib=r()<.35;
  return o},
 draw(P,g,o){const br=o.br,hr=o.hr,cx=110,gy=o.perch?118:144,cy=gy-o.leg-br*.75,hx=cx-br*.7,hy=cy-br*.7;let s="";
  if(o.perch)s+=`<path d="M24 ${gy+2} Q100 ${gy-6} 188 ${gy+4}" stroke="#6A4A2A" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M150 ${gy} q8 -12 18 -10" stroke="#6A4A2A" stroke-width="3" fill="none"/>`;else s+=fShadow(br*1.3,cx);
  const tx=cx+br*.8,ty=cy+br*.25;
  const T={fan:`<path d="M${tx} ${ty} L${tx+br*1.1} ${ty+br*.2} Q${tx+br*1.25} ${ty+br*.7} ${tx+br*.9} ${ty+br*1.05} Z" fill="${P.nd}" ${SW}/>`,
   forked:`<path d="M${tx} ${ty} L${tx+br*1.4} ${ty+br*.5} L${tx+br*.9} ${ty+br*.4} L${tx+br*1.3} ${ty+br*.95} Z" fill="${P.nd}" ${SW}/>`,
   short:`<path d="M${tx} ${ty} L${tx+br*.7} ${ty+br*.3} L${tx+br*.5} ${ty+br*.6} Z" fill="${P.nd}" ${SW2}/>`,
   wedge:`<path d="M${tx} ${ty-2} L${tx+br*1.3} ${ty+br*.55} L${tx+br*1.1} ${ty+br*.8} L${tx-2} ${ty+br*.4} Z" fill="${P.nd}" ${SW}/>`,
   streamer:`<path d="M${tx} ${ty} Q${tx+br*1.4} ${ty+br*.6} ${tx+br*2.2} ${ty+br*1.5} Q${tx+br*1.2} ${ty+br*1.1} ${tx} ${ty+br*.5} Z" fill="${P.nd}" ${SW}/><path d="M${tx+4} ${ty+br*.3} Q${tx+br*1.3} ${ty+br*.9} ${tx+br*2} ${ty+br*1.45}" stroke="${P.ac}" stroke-width="2" fill="none"/>`,
   plume:`<path d="M${tx} ${ty} Q${tx+br*.8} ${ty-br*1.4} ${tx+br*1.9} ${ty-br*1.2} Q${tx+br*1.2} ${ty-br*.7} ${tx+br*1.5} ${ty-br*.1} Q${tx+br*.8} ${ty-br*.2} ${tx} ${ty+br*.5} Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<circle cx="${R1(tx+br*(1.3+i*.2))}" cy="${R1(ty-br*(1.1-i*.4))}" r="2.4" fill="${P.ac}" ${SW2}/>`).join("")}`,
   bustle:`<path d="M${tx-4} ${ty-4} Q${tx+br*.6} ${ty-br*1.6} ${tx+br*1.3} ${ty-br*.4} Q${tx+br*1.1} ${ty+br*.6} ${tx} ${ty+br*.5} Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${tx} ${ty} L${R1(tx+br*(.7+i*.25))} ${R1(ty-br*(1-i*.4))}" stroke="${P.ndd}" stroke-width="1.2"/>`).join("")}`}[o.tail];
  s+=pt("tail",R1(tx),R1(ty),T);
  s+=`<path d="M${R1(cx-3)} ${R1(cy+br*.7)} L${R1(cx-6)} ${gy}" stroke="${P.ac}" stroke-width="2.8" stroke-linecap="round"/>`;
  s+=`<path d="${fgBody(cx,cy,br,br*.78,2)}" fill="${P.n}" ${SW}/>`;
  if(o.bib)s+=`<path d="M${R1(cx-br*.95)} ${R1(cy-br*.1)} Q${R1(cx-br*.6)} ${R1(cy+br*.75)} ${R1(cx+br*.1)} ${R1(cy+br*.7)} Q${R1(cx-br*.3)} ${R1(cy+br*.1)} ${R1(cx-br*.6)} ${R1(cy-br*.5)} Z" fill="${P.nll}"/>`;
  s+=fgPattern(o.pat,cx+br*.15,cy+2,br*.7,br*.5,P,fgRng(o.seed||3));
  s+=`<path d="M${R1(cx+4)} ${R1(cy+br*.7)} L${R1(cx+2)} ${gy}" stroke="${P.ac}" stroke-width="2.8" stroke-linecap="round"/><path d="M${R1(cx-4)} ${gy} h-6 M${R1(cx-4)} ${gy} l-4 3 M${R1(cx+2)} ${gy} h-5" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`;
  const wy=o.wingUp?-1:1;
  s+=pt("wingF",R1(cx-br*.1),R1(cy-br*.3),o.wingUp?`<path d="M${R1(cx-br*.1)} ${R1(cy-br*.3)} Q${R1(cx+br*.4)} ${R1(cy-br*2)} ${R1(cx+br*1.4)} ${R1(cy-br*1.7)} Q${R1(cx+br*.9)} ${R1(cy-br*1.1)} ${R1(cx+br*.9)} ${R1(cy-br*.5)} Q${R1(cx+br*.4)} ${R1(cy-br*.2)} ${R1(cx-br*.1)} ${R1(cy-br*.1)} Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${R1(cx+br*(.2+i*.3))} ${R1(cy-br*.4)} L${R1(cx+br*(.5+i*.32))} ${R1(cy-br*(1.3+i*.1))}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`
   :`<path d="M${R1(cx-br*.3)} ${R1(cy-br*.35)} Q${R1(cx+br*.5)} ${R1(cy-br*.6)} ${R1(cx+br*1.05)} ${R1(cy+br*.15)} Q${R1(cx+br*.6)} ${R1(cy+br*.55)} ${R1(cx)} ${R1(cy+br*.35)} Q${R1(cx-br*.35)} ${R1(cy)} ${R1(cx-br*.3)} ${R1(cy-br*.35)} Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${R1(cx+br*(.2+i*.25))} ${R1(cy+br*(.05+i*.08))} l${R1(br*.3)} ${R1(br*.1)}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`);
  /* the head */
  let h=`<circle cx="${R1(hx)}" cy="${R1(hy)}" r="${hr}" fill="${P.n}" ${SW}/>`;
  if(o.crest==="tuft")h=pt("ear",R1(hx+hr*.3),R1(hy-hr*.8),`<path d="M${R1(hx)} ${R1(hy-hr*.8)} Q${R1(hx+hr*.6)} ${R1(hy-hr*2)} ${R1(hx+hr*1.3)} ${R1(hy-hr*1.6)} Q${R1(hx+hr*.8)} ${R1(hy-hr*1.2)} ${R1(hx+hr*.8)} ${R1(hy-hr*.6)} Z" fill="${P.nd}" ${SW2}/>`)+h;
  if(o.crest==="fan")h=pt("ear",R1(hx+hr*.2),R1(hy-hr*.8),[-40,-15,10,35].map(a=>{const t=a*Math.PI/180;return`<path d="M${R1(hx+hr*.2)} ${R1(hy-hr*.7)} L${R1(hx+hr*.2+Math.sin(t)*hr*1.4)} ${R1(hy-hr*.7-Math.cos(t)*hr*1.4)}" stroke="${FI}" stroke-width="4.4" stroke-linecap="round"/><path d="M${R1(hx+hr*.2)} ${R1(hy-hr*.7)} L${R1(hx+hr*.2+Math.sin(t)*hr*1.4)} ${R1(hy-hr*.7-Math.cos(t)*hr*1.4)}" stroke="${P.ac}" stroke-width="2.4" stroke-linecap="round"/>`}).join(""))+h;
  if(o.crest==="plume")h=pt("ear",R1(hx),R1(hy-hr),`<path d="M${R1(hx)} ${R1(hy-hr)} Q${R1(hx-hr*.4)} ${R1(hy-hr*2.4)} ${R1(hx+hr*.6)} ${R1(hy-hr*2.6)}" stroke="${FI}" stroke-width="1.6" fill="none"/><ellipse cx="${R1(hx+hr*.7)}" cy="${R1(hy-hr*2.6)}" rx="3" ry="4" fill="${P.ac}" ${SW2}/>`)+h;
  if(o.crest==="ears")h+=pt("ear",R1(hx+hr*.5),R1(hy-hr*.8),`<path d="M${R1(hx+hr*.2)} ${R1(hy-hr*.8)} L${R1(hx+hr*.6)} ${R1(hy-hr*1.6)} L${R1(hx+hr*.9)} ${R1(hy-hr*.6)} Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",R1(hx-hr*.4),R1(hy-hr*.8),`<path d="M${R1(hx-hr*.7)} ${R1(hy-hr*.6)} L${R1(hx-hr*.6)} ${R1(hy-hr*1.6)} L${R1(hx-hr*.1)} ${R1(hy-hr*.9)} Z" fill="${P.nd}" ${SW2}/>`,.3);
  if(o.mask)h+=`<path d="M${R1(hx-hr*.95)} ${R1(hy-hr*.2)} L${R1(hx+hr*.5)} ${R1(hy-hr*.35)} L${R1(hx+hr*.5)} ${R1(hy+hr*.1)} L${R1(hx-hr*.9)} ${R1(hy+hr*.2)} Z" fill="${P.ndd}" opacity=".85"/>`;
  const bx=hx-hr*.85,by=hy+hr*.1,bl={cone:hr*.7,thin:hr*1.1,dagger:hr*1.5,hook:hr*.8,hooksm:hr*.55,hookbig:hr*1}[o.beak],bh={cone:hr*.42,thin:hr*.18,dagger:hr*.24,hook:hr*.5,hooksm:hr*.38,hookbig:hr*.72}[o.beak];
  h+=`<path d="M${R1(bx+2)} ${R1(by)} L${R1(bx-bl*.8)} ${R1(by+1)} L${R1(bx+2)} ${R1(by+bh*.9)} Z" fill="${FMOUTH}"/>`;
  h+=pt("beak",R1(bx+2),R1(by+bh*.5),`<path d="M${R1(bx+2)} ${R1(by+bh*.4)} L${R1(bx-bl*.75)} ${R1(by+bh*.5)} Q${R1(bx-bl*.4)} ${R1(by+bh*1.15)} ${R1(bx+2)} ${R1(by+bh)} Z" fill="${P.d}" ${SW2}/>`);
  h+=/hook/.test(o.beak)?`<path d="M${R1(bx+3)} ${R1(by-bh*.6)} Q${R1(bx-bl*.9)} ${R1(by-bh*.7)} ${R1(bx-bl)} ${R1(by+bh*.6)} Q${R1(bx-bl*.6)} ${R1(by+bh*.1)} ${R1(bx+3)} ${R1(by+bh*.45)} Z" fill="${P.b}" ${SW2}/>`
     :`<path d="M${R1(bx+3)} ${R1(by-bh*.55)} L${R1(bx-bl)} ${R1(by+bh*.3)} L${R1(bx+3)} ${R1(by+bh*.45)} Z" fill="${P.b}" ${SW2}/>`;
  h+=fgEye(R1(hx-hr*.15),R1(hy-hr*.15),R1(hr*(/Owl/.test(o.sp)?.42:.32)),o.kind==="raptor"?"#E8A020":"#2A1A0A");
  if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,bx-bl*.6,by+bh*.5,14,-10);
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hr-3,14,0);
  s+=pt("head",R1(hx+hr*.6),R1(hy+hr*.6),h);
  if(o.acc&&!["hold","head"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+hr*.5,hy+hr*1.1],back:[cx+br*.3,cy-br*.95],side:[cx+br*.2,cy+br*.15],floor:[cx,gy+3]});
  s+=fG(g,1,`<path d="M${R1(cx-br*2)} ${R1(cy-br)} q-4 -4 0 -8" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="${R1(cx+br*.3)}" cy="${R1(cy+br*.2)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+br*.6),R1(Math.max(14,cy-br*1.8)),6));
  return s},
 parts:["head","jaw","tail","wing"],
 sig:o=>[o.kind,o.sp,o.beak,o.tail,o.crest,o.perch?1:0,o.wingUp?1:0,o.pat].join(".")};

/* ---- long-legged waders and big ground birds ---- */
FGP.wader={hab:{"z-wreck":3,"z-glacier":2,"z-volcano":1,"z-vault":1.2,"z-scrap":.8,"z-mine":.4,"z-crater":.8,"z-reactor":.6},loco:"perch",
 kinds:{wade:["Stork","Ibis","Egret","Avocet","Stilt","Curlew","Godwit","Bittern","Jabiru","Adjutant","Limpkin","Heron Chick","Hammerkop","Whimbrel"],ground:["Emu","Rhea","Cassowary","Seriema","Secretarybird","Bustard","Moa","Kiwi Chick"]},
 gen(r,tr,a){const kind=fgW(r,{wade:3,ground:tr.heavy?2.5:1});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.leg=R1(kind==="ground"?36+r()*10:40+r()*16);o.br=R1(kind==="ground"?28+r()*6:18+r()*6);o.neck=R1(kind==="ground"?26+r()*12:30+r()*20);o.hr=R1(kind==="ground"?11+r()*3:9+r()*3);
  o.bill=fgPick(r,kind==="ground"?["short","short","hook","casque"]:["straight","down","up","spoon","dagger","heavy"]);o.plume=fgPick(r,["none","none","back","nape","shag"]);o.water=kind==="wade"&&r()<.6;o.oneleg=kind==="wade"&&r()<.35;
  o.tail=fgPick(r,["short","fluff","none"]);o.pat=fgPick(r,["none","bands","spots","patch","none"]);return o},
 draw(P,g,o){const cx=118,gy=144,top=gy-o.leg,cy=top-o.br*.4,br=o.br,hx=cx-br*.6-o.neck*.35,hy=Math.max(22+o.hr,cy-o.neck),hr=o.hr;let s="";
  if(o.water)s+=`<path d="M20 140 Q100 132 186 142" stroke="#8AB4D8" stroke-width="3" fill="none"/>`;s+=fShadow(br*1.1,cx);
  s+=pt("legB",R1(cx+4),R1(top),o.oneleg?fOL(`M${R1(cx+4)} ${R1(top)} L${R1(cx+12)} ${R1(top+o.leg*.35)} L${R1(cx)} ${R1(top+o.leg*.42)}`,P.ac,3):fOL(`M${R1(cx+4)} ${R1(top)} L${R1(cx+8)} ${R1(top+o.leg*.5)} L${R1(cx+6)} ${gy}`,P.ac,3)+`<path d="M${R1(cx+6)} ${gy} h-8 M${R1(cx+6)} ${gy} l-5 2" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`,.5);
  if(o.tail==="fluff")s+=pt("tail",R1(cx+br),R1(cy),`<path d="M${R1(cx+br*.8)} ${R1(cy-4)} Q${R1(cx+br*1.8)} ${R1(cy-br*.4)} ${R1(cx+br*1.6)} ${R1(cy+br*.6)} Q${R1(cx+br*1.2)} ${R1(cy+br*.7)} ${R1(cx+br*.7)} ${R1(cy+br*.4)} Z" fill="${P.nl}" ${SW2}/>`);
  else if(o.tail==="short")s+=pt("tail",R1(cx+br),R1(cy),`<path d="M${R1(cx+br*.8)} ${R1(cy-2)} L${R1(cx+br*1.5)} ${R1(cy+br*.2)} L${R1(cx+br*.8)} ${R1(cy+br*.4)} Z" fill="${P.nd}" ${SW2}/>`);
  if(o.plume==="back")s+=pt("sway",R1(cx+br*.6),R1(cy-br*.4),`<path d="M${R1(cx)} ${R1(cy-br*.5)} Q${R1(cx+br*1.4)} ${R1(cy-br*1.4)} ${R1(cx+br*2)} ${R1(cy+br*.4)} Q${R1(cx+br*1.2)} ${R1(cy-br*.3)} ${R1(cx+br*.3)} ${R1(cy)} Z" fill="${P.nll}" ${SW2}/>`);
  s+=`<path d="${fgBody(cx,cy,br,br*(o.kind==="ground"?.85:.62),o.kind==="ground"?8:2)}" fill="${P.n}" ${SW}/>`+fgPattern(o.pat,cx,cy,br*.8,br*.5,P,fgRng(o.seed||5));
  s+=pt("wingF",R1(cx-br*.3),R1(cy-br*.3),`<path d="M${R1(cx-br*.4)} ${R1(cy-br*.35)} Q${R1(cx+br*.6)} ${R1(cy-br*.6)} ${R1(cx+br*1.1)} ${R1(cy+br*.2)} Q${R1(cx+br*.4)} ${R1(cy+br*.5)} ${R1(cx-br*.3)} ${R1(cy+br*.15)} Z" fill="${P.nd}" ${SW2}/>`);
  s+=pt("legF",R1(cx-4),R1(top),fOL(`M${R1(cx-4)} ${R1(top)} L${R1(cx-6)} ${R1(top+o.leg*.5)} L${R1(cx-4)} ${gy}`,P.ac,3)+`<path d="M${R1(cx-4)} ${gy} h-9 M${R1(cx-4)} ${gy} l-6 3 M${R1(cx-4)} ${gy} l3 2" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`);
  let h=fOL(`M${R1(cx-br*.7)} ${R1(cy-br*.2)} Q${R1(hx+o.neck*.5)} ${R1((cy+hy)/2+8)} ${R1(hx+4)} ${R1(hy+hr*.5)}`,P.n,R1(o.kind==="ground"?8:5.5));
  if(o.plume==="nape")h+=pt("ear",R1(hx+hr*.6),R1(hy-hr*.2),`<path d="M${R1(hx+hr*.5)} ${R1(hy-hr*.4)} Q${R1(hx+hr*2.6)} ${R1(hy-hr*.6)} ${R1(hx+hr*3.4)} ${R1(hy+hr*.6)}" stroke="${FI}" stroke-width="2.6" fill="none"/><path d="M${R1(hx+hr*.5)} ${R1(hy-hr*.4)} Q${R1(hx+hr*2.6)} ${R1(hy-hr*.6)} ${R1(hx+hr*3.4)} ${R1(hy+hr*.6)}" stroke="${P.nll}" stroke-width="1.2" fill="none"/>`);
  if(o.plume==="shag")h+=pt("ear",R1(hx+hr*.3),R1(hy-hr*.8),`${[-1,0,1].map(i=>`<path d="M${R1(hx+i*3)} ${R1(hy-hr*.8)} l${R1(i*4+4)} ${R1(-hr)}" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M${R1(hx+i*3)} ${R1(hy-hr*.8)} l${R1(i*4+4)} ${R1(-hr)}" stroke="${P.nd}" stroke-width="1.6" stroke-linecap="round"/>`).join("")}`);
  h+=`<circle cx="${R1(hx)}" cy="${R1(hy)}" r="${hr}" fill="${P.n}" ${SW}/>`;
  const bx=hx-hr*.8,by=hy+hr*.1,L={straight:hr*3,down:hr*3.2,up:hr*3,spoon:hr*2.8,dagger:hr*2.6,heavy:hr*2.4,short:hr*1.1,hook:hr*1.3,casque:hr*1.2}[o.bill];
  const curve={straight:0,down:hr*1.4,up:-hr*1.2,spoon:0,dagger:0,heavy:hr*.4,short:0,hook:hr*.5,casque:0}[o.bill],thick={heavy:hr*.5,dagger:hr*.3,casque:hr*.4}[o.bill]||hr*.24;
  h+=`<path d="M${R1(bx+2)} ${R1(by-thick*.2)} L${R1(bx-L*.85)} ${R1(by+curve*.8)} L${R1(bx+2)} ${R1(by+thick)} Z" fill="${FMOUTH}"/>`;
  h+=pt("beak",R1(bx+2),R1(by+thick*.5),`<path d="M${R1(bx+2)} ${R1(by+thick*.4)} Q${R1(bx-L*.5)} ${R1(by+thick*.6+curve*.4)} ${R1(bx-L*.92)} ${R1(by+curve+1)} Q${R1(bx-L*.4)} ${R1(by+thick*1.2+curve*.5)} ${R1(bx+2)} ${R1(by+thick*1.1)} Z" fill="${P.d}" ${SW2}/>`);
  h+=`<path d="M${R1(bx+3)} ${R1(by-thick*.6)} Q${R1(bx-L*.5)} ${R1(by-thick*.3+curve*.4)} ${R1(bx-L)} ${R1(by+curve)} Q${R1(bx-L*.5)} ${R1(by+thick*.4+curve*.5)} ${R1(bx+3)} ${R1(by+thick*.45)} Z" fill="${P.b}" ${SW2}/>`;
  if(o.bill==="spoon")h+=`<ellipse cx="${R1(bx-L)}" cy="${R1(by+1)}" rx="${R1(hr*.5)}" ry="${R1(hr*.4)}" fill="${P.b}" ${SW2}/>`;
  if(o.bill==="casque")h+=`<path d="M${R1(hx-hr*.6)} ${R1(hy-hr*.7)} Q${R1(hx-hr*.2)} ${R1(hy-hr*2.2)} ${R1(hx+hr*.5)} ${R1(hy-hr*.8)} Z" fill="${P.ac}" ${SW2}/>`;
  h+=fgEye(R1(hx-hr*.1),R1(hy-hr*.2),R1(hr*.34),"#C8A040");
  if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,bx-L*.8,by+4,13,0);
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hr-3,13,0);
  s+=pt("head",R1(cx-br*.6),R1(cy-br*.2),h);
  if(o.acc&&!["hold","head"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[cx-br*.6,cy-br*.1],back:[cx+br*.2,cy-br*.85],side:[cx+br*.1,cy+br*.1],floor:[cx,gy+3]});
  s+=fG(g,1,`<path d="M${R1(cx+br*1.6)} ${R1(cy-br)} l6 -4 M${R1(cx+br*1.6)} ${R1(cy-br+8)} l8 0" stroke="${P.l}" stroke-width="2" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="${R1(cx+br*.3)}" cy="${R1(cy)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+br),R1(Math.max(14,hy-hr-10)),6));
  return s},
 parts:["head","jaw","wing","leg"],
 sig:o=>[o.kind,o.sp,o.bill,o.plume,o.tail,o.water?1:0,o.oneleg?1:0].join(".")};

/* ---- birds on the water ---- */
FGP.fowl={hab:{"z-wreck":4,"z-glacier":3,"z-scrap":.5,"z-volcano":.3,"z-vault":.8,"z-mine":.3,"z-crater":.4,"z-reactor":.5},loco:"swim",
 sp:["Duck","Teal","Wigeon","Eider","Scoter","Merganser","Grebe","Loon","Coot","Moorhen","Goose","Brant","Shelduck","Pochard","Smew","Garganey","Pintail","Gadwall","Shoveler","Cygnet","Cormorant","Darter Chick"],
 gen(r,tr,a){const o={sp:fgPick(r,this.sp)};o.br=R1(26+r()*8);o.neck=R1(fgPick(r,[6,10,18,28]));o.hr=R1(10+r()*3);o.bill=fgPick(r,["flat","flat","point","hook","broad","knob"]);o.crest=fgPick(r,["none","none","tuft","shag","cap"]);
  o.tail=fgPick(r,["up","pin","flat"]);o.diving=r()<.2;o.pat=fgPick(r,["none","bands","spots","patch","scales"]);o.wave=fgPick(r,["calm","ripple","foam"]);return o},
 draw(P,g,o){const cx=112,wl=112,br=o.br,cy=wl-br*.25,hx=cx-br*.9,hy=cy-br*.4-o.neck,hr=o.hr;let s=`<ellipse class="shd" cx="104" cy="150" rx="56" ry="4" fill="#000" opacity=".12"/>`;
  s+=pt("tail",R1(cx+br),R1(cy-br*.1),o.tail==="up"?`<path d="M${R1(cx+br*.8)} ${R1(cy)} L${R1(cx+br*1.35)} ${R1(cy-br*.6)} L${R1(cx+br*1.2)} ${R1(cy+br*.1)} Z" fill="${P.nd}" ${SW2}/>`:o.tail==="pin"?`<path d="M${R1(cx+br*.8)} ${R1(cy)} L${R1(cx+br*1.8)} ${R1(cy-br*.35)} L${R1(cx+br*.9)} ${R1(cy+br*.2)} Z" fill="${P.nd}" ${SW2}/>`:`<path d="M${R1(cx+br*.8)} ${R1(cy)} Q${R1(cx+br*1.4)} ${R1(cy-br*.1)} ${R1(cx+br*1.3)} ${R1(cy+br*.3)} Z" fill="${P.nd}" ${SW2}/>`);
  s+=`<path d="M${R1(cx-br)} ${R1(cy)} Q${R1(cx-br)} ${R1(cy-br*.75)} ${R1(cx)} ${R1(cy-br*.7)} Q${R1(cx+br)} ${R1(cy-br*.7)} ${R1(cx+br*1.05)} ${R1(cy)} Q${R1(cx+br*.8)} ${R1(cy+br*.55)} ${R1(cx)} ${R1(cy+br*.55)} Q${R1(cx-br*.9)} ${R1(cy+br*.5)} ${R1(cx-br)} ${R1(cy)} Z" fill="${P.n}" ${SW}/>`+fgPattern(o.pat,cx+4,cy,br*.7,br*.35,P,fgRng(o.seed||7));
  s+=pt("wingF",R1(cx),R1(cy-br*.3),`<path d="M${R1(cx-br*.4)} ${R1(cy-br*.35)} Q${R1(cx+br*.5)} ${R1(cy-br*.7)} ${R1(cx+br*.95)} ${R1(cy-br*.05)} Q${R1(cx+br*.3)} ${R1(cy+br*.2)} ${R1(cx-br*.3)} ${R1(cy)} Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${R1(cx+br*(.1+i*.25))} ${R1(cy-br*(.2-i*.05))} l${R1(br*.25)} ${R1(br*.08)}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`);
  s+=`<path d="M10 ${wl} Q60 ${wl-5} 100 ${wl} Q150 ${wl+5} 194 ${wl-2} L194 160 L10 160 Z" fill="#8AB4D8" opacity=".38"/><path d="M10 ${wl} Q60 ${wl-5} 100 ${wl} Q150 ${wl+5} 194 ${wl-2}" stroke="#5A8AB8" stroke-width="2.4" fill="none"/>`;
  if(o.wave==="foam")s+=`<path d="M${R1(cx-br-6)} ${wl-1} q4 -5 8 0 q4 -5 8 0" stroke="#FFFFFF" stroke-width="2" fill="none"/>`;if(o.wave==="ripple")s+=`<path d="M${R1(cx-br*1.4)} ${wl+8} h16 M${R1(cx+br*.6)} ${wl+10} h20" stroke="#FFFFFF" stroke-width="1.6" opacity=".7"/>`;
  let h=o.neck>8?fOL(`M${R1(cx-br*.6)} ${R1(cy-br*.3)} Q${R1(hx+6)} ${R1((cy+hy)/2+6)} ${R1(hx+3)} ${R1(hy+hr*.5)}`,P.n,R1(hr*.9)):"";
  if(o.crest==="tuft")h+=pt("ear",R1(hx+hr*.5),R1(hy-hr*.5),`<path d="M${R1(hx+hr*.3)} ${R1(hy-hr*.7)} Q${R1(hx+hr*1.6)} ${R1(hy-hr*1.3)} ${R1(hx+hr*2)} ${R1(hy-hr*.3)} Q${R1(hx+hr*1.2)} ${R1(hy-hr*.6)} ${R1(hx+hr*.6)} ${R1(hy)} Z" fill="${P.nd}" ${SW2}/>`);
  if(o.crest==="shag")h+=pt("ear",R1(hx+hr*.3),R1(hy-hr*.6),`<path d="M${R1(hx-hr*.2)} ${R1(hy-hr*.8)} l${R1(hr*.4)} ${R1(-hr*.8)} l${R1(hr*.3)} ${R1(hr*.5)} l${R1(hr*.4)} ${R1(-hr*.6)} l${R1(hr*.3)} ${R1(hr*1.1)} Z" fill="${P.nd}" ${SW2}/>`);
  h+=`<circle cx="${R1(hx)}" cy="${R1(hy)}" r="${hr}" fill="${P.n}" ${SW}/>`;if(o.crest==="cap")h+=`<path d="M${R1(hx-hr)} ${R1(hy-hr*.1)} Q${R1(hx)} ${R1(hy-hr*1.5)} ${R1(hx+hr)} ${R1(hy-hr*.1)} Q${R1(hx)} ${R1(hy-hr*.6)} ${R1(hx-hr)} ${R1(hy-hr*.1)} Z" fill="${P.ndd}"/>`;
  const bx=hx-hr*.85,by=hy+hr*.15,L={flat:hr*1.3,point:hr*1.4,hook:hr*1.4,broad:hr*1.5,knob:hr*1.2}[o.bill],T={flat:hr*.28,point:hr*.2,hook:hr*.26,broad:hr*.36,knob:hr*.3}[o.bill];
  h+=`<path d="M${R1(bx+2)} ${R1(by)} L${R1(bx-L*.8)} ${R1(by+1)} L${R1(bx+2)} ${R1(by+T*1.4)} Z" fill="${FMOUTH}"/>`;
  h+=pt("beak",R1(bx+2),R1(by+T),`<path d="M${R1(bx+2)} ${R1(by+T*.8)} L${R1(bx-L*.85)} ${R1(by+T*.9)} Q${R1(bx-L*.9)} ${R1(by+T*1.6)} ${R1(bx-L*.6)} ${R1(by+T*1.6)} L${R1(bx+2)} ${R1(by+T*1.5)} Z" fill="${P.d}" ${SW2}/>`);
  h+=o.bill==="hook"?`<path d="M${R1(bx+3)} ${R1(by-T)} L${R1(bx-L)} ${R1(by)} Q${R1(bx-L*1.05)} ${R1(by+T*1.2)} ${R1(bx-L*.85)} ${R1(by+T*.9)} L${R1(bx+3)} ${R1(by+T*.8)} Z" fill="${P.b}" ${SW2}/>`
   :`<path d="M${R1(bx+3)} ${R1(by-T)} Q${R1(bx-L*.6)} ${R1(by-T*(o.bill==="broad"?1.4:1))} ${R1(bx-L)} ${R1(by)} Q${R1(bx-L*1.02)} ${R1(by+T)} ${R1(bx-L*.8)} ${R1(by+T*.9)} L${R1(bx+3)} ${R1(by+T*.8)} Z" fill="${P.b}" ${SW2}/>`;
  if(o.bill==="knob")h+=`<circle cx="${R1(bx-2)}" cy="${R1(by-T*1.4)}" r="${R1(hr*.32)}" fill="${P.ac}" ${SW2}/>`;
  h+=fgEye(R1(hx-hr*.1),R1(hy-hr*.2),R1(hr*.32),"#C84A3A");
  if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,bx-L*.6,by+T,13,0);if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hr-3,13,0);
  s+=pt("head",R1(cx-br*.6),R1(cy-br*.3),h);
  if(o.acc&&!["hold","head"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+hr*.4,hy+hr*1.2],back:[cx+br*.3,cy-br*.85],side:[cx+br*.1,cy],floor:[cx,wl+10]});
  s+=fG(g,1,`<circle cx="${R1(cx-br*1.6)}" cy="${wl+14}" r="3" fill="none" stroke="#FFFFFF" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="${R1(cx+br*.4)}" cy="${R1(cy-br*.2)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+br*.4),R1(Math.max(14,hy-hr-12)),6));
  return s},
 parts:["head","jaw","tail","wing"],
 sig:o=>[o.sp,o.bill,o.crest,o.tail,Math.round(o.neck/8),o.wave].join(".")};
