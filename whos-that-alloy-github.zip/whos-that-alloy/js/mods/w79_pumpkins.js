/* =============== PUMPKINS ===============
   Hollowmere carves neeps, the way it always has, but the rest of the country has taken to pumpkins, and this year they've turned up
   everywhere. Each place has done its pumpkin its own way. They stand on their own square like the other showpieces. */
const PK_O="#E8862A",PK_D="#C8641A",PK_L="#F6A84A",PK_K="#3A1A08",PK_G="#FFD27A";
/* one pumpkin: centre x, base y, scale, face kind, body colours */
function pumpkin(x,y,s,face,c){c=c||[PK_O,PK_D,PK_L];const w=15*s,h=11*s,t=y-h*2;
  let f="";if(face==="grin")f=`<path d="M${x-7*s} ${t+h*.75} L${x-4*s} ${t+h*.45} L${x-2.4*s} ${t+h*.85} Z M${x+7*s} ${t+h*.75} L${x+4*s} ${t+h*.45} L${x+2.4*s} ${t+h*.85} Z" fill="${PK_G}" stroke="${PK_K}" stroke-width=".6"/><path d="M${x-8*s} ${t+h*1.25} L${x-5*s} ${t+h*1.5} L${x-2.6*s} ${t+h*1.3} L${x} ${t+h*1.6} L${x+2.6*s} ${t+h*1.3} L${x+5*s} ${t+h*1.5} L${x+8*s} ${t+h*1.25} Q${x} ${t+h*2.05} ${x-8*s} ${t+h*1.25} Z" fill="${PK_G}" stroke="${PK_K}" stroke-width=".6"/>`;
  else if(face==="stars")f=[[x-5*s,t+h*.75,2.6],[x+5*s,t+h*.75,2.6],[x,t+h*1.4,2]].map(([a,b,r])=>`<path d="${Array.from({length:10},(_,i)=>{const R=i%2?r*s*.42:r*s,an=i/10*6.283-1.57;return(i?"L":"M")+(a+Math.cos(an)*R).toFixed(1)+" "+(b+Math.sin(an)*R).toFixed(1)}).join(" ")} Z" fill="${PK_G}" stroke="${PK_K}" stroke-width=".5"/>`).join("")+`<path d="M${x+2*s} ${t+h*.2} a${3*s} ${3*s} 0 1 0 ${3*s} ${3.4*s} a${2.2*s} ${2.2*s} 0 1 1 -${3*s} -${3.4*s} Z" fill="${PK_G}" opacity=".9"/>`;
  else if(face==="bolt")f=`<circle cx="${x-4.6*s}" cy="${t+h*.8}" r="${2.2*s}" fill="${PK_G}" stroke="#4A4A52" stroke-width="${1.2*s}"/><circle cx="${x+4.6*s}" cy="${t+h*.8}" r="${2.2*s}" fill="${PK_G}" stroke="#4A4A52" stroke-width="${1.2*s}"/><rect x="${x-6*s}" y="${t+h*1.25}" width="${12*s}" height="${3.4*s}" rx="${1*s}" fill="${PK_G}" stroke="#4A4A52" stroke-width="${.9*s}"/>${[-3,0,3].map(o=>`<path d="M${x+o*s} ${t+h*1.25} v${3.4*s}" stroke="#4A4A52" stroke-width=".7"/>`).join("")}`;
  return`<ellipse cx="${x}" cy="${y-.5}" rx="${w*.9}" ry="${2*s}" fill="#000" opacity=".28"/>
   <ellipse cx="${x-w*.5}" cy="${t+h}" rx="${w*.55}" ry="${h}" fill="${c[1]}" stroke="${PK_K}" stroke-width="1"/><ellipse cx="${x+w*.5}" cy="${t+h}" rx="${w*.55}" ry="${h}" fill="${c[1]}" stroke="${PK_K}" stroke-width="1"/>
   <ellipse cx="${x}" cy="${t+h}" rx="${w*.6}" ry="${h*1.02}" fill="${c[0]}" stroke="${PK_K}" stroke-width="1"/><path d="M${x-w*.25} ${t+h*.3} Q${x-w*.32} ${t+h} ${x-w*.25} ${t+h*1.7}" stroke="${c[2]}" stroke-width="${1.4*s}" fill="none" opacity=".8"/>
   <path d="M${x} ${t+1} Q${x+1*s} ${t-4*s} ${x+3*s} ${t-5*s}" stroke="#4A6A24" stroke-width="${2.4*s}" fill="none" stroke-linecap="round"/>${f}`}
/* the light inside, for carved ones: drawn once, and the candle's flame is the only thing that moves */
const PKL=(x,y,s)=>SG(x,y-11*s,13*s,"#FFB43A")+SF(x,y-6*s,.8*s,"#FFE7A0",(x*7+y)%9*.2);

/* QUILLMOOR: a specimen like any other, under a bell jar, tagged and catalogued */
show("z-quill",9,17,`<rect x="8" y="32" width="24" height="6" rx="1" fill="#6A4A2E" stroke="#2A1A0E" stroke-width=".9"/>${PKL(20,32,1)}${pumpkin(20,32,1,"grin")}
  <path d="M8 32 V6 Q8 -4 20 -4 Q32 -4 32 6 V32" fill="#DDF0FF" fill-opacity=".22" stroke="#9AB8CC" stroke-width="1.2"/><circle cx="20" cy="-6" r="2.2" fill="#9AB8CC"/><path d="M11 6 Q11 -1 16 -2" stroke="#FFFFFF" stroke-width="1.4" fill="none" opacity=".7"/>
  <path d="M30 34 l6 3 l-1 3 l-6 -2 Z" fill="#F4ECD8" stroke="#6A5A3A" stroke-width=".5"/><path d="M31 36 h3" stroke="#3A3A3A" stroke-width=".4"/>`,"Catalogued, tagged and put under a bell jar like everything else in here. The tag reads: 'Cucurbita, carved. Collected 31st October. Do NOT feed to the specimens.'");
/* RUSTVEIN: riding in an ore tub, with somebody's helmet lamp on its head */
show("z-mine",21,19,`<path d="M6 22 H34 L31 34 H9 Z" fill="#5A5A62" stroke="#1E1E24" stroke-width="1"/><path d="M6 22 H34" stroke="#8A8A92" stroke-width="1.6"/><circle cx="12" cy="36" r="2.6" fill="#2A2A30"/><circle cx="28" cy="36" r="2.6" fill="#2A2A30"/>
  ${PKL(20,24,1)}${pumpkin(20,24,1,"grin")}<path d="M12 3 Q20 -4 28 3 L28 5 H12 Z" fill="#E0B820" stroke="#5A4A10" stroke-width=".9"/><circle cx="20" cy="2" r="2.4" fill="#FFF2C8" stroke="#5A4A10" stroke-width=".6"/>${SG(20,2,6,"#FFF2C8")}`,"Somebody's put a pumpkin in an ore tub and lent it a helmet lamp. Nettie says it's the safest-lit thing in the whole mine.");
/* SCRAPYARD: patched with tin, eyes made of bolt-washers, a spring for a stalk */
show("z-scrap",36,2,`${PKL(20,36,1.1)}${pumpkin(20,36,1.1,"bolt",["#D07A2A","#A85A1A","#E8A050"])}
  <path d="M10 18 l6 -2 l2 6 l-6 2 Z" fill="#9AA0A8" stroke="#3A3A42" stroke-width=".7"/><circle cx="11.6" cy="18.4" r=".7" fill="#3A3A42"/><circle cx="16" cy="21" r=".7" fill="#3A3A42"/>
  <path d="M20 13 q-3 -2 0 -3 q3 -1 0 -3 q-3 -1 0 -3" stroke="#8A8A92" stroke-width="1.3" fill="none"/>`,"Bolt's pumpkin. He's patched it with tin, given it washer eyes and a spring for a stalk. 'It's not finished,' he says. Nothing Bolt makes is ever finished.");
/* COVE: netted on top of a lobster pot, with a bit of kelp for hair */
show("z-wreck",16,14,`<path d="M6 38 V28 Q20 20 34 28 V38 Z" fill="#8A6A3A" stroke="#3A2410" stroke-width="1"/>${[10,16,22,28].map(x=>`<path d="M${x} 38 V26" stroke="#5A3A1A" stroke-width=".8"/>`).join("")}
  ${PKL(20,26,1)}${pumpkin(20,26,1,"grin")}<path d="M7 26 Q20 0 33 26 M10 16 Q20 22 30 16 M13 9 Q20 14 27 9" stroke="#D8C8A0" stroke-width=".7" fill="none" opacity=".85"/><path d="M14 4 q-6 2 -8 8 M24 4 q5 3 6 9" stroke="#3A6A3A" stroke-width="1.8" fill="none"/>`,"Netted onto a lobster pot so the tide can't have it. Somebody has given it a bit of kelp for hair.");
/* CALDERA: roasting on hot stones, charred on one side, steaming */
show("z-volcano",16,13,`${[[8,36],[16,37],[24,37],[32,36],[12,33],[28,33]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="5" ry="3" fill="#3A2C28" stroke="#1E1612" stroke-width=".8"/><path d="M${x-2} ${y} h4" stroke="#FF8A2A" stroke-width="1"/>`).join("")}
  ${PKL(20,32,1)}${pumpkin(20,32,1,"grin",["#C86A2A","#7A3A1A","#E89050"])}<path d="M24 14 Q32 16 33 24 Q30 30 26 31" fill="#2A1A10" opacity=".55"/><path d="M14 8 q-4 -6 1 -10 M24 6 q4 -6 -1 -10" stroke="#C8C4C0" stroke-width="1.6" fill="none" opacity=".6" stroke-linecap="round"/>`,"Roasting on the hot stones, and it smells wonderful. One side's gone black. The forge hands are taking it in turns to keep an eye on it.");
/* GILDED VAULT: gilded, on a velvet cushion, with a brass plaque */
show("z-vault",34,9,`<path d="M4 34 Q4 28 20 28 Q36 28 36 34 Q36 39 20 39 Q4 39 4 34 Z" fill="#7A1E3A" stroke="#3A0A18" stroke-width="1"/>${[[5,33],[35,33]].map(([x,y])=>`<path d="M${x} ${y} l-2 3 M${x} ${y} l2 3" stroke="#D8B040" stroke-width="1"/>`).join("")}
  ${PKL(20,30,1)}${pumpkin(20,30,1,"grin",["#E8C040","#B8902A","#FFF0A0"])}<rect x="13" y="34" width="14" height="4" rx="1" fill="#D8B040" stroke="#5A4418" stroke-width=".6"/>`,"Gilded all over and set on a velvet cushion. The brass plaque says it's on loan to the Vault 'for the season, uninsured'.");
/* REACTOR: sealed in a glass case with a warning label, glowing a funny colour */
show("z-reactor",32,7,`<rect x="6" y="2" width="28" height="36" rx="2" fill="#DDF0FF" fill-opacity=".18" stroke="#6A706A" stroke-width="1.4"/><rect x="6" y="34" width="28" height="4" fill="#6A706A"/>
  ${SG(20,22,13,"#B8F07A")}${pumpkin(20,34,1,"grin",["#C8B84A","#8A8A2A","#E8E08A"])}<path d="M8 6 l6 -0 l-3 5 Z" fill="#F2C230" stroke="#1E1E22" stroke-width=".5"/><path d="M11 7.4 v1.6" stroke="#1E1E22" stroke-width=".6"/>`,"Sealed in a glass case with a warning label on it. The pumpkin itself is perfectly ordinary, they say. It's the glow that's being kept an eye on.");
/* FROSTBITE: frozen solid inside a block of ice, its grin still lit */
show("z-glacier",12,9,`${PKL(20,34,1)}${pumpkin(20,34,1,"grin")}<path d="M4 38 L3 10 L10 4 L32 3 L37 10 L36 38 Z" fill="#CFEAFA" fill-opacity=".45" stroke="#8AB0CC" stroke-width="1.2"/>
  <path d="M8 12 L14 7 M30 8 L34 14 M7 30 L10 24" stroke="#FFFFFF" stroke-width="1.2" opacity=".8"/>`,"Frozen solid inside a block of ice. Its candle is still going in there somehow. Nobody wants to be the one to find out how.");
/* STARFALL: carved with stars and a moon, sitting on a lump of meteorite */
show("z-crater",33,3,`<path d="M6 38 Q4 30 12 28 Q20 24 28 28 Q36 30 34 38 Z" fill="#4A4258" stroke="#1E1A2A" stroke-width="1"/><circle cx="12" cy="33" r="1.4" fill="#2A2438"/><circle cx="27" cy="34" r="1.8" fill="#2A2438"/>
  ${PKL(20,29,1)}${pumpkin(20,29,1,"stars")}`,"Carved with stars and a little moon instead of a face, and sat on a lump of the meteorite. The observers say it's the only pumpkin in the country that's correctly aligned.");
/* HOLLOWMERE: the village has started growing them as well as neeps */
show("z-hollow",33,9,`<path d="M0 34 Q10 28 18 34 Q28 40 40 32" stroke="#3A6A24" stroke-width="2" fill="none"/><path d="M6 31 q-3 -5 2 -7 q4 3 -2 7 Z M30 34 q-1 -6 4 -6 q2 4 -4 6 Z" fill="#4A8A2E" stroke="#2A4A14" stroke-width=".6"/>
  ${pumpkin(10,38,.7)}${pumpkin(31,38,.62)}${PKL(21,36,.95)}${pumpkin(21,36,.95,"grin")}`,"Hollowmere has started growing pumpkins alongside its neeps. The old ones grumble that a pumpkin's too easy to carve. They've carved one anyway.");
show("z-hollow",10,9,`${pumpkin(20,38,1.1)}${PKL(20,22,.85)}${pumpkin(20,22,.85,"grin")}${PKL(20,9,.6)}${pumpkin(20,9,.6,"grin")}`,"Three pumpkins stacked on a doorstep, biggest at the bottom. The top one's carved to look surprised about it.");
show("z-hollow",25,11,`<path d="M4 38 H36" stroke="#6A4A2A" stroke-width="2.4"/>${pumpkin(20,37,1.35)}<g transform="translate(31 18)"><circle r="5" fill="#C83A2A" stroke="#5A1010" stroke-width=".8"/><circle r="2.4" fill="#F2C94C"/><path d="M-2 4 L-4 11 M2 4 L4 11" stroke="#C83A2A" stroke-width="2"/></g>`,"This year's biggest pumpkin, with its first-prize rosette. Nobody's carving this one. They're going to make soup.");

/* ---- the encounter opener, for anything from Hollowmere ----
   The bars that sweep across the screen are lit pumpkin instead of black, and a carved jack-o'-lantern face comes up over them.
   A Radiant one keeps its gold bars, with the same face cut into them. */
const JACK_FACE=(()=>{const top=[],bot=[];const N=11;
  for(let i=0;i<=N;i++){const f=i/N,x=26+f*188,base=146+Math.sin(f*Math.PI)*16;top.push(`${x.toFixed(1)} ${base.toFixed(1)}`);if(i<N){const xm=x+188/N/2,bm=146+Math.sin((f+.5/N)*Math.PI)*16+20;top.push(`${xm.toFixed(1)} ${bm.toFixed(1)}`)}}
  for(let i=N;i>=0;i--){const f=i/N,x=30+f*180,base=200+Math.sin(f*Math.PI)*22;bot.push(`${x.toFixed(1)} ${base.toFixed(1)}`);if(i>0){const xm=x-180/N/2,bm=200+Math.sin((f-.5/N)*Math.PI)*22-20;bot.push(`${xm.toFixed(1)} ${bm.toFixed(1)}`)}}
  return`<svg viewBox="0 0 240 260" aria-hidden="true"><g fill="#0A0604">
   <path d="M40 54 Q56 98 106 104 Q110 86 96 78 Q72 66 40 54 Z"/><path d="M200 54 Q184 98 134 104 Q130 86 144 78 Q168 66 200 54 Z"/>
   <path d="M120 112 L134 136 L106 136 Z"/>
   <path d="M14 118 Q20 136 26 146 L${top.join(" L")} L214 146 Q220 136 226 118 Q224 168 210 200 L${bot.join(" L")} L30 200 Q16 168 14 118 Z"/></g></svg>`})();
function lntEncounterKind(){const isH=n=>LNT_NAMES.has(n)||n===GW_NAME,sa=EXP.storyAlloy&&EXP.storyAlloy.name;if(sa)return isH(sa);
  /* the tutorial's practice sample counts too, when it's a Hollowmere one */
  if(typeof TUT!=="undefined"&&TUT.on&&TUT.i<=3&&typeof TUT_ALLOY!=="undefined"&&isH(TUT_ALLOY))return true;
  return typeof inHollow==="function"&&inHollow()}
{const _en=encounter;encounter=function(){const w=$("#wipe"),lnt=lntEncounterKind();_en();if(!w)return;w.classList.toggle("lnt",!!lnt);
  let f=w.querySelector(".wface");if(lnt){if(!f){f=document.createElement("b");f.className="wface";f.innerHTML=JACK_FACE;w.appendChild(f)}}else if(f)f.remove()}}
