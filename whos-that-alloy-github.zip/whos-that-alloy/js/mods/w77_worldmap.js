/* =============== THE MAP OF DROSSMARCH ===============
   A painted map of the whole land, laid out the way it would be if you walked between places instead of being sent: Quillmoor on the
   moor in the middle, roads out to every site, the bay in the south with the Caldera smoking on its island.
   Only buildings you can actually go into are drawn as buildings. Anything you haven't found yet isn't on the map at all.
   The picture is painted once (when the map is first opened, or when something new has been found) and then just shown. */
const WM={W:1200,H:840,img:null,key:"",sel:null};

/* ---- the land ---- */
const WM_LAND=[[118,168],[210,112],[330,96],[450,118],[560,92],[690,80],[820,92],[930,104],[1040,140],[1104,226],[1098,330],[1112,428],[1088,520],[1108,600],[1060,668],[960,700],[860,686],[806,640],[782,566],[730,522],[660,500],[590,498],[530,520],[492,576],[478,650],[440,700],[352,716],[262,706],[188,668],[134,594],[100,506],[92,410],[100,312],[98,232]];
const WM_ISLE=[[550,698],[584,660],[634,650],[684,666],[706,704],[690,752],[644,774],[590,768],[556,742]];
/* the Cove's Assay Hall stands on its own rock, joined to the island by a causeway (as it is when you're there) */
const WM_ISLET=[[722,728],[748,716],[772,726],[776,750],[754,764],[728,758]];
const WM_ROCKS=[[372,782,9],[402,800,6],[1000,760,8],[1028,744,5],[150,760,7],[860,770,6],[520,640,6]];
/* where things are */
const WM_P={
 "z-quill":{x:380,y:360,nm:"Quillmoor",r:58},
 "z-mine":{x:240,y:190,nm:"Rustvein Mine",r:50},
 "z-glacier":{x:630,y:168,nm:"Frostbite Cavern",r:48},
 "z-vault":{x:880,y:240,nm:"Gilded Vault",r:54},
 "z-reactor":{x:1036,y:368,nm:"Old Reactor Hall",r:50},
 "z-volcano":{x:716,y:420,nm:"Emberforge Caldera",r:56},
 "z-crater":{x:938,y:590,nm:"Starfall Crater",r:56},
 "z-scrap":{x:206,y:500,nm:"Tinker's Scrapyard",r:52},
 "z-slag":{x:262,y:626,nm:"The Slag Works",r:46},
 "z-wreck":{x:628,y:706,nm:"Sunken Galleon Cove",r:52},
 "z-hollow":{x:390,y:556,nm:"Hollowmere",r:40}};
/* each Assay Hall stands just off its site, by a road in */
const WM_HALL={"z-mine":[300,268],"z-glacier":[700,196],"z-vault":[944,286],"z-reactor":[1020,438],"z-scrap":[278,462],"z-wreck":[750,740],"z-volcano":[812,488],"z-crater":[862,628]};
/* the roads make a ring round the land, like any proper region: no one place is the middle of everything */
const WM_ROADS=[
 {k:"quillMine",p:[[372,322],[330,296],[300,268],[262,224]]},
 {k:"mineFrost",p:[[262,170],[340,136],[440,122],[540,136],[606,162]]},
 {k:"frostVault",p:[[656,178],[700,196],[780,212],[852,234]]},
 {k:"vaultReact",p:[[910,258],[944,286],[990,322],[1028,352]]},
 {k:"reactCrater",p:[[1034,400],[1020,438],[996,500],[958,560]]},
 {k:"craterEmber",p:[[904,582],[862,560],[812,488],[760,450]]},
 {k:"emberQuill",p:[[672,416],[600,404],[520,388],[426,368]]},
 {k:"quillScrap",p:[[350,392],[278,462],[236,488]]},
 {k:"pier",p:[[884,616],[862,628],[818,644],[800,650]]},
 {k:"slag",p:[[214,532],[232,580],[252,604]],secret:"slag"}];
/* the only way to the Cove: the ferry from the pier on the Starfall shore */
const WM_FERRY=[[796,652],[752,668],[704,682],[676,690]];
const WM_RIVER=[[590,150],[566,212],[528,282],[496,340],[476,420],[486,486],[506,540],[530,578]];
/* ---- little geometry kit ---- */
function wmIn(pt,poly){let c=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const[a,b]=poly[i],[d,e]=poly[j];if((b>pt[1])!==(e>pt[1])&&pt[0]<(d-a)*(pt[1]-b)/(e-b)+a)c=!c}return c}
function wmSegD(p,a,b){const dx=b[0]-a[0],dy=b[1]-a[1],L=dx*dx+dy*dy||1;let t=((p[0]-a[0])*dx+(p[1]-a[1])*dy)/L;t=Math.max(0,Math.min(1,t));return Math.hypot(p[0]-a[0]-t*dx,p[1]-a[1]-t*dy)}
function wmLineD(p,L){let m=1e9;for(let i=1;i<L.length;i++)m=Math.min(m,wmSegD(p,L[i-1],L[i]));return m}
function wmPolyD(p,poly){let m=1e9;for(let i=0;i<poly.length;i++)m=Math.min(m,wmSegD(p,poly[i],poly[(i+1)%poly.length]));return m}
/* smooth closed / open curves through the points */
function wmCurve(P,closed){const n=P.length,g=i=>closed?P[(i+n)%n]:P[Math.max(0,Math.min(n-1,i))];let d=`M${P[0][0]} ${P[0][1]}`;const m=closed?n:n-1;
  for(let i=0;i<m;i++){const p0=g(i-1),p1=g(i),p2=g(i+1),p3=g(i+2);d+=` C${(p1[0]+(p2[0]-p0[0])/6).toFixed(1)} ${(p1[1]+(p2[1]-p0[1])/6).toFixed(1)} ${(p2[0]-(p3[0]-p1[0])/6).toFixed(1)} ${(p2[1]-(p3[1]-p1[1])/6).toFixed(1)} ${p2[0]} ${p2[1]}`}return d+(closed?" Z":"")}
/* a wobbly blob, for painted patches */
function wmBlob(cx,cy,rx,ry,R,n){n=n||11;const P=[];for(let i=0;i<n;i++){const a=i/n*6.283,k=.78+R()*.4;P.push([+(cx+Math.cos(a)*rx*k).toFixed(1),+(cy+Math.sin(a)*ry*k).toFixed(1)])}return wmCurve(P,true)}

/* ---- what the map should show right now ---- */
function wmState(){const st={slag:typeof slagOpen==="function"&&slagOpen(),hollow:typeof lntOn==="function"&&lntOn()&&typeof lntF==="function"&&!!lntF("hm"),
  base:typeof Q!=="undefined"&&Q.s>=8,study:typeof Q!=="undefined"&&Q.s>=11};
  let seals=[];try{seals=(asData().seals||[]).slice()}catch(e){}st.seals=seals;return st}
function wmHere(){if(typeof EXP==="undefined"||!EXP.zone)return null;if(typeof inHollow==="function"&&inHollow())return"z-hollow";const c=EXP.zone.cls;return c==="z-basement"?"z-quill":c}

/* ================= THE PAINTING ================= */
function wmPaint(st){const R=mulberry(20261029),W=WM.W,H=WM.H,L=WM_LAND;
  const roads=WM_ROADS.filter(r=>!r.secret||st[r.secret]);
  const sites=Object.keys(WM_P).filter(k=>(k!=="z-slag"||st.slag)&&(k!=="z-hollow"||st.hollow));
  const land=wmCurve(L,true),isle=wmCurve(WM_ISLE,true),islet=wmCurve(WM_ISLET,true);
  let s=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W*2}" height="${H*2}">
  <defs>
   <filter id="paint" x="-2%" y="-2%" width="104%" height="104%"><feTurbulence type="fractalNoise" baseFrequency=".035" numOctaves="3" seed="4" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="5" xChannelSelector="R" yChannelSelector="G"/></filter>
   <filter id="brush" x="-5%" y="-5%" width="110%" height="110%"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="2" seed="9" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="1.6" xChannelSelector="R" yChannelSelector="G"/></filter>
   <filter id="soft"><feGaussianBlur stdDeviation="7"/></filter><filter id="soft2"><feGaussianBlur stdDeviation="16"/></filter><filter id="soft1"><feGaussianBlur stdDeviation="2.2"/></filter>
   <filter id="grain" x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency=".75" numOctaves="2" seed="2"/><feColorMatrix values="0 0 0 0 .5  0 0 0 0 .45  0 0 0 0 .38  0 0 0 .55 -.18"/></filter>
   <radialGradient id="sea" cx=".5" cy=".55" r=".75"><stop offset="0" stop-color="#3E86D0"/><stop offset=".6" stop-color="#2A62B0"/><stop offset="1" stop-color="#173A80"/></radialGradient>
   <radialGradient id="lava" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFE7A0"/><stop offset=".45" stop-color="#FF9A2E"/><stop offset="1" stop-color="#C8321E"/></radialGradient>
   <radialGradient id="glow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFD890" stop-opacity=".85"/><stop offset="1" stop-color="#FFD890" stop-opacity="0"/></radialGradient>
   <radialGradient id="cloud" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFFFFF" stop-opacity=".95"/><stop offset=".6" stop-color="#EEF2FA" stop-opacity=".8"/><stop offset="1" stop-color="#E4EAF6" stop-opacity="0"/></radialGradient>
   <linearGradient id="snow" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFFFFF"/><stop offset="1" stop-color="#C8DCEE"/></linearGradient>
   <clipPath id="landC"><path d="${land}"/><path d="${isle}"/><path d="${islet}"/></clipPath>
  </defs>
  <rect width="${W}" height="${H}" fill="url(#sea)"/>`;
  /* the sea: long brushed swells, lighter shallows hugging every shore */
  let sw="";for(let i=0;i<260;i++){const x=R()*W,y=R()*H;if(wmIn([x,y],L)||wmIn([x,y],WM_ISLE)||wmIn([x,y],WM_ISLET))continue;const l=8+R()*22;sw+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} q${(l/2).toFixed(0)} -${(2+R()*3).toFixed(1)} ${l.toFixed(0)} 0" stroke="#9CD0F4" stroke-width="${(1+R()*1.4).toFixed(1)}" fill="none" opacity="${(.18+R()*.3).toFixed(2)}" stroke-linecap="round"/>`}
  s+=`<g>${sw}</g>`;
  s+=`<g filter="url(#soft)" opacity=".9"><path d="${land}" fill="none" stroke="#7CC8EE" stroke-width="58"/><path d="${isle}" fill="none" stroke="#7CC8EE" stroke-width="50"/><path d="${islet}" fill="none" stroke="#7CC8EE" stroke-width="36"/>${WM_ROCKS.map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r*2.4}" fill="#7CC8EE"/>`).join("")}</g>
   <g filter="url(#soft1)"><path d="${land}" fill="none" stroke="#B4E2F6" stroke-width="20" opacity=".8"/><path d="${isle}" fill="none" stroke="#B4E2F6" stroke-width="18" opacity=".8"/><path d="${islet}" fill="none" stroke="#B4E2F6" stroke-width="14" opacity=".8"/></g>`;
  /* little rocks out at sea */
  s+=WM_ROCKS.map(([x,y,r])=>`<ellipse cx="${x}" cy="${y+r*.3}" rx="${r*1.2}" ry="${r*.5}" fill="#DDF2FC" opacity=".7"/><path d="M${x-r} ${y+r*.3} Q${x-r*.6} ${y-r} ${x} ${y-r*.9} Q${x+r*.8} ${y-r*.7} ${x+r} ${y+r*.3} Z" fill="#8A8478" stroke="#4A463E" stroke-width="1.2"/><path d="M${x-r*.5} ${y-r*.3} Q${x} ${y-r*.8} ${x+r*.4} ${y-r*.4}" stroke="#C8C0B0" stroke-width="1.4" fill="none"/>`).join("");

  /* ---------- the land itself ---------- */
  let g=`<path d="${land}" fill="#E6D49A"/><path d="${isle}" fill="#E8D8A0"/><path d="${islet}" fill="#B8AE98"/>`;
  const inner=L.map(([x,y])=>{const cx=600,cy=400,dx=x-cx,dy=y-cy,d=Math.hypot(dx,dy);return[x-dx/d*9,y-dy/d*9]});
  g+=`<path d="${wmCurve(inner,true)}" fill="#5C9C3A"/><path d="${wmBlob(628,702,58,36,mulberry(31),10)}" fill="#6AA846"/>`;
  /* painted ground: each area has its own ground under the trees */
  const patch=(cx,cy,rx,ry,c,o,blur)=>`<path d="${wmBlob(cx,cy,rx,ry,R,13)}" fill="${c}" opacity="${o}" filter="url(#${blur||"soft2"})"/>`;
  g+=`<g clip-path="url(#landC)">
   ${patch(600,420,520,300,"#6AAA44",.6)}${patch(330,560,180,120,"#4E8A34",.5)}${patch(820,460,200,140,"#5A9A3A",.5)}
   ${patch(380,360,160,104,"#A0A468",.9)}${patch(380,360,104,66,"#B4AE7A",.7,"soft")}
   ${patch(240,180,170,100,"#8E7E66",.95)}${patch(610,150,170,82,"#C8D8E8",.95)}${patch(610,140,110,56,"#F2F6FA",.9,"soft")}${patch(716,420,120,84,"#5A4A42",.95)}${patch(716,420,64,44,"#6E5A4E",.9,"soft")}
   ${patch(206,500,118,84,"#B8A07A",.9)}${patch(206,500,70,50,"#C6AE84",.8,"soft")}
   ${patch(880,240,130,84,"#86B85A",.85)}${patch(1036,368,92,96,"#A8C27A",.85)}
   ${patch(938,590,140,92,"#C2B676",.85)}${patch(938,590,90,56,"#D0C48A",.7,"soft")}
   ${st.slag?patch(262,626,90,64,"#8A8580",.95):""}${st.hollow?patch(390,556,74,56,"#3A4A3A",.85):""}
  </g>`;
  /* the coast: a thin sandy beach where land meets sea, a bright sand bar at the Cove */
  g+=`<path d="${land}" fill="none" stroke="#F0E2B0" stroke-width="7" opacity=".9"/><path d="${isle}" fill="none" stroke="#F4E8BC" stroke-width="6"/><path d="${islet}" fill="none" stroke="#6A6252" stroke-width="2"/>`;
  
  /* the river, from the snow down through the moor to the bay */
  const rv=wmCurve(WM_RIVER,false);g+=`<path d="${rv}" stroke="#2E66B0" stroke-width="12" fill="none" stroke-linecap="round"/><path d="${rv}" stroke="#5EA4E4" stroke-width="7" fill="none" stroke-linecap="round"/><path d="${rv}" stroke="#A8D8F8" stroke-width="2" fill="none" stroke-dasharray="6 10" stroke-linecap="round"/>`;
  /* the mere in the hollow, if you've been there */
  if(st.hollow)g+=`<ellipse cx="356" cy="576" rx="20" ry="9" fill="#24364A"/><ellipse cx="352" cy="574" rx="10" ry="3" fill="#5A7A9A" opacity=".6"/>`;

  /* ---------- mountains ---------- */
  const peaks=[];const range=(cx,cy,rx,ry,n,snow,avoid)=>{for(let i=0;i<n;i++){const a=R()*6.283,k=Math.sqrt(R());const x=cx+Math.cos(a)*rx*k,y=cy+Math.sin(a)*ry*k;if(!wmIn([x,y+10],L))continue;if(avoid&&Math.hypot(x-avoid[0],y-avoid[1])<avoid[2])continue;
    if(roads.some(r=>wmLineD([x,y+8],r.p)<22))continue;peaks.push({x,y,w:26+R()*24,h:24+R()*22,snow})}};
  range(222,166,160,80,46,false,[240,190,34]);range(610,146,180,66,44,true,[630,168,30]);range(1060,214,40,60,8,false);range(150,330,40,60,8,false);range(716,420,104,72,40,"ash",[716,420,60]);
  peaks.sort((a,b)=>a.y-b.y);
  g+=peaks.map(p=>{const{x,y,w,h}=p,ash=p.snow==="ash",snow=p.snow===true,t=y-h,lc=snow?"#E8F0F8":ash?"#6A5A52":"#B8A88A",dc=snow?"#A8BCD4":ash?"#3E3230":"#7A6A52",ol=snow?"#5A6A84":ash?"#1E1614":"#4A3E30";
    let m=`<path d="M${(x-w/2).toFixed(1)} ${y.toFixed(1)} L${(x-w*.06).toFixed(1)} ${t.toFixed(1)} L${x.toFixed(1)} ${(y-h*.25).toFixed(1)} Z" fill="${lc}"/><path d="M${(x-w*.06).toFixed(1)} ${t.toFixed(1)} L${(x+w/2).toFixed(1)} ${y.toFixed(1)} L${x.toFixed(1)} ${(y-h*.25).toFixed(1)} Z" fill="${dc}"/>`;
    if(ash&&R()<.5)m+=`<path d="M${(x-w*.06).toFixed(1)} ${t.toFixed(1)} Q${(x-w*.1).toFixed(1)} ${(t+h*.4).toFixed(1)} ${(x-w*.2).toFixed(1)} ${(y-2).toFixed(1)}" stroke="#E8642A" stroke-width="1.6" fill="none" opacity=".8"/>`;if(!snow&&!ash&&R()<.7)m+=`<path d="M${(x-w*.06).toFixed(1)} ${t.toFixed(1)} L${(x-w*.2).toFixed(1)} ${(t+h*.3).toFixed(1)} L${(x-w*.05).toFixed(1)} ${(t+h*.24).toFixed(1)} L${(x+w*.1).toFixed(1)} ${(t+h*.32).toFixed(1)} Z" fill="#E8E0D0" opacity=".9"/>`;
    if(snow)m+=`<path d="M${(x-w*.06).toFixed(1)} ${t.toFixed(1)} L${(x-w*.28).toFixed(1)} ${(t+h*.42).toFixed(1)} L${(x-w*.1).toFixed(1)} ${(t+h*.34).toFixed(1)} L${(x+w*.04).toFixed(1)} ${(t+h*.46).toFixed(1)} L${(x+w*.22).toFixed(1)} ${(t+h*.36).toFixed(1)} Z" fill="#FFFFFF"/>`;
    return m+`<path d="M${(x-w/2).toFixed(1)} ${y.toFixed(1)} L${(x-w*.06).toFixed(1)} ${t.toFixed(1)} L${(x+w/2).toFixed(1)} ${y.toFixed(1)}" fill="none" stroke="${ol}" stroke-width="1.6" stroke-linejoin="round"/>`}).join("");

  /* ---------- roads ---------- */
  const rd=roads.map(r=>wmCurve(r.p,false));
  g+=`<g fill="none" stroke-linecap="round" stroke-linejoin="round">${rd.map(d=>`<path d="${d}" stroke="#4E6A2E" stroke-width="19" opacity=".55"/>`).join("")}${rd.map(d=>`<path d="${d}" stroke="#7A5E36" stroke-width="13"/>`).join("")}${rd.map(d=>`<path d="${d}" stroke="#E8D49A" stroke-width="9.5"/>`).join("")}${rd.map(d=>`<path d="${d}" stroke="#F6E8BE" stroke-width="2" stroke-dasharray="2 9" opacity=".9"/>`).join("")}</g>`;
  /* bridges where roads cross the river */
  const bridge=(x,y,a)=>`<g transform="translate(${x} ${y}) rotate(${a})"><rect x="-13" y="-7" width="26" height="14" rx="2" fill="#9A6A3A" stroke="#4A2E16" stroke-width="1.6"/>${[-9,-3,3,9].map(o=>`<path d="M${o} -7 V7" stroke="#6A4420" stroke-width="1"/>`).join("")}<path d="M-13 -7 H13 M-13 7 H13" stroke="#3A2410" stroke-width="2.2"/></g>`;
  /* bridges go wherever a road actually crosses the river (checked on the drawn curves, sampled finely) */
  const samp=(P,n)=>{const d=wmCurve(P,false),pts=[];const ns="http://www.w3.org/2000/svg",pe=document.createElementNS(ns,"path");pe.setAttribute("d",d);const Lh=pe.getTotalLength();for(let i=0;i<=n;i++){const q=pe.getPointAtLength(Lh*i/n);pts.push([q.x,q.y])}return pts};
  const rvS=samp(WM_RIVER,160);roads.forEach(r=>{const rs=samp(r.p,120);for(let i=1;i<rs.length;i++){for(let j=1;j<rvS.length;j++){const[a,b]=[rs[i-1],rs[i]],[c,d]=[rvS[j-1],rvS[j]];
    const den=(b[0]-a[0])*(d[1]-c[1])-(b[1]-a[1])*(d[0]-c[0]);if(!den)continue;const t=((c[0]-a[0])*(d[1]-c[1])-(c[1]-a[1])*(d[0]-c[0]))/den,u=((c[0]-a[0])*(b[1]-a[1])-(c[1]-a[1])*(b[0]-a[0]))/den;
    if(t>=0&&t<=1&&u>=0&&u<=1){g+=bridge((a[0]+t*(b[0]-a[0])).toFixed(1),(a[1]+t*(b[1]-a[1])).toFixed(1),(Math.atan2(b[1]-a[1],b[0]-a[0])*57.3).toFixed(0))}}}});
  /* the ferry across the bay (drawn on the sea, later) */

  /* ---------- tall grass along the roads, the way you'd find it on any route ---------- */
  const grass=[];roads.forEach(r=>{for(let i=1;i<r.p.length;i++){const[a,b]=[r.p[i-1],r.p[i]];if(R()<.55){const t=.3+R()*.4,nx=-(b[1]-a[1]),ny=b[0]-a[0],nl=Math.hypot(nx,ny)||1,sd=R()<.5?-1:1,
    cx=a[0]+(b[0]-a[0])*t+nx/nl*sd*22,cy=a[1]+(b[1]-a[1])*t+ny/nl*sd*22;if(wmIn([cx,cy],L)&&!Object.values(WM_P).some(p=>Math.hypot(p.x-cx,p.y-cy)<p.r*.9))grass.push([cx,cy,14+R()*10,8+R()*5])}}});
  g+=grass.map(([cx,cy,rx,ry])=>{let t=`<ellipse cx="${cx.toFixed(0)}" cy="${cy.toFixed(0)}" rx="${rx.toFixed(0)}" ry="${ry.toFixed(0)}" fill="#4E9A34" stroke="#2E6A22" stroke-width="1.2"/>`;
    for(let i=0;i<14;i++){const x=cx+(R()-.5)*rx*1.6,y=cy+(R()-.5)*ry*1.4;t+=`<path d="M${(x-2).toFixed(1)} ${(y+2).toFixed(1)} L${x.toFixed(1)} ${(y-3).toFixed(1)} L${(x+2).toFixed(1)} ${(y+2).toFixed(1)}" stroke="#9AD86A" stroke-width="1.3" fill="none"/>`}return t}).join("");
  /* the moor round Quillmoor flowers; the coast has dune grass */
  for(let i=0;i<60;i++){const a=R()*6.283,k=.45+R()*.5,x=560+Math.cos(a)*150*k,y=350+Math.sin(a)*96*k;if(roads.some(r=>wmLineD([x,y],r.p)<10)||Math.hypot(x-560,(y-350)*1.6)<70)continue;g+=`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(1.3+R()*1.2).toFixed(1)}" fill="${["#B88AC8","#F2E2A0","#E8A0B8"][i%3]}"/>`}
  /* ---------- trees: everywhere that isn't road, water, rock, sand or a site ---------- */
  const T=[],sp=15,bare=[[240,176,150,86],[610,146,160,70],[206,500,108,78],[938,590,122,78],[380,360,108,72],[1036,368,64,64],[880,240,80,56],[716,420,108,78]];
  if(st.slag)bare.push([262,626,86,60]);if(st.hollow)bare.push([390,556,40,30]);
  for(let y=96;y<H;y+=sp*.82)for(let x=80;x<W;x+=sp){const px=x+(R()-.5)*sp*.9,py=y+(R()-.5)*sp*.7;
    if(!wmIn([px,py+6],L))continue;if(wmPolyD([px,py],L)<16)continue;
    if(roads.some(r=>wmLineD([px,py+4],r.p)<15))continue;if(wmLineD([px,py+4],WM_RIVER)<12)continue;
    let skip=false,edge=0;for(const[cx,cy,rx,ry]of bare){const e=((px-cx)/rx)**2+((py-cy)/ry)**2;if(e<1){skip=true;break}if(e<1.6)edge=Math.max(edge,1.6-e)}
    if(skip&&R()>.06)continue;if(edge&&R()<edge*.8)continue;
    if(peaks.some(p=>Math.abs(px-p.x)<p.w*.45&&py<p.y+4&&py>p.y-p.h))continue;
    const north=py<220,k=north&&R()<.75?"pine":R()<.12?"dark":"round";T.push({x:px,y:py,k,s:.85+R()*.4})}
  /* the Cove's island: palms and scrub round a sandy middle */
  for(let i=0;i<30;i++){const a=R()*6.283,x=628+Math.cos(a)*(40+R()*20),y=704+Math.sin(a)*(24+R()*14);if(wmIn([x,y+4],WM_ISLE)&&wmPolyD([x,y],WM_ISLE)>9&&Math.hypot(x-628,(y-706)*1.5)>34)T.push({x,y,k:"round",s:.7+R()*.3})}
  T.sort((a,b)=>a.y-b.y);
  g+=T.map(t=>{const{x,y,s}=t,X=x.toFixed(1),Y=y.toFixed(1);
    if(t.k==="pine")return`<ellipse cx="${X}" cy="${(y+5*s).toFixed(1)}" rx="${(6*s).toFixed(1)}" ry="${(2.2*s).toFixed(1)}" fill="#1E3A1A" opacity=".45"/><path d="M${X} ${(y-13*s).toFixed(1)} L${(x+7*s).toFixed(1)} ${(y+4*s).toFixed(1)} L${(x-7*s).toFixed(1)} ${(y+4*s).toFixed(1)} Z" fill="#2E5A34" stroke="#173020" stroke-width="1"/><path d="M${X} ${(y-13*s).toFixed(1)} L${(x-7*s).toFixed(1)} ${(y+4*s).toFixed(1)} L${(x-1*s).toFixed(1)} ${(y+4*s).toFixed(1)} Z" fill="#4A7E4A"/>`;
    const c=t.k==="dark"?["#2E5E26","#244A1E","#4A8A3A"]:["#3E7E2E","#2A5A22","#7AB84A"];
    return`<ellipse cx="${X}" cy="${(y+6*s).toFixed(1)}" rx="${(8*s).toFixed(1)}" ry="${(2.6*s).toFixed(1)}" fill="#1E3A14" opacity=".45"/><circle cx="${X}" cy="${Y}" r="${(8.2*s).toFixed(1)}" fill="${c[0]}" stroke="${c[1]}" stroke-width="1.2"/><circle cx="${(x-2.6*s).toFixed(1)}" cy="${(y-2.8*s).toFixed(1)}" r="${(3.6*s).toFixed(1)}" fill="${c[2]}" opacity=".85"/>`}).join("");
  s+=`<g filter="url(#paint)">${g}</g>`;

  /* ---------- the ferry line across the bay ---------- */
  s+=`<path d="${wmCurve(WM_FERRY,false)}" stroke="#FFFFFF" stroke-width="3" fill="none" stroke-dasharray="7 9" stroke-linecap="round" opacity=".85"/>
   <g transform="translate(744 670)"><path d="M-12 0 L12 0 L8 6 L-8 6 Z" fill="#8A4A2A" stroke="#3A1E10" stroke-width="1.4"/><path d="M0 0 V-14 L9 -3 Z" fill="#F4ECD8" stroke="#3A1E10" stroke-width="1"/></g>`;

  /* the causeway out to the Cove's hall */
  s+=`<path d="M690 722 L732 734" stroke="#6A5A44" stroke-width="9" stroke-linecap="round"/><path d="M690 722 L732 734" stroke="#C8B48A" stroke-width="6" stroke-linecap="round"/>${[0,1,2,3,4].map(i=>`<path d="M${694+i*8} ${719+i*2.4} l-1.4 6" stroke="#6A5A44" stroke-width="1"/>`).join("")}`;
  /* ---------- the places ---------- */
  s+=`<g filter="url(#brush)">`;
  const hall=(z,x,y)=>{const roof={"z-mine":"#8A5A3A","z-glacier":"#5A7AA0","z-vault":"#8A6A2A","z-reactor":"#4A6A5A","z-scrap":"#6A5A4A","z-wreck":"#3A5A7A","z-volcano":"#7A3A2A","z-crater":"#5A4A7A"}[z],sealed=st.seals.includes(z);
    return`<g transform="translate(${x} ${y})"><ellipse cx="0" cy="12" rx="30" ry="7" fill="#1E2A14" opacity=".35"/>
     <rect x="-24" y="-6" width="48" height="18" fill="#E4DCC8" stroke="#3A3226" stroke-width="1.6"/>
     ${[-18,-10,10,18].map(o=>`<rect x="${o-2}" y="-4" width="4" height="16" fill="#F6F0E2" stroke="#8A8270" stroke-width=".8"/>`).join("")}
     <path d="M-28 -6 L0 -22 L28 -6 Z" fill="${roof}" stroke="#2A2218" stroke-width="1.6" stroke-linejoin="round"/>
     <circle cx="0" cy="-11" r="4.4" fill="${sealed?"#F2C94C":"#D8D0BC"}" stroke="#2A2218" stroke-width="1.2"/>${sealed?`<path d="M-2 -11 L-.4 -9.4 L2.4 -12.6" stroke="#5A3A10" stroke-width="1.2" fill="none"/>`:""}
     <rect x="-5" y="1" width="10" height="11" rx="4" fill="#4A3020" stroke="#2A1A10" stroke-width="1"/><rect x="-26" y="10" width="52" height="3" fill="#B8B0A0" stroke="#3A3226" stroke-width="1"/></g>`};
  const P={};
  P["z-quill"]=(x,y)=>`<ellipse cx="${x}" cy="${y+8}" rx="66" ry="32" fill="#D8C898" stroke="#8A7A52" stroke-width="2"/><ellipse cx="${x}" cy="${y+8}" rx="54" ry="24" fill="#E4D6A8"/>
    <g transform="translate(${x} ${y-6})"><ellipse cx="0" cy="22" rx="58" ry="9" fill="#2A2A14" opacity=".3"/>
     <rect x="-56" y="-2" width="26" height="24" fill="#CFC4AE" stroke="#3A3226" stroke-width="1.8"/><rect x="30" y="-2" width="26" height="24" fill="#CFC4AE" stroke="#3A3226" stroke-width="1.8"/>
     <path d="M-59 -2 L-43 -14 L-27 -2 Z M27 -2 L43 -14 L59 -2 Z" fill="#5A4A6A" stroke="#2A2218" stroke-width="1.6" stroke-linejoin="round"/>
     <rect x="-32" y="-10" width="64" height="32" fill="#E2D8C2" stroke="#3A3226" stroke-width="1.8"/><path d="M-36 -10 L0 -30 L36 -10 Z" fill="#6A5A7A" stroke="#2A2218" stroke-width="1.8" stroke-linejoin="round"/>
     <rect x="-9" y="-50" width="18" height="30" fill="#E8DEC8" stroke="#3A3226" stroke-width="1.6"/><path d="M-12 -50 L0 -64 L12 -50 Z" fill="#6A5A7A" stroke="#2A2218" stroke-width="1.6"/><circle cx="0" cy="-40" r="5.4" fill="#FFF8E4" stroke="#2A2218" stroke-width="1.2"/><path d="M0 -40 V-43.6 M0 -40 H2.6" stroke="#2A2218" stroke-width="1"/>
     ${[-52,-44,-38,34,40,48].map(o=>`<rect x="${o}" y="4" width="5" height="7" fill="#8AB4D8" stroke="#3A3226" stroke-width=".8"/>`).join("")}${[-24,-14,10,20].map(o=>`<rect x="${o}" y="-4" width="5" height="9" fill="#8AB4D8" stroke="#3A3226" stroke-width=".8"/>`).join("")}
     <path d="M-7 22 V10 Q0 3 7 10 V22 Z" fill="#5A3A24" stroke="#2A1A10" stroke-width="1.2"/><rect x="-14" y="22" width="28" height="3" fill="#B8B0A0"/></g>
     ${st.hollow?"":""}`;
  P["z-mine"]=(x,y)=>`<g transform="translate(${x} ${y})"><path d="M-40 18 Q-20 -30 6 -34 Q30 -26 42 18 Z" fill="#7A6A52" stroke="#3A2E22" stroke-width="2"/><path d="M-20 18 Q-14 -18 6 -22 Q-4 -2 -2 18 Z" fill="#9A8A6E" opacity=".7"/>
    <path d="M-12 18 V-2 Q0 -12 12 -2 V18 Z" fill="#1A120C"/><path d="M-14 18 V-4 H14 V18 M-16 -4 H16" stroke="#8A5A2A" stroke-width="4" fill="none"/>
    <path d="M-6 18 L-14 40 M6 18 L14 40" stroke="#5A4A3A" stroke-width="2"/>${[22,28,34].map(o=>`<path d="M${-6-o*.36} ${o} H${6+o*.36}" stroke="#7A5A3A" stroke-width="2"/>`).join("")}
    <path d="M24 26 Q34 14 46 26 Z" fill="#6A5A4A" stroke="#3A2E22" stroke-width="1.4"/><rect x="18" y="26" width="16" height="9" fill="#8A6A3A" stroke="#3A2410" stroke-width="1.2"/><circle cx="21" cy="36" r="2.2" fill="#2A2018"/><circle cx="31" cy="36" r="2.2" fill="#2A2018"/></g>`;
  P["z-glacier"]=(x,y)=>`<g transform="translate(${x} ${y})"><path d="M-42 20 Q-34 -26 0 -32 Q36 -26 44 20 Z" fill="#DCEAF6" stroke="#5A7090" stroke-width="2"/><path d="M-30 20 Q-24 -14 0 -20 Q-18 0 -16 20 Z" fill="#FFFFFF" opacity=".8"/>
    <path d="M-14 20 Q-14 -4 0 -8 Q14 -4 14 20 Z" fill="#2A4A6E"/><path d="M-14 20 Q-14 -4 0 -8 Q14 -4 14 20" fill="none" stroke="#A8D0F0" stroke-width="2.4"/>
    ${[-10,-5,0,5,10].map((o,i)=>`<path d="M${o-2} ${-6+Math.abs(o)*.3} L${o} ${2+(i%2)*4} L${o+2} ${-6+Math.abs(o)*.3} Z" fill="#E8F6FF"/>`).join("")}<path d="M-30 6 L-24 -4 M28 4 L22 -6" stroke="#FFFFFF" stroke-width="2"/></g>`;
  P["z-vault"]=(x,y)=>`<g transform="translate(${x} ${y})"><path d="${wmBlob(0,6,62,38,mulberry(77),12)}" fill="none" stroke="#8A7A5E" stroke-width="7"/><path d="${wmBlob(0,6,62,38,mulberry(77),12)}" fill="none" stroke="#C8B894" stroke-width="3.4" stroke-dasharray="6 3"/>
    ${[[-44,-10],[44,-6],[-30,34],[36,32]].map(([a,b])=>`<rect x="${a-5}" y="${b-8}" width="10" height="12" fill="#B8A882" stroke="#3A3226" stroke-width="1.2"/><path d="M${a-6} ${b-8} L${a} ${b-14} L${a+6} ${b-8} Z" fill="#6A5A3A" stroke="#2A2218" stroke-width="1"/>`).join("")}
    <rect x="-26" y="14" width="52" height="5" fill="#C8BEA4" stroke="#3A3226" stroke-width="1"/><rect x="-22" y="10" width="44" height="5" fill="#D8CEB4" stroke="#3A3226" stroke-width="1"/>
    <rect x="-20" y="-10" width="40" height="20" fill="#EDE4CC" stroke="#3A3226" stroke-width="1.6"/>${[-15,-7,7,15].map(o=>`<rect x="${o-2}" y="-8" width="4" height="18" fill="#FFFAEC" stroke="#9A9078" stroke-width=".8"/>`).join("")}
    <path d="M-24 -10 L0 -26 L24 -10 Z" fill="#E2D6B8" stroke="#3A3226" stroke-width="1.6"/><path d="M-10 -14 Q0 -30 10 -14" fill="#C8A848" stroke="#5A4418" stroke-width="1.4"/><rect x="-4" y="0" width="8" height="10" fill="#5A4426" stroke="#2A1A10" stroke-width="1"/></g>`;
  P["z-reactor"]=(x,y)=>`<g transform="translate(${x} ${y})"><rect x="-46" y="-30" width="92" height="64" rx="6" fill="none" stroke="#6A7A6A" stroke-width="2" stroke-dasharray="3 3"/>
    ${[[-24,-2,15,26],[26,-6,13,24]].map(([a,b,w,h])=>`<path d="M${a-w} ${b+h} Q${a-w*.55} ${b} ${a-w*.75} ${b-h*.4} H${a+w*.75} Q${a+w*.55} ${b} ${a+w} ${b+h} Z" fill="#C8CCC4" stroke="#3A403A" stroke-width="1.6"/><ellipse cx="${a}" cy="${b-h*.4}" rx="${w*.75}" ry="3" fill="#8A908A" stroke="#3A403A" stroke-width="1"/><path d="M${a-4} ${b-h*.5} q-6 -10 2 -16 q8 -6 0 -14" stroke="#F4F6F8" stroke-width="6" fill="none" stroke-linecap="round" opacity=".85"/>`).join("")}
    <path d="M-10 26 V8 Q2 -10 14 8 V26 Z" fill="#B8C4B0" stroke="#3A403A" stroke-width="1.6"/><rect x="-14" y="18" width="34" height="10" fill="#9AA894" stroke="#3A403A" stroke-width="1.4"/><rect x="0" y="20" width="6" height="8" fill="#3A403A"/><circle cx="2" cy="6" r="2.4" fill="#B8F07A"/></g>`;
  P["z-scrap"]=(x,y)=>{const r=mulberry(55);let h=`<path d="${wmBlob(0,6,58,34,mulberry(9),12)}" fill="#A88E66" stroke="#6A5A40" stroke-width="2"/>`;
    [[-30,4,26,20],[8,-8,32,26],[34,14,22,16],[-8,22,26,14]].forEach(([a,b,w,hh])=>{h+=`<path d="M${a-w} ${b+hh*.5} L${a-w*.55} ${b-hh*.55} L${a-w*.1} ${b-hh} L${a+w*.45} ${b-hh*.5} L${a+w} ${b+hh*.5} Z" fill="#8A7A6A" stroke="#3A3026" stroke-width="1.6"/><path d="M${a-w*.55} ${b-hh*.55} L${a-w*.1} ${b-hh} L${a+w*.1} ${b-hh*.2} Z" fill="#A89A88" opacity=".8"/>`;
      for(let i=0;i<9;i++){const px=a+(r()-.5)*w*1.3,py=b+(r()-.55)*hh*.9,ww=3+r()*7,hh2=2+r()*5,c=["#B8B0A0","#6A7A8A","#C8783A","#5A6A4A","#D8C890","#8A4A3A"][i%6];
        h+=i%3===0?`<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="${(ww*.45).toFixed(1)}" fill="none" stroke="${c}" stroke-width="1.6"/>`:`<rect x="${px.toFixed(1)}" y="${py.toFixed(1)}" width="${ww.toFixed(1)}" height="${hh2.toFixed(1)}" transform="rotate(${(r()*70-35).toFixed(0)} ${px.toFixed(1)} ${py.toFixed(1)})" fill="${c}" stroke="#2A2218" stroke-width=".7"/>`}});
    return`<g transform="translate(${x} ${y})">${h}<rect x="-58" y="-24" width="12" height="8" fill="#B84A2A" stroke="#2A1A10" stroke-width="1.2" transform="rotate(-8 -52 -20)"/><circle cx="-55" cy="-14" r="2.4" fill="#2A2018"/><circle cx="-48" cy="-15" r="2.4" fill="#2A2018"/>
     <path d="M44 -40 V22 M38 22 H50 M44 -40 L10 -32 M44 -30 L54 -40 M44 -40 L52 -32" stroke="#C8A040" stroke-width="3" fill="none" stroke-linejoin="round"/><path d="M44 -40 V22" stroke="#3A2A10" stroke-width="1" stroke-dasharray="3 3"/><path d="M10 -32 V-16" stroke="#2A2218" stroke-width="1.2"/><path d="M5 -16 H15 L12 -10 H8 Z" fill="#6A6A6A" stroke="#2A2218" stroke-width="1"/>
     <path d="M-60 36 H60" stroke="#5A4A3A" stroke-width="2.4" stroke-dasharray="1 4"/>${[-56,-36,-16,4,24,44].map(o=>`<path d="M${o} 30 V40" stroke="#5A4A3A" stroke-width="2"/>`).join("")}</g>`};
  P["z-slag"]=(x,y)=>`<g transform="translate(${x} ${y})">${[[56,34,"#9A948C"],[44,26,"#86807A"],[32,18,"#726C66"],[20,11,"#5E5852"]].map(([a,b,c])=>`<ellipse cx="0" cy="4" rx="${a}" ry="${b}" fill="${c}" stroke="#3A3632" stroke-width="1.4"/>`).join("")}
    <path d="M-10 10 Q-10 -6 0 -8 Q10 -6 10 10 Z" fill="#A8826A" stroke="#3A2A20" stroke-width="1.4"/><path d="M-3 10 V4 Q0 1 3 4 V10 Z" fill="#FFB43A"/><circle cx="0" cy="6" r="14" fill="url(#glow)" opacity=".7"/>
    <path d="M0 -8 q-6 -10 2 -16 q8 -8 -2 -18" stroke="#B8B4AE" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>
    <g transform="translate(-6 -48)"><rect x="-10" y="-2" width="20" height="10" fill="none" stroke="#3A3226" stroke-width="2"/>${[-6,-2,2,6].map(o=>`<path d="M${o} -2 V8" stroke="#3A3226" stroke-width="1.4"/>`).join("")}</g></g>`;
  P["z-wreck"]=(x,y)=>`<g transform="translate(${x} ${y})"><path d="${wmBlob(-4,6,30,15,mulberry(12),9)}" fill="#3A86C8" stroke="#E8D8A0" stroke-width="3"/><path d="${wmBlob(-4,6,20,9,mulberry(13),8)}" fill="#5AA8E0" opacity=".8"/>
    <g transform="translate(-2 6) rotate(-14)"><path d="M-22 0 Q-19 9 0 9 Q18 9 24 -2 Z" fill="#6A4426" stroke="#2A180C" stroke-width="1.6"/><path d="M-4 0 V-26 M8 -2 V-18" stroke="#3A2414" stroke-width="2.2"/><path d="M-4 -23 L7 -18 L-4 -13 Z" fill="#E8DCC0" opacity=".85"/></g>
    <g transform="translate(-34 -16)"><path d="M0 0 L4 -6 L8 0 Z" fill="#6A4A2A"/><circle cx="14" cy="2" r="2" fill="#F2C94C"/><circle cx="18" cy="4" r="1.6" fill="#F2C94C"/></g>
    ${[[-40,10],[30,-10],[34,18]].map(([a,b])=>`<path d="M${a} ${b} q2 -12 0 -18" stroke="#7A5A34" stroke-width="2" fill="none"/><path d="M${a} ${b-18} q-9 -2 -12 4 M${a} ${b-18} q9 -2 12 4 M${a} ${b-18} q-4 -8 -10 -8 M${a} ${b-18} q4 -8 10 -8" stroke="#3E8A2E" stroke-width="2.4" fill="none" stroke-linecap="round"/>`).join("")}</g>`;
  P["z-volcano"]=(x,y)=>`<g transform="translate(${x} ${y})"><ellipse cx="0" cy="10" rx="58" ry="30" fill="#3A2C28" stroke="#1E1612" stroke-width="2"/><ellipse cx="0" cy="10" rx="46" ry="22" fill="none" stroke="url(#lava)" stroke-width="7"/><ellipse cx="0" cy="10" rx="46" ry="22" fill="none" stroke="#FFD27A" stroke-width="1.4" stroke-dasharray="4 7" opacity=".8"/>
    <ellipse cx="0" cy="10" rx="36" ry="15" fill="#5A4A42"/>${[[-46,10],[46,10]].map(([a,b])=>`<rect x="${a-7}" y="${b-3}" width="14" height="6" fill="#8A6A4A" stroke="#2A1A10" stroke-width="1"/>`).join("")}
    <path d="M-22 14 Q-14 -18 0 -22 Q14 -18 22 14 Z" fill="#4A3A34" stroke="#1E1612" stroke-width="1.8"/><ellipse cx="0" cy="-20" rx="9" ry="3.6" fill="url(#lava)" stroke="#1E1612" stroke-width="1.2"/><path d="M-2 -17 Q-6 -4 -2 6" stroke="#FF8A2A" stroke-width="2.6" fill="none" stroke-linecap="round"/>
    <circle cx="0" cy="-20" r="20" fill="url(#glow)" opacity=".6"/><path d="M-4 -26 q-8 -10 2 -16 q10 -6 0 -18" stroke="#8A8480" stroke-width="6" fill="none" stroke-linecap="round" opacity=".7"/></g>`;
  P["z-crater"]=(x,y)=>`<g transform="translate(${x} ${y})"><ellipse cx="0" cy="0" rx="50" ry="26" fill="#A89A62" stroke="#6A5A34" stroke-width="2"/><ellipse cx="2" cy="3" rx="38" ry="18" fill="#7A6E4A"/><ellipse cx="-4" cy="-3" rx="34" ry="14" fill="#5E5438"/>
    <path d="M-48 -4 Q-30 -26 0 -26 Q30 -26 48 -4" stroke="#D8CC98" stroke-width="3" fill="none"/><path d="M-4 -3 l2 -7 l2 7 l7 2 l-7 2 l-2 7 l-2 -7 l-7 -2 Z" fill="#E8F0FF"/><circle cx="-2" cy="-1" r="9" fill="url(#glow)" opacity=".6"/>
    ${[[-60,10],[58,8],[-40,24],[44,22]].map(([a,b])=>`<ellipse cx="${a}" cy="${b}" rx="6" ry="3" fill="#8A7E52"/>`).join("")}</g>`;
  P["z-hollow"]=(x,y)=>`<g transform="translate(${x} ${y})"><ellipse cx="0" cy="6" rx="56" ry="30" fill="#2A3428" opacity=".9"/>
    ${[[-44,-8],[-34,-22],[-14,-28],[10,-28],[32,-22],[46,-6],[44,14],[-46,14]].map(([a,b])=>`<path d="M${a} ${b-12} L${a+7} ${b+4} L${a-7} ${b+4} Z" fill="#1E2A1E" stroke="#0E160E" stroke-width="1"/>`).join("")}
    <circle cx="4" cy="8" r="26" fill="url(#glow)"/><path d="M-4 16 L4 -4 L12 16 Z" fill="#FF8A2A" stroke="#7A2A10" stroke-width="1"/><path d="M0 16 L4 4 L8 16 Z" fill="#FFE7A0"/><path d="M-6 17 L14 13 M-6 13 L14 17" stroke="#4A2A14" stroke-width="2.4"/>
    ${[[-28,-4],[24,-10],[-18,20],[32,16],[-34,10],[12,24]].map(([a,b])=>`<circle cx="${a}" cy="${b}" r="9" fill="url(#glow)" opacity=".8"/><circle cx="${a}" cy="${b}" r="3" fill="#FF9A2E" stroke="#5A2A10" stroke-width=".8"/><path d="M${a-1.2} ${b-.6} h.9 M${a+.4} ${b-.6} h.9 M${a-1.4} ${b+1} q1.4 1 2.8 0" stroke="#5A2A10" stroke-width=".6" fill="none"/>`).join("")}
    ${[[-20,-14,60],[16,4,70]].map(([a,b,w])=>`<path d="M${a-w/2} ${b} q${w/4} -6 ${w/2} 0 t${w/2} 0" stroke="#D8D4E8" stroke-width="5" fill="none" opacity=".35" stroke-linecap="round"/>`).join("")}</g>`;
  sites.forEach(k=>{const p=WM_P[k];s+=P[k](p.x,p.y);if(WM_HALL[k])s+=hall(k,...WM_HALL[k])});
  s+=`</g>`;

  /* ---------- clouds round the edges, a little paper grain over everything ---------- */
  let cl="";const cloud=(x,y,w)=>{for(let i=0;i<7;i++){const cx=x+(R()-.5)*w,cy=y+(R()-.5)*w*.45,r=w*(.22+R()*.22);cl+=`<circle cx="${cx.toFixed(0)}" cy="${cy.toFixed(0)}" r="${r.toFixed(0)}" fill="url(#cloud)"/>`}};
  [[40,40,170],[1160,40,180],[30,800,160],[1170,810,170],[600,-10,150],[-10,420,120],[1210,450,120],[300,850,120],[880,850,120]].forEach(c=>cloud(...c));
  s+=`<g opacity=".92">${cl}</g><rect width="${W}" height="${H}" filter="url(#grain)" opacity=".45"/>
   <rect width="${W}" height="${H}" fill="none" stroke="#0E2250" stroke-width="22" opacity=".25" filter="url(#soft)"/></svg>`;
  return s}

/* ================= THE MAP WINDOW ================= */
function wmPlaces(st){const nm=z=>(typeof GYMS!=="undefined"&&GYMS[z])?GYMS[z].hall:null,zs=c=>(ZONES.find(z=>z.cls===c)||{}).sub||"";
  const t=s=>s.toLowerCase().replace(/(^|[\s'-])([a-z])/g,(m,a,b)=>a+b.toUpperCase()).replace(/'S\b/g,"'s");
  const L={
   "z-quill":{sub:zs("z-quill"),in:["The Institute and its specimen hall"].concat(st.base?["The Founder's Basement, under the Institute"]:[],st.study?["The hidden study, behind the portrait"]:[])},
   "z-mine":{sub:zs("z-mine"),in:["The mine tunnels"]},"z-glacier":{sub:zs("z-glacier"),in:["The ice cave"]},
   "z-vault":{sub:zs("z-vault"),in:["The Gilded Vault"]},"z-reactor":{sub:zs("z-reactor"),in:["The old reactor hall"]},
   "z-scrap":{sub:zs("z-scrap"),in:[]},"z-wreck":{sub:zs("z-wreck")+" An island out in the bay; the ferry crosses from the pier on the Starfall shore.",in:[]},"z-volcano":{sub:zs("z-volcano"),in:[]},"z-crater":{sub:zs("z-crater"),in:[]},
   "z-slag":{sub:"A worked-out quarry behind the Scrapyard, with a kiln at the bottom that nobody lets go out. The only way in is through the Scrapyard's gate.",in:["The quarry and its kiln"]},
   "z-hollow":{sub:"A village in a hollow, lit for Lantern Night. No road leads there.",in:[]}};
  Object.keys(L).forEach(z=>{const h=nm(z);if(h)L[z].in.push(t(h)+(st.seals.includes(z)?" (seal earned)":""))});return L}
function openWorldMap(){const m=modal("wmap","MAP OF DROSSMARCH"),list=m.querySelector(".bag-list"),st=wmState(),key=JSON.stringify(st);
  if(!list.querySelector(".wm-frame")){list.innerHTML=`<div class="wm-frame"><img class="wm-img" alt="A painted map of Drossmarch" decoding="async"><div class="wm-wait">Unrolling the map…</div><div class="wm-pins"></div></div><div class="wm-card" aria-live="polite"></div>`}
  const img=list.querySelector(".wm-img"),wait=list.querySelector(".wm-wait");
  if(WM.key!==key){WM.key=key;img.style.visibility="hidden";wait.hidden=false;
    setTimeout(()=>{const svg=wmPaint(st);img.onload=()=>{img.style.visibility="";wait.hidden=true};img.src="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg)},30)}
  const here=wmHere(),PL=wmPlaces(st),pins=list.querySelector(".wm-pins");
  const show=Object.keys(WM_P).filter(k=>(k!=="z-slag"||st.slag)&&(k!=="z-hollow"||st.hollow));
  pins.innerHTML=show.map(k=>{const p=WM_P[k],LO={"z-wreck":[628,664],"z-quill":[380,278],"z-volcano":[716,356],"z-reactor":[1044,320],"z-scrap":[190,452],"z-glacier":[630,118]}[k]||[p.x,p.y-p.r*.95],lx=(LO[0]/WM.W*100).toFixed(2),ly=(LO[1]/WM.H*100).toFixed(2);
    return`<button class="wm-pin${k===here?" here":""}" data-z="${k}" style="left:${(p.x/WM.W*100).toFixed(2)}%;top:${(p.y/WM.H*100).toFixed(2)}%;width:${(p.r*2/WM.W*100).toFixed(2)}%;height:${(p.r*2/WM.H*100).toFixed(2)}%" aria-label="${p.nm}"></button><span class="wm-lab${k===here?" here":""}" data-z="${k}" style="left:${lx}%;top:${ly}%">${p.nm}</span>`}).join("")
    +(here&&WM_P[here]?`<i class="wm-you" style="left:${(WM_P[here].x/WM.W*100).toFixed(2)}%;top:${(WM_P[here].y/WM.H*100).toFixed(2)}%"></i>`:"");
  const card=list.querySelector(".wm-card");
  const pick=k=>{WM.sel=k;pins.querySelectorAll(".wm-pin,.wm-lab").forEach(b=>b.classList.toggle("on",b.dataset.z===k));const p=WM_P[k],d=PL[k];
    card.innerHTML=`<b>${p.nm}${k===here?' <em>You are here</em>':""}</b><span>${d.sub}</span>${d.in.length?`<span class="wm-in"><u>You can go inside:</u> ${d.in.join(" · ")}</span>`:""}`;sfx("sel")};
  pins.querySelectorAll(".wm-pin").forEach(b=>b.onclick=()=>pick(b.dataset.z));
  const first=WM.sel&&show.includes(WM.sel)?WM.sel:here&&show.includes(here)?here:"z-quill";WM.sel=first;
  {const p=WM_P[first],d=PL[first];pins.querySelectorAll(".wm-pin,.wm-lab").forEach(b=>b.classList.toggle("on",b.dataset.z===first));
   card.innerHTML=`<b>${p.nm}${first===here?' <em>You are here</em>':""}</b><span>${d.sub}</span>${d.in.length?`<span class="wm-in"><u>You can go inside:</u> ${d.in.join(" · ")}</span>`:""}`}}
/* a MAP button beside the Journal */
(function(){const a=$(".audio");if(!a||$("#wmbtn"))return;const b=document.createElement("button");b.className="aubtn";b.id="wmbtn";b.textContent="MAP";b.onclick=openWorldMap;const j=$("#jbtn");if(j)j.after(b);else a.prepend(b)})();
