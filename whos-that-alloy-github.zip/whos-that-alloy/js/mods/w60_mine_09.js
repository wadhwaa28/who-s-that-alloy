/* ---- Rustvein Mine, 9 ---- */
/* Murmuration Metal: starlings murmured over the roof for an hour. A great bird-shape made entirely of starlings flying together. */
addForm("Murmuration Metal",{n:"#2A2A3A",a:"#B8A8E8",rn:"#E8D8C8",rb:"#3A6A5A",ra:"#F2C94C"},"hover",(P,g)=>{const R=fgRng(fgHash("murm")),dots=(cx,cy,rx,ry,n,cl)=>Array.from({length:n},()=>{const a=R()*6.283,r=Math.sqrt(R());const x=cx+Math.cos(a)*rx*r,y=cy+Math.sin(a)*ry*r;return`<path d="M${x-3} ${y} Q${x} ${y-2.4} ${x+3} ${y} Q${x} ${y-1} ${x-3} ${y} Z" fill="${cl}" stroke="${FI}" stroke-width=".7"/>`}).join("");
 return `<ellipse class="shd" cx="104" cy="148" rx="40" ry="3" fill="#000" opacity=".08"/>`+
 pt("wingB",112,76,dots(140,52,30,18,34,P.nd),.3)+pt("tail",150,90,dots(162,94,16,10,16,P.nd))+
 pt("sway",104,84,dots(104,86,34,18,60,P.n))+pt("wingF",96,78,dots(66,50,30,18,38,P.n))+
 pt("head",62,92,dots(58,94,12,10,18,P.n)+`<circle cx="56" cy="90" r="4.4" fill="${P.ac}" ${SW2}/><circle cx="55" cy="89" r="2" fill="${FI}"/>`+pt("beak",46,96,`<path d="M48 94 L36 96 L48 99 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M20 140 h40 v-12 h-40 Z" fill="#8A6A4A" ${SW2}/><path d="M20 128 l20 -10 l20 10" fill="#6A4A3A" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="86" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(170,24,6))});
FORM_TITLE["Murmuration Metal"]="Murmuration";SM("Murmuration Metal","Flock Turn","STR","a",20,100,"multi:3-5","Thousands of birds, all changing direction at once.");

/* Nine-Minute Metal: a quartet's nine-minute joke with no punchline. A mantis holding its bow-arm across a violin, mid-performance. */
addForm("Nine-Minute Metal",{n:"#7AA85A",a:"#C8803A",rn:"#3A3A4A",rb:"#E8C8A0",ra:"#E8412C"},"stand",(P,g)=>fShadow(60)+
 pt("wingB",120,90,`<path d="M118 90 Q150 84 178 108 Q150 108 120 100 Z" fill="${P.nl}" opacity=".7" ${SW2}/>`,.3)+
 `<path d="M108 98 Q140 96 172 116 Q166 124 140 118 Q114 112 106 104 Z" fill="${P.n}" ${SW}/>${[124,136,148,160].map(x=>`<path d="M${x} ${100+(x-120)*.36} q-2 6 0 10" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`).join("")}`+
 [[150,"legB",.5],[128,"legB",1],[120,"legF",0],[140,"legF",.7]].map(([x,c,d])=>pt(c,x,112,`<path d="M${x} 112 L${x+8} 126 L${x+4} 144" stroke="${FI}" stroke-width="3.4" fill="none" stroke-linejoin="round"/><path d="M${x} 112 L${x+8} 126 L${x+4} 144" stroke="${P.nd}" stroke-width="1.8" fill="none" stroke-linejoin="round"/>`,d)).join("")+
 `<path d="M100 104 Q96 80 92 66 L100 64 Q108 84 110 100 Z" fill="${P.n}" ${SW}/>`+
 `<g transform="rotate(30 74 92)"><path d="M62 72 Q56 80 62 88 Q56 98 64 108 Q74 112 84 108 Q92 98 86 88 Q92 80 86 72 Q74 66 62 72 Z" fill="${P.ac}" ${SW}/><path d="M74 66 V40" stroke="${FI}" stroke-width="5"/><path d="M70 40 Q74 32 78 40" fill="${FI}"/><path d="M72 76 V106 M76 76 V106" stroke="#E8E0C0" stroke-width="1"/><path d="M68 94 q2 -4 4 0 M80 94 q2 -4 4 0" stroke="${FI}" stroke-width="1.6" fill="none"/></g>`+
 pt("armF",96,74,`<path d="M96 74 L80 62 L70 76" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M96 74 L80 62 L70 76" stroke="${P.n}" stroke-width="3" fill="none" stroke-linejoin="round"/>`)+
 pt("armB",100,72,`<path d="M100 72 L114 56 L104 50" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M100 72 L114 56 L104 50" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linejoin="round"/><path d="M104 50 L40 108" stroke="#8A5A2A" stroke-width="2.4"/><path d="M104 50 L40 108" stroke="#E8E0C0" stroke-width=".8"/>`,.4)+
 pt("head",94,62,`<path d="M80 54 Q94 40 108 54 L96 74 Z" fill="${P.n}" ${SW}/>${E2(84,54,4.6,"#3A6A2A")}${E2(104,54,4.6,"#3A6A2A")}`+HMOUTH(92,64,98,P,2.4)+pt("ant",90,44,`<path d="M88 46 Q80 22 66 18 M100 46 Q104 22 118 14" stroke="${FI}" stroke-width="1.4" fill="none"/>`))+
 fG(g,1,`<text x="150" y="50" font-family="monospace" font-size="12" font-weight="bold" fill="${P.ac}">9:00</text>`)+fG(g,2,`<circle cx="140" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Nine-Minute Metal"]="Violinist Mantis";SM("Nine-Minute Metal","Long Joke","RES","s",0,100,"tspd-1,tacc-1","It goes on, and on, and it's nearly there, and...");

/* No-Haggle Blend: haggle and the seller simply walks away. A llama turning its back, nose in the air, saddlebags of spice. */
addForm("No-Haggle Blend",{n:"#E8DCC8",a:"#B8402A",rn:"#4A3A30",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",150,84,`<path d="M148 82 Q160 80 158 92 Q152 94 148 90 Z" fill="${P.n}" ${SW2}/>`)+
 fLeg("legB",140,104,38,8,P.nd,P.ndd,.5)+fLeg("legB",108,106,36,8,P.nd,P.ndd,1.3)+
 `<path d="M88 96 Q88 74 120 72 Q150 74 154 94 Q150 112 122 112 Q92 112 88 96 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${96+i*9} ${78+i%2*3} q3 6 -1 12" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 `<path d="M100 74 L140 74 L142 98 L98 98 Z" fill="${P.ac}" ${SW}/>${[106,116,126,136].map(x=>`<path d="M${x} 76 l4 20" stroke="#F2C94C" stroke-width="2"/>`).join("")}<rect x="92" y="94" width="18" height="16" rx="4" fill="#8A5A2A" ${SW2}/><rect x="128" y="94" width="18" height="16" rx="4" fill="#8A5A2A" ${SW2}/><path d="M96 96 q5 -6 10 0" fill="#E8A040"/>`+
 fLeg("legF",132,106,36,8,P.n,P.ndd,0)+fLeg("legF",98,106,36,8,P.n,P.ndd,.8)+
 pt("head",96,84,`<path d="M96 90 Q88 60 90 36" stroke="${FI}" stroke-width="18" fill="none" stroke-linecap="round"/><path d="M96 90 Q88 60 90 36" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/>`+
  `<path d="M74 34 Q72 18 90 16 Q104 18 102 32 Q100 42 88 42 Q76 42 74 34 Z" fill="${P.n}" ${SW}/><path d="M74 26 Q66 22 64 28 Q68 34 76 34 Z" fill="${P.n}" ${SW2}/>${E2(88,26,3.6,"#3A2410",[.6,-.4])}<path d="M82 22 l10 0" stroke="${FI}" stroke-width="2"/>`+
  `<path d="M66 30 L74 30 L72 34 Z" fill="${FMOUTH}"/>`+pt("jaw",70,34,`<path d="M66 32 Q70 38 76 34 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ear",96,18,`<path d="M94 20 L96 4 L102 18 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",88,18,`<path d="M86 20 L84 6 L92 16 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M24 136 h22 v-14 h-22 Z" fill="#E8A040" ${SW2}/><path d="M24 122 q11 -10 22 0" fill="#C8401A" ${SW2}/>`)+fG(g,2,`<circle cx="120" cy="86" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["No-Haggle Blend"]="Walk-Away Llama";SM("No-Haggle Blend","Final Offer","STR","a",80,100,"tdef-1@30","That's the price. Take it or leave it.");

/* Oakesite: on your tenth birthday you pick one mystery box from the shed. A jack-in-the-box imp springing out of its box. */
addForm("Oakesite",{n:"#E8604A",a:"#F2C94C",rn:"#3A4A8A",rb:"#5AB04A",ra:"#5FE0F0"},"hop",(P,g)=>fShadow(50,110)+
 `<rect x="74" y="104" width="56" height="40" fill="#4A6AC8" ${SW}/><path d="M74 104 L62 86 L118 86 L130 104" fill="#5A7AD8" ${SW}/>${[[88,118,"★"],[110,132,"?"]].map(([x,y,t])=>`<text x="${x}" y="${y}" font-size="14" font-weight="bold" fill="#F2C94C">${t}</text>`).join("")}<rect x="130" y="116" width="10" height="4" fill="${P.b}" ${SW2}/>`+pt("spin",144,118,`<path d="M140 118 h10 v-10" stroke="${FI}" stroke-width="3" fill="none"/>`)+
 pt("sway",102,96,`${[0,1,2,3].map(i=>`<ellipse cx="102" cy="${100-i*8}" rx="10" ry="3.4" fill="none" stroke="${FI}" stroke-width="4.6"/><ellipse cx="102" cy="${100-i*8}" rx="10" ry="3.4" fill="none" stroke="${P.ll}" stroke-width="2.4"/>`).join("")}`)+
 pt("armF",86,58,`<path d="M90 60 Q72 56 66 44" stroke="${FI}" stroke-width="8" stroke-linecap="round" fill="none"/><path d="M90 60 Q72 56 66 44" stroke="${P.ac}" stroke-width="5" stroke-linecap="round" fill="none"/><circle cx="64" cy="40" r="5" fill="#fff" ${SW2}/>`)+
 pt("armB",116,58,`<path d="M114 60 Q132 56 138 44" stroke="${FI}" stroke-width="8" stroke-linecap="round" fill="none"/><path d="M114 60 Q132 56 138 44" stroke="${P.ac}" stroke-width="5" stroke-linecap="round" fill="none"/><circle cx="140" cy="40" r="5" fill="#fff" ${SW2}/>`,.4)+
 `<path d="M88 72 L92 56 L112 56 L116 72 Z" fill="${P.ac}" ${SW}/><path d="M88 72 L102 66 L116 72" stroke="${P.n}" stroke-width="3" fill="none"/>`+
 pt("head",102,42,`<circle cx="102" cy="40" r="15" fill="#F4E0D0" ${SW}/><circle cx="102" cy="44" r="4" fill="${P.n}" ${SW2}/>${E2(95,36,3.6)}${E2(109,36,3.6)}`+HMOUTH(96,48,108,P,3)+
  `<path d="M88 30 L74 14 L94 26 L100 6 L106 26 L128 12 L116 30 Z" fill="${P.n}" ${SW}/>${[[74,14],[100,6],[128,12]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.ac}" ${SW2}/>`).join("")}`)+
 fG(g,1,`<text x="20" y="60" font-size="18" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">10</text>`)+fG(g,2,`<circle cx="102" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Oakesite"]="Jack-in-the-Box Imp";SM("Oakesite","Pop Goes","STR","a",65,100,"prio,tacc-1@30","Turn the handle long enough and something always jumps out.");

/* Open Door No. 3: locksmiths found the vault door open with a note: 'it didn't want to stay'. A raccoon with a set of lockpicks, door swinging behind. */
addForm("Open Door No. 3",{n:"#8A8A92",a:"#2A2A30",rn:"#E8D8C8",rb:"#5A3A2A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M150 20 L188 28 L188 146 L150 140 Z" fill="${P.b}" ${SW}/><circle cx="174" cy="80" r="12" fill="${P.d}" ${SW2}/>${[0,1,2,3,4,5].map(i=>`<path d="M174 80 L${174+Math.cos(i)*10} ${80+Math.sin(i)*10}" stroke="${P.ll}" stroke-width="2"/>`).join("")}<rect x="140" y="16" width="10" height="130" fill="#3A3A44" ${SW2}/>`+fShadow(64)+
 pt("tail",144,100,`<path d="M140 100 Q164 100 166 120" stroke="${FI}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M140 100 Q164 100 166 120" stroke="${P.n}" stroke-width="10.6" fill="none" stroke-linecap="round"/>${[[148,101],[156,104],[162,112]].map(([x,y])=>`<path d="M${x} ${y-5} v10" stroke="${P.ac}" stroke-width="4"/>`).join("")}`)+
 fLeg("legB",132,116,24,9,P.nd,P.ac,.5)+
 `<path d="M84 110 Q82 86 112 84 Q142 86 146 108 Q142 126 114 126 Q88 126 84 110 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",122,118,22,9,P.n,P.ac,0)+
 pt("armF",96,108,fOL("M98 108 Q82 104 74 92",P.n,8)+`<ellipse cx="72" cy="90" rx="5" ry="4" fill="${P.ac}" ${SW2}/><path d="M72 88 L58 70 M74 88 L66 66 L62 62" stroke="${P.ll}" stroke-width="2.4" stroke-linecap="round" fill="none"/>`)+
 pt("head",90,92,`<path d="M56 98 Q56 76 78 74 Q100 76 100 96 Q96 110 78 110 Q60 110 56 98 Z" fill="${P.n}" ${SW}/><path d="M60 90 Q72 84 84 90 Q90 92 96 88 L98 94 Q88 98 80 96 Q70 96 62 98 Z" fill="${P.ac}"/><path d="M56 100 L44 102 Q44 96 52 94 Z" fill="${P.nl}" ${SW2}/><circle cx="45" cy="100" r="2.6" fill="${FI}"/>${E2(70,90,3.8,"#C8A020")}${E2(86,90,3.8,"#C8A020")}`+HMOUTH(50,104,58,P,2.4)+
  pt("ear",72,76,`<path d="M68 78 L70 64 L80 76 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",90,78,`<path d="M86 76 L96 64 L98 80 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<g transform="rotate(-8 30 128)"><rect x="20" y="120" width="22" height="16" fill="#F4F0E4" ${SW2}/><path d="M24 126 h14 M24 130 h10" stroke="${FI}" stroke-width="1"/></g>`)+fG(g,2,`<circle cx="114" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,46,6)));
FORM_TITLE["Open Door No. 3"]="Lockpick Raccoon";SM("Open Door No. 3","Let Itself Out","RES","s",0,100,"spd+1,cure","Three locks, no problem. It didn't want to stay.");

/* Ottersby Helmetite: pencilled on a caver's helmet. A pale cave olm, a stub of pencil tucked behind its gills. */
addForm("Ottersby Helmetite",{n:"#F0D8D0",a:"#E87A8A",rn:"#3A3A4A",rb:"#7AB8C8",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 40 Q60 20 104 34 Q150 18 194 40 V14 H14 Z" fill="#5A5A64"/>${[40,90,140,170].map(x=>`<path d="M${x} ${30+(x%3)*4} l4 14 l4 -14" fill="#6A6A74" ${SW2}/>`).join("")}`+fShadow(80)+
 pt("tail",160,124,`<path d="M150 120 Q176 116 192 128 Q176 134 150 132 Z" fill="${P.n}" ${SW}/>`)+
 [[142,"legB",.5],[96,"legB",1.3]].map(([x,c,d])=>pt(c,x,128,fOL(`M${x} 128 L${x+4} 140 l4 2 M${x+4} 140 l-2 4`,P.nd,3),d)).join("")+
 `<path d="M64 124 Q66 110 104 108 Q148 110 156 124 Q150 136 104 136 Q68 136 64 124 Z" fill="${P.n}" ${SW}/><path d="M76 128 Q110 136 148 128" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".7"/>`+
 [[132,"legF",0],[84,"legF",.8]].map(([x,c,d])=>pt(c,x,130,fOL(`M${x} 130 L${x-4} 142 l-4 2 M${x-4} 142 l2 3`,P.n,3),d)).join("")+
 pt("head",68,120,`<path d="M30 120 Q32 108 52 108 Q70 110 72 120 Q68 132 50 132 Q34 132 30 120 Z" fill="${P.n}" ${SW}/><circle cx="48" cy="116" r="1.6" fill="${FI}" opacity=".5"/>`+HMOUTH(32,124,42,P,2.4)+
  pt("ear",64,112,`${[0,1,2].map(i=>`<path d="M62 ${112+i*5} Q${72+i*2} ${100+i*8} ${80} ${106+i*8}" stroke="${P.ac}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`).join("")}<g transform="rotate(-24 70 104)"><rect x="60" y="100" width="22" height="5" fill="#F2C94C" ${SW2}/><path d="M82 100 L88 102.5 L82 105 Z" fill="#E8C8A0" ${SW2}/><rect x="56" y="100" width="4" height="5" fill="#E8A0B0" ${SW2}/></g>`))+
 fG(g,1,`<path d="M20 144 Q40 136 60 144" stroke="#7AB8E8" stroke-width="3" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,60,6)));
FORM_TITLE["Ottersby Helmetite"]="Pencil-Gilled Olm";SM("Ottersby Helmetite","Survey Notes","RES","s",0,100,"acc+1,def+1","Write it down before you forget where you are.");

/* Overdue Metal: left in a returns bin to see if anyone will ever borrow it. An armadillo whose bands are library date cards, all stamped overdue. */
addForm("Overdue Metal",{n:"#B8A890",a:"#8A2A3A",rn:"#3A3A4A",rb:"#E8C060",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",156,122,`<path d="M152 120 Q176 124 186 136" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M152 120 Q176 124 186 136" stroke="${P.nd}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 [[142,.5],[96,1.3]].map(([x,d])=>pt("legB",x,128,`<rect x="${x-5}" y="126" width="10" height="16" rx="3" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M72 128 Q72 82 114 80 Q156 82 158 128 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4].map(i=>{const x=84+i*14;return`<path d="M${x} 128 Q${x-2} ${92-Math.sin((i+.5)/5*3.14)*8} ${x+12} ${86-Math.sin((i+.5)/5*3.14)*6} L${x+14} 128 Z" fill="#F4F0E4" ${SW2}/>${[0,1,2].map(k=>`<path d="M${x+3} ${100+k*8} h8" stroke="#8A8A9A" stroke-width=".8"/>`).join("")}<rect x="${x+2}" y="${110}" width="10" height="5" fill="${P.ac}" opacity=".85" transform="rotate(-12 ${x+7} 112)"/>`}).join("")}<path d="M72 128 Q72 82 114 80 Q156 82 158 128" fill="none" ${SW}/>`+
 [[132,0],[84,.8]].map(([x,d])=>pt("legF",x,128,`<rect x="${x-5}" y="126" width="10" height="17" rx="3" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",74,116,`<path d="M36 120 Q40 104 60 102 Q76 104 78 118 Q72 130 56 130 Z" fill="${P.n}" ${SW}/><path d="M36 120 L28 122 L36 126 Z" fill="${P.n}" ${SW2}/>${E2(56,112,3.6)}`+HMOUTH(34,124,44,P,2.4)+pt("ear",66,104,`<path d="M62 104 L66 90 L72 104 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<rect x="160" y="30" width="28" height="16" rx="2" fill="${P.ac}" ${SW2}/><text x="163" y="42" font-size="7" font-weight="bold" fill="#fff">LATE</text>`)+fG(g,2,`<circle cx="114" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(114,50,6)));
FORM_TITLE["Overdue Metal"]="Date-Stamp Armadillo";SM("Overdue Metal","Late Fee","RES","a",60,100,"tdef-1@30","It adds up a penny a day, until suddenly it doesn't feel like pennies.");

/* Page Nine Metal: ran on page nine under a runaway goose story. A pelican with a rolled newspaper stuffed in its pouch. */
addForm("Page Nine Metal",{n:"#F4F0E8",a:"#E8A040",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#E8412C"},"stand",(P,g)=>fShadow(60)+
 pt("tail",144,104,`<path d="M140 100 L162 108 L140 114 Z" fill="${P.nd}" ${SW}/>`)+
 [[118,"legB",.5],[104,"legF",0]].map(([x,c,d])=>pt(c,x,114,`<path d="M${x} 112 V138" stroke="${FI}" stroke-width="5"/><path d="M${x} 112 V138" stroke="${P.ac}" stroke-width="3"/><path d="M${x-8} 142 L${x} 138 L${x+8} 142 Z" fill="${P.ac}" ${SW2}/>`,d)).join("")+
 `<path d="M88 100 Q88 74 114 72 Q140 76 144 100 Q138 118 114 118 Q92 118 88 100 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,90,`<path d="M100 86 Q130 80 146 100 Q128 110 104 104 Z" fill="${P.nl}" ${SW}/><path d="M126 96 L146 100" stroke="${FI}" stroke-width="3"/>`)+
 pt("head",96,72,`<path d="M100 80 Q92 60 96 46" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M100 80 Q92 60 96 46" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><circle cx="94" cy="40" r="12" fill="${P.n}" ${SW}/>${E2(94,36,3.6,"#3A6AA8")}`+
  `<path d="M84 36 L34 40 L84 44 Z" fill="${P.ac}" ${SW2}/>`+pt("beak",84,46,`<path d="M84 44 L34 42 Q42 66 64 66 Q80 64 86 50 Z" fill="${P.ac}" opacity=".9" ${SW2}/><g transform="rotate(-20 58 52)"><rect x="44" y="44" width="30" height="14" rx="3" fill="#E8E4DA" ${SW2}/><path d="M48 48 h22 M48 52 h18" stroke="#6A6A7A" stroke-width="1"/><text x="48" y="57" font-size="4.6" font-weight="bold" fill="${FI}">p.9</text></g>`))+
 fG(g,1,`<g transform="rotate(10 30 130)"><rect x="18" y="120" width="30" height="20" fill="#E8E4DA" ${SW2}/><text x="20" y="128" font-size="5" font-weight="bold" fill="${FI}">GOOSE!</text><path d="M20 132 h26 M20 136 h20" stroke="#8A8A9A" stroke-width="1"/></g>`)+fG(g,2,`<circle cx="114" cy="106" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(150,40,6)));
FORM_TITLE["Page Nine Metal"]="Newspaper Pelican";SM("Page Nine Metal","Buried Lead","RES","a",70,100,"dodge","The real story is always on page nine.");

/* Parcelon: posted in 1932, delivered in 1987. A wombat with a postbag and a very old stamp stuck to its rump. */
addForm("Parcelon",{n:"#9A7A5A",a:"#C8302A",rn:"#3A3A4A",rb:"#E8D8C0",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(66)+
 fLeg("legB",144,120,20,12,P.nd,P.ndd,.5)+fLeg("legB",110,122,18,12,P.nd,P.ndd,1.3)+
 `<path d="M80 114 Q78 82 118 80 Q158 82 162 112 Q158 132 120 132 Q84 132 80 114 Z" fill="${P.n}" ${SW}/>`+
 `<g transform="rotate(8 150 102)"><rect x="140" y="92" width="18" height="20" fill="#E8D8C0" stroke="${FI}" stroke-width="1.6" stroke-dasharray="2 1.4"/><rect x="143" y="95" width="12" height="11" fill="${P.ac}" opacity=".7"/><text x="142" y="111" font-size="4.4" font-weight="bold" fill="${FI}">1932</text></g>`+
 `<path d="M104 80 L92 120" stroke="#6A4A2A" stroke-width="4"/><path d="M84 106 Q82 128 100 132 Q118 132 118 112 Z" fill="#8A6A3A" ${SW}/><path d="M86 110 Q100 116 116 110" stroke="${FI}" stroke-width="2" fill="none"/><path d="M98 120 h8" stroke="#F2C94C" stroke-width="3"/>`+
 fLeg("legF",136,124,18,12,P.n,P.ndd,0)+fLeg("legF",92,124,16,12,P.n,P.ndd,.8)+
 pt("head",84,100,`<path d="M48 104 Q48 82 70 80 Q92 82 94 102 Q90 118 70 118 Q52 118 48 104 Z" fill="${P.n}" ${SW}/><path d="M48 102 Q44 98 46 92 Q54 90 56 98 Z" fill="${P.nd}" ${SW2}/><ellipse cx="48" cy="96" rx="4" ry="3.4" fill="${FI}"/>${E2(66,94,3.6)}`+HMOUTH(50,108,58,P,2.4)+
  pt("ear",80,84,`<path d="M76 86 L80 72 L88 84 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",70,84,`<path d="M66 86 L66 74 L74 84 Z" fill="${P.nd}" ${SW2}/>`,.3)+
  `<path d="M58 80 Q70 70 90 80 L90 84 Q72 76 58 84 Z" fill="#3A3A5A" ${SW2}/><path d="M58 82 L48 84" stroke="#3A3A5A" stroke-width="4" stroke-linecap="round"/>`)+
 fG(g,1,`<rect x="20" y="124" width="24" height="16" fill="#C89A5A" ${SW2}/><path d="M20 124 l12 8 l12 -8" stroke="${FI}" stroke-width="1.4" fill="none"/>`)+fG(g,2,`<circle cx="124" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Parcelon"]="Postbag Wombat";SM("Parcelon","Signed For","RES","s",0,100,"def+1,heal:25","Fifty-five years late, but delivered all the same.");

/* Paw Print Special: approved with one signature and one paw print. A red panda with inky paws, leaving prints on the approval form. */
addForm("Paw Print Special",{n:"#C8603A",a:"#2A2A30",rn:"#E8E0D0",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>`<g transform="rotate(-4 60 136)"><rect x="24" y="126" width="64" height="18" fill="#F4F0E4" ${SW2}/><path d="M30 132 h20 M30 137 q8 -4 16 0" stroke="#3A5AA8" stroke-width="1.4" fill="none"/></g>`+fShadow(70)+
 pt("tail",156,100,`<path d="M152 100 Q182 96 184 72" stroke="${FI}" stroke-width="18" fill="none" stroke-linecap="round"/><path d="M152 100 Q182 96 184 72" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/>${[[166,98],[178,88],[183,76]].map(([x,y])=>`<path d="M${x-6} ${y-4} l12 6" stroke="#E8D0B0" stroke-width="4"/>`).join("")}`)+
 fLeg("legB",142,112,26,9,P.ac,P.ac,.5)+fLeg("legB",112,114,24,9,P.ac,P.ac,1.3)+
 `<path d="M88 104 Q88 82 120 80 Q152 82 156 102 Q152 120 122 120 Q92 120 88 104 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",134,116,24,9,P.ac,P.ac,0)+pt("legF",100,114,fOL("M100 114 L84 124 L76 130",P.ac,9)+`<ellipse cx="74" cy="132" rx="6" ry="3.6" fill="${P.ac}" ${SW2}/>`,.8)+
 pt("head",92,90,`<path d="M58 92 Q58 70 82 68 Q104 70 106 90 Q102 106 82 106 Q62 106 58 92 Z" fill="${P.n}" ${SW}/><path d="M60 96 Q66 90 74 94 Q80 102 70 104 Q62 104 60 96 Z" fill="#F4F0E4"/><path d="M76 78 q4 -6 8 0 M90 78 q4 -6 8 0" fill="#F4F0E4" ${SW2}/><path d="M76 84 Q78 94 74 100 M96 84 Q98 94 94 100" stroke="#6A2A1A" stroke-width="3" fill="none"/><ellipse cx="60" cy="94" rx="3" ry="2.4" fill="${FI}"/>${E2(80,84,3.8,"#1A1A1A")}${E2(94,84,3.8,"#1A1A1A")}`+HMOUTH(62,100,70,P,2.4)+
  pt("ear",72,70,`<path d="M66 74 L68 58 L80 70 Z" fill="${P.n}" ${SW2}/><path d="M69 70 L70 62 L76 70 Z" fill="#F4F0E4"/>`)+pt("ear",96,70,`<path d="M92 70 L102 58 L104 74 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`${[[40,136],[56,132]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="3" ry="2.4" fill="${FI}"/>${[-3,0,3].map(d=>`<circle cx="${x+d}" cy="${y-4}" r="1.2" fill="${FI}"/>`).join("")}`).join("")}`)+fG(g,2,`<circle cx="122" cy="102" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,46,6)));
FORM_TITLE["Paw Print Special"]="Inky-Paw Red Panda";SM("Paw Print Special","Rubber Stamp","RES","a",65,100,"tacc-1@40","Approved. Paw print and all.");
