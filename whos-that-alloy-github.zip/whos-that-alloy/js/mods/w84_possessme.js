/* =============== WHEN A SHADOW GETS HOLD OF YOU, IT GETS IN ===============
   A shadow that catches you doesn't just hold on and let go any more: when it lets go of your arms, it goes down into your shadow.
   While it's in you, you are dark, your eyes shine, and your feet don't always go where you send them. It gets out three ways:
   stand in good light long enough and it can't bear it; identify the next sample you meet (it will have got into that one too, and
   when the sample lets go, so does it); or wait it out, which takes a long and unpleasant while. */
const PME={on:false,t:0,lit:0,iv:null,lurch:0};
const PME_MAX=45,PME_LIGHT=3;
function pmeEyes(){const pl=$("#player");if(!pl)return;pl.classList.toggle("possessed",PME.on);let e=pl.querySelector(".pos-eyes");
  if(PME.on&&!e)pl.insertAdjacentHTML("beforeend",`<i class="pos-eyes pme-eyes"><b></b><b></b></i>`);if(!PME.on&&e)e.remove()}
function pmeStart(){if(PME.on)return;PME.on=true;PME.t=0;PME.lit=0;PME.lurch=4+Math.random()*4;store.set("wta_pme",1);pmeEyes();hmShake();
  if(gate("pme",1500))sfx("alert");
  say0(!lntF("pmeTold")?"It lets go of your arms, and goes down into your shadow instead. Your shadow isn't doing what you're doing. Get into good light, or get rid of it some other way.":"It's in your shadow again. Find some light.");
  lntSet("pmeTold",1);clearInterval(PME.iv);PME.iv=setInterval(pmeTick,400)}
function pmeEnd(how){if(!PME.on)return;PME.on=false;clearInterval(PME.iv);PME.iv=null;store.set("wta_pme",0);pmeEyes();
  const L={light:"The light's too much for it. It comes up out of your shadow like steam off a kettle and slinks away into the dark.",
   sample:"",time:"It gets bored of you, finally, and slides off into the nearest shadow. Your feet are your own again.",leave:""}[how];if(L)say0(L)}
function pmeTick(){if(!PME.on)return;const paused=S.phase!=="explore"||DLG.open||document.hidden||$("#lnt-mg")||document.querySelector(".modal:not([hidden])");if(paused)return;
  PME.t+=.4;
  const lit=typeof inHollow==="function"&&inHollow()?hmLightAt(EXP.x,EXP.y):(EXP.zone&&!EXP.zone.dark?1:0);
  if(lit){PME.lit+=.4;if(PME.lit>=PME_LIGHT){pmeEnd("light");return}}else PME.lit=Math.max(0,PME.lit-.2);
  if(PME.t>=PME_MAX){pmeEnd("time");return}
  /* now and then it takes a step of its own, towards the dark */
  PME.lurch-=.4;if(PME.lurch<=0&&!EXP.busy){PME.lurch=5+Math.random()*5;const D=[[1,0],[-1,0],[0,1],[0,-1]].filter(([dx,dy])=>canWalk(tileAt(EXP.x+dx,EXP.y+dy))&&!thingsAt(EXP.x+dx,EXP.y+dy).length);
    if(D.length){const dark=D.filter(([dx,dy])=>typeof hmLightAt!=="function"||!inHollow()||!hmLightAt(EXP.x+dx,EXP.y+dy)),[dx,dy]=(dark.length?dark:D)[Math.random()*(dark.length?dark:D).length|0];
      PME.wild=1;step(dx,dy);PME.wild=0;if(gate("pmelurch",4000))say0(["Your feet take a step on their own.","You didn't mean to go that way.","Your shadow pulls, and you follow it."][Math.random()*3|0])}}}
/* your feet don't always go where you send them */
{const _st=step;step=function(dx,dy){if(PME.on&&!PME.wild&&!EXP.busy&&S.phase==="explore"&&Math.random()<.22){
    const D=[[1,0],[-1,0],[0,1],[0,-1]].filter(([a,b])=>!(a===dx&&b===dy)&&canWalk(tileAt(EXP.x+a,EXP.y+b)));if(D.length){const[a,b]=D[Math.random()*D.length|0];EXP.path=null;return _st(a,b)}}
  return _st(dx,dy)}}
/* the shadow that catches you goes into you instead of off into the dark (unless it has handed you the Gutterwick's vial) */
{const _tick=shdTick;shdTick=function(){const before=STK.held;_tick();if(!before&&STK.held&&!PME.grabWatch){PME.grabWatch=1;
    setTimeout(()=>{PME.grabWatch=0;if(S.phase==="explore"&&!EXP.storyAlloy&&inHollow()&&!(typeof TUT!=="undefined"&&TUT.on))pmeStart()},2300)}}}
/* the next sample you meet has it in it too; when that one lets go, so does yours */
{const _en=encounter;encounter=function(){if(PME.on&&lntOn()&&!EXP.storyAlloy&&!EXP.duel&&!EXP.trial&&!EXP.questAlloy)window.__pmeForce=1;
  const f=window.__posForce;if(window.__pmeForce)window.__posForce=1;try{_en()}finally{window.__posForce=f;window.__pmeForce=0}}}
{const _w=win;win=function(){const pos=S.r&&S.r.possessed;_w();if(pos&&PME.on){pmeEnd("sample");setTimeout(()=>say("And the one in your shadow goes with it. Your feet are your own again."),2600)}}}
/* people can tell */
{const _tt=talkTo;talkTo=function(p){if(PME.on&&p&&!p.possessed&&Math.random()<.5){talk(p.n,[["(They look at your eyes and take a step back.) You've got one in you. Get yourself into the light, and then we'll talk.","Your shadow just waved at me. You didn't.","(They won't look at you.) Go and stand by a lamp a while, pet."][Math.random()*3|0]]);return}_tt(p)}}
/* keep the eyes on through costume changes and redraws, and don't carry it out of the game */
{const _cr=coatRefresh;coatRefresh=function(){_cr();pmeEyes()}}
{const _pp=placePlayer;placePlayer=function(i){_pp(i);if(PME.on&&!$("#player .pme-eyes"))pmeEyes()}}
if(store.get("wta_pme",0))store.set("wta_pme",0);
