/* ---- fish and other swimmers ---- */
FGP.fish={hab:{"z-wreck":5,"z-glacier":2.5,"z-reactor":1,"z-volcano":.5,"z-vault":.8,"z-scrap":.5,"z-mine":.6,"z-crater":.7},loco:"swim",
 kinds:{fish:["Bream","Perch","Pike","Carp","Tench","Wrasse","Grouper","Snapper","Cod","Haddock","Mackerel","Tuna","Bass","Char","Trout","Goby","Blenny","Tetra","Cichlid","Gourami","Zander","Ide","Rudd","Mullet","Dory","Bonito"],
  flat:["Flounder","Plaice","Sole","Halibut","Skate","Brill","Turbot"],long:["Eel","Lamprey","Needlefish","Garfish","Oarfish","Pipefish","Ribbonfish"],odd:["Sculpin","Toadfish","Batfish","Frogfish","Stargazer","Hatchetfish","Boxfish","Cowfish","Lumpsucker","Wolffish","Coelacanth"],
  myth:["Leviathan Fry","Kraken Spawn","Aspidochelone","Makara","Bakunawa","Lusca","Ningyo"]},
 gen(r,tr,a){const kind=fgW(r,{fish:5,flat:1.2,long:1.3,odd:2,myth:a.rar==="legendary"?5:a.rar==="rare"?1.2:.3});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.L=R1(kind==="long"?110:kind==="flat"?70:62+r()*30);o.H=R1(kind==="long"?16:kind==="flat"?44:kind==="odd"?34+r()*14:22+r()*18);o.mouth=fgPick(r,["small","wide","under","up","teeth","tube"]);
  o.dorsal=fgPick(r,["sail","spiny","low","split","none","tall"]);o.tail=fgPick(r,["fork","round","lunate","square","point","fan"]);o.pat=fgPick(r,["bars","spots","stripe","none","scales","patch"]);
  o.barbel=r()<.25;o.lure=kind==="odd"&&r()<.4||kind==="myth"&&r()<.4;o.horn=kind==="myth"?fgPick(r,["crystal","spiral","blade"]):"none";return o},
 draw(P,g,o){const cx=104,cy=92,L=o.L,H=o.H,x0=cx-L/2,x1=cx+L/2;let s=`<ellipse class="shd" cx="104" cy="150" rx="${R1(L*.5)}" ry="4" fill="#000" opacity=".14"/>`;
  const tail={fork:`M${x1-4} ${cy} L${x1+20} ${cy-H*.75} L${x1+12} ${cy} L${x1+20} ${cy+H*.75} Z`,round:`M${x1-4} ${cy} Q${x1+26} ${cy-H*.8} ${x1+24} ${cy} Q${x1+26} ${cy+H*.8} ${x1-4} ${cy} Z`,
   lunate:`M${x1-4} ${cy} Q${x1+14} ${cy-H*.3} ${x1+22} ${cy-H*.95} Q${x1+12} ${cy} ${x1+22} ${cy+H*.95} Q${x1+14} ${cy+H*.3} ${x1-4} ${cy} Z`,square:`M${x1-4} ${cy-4} L${x1+18} ${cy-H*.6} L${x1+18} ${cy+H*.6} L${x1-4} ${cy+4} Z`,
   point:`M${x1-4} ${cy-H*.3} L${x1+24} ${cy} L${x1-4} ${cy+H*.3} Z`,fan:`M${x1-4} ${cy} L${x1+16} ${cy-H*.8} Q${x1+28} ${cy} ${x1+16} ${cy+H*.8} Z`}[o.tail];
  s+=pt("tail",R1(x1),cy,`<path d="${tail}" fill="${P.nd}" ${SW}/>`);
  if(o.dorsal!=="none"){const d={sail:`M${cx-L*.25} ${cy-H*.8} Q${cx} ${cy-H*2.1} ${cx+L*.3} ${cy-H*.8} Z`,spiny:`M${cx-L*.28} ${cy-H*.85} ${Array.from({length:6},(_,i)=>`L${R1(cx-L*.22+i*L*.09)} ${R1(cy-H*1.6)} L${R1(cx-L*.18+i*L*.09)} ${R1(cy-H*.95)}`).join(" ")} Z`,
    low:`M${cx-L*.3} ${cy-H*.85} Q${cx} ${cy-H*1.3} ${cx+L*.35} ${cy-H*.75} Z`,split:`M${cx-L*.3} ${cy-H*.85} L${cx-L*.15} ${cy-H*1.5} L${cx} ${cy-H*.9} Z M${cx+L*.05} ${cy-H*.9} L${cx+L*.2} ${cy-H*1.4} L${cx+L*.35} ${cy-H*.75} Z`,tall:`M${cx-L*.1} ${cy-H*.9} L${cx+L*.02} ${cy-H*2} L${cx+L*.2} ${cy-H*.85} Z`}[o.dorsal];
   s+=pt("fin",R1(cx),R1(cy-H*.85),`<path d="${d}" fill="${P.nd}" ${SW2}/>`)}
  s+=pt("fin",R1(cx+L*.05),R1(cy+H*.85),`<path d="M${R1(cx-L*.05)} ${R1(cy+H*.8)} L${R1(cx+L*.1)} ${R1(cy+H*1.5)} L${R1(cx+L*.22)} ${R1(cy+H*.75)} Z" fill="${P.nd}" ${SW2}/>`,.5);
  if(o.kind==="long")s+=`<path d="M${x0} ${cy} Q${cx-L*.2} ${cy-H*1.6} ${cx} ${cy} Q${cx+L*.2} ${cy+H*1.6} ${x1} ${cy} Q${cx+L*.2} ${cy+H*2.6} ${cx} ${cy+H} Q${cx-L*.2} ${cy-H*.6} ${x0} ${cy+H*.9} Z" fill="${P.n}" ${SW}/>`;
  else s+=`<path d="M${x0} ${cy} Q${x0+L*.08} ${cy-H} ${cx-L*.1} ${cy-H} Q${x1-L*.15} ${cy-H*.95} ${x1} ${cy} Q${x1-L*.15} ${cy+H*.95} ${cx-L*.1} ${cy+H} Q${x0+L*.08} ${cy+H} ${x0} ${cy} Z" fill="${P.n}" ${SW}/>`;
  s+=`<path d="M${R1(x0+L*.1)} ${R1(cy+H*.45)} Q${cx} ${R1(cy+H*.98)} ${R1(x1-L*.12)} ${R1(cy+H*.4)}" stroke="${P.nll}" stroke-width="${R1(H*.28)}" fill="none" opacity=".55"/>`;
  if(o.pat==="bars")for(let i=0;i<4;i++)s+=`<path d="M${R1(cx-L*.2+i*L*.14)} ${R1(cy-H*.85)} Q${R1(cx-L*.17+i*L*.14)} ${cy} ${R1(cx-L*.2+i*L*.14)} ${R1(cy+H*.85)}" stroke="${P.ndd}" stroke-width="${R1(L*.04)}" fill="none" opacity=".75"/>`;
  else if(o.pat==="stripe")s+=`<path d="M${R1(x0+L*.15)} ${cy} L${R1(x1-L*.08)} ${cy}" stroke="${P.ac}" stroke-width="${R1(H*.2)}" stroke-linecap="round" opacity=".85"/>`;
  else s+=fgPattern(o.pat,cx,cy,L*.45,H*.85,P,fgRng(o.seed||11));
  s+=`<path d="M${R1(x0+L*.22)} ${R1(cy-H*.55)} Q${R1(x0+L*.28)} ${cy} ${R1(x0+L*.22)} ${R1(cy+H*.55)}" stroke="${P.nd}" stroke-width="2" fill="none"/>`;
  s+=pt("fin",R1(x0+L*.3),R1(cy+H*.2),`<path d="M${R1(x0+L*.3)} ${R1(cy+H*.15)} Q${R1(x0+L*.42)} ${R1(cy+H*.7)} ${R1(x0+L*.48)} ${R1(cy+H*.3)} Z" fill="${P.nd}" ${SW2}/>`,.3);
  let h="";const mx=x0+2,my=cy+({under:H*.45,up:-H*.25}[o.mouth]||H*.12),mw={small:L*.06,wide:L*.16,under:L*.08,up:L*.08,teeth:L*.14,tube:L*.05}[o.mouth];
  if(o.mouth==="tube")h+=`<path d="M${mx+4} ${my-3} L${mx-10} ${my-2} L${mx-10} ${my+3} L${mx+4} ${my+3} Z" fill="${P.n}" ${SW2}/><circle cx="${mx-10}" cy="${my+.5}" r="2" fill="${FMOUTH}"/>`;
  h+=`<path d="M${R1(mx)} ${R1(my)} L${R1(mx+mw)} ${R1(my+1)} L${R1(mx+mw*.8)} ${R1(my+4)} L${R1(mx+1)} ${R1(my+3)} Z" fill="${FMOUTH}"/>`;
  if(o.mouth==="teeth")h+=Array.from({length:4},(_,i)=>`<path d="M${R1(mx+2+i*mw*.22)} ${R1(my+.5)} l1.4 3 l1.4 -3" fill="#FFFFFF"/>`).join("");
  h+=pt("jaw",R1(mx+mw),R1(my+3),`<path d="M${R1(mx+mw)} ${R1(my+3)} Q${R1(mx+mw*.4)} ${R1(my+8)} ${R1(mx-1)} ${R1(my+3)} Q${R1(mx+mw*.4)} ${R1(my+5)} ${R1(mx+mw)} ${R1(my+5)} Z" fill="${P.nl}" ${SW2}/>`);
  if(o.barbel)h+=pt("ant",R1(mx+4),R1(my+4),`<path d="M${R1(mx+4)} ${R1(my+4)} Q${R1(mx-6)} ${R1(my+12)} ${R1(mx-14)} ${R1(my+10)} M${R1(mx+6)} ${R1(my+5)} Q${R1(mx)} ${R1(my+16)} ${R1(mx-8)} ${R1(my+18)}" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`);
  if(o.lure)h+=pt("ant",R1(mx+L*.12),R1(cy-H*.85),`<path d="M${R1(mx+L*.12)} ${R1(cy-H*.85)} Q${R1(mx)} ${R1(cy-H*2.2)} ${R1(mx-14)} ${R1(cy-H*1.6)}" stroke="${P.n}" stroke-width="2.4" fill="none"/><circle class="p-glow" cx="${R1(mx-14)}" cy="${R1(cy-H*1.5)}" r="4" fill="${P.ac}" ${SW2}/>`);
  if(o.horn!=="none")h+=fgHorn(o.horn,R1(x0+L*.14),R1(cy-H*.75),P,.9,-1);
  h+=fgEye(R1(x0+L*.13),R1(cy-H*.28),R1(Math.max(3.4,H*.2)),o.kind==="myth"?P.ac:"#C8A040");
  s+=pt("head",R1(x0+L*.2),cy,h);
  if(o.acc)s+=fgPlace(o,P,{neck:[x0+L*.25,cy+H*.6],back:[cx,cy-H*1.1-6],side:[cx+L*.1,cy],hold:[mx-8,my+4],floor:[cx,140],head:[x0+L*.15,cy-H-6]});
  s+=fG(g,1,`<circle cx="${R1(x0-10)}" cy="${R1(cy-H)}" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="${cx}" cy="${cy}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(cx,R1(Math.max(14,cy-H*2-6)),6));
  return s},
 parts:["head","jaw","tail","fin"],
 sig:o=>[o.kind,o.sp,o.mouth,o.dorsal,o.tail,o.pat,o.barbel?1:0,o.lure?1:0].join(".")};

/* ---- snakes and serpents ---- */
FGP.serpent={hab:{"z-volcano":2.5,"z-mine":1.5,"z-vault":1.5,"z-scrap":1,"z-crater":1.4,"z-reactor":1.4,"z-wreck":1,"z-glacier":.6},loco:"slink",want:tr=>tr.low||tr.liquid?2:1,
 kinds:{snake:["Adder","Viper","Mamba","Krait","Boa","Racer","Kingsnake","Sidewinder","Asp","Taipan","Whipsnake","Grass Snake","Ratsnake","Milksnake"],legless:["Slowworm","Caecilian","Glass Lizard","Amphisbaena"],
  myth:["Wyrm","Lindworm","Basilisk","Naga","Jaculus","Ouroboros","Quetzal Wyrm","Cockatrice Chick","Vritra"]},
 gen(r,tr,a){const kind=fgW(r,{snake:4,legless:.8,myth:a.rar==="legendary"?5:a.rar==="rare"?1.5:.4});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.coil=fgPick(r,["s","coil","rise","loop"]);o.th=R1(9+r()*6);o.head=fgPick(r,["arrow","round","hood","blunt"]);o.horn=kind==="myth"?fgPick(r,["curve","crystal","branch","nub"]):r()<.15?"nub":"none";
  o.tail=fgPick(r,["point","rattle","club","fin","flame"]);o.pat=fgPick(r,["diamond","bands","spots","stripe","none"]);o.wings=kind==="myth"&&r()<.4;o.frill=kind==="myth"&&!o.wings&&r()<.5;return o},
 draw(P,g,o){const th=o.th;let s=fShadow(62);const path={s:"M150 136 Q182 128 170 110 Q156 96 120 112 Q86 128 70 108 Q58 94 66 74",coil:"M156 136 Q190 130 176 116 Q160 104 112 118 Q70 132 64 116 Q60 100 92 96 Q120 92 106 82 Q90 72 72 66",
   rise:"M176 138 Q140 140 112 134 Q80 128 76 108 Q72 88 82 70",loop:"M140 138 Q186 134 168 112 Q150 94 118 104 Q90 114 94 130 Q98 144 76 140 Q56 132 62 106 Q66 86 80 72"}[o.coil];
  const end=path.match(/M(\d+) (\d+)/),tx=+end[1],ty=+end[2];
  const tl={point:"",rattle:`${[0,1,2].map(i=>`<ellipse cx="${tx+4+i*5}" cy="${ty-2-i*3}" rx="3.4" ry="2.6" fill="${P.ll}" ${SW2}/>`).join("")}`,club:`<circle cx="${tx+6}" cy="${ty-2}" r="6" fill="${P.d}" ${SW2}/>`,fin:`<path d="M${tx} ${ty-2} L${tx+16} ${ty-12} L${tx+12} ${ty+4} Z" fill="${P.nd}" ${SW2}/>`,flame:`<path class="p-glow" d="M${tx} ${ty} Q${tx+12} ${ty-12} ${tx+20} ${ty-4} Q${tx+14} ${ty+2} ${tx+18} ${ty+8} Q${tx+6} ${ty+6} ${tx} ${ty+2} Z" fill="${P.ac}" ${SW2}/>`}[o.tail];
  s+=pt("tail",tx,ty,tl);
  if(o.wings)s+=pt("wingB",120,108,`<path d="M120 108 Q140 60 178 54 Q164 80 170 92 Q150 92 132 112 Z" fill="${P.nd}" ${SW}/>`);
  s+=`<path d="${path}" stroke="${FI}" stroke-width="${th+5.4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${path}" stroke="${P.n}" stroke-width="${th}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  s+=`<path d="${path}" stroke="${P.nl}" stroke-width="${R1(th*.3)}" fill="none" stroke-linecap="round" opacity=".6" transform="translate(0 ${R1(th*.22)})"/>`;
  if(o.pat==="bands")s+=`<path d="${path}" stroke="${P.ndd}" stroke-width="${th}" fill="none" stroke-dasharray="4 10" opacity=".7"/>`;
  else if(o.pat==="diamond")s+=`<path d="${path}" stroke="${P.ac}" stroke-width="${R1(th*.45)}" fill="none" stroke-dasharray="5 7" opacity=".8"/>`;
  else if(o.pat==="spots")s+=`<path d="${path}" stroke="${P.nd}" stroke-width="${R1(th*.5)}" fill="none" stroke-dasharray="2 9" stroke-linecap="round"/>`;
  else if(o.pat==="stripe")s+=`<path d="${path}" stroke="${P.ac}" stroke-width="${R1(th*.18)}" fill="none" opacity=".85"/>`;
  if(o.wings)s+=pt("wingF",96,104,`<path d="M96 104 Q70 52 30 50 Q46 74 40 88 Q62 88 84 108 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${88-i*4} ${100-i} L${48+i*8} ${60+i*8}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`);
  const m=path.match(/(\d+) (\d+)$/),hx=+m[1],hy=+m[2],hr=th*1.3;let h="";
  if(o.frill)h+=pt("ear",hx+4,hy,`<path d="M${hx+2} ${R1(hy-hr*1.6)} Q${R1(hx+hr*2.2)} ${hy} ${hx+2} ${R1(hy+hr*1.6)} Z" fill="${P.ac}" ${SW2}/>`);
  if(o.head==="hood")h+=`<path d="M${R1(hx+hr*.4)} ${R1(hy-hr*1.5)} Q${R1(hx+hr*2.4)} ${hy} ${R1(hx+hr*.4)} ${R1(hy+hr*1.5)} Q${R1(hx-hr*.4)} ${hy} ${R1(hx+hr*.4)} ${R1(hy-hr*1.5)} Z" fill="${P.nd}" ${SW2}/>`;
  if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+hr*.2),R1(hy-hr*.75),P,.8,1);
  const L=o.head==="arrow"?hr*2.4:o.head==="blunt"?hr*1.8:hr*2;
  h+=`<path d="M${R1(hx-L+2)} ${R1(hy+hr*.1)} L${R1(hx)} ${R1(hy)} L${R1(hx)} ${R1(hy+hr*.5)} Z" fill="${FMOUTH}"/>`;
  h+=pt("tongue",R1(hx-L+2),R1(hy+hr*.15),`<path d="M${R1(hx-L+2)} ${R1(hy+hr*.15)} l-10 0 l-3 -3 M${R1(hx-L-8)} ${R1(hy+hr*.15)} l-3 3" stroke="${FTONGUE}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`);
  h+=pt("jaw",R1(hx),R1(hy+hr*.4),`<path d="M${R1(hx)} ${R1(hy+hr*.3)} Q${R1(hx-L*.5)} ${R1(hy+hr*.9)} ${R1(hx-L+2)} ${R1(hy+hr*.3)} Q${R1(hx-L*.5)} ${R1(hy+hr*.5)} ${R1(hx)} ${R1(hy+hr*.6)} Z" fill="${P.nl}" ${SW2}/>`);
  h+=o.head==="arrow"?`<path d="M${R1(hx+hr*.6)} ${R1(hy-hr*.4)} Q${R1(hx-L*.3)} ${R1(hy-hr*1.4)} ${R1(hx-L)} ${R1(hy+hr*.1)} Q${R1(hx-L*.4)} ${R1(hy+hr*.4)} ${R1(hx+hr*.6)} ${R1(hy+hr*.5)} Z" fill="${P.n}" ${SW}/>`
   :`<path d="M${R1(hx+hr*.6)} ${R1(hy-hr*.4)} Q${R1(hx-L*.2)} ${R1(hy-hr*1.2)} ${R1(hx-L)} ${R1(hy-hr*.1)} Q${R1(hx-L*1.02)} ${R1(hy+hr*.3)} ${R1(hx-L*.8)} ${R1(hy+hr*.35)} L${R1(hx+hr*.6)} ${R1(hy+hr*.5)} Z" fill="${P.n}" ${SW}/>`;
  h+=`<circle cx="${R1(hx-L+5)}" cy="${R1(hy-hr*.2)}" r="1" fill="${FI}"/>`+fgEye(R1(hx-L*.35),R1(hy-hr*.4),R1(hr*.36),o.kind==="myth"?P.ac:"#C8A040",[-.4,0],.2,P.n);
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx-L*.3,hy-hr-6,14,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,hx-L-6,hy+hr*.4,13,0);
  s+=pt("head",hx,hy+6,h);
  if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+4,hy+hr*1.3],back:[136,104],side:[124,120],floor:[110,146]});
  s+=fG(g,1,`<path d="M30 130 q4 -6 8 0 q4 -6 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="118" cy="122" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(hx+10),R1(Math.max(14,hy-28)),6));
  return s},
 parts:["head","jaw","tongue","tail"],
 sig:o=>[o.kind,o.sp,o.coil,o.head,o.horn,o.tail,o.pat,o.wings?1:0,o.frill?1:0].join(".")};
