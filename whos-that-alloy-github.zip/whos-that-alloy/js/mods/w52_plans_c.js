/* ---- small mammals: rodents, shrews, bats-on-the-ground and the like, sitting up ---- */
FGP.critter={hab:{"z-mine":3,"z-scrap":3,"z-glacier":2,"z-vault":2,"z-crater":1.2,"z-reactor":1.4,"z-volcano":1.2,"z-wreck":.8},loco:o=>o.hop?"hop":"stand",want:tr=>tr.light||tr.soft?1.5:1,
 sp:["Vole","Shrew","Mole Rat","Gerbil","Jird","Pika","Marmoset","Chinchilla","Degu","Dormouse","Lemming","Hamster","Gopher","Chipmunk","Bandicoot","Bilby","Quoll","Possum","Tenrec","Agouti","Paca","Hutia","Hyrax","Coati","Kinkajou","Numbat","Potoroo","Bushbaby","Loris","Cavy","Mara","Viscacha","Tuco-Tuco","Springhare","Hedgehog Tenrec","Desman","Solenodon","Jerboa"],
 myth:["Tanuki","Kitsune Kit","Wolpertinger Kit","Squonk","Jenny Haniver","Brownie","Moss Sprite","Hob","Bunyip Cub"],
 gen(r,tr,a){const myth=a.rar!=="uncommon"&&r()<.35;const o={sp:fgPick(r,myth?this.myth:this.sp),myth};o.br=R1(24+r()*8);o.hr=R1(o.br*(.66+r()*.2));
  o.ear=fgPick(r,["round","round","point","long","tuft","fan"]);o.tail=fgPick(r,["brush","thin","curl","stub","tuft","key"]);o.sn=R1(4+r()*10);o.pat=fgPick(r,["none","patch","bands","spots","stripes","none"]);
  o.hop=r()<.35;o.cheeks=r()<.3;o.spines=tr.tough&&r()<.4?"spikes":r()<.12?"ruff":"none";o.hold=r()<.6;o.horn=myth&&r()<.5?fgPick(r,["nub","crystal","branch"]):"none";return o},
 draw(P,g,o){const br=o.br,hr=o.hr,cx=110,cy=144-br*1.05,hx=cx-br*.25,hy=cy-br*.95-hr*.4;let s=fShadow(br*1.4,cx);
  s+=pt("tail",R1(cx+br*.7),R1(cy+br*.6),fgTail(o.tail,R1(cx+br*.7),R1(cy+br*.6),P,br/20,1));
  s+=pt("legB",R1(cx+br*.4),R1(cy+br*.6),`<path d="M${R1(cx)} ${R1(cy+br*.3)} Q${R1(cx+br*.9)} ${R1(cy+br*.2)} ${R1(cx+br*.8)} ${R1(cy+br*.9)} L${R1(cx+br*.1)} ${R1(cy+br*1.02)} Z" fill="${P.nd}" ${SW2}/><path d="M${R1(cx-br*.4)} 144 Q${R1(cx-br*.4)} 139 ${R1(cx+br*.1)} 139 L${R1(cx+br*.5)} 140 Q${R1(cx+br*.6)} 145 ${R1(cx+br*.3)} 145.6 L${R1(cx-br*.3)} 145.6 Z" fill="${P.nd}" ${SW2}/>`);
  s+=`<path d="M${R1(cx-br*.95)} ${R1(cy+br*.3)} Q${R1(cx-br*1.05)} ${R1(cy-br*.9)} ${R1(cx-br*.1)} ${R1(cy-br*1.05)} Q${R1(cx+br*.95)} ${R1(cy-br*.8)} ${R1(cx+br*.9)} ${R1(cy+br*.4)} Q${R1(cx+br*.8)} ${R1(cy+br*1.02)} ${R1(cx)} ${R1(cy+br*1.02)} Q${R1(cx-br*.85)} ${R1(cy+br*1)} ${R1(cx-br*.95)} ${R1(cy+br*.3)} Z" fill="${P.n}" ${SW}/>`;
  s+=`<path d="M${R1(cx-br*.7)} ${R1(cy+br*.6)} Q${R1(cx-br*.75)} ${R1(cy-br*.4)} ${R1(cx-br*.2)} ${R1(cy-br*.55)} Q${R1(cx+br*.1)} ${R1(cy+br*.2)} ${R1(cx-br*.1)} ${R1(cy+br*.95)} Z" fill="${P.nll}"/>`;
  s+=fgPattern(o.pat,cx+br*.2,cy,br*.7,br*.8,P,fgRng(o.seed||13));
  s+=fgSpines(o.spines,Array.from({length:6},(_,i)=>{const a=-Math.PI*.95+i*.38;return[R1(cx+Math.cos(a)*br*.95),R1(cy+Math.sin(a)*br*.95),a]}),P);
  s+=pt("legF",R1(cx-br*.3),R1(cy+br*.7),`<ellipse cx="${R1(cx-br*.4)}" cy="${R1(144.4)}" rx="${R1(br*.36)}" ry="${R1(br*.16)}" fill="${P.n}" ${SW2}/>`);
  const arms=o.hold?`M${R1(cx-br*.5)} ${R1(cy-br*.3)} Q${R1(cx-br*1.1)} ${R1(cy-br*.1)} ${R1(cx-br*1.05)} ${R1(cy+br*.2)}`:`M${R1(cx-br*.5)} ${R1(cy-br*.3)} Q${R1(cx-br*.9)} ${R1(cy+br*.2)} ${R1(cx-br*.7)} ${R1(cy+br*.5)}`;
  s+=pt("armF",R1(cx-br*.5),R1(cy-br*.3),fOL(arms,P.n,R1(br*.22))+(o.hold&&o.acc?fgAcc(o.acc,P,cx-br*1.15,cy+br*.15,14,-15):""));
  let h="";if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+hr*.2),R1(hy-hr*.8),P,hr/14,1);
  h+=fgEar(o.ear,R1(hx+hr*.6),R1(hy-hr*.55),P,hr/14);
  h+=`<path d="${fgEll(hx,hy,hr,hr*.9)}" fill="${P.n}" ${SW}/>`;
  if(o.cheeks)h+=`<ellipse cx="${R1(hx-hr*.35)}" cy="${R1(hy+hr*.4)}" rx="${R1(hr*.5)}" ry="${R1(hr*.4)}" fill="${P.n}" ${SW2}/>`;
  const sx=hx-hr*.85,sy=hy+hr*.15;
  if(o.sn>8)h+=`<path d="M${R1(sx+4)} ${R1(sy-4)} Q${R1(sx-o.sn)} ${R1(sy-2)} ${R1(sx-o.sn)} ${R1(sy+2)} Q${R1(sx-o.sn+2)} ${R1(sy+5)} ${R1(sx+4)} ${R1(sy+5)} Z" fill="${P.n}" ${SW2}/>`;
  const nx=o.sn>8?sx-o.sn:sx-2;
  h+=`<path d="M${R1(nx+3)} ${R1(sy+4)} L${R1(sx+6)} ${R1(sy+5)} L${R1(sx+5)} ${R1(sy+8)} Z" fill="${FMOUTH}"/><rect x="${R1(nx+4)}" y="${R1(sy+4)}" width="2.6" height="2.6" fill="#FFFFFF"/>`;
  h+=pt("jaw",R1(sx+5),R1(sy+6),`<path d="M${R1(sx+5)} ${R1(sy+6)} Q${R1(nx+6)} ${R1(sy+11)} ${R1(nx+3)} ${R1(sy+5)} Q${R1(nx+6)} ${R1(sy+8)} ${R1(sx+5)} ${R1(sy+8)} Z" fill="${P.nl}" ${SW2}/>`);
  h+=`<ellipse cx="${R1(nx)}" cy="${R1(sy)}" rx="2.6" ry="2.2" fill="#E89AA8" ${SW2}/><path d="M${R1(nx+5)} ${R1(sy+1)} l-12 -3 M${R1(nx+5)} ${R1(sy+2.6)} l-12 2" stroke="${FI}" stroke-width=".9"/>`;
  h+=fgEar(o.ear,R1(hx-hr*.05),R1(hy-hr*.7),P,hr/13);
  h+=fgEye(R1(hx-hr*.3),R1(hy-hr*.15),R1(hr*.36),o.myth?P.ac:"#2A1A0A");
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hr-4,13,0);
  s+=pt("head",R1(hx+hr*.3),R1(hy+hr*.8),h);
  if(o.acc&&!o.hold&&FG_SLOT[o.acc]!=="head")s+=fgPlace(o,P,{neck:[hx+hr*.2,hy+hr*1.1],back:[cx+br*.6,cy-br*.9],side:[cx+br*.3,cy+br*.2],hold:[cx-br*1.1,cy+br*.2],floor:[cx,146]});
  s+=fG(g,1,`<path d="M${R1(cx-br*2)} ${R1(cy)} q-4 -4 0 -8" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="${R1(cx+br*.3)}" cy="${R1(cy+br*.3)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+br),R1(Math.max(14,hy-hr-14)),6));
  return s},
 parts:["head","jaw","ear","tail","arm"],
 sig:o=>[o.sp,o.ear,o.tail,o.pat,o.hop?1:0,o.cheeks?1:0,o.spines,o.hold?1:0,o.horn,Math.round(o.sn/4)].join(".")};

/* ---- lizards, newts, frogs and the dragon kin ---- */
FGP.lizard={hab:{"z-volcano":4,"z-crater":1.8,"z-vault":1.4,"z-mine":1.4,"z-scrap":1,"z-reactor":1.2,"z-wreck":1,"z-glacier":.4},loco:o=>o.frog?"stand":"crawl",want:tr=>tr.ref?1.8:1,
 kinds:{lizard:["Skink","Anole","Agama","Monitor","Tegu","Gecko","Basilisk Lizard","Uromastyx","Chuckwalla","Racerunner","Whiptail","Collared Lizard","Horned Toad","Thorny Devil","Frilled Lizard","Tuatara","Gila"],
  amph:["Newt","Salamander","Mudpuppy","Hellbender","Olm","Siren"],frog:["Toad","Treefrog","Bullfrog","Tomato Frog","Horned Frog","Spadefoot","Glass Frog","Reed Frog"],
  myth:["Drake","Wyvern Hatchling","Salamander Spirit","Tarasque","Peluda","Amphiptere","Fire-Drake","Ember Drake","Coatl Hatchling"]},
 gen(r,tr,a){const kind=fgW(r,{lizard:5,amph:1.5,frog:1.5,myth:a.rar==="legendary"?6:a.rar==="rare"?2:.4});const o={kind,sp:fgPick(r,this.kinds[kind]),frog:kind==="frog"};
  o.L=R1(kind==="frog"?58+r()*10:60+r()*24);o.H=R1(kind==="frog"?28+r()*6:16+r()*8);o.crest=fgPick(r,kind==="frog"?["none"]:["none","spikes","crest","sail","none","frill"]);o.horn=kind==="myth"?fgPick(r,["curve","straight","crystal","branch"]):r()<.2?fgPick(r,["nub","straight"]):"none";
  o.tail=kind==="frog"?"none":fgPick(r,["thin","curl","spiked","flame","fork","thin"]);o.pat=fgPick(r,["spots","bands","stripes","scales","none","patch"]);o.wings=kind==="myth"&&r()<.55;o.tongue=r()<.5;o.rear=kind!=="frog"&&r()<.25;return o},
 draw(P,g,o){let s=fShadow(o.L*.6+10);const cx=112,L=o.L,H=o.H;
  if(o.frog){const cy=144-H*.9,bx=cx,hx=bx-L*.42;
   s+=pt("legB",R1(bx+L*.25),R1(cy+H*.3),`<path d="M${R1(bx+L*.1)} ${R1(cy)} Q${R1(bx+L*.6)} ${R1(cy-H*.2)} ${R1(bx+L*.55)} ${R1(cy+H*.6)} Q${R1(bx+L*.35)} ${R1(cy+H*.9)} ${R1(bx)} ${R1(cy+H*.85)} Z" fill="${P.nd}" ${SW}/><path d="M${R1(bx+L*.1)} 144 h${R1(L*.4)} l4 2" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><path d="M${R1(bx+L*.1)} 144 h${R1(L*.4)}" stroke="${P.nd}" stroke-width="3" stroke-linecap="round"/>`);
   s+=`<path d="M${R1(bx-L*.55)} ${R1(cy+H*.1)} Q${R1(bx-L*.5)} ${R1(cy-H*.9)} ${R1(bx)} ${R1(cy-H*.85)} Q${R1(bx+L*.55)} ${R1(cy-H*.6)} ${R1(bx+L*.5)} ${R1(cy+H*.4)} Q${R1(bx+L*.3)} ${R1(cy+H*.95)} ${R1(bx-L*.2)} ${R1(cy+H*.95)} Q${R1(bx-L*.6)} ${R1(cy+H*.7)} ${R1(bx-L*.55)} ${R1(cy+H*.1)} Z" fill="${P.n}" ${SW}/>`+fgPattern(o.pat,bx+L*.05,cy,L*.4,H*.6,P,fgRng(o.seed||17));
   s+=`<path d="M${R1(bx-L*.5)} ${R1(cy+H*.4)} Q${R1(bx-L*.1)} ${R1(cy+H*1.05)} ${R1(bx+L*.3)} ${R1(cy+H*.7)}" stroke="${P.nll}" stroke-width="${R1(H*.3)}" fill="none" opacity=".6"/>`;
   s+=pt("legF",R1(bx-L*.25),R1(cy+H*.5),fOL(`M${R1(bx-L*.2)} ${R1(cy+H*.4)} L${R1(bx-L*.35)} 143`,P.n,5)+`<path d="M${R1(bx-L*.45)} 145 l4 -3 l4 3 l4 -3" stroke="${FI}" stroke-width="2.4" fill="none"/>`);
   let h=`<path d="M${R1(hx-6)} ${R1(cy-H*.05)} Q${R1(hx+L*.2)} ${R1(cy+H*.15)} ${R1(hx+L*.35)} ${R1(cy-H*.05)}" stroke="${FMOUTH}" stroke-width="3" fill="none"/>`;
   h+=pt("jaw",R1(hx+L*.3),R1(cy),`<path d="M${R1(hx+L*.3)} ${R1(cy)} Q${R1(hx+L*.1)} ${R1(cy+H*.45)} ${R1(hx-6)} ${R1(cy)} Q${R1(hx+L*.1)} ${R1(cy+H*.2)} ${R1(hx+L*.3)} ${R1(cy+H*.1)} Z" fill="${P.nll}" ${SW2}/>`);
   if(o.tongue)h+=pt("tongue",R1(hx-4),R1(cy+2),`<path d="M${R1(hx-4)} ${R1(cy+2)} L${R1(hx-22)} ${R1(cy+4)}" stroke="${FTONGUE}" stroke-width="3" stroke-linecap="round"/><circle cx="${R1(hx-23)}" cy="${R1(cy+4)}" r="3" fill="${FTONGUE}" ${SW2}/>`);
   h+=`<path d="M${R1(hx-6)} ${R1(cy-H*.05)} Q${R1(hx+L*.2)} ${R1(cy+H*.12)} ${R1(hx+L*.35)} ${R1(cy-H*.05)}" stroke="${FI}" stroke-width="2.2" fill="none"/>`;
   h+=fgEye(R1(hx+L*.08),R1(cy-H*.8),R1(H*.24),"#C8A040",[-.4,0],.3,P.n)+fgEye(R1(hx+L*.3),R1(cy-H*.9),R1(H*.22),"#C8A040",[-.4,0],.3,P.n);
   if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+L*.2),R1(cy-H*1),P,.7,-1);
   s+=pt("head",R1(hx+L*.2),R1(cy),h);
   if(o.acc)s+=fgPlace(o,P,{neck:[hx+L*.25,cy+H*.4],back:[bx+L*.1,cy-H*1.05],side:[bx+L*.1,cy+H*.1],hold:[hx-8,cy+H*.6],floor:[bx,146],head:[hx+L*.2,cy-H*1.2]});
  }else{const cy=o.rear?112:144-H*1.3,x0=cx-L*.45,x1=cx+L*.45;
   s+=pt("tail",R1(x1-4),R1(cy+2),fgTail(o.tail==="thin"?"thin":o.tail,R1(x1-4),R1(cy+2),P,1.1,1));
   if(o.wings)s+=pt("wingB",R1(cx+4),R1(cy-H*.6),`<path d="M${R1(cx+4)} ${R1(cy-H*.6)} Q${R1(cx+20)} ${R1(cy-H*4)} ${R1(cx+56)} ${R1(cy-H*4.2)} Q${R1(cx+44)} ${R1(cy-H*2.6)} ${R1(cx+50)} ${R1(cy-H*1.8)} Q${R1(cx+30)} ${R1(cy-H*1.6)} ${R1(cx+18)} ${R1(cy)} Z" fill="${P.nd}" ${SW}/>`);
   [[x1-14,"legB",.5],[cx-6,"legB",0]].forEach(([x,c,d])=>{s+=pt(c,R1(x),R1(cy+H*.4),fOL(`M${R1(x)} ${R1(cy+H*.4)} L${R1(x+8)} ${R1(cy+H*1.1)} L${R1(x+4)} 143`,P.nd,5)+`<path d="M${R1(x)} 144 l3 -2 l3 2 l3 -2" stroke="${FI}" stroke-width="2" fill="none"/>`,d)});
   s+=`<path d="M${R1(x0)} ${R1(cy)} Q${R1(x0+L*.1)} ${R1(cy-H*1.15)} ${R1(cx)} ${R1(cy-H)} Q${R1(x1)} ${R1(cy-H*.9)} ${R1(x1+4)} ${R1(cy+2)} Q${R1(x1-L*.1)} ${R1(cy+H*1)} ${R1(cx)} ${R1(cy+H)} Q${R1(x0+L*.1)} ${R1(cy+H)} ${R1(x0)} ${R1(cy)} Z" fill="${P.n}" ${SW}/>`;
   s+=`<path d="M${R1(x0+L*.1)} ${R1(cy+H*.55)} Q${R1(cx)} ${R1(cy+H*1.1)} ${R1(x1-L*.1)} ${R1(cy+H*.5)}" stroke="${P.nll}" stroke-width="${R1(H*.35)}" fill="none" opacity=".55"/>`+fgPattern(o.pat,cx,cy,L*.42,H*.85,P,fgRng(o.seed||19));
   const top=Array.from({length:7},(_,i)=>[R1(x0+L*.15+i*L*.12),R1(cy-H*.98+Math.abs(i-3)*.6),-Math.PI/2]);
   if(o.crest==="sail")s+=`<path d="M${R1(x0+L*.15)} ${R1(cy-H)} Q${R1(cx)} ${R1(cy-H*3.2)} ${R1(x1-L*.1)} ${R1(cy-H*.9)} Z" fill="${P.ac}" ${SW2}/>`+[.3,.45,.6,.75].map(t=>`<path d="M${R1(x0+L*t)} ${R1(cy-H)} L${R1(x0+L*t)} ${R1(cy-H*2.6+Math.abs(t-.5)*H*2)}" stroke="${FI}" stroke-width="1.2"/>`).join("");
   else if(o.crest!=="frill")s+=fgSpines(o.crest,top,P);
   if(o.wings)s+=pt("wingF",R1(cx-6),R1(cy-H*.6),`<path d="M${R1(cx-6)} ${R1(cy-H*.6)} Q${R1(cx-14)} ${R1(cy-H*4.2)} ${R1(cx-50)} ${R1(cy-H*4.4)} Q${R1(cx-38)} ${R1(cy-H*2.8)} ${R1(cx-46)} ${R1(cy-H*1.8)} Q${R1(cx-24)} ${R1(cy-H*1.8)} ${R1(cx+6)} ${R1(cy-H*.2)} Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M${R1(cx-8)} ${R1(cy-H*.8)} L${R1(cx-46+i*12)} ${R1(cy-H*(4-i*.6))}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`);
   [[cx+L*.15,"legF",.5],[x0+L*.18,"legF",0]].forEach(([x,c,d])=>{s+=pt(c,R1(x),R1(cy+H*.4),fOL(`M${R1(x)} ${R1(cy+H*.4)} L${R1(x-8)} ${R1(cy+H*1.1)} L${R1(x-4)} 143`,P.n,5)+`<path d="M${R1(x-10)} 144 l3 -2 l3 2 l3 -2" stroke="${FI}" stroke-width="2" fill="none"/>`,d)});
   const hx=x0-L*.08,hy=cy-H*.3,hl=L*.32,hh=H*.9;let h="";
   if(o.crest==="frill")h+=pt("ear",R1(hx+hl*.7),R1(hy),`<path d="M${R1(hx+hl*.6)} ${R1(hy-hh*1.6)} Q${R1(hx+hl*1.4)} ${R1(hy)} ${R1(hx+hl*.6)} ${R1(hy+hh*1.6)} Q${R1(hx+hl*1)} ${R1(hy)} ${R1(hx+hl*.6)} ${R1(hy-hh*1.6)} Z" fill="${P.ac}" ${SW2}/>`);
   h+=`<path d="M${R1(hx-hl*.55)} ${R1(hy+hh*.25)} L${R1(hx+hl*.4)} ${R1(hy+hh*.3)} L${R1(hx+hl*.35)} ${R1(hy+hh*.6)} Z" fill="${FMOUTH}"/>`;
   if(o.tongue)h+=pt("tongue",R1(hx-hl*.55),R1(hy+hh*.3),`<path d="M${R1(hx-hl*.55)} ${R1(hy+hh*.3)} l-12 0 l-3 -3 M${R1(hx-hl*.55-12)} ${R1(hy+hh*.3)} l-3 3" stroke="${FTONGUE}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`);
   h+=pt("jaw",R1(hx+hl*.4),R1(hy+hh*.45),`<path d="M${R1(hx+hl*.4)} ${R1(hy+hh*.4)} Q${R1(hx)} ${R1(hy+hh*1.05)} ${R1(hx-hl*.55)} ${R1(hy+hh*.3)} Q${R1(hx)} ${R1(hy+hh*.65)} ${R1(hx+hl*.4)} ${R1(hy+hh*.7)} Z" fill="${P.nl}" ${SW2}/>`);
   h+=`<path d="M${R1(hx+hl*.6)} ${R1(hy-hh*.5)} Q${R1(hx-hl*.2)} ${R1(hy-hh*.9)} ${R1(hx-hl*.6)} ${R1(hy+hh*.1)} Q${R1(hx-hl*.6)} ${R1(hy+hh*.35)} ${R1(hx-hl*.4)} ${R1(hy+hh*.32)} L${R1(hx+hl*.6)} ${R1(hy+hh*.5)} Z" fill="${P.n}" ${SW}/><circle cx="${R1(hx-hl*.48)}" cy="${R1(hy)}" r="1" fill="${FI}"/>`;
   if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+hl*.2),R1(hy-hh*.65),P,.8,1);
   h+=fgEye(R1(hx+hl*.05),R1(hy-hh*.3),R1(hh*.32),o.kind==="myth"?P.ac:"#C8A040",[-.4,0],.22,P.n);
   if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hh-6,13,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,hx-hl*.7,hy+hh*.4,13,0);
   s+=pt("head",R1(x0+4),R1(cy),h);
   if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[x0+6,cy+H*.4],back:[cx,cy-H-8],side:[cx,cy],floor:[cx,146]});
  }
  s+=fG(g,1,`<path d="M20 132 l6 -6 M24 138 l8 -4" stroke="${P.l}" stroke-width="2" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="${cx}" cy="${R1(o.frog?144-o.H*.9:144-o.H*1.3)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+20),40,6));
  return s},
 parts:o=>o.wings?["head","jaw","tail","wing"]:o.tongue?["head","jaw","tongue","tail"]:["head","jaw","tail","leg"],
 sig:o=>[o.kind,o.sp,o.crest,o.horn,o.tail,o.pat,o.wings?1:0,o.tongue?1:0,o.rear?1:0].join(".")};
