/* ---- Tinker's Scrapyard, 8 ---- */
/* Disappointium: opened at a birthday party and briefly thought the world's most disappointing present. A hermit crab living in the gift box instead. */
addForm("Disappointium",{n:"#E8704A",a:"#5A8AC8",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(64)+
 `<rect x="94" y="80" width="64" height="54" fill="${P.ac}" ${SW}/><path d="M126 80 V134 M94 106 H158" stroke="#F2C94C" stroke-width="6"/><path d="M126 80 q-10 -14 -18 -6 q6 8 18 6 q10 -14 18 -6 q-6 8 -18 6" fill="#F2C94C" ${SW2}/><path d="M90 76 L160 74 L162 82 L92 84 Z" fill="${P.ac}" ${SW2} transform="rotate(-14 126 78)"/>`+
 [[96,"legB",.5],[88,"legB",1]].map(([x,c,d],i)=>pt(c,x,124,fOL(`M${x} 124 Q${x-10} ${118-i*4} ${x-16} 140`,P.nd,5),d)).join("")+
 `<path d="M70 126 Q72 104 96 100 Q106 112 100 132 Q84 136 70 126 Z" fill="${P.n}" ${SW}/>`+
 [[84,"legF",0],[76,"legF",.8]].map(([x,c,d],i)=>pt(c,x,128,fOL(`M${x} 128 Q${x-14} ${124+i*2} ${x-20} 144`,P.n,5),d)).join("")+
 pt("claw",70,110,fOL("M76 112 Q64 112 56 100",P.n,6)+`<path d="M34 90 Q36 80 52 82 Q62 86 60 96 Q54 104 40 100 Z" fill="${P.n}" ${SW}/>`+pt("claw2",42,90,`<path d="M42 90 Q34 84 30 88 Q34 94 44 94 Z" fill="${P.nd}" ${SW2}/>`))+
 pt("head",80,104,`<path d="M80 102 L76 80" stroke="${FI}" stroke-width="3"/><path d="M88 102 L90 78" stroke="${FI}" stroke-width="3"/>${E2(76,78,4.6,"#1A1A1A",[0,.6])}${E2(90,76,4.6,"#1A1A1A",[0,.6])}<path d="M72 72 l8 2 M86 70 l8 2" stroke="${FI}" stroke-width="1.6"/>`+pt("jaw",76,108,`<path d="M70 108 q6 -3 12 0" stroke="${FI}" stroke-width="2" fill="none"/>`))+
 fG(g,1,`<path d="M20 40 l-4 -12 l8 4 l4 -8 l4 8 l8 -4 l-4 12 Z" fill="#F2C94C" ${SW2}/>`)+fG(g,2,`<circle cx="126" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Disappointium"]="Gift-Box Hermit Crab";SM("Disappointium","Oh. Thanks.","RES","s",0,100,"tatk-2","It's the thought that counts. Apparently.");

/* Do Not Use Mix: mixed from two tags that both read 'do not use'. A coral snake, banded all over in the colours that mean keep away. */
addForm("Do Not Use Mix",{n:"#C8302A",a:"#F2D040",rn:"#3A3A4A",rb:"#2A2A30",ra:"#5FE0F0"},"slink",(P,g)=>fShadow(74)+
 pt("tail",170,120,`<path d="M160 124 Q180 128 188 116" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M160 124 Q180 128 188 116" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 pt("sway",110,118,`<path d="M54 110 Q80 140 108 118 Q136 96 162 124" stroke="${FI}" stroke-width="18" fill="none" stroke-linecap="round"/><path d="M54 110 Q80 140 108 118 Q136 96 162 124" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/>${[[62,116],[78,128],[96,126],[114,112],[132,106],[150,114]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="7.2" fill="${i%2?P.ac:"#2A2A30"}"/>`).join("")}`)+
 pt("head",50,104,`<path d="M30 106 Q30 90 46 88 Q62 90 62 104 Q58 116 46 116 Z" fill="#2A2A30" ${SW}/><path d="M50 92 v20" stroke="${P.ac}" stroke-width="5"/>${E2(42,98,3,"#E8D040")}<path d="M32 108 L46 110 L44 114 L34 112 Z" fill="${FMOUTH}"/>`+pt("tongue",32,110,`<path d="M32 110 h-8 l-3 -3 M24 110 l-3 3" stroke="${FTONGUE}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`${[0,1].map(i=>`<g transform="rotate(${i?8:-8} ${150+i*20} 40)"><rect x="${140+i*20}" y="30" width="26" height="14" fill="#F2E060" ${SW2}/><text x="${142+i*20}" y="40" font-size="5" font-weight="bold" fill="#C8302A">DO NOT USE</text></g>`).join("")}`)+fG(g,2,`<circle cx="108" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Do Not Use Mix"]="Warning-Banded Coral Snake";SM("Do Not Use Mix","Do Not Use","SCR","a",60,100,"corrode@40,tatk-1@30","The label said not to. Twice.");

/* Dobanite: termites built their mound three times taller round its buried crate. An aardwolf, the termite-lapping hyena cousin, beside a towering mound. */
addForm("Dobanite",{n:"#D8B070",a:"#2A2A30",rn:"#3A3A4A",rb:"#B8603A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M140 146 Q140 80 158 20 Q170 14 176 24 Q186 80 190 146 Z" fill="#B8803A" ${SW}/>${[[160,40],[168,70],[156,100],[176,110]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="3" ry="4" fill="#6A4A2A"/>`).join("")}`+fShadow(66)+
 pt("tail",128,96,`<path d="M126 96 Q140 98 144 112" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M126 96 Q140 98 144 112" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M140 106 l6 8" stroke="${P.ac}" stroke-width="5" stroke-linecap="round"/>`)+
 fLeg("legB",118,106,34,7,P.nd,P.ndd,.5)+fLeg("legB",92,108,32,7,P.nd,P.ndd,1.3)+
 `<path d="M64 98 Q64 78 96 76 Q126 78 130 96 Q126 112 98 112 Q68 112 64 98 Z" fill="${P.n}" ${SW}/>${[78,90,102,114].map(x=>`<path d="M${x} 80 l-4 26" stroke="${P.ac}" stroke-width="3"/>`).join("")}<path d="M72 78 Q96 70 124 80" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 fLeg("legF",112,108,32,7,P.n,P.ndd,0)+fLeg("legF",78,108,32,7,P.n,P.ndd,.8)+
 pt("head",66,90,`<path d="M30 92 Q32 76 50 74 Q66 76 68 90 Q64 102 48 102 Z" fill="${P.n}" ${SW}/><path d="M30 92 L22 96 L32 100 Z" fill="${P.ac}" ${SW2}/>${E2(48,84,3.4,"#1A1A1A")}`+HMOUTH(28,98,38,P,2)+pt("tongue",28,100,`<path d="M28 100 Q14 108 10 118" stroke="${FTONGUE}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
  pt("ear",58,76,`<path d="M54 78 L56 58 L66 76 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`${[[20,130],[30,136],[14,138]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="2" ry="1.2" fill="#6A4A2A"/>`).join("")}`)+fG(g,2,`<circle cx="98" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Dobanite"]="Mound-Licking Aardwolf";SM("Dobanite","Termite Feast","RES","a",55,100,"drain:30","Thousands of tiny bites, all at once.");

/* Documentex: a year-long documentary about it, in which it never appears. A Bigfoot, blurry, half out of frame, as all the best footage is. */
addForm("Documentex",{n:"#6A4A3A",a:"#3A3A40",rn:"#E8D8C8",rb:"#5A8A4A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="14" y="10" width="180" height="136" fill="none" stroke="${FI}" stroke-width="2" stroke-dasharray="10 6"/><circle cx="26" cy="22" r="4" fill="#C8302A"/><text x="34" y="26" font-size="8" font-weight="bold" fill="#C8302A">REC</text>`+fShadow(50)+
 `<g opacity=".9" filter="url(#blurBF)"><filter id="blurBF"><feGaussianBlur stdDeviation=".8"/></filter>`+
 pt("legB",116,124,fOL("M114 116 L120 140 H132",P.nd,13),.5)+
 `<path d="M82 120 Q74 70 104 62 Q134 70 128 120 Q120 134 104 134 Q90 134 82 120 Z" fill="${P.n}" ${SW}/>${Array.from({length:12},(_,i)=>`<path d="M${88+(i%4)*10} ${76+Math.floor(i/4)*16} q2 8 -2 12" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("legF",92,124,fOL("M94 116 L88 140 H76",P.n,13))+
 pt("armB",126,84,fOL("M126 84 Q144 100 142 124",P.nd,11),.4)+pt("armF",86,84,fOL("M84 84 Q66 100 68 124",P.n,11))+
 pt("head",104,54,`<path d="M88 58 Q86 36 104 34 Q122 36 120 58 Q116 70 104 70 Q92 70 88 58 Z" fill="${P.n}" ${SW}/><path d="M94 54 Q104 48 114 54 L112 64 Q104 68 96 64 Z" fill="#A88A70"/>${E2(99,54,2.6,"#1A1A1A",[.8,0])}${E2(109,54,2.6,"#1A1A1A",[.8,0])}`+HMOUTH(100,62,108,P,1.6))+`</g>`+
 fG(g,1,`<text x="150" y="140" font-size="8" fill="${FI}" font-family="monospace">00:01:12</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,30,6)));
FORM_TITLE["Documentex"]="Camera-Shy Bigfoot";SM("Documentex","Out Of Frame","RES","s",0,100,"dodge,dodge@50","There it was! No, wait. Gone again.");

/* Double-Speed Mix: the backup generator ran every mixer at double speed for an hour. A squirrel monkey, running at double speed at all times. */
addForm("Double-Speed Mix",{n:"#E8C060",a:"#F4F0F4",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"hop",(P,g)=>fShadow(60,104)+
 pt("tail",128,104,`<path d="M124 108 Q160 114 170 94 Q176 80 166 72" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M124 108 Q160 114 170 94 Q176 80 166 72" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M168 76 l-4 -6" stroke="${FI}" stroke-width="6" stroke-linecap="round"/>`)+
 pt("legB",118,118,fOL("M118 114 Q134 120 132 134 L140 140",P.nd,7),.0)+
 `<path d="M88 114 Q86 90 106 86 Q126 90 126 114 Q120 126 106 126 Q92 126 88 114 Z" fill="#9A9AA0" ${SW}/>`+
 pt("legF",94,118,fOL("M96 114 Q80 120 82 134 L74 140",P.n,7),.5)+
 pt("armF",92,98,fOL("M92 98 Q76 96 68 84",P.n,5))+pt("armB",120,98,fOL("M120 98 Q136 90 142 78",P.n,5),.4)+
 pt("head",104,74,`<circle cx="104" cy="72" r="16" fill="#9A9AA0" ${SW}/><path d="M92 70 Q96 60 104 62 Q112 60 116 70 Q114 82 104 84 Q94 82 92 70 Z" fill="${P.ac}"/><path d="M94 72 Q104 66 114 72" fill="${FI}" opacity=".8"/>${E2(98,70,3.4,"#3A2410")}${E2(110,70,3.4,"#3A2410")}`+HMOUTH(100,78,108,P,2)+`<path d="M92 56 Q104 48 116 56" stroke="${FI}" stroke-width="5" fill="none"/>`)+
 fG(g,1,`<path d="M20 70 h-6 M26 80 h-12 M20 90 h-8 M28 100 h-14" stroke="${P.l}" stroke-width="2.4" stroke-linecap="round"/><text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}">×2</text>`)+fG(g,2,`<circle cx="106" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Double-Speed Mix"]="Double-Speed Squirrel Monkey";SM("Double-Speed Mix","Overdrive","STR","a",40,100,"multi:2-2,spd+1","Everything twice as fast. Even the mistakes.");

/* Dreamtrain Blend: the night crew dreamt about it forty-one times in one year, always on a train. A baku, the dream-eating creature, riding the night train. */
addForm("Dreamtrain Blend",{n:"#7A6AA8",a:"#F4F0F4",rn:"#3A3A4A",rb:"#F2C94C",ra:"#5FE0F0"},"stand",(P,g)=>`<rect x="14" y="126" width="180" height="6" fill="#5A5A64"/>${[30,70,110,150,190].map(x=>`<path d="M${x} 132 v12" stroke="#6A4A2A" stroke-width="4"/>`).join("")}<rect x="132" y="70" width="58" height="56" rx="6" fill="#3A3A5A" ${SW}/><rect x="140" y="80" width="18" height="16" fill="#F2E080" ${SW2}/><rect x="164" y="80" width="18" height="16" fill="#F2E080" ${SW2}/>`+fShadow(66)+
 pt("tail",128,96,`<path d="M126 96 l10 4" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+
 fLeg("legB",118,106,20,11,P.nd,P.ndd,.5)+fLeg("legB",90,108,18,11,P.nd,P.ndd,1.3)+
 `<path d="M62 100 Q62 76 96 74 Q128 76 132 98 Q128 116 98 116 Q66 116 62 100 Z" fill="${P.n}" ${SW}/><path d="M82 76 Q100 72 120 80 L118 112 Q100 116 84 112 Z" fill="${P.ac}" ${SW2}/>${[[90,90],[106,96],[98,104]].map(([x,y])=>`<path d="M${x} ${y} l1.6 -3 l1.6 3 l3 1.6 l-3 1.6 l-1.6 3 l-1.6 -3 l-3 -1.6 Z" fill="#F2C94C"/>`).join("")}`+
 fLeg("legF",112,108,18,11,P.n,P.ndd,0)+fLeg("legF",74,108,18,11,P.n,P.ndd,.8)+
 pt("head",66,88,`<path d="M42 92 Q42 72 62 70 Q82 72 84 90 Q80 104 62 104 Q46 104 42 92 Z" fill="${P.n}" ${SW}/>`+pt("tongue",44,94,`<path d="M46 90 Q32 92 28 106 Q26 116 32 118" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M46 90 Q32 92 28 106 Q26 116 32 118" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
  `<path d="M54 84 q4 3 8 0" stroke="${FI}" stroke-width="2" fill="none"/><path d="M68 84 q4 3 8 0" stroke="${FI}" stroke-width="2" fill="none"/>`+pt("ear",76,74,`<ellipse cx="78" cy="74" rx="5" ry="6" fill="${P.n}" ${SW2}/>`)+
  `<path d="M38 64 Q46 56 54 62 Q48 66 44 72 Z" fill="${P.ac}" opacity=".6"/><path d="M28 52 q6 -4 12 0 q-6 4 -12 0 Z" fill="${P.ac}" opacity=".5"/>`)+
 fG(g,1,`<path d="M20 30 a10 10 0 1 0 8 -10 a7 7 0 1 1 -8 10 Z" fill="#F2D060" ${SW2}/>`)+fG(g,2,`<circle cx="100" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["Dreamtrain Blend"]="Night-Train Baku";SM("Dreamtrain Blend","Eat The Dream","RES","a",60,100,"drain:30,tacc-1@30","It eats the bad dreams. Usually only the bad ones.");

/* Duetium: karaoke ran late and a duet drowned out the timer. A cockatiel, crest up, belting into a microphone. */
addForm("Duetium",{n:"#C8C0B0",a:"#F2C020",rn:"#3A3A4A",rb:"#E8604A",ra:"#5FE0F0"},"perch",(P,g)=>`<rect x="140" y="80" width="6" height="60" fill="${FI}"/><path d="M128 146 h30" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`+`<path d="M40 126 H130" stroke="#6A4A2A" stroke-width="7" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",100,118,`<path d="M96 116 L118 148 L108 148 L92 122 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M68 114 Q66 86 88 82 Q110 86 110 114 Q102 124 88 124 Q74 124 68 114 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",94,98,`<path d="M84 94 Q104 90 112 110 Q98 116 86 108 Z" fill="${P.nd}" ${SW}/><path d="M92 98 h14" stroke="#F4F0F4" stroke-width="3"/>`)+
 pt("legF",86,122,`<path d="M84 122 l-2 4 M90 122 l2 4" stroke="#C8A0A0" stroke-width="2.4"/>`)+
 pt("head",82,76,`<circle cx="80" cy="72" r="13" fill="${P.ac}" ${SW}/><circle cx="76" cy="78" r="5" fill="#E8604A" ${SW2}/>${E2(78,68,3,"#1A1A1A")}`+
  `<path d="M68 70 L60 72 L68 78 Z" fill="${FMOUTH}"/>`+pt("beak",66,78,`<path d="M68 76 L60 80 L68 80 Z" fill="#8A8A94"/>`)+`<path d="M68 66 Q58 66 58 72 L68 70 Z" fill="#8A8A94"/>`+
  pt("ant",84,60,`${[0,1,2].map(i=>`<path d="M${82+i*3} 60 Q${80+i*6} ${40-i*2} ${92+i*6} ${30+i*2}" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M${82+i*3} 60 Q${80+i*6} ${40-i*2} ${92+i*6} ${30+i*2}" stroke="${P.ac}" stroke-width="2" fill="none" stroke-linecap="round"/>`).join("")}`))+
 pt("armF",142,76,`<circle cx="142" cy="72" r="9" fill="#5A5A64" ${SW}/>${[0,1,2].map(i=>`<path d="M${136+i*5} 66 v12" stroke="#8A8A94" stroke-width="1"/>`).join("")}`)+
 fG(g,1,`<path d="M30 40 v-14 l8 3 M44 46 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="28" cy="40" r="3" fill="${P.ac}"/><circle cx="42" cy="46" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="88" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,30,6)));
FORM_TITLE["Duetium"]="Karaoke Cockatiel";SM("Duetium","Power Ballad","RES","a",70,100,"tacc-1,tspd-1@30","The big finish. The timer never stood a chance.");

/* Eclipsium: mixed on Tamber Hill while the moon covered the sun, mostly by guessing. An owl monkey, the night monkey, peering through eclipse glasses. */
addForm("Eclipsium",{n:"#8A7A6A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#2A2A30",ra:"#F2C94C"},"perch",(P,g)=>`<circle cx="160" cy="34" r="16" fill="#F2C94C" ${SW2}/><circle cx="154" cy="32" r="15" fill="#2A2A30"/><path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",122,110,`<path d="M118 112 Q140 128 144 148" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M118 112 Q140 128 144 148" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 `<path d="M86 114 Q82 86 104 82 Q126 86 124 114 Q118 124 104 124 Q90 124 86 114 Z" fill="${P.n}" ${SW}/><path d="M94 112 Q104 120 116 112 Q114 98 104 96 Q96 98 94 112 Z" fill="${P.ac}"/>`+
 pt("legF",96,118,`<path d="M96 116 l-4 6 M100 118 l0 6" stroke="${FI}" stroke-width="3"/>`)+
 pt("armF",92,96,fOL("M92 96 Q80 84 84 70",P.n,5))+pt("armB",118,96,fOL("M118 96 Q128 84 124 70",P.nd,5),.4)+
 pt("head",104,66,`<circle cx="104" cy="64" r="16" fill="${P.n}" ${SW}/><circle cx="96" cy="64" r="8" fill="${P.ac}"/><circle cx="112" cy="64" r="8" fill="${P.ac}"/>${E2(96,64,6,"#C8901A")}${E2(112,64,6,"#C8901A")}<rect x="86" y="58" width="16" height="12" rx="3" fill="#2A2A30" opacity=".85" ${SW2}/><rect x="106" y="58" width="16" height="12" rx="3" fill="#2A2A30" opacity=".85" ${SW2}/><path d="M102 64 h4" stroke="${FI}" stroke-width="2"/>`+HMOUTH(100,74,108,P,1.6))+
 fG(g,1,`${[[20,40],[40,24],[30,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="#F2C94C"/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Eclipsium"]="Eclipse-Glasses Owl Monkey";SM("Eclipsium","Four Minutes Dark","RES","s",0,100,"acc+1,dodge","Night-eyes are made for exactly this.");

/* Edwynite: one mistyped line in 1965, still in every copy. A woodpecker punching holes in a punch card, one in the wrong place. */
addForm("Edwynite",{n:"#3A3A40",a:"#C8302A",rn:"#E8D8C8",rb:"#E8D8A0",ra:"#5FE0F0"},"perch",(P,g)=>`<rect x="130" y="20" width="56" height="120" fill="#E8D8A0" ${SW}/>${Array.from({length:30},(_,i)=>{const c=i%5,r=Math.floor(i/5);return`<rect x="${136+c*10}" y="${30+r*16}" width="5" height="9" fill="${(c*7+r*3)%4?"#E8D8A0":"#3A3A44"}"/>`}).join("")}<rect x="146" y="78" width="5" height="9" fill="${P.ac}"/><path d="M130 30 L136 20" stroke="${FI}" stroke-width="1"/>`+fShadow(40,110)+
 pt("tail",116,120,`<path d="M112 116 L124 140 L112 136 Z" fill="${P.n}" ${SW}/>`)+
 pt("legB",120,92,`<path d="M120 92 l6 2 M120 100 l6 4" stroke="${FI}" stroke-width="2.4"/>`,.5)+
 `<path d="M92 112 Q90 80 106 74 Q122 78 122 112 Q116 124 106 124 Q96 124 92 112 Z" fill="${P.n}" ${SW}/><path d="M96 108 Q96 90 106 88 Q114 92 114 108" fill="#F4F0F4"/>${[0,1,2].map(i=>`<path d="M${100+i*5} 80 h4" stroke="#F4F0F4" stroke-width="2.4"/>`).join("")}`+
 pt("legF",118,108,`<path d="M118 108 l6 2" stroke="${FI}" stroke-width="2.4"/>`)+
 pt("head",108,66,`<circle cx="106" cy="62" r="13" fill="${P.n}" ${SW}/><path d="M96 50 Q106 40 116 52 Q108 48 98 54 Z" fill="${P.ac}" ${SW2}/>${E2(108,60,3,"#1A1A1A")}<path d="M98 66 h10" stroke="#F4F0F4" stroke-width="3"/>`+
  `<path d="M118 60 L142 62 L118 66 Z" fill="${FMOUTH}"/>`+pt("beak",120,66,`<path d="M118 66 L140 64 L118 69 Z" fill="#8A8A94" ${SW2}/>`)+`<path d="M118 56 L144 61 L118 62 Z" fill="#8A8A94" ${SW2}/>`)+
 fG(g,1,`<text x="20" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">1965</text>`)+fG(g,2,`<circle cx="106" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,90,6)));
FORM_TITLE["Edwynite"]="Keypunch Woodpecker";SM("Edwynite","Typo","STR","a",60,100,"multi:1-3,tacc-1@20","One hole in the wrong place, copied forever.");
