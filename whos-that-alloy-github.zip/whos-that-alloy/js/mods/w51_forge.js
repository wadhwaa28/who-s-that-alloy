/* =============== THE FORGE: Overclocked forms for every other alloy ===============
   The hand-drawn forms cover the alloys you meet first. For the rest, the moor "cooks" a form from the alloy itself: a body plan chosen by
   where it lives and how it's built, features chosen by what it's made of, and something it carries or wears chosen by what it's used
   for. Plenty of them are animals. Plenty aren't: golems, walking tools, clockwork, wisps, things from stories, and things nobody has a
   word for. Every alloy gets its own combination, checked so that no two come out the same. */
const FG={plans:{},pick:{},sig:new Set(),titles:new Set()};
const fgHash=s=>{let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0};
function fgRng(seed){let a=seed>>>0;return()=>{a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const fgPick=(r,arr)=>arr[Math.floor(r()*arr.length)%arr.length];
const fgW=(r,obj)=>{const e=Object.entries(obj).filter(([,w])=>w>0),t=e.reduce((s,[,w])=>s+w,0);let x=r()*t;for(const[k,w]of e){x-=w;if(x<=0)return k}return e[0][0]};
const R1=v=>Math.round(v*10)/10;

/* ---- what the alloy is like ---- */
const FG_HEAVY=new Set("W Pb Au Pt Os Ir Ta Re U Bi Hg Th Pu Np Am".split(" ")),FG_LIGHT=new Set("Al Mg Ti Be Li Sc Na K Ca Si B".split(" ")),
 FG_MAG=new Set("Fe Co Ni Nd Sm Gd Dy Tb".split(" ")),FG_RAD=new Set("U Th Pu Ra Po Rn Am Cm Pm At Fr Np Pa Ac Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og Tc".split(" ")),
 FG_LOW=new Set("Bi Ga In Sn Pb Cd Hg".split(" ")),FG_PREC=new Set("Au Ag Pt Pd Rh Ru Ir Os".split(" ")),FG_REF=new Set("W Mo Ta Nb Re Hf Zr Cr V".split(" ")),FG_REACT=new Set("Na K Cs Rb Fr Li Ca Ba Sr".split(" "));
function fgTraits(a){const C=a.comp||[],has=S=>C.reduce((s,[e,v])=>s+(S.has(e)?v:0),0),T=(a.types||[]).join("/").toLowerCase();
  return{heavy:has(FG_HEAVY)>25||a.d>12,light:has(FG_LIGHT)>45||a.d<4.2,mag:has(FG_MAG)>40||a.mag>0||/magnet/.test(T),rad:has(FG_RAD)>0.5||/radioac/.test(T),low:has(FG_LOW)>35||/low-melt/.test(T)||a.mp<350,
   prec:has(FG_PREC)>25||/precious/.test(T),ref:has(FG_REF)>20||/heat-proof/.test(T)||a.mp>2200,react:has(FG_REACT)>5||/reactive/.test(T),liquid:/liquid/.test(T)||a.mp<40,tough:/tough/.test(T)||a.hard>=7,soft:a.hard<=2.5,many:C.length>=4}}

/* ---- what it does for a living: the thing it carries, wears or is part-made of ---- */
const FG_USE=[[/spring|coil/,"spring"],[/gear|flywheel/,"gear"],[/\bkeys?\b|latch|locker|hinge|door/,"key"],[/coin|medal|commemorat|trophy|cups/,"medal"],[/\bbells?\b|gong|cymbal/,"bell"],[/pipe|fitting|valve|fountain|plumb/,"valve"],
 [/blade|knife|cutting|dies\b|drill|bits\b|teeth|crusher|file blank|saw/,"blade"],[/chain|bicycle/,"chain"],[/bolt|rivet|spike|railway|nail/,"bolt"],[/plate|armou?r|shield|liner|plating|cladding/,"plate"],
 [/lens|telescope|mirror|camera|glass/,"lens"],[/bearing/,"bearing"],[/compass|needle/,"compass"],[/magnet|relay|armature|loudspeaker|motor|induction|winding|transformer/,"magnet"],
 [/lamp|kiln|furnace|heating|element|fire|stirrer|manifold|exhaust/,"flame"],[/rocket|nozzle|afterburner|jet/,"jet"],[/turbine|drone|fan|dryer/,"fan"],[/satellite|antenna|sensor/,"antenna"],[/glider|racing|kayak|yacht|keel|boat|cleat|paddle/,"fin"],
 [/watch|clock|precision|resistor|gauge/,"dial"],[/jewel|ceremonial|luxury|stained|crown/,"jewel"],[/simulation|computer/,"glitch"],[/research|sample|reference|test|experimental|prototype|catalyst/,"tag"],
 [/fishing|weight|ballast|counterweight|paperweight/,"weight"],[/prosthetic|limb/,"limb"],[/maglev|track|rail/,"rail"],[/ladder|rung|frame|bracket|strut|bridge|structural|crane/,"strut"],
 [/nib|pen\b/,"nib"],[/laptop|shell|housing|casing|case/,"case"],[/garden|tool|pick/,"tool"],[/fuse|fusible|plug|solder|safety/,"fuse"],[/organ/,"organ"],[/dart/,"dart"],[/soldier|model|toy/,"toy"],
 [/nuclear|radiation|reactor/,"atom"],[/hair/,"comb"],[/snowplow|plow/,"plow"],[/stretch/,"band"]];
function fgUse(a){const u=String(a.uses||"").toLowerCase().replace(/formerly[^;]*;\s*now mostly/,"");for(const[re,k]of FG_USE)if(re.test(u))return k;return null}

/* small things, drawn at (x,y) and roughly s units across */
function fgAcc(id,P,x,y,s,rot){s=s||14;const k=s/14,T=(inner)=>`<g transform="translate(${R1(x)} ${R1(y)}) rotate(${rot||0}) scale(${R1(k)})">${inner}</g>`;
 switch(id){
  case"spring":return T(`<path d="M-7 6 l14 -3 l-14 -3 l14 -3 l-14 -3 l14 -3" stroke="${FI}" stroke-width="4" fill="none" stroke-linejoin="round"/><path d="M-7 6 l14 -3 l-14 -3 l14 -3 l-14 -3 l14 -3" stroke="${P.l}" stroke-width="2" fill="none" stroke-linejoin="round"/>`);
  case"gear":return T(`${Array.from({length:8},(_,i)=>`<rect x="-1.8" y="-8.4" width="3.6" height="4" fill="${P.b}" stroke="${FI}" stroke-width="1" transform="rotate(${i*45})"/>`).join("")}<circle r="6" fill="${P.b}" stroke="${FI}" stroke-width="1.6"/><circle r="2" fill="${FI}"/>`);
  case"key":return T(`<circle cx="-4" r="3.6" fill="none" stroke="${FI}" stroke-width="3.4"/><circle cx="-4" r="3.6" fill="none" stroke="${P.b}" stroke-width="1.8"/><path d="M0 0 H9 M6 0 v3 M8.4 0 v2.4" stroke="${FI}" stroke-width="3.4" stroke-linecap="round"/><path d="M0 0 H9 M6 0 v3 M8.4 0 v2.4" stroke="${P.b}" stroke-width="1.6" stroke-linecap="round"/>`);
  case"medal":return T(`<path d="M-3 -9 L0 -2 L3 -9" stroke="${P.ac}" stroke-width="2.4" fill="none"/><circle r="5.4" fill="${P.b}" stroke="${FI}" stroke-width="1.6"/>${star(0,0,3,P.l)}`);
  case"bell":return T(`<path d="M-6 4 Q-6 -6 0 -7 Q6 -6 6 4 L7 5 L-7 5 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.6" stroke-linejoin="round"/><circle cy="6.4" r="1.6" fill="${P.d}" stroke="${FI}" stroke-width="1"/><path d="M0 -7 v-2" stroke="${FI}" stroke-width="1.6"/>`);
  case"valve":return T(`<rect x="-8" y="-2.4" width="16" height="4.8" rx="1" fill="${P.d}" stroke="${FI}" stroke-width="1.4"/><circle cy="-6" r="4.6" fill="none" stroke="${FI}" stroke-width="3"/><circle cy="-6" r="4.6" fill="none" stroke="${P.ac}" stroke-width="1.6"/><path d="M0 -10.6 V-1.4 M-4.6 -6 H4.6" stroke="${P.ac}" stroke-width="1.2"/>`);
  case"blade":return T(`<path d="M-8 2 L6 -3 Q9 -3 8 0 L-8 4 Z" fill="${P.ll}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><rect x="-12" y="1" width="5" height="3.6" rx="1" fill="${P.d}" stroke="${FI}" stroke-width="1.2"/>`);
  case"chain":return T(`${[-6,0,6].map((cx,i)=>`<ellipse cx="${cx}" rx="3.6" ry="2.2" fill="none" stroke="${FI}" stroke-width="2.6" transform="rotate(${i%2?90:0} ${cx} 0)"/><ellipse cx="${cx}" rx="3.6" ry="2.2" fill="none" stroke="${P.l}" stroke-width="1.2" transform="rotate(${i%2?90:0} ${cx} 0)"/>`).join("")}`);
  case"bolt":return T(`<path d="M-5 -5 H5 V-1 H-5 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.3"/><path d="M-2 -1 H2 V8 H-2 Z" fill="${P.d}" stroke="${FI}" stroke-width="1.2"/><path d="M-2 2 h4 M-2 5 h4" stroke="${FI}" stroke-width=".8"/>`);
  case"plate":return T(`<path d="M-7 -6 H7 V3 Q0 9 -7 3 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.6" stroke-linejoin="round"/>${[[-4,-3],[4,-3]].map(([a,b])=>`<circle cx="${a}" cy="${b}" r="1" fill="${P.dd}"/>`).join("")}<path d="M-5 -1 H5" stroke="${P.l}" stroke-width="1.2"/>`);
  case"lens":return T(`<circle r="6" fill="#CFE6F4" stroke="${FI}" stroke-width="1.6" opacity=".9"/><circle r="6" fill="none" stroke="${P.b}" stroke-width="1.6"/><path d="M-3 -2 Q-1 -4 2 -4" stroke="#FFFFFF" stroke-width="1.4" fill="none"/><path d="M4 4 L9 9" stroke="${FI}" stroke-width="3"/>`);
  case"bearing":return T(`<circle r="7" fill="none" stroke="${FI}" stroke-width="2.6"/><circle r="7" fill="none" stroke="${P.d}" stroke-width="1.2"/>${Array.from({length:6},(_,i)=>`<circle cx="${R1(4.6*Math.cos(i*1.047))}" cy="${R1(4.6*Math.sin(i*1.047))}" r="1.8" fill="${P.ll}" stroke="${FI}" stroke-width=".8"/>`).join("")}`);
  case"compass":return T(`<circle r="6.4" fill="${P.ll}" stroke="${FI}" stroke-width="1.6"/><path d="M0 -5 L1.6 0 L0 5 L-1.6 0 Z" fill="${P.ac}" stroke="${FI}" stroke-width=".8"/><circle r="1" fill="${FI}"/>`);
  case"magnet":return T(`<path d="M-6 6 V-1 Q-6 -7 0 -7 Q6 -7 6 -1 V6 H2.6 V-1 Q2.6 -3.6 0 -3.6 Q-2.6 -3.6 -2.6 -1 V6 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><rect x="-6" y="3" width="3.4" height="3" fill="${P.ll}"/><rect x="2.6" y="3" width="3.4" height="3" fill="${P.ll}"/>`);
  case"flame":return T(`<path class="p-glow" d="M0 6 Q-7 2 -3 -4 Q-2 0 0 -2 Q0 -6 3 -9 Q8 -2 5 3 Q4 6 0 6 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.3"/><path d="M0 5 Q-3 2 -1 -1 Q1 1 2 -2 Q4 2 2 4 Z" fill="#FFE070"/>`);
  case"jet":return T(`<path d="M-8 -4 L4 -3 L8 0 L4 3 L-8 4 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.4"/><path class="p-glow" d="M-8 -3 Q-16 0 -8 3 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1"/>`);
  case"fan":return T(`<g class="p-spin" style="transform-origin:0px 0px">${[0,1,2,3].map(i=>`<ellipse cx="0" cy="-4.4" rx="2.2" ry="4.4" fill="${P.l}" stroke="${FI}" stroke-width="1" transform="rotate(${i*90})"/>`).join("")}</g><circle r="2" fill="${P.d}" stroke="${FI}" stroke-width="1"/>`);
  case"antenna":return T(`<path d="M0 6 V-6" stroke="${FI}" stroke-width="1.6"/><path d="M-6 -4 Q0 -10 6 -4" fill="none" stroke="${P.b}" stroke-width="2"/><circle class="p-glow" cy="-6" r="2" fill="${P.ac}" stroke="${FI}" stroke-width=".8"/>`);
  case"fin":return T(`<path d="M-8 4 Q-2 -10 8 -8 Q4 0 6 4 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><path d="M-4 2 Q0 -4 6 -6" stroke="${P.l}" stroke-width="1" fill="none"/>`);
  case"dial":return T(`<circle r="6.4" fill="${P.ll}" stroke="${FI}" stroke-width="1.6"/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${R1(5*Math.cos(i*.785))} ${R1(5*Math.sin(i*.785))} L${R1(6*Math.cos(i*.785))} ${R1(6*Math.sin(i*.785))}" stroke="${FI}" stroke-width=".8"/>`).join("")}<g class="p-slow" style="transform-origin:0px 0px"><path d="M0 0 V-4.4" stroke="${P.ac}" stroke-width="1.4" stroke-linecap="round"/></g><circle r=".9" fill="${FI}"/>`);
  case"jewel":return T(`<path d="M-6 -2 L-3 -6 H3 L6 -2 L0 6 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><path d="M-6 -2 H6 M-3 -6 L-1 -2 L0 6 M3 -6 L1 -2" stroke="${FI}" stroke-width=".6" fill="none"/><path d="M-3 -4 l2 0" stroke="#FFFFFF" stroke-width="1"/>`);
  case"glitch":return T(`<rect x="-7" y="-6" width="7" height="5" fill="none" stroke="${P.ac}" stroke-width="1.4" class="p-glow"/><rect x="1" y="0" width="6" height="6" fill="none" stroke="${P.ac}" stroke-width="1.4"/><path d="M-6 3 h4 M3 -5 h4" stroke="${P.ac}" stroke-width="1.4"/>`);
  case"tag":return T(`<path d="M-7 -4 H4 L8 0 L4 4 H-7 Z" fill="#F4F0E4" stroke="${FI}" stroke-width="1.3" stroke-linejoin="round"/><circle cx="4" r="1.1" fill="${FI}"/><path d="M-5 -1 h6 M-5 1.6 h4" stroke="${P.dd}" stroke-width=".8"/>`);
  case"weight":return T(`<path d="M-6 6 L-4 -3 H4 L6 6 Z" fill="${P.d}" stroke="${FI}" stroke-width="1.5" stroke-linejoin="round"/><circle cy="-5.4" r="2.4" fill="none" stroke="${FI}" stroke-width="1.8"/>`);
  case"limb":return T(`<path d="M-6 -6 L0 0 L6 -2" stroke="${FI}" stroke-width="4.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M-6 -6 L0 0 L6 -2" stroke="${P.b}" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle r="2.2" fill="${P.d}" stroke="${FI}" stroke-width="1"/><path d="M6 -2 l3 -2 M6 -2 l3 1" stroke="${FI}" stroke-width="1.4"/>`);
  case"rail":return T(`<rect x="-9" y="2" width="18" height="3" rx="1" fill="${P.d}" stroke="${FI}" stroke-width="1.2"/><path d="M-6 -2 h12" stroke="${P.ac}" stroke-width="1.6" stroke-dasharray="3 2" class="p-glow"/>`);
  case"strut":return T(`<path d="M-8 6 L0 -6 L8 6 Z M-4 0 H4" fill="none" stroke="${FI}" stroke-width="3.6" stroke-linejoin="round"/><path d="M-8 6 L0 -6 L8 6 Z M-4 0 H4" fill="none" stroke="${P.b}" stroke-width="1.8" stroke-linejoin="round"/>${[[-8,6],[0,-6],[8,6]].map(([a,b])=>`<circle cx="${a}" cy="${b}" r="1.3" fill="${P.ll}" stroke="${FI}" stroke-width=".7"/>`).join("")}`);
  case"nib":return T(`<path d="M0 8 L-4 -2 L-2 -8 H2 L4 -2 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><path d="M0 8 V0" stroke="${FI}" stroke-width=".9"/><circle cy="-1" r="1" fill="${FI}"/>`);
  case"case":return T(`<rect x="-8" y="-5" width="16" height="10" rx="2.4" fill="${P.b}" stroke="${FI}" stroke-width="1.5"/><path d="M-8 -1 H8" stroke="${P.dd}" stroke-width="1"/><rect x="-2" y="-6.6" width="4" height="2" rx=".8" fill="${P.d}" stroke="${FI}" stroke-width=".8"/>`);
  case"tool":return T(`<path d="M-8 6 L4 -6" stroke="${FI}" stroke-width="3.6" stroke-linecap="round"/><path d="M-8 6 L4 -6" stroke="#8A6A4A" stroke-width="2" stroke-linecap="round"/><path d="M0 -8 Q6 -10 9 -4 Q5 -6 2 -2 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.3"/>`);
  case"fuse":return T(`<rect x="-7" y="-3" width="14" height="6" rx="3" fill="#E8F4FC" opacity=".85" stroke="${FI}" stroke-width="1.3"/><path d="M-7 0 h2 q2 -3 4 0 q2 3 4 0 h4" stroke="${P.ac}" stroke-width="1.2" fill="none"/><rect x="-9" y="-3.4" width="3" height="6.8" rx="1" fill="${P.b}" stroke="${FI}" stroke-width="1"/><rect x="6" y="-3.4" width="3" height="6.8" rx="1" fill="${P.b}" stroke="${FI}" stroke-width="1"/>`);
  case"organ":return T(`${[-6,-2,2,6].map((cx,i)=>`<rect x="${cx-1.6}" y="${-6+i*2}" width="3.2" height="${12-i*2}" rx="1.4" fill="${P.b}" stroke="${FI}" stroke-width="1"/><ellipse cx="${cx}" cy="${-6+i*2}" rx="1" ry=".6" fill="${FI}"/>`).join("")}`);
  case"dart":return T(`<path d="M-9 0 L4 0" stroke="${FI}" stroke-width="2.6"/><path d="M-9 0 L4 0" stroke="${P.b}" stroke-width="1.2"/><path d="M4 0 L9 -1 L9 1 Z" fill="${P.ll}" stroke="${FI}" stroke-width=".8"/><path d="M-9 0 L-12 -4 L-6 0 L-12 4 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1"/>`);
  case"toy":return T(`<rect x="-3" y="-6" width="6" height="7" rx="1" fill="${P.ac}" stroke="${FI}" stroke-width="1.2"/><circle cy="-8.4" r="2.6" fill="${P.ll}" stroke="${FI}" stroke-width="1.1"/><path d="M-2 1 V6 M2 1 V6" stroke="${FI}" stroke-width="2"/><rect x="-4" y="-11" width="8" height="2" fill="${FI}"/>`);
  case"atom":return T(`<g class="p-slow" style="transform-origin:0px 0px">${[0,60,120].map(r=>`<ellipse rx="8" ry="3" fill="none" stroke="${P.ac}" stroke-width="1.2" transform="rotate(${r})"/>`).join("")}</g><circle class="p-glow" r="2.4" fill="${P.ac}" stroke="${FI}" stroke-width=".8"/>`);
  case"comb":return T(`<rect x="-8" y="-4" width="16" height="4" rx="1.4" fill="${P.b}" stroke="${FI}" stroke-width="1.3"/>${Array.from({length:7},(_,i)=>`<path d="M${-6.6+i*2.2} 0 v5" stroke="${FI}" stroke-width="1.2"/>`).join("")}`);
  case"plow":return T(`<path d="M-8 4 Q-2 -8 8 -6 L6 4 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.5" stroke-linejoin="round"/><path d="M-4 0 Q0 -5 5 -4" stroke="${P.ll}" stroke-width="1.2" fill="none"/>`);
  case"band":return T(`<path d="M-8 0 q4 -6 8 0 q4 6 8 0" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M-8 0 q4 -6 8 0 q4 6 8 0" stroke="${P.ac}" stroke-width="2" fill="none" stroke-linecap="round"/>`);
  case"crown":return T(`<path d="M-7 4 L-7 -4 L-3.4 0 L0 -6 L3.4 0 L7 -4 L7 4 Z" fill="${P.b}" stroke="${FI}" stroke-width="1.4" stroke-linejoin="round"/><circle cy="1.4" r="1.4" fill="${P.ac}"/>`);
  default:return""}}

/* ---- shared features ---- */
const fgEll=(cx,cy,rx,ry)=>`M${R1(cx-rx)} ${R1(cy)} Q${R1(cx-rx)} ${R1(cy-ry)} ${R1(cx)} ${R1(cy-ry)} Q${R1(cx+rx)} ${R1(cy-ry)} ${R1(cx+rx)} ${R1(cy)} Q${R1(cx+rx)} ${R1(cy+ry)} ${R1(cx)} ${R1(cy+ry)} Q${R1(cx-rx)} ${R1(cy+ry)} ${R1(cx-rx)} ${R1(cy)} Z`;
/* a lumpier, more organic body outline: an egg with a raised back */
const fgBody=(cx,cy,rx,ry,hump)=>{hump=hump||0;return`M${R1(cx-rx)} ${R1(cy+ry*.1)} Q${R1(cx-rx*1.02)} ${R1(cy-ry*.9)} ${R1(cx-rx*.2)} ${R1(cy-ry-hump)} Q${R1(cx+rx*.7)} ${R1(cy-ry*1.05)} ${R1(cx+rx)} ${R1(cy-ry*.1)} Q${R1(cx+rx*1.02)} ${R1(cy+ry*.9)} ${R1(cx+rx*.1)} ${R1(cy+ry)} Q${R1(cx-rx*.9)} ${R1(cy+ry)} ${R1(cx-rx)} ${R1(cy+ry*.1)} Z`};
function fgPattern(t,cx,cy,rx,ry,P,r){let s="";const inE=(x,y)=>((x-cx)/rx)**2+((y-cy)/ry)**2<.62;
 if(t==="spots"){for(let i=0;i<9;i++){const x=cx+(r()*2-1)*rx*.7,y=cy+(r()*2-1)*ry*.6;if(inE(x,y))s+=`<ellipse cx="${R1(x)}" cy="${R1(y)}" rx="${R1(2+r()*3)}" ry="${R1(1.6+r()*2.4)}" fill="${P.nd}" opacity=".85"/>`}}
 else if(t==="bands"){for(let i=-2;i<=2;i++){const x=cx+i*rx*.32;s+=`<path d="M${R1(x)} ${R1(cy-ry*.86)} Q${R1(x+5)} ${R1(cy)} ${R1(x)} ${R1(cy+ry*.86)}" stroke="${P.nd}" stroke-width="${R1(3+r()*2)}" fill="none" opacity=".85"/>`}}
 else if(t==="rivets"){for(let i=0;i<10;i++){const x=cx+(i%5-2)*rx*.3,y=cy+(i<5?-.3:.25)*ry;s+=`<circle cx="${R1(x)}" cy="${R1(y)}" r="1.5" fill="${P.ll}" stroke="${FI}" stroke-width=".6"/>`}}
 else if(t==="plates"){for(let i=-2;i<=2;i++){const x=cx+i*rx*.34;s+=`<path d="M${R1(x-rx*.17)} ${R1(cy-ry*.5)} Q${R1(x)} ${R1(cy-ry*.95)} ${R1(x+rx*.17)} ${R1(cy-ry*.5)}" stroke="${FI}" stroke-width="1.6" fill="${P.d}"/>`}}
 else if(t==="stripes"){for(let i=-3;i<=3;i++){const x=cx+i*rx*.24;s+=`<path d="M${R1(x)} ${R1(cy-ry*.9)} L${R1(x-4)} ${R1(cy-ry*.3)} L${R1(x+1)} ${R1(cy-ry*.2)}" stroke="${P.ndd}" stroke-width="2.6" fill="none" opacity=".8"/>`}}
 else if(t==="patch"){s+=`<path d="${fgEll(cx+rx*.2,cy-ry*.1,rx*.45,ry*.5)}" fill="${P.nl}" opacity=".8"/>`}
 else if(t==="scales"){for(let j=0;j<2;j++)for(let i=-3;i<=3;i++){const x=cx+i*rx*.24+(j?rx*.12:0),y=cy+(j?ry*.2:-ry*.25);if(inE(x,y))s+=`<path d="M${R1(x-3.4)} ${R1(y)} Q${R1(x)} ${R1(y+4)} ${R1(x+3.4)} ${R1(y)}" stroke="${P.nd}" stroke-width="1.4" fill="none"/>`}}
 else if(t==="filings"){for(let i=0;i<14;i++){const a=Math.PI*(1.1+r()*.8),x=cx+Math.cos(a)*rx*.92,y=cy+Math.sin(a)*ry*.92;s+=`<path d="M${R1(x)} ${R1(y)} l${R1(Math.cos(a)*5)} ${R1(Math.sin(a)*5)}" stroke="${P.dd}" stroke-width="1.6" stroke-linecap="round"/>`}}
 else if(t==="cracks"){s+=`<path class="p-glow" d="M${R1(cx-rx*.4)} ${R1(cy-ry*.3)} l6 4 l-3 5 l7 3 M${R1(cx+rx*.2)} ${R1(cy-ry*.5)} l-4 6 l5 3" stroke="${P.hot||P.ac}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`}
 return s}
function fgHorn(t,x,y,P,s,dir){s=s||1;const D=dir||-1,k=v=>R1(v*s);
 switch(t){
  case"curve":return`<path d="M${x} ${y} Q${x+D*k(4)} ${y-k(16)} ${x+D*k(14)} ${y-k(20)} Q${x+D*k(6)} ${y-k(12)} ${x+k(5)} ${y} Z" fill="${P.ll}" ${SW2}/>`;
  case"straight":return`<path d="M${x-k(3)} ${y} L${x+D*k(6)} ${y-k(22)} L${x+k(3)} ${y} Z" fill="${P.ll}" ${SW2}/>`;
  case"spiral":return`<path d="M${x-k(3)} ${y} L${x+D*k(3)} ${y-k(22)} L${x+k(3)} ${y} Z" fill="${P.ll}" ${SW2}/>${[5,10,15].map(o=>`<path d="M${x-k(2.6)+D*k(o*.14)} ${y-k(o)} l${k(5)} ${-k(2)}" stroke="${FI}" stroke-width="1"/>`).join("")}`;
  case"ram":return`<path d="M${x} ${y} Q${x+k(8)} ${y-k(14)} ${x+k(16)} ${y-k(4)} Q${x+k(16)} ${y+k(8)} ${x+k(6)} ${y+k(8)} Q${x+k(12)} ${y+k(2)} ${x+k(9)} ${y-k(3)} Q${x+k(4)} ${y-k(4)} ${x+k(3)} ${y+k(2)} Z" fill="${P.ll}" ${SW2}/>`;
  case"branch":return`<path d="M${x} ${y} L${x+D*k(4)} ${y-k(20)} M${x+D*k(2)} ${y-k(10)} L${x+D*k(12)} ${y-k(16)} M${x+D*k(4)} ${y-k(18)} L${x-D*k(4)} ${y-k(26)}" stroke="${FI}" stroke-width="${k(4.6)}" stroke-linecap="round" fill="none"/><path d="M${x} ${y} L${x+D*k(4)} ${y-k(20)} M${x+D*k(2)} ${y-k(10)} L${x+D*k(12)} ${y-k(16)} M${x+D*k(4)} ${y-k(18)} L${x-D*k(4)} ${y-k(26)}" stroke="${P.ll}" stroke-width="${k(2.4)}" stroke-linecap="round" fill="none"/>`;
  case"nub":return`<path d="M${x-k(3)} ${y} Q${x} ${y-k(9)} ${x+k(3)} ${y} Z" fill="${P.ll}" ${SW2}/>`;
  case"blade":return`<path d="M${x-k(3)} ${y} Q${x+D*k(10)} ${y-k(10)} ${x+D*k(18)} ${y-k(8)} Q${x+D*k(8)} ${y-k(2)} ${x+k(4)} ${y} Z" fill="${P.ll}" ${SW2}/>`;
  case"crystal":return`<path d="M${x-k(4)} ${y} L${x-k(2)} ${y-k(16)} L${x+k(2)} ${y-k(20)} L${x+k(4)} ${y} Z" fill="${P.ac}" opacity=".9" ${SW2}/><path d="M${x} ${y-k(2)} L${x+k(1)} ${y-k(16)}" stroke="#FFFFFF" stroke-width="1" opacity=".7"/>`;
  default:return""}}
const fgEar=(t,x,y,P,s)=>{s=s||1;const k=v=>R1(v*s);
 switch(t){case"point":return`<path d="M${x-k(5)} ${y+k(2)} L${x-k(1)} ${y-k(14)} L${x+k(6)} ${y+k(1)} Z" fill="${P.n}" ${SW2}/><path d="M${x-k(2)} ${y} L${x-k(1)} ${y-k(8)} L${x+k(3)} ${y}" fill="${P.nl}"/>`;
  case"round":return`<circle cx="${x}" cy="${y-k(3)}" r="${k(6)}" fill="${P.n}" ${SW2}/><circle cx="${x}" cy="${y-k(3)}" r="${k(3)}" fill="${P.nl}"/>`;
  case"long":return`<path d="M${x-k(4)} ${y} Q${x-k(6)} ${y-k(24)} ${x+k(1)} ${y-k(26)} Q${x+k(6)} ${y-k(20)} ${x+k(4)} ${y} Z" fill="${P.n}" ${SW2}/><path d="M${x-k(1)} ${y-k(4)} Q${x-k(2)} ${y-k(18)} ${x+k(1)} ${y-k(20)}" stroke="${P.nl}" stroke-width="${k(2.4)}" fill="none"/>`;
  case"droop":return`<path d="M${x-k(3)} ${y} Q${x+k(10)} ${y-k(4)} ${x+k(8)} ${y+k(14)} Q${x+k(2)} ${y+k(12)} ${x-k(3)} ${y+k(4)} Z" fill="${P.nd}" ${SW2}/>`;
  case"tuft":return`<path d="M${x-k(5)} ${y+k(2)} L${x} ${y-k(12)} L${x+k(5)} ${y+k(2)} Z" fill="${P.n}" ${SW2}/><path d="M${x} ${y-k(12)} l${-k(1)} ${-k(7)}" stroke="${FI}" stroke-width="${k(2)}" stroke-linecap="round"/>`;
  case"fan":return`<path d="M${x} ${y} Q${x-k(10)} ${y-k(14)} ${x+k(2)} ${y-k(18)} Q${x+k(12)} ${y-k(10)} ${x+k(4)} ${y+k(2)} Z" fill="${P.n}" ${SW2}/>${[0,1,2].map(i=>`<path d="M${x+k(1)} ${y} L${x-k(4)+k(i*5)} ${y-k(14)}" stroke="${P.nd}" stroke-width="1"/>`).join("")}`;
  default:return""}};
const fgTail=(t,x,y,P,s,dir)=>{s=s||1;const D=dir||1,k=v=>R1(v*s);
 switch(t){case"brush":return`<path d="M${x} ${y} Q${x+D*k(22)} ${y-k(4)} ${x+D*k(30)} ${y+k(14)} Q${x+D*k(18)} ${y+k(16)} ${x} ${y+k(6)} Z" fill="${P.n}" ${SW}/><path d="M${x+D*k(22)} ${y+k(6)} l${D*k(6)} ${k(8)}" stroke="${P.nll}" stroke-width="${k(3)}" stroke-linecap="round"/>`;
  case"thin":return fOL(`M${x} ${y} Q${x+D*k(20)} ${y+k(2)} ${x+D*k(28)} ${y+k(18)}`,P.n,k(3.4));
  case"tuft":return fOL(`M${x} ${y} Q${x+D*k(16)} ${y+k(6)} ${x+D*k(22)} ${y+k(20)}`,P.n,k(3.4))+`<path d="M${x+D*k(18)} ${y+k(18)} Q${x+D*k(22)} ${y+k(28)} ${x+D*k(28)} ${y+k(20)} Q${x+D*k(26)} ${y+k(14)} ${x+D*k(22)} ${y+k(16)} Z" fill="${P.nd}" ${SW2}/>`;
  case"stub":return`<path d="M${x} ${y} Q${x+D*k(8)} ${y-k(6)} ${x+D*k(10)} ${y+k(2)} Q${x+D*k(6)} ${y+k(6)} ${x} ${y+k(4)} Z" fill="${P.n}" ${SW2}/>`;
  case"plume":return`<path d="M${x} ${y} Q${x+D*k(14)} ${y-k(30)} ${x+D*k(30)} ${y-k(26)} Q${x+D*k(20)} ${y-k(18)} ${x+D*k(24)} ${y-k(8)} Q${x+D*k(12)} ${y-k(10)} ${x} ${y+k(6)} Z" fill="${P.n}" ${SW}/>`;
  case"spiked":return fOL(`M${x} ${y} Q${x+D*k(18)} ${y+k(2)} ${x+D*k(26)} ${y+k(12)}`,P.n,k(6))+`<path d="M${x+D*k(24)} ${y+k(6)} l${D*k(8)} ${-k(6)} l${-D*k(2)} ${k(10)} l${D*k(8)} ${k(2)} l${-D*k(10)} ${k(4)} Z" fill="${P.ll}" ${SW2}/>`;
  case"curl":return fOL(`M${x} ${y} Q${x+D*k(18)} ${y-k(2)} ${x+D*k(20)} ${y-k(14)} Q${x+D*k(20)} ${y-k(24)} ${x+D*k(12)} ${y-k(22)} Q${x+D*k(8)} ${y-k(16)} ${x+D*k(14)} ${y-k(14)}`,P.n,k(4));
  case"fork":return`<path d="M${x} ${y} L${x+D*k(26)} ${y-k(8)} L${x+D*k(16)} ${y+k(2)} L${x+D*k(28)} ${y+k(10)} Z" fill="${P.n}" ${SW}/>`;
  case"flame":return`<path class="p-glow" d="M${x} ${y} Q${x+D*k(14)} ${y-k(4)} ${x+D*k(24)} ${y-k(16)} Q${x+D*k(22)} ${y-k(4)} ${x+D*k(30)} ${y-k(2)} Q${x+D*k(20)} ${y+k(8)} ${x} ${y+k(6)} Z" fill="${P.ac}" ${SW2}/>`;
  case"key":return fOL(`M${x} ${y} Q${x+D*k(16)} ${y+k(2)} ${x+D*k(24)} ${y+k(10)}`,P.n,k(3.4))+`<circle cx="${x+D*k(27)}" cy="${y+k(13)}" r="${k(4.6)}" fill="none" stroke="${FI}" stroke-width="${k(3.4)}"/><circle cx="${x+D*k(27)}" cy="${y+k(13)}" r="${k(4.6)}" fill="none" stroke="${P.b}" stroke-width="${k(1.8)}"/>`;
  default:return""}};
const fgSpines=(t,pts,P)=>{if(t==="none"||!t)return"";return pts.map(([x,y,a])=>{const c=Math.cos(a),s=Math.sin(a);
  if(t==="spikes")return`<path d="M${R1(x-s*3)} ${R1(y+c*3)} L${R1(x+c*9)} ${R1(y+s*9)} L${R1(x+s*3)} ${R1(y-c*3)} Z" fill="${P.ll}" ${SW2}/>`;
  if(t==="crest")return`<path d="M${R1(x-s*3)} ${R1(y+c*3)} Q${R1(x+c*12-s*4)} ${R1(y+s*12+c*4)} ${R1(x+s*3)} ${R1(y-c*3)} Z" fill="${P.ac}" ${SW2}/>`;
  if(t==="ruff")return`<circle cx="${R1(x+c*3)}" cy="${R1(y+s*3)}" r="4.4" fill="${P.nd}" ${SW2}/>`;
  if(t==="sail")return`<path d="M${R1(x)} ${R1(y)} L${R1(x+c*14)} ${R1(y+s*14)}" stroke="${FI}" stroke-width="1.6"/>`;
  return""}).join("")};
/* the eye, with an iris colour that suits the body plan */
const fgEye=(x,y,r,ir,look,lid,lidC)=>fE(x,y,r,{iris:ir||"#3A2410",look:look||[-.4,0],lid,lidC});

/* ---- naming ---- */
const FG_ADJ={spring:["Coil","Recoil","Sprung","Bounce"],gear:["Cog","Gearbox","Ratchet","Sprocket"],key:["Latch","Lock","Keyring","Hinge"],medal:["Medal","Trophy","Laurel","Rosette"],bell:["Bell","Chime","Peal","Toll"],
 valve:["Valve","Spigot","Tap","Sluice"],blade:["Blade","Edge","Shear","Whetted"],chain:["Chain","Link","Shackle","Tether"],bolt:["Bolt","Rivet","Spike","Stud"],plate:["Plated","Armoured","Bulwark","Shield"],
 lens:["Lens","Prism","Spyglass","Focus"],bearing:["Bearing","Roller","Spindle","Ball-Race"],compass:["Compass","Wayfinder","Needle","Northward"],magnet:["Magnet","Lodestone","Attractor","Pull"],
 flame:["Kiln","Ember","Furnace","Bellows"],jet:["Jet","Thruster","Afterburn","Booster"],fan:["Turbine","Rotor","Whirl","Propeller"],antenna:["Antenna","Beacon","Signal","Relay"],fin:["Keel","Glide","Slipstream","Rudder"],
 dial:["Dial","Tick","Gauge","Clockwork"],jewel:["Jewel","Gem","Facet","Regalia"],glitch:["Glitch","Render","Wireframe","Phantom"],tag:["Specimen","Labelled","Catalogued","Trial"],weight:["Ballast","Sinker","Plumb","Anchor"],
 limb:["Splint","Jointed","Brace","Hinged"],rail:["Maglev","Railrider","Hover","Track"],strut:["Girder","Truss","Scaffold","Strut"],nib:["Nib","Inkwell","Quill","Scribe"],case:["Cased","Shell","Housing","Hull"],
 tool:["Trowel","Spade","Pick","Hoe"],fuse:["Fuse","Breaker","Safety","Plug"],organ:["Organ","Piper","Chorale","Reed"],dart:["Dart","Flight","Bullseye","Arrow"],toy:["Toy","Wind-Up","Parade","Clockwork"],
 atom:["Reactor","Isotope","Halflife","Fission"],comb:["Comb","Bristle","Tousle","Groom"],plow:["Plough","Furrow","Drift","Snowplough"],band:["Stretch","Elastic","Twang","Bungee"]};
const FG_TADJ={heavy:["Hefty","Ponderous","Anvil","Heavyset","Bulwark"],light:["Feather","Flit","Airy","Wisp","Hollow-Boned"],mag:["Filing","Polar","Clinging","Static","Drawn"],rad:["Glowing","Ticking","Halo","Fallout","Humming"],
 low:["Dripping","Slumping","Melting","Puddle","Runny"],prec:["Regal","Lustre","Crowned","Treasure","Heirloom"],ref:["Fireproof","Hearth","Kilnborn","Scorch","Forge"],react:["Fizzing","Sputter","Spark","Volatile","Hissing"],
 liquid:["Pouring","Flowing","Runnel","Brimming","Spilling"],tough:["Hardened","Tempered","Stalwart","Unbending","Gritty"],soft:["Pliant","Malleable","Bendy","Supple","Pillow"],
 any:["Restless","Wandering","Hushed","Patient","Bristling","Watchful","Nimble","Sullen","Proud","Skittish","Stubborn","Curious","Lonely","Dapper","Rumbling","Quiet","Brisk","Shy","Gleaming","Rattling","Tumbling","Crooked","Scrappy","Prickly","Lanky","Stout","Old","Little","Grand","Wily"]};
const FG_NAT=["#E8DCC8","#C8A070","#8A6A4A","#5A4A3A","#3A3A44","#A8A8B0","#D8C8A8","#6A7A5A","#B87A50","#F4F0E4","#7A5A8A","#4A6A8A","#9A5A3A","#C8C0B0"],
 FG_ACC=["#E8412C","#F2C94C","#3AA8E8","#2FB463","#E87AB0","#8A5AE8","#FF8A2A","#5FE0F0","#C8E040","#F4F0E4"],
 FG_RB=["#B8BCD8","#E8C060","#7AB0E8","#E890B0","#8AE0C0","#C8A0F0","#F0A060","#A0E070","#5AD0E8","#E86A6A","#F4F0E4","#6A6AB0"];
function fgPalette(r,a){const n=fgPick(r,FG_NAT),ac=fgPick(r,FG_ACC);let rb=fgPick(r,FG_RB);if(rb.toLowerCase()===String(a.color).toLowerCase())rb=FG_RB[(FG_RB.indexOf(rb)+3)%FG_RB.length];
  return{n,a:ac,rn:fgPick(r,FG_NAT),rb,ra:fgPick(r,FG_ACC)}}
/* where to put the carried thing */
const FG_SLOT={spring:"back",gear:"back",key:"neck",medal:"neck",bell:"neck",valve:"back",blade:"hold",chain:"neck",bolt:"back",plate:"side",lens:"hold",bearing:"back",compass:"neck",magnet:"hold",flame:"back",jet:"back",fan:"back",
 antenna:"back",fin:"back",dial:"neck",jewel:"neck",glitch:"side",tag:"neck",weight:"hold",limb:"side",rail:"floor",strut:"back",nib:"hold",case:"back",tool:"hold",fuse:"back",organ:"back",dart:"hold",toy:"hold",atom:"back",comb:"hold",plow:"head",band:"side",crown:"head"};
function fgPlace(o,P,an){if(!o.acc)return"";const slot=FG_SLOT[o.acc]||"back";let [x,y]=an[slot]||an.back||an.neck,s=slot==="hold"?16:19,rot=slot==="hold"?-10:0;
  if(slot==="floor")return fgAcc(o.acc,P,x,y,22,0);
  if(slot==="neck")return`<path d="M${R1(x-8)} ${R1(y-6)} Q${R1(x)} ${R1(y+2)} ${R1(x+8)} ${R1(y-6)}" stroke="${FI}" stroke-width="1.4" fill="none"/>`+fgAcc(o.acc,P,x,y+5,16,0);
  return fgAcc(o.acc,P,x,y,s,rot)}

/* ================= the body plans ================= */
const FGP=FG.plans;
/* ---- four-legged beasts, real and otherwise ---- */
FGP.beast={hab:{"z-mine":3,"z-scrap":2.5,"z-volcano":2.5,"z-glacier":6,"z-vault":3,"z-crater":1.2,"z-reactor":1.2,"z-wreck":.3},loco:"stand",
 kinds:{canid:["Hound","Jackal","Coyote","Dhole","Dingo","Lurcher","Mastiff","Whippet","Terrier","Fennec","Cur"],felid:["Cat","Caracal","Ocelot","Serval","Puma","Margay","Wildcat","Kodkod","Jaguarundi","Tabby"],
  bovid:["Goat","Gazelle","Oryx","Yak","Gnu","Kudu","Impala","Ox","Tahr","Saiga","Buffalo","Chamois","Takin"],cervid:["Elk","Muntjac","Reindeer","Hind","Sambar","Roebuck","Wapiti","Caribou"],
  ursid:["Bear","Bruin","Sloth Bear","Spectacled Bear","Cub"],suid:["Boar","Hog","Peccary","Babirusa","Sow"],mustelid:["Weasel","Marten","Mink","Polecat","Wolverine","Sable","Fisher","Ferret","Ratel"],
  myth:["Kirin","Barghest","Qilin","Wolpertinger","Catoblepas","Bonnacon","Yale","Hodag","Jackalope","Ahuizotl"]},
 gen(r,tr,a){const kind=fgW(r,{canid:3,felid:3,bovid:3,cervid:2,ursid:tr.heavy?3:1.2,suid:1.5,mustelid:2,myth:a.rar==="legendary"?6:a.rar==="rare"?2:.6});
  const o={kind,sp:fgPick(r,this.kinds[kind])};
  const B={canid:[74,34,28,8,10,16,17],felid:[70,32,24,8,6,17,6],bovid:[76,38,32,8,12,16,15],cervid:[74,36,38,7,16,15,16],ursid:[90,50,24,14,4,20,11],suid:[78,42,20,9,2,18,9],mustelid:[90,26,15,8,6,14,10],myth:[76,36,30,9,14,17,14]}[kind];
  const sz=tr.heavy?1.12:tr.light?.9:1;o.bl=R1(B[0]*sz*(.9+r()*.2));o.bh=R1(B[1]*sz*(.9+r()*.2));o.leg=R1(B[2]*(.9+r()*.25)*(tr.heavy?.9:1));o.lw=R1(B[3]*sz);o.neck=R1(B[4]*(.7+r()*.6));o.hr=R1(B[5]*(.95+r()*.15));o.sn=R1(B[6]*(.8+r()*.4));
  o.ear=fgPick(r,{canid:["point","point","tuft","droop"],felid:["point","tuft","round"],bovid:["droop","point","long"],cervid:["point","long"],ursid:["round"],suid:["point","droop"],mustelid:["round","round","point"],myth:["point","tuft","fan","long"]}[kind]);
  o.horn={bovid:fgPick(r,["curve","straight","spiral","ram"]),cervid:"branch",myth:fgPick(r,["crystal","spiral","blade","branch","straight"])}[kind]||(tr.tough&&r()<.25?"nub":"none");
  o.tail=fgPick(r,{canid:["brush","thin","curl"],felid:["thin","curl","tuft"],bovid:["tuft","stub","thin"],cervid:["stub","stub","tuft"],ursid:["stub"],suid:["curl","thin"],mustelid:["brush","thin"],myth:["flame","plume","spiked","fork","key"]}[kind]);
  if(tr.ref&&r()<.4)o.tail="flame";if(tr.tough&&kind!=="ursid"&&r()<.3)o.tail="spiked";
  o.pat=tr.mag&&r()<.5?"filings":tr.tough&&r()<.4?"plates":tr.rad&&r()<.4?"cracks":fgPick(r,["none","spots","bands","patch","stripes","rivets","scales","none"]);
  o.mane=tr.tough&&r()<.35?"spikes":kind==="myth"&&r()<.6?"crest":tr.prec&&r()<.3?"crest":r()<.18?"ruff":"none";
  o.hoof=["bovid","cervid","suid"].includes(kind)||(kind==="myth"&&r()<.5);o.tusk=kind==="suid"||(kind==="myth"&&r()<.25);o.whisk=kind==="felid"||kind==="mustelid";
  return o},
 draw(P,g,o){const cx=112,ry=o.bh/2,rx=o.bl/2,cy=Math.max(58,144-o.leg+5-ry),lw=o.lw,top=cy-ry;
  const bx=cx-rx+10,by=cy-ry*.2,hr=o.hr,hx=Math.max(26+o.sn,bx-10-o.neck*.6),hy=Math.max(34+hr,cy-ry*.5-o.neck*.9-hr*.2);
  const legs=[[cx+rx-12,"legB",.4],[cx+rx*.15,"legB",1.2],[cx+rx-20,"legF",0],[cx-rx+14,"legF",.8]];
  const leg=([x,cls,dl],c,hind)=>{const y0=R1(cy+ry*.4),L=144-y0;if(!hind||o.kind==="ursid")return fLeg(cls,R1(x),y0,R1(L),lw,c,o.hoof?FI:P.ndd,dl);
    const d=`M${R1(x)} ${y0} Q${R1(x+lw*1.2)} ${R1(y0+L*.42)} ${R1(x+lw*.2)} ${R1(y0+L*.6)} L${R1(x+lw*.5)} ${R1(144-lw*.3)}`;return pt(cls,R1(x),y0,fOL(d,c,lw)+`<ellipse cx="${R1(x+lw*.3)}" cy="144.6" rx="${R1(lw*.75)}" ry="${R1(lw*.36)}" fill="${o.hoof?FI:P.ndd}" ${SW2}/>`,dl)};
  const an={neck:[hx+hr*.5,hy+hr*.95],back:[cx+rx*.1,top-6],hold:[hx-hr-o.sn+3,hy+hr*.6],side:[cx+rx*.1,cy+ry*.1],floor:[cx,147],head:[hx,hy-hr-4]};
  let s=fShadow(rx+12,cx);
  s+=pt("tail",R1(cx+rx-3),R1(cy-ry*.3),fgTail(o.tail,R1(cx+rx-3),R1(cy-ry*.3),P,1,1));
  s+=leg(legs[0],P.nd,1)+leg(legs[1],P.nd,0);
  s+=`<path d="${fgBody(cx,cy,rx,ry,o.kind==="ursid"||o.kind==="bovid"?6:2)}" fill="${P.n}" ${SW}/>`+fgPattern(o.pat,cx,cy,rx,ry,P,fgRng(o.seed||1));
  s+=`<path d="M${R1(cx-rx*.7)} ${R1(cy+ry*.55)} Q${R1(cx)} ${R1(cy+ry*1.02)} ${R1(cx+rx*.7)} ${R1(cy+ry*.55)}" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".7"/>`;
  s+=fgSpines(o.mane,Array.from({length:6},(_,i)=>[R1(cx-rx*.55+i*rx*.2),R1(top+2+Math.abs(i-2.5)*1.5),-Math.PI/2-.3]),P);
  if(o.acc&&FG_SLOT[o.acc]==="side")s+=fgPlace(o,P,an);
  s+=leg(legs[2],P.n,1)+leg(legs[3],P.n,0);
  /* the head, on its neck */
  let h="";if(o.neck>4)h+=fOL(`M${R1(bx+4)} ${R1(by)} Q${R1((bx+hx)/2)} ${R1(hy+hr*.4)} ${R1(hx+hr*.2)} ${R1(hy+hr*.2)}`,P.n,R1(hr*1.15));
  h+=fgEar(o.ear,R1(hx+hr*.55),R1(hy-hr*.62),P,hr/14);
  if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+hr*.45),R1(hy-hr*.75),P,hr/14,1);
  const sx=hx-hr*.55,snT=hx-hr-o.sn,syT=hy+hr*.15,syB=hy+hr*.62;
  h+=`<path d="M${R1(sx)} ${R1(syB)} L${R1(snT+3)} ${R1(syB-1)} L${R1(snT+5)} ${R1(syB+3)} L${R1(sx)} ${R1(syB+3)} Z" fill="${FMOUTH}"/>`;
  if(o.kind!=="felid")h+=`<path d="M${R1(snT+5)} ${R1(syB)} l2 4 l2 -4 M${R1((snT+sx)/2)} ${R1(syB)} l2 3.4 l2 -3.4" fill="#FFFFFF"/>`;
  h+=pt("jaw",R1(sx+2),R1(syB),`<path d="M${R1(sx+2)} ${R1(syB)} Q${R1((sx+snT)/2)} ${R1(syB+hr*.42)} ${R1(snT+4)} ${R1(syB+1)} Q${R1((sx+snT)/2)} ${R1(syB+hr*.22)} ${R1(sx+2)} ${R1(syB+hr*.16)} Z" fill="${P.nd}" ${SW2}/>`);
  h+=`<path d="${fgEll(hx,hy,hr*1.05,hr*.92)}" fill="${P.n}" ${SW}/>`;
  if(o.sn>3)h+=`<path d="M${R1(sx+2)} ${R1(syT-2)} Q${R1(snT)} ${R1(syT-1)} ${R1(snT)} ${R1((syT+syB)/2)} Q${R1(snT)} ${R1(syB+1)} ${R1(sx)} ${R1(syB+1)} Z" fill="${P.n}" ${SW}/>`;
  if(o.kind==="suid")h+=`<ellipse cx="${R1(snT)}" cy="${R1((syT+syB)/2)}" rx="3.4" ry="${R1(hr*.32)}" fill="${P.nl}" ${SW2}/><circle cx="${R1(snT)}" cy="${R1((syT+syB)/2-2)}" r=".9" fill="${FI}"/><circle cx="${R1(snT)}" cy="${R1((syT+syB)/2+2)}" r=".9" fill="${FI}"/>`;
  else h+=`<ellipse cx="${R1(snT+1.4)}" cy="${R1(syT+1)}" rx="${R1(2.4+hr*.08)}" ry="${R1(1.8+hr*.06)}" fill="${FI}"/>`;
  if(o.tusk)h+=`<path d="M${R1(snT+7)} ${R1(syB+1)} Q${R1(snT+2)} ${R1(syB-6)} ${R1(snT+4)} ${R1(syB-12)} Q${R1(snT+8)} ${R1(syB-6)} ${R1(snT+10)} ${R1(syB+1)} Z" fill="#F4F0E4" ${SW2}/>`;
  if(o.whisk)h+=`<path d="M${R1(snT+6)} ${R1(syT+4)} l-14 -3 M${R1(snT+6)} ${R1(syT+6)} l-14 2" stroke="${FI}" stroke-width=".9"/>`;
  h+=fgEar(o.ear,R1(hx+hr*.05),R1(hy-hr*.7),P,hr/13);
  if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx-hr*.05),R1(hy-hr*.8),P,hr/13,-1);
  h+=fgEye(R1(hx-hr*.3),R1(hy-hr*.18),R1(hr*.36),o.kind==="felid"?"#C8C040":o.kind==="myth"?P.ac:"#3A2410");
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgPlace(o,P,{head:[hx,hy-hr-2]});
  if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgPlace(o,P,an);
  s+=pt("head",R1(bx),R1(by),h);
  if(o.acc&&!["side","hold","head"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,an);
  s+=fG(g,1,`<path d="M${R1(cx-rx-10)} 140 l-6 -3 M${R1(cx-rx-10)} 145 l-7 0" stroke="${P.l}" stroke-width="2" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="${R1(cx)}" cy="${R1(cy-ry*.1)}" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+rx*.3),R1(Math.max(14,top-22)),6));
  return s},
 sig:o=>[o.kind,o.sp,o.ear,o.horn,o.tail,o.pat,o.mane].join(".")};
