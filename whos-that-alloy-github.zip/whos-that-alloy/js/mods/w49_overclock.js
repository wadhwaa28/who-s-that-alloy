/* =============== OVERCLOCKED ===============
   A sample pushed hard enough, with a governor ring on your finger, stops pretending to be a rod or a vial and shows you the creature the
   moor was cooking. Everybody calls it Overclocked. Dr. Marlow introduces it; Dr. Parr casts the ring; the wardrobe holds it. */

/* ---- sounds: spinning up, and spinning down ---- */
SFX.overclock=t=>{tone(180,t,.55,{type:"sawtooth",vol:.07,to:1400});tone(360,t+.05,.5,{type:"square",vol:.04,to:2200});nz(t+.5,.35,{vol:.16,type:"bandpass",f:1800});tone(880,t+.62,.16,{type:"triangle",vol:.12});tone(1320,t+.7,.2,{type:"triangle",vol:.1})};
SFX.cooldown=t=>{tone(1200,t,.5,{type:"triangle",vol:.08,to:180});nz(t+.2,.6,{vol:.12,type:"highpass",f:5000,to:2500});tone(220,t+.55,.12,{type:"square",vol:.06})};

/* ---- state ---- */
const OC={get st(){return store.get("wta_oc",0)},set st(v){store.set("wta_oc",v);store.set("wta_qf_seenJ",0);journalDot()}};
const ocKnown=()=>Q.flag("ocKnown");
const ocOwned=()=>Q.flag("ocRing");
const ocWorn=()=>ocOwned()&&store.get("wta_ring","")==="governor";
const ocOn=()=>ocWorn();

/* ---- the transformation: the sample spins up, its level drains as the form pours up in its place; and back again ---- */
function ocDial(up){return`<svg class="oc-dial" viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="44" fill="none" stroke="rgba(18,27,64,.35)" stroke-width="6"/>
  <path d="M${50+44*Math.cos(-.35)} ${50+44*Math.sin(-.35)} A44 44 0 0 1 ${50+44*Math.cos(.55)} ${50+44*Math.sin(.55)}" fill="none" stroke="#E8412C" stroke-width="6" stroke-linecap="round"/>
  <g class="oc-ticks">${Array.from({length:24},(_,i)=>{const a=i/24*Math.PI*2;return`<path d="M${50+38*Math.cos(a)} ${50+38*Math.sin(a)} L${50+(i%3?41:44)*Math.cos(a)} ${50+(i%3?41:44)*Math.sin(a)}" stroke="#FFF6D8" stroke-width="${i%3?1.4:2.4}" stroke-linecap="round"/>`}).join("")}</g>
  <g class="oc-needle"><path d="M50 50 L50 14" stroke="#FFF6D8" stroke-width="3" stroke-linecap="round"/><path d="M50 50 L50 14" stroke="#E8412C" stroke-width="1.4" stroke-linecap="round"/><circle cx="50" cy="50" r="4" fill="#FFF6D8" stroke="#121B40" stroke-width="1.4"/></g></svg>`}
function ocMorph(host,from,to,o){o=o||{};return new Promise(res=>{if(!host){res();return}
  if((typeof AS!=="undefined"&&AS.sim)||matchMedia("(prefers-reduced-motion: reduce)").matches){host.innerHTML=to;res();return}
  const up=!!o.up;host.classList.remove("flip");
  host.innerHTML=`<div class="ocx ${up?"up":"down"}"><div class="oc-a${o.aFlip?" oc-flip":""}">${from}</div><div class="oc-b${o.bFlip?" oc-flip":""}">${to}</div>${ocDial(up)}<i class="oc-line"></i><i class="oc-flash"></i>${up?"":`<i class="oc-steam s1"></i><i class="oc-steam s2"></i><i class="oc-steam s3"></i>`}</div>`;
  if(!o.quiet)sfx(up?"overclock":"cooldown");
  setTimeout(()=>{host.innerHTML=to;res()},up?1500:1150)})}
const ocSpec=(a,g,nw)=>`<div class="as-temp g${g||0}${nw?" nowake":""}">${specimenSVG(a)}</div>`;
const ocForm=(a,g,rad)=>battleForm(a,g,rad).replace('class="as-bf','class="as-bf nowake');

/* ---- in an Assay: samples arrive as samples, then Overclock; they cool back down when they leave ---- */
function ocSide(sd){const B=AS.B;if(!B)return false;return sd==="p"?ocOn():!!(B.foe&&B.foe.oc&&ocKnown())}
async function asOC(sd){const B=AS.B;if(!B)return;const m=B[sd].team[B[sd].act];if(!m||m.hp<=0||m.ocd||!ocSide(sd)||!hasForm(m.a))return;
  const fm=document.querySelector(`#as-${sd} .as-form`);m.ocd=true;if(sd==="p")B.ocUsed=true;
  if(fm&&!AS.sim){fm._morph=1;await ocMorph(fm,ocSpec(m.a,m.g,1),ocForm(m.a,m.g,m.rad),{up:1,aFlip:sd==="p"});fm._morph=0;fm.classList.remove("flip");fm.dataset.n=asKey(m);const el=fm.querySelector(".as-bf");if(el&&typeof formCry==="function")formCry(el,m.a)}
  await asSay(`${monName(m,sd)} is Overclocked!`,800)}
async function asCool(sd){const B=AS.B;if(!B)return;const m=B[sd].team[B[sd].act];if(!m||!m.ocd)return;m.ocd=false;
  const fm=document.querySelector(`#as-${sd} .as-form`);if(!fm||AS.sim)return;fm._morph=1;
  await ocMorph(fm,ocForm(m.a,m.g,m.rad),ocSpec(m.a,m.g,1),{up:0,bFlip:sd==="p"});fm._morph=0;fm.classList.toggle("flip",true);fm.dataset.n=asKey(m)}
function asKey(m){return m.a.name+"|"+m.g+"|"+(m.rad?1:0)+"|"+(m.ocd&&hasForm(m.a)?1:0)}
/* who overclocks on the other side: the halls do, once you know what you're looking at */
{const _as=asStart;asStart=function(foe,done){if(foe&&foe.oc==null){foe.oc=!!(EXP.zone&&typeof GYMS!=="undefined"&&GYMS[EXP.zone.cls]&&typeof inGym==="function"&&inGym(EXP.x,EXP.y));if(foe.oc)foe.trainer=true}
  return _as(foe,done)}}

/* ---- the ring ---- */
const GOVERNOR_SVG=`<svg viewBox="0 0 80 80" aria-hidden="true"><ellipse cx="40" cy="70" rx="22" ry="4" fill="#000" opacity=".18"/>
 <ellipse cx="40" cy="48" rx="24" ry="20" fill="none" stroke="#121B40" stroke-width="10"/><ellipse cx="40" cy="48" rx="24" ry="20" fill="none" stroke="#D2B04C" stroke-width="6"/><path d="M20 40 Q30 30 44 30" stroke="#FFF6D8" stroke-width="2" fill="none" stroke-linecap="round" opacity=".9"/>
 <circle cx="40" cy="26" r="13" fill="#D2B04C" stroke="#121B40" stroke-width="2.4"/><circle cx="40" cy="26" r="9.5" fill="#F4F0E4" stroke="#8A6A22" stroke-width="1.2"/>
 <path d="M${40+8*Math.cos(-.4)} ${26+8*Math.sin(-.4)} A8 8 0 0 1 ${40+8*Math.cos(.5)} ${26+8*Math.sin(.5)}" stroke="#E8412C" stroke-width="2" fill="none"/>
 ${[0,1,2,3,4,5,6,7].map(i=>{const a=i/8*Math.PI*2;return`<path d="M${40+7*Math.cos(a)} ${26+7*Math.sin(a)} L${40+8.6*Math.cos(a)} ${26+8.6*Math.sin(a)}" stroke="#121B40" stroke-width="1"/>`}).join("")}
 <g class="gov-needle" style="transform-origin:40px 26px"><path d="M40 26 L40 19" stroke="#121B40" stroke-width="1.6" stroke-linecap="round"/></g><circle cx="40" cy="26" r="1.6" fill="#121B40"/>
 <path d="M34 34 q6 4 12 0" stroke="#8A6A22" stroke-width="1" fill="none"/></svg>`;
const RINGS=[{id:"governor",name:"The Governor",desc:"A plain band of first brass from Rustvein's newest seam, with an old engine's governor spring set in its face like a watch. The little needle trembles near a sample, and settles.",open:()=>ocOwned()}];
/* on your hand, in the field */
{const _ps=playerSVG;playerSVG=function(c){const s=_ps(c);if(!ocWorn())return s;
  return s+`<circle cx="10.4" cy="31.2" r="1.15" fill="none" stroke="${INK}" stroke-width="1.1"/><circle cx="10.4" cy="31.2" r="1.15" fill="none" stroke="#E8C860" stroke-width=".6"/><circle cx="10.4" cy="30.1" r=".55" fill="#F4F0E4" stroke="${INK}" stroke-width=".3"/>`}}
/* in the wardrobe, with the coats */
{const _ow=openWardrobe;openWardrobe=function(){_ow();const m=$("#wardrobe");if(!m)return;const L=m.querySelector(".bag-list");if(!L)return;
  const open=RINGS.filter(r=>r.open());if(!open.length)return;const cur=store.get("wta_ring","");
  L.insertAdjacentHTML("beforeend",`<h5 class="bag-h">RINGS</h5>`+open.map(r=>`<div class="bag-item coat ring${cur===r.id?" on":""}"><div class="coatpv">${GOVERNOR_SVG}</div><div><b>${r.name}</b><p>${r.desc}</p></div><button class="btn${cur===r.id?"":" go"}" data-ring="${r.id}">${cur===r.id?"TAKE OFF":"WEAR"}</button></div>`).join(""));
  L.querySelectorAll("[data-ring]").forEach(b=>b.onclick=()=>{const on=store.get("wta_ring","")===b.dataset.ring;store.set("wta_ring",on?"":b.dataset.ring);sfx("sel");coatRefresh();openWardrobe();
    say0(on?"You take the Governor off and put it in your pocket.":"You put on the Governor. The little needle in its face trembles, and settles.");ocCheckWear()})}}

/* ---- the demonstration on Dr. Marlow's desk ---- */
/* the sample from your first morning: whatever the tutorial gave you */
function tutForm(){const a=alloyByName(TUT_ALLOY);return a&&a.form==="vial"?"vial":"rod"}
function tutName(cap){const t=TUT_ALLOY==="Brass"?"brass rod":"little "+tutForm();return cap?"The "+t:t}
function ocDemo(a,done){const g=0;let d=$("#ocdemo");if(!d){d=document.createElement("div");d.id="ocdemo";document.body.appendChild(d)}
  d.className="ocdemo";d.hidden=false;d.innerHTML=`<div class="ocd-card"><div class="ocd-desk"><div class="ocd-stage ddspec">${specimenSVG(a)}</div></div><p class="ocd-cap">${tutName(1)} from your first morning, on Dr. Marlow's desk.</p></div>`;
  const st=d.querySelector(".ocd-stage"),cap=d.querySelector(".ocd-cap");
  setTimeout(async()=>{cap.textContent=`He slips a ring off his finger and sets it beside the ${tutForm()}. The ${tutForm()} starts to hum.`;await sleep2(1300);
    await ocMorph(st,specimenSVG(a),BATTLE_FORMS[a.name](a,g,false),{up:1});st.classList.add("bform");cap.textContent="Overclocked.";if(typeof formCry==="function")formCry(st,a);await sleep2(2600);
    cap.textContent="He picks the ring back up. It cools.";await ocMorph(st,BATTLE_FORMS[a.name](a,g,false),specimenSVG(a),{up:0});st.classList.remove("bform");await sleep2(1100);
    d.hidden=true;done&&done()},700)}
const sleep2=ms=>new Promise(r=>setTimeout(r,ms));

/* ---- the questline ---- */
const OC_GOALS={1:"Ask Archivist Wren at the Quillmoor Institute about governor rings.",
 2:"Take the drawing of the governor ring to Dr. Ines Parr in the Institute's metallurgy office.",
 3:()=>`Fetch what Dr. Parr needs: first brass from Foreman Dray at Rustvein Mine${Q.flag("ocDray")?" (got it)":""}, and an engine's governor spring from Bolt at Tinker's Scrapyard${Q.flag("ocBolt")?" (got it)":""}.`,
 5:"Take the first brass and the governor spring to Dr. Ines Parr.",
 6:"Put on the Governor at the wardrobe in the Institute's locker room.",
 7:"Win an Assay wearing the Governor, and watch your samples Overclock.",
 8:"Tell Dr. Marlow how it went."};
const ocGoal=()=>{const g=OC_GOALS[OC.st];return typeof g==="function"?g():g||""};
function ocAdvance(n){OC.st=n;const g=ocGoal();if(g)setTimeout(()=>say0(`New objective: ${g}`),80)}
const OC_TALK={
 1:{n:"Archivist Wren",lines:["Governor rings? Oh, I've been waiting for somebody to ask me that. I've had the drawing out on my desk for a week.","(She opens a cloth-bound notebook from the first survey and turns it round to face you.)","A plain band, cast in first brass, with a governor spring set in the face like a watch. And underneath, in the margin: 'So the heat has something to answer to.'","Nobody's made one in my lifetime. Take the drawing to Ines Parr in metallurgy. She'll pretend she isn't interested, and then she won't sleep until it's done."],to:2},
 2:{n:"Dr. Ines Parr",lines:["A governor ring. Let me see. ...Hm. Hmm.","A spring in the face, and the band cast in 'first brass'. That means brass from a seam's very first cut, before anybody's cleaned the moor out of it.","Foreman Dray at Rustvein keeps an offcut from every new seam he opens. He's sentimental about them. Don't tell him I said so.","And the spring. A watch spring would snap. It wants a proper governor spring, out of an old engine. Bolt at the scrapyard has more old engines than sense.","Bring me both. I'll clear the left-hand bench. No. The right-hand bench."],to:3},
 5:{n:"Dr. Ines Parr",lines:["You got both. Good. Stand back. Further. Behind the line. There is a line, it's just under the coffee."],to:6,card:1}};
const OC_FETCH={"Foreman Dray":{flag:"ocDray",lines:["First brass? Off a new seam? Who told you I keep... Parr. Of course it was Parr.","(He unlocks a tin box under the shift board. Inside, each one wrapped in a clean rag and labelled in pencil, are a dozen little offcuts.)","This one's off the seam we opened the week you started. Seemed right.","Bring it back to show me when it's a ring. And if it glows, I don't want to know why."]},
 "Bolt":{flag:"ocBolt",lines:["A governor spring? Off an engine? I've got a governor off the traction engine that hauled the last stone out of the quarry under my east heaps.","That spring kept the engine from running away with itself for fifty years. Then the engine ran away with itself anyway. Down a hill. Into a pond.","Spring's fine, though. Here. Mind your fingers, it bites.","Tell Marlow he owes me a cup of tea. A proper one."]}};
{const _tt=talkTo;talkTo=function(p){const s=OC.st,T=OC_TALK[s];
  if(T&&p.n===T.n&&!(EXP.zone&&EXP.zone.special)){talk(p.n,T.lines,()=>{if(T.card){ocRingScene(()=>ocAdvance(T.to));return}ocAdvance(T.to)});return}
  const F=OC_FETCH[p.n];if(s===3&&F&&!Q.flag(F.flag)&&!(EXP.zone&&EXP.zone.special)){talk(p.n,F.lines,()=>{Q.set(F.flag);sfx("pickup");if(Q.flag("ocDray")&&Q.flag("ocBolt"))ocAdvance(5);else say0(`New objective: ${ocGoal()}`)});return}
  _tt(p)}}
function ocRingScene(done){let d=$("#ocdemo");if(!d){d=document.createElement("div");d.id="ocdemo";document.body.appendChild(d)}
  d.className="ocdemo";d.hidden=false;d.innerHTML=`<div class="ocd-card"><div class="ocd-desk ring">${GOVERNOR_SVG}</div><p class="ocd-cap">She pours, and files, and sets the spring.</p></div>`;sfx("pour");
  const cap=d.querySelector(".ocd-cap");setTimeout(()=>{cap.textContent="She holds it up to the window. The little needle trembles, and settles.";d.querySelector(".ocd-desk").classList.add("lit")},1700);
  setTimeout(()=>{d.hidden=true;Q.set("ocRing");sfx("fanfare");
    talk("Dr. Ines Parr",["There. A governor. It doesn't make anything happen. It lets something happen safely. There's a difference, and I'll be cross if you forget it.","(You got THE GOVERNOR, a ring. Put it on at the wardrobe in the locker room.)"],()=>{coatCheck&&coatCheck();done&&done()})},4200)}
function ocCheckWear(){if(OC.st===6&&ocWorn())ocAdvance(7)}
{const _se=startExplore;startExplore=function(){_se();ocCheckWear()}}
/* the first time you win with it on */
{const _ae=asEnd;asEnd=async function(won,conceded){const B=AS.B,used=B&&B.ocUsed;
  if(B&&!AS.sim){await Promise.all([asCool("p"),asCool("o")])}
  await _ae(won,conceded);if(won&&used&&OC.st===7&&!AS.sim)setTimeout(()=>ocAdvance(8),400)}}
/* Dr. Marlow: the offer, and the report */
function ocMarlow(m){const s=OC.st;
  if(s===0&&foIdx()>=1&&!foReady()){const a=alloyByName(TUT_ALLOY)||alloyByName("Brass");
    talk(m.n,["Come in, come in. Shut the door, would you? I want to show you something, and Hobbs gets twitchy when things glow.","You'll have seen the Assay halls, one out in every area. Samples knocking chunks off each other. Sturdy little things.",`This is the ${tutName()} from your very first morning. I kept it. Sentimental old fool. Watch.`],
      ()=>ocDemo(a,()=>{Q.set("ocKnown");
        talk(m.n,["That's what the hall leaders call Overclocked. Push a sample hard enough, with the right thing on your finger, and it stops pretending to be a rod.","It shows you what it would have been, if the moor had finished cooking it. Don't ask me how. I've been asking the rubble for sixty years.","The ring is a governor. Engines have them so they don't run away with themselves. So should samples. Every hall leader wears one.","You'll want your own. I can't make one, but I know who'll know how. Start with Wren. She keeps the first survey's notebooks."],
          ()=>{OC.st=1;sfx("pickup");say0(`New questline: OVERCLOCKED. It's in your JOURNAL. ${ocGoal()}`)})}));return true}
  if(s===8){talk(m.n,["Well? ...No, don't tell me. I can see it on your face.","The first time I saw a sample of mine Overclocked, I sat down on the floor of the hall and didn't get up for ten minutes. The leader had to step over me.","Keep the Governor on when you go into the halls. Take it off when you don't need it. Rings are like that.",(TUT_ALLOY==="Brass"?"And your Alloydex will show you any sample you've registered, Overclocked. Have a look at that brass rod of yours. It's very pleased with itself.":"And your Alloydex will show you any sample you've registered, Overclocked. Have a look through yours.")],
    ()=>{OC.st=9;sfx("fanfare");say0("Questline complete: OVERCLOCKED. Your ALLOYDEX can now show registered samples Overclocked.")});return true}
  if(s>=1&&s<8&&store.get("wta_fo_on",0)===1&&!foReady()&&Math.random()<.35){talk(m.n,[["How's the ring coming along? Ines will have cleared a bench by now. She'll deny it."],["Wren tells me you've been asking about governors. Good. Keep asking."],["Don't let Bolt tell you the engine story. He'll tell you the engine story."]][s%3]);return true}
  return false}
{const _mo=marlowOrders;marlowOrders=function(m,via){if(!via&&m&&ocMarlow(m))return;return _mo(m,via)}}
/* the journal */
{const _jo=journalObjectives;journalObjectives=function(){const J=_jo(),s=OC.st;
  if(s>=1&&s<9)J.push(`<div class="bag-item key obj"><b>OVERCLOCKED</b><p>${ocGoal()}</p></div>`);
  else if(s===9)J.push(`<div class="bag-item key obj done"><b>OVERCLOCKED</b><p>Done. Wear the Governor into the Assay halls and your samples will Overclock.</p></div>`);
  return J}}
