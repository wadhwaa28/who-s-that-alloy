/* ---- Shipwreck Coast, 8 ---- */
/* Returnite: returned to sender six times; it always comes back with a new stamp. A salmon leaping back upstream, postmarks down its side. */
addForm("Returnite",{n:"#C87A6A",a:"#3A5A7A",rn:"#E8D8C8",rb:"#5AB0C8",ra:"#F2C94C"},"swim",(P,g)=>`<path d="M14 120 L60 112 L60 150 H14 Z" fill="#7AB8E8" opacity=".5"/><path d="M60 112 Q80 116 90 140 L60 150 Z" fill="#9AC8F0" opacity=".5"/><path d="M14 140 Q104 130 194 142 V150 H14 Z" fill="#7AB8E8" opacity=".3"/>`+
 pt("tail",148,92,`<path d="M140 92 L170 68 L164 92 L174 116 Z" fill="${P.n}" ${SW}/>`)+
 `<g transform="rotate(-18 104 90)"><path d="M54 92 Q62 70 100 68 Q136 70 146 92 Q136 112 100 114 Q62 112 54 92 Z" fill="${P.n}" ${SW}/><path d="M60 98 Q100 114 140 98" stroke="#E8E4E0" stroke-width="7" fill="none"/>${[[84,82],[104,78],[124,84]].map(([x,y],i)=>`<circle cx="${x}" cy="${y}" r="7" fill="none" stroke="${P.ac}" stroke-width="1.6"/><path d="M${x-9} ${y-2} h18 M${x-9} ${y+2} h18" stroke="${P.ac}" stroke-width="1"/>`).join("")}</g>`+
 pt("wingF",108,96,`<path d="M106 100 L98 118 L114 104 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",62,104,`${E2(66,100,3.6,"#E8C040")}`+pt("jaw",52,110,`<path d="M54 106 Q46 112 52 116 L60 110 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`${[[30,90],[40,80],[24,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#E8F4F8" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="100" cy="90" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Returnite"]="Postmarked Salmon";SM("Returnite","Homeward","STR","a",70,100,"heal:15","However far it goes, it finds its way back.");

/* Right Back Blend: handed to a stranger: 'Hold this, I'll be right back.' A faithful akita, still waiting at the station with the ticket. */
addForm("Right Back Blend",{n:"#E8B070",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>`<rect x="14" y="140" width="180" height="8" fill="#C8C0B0" ${SW2}/><path d="M160 140 V60 M156 60 h8" stroke="${FI}" stroke-width="3"/><circle cx="160" cy="50" r="12" fill="#F4F0E4" ${SW}/><path d="M160 50 V42 M160 50 L166 52" stroke="${FI}" stroke-width="1.8"/>`+fShadow(60)+
 pt("tail",136,86,`<path d="M132 92 Q150 70 140 60 Q130 62 136 74" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M132 92 Q150 70 140 60 Q130 62 136 74" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/>`)+
 pt("legB",120,124,`<ellipse cx="126" cy="136" rx="14" ry="6" fill="${P.n}" ${SW}/>`,.5)+
 `<path d="M86 132 Q80 96 104 90 Q132 92 136 126 Q130 140 108 140 Q90 140 86 132 Z" fill="${P.n}" ${SW}/><path d="M92 112 Q100 104 110 108 L108 136 Q96 138 92 132 Z" fill="${P.ac}"/>`+
 pt("legF",96,128,`<path d="M96 110 V138" stroke="${FI}" stroke-width="12" stroke-linecap="round"/><path d="M96 110 V138" stroke="${P.n}" stroke-width="9" stroke-linecap="round"/>`)+
 pt("head",96,76,`<path d="M72 80 Q72 58 94 56 Q116 58 116 80 Q112 96 94 96 Q76 96 72 80 Z" fill="${P.n}" ${SW}/><path d="M74 84 Q80 78 90 80 Q94 92 84 94 Q76 92 74 84 Z" fill="${P.ac}"/><ellipse cx="74" cy="82" rx="3.6" ry="3" fill="${FI}"/>${E2(88,74,3.4,"#3A2410",[-.6,0])}${E2(102,74,3.4,"#3A2410",[-.6,0])}`+
  `<path d="M76 88 L90 90 L88 94 L78 92 Z" fill="${FMOUTH}"/>`+pt("jaw",88,93,`<path d="M90 92 Q82 98 76 92 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(-10 72 98)"><rect x="60" y="92" width="18" height="10" fill="#E8C870" ${SW2}/><path d="M64 97 h10" stroke="${FI}" stroke-width="1"/></g>`)+
  pt("ear",86,58,`<path d="M82 62 L84 46 L94 58 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",106,60,`<path d="M100 58 L110 46 L112 64 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">...soon?</text>`)+fG(g,2,`<circle cx="110" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["Right Back Blend"]="Faithful Akita";SM("Right Back Blend","Wait Forever","RES","s",0,100,"endure,def+1","It said it'd be right back. So you wait.");

/* Round Trip Metal: circled the globe by mistake, eleven ports, back where it started. An arctic tern, the bird that flies pole to pole every year. */
addForm("Round Trip Metal",{n:"#F4F0F4",a:"#2A2A30",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="34" ry="3" fill="#000" opacity=".1"/><circle cx="160" cy="110" r="24" fill="#7AB8E8" opacity=".5" ${SW2}/><path d="M146 100 q8 -6 14 2 q6 8 14 2 M144 116 q10 6 20 0" stroke="#5A9A4A" stroke-width="5" fill="none" opacity=".8"/><ellipse cx="160" cy="110" rx="34" ry="10" fill="none" stroke="${FI}" stroke-width="1.4" stroke-dasharray="4 4"/>`+
 pt("wingB",112,72,`<path d="M110 72 Q140 40 186 36 Q150 56 132 80 Z" fill="${P.nd}" ${SW}/>`,.3)+
 pt("tail",136,80,`<path d="M130 78 L170 92 L148 84 L172 104 L132 88 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M74 80 Q80 66 104 66 Q128 68 136 82 Q124 92 104 92 Q82 92 74 80 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",100,90,`<path d="M100 90 L98 98 M104 90 L104 98" stroke="#E8412C" stroke-width="2"/>`)+
 pt("wingF",98,74,`<path d="M98 74 Q70 36 22 32 Q56 52 74 82 Z" fill="${P.n}" ${SW}/><path d="M28 34 Q44 40 52 48" stroke="${P.nd}" stroke-width="3" fill="none"/>`)+
 pt("head",78,74,`<circle cx="74" cy="72" r="11" fill="${P.n}" ${SW}/><path d="M66 66 Q74 60 84 64 L82 70 Q74 66 66 70 Z" fill="${P.ac}"/>${E2(72,72,2.8,"#1A1A1A")}<path d="M64 72 L48 74 L64 76 Z" fill="${FMOUTH}"/>`+pt("beak",64,76,`<path d="M64 76 L50 76 L64 79 Z" fill="#E8412C" ${SW2}/>`)+`<path d="M64 70 L46 74 L64 74 Z" fill="#E8412C" ${SW2}/>`)+
 fG(g,1,`<text x="20" y="130" font-size="9" font-weight="bold" fill="${P.ac}">×11 ports</text>`)+fG(g,2,`<circle cx="104" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Round Trip Metal"]="Pole-to-Pole Tern";SM("Round Trip Metal","Round The World","STR","a",75,100,"spd+1","Out one way, home the other. Thousands of miles.");

/* Rule Five Mix: whoever finds something strange at a roadside stall has to bring it home. A coyote with a roadside-stall find in its jaws, tail high. */
addForm("Rule Five Mix",{n:"#B8905A",a:"#E8E0C8",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M14 142 H194" stroke="#9A9AA0" stroke-width="8"/><path d="M30 142 h20 M80 142 h20 M130 142 h20" stroke="#F2C94C" stroke-width="2"/><path d="M168 140 V90 M190 140 V90" stroke="#6A4A2A" stroke-width="3"/><path d="M164 92 L194 92 L190 80 L168 80 Z" fill="#C8302A" ${SW2}/>`+fShadow(66)+
 pt("tail",154,94,`<path d="M150 96 Q172 84 176 104 Q170 114 156 108 Z" fill="${P.n}" ${SW}/><path d="M170 100 Q176 104 174 110" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",140,108,32,7,P.nd,P.ndd,.5)+fLeg("legB",110,110,30,7,P.nd,P.ndd,1.3)+
 `<path d="M84 100 Q86 80 118 78 Q150 80 156 98 Q150 114 118 114 Q88 114 84 100 Z" fill="${P.n}" ${SW}/><path d="M90 106 Q118 116 148 104" stroke="${P.ac}" stroke-width="5" fill="none"/>`+
 fLeg("legF",132,110,30,7,P.n,P.ndd,0)+fLeg("legF",96,110,30,7,P.n,P.ndd,.8)+
 pt("head",88,90,`<path d="M50 86 Q52 68 72 66 Q90 68 92 84 Q88 98 72 98 Q56 98 50 86 Z" fill="${P.n}" ${SW}/><path d="M50 88 L36 92 Q36 96 50 96 Z" fill="${P.n}" ${SW2}/><ellipse cx="36" cy="93" rx="2.6" ry="2.4" fill="${FI}"/>${E2(66,80,3.4,"#C8A020")}`+
  `<path d="M38 96 L52 98 L50 102 L40 100 Z" fill="${FMOUTH}"/>`+pt("jaw",50,101,`<path d="M52 100 Q44 106 38 100 Z" fill="${P.nd}" ${SW2}/><g transform="rotate(-10 34 104)"><path d="M22 96 h20 l-2 14 h-16 Z" fill="#E8C060" ${SW2}/><circle cx="32" cy="103" r="3" fill="#C8302A"/></g>`)+
  pt("ear",72,68,`<path d="M68 70 L70 50 L80 66 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",84,70,`<path d="M80 68 L92 52 L92 72 Z" fill="${P.nd}" ${SW2}/>`,.3))+
 fG(g,1,`<text x="20" y="40" font-size="10" font-weight="bold" fill="${P.ac}">RULE 5</text>`)+fG(g,2,`<circle cx="120" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Rule Five Mix"]="Road-Trip Coyote";SM("Rule Five Mix","Finders Keepers","STR","a",65,100,"drain:25","Rule five: you found it, you bring it home.");

/* Sample Seven: mislabelled 'Allergy Sample 7' and quarantined for a month. A giant panda, mid-sneeze. */
addForm("Sample Seven",{n:"#F4F0E8",a:"#2A2A30",rn:"#3A3A4A",rb:"#5A9A4A",ra:"#E8412C"},"stand",(P,g)=>fShadow(60)+
 pt("legB",122,130,`<ellipse cx="126" cy="138" rx="14" ry="7" fill="${P.ac}" ${SW}/>`,.5)+
 `<path d="M76 126 Q72 88 104 84 Q136 88 134 126 Q128 142 104 142 Q82 142 76 126 Z" fill="${P.n}" ${SW}/><path d="M80 100 Q104 92 130 100 L130 112 Q104 104 80 112 Z" fill="${P.ac}"/>`+
 pt("legF",86,130,`<ellipse cx="82" cy="138" rx="14" ry="7" fill="${P.ac}" ${SW}/>`)+
 pt("armF",84,104,fOL("M84 104 Q66 98 64 84",P.ac,12)+`<path d="M58 80 L70 64" stroke="#5A9A4A" stroke-width="3"/><ellipse cx="72" cy="62" rx="6" ry="3" fill="#5A9A4A" ${SW2}/>`)+pt("armB",128,104,fOL("M128 104 Q144 112 142 124",P.ac,12),.4)+
 pt("head",104,72,`<path d="M78 74 Q78 48 104 46 Q130 48 130 74 Q126 94 104 94 Q82 94 78 74 Z" fill="${P.n}" ${SW}/><ellipse cx="94" cy="70" rx="7" ry="9" fill="${P.ac}" transform="rotate(-20 94 70)"/><ellipse cx="114" cy="70" rx="7" ry="9" fill="${P.ac}" transform="rotate(20 114 70)"/><path d="M90 70 q4 3 8 0 M110 70 q4 3 8 0" stroke="#F4F0F4" stroke-width="2" fill="none"/><ellipse cx="104" cy="80" rx="4" ry="3" fill="${FI}"/>`+
  `<ellipse cx="104" cy="88" rx="6" ry="4" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",104,90,`<path d="M98 88 Q104 96 110 88 Z" fill="${P.n}" ${SW2}/>`)+
  pt("ear",82,50,`<circle cx="82" cy="50" r="8" fill="${P.ac}" ${SW}/>`)+pt("ear",126,50,`<circle cx="126" cy="50" r="8" fill="${P.ac}" ${SW}/>`,.3))+
 fG(g,1,`<path d="M60 90 q-8 -2 -14 -8 M58 96 q-10 2 -18 0 M60 102 q-8 4 -14 10" stroke="${P.ll}" stroke-width="2" fill="none"/><text x="150" y="40" font-size="10" font-weight="bold" fill="#C8302A">ACHOO</text>`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Sample Seven"]="Sneezing Panda";SM("Sample Seven","Achoo","STR","a",70,100,"tacc-1@40","Everyone in range gets a share.");

/* Seat 14C Special: the passenger in 14C never boards; the crate in the hold always arrives. A gremlin riding on the airship's wing, where nobody looks. */
addForm("Seat 14C Special",{n:"#7AA85A",a:"#E8C060",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"perch",(P,g)=>`<path d="M14 120 L194 108 L194 120 L14 136 Z" fill="#C8C8D0" ${SW}/>${[40,80,120,160].map(x=>`<circle cx="${x}" cy="${124-(x-14)*.07}" r="1.6" fill="#8A8A94"/>`).join("")}<path d="M150 112 L160 92 L172 92 L168 110" fill="#B8402A" ${SW2}/>`+fShadow(30,104)+
 pt("tail",128,104,`<path d="M124 106 Q146 102 150 88 L156 84 L150 82" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M124 106 Q146 102 150 88" stroke="${P.n}" stroke-width="2" fill="none"/>`)+
 pt("legB",116,112,fOL("M116 110 L124 116",P.nd,7),.5)+
 `<path d="M86 112 Q84 88 104 84 Q124 88 124 112 Q118 120 104 120 Q90 120 86 112 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",94,114,fOL("M94 112 L86 118",P.n,7))+
 pt("armF",88,96,fOL("M88 96 Q72 92 66 82",P.n,5)+`<path d="M62 78 l-4 -4 M66 76 l-2 -6 M70 78 l2 -6" stroke="${FI}" stroke-width="1.6"/>`)+
 pt("head",104,70,`<path d="M84 72 Q84 52 104 50 Q124 52 124 72 Q120 86 104 86 Q88 86 84 72 Z" fill="${P.n}" ${SW}/>${E2(96,66,5,"#E8C060")}${E2(112,66,5,"#E8C060")}`+HMOUTH(96,78,112,P,3)+`<path d="M98 78 l2 3 l2 -3 l2 3 l2 -3 l2 3" stroke="#fff" stroke-width="1.2" fill="none"/>`+
  pt("ear",84,62,`<path d="M86 62 L62 50 L84 72 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",124,62,`<path d="M122 62 L146 50 L124 72 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<rect x="20" y="30" width="30" height="16" rx="2" fill="#F4F0E4" ${SW2}/><text x="24" y="42" font-size="9" font-weight="bold" fill="${FI}">14C</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Seat 14C Special"]="Wing-Riding Gremlin";SM("Seat 14C Special","Tinker","RES","a",55,100,"tdef-1,tspd-1@30","A loose bolt here, a crossed wire there. Nobody saw anything.");

/* Sedgium: lockkeepers wave its narrowboats through for free. A sedge warbler, singing from a swaying reed. */
addForm("Sedgium",{n:"#A88A60",a:"#F4E8C8",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 136 Q60 128 104 136 Q150 144 194 134 V150 H14 Z" fill="#5A8AA8" opacity=".4"/>`+pt("sway",104,90,`<path d="M106 146 Q100 100 104 40" stroke="#8A9A4A" stroke-width="4" fill="none"/><path d="M104 60 Q90 50 82 30 M106 90 Q122 80 132 62 M104 120 Q86 110 76 94" stroke="#8A9A4A" stroke-width="3" fill="none"/>`)+`${[40,60,150,170].map(x=>`<path d="M${x} 146 Q${x-4} 100 ${x+2} 60" stroke="#8A9A4A" stroke-width="3" fill="none"/>`).join("")}`+fShadow(30,104)+
 pt("tail",120,96,`<path d="M116 92 L138 104 L132 110 L114 100 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M86 92 Q88 72 106 70 Q124 74 124 94 Q116 104 104 104 Q90 104 86 92 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${96+i*6} 76 q2 6 0 10" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}<path d="M88 94 Q100 104 116 98 Q104 92 94 86 Z" fill="${P.ac}"/>`+
 pt("legF",104,102,`<path d="M100 100 l2 8 M108 100 l-2 8" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",92,70,`<circle cx="90" cy="64" r="11" fill="${P.n}" ${SW}/><path d="M80 60 Q90 54 100 60" stroke="${P.ac}" stroke-width="3" fill="none"/>${E2(88,64,2.8,"#1A1A1A")}`+
  `<path d="M80 64 L68 64 L80 70 Z" fill="${FMOUTH}"/>`+pt("beak",78,70,`<path d="M80 68 L70 72 L80 72 Z" fill="${FI}"/>`)+`<path d="M80 62 L66 62 L80 66 Z" fill="${FI}"/>`)+
 fG(g,1,`<path d="M40 40 v-14 l8 3 M54 46 v-14 l8 3" stroke="${P.ac}" stroke-width="2" fill="none"/><circle cx="38" cy="40" r="3" fill="${P.ac}"/><circle cx="52" cy="46" r="3" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="104" cy="90" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,30,6)));
FORM_TITLE["Sedgium"]="Reed-Swaying Sedge Warbler";SM("Sedgium","Toll-Free","RES","s",0,100,"spd+1,heal:15","Waved through without a fee. It's tradition.");

/* Set Piece Metal: a film crew found it already on their period-drama set. A crocodile whose snapping jaw is a film clapperboard. */
addForm("Set Piece Metal",{n:"#3A3A40",a:"#F4F0E4",rn:"#E8D8C8",rb:"#B8402A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(80)+
 pt("tail",160,122,`<path d="M150 116 Q180 118 194 134 Q176 136 150 130 Z" fill="${P.n}" ${SW}/>`)+
 [[144,"legB",.5],[104,"legB",1.3]].map(([x,c,d])=>pt(c,x,128,fOL(`M${x} 126 L${x+8} 140 h6`,P.nd,8),d)).join("")+
 `<path d="M76 124 Q78 106 116 104 Q150 106 156 122 Q150 136 116 136 Q80 136 76 124 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4].map(i=>`<rect x="${86+i*13}" y="108" width="7" height="7" fill="${P.ac}"/>`).join("")}`+
 [[134,"legF",0],[92,"legF",.8]].map(([x,c,d])=>pt(c,x,130,fOL(`M${x} 128 L${x-8} 142 h-6`,P.n,8),d)).join("")+
 pt("head",80,116,`<rect x="30" y="110" width="52" height="16" rx="2" fill="${P.n}" ${SW}/><circle cx="66" cy="106" r="7" fill="${P.n}" ${SW2}/>${E2(66,105,4,"#E8C040")}<text x="34" y="122" font-size="6" fill="${P.ac}">SCENE 1 TAKE 7</text>`+
  pt("jaw",82,104,`<g transform="rotate(-24 82 108)"><rect x="30" y="100" width="54" height="9" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5].map(i=>`<path d="M${34+i*9} 100 l6 9" stroke="${P.ac}" stroke-width="4"/>`).join("")}</g>`))+
 fG(g,1,`<path d="M20 50 h26 v18 h-26 Z" fill="${FI}"/><circle cx="26" cy="44" r="6" fill="none" stroke="${FI}" stroke-width="3"/><circle cx="40" cy="44" r="6" fill="none" stroke="${FI}" stroke-width="3"/>`)+fG(g,2,`<circle cx="116" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,60,6)));
FORM_TITLE["Set Piece Metal"]="Clapperboard Crocodile";SM("Set Piece Metal","Take Seven","SCR","a",80,95,"crit","Snap! And that's a wrap.");

/* Snail Derby Special: the snail race was paused while judges debated whether a crate counted as an obstacle. A racing snail with a number on its shell. */
addForm("Snail Derby Special",{n:"#C8A080",a:"#E8604A",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 140 H194" stroke="#5A9A3A" stroke-width="6"/><path d="M30 136 V146 M170 136 V146" stroke="#F4F0F4" stroke-width="3"/>`+fShadow(66)+
 pt("tail",150,132,`<path d="M140 132 Q160 134 174 136" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 `<path d="M44 136 Q46 124 70 122 L150 126 Q162 130 160 136 Z" fill="${P.n}" ${SW}/>`+
 pt("sway",110,100,`<circle cx="112" cy="98" r="30" fill="${P.ac}" ${SW}/><path d="M112 98 m0 -18 a18 18 0 1 1 -16 26 a10 10 0 1 1 16 -12" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="112" cy="98" r="11" fill="#F4F0F4" ${SW2}/><text x="106" y="103" font-size="12" font-weight="bold" fill="${FI}">3</text>`)+
 pt("head",58,118,`<path d="M58 124 Q54 106 60 96" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M58 124 Q54 106 60 96" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`+HMOUTH(48,114,56,P,2)+
  pt("ant",60,94,`<path d="M58 96 L50 74 M62 96 L66 74" stroke="${FI}" stroke-width="2.6"/>${E2(50,72,3.6)}${E2(66,72,3.6)}`))+
 fG(g,1,`<path d="M170 30 V60 M170 30 h18 v6 h-18 v6 h18 v6 h-18" stroke="${FI}" stroke-width="1.6" fill="none"/><rect x="170" y="30" width="6" height="6" fill="${FI}"/><rect x="182" y="30" width="6" height="6" fill="${FI}"/><rect x="176" y="36" width="6" height="6" fill="${FI}"/>`)+fG(g,2,`<circle cx="112" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Snail Derby Special"]="Derby Racing Snail";SM("Snail Derby Special","Photo Finish","STR","a",50,100,"prio","Slowly, slowly, and then by a whisker.");

/* Snow Day Special: worked out alone by a janitor on a snow day. A snowman, built by that janitor, mop for an arm. */
addForm("Snow Day Special",{n:"#F4F8FC",a:"#2A2A30",rn:"#3A3A4A",rb:"#E8604A",ra:"#5FE0F0"},"stand",(P,g)=>`<path d="M14 140 Q60 130 104 140 Q150 150 194 136 V150 H14 Z" fill="#F4F8FC" ${SW2}/>`+fShadow(56)+
 `<circle cx="104" cy="118" r="26" fill="${P.n}" ${SW}/><circle cx="104" cy="80" r="19" fill="${P.n}" ${SW}/>${[72,82,92].map(y=>`<circle cx="104" cy="${y+38}" r="2.4" fill="${P.ac}"/>`).join("")}`+
 pt("armF",86,82,`<path d="M88 82 L60 66 L56 58 M64 68 L58 72" stroke="#6A4A2A" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 pt("armB",120,82,`<path d="M120 82 L150 60" stroke="#8A6A3A" stroke-width="4" stroke-linecap="round"/><path d="M150 60 L170 140" stroke="#8A6A3A" stroke-width="3" stroke-linecap="round" opacity="0"/><path d="M146 54 L158 66" stroke="${FI}" stroke-width="2"/>${[0,1,2,3,4].map(i=>`<path d="M${150+i*2} ${56-i*2} q8 -6 4 -14" stroke="#B8B8C0" stroke-width="3" fill="none"/>`).join("")}`,.4)+
 pt("head",104,52,`<circle cx="104" cy="50" r="15" fill="${P.n}" ${SW}/><circle cx="98" cy="46" r="2.4" fill="${P.ac}"/><circle cx="110" cy="46" r="2.4" fill="${P.ac}"/><path d="M104 52 L88 56 L104 56 Z" fill="#E8701A" ${SW2}/>`+pt("jaw",104,60,`${[96,100,104,108,112].map((x,i)=>`<circle cx="${x}" cy="${60+Math.abs(i-2)*-1}" r="1.4" fill="${P.ac}"/>`).join("")}`)+
  `<path d="M90 38 Q104 30 118 38 L116 30 Q104 22 92 30 Z" fill="#3A5AA8" ${SW2}/><path d="M88 66 Q104 72 120 66 L120 72 Q104 78 88 72 Z" fill="#C8302A" ${SW2}/><path d="M114 72 L118 86" stroke="#C8302A" stroke-width="5"/>`)+
 fG(g,1,`${[[30,30],[50,50],[170,30],[160,60],[140,20],[30,80]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="#fff" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Snow Day Special"]="Janitor's Snowman";SM("Snow Day Special","School's Out","RES","s",0,100,"tspd-1,heal:20","Everything stops. Nobody's going anywhere today.");

/* Sorter's Stray: never reached anyone and was adopted by the sorting office. A stray puppy curled up asleep in a mail sack. */
addForm("Sorter's Stray",{n:"#D8B080",a:"#F4F0E4",rn:"#3A3A4A",rb:"#B8402A",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(60)+
 `<path d="M58 140 Q50 104 64 90 L144 90 Q158 104 150 140 Z" fill="#C8B890" ${SW}/><path d="M64 90 Q104 98 144 90" stroke="#8A7A50" stroke-width="3" fill="none"/><text x="82" y="128" font-size="10" font-weight="bold" fill="#8A3A2A">MAIL</text>${[[70,112],[132,116]].map(([x,y])=>`<rect x="${x-6}" y="${y-4}" width="12" height="8" fill="#F4F0E4" ${SW2} transform="rotate(${x%13-6} ${x} ${y})"/>`).join("")}`+
 pt("tail",136,86,`<path d="M132 90 Q148 80 146 70" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M132 90 Q148 80 146 70" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 `<path d="M78 92 Q80 72 108 70 Q134 72 138 92 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",86,90,`<ellipse cx="84" cy="92" rx="8" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("head",88,80,`<path d="M62 84 Q62 66 82 64 Q102 66 102 84 Q98 96 82 96 Q66 96 62 84 Z" fill="${P.n}" ${SW}/><path d="M64 88 Q70 82 78 86 Q78 94 70 94 Z" fill="${P.ac}"/><ellipse cx="64" cy="86" rx="3" ry="2.4" fill="${FI}"/><path d="M74 78 q3 2 6 0 M86 78 q3 2 6 0" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(70,90,78,P,1.6)+
  pt("ear",94,66,`<path d="M92 64 Q104 62 104 80 Q100 84 96 78 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<text x="150" y="50" font-family="Georgia,serif" font-size="12" font-weight="bold" fill="${P.ac}">z z</text>`)+fG(g,2,`<circle cx="104" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Sorter's Stray"]="Mail-Sack Puppy";SM("Sorter's Stray","Adopted","RES","s",0,100,"heal:35,def+1","Nobody claimed it, so everybody did.");

/* Stallholder's Mix: an ancient market stall advertised it at an alarming price. A dolphin picked out in ancient floor-mosaic tiles. */
addForm("Stallholder's Mix",{n:"#5A8AC8",a:"#E8D8B0",rn:"#3A3A4A",rb:"#B8603A",ra:"#F2C94C"},"swim",(P,g)=>`<rect x="18" y="20" width="172" height="124" fill="${P.ac}" ${SW}/>${Array.from({length:88},(_,i)=>`<rect x="${20+(i%11)*15.6}" y="${22+Math.floor(i/11)*15}" width="14" height="13.4" fill="${P.ac}" stroke="#C8B890" stroke-width=".8"/>`).join("")}<rect x="22" y="24" width="164" height="116" fill="none" stroke="#B8603A" stroke-width="4" stroke-dasharray="6 3"/>`+
 pt("tail",150,72,`<path d="M140 76 L162 54 L160 76 L172 92 Z" fill="${P.n}" ${SW}/>`)+
 pt("sway",104,84,`<path d="M42 100 Q50 64 100 60 Q134 62 146 78 Q136 96 104 102 Q76 108 60 104 L46 110 Z" fill="${P.n}" ${SW}/>${Array.from({length:14},(_,i)=>`<rect x="${58+(i%7)*12}" y="${70+Math.floor(i/7)*12}" width="10" height="10" fill="none" stroke="${P.nd}" stroke-width="1"/>`).join("")}<path d="M60 98 Q100 106 136 86" stroke="#F4F0F4" stroke-width="5" fill="none" opacity=".7"/>`+
  pt("head",56,92,`${E2(66,84,3.6,"#1A1A1A")}`+pt("jaw",44,104,`<path d="M42 102 L56 104 L46 110 Z" fill="${P.nd}" ${SW2}/>`)))+
 pt("wingF",98,66,`<path d="M96 62 L106 44 L112 64 Z" fill="${P.nd}" ${SW}/>`)+
 fG(g,1,`<text x="28" y="134" font-size="8" font-weight="bold" fill="#B8603A">XIV DENARII</text>`)+fG(g,2,`<circle cx="100" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,120,6)));
FORM_TITLE["Stallholder's Mix"]="Mosaic Dolphin";SM("Stallholder's Mix","Market Price","RES","a",70,100,"drain:20","Ancient prices were alarming too.");

/* Stowaway Blend: a starfish clung to the shipment all the way from Ferris Isle. That starfish, hitching a ride, waving one arm. */
addForm("Stowaway Blend",{n:"#E8704A",a:"#F2C94C",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#5FE0A0"},"crawl",(P,g)=>`<rect x="40" y="92" width="128" height="50" fill="#B88A50" ${SW}/><path d="M40 116 h128 M80 92 v50 M128 92 v50" stroke="#8A6030" stroke-width="2"/><path d="M48 136 q4 -6 10 0" stroke="#5A8A4A" stroke-width="3" fill="none"/>`+fShadow(80)+
 pt("sway",104,80,`${[0,1,2,3,4].map(i=>{const a=-1.57+i*1.2566,x=104+Math.cos(a)*36,y=80+Math.sin(a)*36;return`<path d="M104 80 L${x} ${y}" stroke="${FI}" stroke-width="${i===1?20:22}" stroke-linecap="round"/><path d="M104 80 L${x} ${y}" stroke="${P.n}" stroke-width="${i===1?16:18}" stroke-linecap="round"/>`}).join("")}${Array.from({length:15},(_,i)=>{const a=-1.57+(i%5)*1.2566,r=10+Math.floor(i/5)*9;return`<circle cx="${104+Math.cos(a)*r}" cy="${80+Math.sin(a)*r}" r="2" fill="${P.ac}"/>`}).join("")}`+
  pt("head",104,80,`${E2(98,78,3.6)}${E2(110,78,3.6)}`+HMOUTH(100,86,108,P,2)))+
 pt("armF",140,72,`<path d="M138 70 Q150 56 156 60" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M138 70 Q150 56 156 60" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/>`)+
 fG(g,1,`<path d="M20 40 h20 l-4 -8 h-12 Z" fill="#8A6A4A" ${SW2}/><path d="M30 32 V18 l8 6 l-8 4" stroke="${FI}" stroke-width="1.4" fill="#F4F0F4"/>`)+fG(g,2,`<circle cx="104" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Stowaway Blend"]="Hitchhiking Starfish";SM("Stowaway Blend","Hold On Tight","RES","s",0,100,"endure,def+1","Five arms, and none of them letting go.");

/* Supperite: autocorrect sent the order to a restaurant wholesaler. A lobster in a dinner bib, very much not on the menu. */
addForm("Supperite",{n:"#C83A2A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",150,118,`${[0,1,2,3].map(i=>`<path d="M${140+i*9} ${110+i*2} q6 -4 9 2 v14 q-6 2 -9 -2 Z" fill="${P.n}" ${SW2}/>`).join("")}<path d="M176 114 L190 104 L194 124 L178 128 Z" fill="${P.nd}" ${SW2}/>`)+
 [0,1,2].map(i=>pt("legB",120+i*8,126,`<path d="M${120+i*8} 126 L${126+i*10} 142" stroke="${FI}" stroke-width="3"/>`,i*.2)).join("")+
 `<path d="M84 118 Q86 100 114 98 Q140 100 144 118 Q140 132 114 132 Q88 132 84 118 Z" fill="${P.n}" ${SW}/><path d="M96 102 L112 132 L128 102 Z" fill="${P.ac}" ${SW2}/><path d="M100 108 q12 4 24 0" stroke="#5A8AC8" stroke-width="1.6" fill="none"/>`+
 [0,1].map(i=>pt("legF",100+i*8,128,`<path d="M${100+i*8} 128 L${94+i*8} 144" stroke="${FI}" stroke-width="3"/>`,i*.2+.1)).join("")+
 pt("claw",86,108,fOL("M90 110 Q72 96 66 80",P.n,7)+`<path d="M46 64 Q50 52 64 56 Q74 64 68 78 Q56 86 46 78 Z" fill="${P.n}" ${SW}/>`+pt("claw2",48,74,`<path d="M48 74 Q36 76 34 86 Q46 86 52 80 Z" fill="${P.nd}" ${SW2}/>`)+`<path d="M60 52 L64 40 M54 54 l-2 -14" stroke="#B8B8C0" stroke-width="2.4"/>`)+
 pt("head",84,112,`<path d="M66 116 Q68 104 82 104 Q92 106 92 116 Z" fill="${P.n}" ${SW}/>${E2(74,100,3.6)}${E2(86,100,3.6)}<path d="M74 104 V108 M86 104 V108" stroke="${FI}" stroke-width="2"/>`+pt("ant",72,108,`<path d="M72 110 Q44 108 30 94 M74 112 Q48 120 30 116" stroke="${FI}" stroke-width="1.4" fill="none"/>`)+HMOUTH(64,116,72,P,2))+
 fG(g,1,`<path d="M20 120 h26 v20 h-26 Z" fill="#F4F0E4" ${SW2}/><text x="23" y="133" font-size="7" font-weight="bold" fill="${FI}">MENU</text>`)+fG(g,2,`<circle cx="114" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,60,6)));
FORM_TITLE["Supperite"]="Dinner-Bib Lobster";SM("Supperite","Not On The Menu","SCR","a",75,100,"tdef-1@30","Sent to the wrong kitchen, and not happy about it.");
