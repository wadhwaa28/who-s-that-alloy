/* ---- Tinker's Scrapyard, 1 ---- */
/* 3 A.M. Special: mixed by a sleepwalking assistant who woke holding a clipboard. A kinkajou, the night-roaming honey bear, sleepwalking with a clipboard. */
addForm("3 A.M. Special",{n:"#B8804A",a:"#F4E8C8",rn:"#3A3A4A",rb:"#7A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54)+
 pt("tail",126,120,`<path d="M124 122 Q160 124 164 98 Q166 80 152 82 Q144 88 152 94" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M124 122 Q160 124 164 98 Q166 80 152 82 Q144 88 152 94" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,130,fOL("M116 126 L120 142 H130",P.nd,8),.5)+
 `<path d="M84 128 Q80 96 104 92 Q128 96 126 128 Q120 142 104 142 Q88 142 84 128 Z" fill="${P.n}" ${SW}/>`+
 pt("legF",92,130,fOL("M94 126 L88 142 H78",P.n,8))+
 pt("armF",88,104,fOL("M88 104 Q70 100 60 100",P.n,6)+`<g transform="rotate(-6 50 102)"><rect x="40" y="92" width="18" height="24" rx="2" fill="#B88A50" ${SW2}/><rect x="43" y="96" width="12" height="17" fill="#F4F0E4"/><rect x="46" y="89" width="6" height="4" fill="${P.b}" ${SW2}/></g>`)+pt("armB",122,104,fOL("M122 104 Q140 100 150 102",P.nd,6),.4)+
 pt("head",104,76,`<path d="M82 78 Q82 56 104 54 Q126 56 126 78 Q122 92 104 92 Q86 92 82 78 Z" fill="${P.n}" ${SW}/><path d="M94 72 q4 2 8 0 M108 72 q4 2 8 0" stroke="${FI}" stroke-width="2" fill="none"/><ellipse cx="104" cy="80" rx="3" ry="2" fill="${FI}"/>`+HMOUTH(100,84,108,P,2)+
  pt("ear",86,58,`<circle cx="86" cy="58" r="5" fill="${P.n}" ${SW2}/>`)+pt("ear",122,58,`<circle cx="122" cy="58" r="5" fill="${P.n}" ${SW2}/>`,.3)+`<path d="M86 56 Q104 36 122 56 L128 46 Q104 20 80 46 Z" fill="#5A6AA8" ${SW2}/><circle cx="130" cy="44" r="4" fill="#F4F0E4" ${SW2}/>`)+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}" font-family="monospace">3:00</text><path d="M30 40 a10 10 0 1 0 8 -10 a7 7 0 1 1 -8 10 Z" fill="#F2D060" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["3 A.M. Special"]="Sleepwalking Kinkajou";SM("3 A.M. Special","Sleepwalk","RES","a",60,90,"dodge","Fast asleep, and somehow it still gets everything done.");

/* Abstention No. 19: nineteen meetings, three for, three against, one abstaining. A hoopoe perched on the fence, crest up, refusing to choose. */
addForm("Abstention No. 19",{n:"#D8A070",a:"#2A2A30",rn:"#E8D8C8",rb:"#5A8A4A",ra:"#E8412C"},"perch",(P,g)=>`<path d="M14 116 H194" stroke="#8A6A4A" stroke-width="8"/>${[30,70,110,150,190].map(x=>`<rect x="${x-4}" y="100" width="8" height="46" fill="#8A6A4A" ${SW2}/>`).join("")}`+fShadow(40,104)+
 pt("tail",126,104,`<path d="M120 100 L148 110 L144 118 L122 108 Z" fill="${P.ac}" ${SW}/>${[132,140].map(x=>`<path d="M${x} ${104+(x-130)*.3} l2 6" stroke="#F4F0F4" stroke-width="3"/>`).join("")}`)+
 `<path d="M86 108 Q86 84 106 80 Q128 84 128 106 Q120 116 104 116 Q90 116 86 108 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",112,98,`<path d="M100 92 Q124 88 134 108 Q118 116 104 108 Z" fill="${P.ac}" ${SW}/>${[0,1,2].map(i=>`<path d="M${108+i*8} ${96+i*2} l6 10" stroke="#F4F0F4" stroke-width="3"/>`).join("")}`)+
 pt("legF",102,114,`<path d="M100 114 l-2 4 M106 114 l2 4" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",94,76,`<circle cx="92" cy="72" r="12" fill="${P.n}" ${SW}/>${E2(88,70,3,"#1A1A1A")}<path d="M80 72 Q62 78 52 92 L80 76 Z" fill="${FMOUTH}"/>`+pt("beak",66,84,`<path d="M80 76 Q64 86 54 94 Q66 84 80 78 Z" fill="${FI}"/>`)+`<path d="M80 68 Q62 74 50 90 Q64 78 80 72 Z" fill="${FI}"/>`+
  pt("ant",96,60,`${[0,1,2,3,4].map(i=>`<path d="M${86+i*4} 62 Q${80+i*6} ${42-i} ${88+i*8} 34" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M${86+i*4} 62 Q${80+i*6} ${42-i} ${88+i*8} 34" stroke="${P.n}" stroke-width="3.6" fill="none" stroke-linecap="round"/><path d="M${87+i*8} 36 l2 -4" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>`).join("")}`))+
 fG(g,1,`<text x="150" y="40" font-size="12" font-weight="bold" fill="${P.ac}">3 : 3</text>`)+fG(g,2,`<circle cx="104" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Abstention No. 19"]="Fence-Sitting Hoopoe";SM("Abstention No. 19","Abstain","RES","s",0,100,"def+1,ward+1","No vote either way. Nobody can blame it for anything.");

/* Achy Knee: one old fisherman's aching knee was consulted to pick the date. A fiddler crab with a bandaged knee, one huge claw raised to read the weather. */
addForm("Achy Knee",{n:"#C86A4A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#F2C94C"},"crawl",(P,g)=>`<path d="M14 136 Q104 128 194 140 V150 H14 Z" fill="#E8D8B0" ${SW2}/>`+fShadow(66)+
 [0,1,2].map(i=>pt("legB",126+i*8,122,`<path d="M${126+i*8} 122 L${136+i*10} 112 L${144+i*10} 140" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${126+i*8} 122 L${136+i*10} 112 L${144+i*10} 140" stroke="${P.nd}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>${i===1?`<rect x="${140+i*10-6}" y="${114}" width="9" height="7" fill="${P.ac}" ${SW2} transform="rotate(30 ${140+i*10} 118)"/>`:""}`,i*.2)).join("")+
 `<path d="M88 124 Q90 98 120 96 Q148 98 150 122 Q144 132 118 132 Q92 132 88 124 Z" fill="${P.n}" ${SW}/>`+
 [0,1].map(i=>pt("legF",98+i*8,126,`<path d="M${98+i*8} 126 L${90+i*8} 114 L${84+i*8} 142" stroke="${FI}" stroke-width="5" fill="none" stroke-linejoin="round"/><path d="M${98+i*8} 126 L${90+i*8} 114 L${84+i*8} 142" stroke="${P.n}" stroke-width="2.6" fill="none" stroke-linejoin="round"/>`,i*.2+.1)).join("")+
 pt("claw",92,108,fOL("M94 110 Q76 100 70 86",P.n,8)+`<path d="M40 50 Q36 28 58 26 Q80 30 78 56 Q74 80 56 82 Q40 80 40 50 Z" fill="${P.ac}" ${SW}/>`+pt("claw2",44,72,`<path d="M42 70 Q26 72 22 86 Q38 88 50 78 Z" fill="#E8E0D0" ${SW2}/>`))+
 pt("head",116,100,`<path d="M110 100 V82 M124 100 V82" stroke="${FI}" stroke-width="2.4"/>${E2(110,80,3.6)}${E2(124,80,3.6)}`+HMOUTH(112,108,122,P,2))+
 fG(g,1,`<path d="M150 40 l6 -10 l6 10 Z" fill="none" stroke="${P.ac}" stroke-width="2"/><text x="166" y="42" font-size="9" fill="${P.ac}">rain</text>`)+fG(g,2,`<circle cx="118" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,80,6)));
FORM_TITLE["Achy Knee"]="Weather-Knee Fiddler Crab";SM("Achy Knee","Feel It Coming","RES","s",0,100,"acc+1,dodge","The knee always knows when the weather's turning.");

/* Admiralite: a tortoise called Admiral has sat on the delivery for fourteen years. Admiral himself: a giant tortoise in a bicorne hat. */
addForm("Admiralite",{n:"#6A6A5A",a:"#1A2A4A",rn:"#E8D8C8",rb:"#C8A040",ra:"#E8412C"},"crawl",(P,g)=>`<rect x="70" y="128" width="80" height="16" fill="#B88A50" ${SW}/>`+fShadow(70)+
 pt("tail",160,118,`<path d="M156 114 L170 118 L156 122 Z" fill="${P.n}" ${SW2}/>`)+
 [[148,.5],[96,0]].map(([x,d])=>pt("legB",x,120,`<path d="M${x-8} 118 L${x-10} 132 H${x+8} L${x+8} 118 Z" fill="${P.nd}" ${SW2}/>`,d)).join("")+
 `<path d="M66 120 Q64 62 114 58 Q164 62 162 120 Z" fill="${P.nd}" ${SW}/>${[[90,90],[114,78],[138,90],[102,106],[126,106]].map(([x,y])=>`<path d="M${x-12} ${y} l6 -10 h12 l6 10 l-6 10 h-12 Z" fill="${P.n}" ${SW2}/>`).join("")}<path d="M62 120 H166" stroke="${FI}" stroke-width="5"/>`+
 [[136,.5],[82,0]].map(([x,d])=>pt("legF",x,120,`<path d="M${x-8} 118 L${x-10} 134 H${x+8} L${x+8} 118 Z" fill="${P.n}" ${SW2}/>`,d)).join("")+
 pt("head",66,110,fOL("M72 112 Q56 108 50 96",P.n,14)+`<path d="M22 92 Q24 74 42 74 Q58 76 60 90 Q56 102 42 102 Q26 102 22 92 Z" fill="${P.n}" ${SW}/><path d="M34 82 q4 -2 8 0" stroke="${FI}" stroke-width="2" fill="none"/>${E2(40,86,3,"#3A2410")}`+HMOUTH(24,94,32,P,2.4)+
  `<path d="M20 74 Q42 54 64 74 Q42 68 20 74 Z" fill="${P.ac}" ${SW}/><circle cx="42" cy="66" r="3" fill="#C8A040" ${SW2}/><path d="M30 72 Q42 66 54 72" stroke="#C8A040" stroke-width="1.6" fill="none"/>`)+
 fG(g,1,`<text x="160" y="40" font-size="12" font-weight="bold" fill="${P.ac}">14 yrs</text>`)+fG(g,2,`<circle cx="114" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(120,30,6)));
FORM_TITLE["Admiralite"]="Admiral Tortoise";SM("Admiralite","Hold Position","RES","s",0,100,"def+2,endure","Fourteen years in the same spot. It isn't moving now.");

/* After-Lunch Metal: forty minutes of debate, ending in a vote to 'revisit after lunch'. A python sleeping off a very large lunch. */
addForm("After-Lunch Metal",{n:"#8A7A4A",a:"#3A3A30",rn:"#E8D8C8",rb:"#5A8A4A",ra:"#E8412C"},"slink",(P,g)=>fShadow(80)+
 pt("tail",170,126,`<path d="M150 128 Q176 132 186 120 Q192 110 184 106" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M150 128 Q176 132 186 120 Q192 110 184 106" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 pt("sway",104,120,`<path d="M40 124 Q60 120 80 124 Q90 104 116 104 Q142 106 146 124 Q156 128 160 128" stroke="${FI}" stroke-width="18" fill="none" stroke-linecap="round"/><path d="M40 124 Q60 120 80 124 Q90 104 116 104 Q142 106 146 124 Q156 128 160 128" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/><ellipse cx="114" cy="118" rx="32" ry="20" fill="${P.n}" ${SW}/>${[[100,112],[118,106],[130,120],[108,126],[90,124]].map(([x,y])=>`<path d="M${x-4} ${y} l4 -4 l4 4 l-4 4 Z" fill="${P.ac}" opacity=".7"/>`).join("")}`)+
 pt("head",40,120,`<path d="M18 124 Q18 110 34 108 Q50 110 50 122 Q46 132 34 132 Z" fill="${P.n}" ${SW}/><path d="M28 116 q3 2 6 0" stroke="${FI}" stroke-width="2" fill="none"/>`+HMOUTH(20,126,28,P,1.6))+
 fG(g,1,`<text x="20" y="80" font-family="Georgia,serif" font-size="13" font-weight="bold" fill="${P.ac}">z z z</text><path d="M150 60 h26 v-6 h-26 Z" fill="#F4F0E4" ${SW2}/><path d="M150 54 q13 -10 26 0" fill="none" stroke="${FI}" stroke-width="1.4"/>`)+fG(g,2,`<circle cx="114" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,60,6)));
FORM_TITLE["After-Lunch Metal"]="Post-Lunch Python";SM("After-Lunch Metal","Revisit After Lunch","RES","s",0,100,"heal:45,selfspd-1","Let's pick this up later. Much later.");

/* After-You Metal: whoever's nearest holds the door for its crate. An okapi doorman, cap on, holding the door wide. */
addForm("After-You Metal",{n:"#5A3A2A",a:"#F4F0E4",rn:"#E8D8C8",rb:"#3A5A8A",ra:"#F2C94C"},"stand",(P,g)=>`<rect x="150" y="20" width="40" height="124" fill="#8A6A4A" ${SW}/><rect x="154" y="24" width="32" height="116" fill="#C8E0F0" opacity=".6"/><circle cx="158" cy="84" r="3" fill="#C8A040" ${SW2}/>`+fShadow(66)+
 pt("tail",156,90,fOL("M154 90 Q164 100 162 116",P.n,3))+
 fLeg("legB",144,104,38,7,P.ac,P.ndd,.5)+fLeg("legB",114,106,36,7,P.ac,P.ndd,1.3)+
 `<path d="M88 98 Q88 76 120 74 Q152 76 156 96 Q152 112 122 112 Q92 112 88 98 Z" fill="${P.n}" ${SW}/>${[0,1,2,3].map(i=>`<path d="M${132+i*6} 82 l-2 24" stroke="${P.ac}" stroke-width="3"/>`).join("")}`+
 fLeg("legF",136,106,36,7,P.ac,P.ndd,0)+pt("legF",100,104,fOL("M100 104 L84 110 L80 142",P.ac,7),.8)+
 pt("armF",120,86,`<path d="M140 84 L152 74" stroke="${FI}" stroke-width="5" stroke-linecap="round" opacity="0"/>`)+
 pt("head",94,82,`<path d="M98 88 Q90 60 90 44" stroke="${FI}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M98 88 Q90 60 90 44" stroke="${P.n}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M68 44 Q68 28 86 26 Q102 28 102 42 Q100 52 88 52 L70 52 Z" fill="${P.n}" ${SW}/><path d="M68 44 Q68 50 76 52 L74 44 Z" fill="${P.ac}"/>${E2(86,38,3.4,"#1A1A1A")}`+HMOUTH(70,48,78,P,2)+
  pt("ear",96,30,`<path d="M94 32 Q104 22 108 28 Q104 36 96 36 Z" fill="${P.n}" ${SW2}/>`)+`<path d="M78 28 Q88 14 100 24 L100 28 Q88 22 80 30 Z" fill="#3A5AA8" ${SW2}/><path d="M76 28 L68 30" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,1,`<text x="20" y="40" font-family="Georgia,serif" font-size="10" font-style="italic" fill="${P.ac}">after you</text>`)+fG(g,2,`<circle cx="122" cy="98" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,80,6)));
FORM_TITLE["After-You Metal"]="Doorman Okapi";SM("After-You Metal","After You","RES","s",0,100,"tatk-1,spd+1","Please, go ahead. No, really, I insist.");

/* Ainsleyite: two brothers split the business down the middle. A cardinal split exactly down the middle, half one colour, half the other. */
addForm("Ainsleyite",{n:"#C8302A",a:"#9A8A70",rn:"#3A3A4A",rb:"#5A8A4A",ra:"#F2C94C"},"perch",(P,g)=>`<path d="M14 120 Q104 110 194 124" stroke="#6A4A2A" stroke-width="8" stroke-linecap="round"/>`+fShadow(40,104)+
 pt("tail",124,104,`<path d="M118 100 L146 116 L138 124 L116 108 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M80 108 Q80 80 104 78 Q128 82 128 108 Q120 120 104 120 Q88 120 80 108 Z" fill="${P.n}" ${SW}/><clipPath id="spC"><rect x="104" y="40" width="40" height="90"/></clipPath><g clip-path="url(#spC)"><path d="M80 108 Q80 80 104 78 Q128 82 128 108 Q120 120 104 120 Q88 120 80 108 Z" fill="${P.ac}"/><circle cx="102" cy="68" r="14" fill="${P.ac}"/><path d="M104 56 L110 34 L116 54 Z" fill="${P.ac}"/></g><path d="M104 40 V120" stroke="${FI}" stroke-width="1.6"/><path d="M80 108 Q80 80 104 78 Q128 82 128 108" fill="none" ${SW}/>`+
 pt("legF",102,118,`<path d="M98 118 l-2 6 M106 118 l2 6" stroke="${FI}" stroke-width="2"/>`)+
 pt("head",100,70,`<path d="M88 66 Q88 52 102 52 Q116 54 116 68 Q114 80 102 82 Q88 80 88 66 Z" fill="none" ${SW}/><path d="M96 56 L102 34 L108 54" fill="none" ${SW2}/><path d="M88 66 L96 64 L98 74 L90 74 Z" fill="${FI}"/>${E2(96,66,2.8,"#1A1A1A")}<path d="M88 68 L78 70 L88 74 Z" fill="${FMOUTH}"/>`+pt("beak",86,74,`<path d="M88 72 Q80 76 78 72 Q82 78 88 76 Z" fill="#E8A040" ${SW2}/>`)+`<path d="M90 64 Q80 64 76 70 L88 70 Z" fill="#E8A040" ${SW2}/>`)+
 fG(g,1,`<path d="M30 40 h20 M40 30 v20" stroke="${P.ac}" stroke-width="2"/><text x="150" y="40" font-size="10" font-weight="bold" fill="${P.n}">½ + ½</text>`)+fG(g,2,`<circle cx="104" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,80,6)));
FORM_TITLE["Ainsleyite"]="Half-and-Half Cardinal";SM("Ainsleyite","Split Down The Middle","RES","a",60,100,"drain:30","Half for you, half for me. Fair is fair.");

/* Alnico: before rare-earth magnets, the strongest permanent magnet going. A hedgehog whose spines are iron filings standing up in its field. */
addForm("Alnico",{n:"#8A8A94",a:"#C8302A",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60)+
 `${[-1,1].map(s=>[0,1,2].map(i=>`<path d="M${104+s*(48+i*8)} 120 Q${104+s*(40+i*10)} ${70-i*14} 104 ${60-i*10}" stroke="#9AA0B0" stroke-width="1" fill="none" stroke-dasharray="3 3"/>`).join("")).join("")}`+
 pt("sway",112,104,`<path d="M74 124 Q70 84 112 78 Q154 84 156 124 Q150 134 112 134 Q78 134 74 124 Z" fill="${P.n}" ${SW}/>${Array.from({length:26},(_,i)=>{const a=-2.9+i*.105,x=114+Math.cos(a)*38,y=124+Math.sin(a)*40;return`<path d="M${x} ${y} L${x+Math.cos(a)*14} ${y+Math.sin(a)*14}" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`}).join("")}`)+
 `<path d="M98 136 Q98 120 114 120 Q130 120 130 136" stroke="${FI}" stroke-width="12" fill="none"/><path d="M98 136 Q98 120 114 120 Q130 120 130 136" stroke="${P.ac}" stroke-width="8" fill="none"/><path d="M94 132 h8 M126 132 h8" stroke="#E8E8F0" stroke-width="8"/>`+
 pt("legF",88,130,`<ellipse cx="86" cy="136" rx="7" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("head",76,114,`<path d="M40 118 Q44 100 66 98 Q84 100 86 116 Q80 130 62 130 Q46 130 40 118 Z" fill="#E8D8C0" ${SW}/><circle cx="40" cy="118" r="3.4" fill="${FI}"/>${E2(62,110,3.6,"#1A1A1A")}`+HMOUTH(44,122,54,P,2)+pt("ear",74,100,`<circle cx="74" cy="100" r="4" fill="#E8D8C0" ${SW2}/>`))+
 fG(g,1,`<text x="20" y="40" font-size="14" font-weight="bold" fill="${P.ac}">N</text><text x="176" y="40" font-size="14" font-weight="bold" fill="#3A5AA8">S</text>`)+fG(g,2,`<circle cx="114" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(104,30,6)));
FORM_TITLE["Alnico"]="Iron-Filing Hedgehog";SM("Alnico","Field Lines","RES","s",0,100,"mag,def+1","Every filing stands up and points the same way.");

/* Alumel: the cold half of the world's commonest thermocouple. A snipe, whose long beak probes like a temperature lead. */
addForm("Alumel",{n:"#A8906A",a:"#3A3A30",rn:"#E8D8C8",rb:"#5AB0C8",ra:"#F2C94C"},"stand",(P,g)=>`<path d="M14 140 Q60 132 104 140 Q150 148 194 136 V150 H14 Z" fill="#6A5A3A" ${SW2}/>`+fShadow(54,110)+
 pt("tail",136,96,`<path d="M132 92 L150 98 L134 104 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legB",118,112,`<path d="M118 110 L120 138" stroke="#8A9A6A" stroke-width="3"/><path d="M112 140 h14" stroke="#8A9A6A" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M88 100 Q90 80 112 78 Q134 82 136 102 Q128 114 110 114 Q92 114 88 100 Z" fill="${P.n}" ${SW}/>${Array.from({length:10},(_,i)=>`<path d="M${96+(i%5)*8} ${86+Math.floor(i/5)*12} l4 6" stroke="${P.ac}" stroke-width="2"/>`).join("")}`+
 pt("legF",104,112,`<path d="M104 110 L102 138" stroke="#8A9A6A" stroke-width="3"/><path d="M94 140 h14" stroke="#8A9A6A" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",92,80,`<circle cx="90" cy="76" r="12" fill="${P.n}" ${SW}/><path d="M82 70 Q90 64 98 70" stroke="${P.ac}" stroke-width="3" fill="none"/>${E2(88,76,3,"#1A1A1A")}`+
  `<path d="M78 78 L36 112 L40 114 L80 82 Z" fill="${FMOUTH}"/>`+pt("beak",58,98,`<path d="M80 82 L40 116 L42 118 L82 84 Z" fill="#C8A060" ${SW2}/>`)+`<path d="M78 76 L34 110 L38 112 L80 80 Z" fill="#C8A060" ${SW2}/><circle cx="36" cy="113" r="3" fill="#5AB0C8" ${SW2}/>`)+
 fG(g,1,`<path d="M160 30 v28" stroke="${FI}" stroke-width="5" stroke-linecap="round"/><circle cx="160" cy="62" r="5" fill="#5AB0C8" ${SW2}/><text x="170" y="44" font-size="9" fill="#5AB0C8">cold</text>`)+fG(g,2,`<circle cx="112" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Alumel"]="Probe-Beaked Snipe";SM("Alumel","Cold Junction","RES","a",60,100,"tspd-1@40","One half of the pair. The cold, steady half.");

/* Amblite: stitched into square thirty of the village quilt. A guinea pig made of quilt patches, one square stitched with tiny numbers. */
addForm("Amblite",{n:"#C8805A",a:"#F4F0E4",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60)+
 [[134,.5],[96,1.2]].map(([x,d])=>pt("legB",x,132,`<ellipse cx="${x}" cy="140" rx="7" ry="4" fill="#E8A0A0" ${SW2}/>`,d)).join("")+
 `<path d="M70 122 Q70 92 110 90 Q150 92 152 122 Q148 138 110 138 Q74 138 70 122 Z" fill="${P.n}" ${SW}/><clipPath id="qlC"><path d="M70 122 Q70 92 110 90 Q150 92 152 122 Q148 138 110 138 Q74 138 70 122 Z"/></clipPath><g clip-path="url(#qlC)">${[[70,88,"#E8C060"],[96,88,"#7AB8E8"],[122,88,"#E8604A"],[70,114,"#5AB04A"],[96,114,"#F4F0E4"],[122,114,"#B85AC8"]].map(([x,y,c])=>`<rect x="${x}" y="${y}" width="26" height="26" fill="${c}" opacity=".75"/><rect x="${x+2}" y="${y+2}" width="22" height="22" fill="none" stroke="${FI}" stroke-width="1" stroke-dasharray="2 2"/>`).join("")}<text x="100" y="130" font-size="9" font-weight="bold" fill="${FI}">30</text></g><path d="M70 122 Q70 92 110 90 Q150 92 152 122 Q148 138 110 138 Q74 138 70 122" fill="none" ${SW}/>`+
 [[124,0],[84,.7]].map(([x,d])=>pt("legF",x,134,`<ellipse cx="${x}" cy="141" rx="7" ry="4" fill="#E8A0A0" ${SW2}/>`,d)).join("")+
 pt("head",78,114,`<path d="M42 116 Q44 98 64 96 Q84 98 86 114 Q82 130 62 130 Q46 130 42 116 Z" fill="${P.n}" ${SW}/><path d="M50 104 Q58 98 66 104 L64 118 L52 116 Z" fill="${P.ac}" opacity=".85"/><circle cx="44" cy="116" r="2.6" fill="${FI}"/>${E2(60,108,3.6,"#1A1A1A")}`+HMOUTH(46,122,54,P,2)+
  pt("ear",72,98,`<path d="M68 98 Q76 90 82 96 Q78 102 72 102 Z" fill="#E8A0A0" ${SW2}/>`))+
 fG(g,1,`<path d="M20 50 q10 -8 20 0" stroke="${FI}" stroke-width="1.4" stroke-dasharray="3 2" fill="none"/><path d="M40 50 l6 -10" stroke="#C8C8D0" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="110" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(150,60,6)));
FORM_TITLE["Amblite"]="Patchwork Guinea Pig";SM("Amblite","Stitch In Time","RES","s",0,100,"heal:30,def+1","Patch it up properly and it'll last a hundred years.");
