/* =============== BATTLE FORMS (third pass: rigged) ===============
   Each form is a creature built from what its alloy IS: its metals, its types, and what it is used for, with its story only as an
   occasional accent. Every form is rigged like a puppet: a head that turns, a jaw or beak that really opens over a mouth, limbs and claws
   that swing from their joints, tails and wings that move from their roots, and a body that shifts its weight, hops, swims or hovers
   according to how that creature gets about. Nothing simply swells and shrinks. */
const BATTLE_FORMS={};
const FI="#121B40",FMOUTH="#5A1A2A",FTONGUE="#E8708A";
function fPal(a,rad,R){const b=rad?R.rb:a.color,n=rad?R.rn:R.n;return{b,d:shade(b,-.3),dd:shade(b,-.52),l:shade(b,.28),ll:shade(b,.58),n,nd:shade(n,-.28),ndd:shade(n,-.5),nl:shade(n,.3),nll:shade(n,.55),ac:rad?R.ra:R.a,ink:FI}}
function fE(x,y,r,o){o=o||{};const ry=r*1.15,[dx,dy]=o.look||[-.25,0],ir=o.iris||"#3A2A1A";let s=`<g class="eye" style="transform-origin:${x}px ${y}px"><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${ry}" fill="#FFFFFF" stroke="${FI}" stroke-width="2.2"/>`+
  `<circle cx="${x+dx*r}" cy="${y+dy*r+r*.08}" r="${r*.66}" fill="${ir}"/><circle cx="${x+dx*r}" cy="${y+dy*r+r*.12}" r="${r*.36}" fill="${FI}"/><circle cx="${x+dx*r-r*.24}" cy="${y+dy*r-r*.2}" r="${r*.22}" fill="#FFFFFF"/><circle cx="${x+dx*r+r*.2}" cy="${y+dy*r+r*.28}" r="${r*.1}" fill="#FFFFFF"/>`;
  if(o.lid){const yc=y-ry+2*ry*o.lid,half=r*Math.sqrt(Math.max(0,1-Math.pow((yc-y)/ry,2)));s+=`<path d="M${(x-half).toFixed(2)} ${yc.toFixed(2)} A${r} ${ry} 0 ${yc>y?1:0} 1 ${(x+half).toFixed(2)} ${yc.toFixed(2)} Z" fill="${o.lidC||"#888"}" stroke="${FI}" stroke-width="2.2" stroke-linejoin="round"/>`}
  return s+"</g>"}
const fG=(g,n,s)=>g>=n?s:"";
const fShadow=(rx,cx)=>`<ellipse class="shd" cx="${cx||100}" cy="148" rx="${rx||52}" ry="7" fill="#000" opacity=".2"/>`;
const SW=`stroke="${FI}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`,SW2=`stroke="${FI}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"`;
/* a rigged part: it turns about its own joint, given in the drawing's coordinates */
const pt=(c,x,y,s,d)=>`<g class="pt p-${c}" style="transform-origin:${x}px ${y}px${d?`;--dl:${d}s`:""}">${s}</g>`;
const star=(x,y,r,c)=>`<path d="M${x} ${y-r} L${x+r*.28} ${y-r*.28} L${x+r} ${y} L${x+r*.28} ${y+r*.28} L${x} ${y+r} L${x-r*.28} ${y+r*.28} L${x-r} ${y} L${x-r*.28} ${y-r*.28} Z" fill="${c||"#FFD23F"}" stroke="${FI}" stroke-width="1.3"/>`;
function fWrap(inner,g,loco){const s=.92+.03*g;return`<svg viewBox="0 0 200 160" aria-hidden="true"><g transform="translate(100 148) scale(${s}) translate(-100 -148)"><g class="cr-body L-${loco}"><g class="ib">${inner}</g></g></g></svg>`}
const FORM_R={},FORM_FN={},FORM_LOCO={};
function addForm(name,R,loco,fn){FORM_R[name]=R;FORM_FN[name]=fn;FORM_LOCO[name]=loco;BATTLE_FORMS[name]=(a,g,rad)=>{const P=fPal(a,rad,R);return fWrap(fn(P,g,!!rad),g,loco)}}
const FORM_TITLE={};

/* 1. Twirler's Dream (copper with beryllium: the springiest copper there is) — a jerboa built on coiled spring legs that never stops
   bouncing, copper bands round its middle, ears like tuning forks. */
addForm("Twirler's Dream",{n:"#E8C89A",a:"#E8412C",rn:"#C8B8F0",rb:"#7A5CC8",ra:"#FFD23F"},"hop",(P,g)=>fShadow(40,108)+
 pt("tail",128,116,`<path d="M128 116 Q160 126 186 112" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M128 116 Q160 126 186 112" ${SW2} fill="none" opacity=".35"/><path d="M180 104 Q196 108 192 120 Q184 118 178 114 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("legB",118,120,`<path d="M118 120 l-8 4 l14 4 l-14 4 l14 4 l-14 4 l8 4" stroke="${P.b}" stroke-width="4" fill="none" stroke-linejoin="round"/><path d="M118 120 l-8 4 l14 4 l-14 4 l14 4 l-14 4 l8 4" stroke="${FI}" stroke-width="1.2" fill="none" opacity=".6"/><path d="M104 146 Q104 140 118 140 L134 142 Q138 147 130 148 H106 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M84 124 Q74 96 94 80 Q118 70 130 94 Q136 118 116 128 Q98 134 84 124 Z" fill="${P.n}" ${SW}/><path d="M90 118 Q86 100 98 92 Q110 96 108 118 Q100 124 90 118 Z" fill="${P.nll}"/>`+
 `<path d="M112 82 Q132 92 128 116 Q120 128 108 128 Q128 108 112 82 Z" fill="${P.nd}" opacity=".35"/>`+
 [100,108,116].map(y=>`<path d="M${82+(y-100)*.2} ${y} Q104 ${y+6} ${128-(y-100)*.3} ${y-2}" stroke="${P.b}" stroke-width="4" fill="none"/>`).join("")+
 pt("armF",90,94,`<path d="M90 92 Q76 98 72 110" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M90 92 Q76 98 72 110" stroke="${P.n}" stroke-width="4.5" fill="none" stroke-linecap="round"/><path d="M68 110 l-3 4 M72 112 l-1 5 M76 111 l1 4" stroke="${FI}" stroke-width="1.6" stroke-linecap="round"/>`)+
 pt("head",98,80,
  pt("ear",94,48,`<path d="M92 48 L90 14 Q96 10 98 14 L100 46 Z" fill="${P.n}" ${SW2}/><path d="M94 44 L93 18" stroke="${P.b}" stroke-width="2.4"/>`)+
  pt("ear",102,50,`<path d="M100 48 L106 16 Q112 14 112 20 L106 50 Z" fill="${P.n}" ${SW2}/><path d="M104 46 L109 20" stroke="${P.b}" stroke-width="2.4"/>`,.4)+
  `<path d="M60 70 L82 72 L80 76 L62 74 Z" fill="${FMOUTH}"/>`+
  pt("jaw",84,70,`<path d="M84 70 Q72 80 60 72 Q70 78 84 76 Z" fill="${P.nl}" ${SW2}/>`)+
  `<path d="M60 68 Q56 52 76 46 Q100 42 106 60 Q106 76 86 76 Q66 76 60 68 Z" fill="${P.n}" ${SW}/><ellipse cx="58" cy="66" rx="4" ry="3.4" fill="#E8708A" ${SW2}/>`+
  `${fE(82,58,7.5,{iris:"#2A1A0A",look:[-.3,0]})}<path d="M64 64 l-10 -4 M64 67 l-10 0" stroke="${FI}" stroke-width="1"/>`)+
 fG(g,1,`<path d="M134 96 Q142 92 146 98" stroke="${P.b}" stroke-width="3" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(126,62,6)+star(48,40,5)));
FORM_TITLE["Twirler's Dream"]="Spring Jerboa";

/* 2. Branny Head Special (silicon bronze: the casting bronze of statues and boat fittings) — a statue's lion cub that came down off its
   plinth, green patina in its creases, a cast mane, roaring. */
addForm("Branny Head Special",{n:"#7AB89A",a:"#E8C060",rn:"#E8A0C8",rb:"#C87AB0",ra:"#FFFFFF"},"stand",(P,g)=>fShadow(66)+
 pt("tail",146,104,`<path d="M146 104 Q172 96 176 76" stroke="${P.b}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M146 104 Q172 96 176 76" ${SW2} fill="none" opacity=".35"/><path d="M170 66 Q184 70 180 82 Q172 80 170 76 Z" fill="${P.d}" ${SW2}/>`)+
 pt("legB",136,118,`<path d="M128 112 Q146 116 144 132 L148 146 H130 Q128 132 124 124 Z" fill="${P.b}" ${SW}/><path d="M132 144 v-4 M138 144 v-4" stroke="${FI}" stroke-width="1.4"/>`)+
 `<path d="M60 124 Q56 94 84 88 L136 86 Q156 90 154 114 Q150 130 128 130 L74 130 Q62 132 60 124 Z" fill="${P.b}" ${SW}/>`+
 `<path d="M124 88 Q156 92 152 116 Q146 128 128 130 Q148 110 124 88 Z" fill="${P.dd}" opacity=".35"/><path d="M80 120 Q100 126 120 120" stroke="${P.n}" stroke-width="5" fill="none" opacity=".75"/><path d="M130 100 q6 4 10 0 M98 96 q4 -3 8 0" stroke="${P.n}" stroke-width="3" fill="none" opacity=".8"/>`+
 pt("legF",76,118,`<path d="M66 112 Q60 128 64 146 H82 Q80 130 86 118 Z" fill="${P.b}" ${SW}/><path d="M68 144 v-4 M74 144 v-4" stroke="${FI}" stroke-width="1.4"/>`)+
 pt("head",70,90,
  `<path d="${Array.from({length:20},(_,i)=>{const t=i/20*Math.PI*2,r=i%2?31:37;return (i?'L':'M')+(66+r*Math.cos(t)).toFixed(1)+' '+(74+r*Math.sin(t)).toFixed(1)}).join(' ')}Z" fill="${P.dd}" ${SW}/>`+`<circle cx="66" cy="74" r="26" fill="${P.d}" ${SW}/><path d="M50 60 q6 -4 10 2 M78 52 q6 0 8 6" stroke="${P.n}" stroke-width="3" fill="none"/>`+
  `<path d="M34 82 L58 84 L56 92 L36 88 Z" fill="${FMOUTH}"/><path d="M40 84 l3 4 l3 -4 M48 85 l3 4 l3 -4" fill="#FFFFFF"/>`+
  pt("jaw",58,86,`<path d="M58 86 Q46 98 34 88 Q42 94 58 92 Z" fill="${P.b}" ${SW2}/><path d="M40 90 l3 -3 l3 3" fill="#FFFFFF"/>`)+
  `<path d="M38 80 Q32 64 48 56 Q68 50 80 62 Q86 78 70 84 Q52 88 38 80 Z" fill="${P.b}" ${SW}/><path d="M34 74 Q30 70 36 68 L44 70 Q42 76 34 74 Z" fill="${P.dd}" ${SW2}/>`+
  `${fE(56,66,6.5,{iris:"#E8C060",look:[-.4,0]})}${fE(70,64,6,{iris:"#E8C060",look:[-.4,0]})}<path d="M50 58 L60 61 M66 56 L76 60" ${SW2}/>`+
  pt("ear",80,52,`<path d="M76 54 Q78 40 90 44 Q90 54 82 58 Z" fill="${P.b}" ${SW2}/>`))+
 fG(g,1,`<rect x="96" y="134" width="40" height="10" rx="2" fill="${P.n}" opacity=".5"/>`)+
 fG(g,2,`<path d="M100 92 Q110 86 120 92" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 fG(g,3,`<path d="M50 34 L54 24 L60 32 L66 22 L72 34 Z" fill="#FFD23F" ${SW2}/>`));
FORM_TITLE["Branny Head Special"]="Statue Cub";

/* 3. Varnite (beryllium copper: the metal of non-sparking tools, safe to dig with near gas) — a mole cricket, the great burrower, with
   two huge shovel claws that open out, armoured copper shoulders and sweeping antennae. */
addForm("Varnite",{n:"#6A4A2E",a:"#E8C060",rn:"#2E4A6A",rb:"#5FE0F0",ra:"#FF8A2A"},"crawl",(P,g)=>fShadow(70)+
 [[112,124],[130,124],[146,122]].map(([x,y],i)=>pt("legB",x,y,`<path d="M${x} ${y} L${x+10} ${y+10} L${x+6} ${y+22}" stroke="${P.nd}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.15)).join("")+
 `<path d="M98 126 Q96 100 124 98 Q160 96 176 112 Q180 124 160 128 Q128 134 98 126 Z" fill="${P.n}" ${SW}/>${[118,132,146,160].map(x=>`<path d="M${x} 100 Q${x+3} 114 ${x} 128" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 `<path d="M140 98 Q176 100 178 118 L176 120 Q164 100 140 98 Z" fill="${P.nll}" opacity=".5"/>`+
 `<path d="M64 116 Q60 84 92 80 Q118 80 120 108 Q118 126 92 128 Q70 128 64 116 Z" fill="${P.b}" ${SW}/><path d="M76 90 Q92 84 108 90" stroke="${P.ll}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M100 84 Q120 92 116 118 Q108 126 96 127 Q116 106 100 84 Z" fill="${P.dd}" opacity=".35"/>`+
 pt("claw",70,112,`<path d="M74 110 Q54 112 44 124" stroke="${P.b}" stroke-width="8" fill="none" stroke-linecap="round"/>`+pt("claw2",46,124,`<path d="M48 118 L28 114 L34 122 L22 124 L32 130 L22 136 L36 136 L46 132 Z" fill="${P.ll}" ${SW2}/>`))+
 pt("claw",84,118,`<path d="M88 116 Q74 126 70 138" stroke="${P.b}" stroke-width="8" fill="none" stroke-linecap="round"/>`+pt("claw2",70,138,`<path d="M72 132 L52 132 L60 140 L48 144 L60 148 L72 146 Z" fill="${P.ll}" ${SW2}/>`),.3)+
 pt("head",70,96,`<path d="M42 100 Q38 82 56 78 Q72 78 74 96 Q72 108 58 108 Q44 108 42 100 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M38 100 L50 102 L48 106 L38 104 Z" fill="${FMOUTH}"/>`+pt("jaw",50,102,`<path d="M50 102 L36 108 L50 108 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(56,88,6,{iris:"#E8C060",look:[-.4,0]})}`+
  pt("ant",54,80,`<path d="M54 80 Q40 50 14 44" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`)+pt("ant",62,80,`<path d="M62 80 Q60 46 38 26" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`,.5))+
 fG(g,1,`<path d="M30 146 q6 -8 14 -2 q6 -6 12 2" fill="#8A6A4A" ${SW2}/>`)+
 fG(g,2,`<path d="M80 86 L86 80 L92 86" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(100,64,6)));
FORM_TITLE["Varnite"]="Burrow Cricket";

/* 4. Pickle's Prize (plain carbon steel with a pinch of cobalt: as magnetic as metal gets) — a wolf whose ruff and tail are iron filings
   standing up along its own magnetic field lines, jaw that snaps shut like a latch. */
addForm("Pickle's Prize",{n:"#5A6070",a:"#E8412C",rn:"#E8E4F2",rb:"#E87AB0",ra:"#3AC0E0"},"stand",(P,g)=>fShadow(70)+
 pt("tail",150,98,`${Array.from({length:7},(_,i)=>`<path d="M150 98 Q${168+i*2} ${92-i*3} ${180+i} ${74-i*4}" stroke="${P.b}" stroke-width="2" fill="none"/>`).join("")}<path d="M150 98 Q170 88 182 70" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".8"/>`)+
 pt("legB",140,118,`<path d="M132 110 Q150 116 146 134 L150 146 H134 Q132 134 128 124 Z" fill="${P.n}" ${SW}/>`)+
 pt("legB",120,120,`<path d="M114 114 Q124 128 122 146 H108 Q110 132 106 122 Z" fill="${P.nd}" ${SW}/>`,.5)+
 `<path d="M62 116 Q56 88 88 84 L138 82 Q158 86 156 108 Q150 126 128 126 L78 126 Q64 126 62 116 Z" fill="${P.n}" ${SW}/><path d="M86 118 Q110 124 136 118" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".6"/>`+
 `<path d="M124 84 Q156 88 154 110 Q148 124 130 125 Q150 104 124 84 Z" fill="${P.ndd}" opacity=".35"/>`+
 Array.from({length:14},(_,i)=>{const x=74+i*5;return`<path d="M${x} 86 Q${x-4} ${74-(i%3)*3} ${x-10} ${66-(i%3)*4}" stroke="${P.b}" stroke-width="2" fill="none"/>`}).join("")+
 pt("legF",80,116,`<path d="M72 110 Q66 126 70 146 H86 Q84 130 90 118 Z" fill="${P.n}" ${SW}/>`)+
 pt("legF",96,118,`<path d="M92 114 Q88 130 92 146 H104 Q102 130 104 118 Z" fill="${P.nd}" ${SW}/>`,.5)+
 pt("head",74,86,
  pt("ear",70,58,`<path d="M66 62 L62 38 L80 54 Z" fill="${P.n}" ${SW2}/><path d="M66 58 L65 46 L74 54" fill="${P.ac}"/>`)+
  pt("ear",84,58,`<path d="M80 60 L88 38 L94 58 Z" fill="${P.nd}" ${SW2}/>`,.3)+
  `<path d="M26 84 L52 86 L50 92 L28 90 Z" fill="${FMOUTH}"/><path d="M30 86 l3 4 l3 -4 M40 86 l3 4 l3 -4" fill="#FFFFFF"/>`+
  pt("jaw",54,88,`<path d="M54 88 Q40 98 26 90 Q36 96 54 94 Z" fill="${P.nd}" ${SW2}/><rect x="40" y="91" width="8" height="4" fill="${P.b}" stroke="${FI}" stroke-width="1"/>`)+
  `<path d="M28 82 Q26 70 44 66 Q58 56 76 62 Q90 72 82 86 Q66 92 28 82 Z" fill="${P.n}" ${SW}/><path d="M28 82 Q24 78 28 76 L36 76 Q36 82 28 82 Z" fill="${FI}"/>`+
  `${fE(60,72,6.5,{iris:"#E8C040",look:[-.4,0]})}<path d="M52 66 L66 68" ${SW2}/>`+
  Array.from({length:8},(_,i)=>{const a=-1.9+i*.32;return`<path d="M${74+18*Math.cos(a)} ${84+18*Math.sin(a)} L${74+30*Math.cos(a)} ${84+30*Math.sin(a)}" stroke="${P.b}" stroke-width="2.4"/>`}).join(""))+
 fG(g,1,`<circle cx="86" cy="84" r="4" fill="${P.ac}" ${SW2}/>`)+
 fG(g,2,`<path d="M100 60 q10 -10 20 0 M104 52 q6 -6 12 0" stroke="${P.b}" stroke-width="1.6" fill="none" stroke-dasharray="2 2"/>`)+
 fG(g,3,star(40,46,6)));
FORM_TITLE["Pickle's Prize"]="Filing Wolf";

/* 5. Extra Mile Metal (steel with molybdenum and copper, made for shielding sensors) — a pangolin plated in overlapping shield scales,
   long sticky tongue, digging claws, and a tail it can wrap round itself. */
addForm("Extra Mile Metal",{n:"#C89A6A",a:"#E8604A",rn:"#2E3548",rb:"#3AC0E0",ra:"#FFD23F"},"crawl",(P,g)=>fShadow(70)+
 pt("tail",150,112,`<path d="M150 112 Q182 116 186 136 Q178 146 164 140" fill="none" stroke="${P.b}" stroke-width="14" stroke-linecap="round"/><path d="M150 112 Q182 116 186 136 Q178 146 164 140" ${SW} fill="none" opacity=".3"/>${[[162,112],[174,118],[182,128],[180,138]].map(([x,y])=>`<path d="M${x-6} ${y-4} Q${x} ${y-9} ${x+6} ${y-4}" stroke="${P.dd}" stroke-width="2" fill="none"/>`).join("")}`)+
 [[78,126],[100,130],[124,130],[144,126]].map(([x,y],i)=>pt(i%2?"legB":"legF",x,y,`<path d="M${x-6} ${y-6} L${x-6} ${y+14} L${x+6} ${y+14} L${x+6} ${y-6} Z" fill="${P.n}" ${SW2}/><path d="M${x-8} ${y+14} l-4 2 M${x-4} ${y+15} l-3 3" stroke="${FI}" stroke-width="1.8" stroke-linecap="round"/>`,i*.25)).join("")+
 `<path d="M60 120 Q58 84 104 78 Q150 80 156 116 Q150 132 104 134 Q66 134 60 120 Z" fill="${P.b}" ${SW}/>`+
 [[0,0],[1,0],[2,0],[3,0],[4,0],[.5,1],[1.5,1],[2.5,1],[3.5,1],[1,2],[2,2],[3,2]].map(([c,r])=>{const x=74+c*18,y=90+r*13;return`<path d="M${x-10} ${y+6} Q${x-10} ${y-8} ${x} ${y-10} Q${x+10} ${y-8} ${x+10} ${y+6} Q${x} ${y+12} ${x-10} ${y+6} Z" fill="${P.b}" stroke="${FI}" stroke-width="1.8"/><path d="M${x-5} ${y-4} Q${x} ${y-7} ${x+5} ${y-4}" stroke="${P.ll}" stroke-width="1.6" fill="none"/>`}).join("")+
 pt("head",62,104,`<path d="M62 96 Q40 92 26 106 Q22 112 30 114 Q46 116 64 114 Z" fill="${P.n}" ${SW}/>`+
  pt("tongue",26,110,`<path d="M26 110 Q12 112 2 108" stroke="${FTONGUE}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
  `<circle cx="26" cy="108" r="2.5" fill="${FI}"/>${fE(48,102,5,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}<path d="M56 98 Q60 92 64 96" ${SW2} fill="${P.n}"/>`)+
 fG(g,1,`<path d="M90 76 L96 70 L102 76" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<circle cx="104" cy="70" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(130,66,6)));
FORM_TITLE["Extra Mile Metal"]="Shield Pangolin";

/* 6. Farthingite (soft magnetic steel beads, the kind in loudspeaker magnets) — a fat bullfrog whose throat sac is a loudspeaker cone,
   croaking so loud the beads on its back rattle. */
addForm("Farthingite",{n:"#6AA04A",a:"#E8C040",rn:"#E87AB0",rb:"#F2E6C8",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(66)+
 pt("legB",138,124,`<path d="M124 112 Q160 106 162 128 Q160 140 146 140 L168 146 H130 Q122 136 124 112 Z" fill="${P.n}" ${SW}/><path d="M160 146 l6 -2 M154 146 l4 -3" ${SW2}/>`)+
 `<path d="M56 124 Q48 88 94 80 Q140 78 150 112 Q148 134 106 136 Q64 136 56 124 Z" fill="${P.n}" ${SW}/><path d="M120 84 Q148 92 148 116 Q140 132 120 134 Q142 110 120 84 Z" fill="${P.ndd}" opacity=".3"/>`+
 [[90,88],[104,86],[118,90],[96,98],[112,98],[126,100],[132,110]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="4" fill="${P.b}" stroke="${FI}" stroke-width="1.5"/><circle cx="${x-1.2}" cy="${y-1.2}" r="1.2" fill="#FFFFFF"/>`).join("")+
 pt("armF",72,120,`<path d="M74 118 Q64 132 66 146 H54 L60 140" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M74 118 Q64 132 66 146" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`)+
 pt("head",80,92,
  `<path d="M28 96 Q24 70 54 64 Q88 60 96 84 Q92 98 70 100 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M30 96 L86 98 L84 104 L34 102 Z" fill="${FMOUTH}"/>`+
  pt("jaw",88,98,`<path d="M88 98 Q60 112 30 98 Q56 108 88 104 Z" fill="${P.nl}" ${SW2}/>`)+
  `<circle cx="50" cy="64" r="11" fill="${P.n}" ${SW2}/><circle cx="76" cy="62" r="10" fill="${P.n}" ${SW2}/>${fE(50,62,7,{iris:"#E8C040",look:[-.3,0],lid:.35,lidC:P.n})}${fE(76,60,6.5,{iris:"#E8C040",look:[-.3,0],lid:.35,lidC:P.n})}`+
  `<ellipse cx="34" cy="80" rx="2" ry="1.4" fill="${FI}"/>`)+
 pt("sac",58,112,`<g class="sac"><ellipse cx="60" cy="116" rx="20" ry="14" fill="#2A2E34" ${SW}/><ellipse cx="60" cy="116" rx="14" ry="10" fill="${P.b}" stroke="${FI}" stroke-width="1.6"/><ellipse cx="60" cy="116" rx="8" ry="6" fill="#3A3E48"/><circle cx="60" cy="116" r="3" fill="${P.b}"/></g>`)+
 fG(g,1,`<path d="M30 116 q-6 -4 -10 0 M28 124 q-8 0 -12 4" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="140" cy="122" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(66,44,6)));
FORM_TITLE["Farthingite"]="Speaker Frog";

/* 7. Mahjongite (copper-beryllium with silicon and zirconium: light, stiff, made for satellite brackets and glider struts) — a manta
   ray gliding on wings braced by thin struts, its head flaps curling in to feed. */
addForm("Mahjongite",{n:"#2E4A6A",a:"#FFFFFF",rn:"#F2E6C8",rb:"#E87AB0",ra:"#3A6AD8"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="60" ry="5" fill="#000" opacity=".14"/>`+
 pt("tail",140,82,`<path d="M140 82 Q170 92 196 84" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 pt("wingB",112,78,`<path d="M112 70 Q140 30 176 26 Q168 58 140 84 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M116 ${74-i*2} L${150+i*8} ${38-i*4}" stroke="${P.b}" stroke-width="2.4"/>`).join("")}`)+
 `<path d="M60 84 Q80 60 116 64 Q148 70 146 88 Q128 104 92 102 Q66 100 60 84 Z" fill="${P.n}" ${SW}/><path d="M74 90 Q100 98 130 92" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".7"/>`+
 pt("wingF",96,92,`<path d="M96 92 Q64 120 20 124 Q36 102 74 86 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M${90-i*4} ${94+i} L${40+i*10} ${118-i*4}" stroke="${P.b}" stroke-width="2.4"/>`).join("")}<path d="M60 108 Q46 116 32 118" stroke="${P.nl}" stroke-width="3" fill="none" opacity=".6"/>`)+
 pt("head",66,82,`${fE(72,74,5.5,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("jaw",62,80,`<path d="M62 76 Q48 70 44 80 Q52 82 60 82 Z" fill="${P.nl}" ${SW2}/>`)+pt("beak",62,88,`<path d="M62 88 Q48 94 44 86 Q52 84 60 84 Z" fill="${P.nl}" ${SW2}/>`)+`<path d="M54 82 L62 82" stroke="${FMOUTH}" stroke-width="4"/>`)+
 fG(g,1,`<circle cx="120" cy="80" r="2.4" fill="${P.ac}"/><circle cx="128" cy="78" r="2" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M24 130 q8 -4 16 0 q8 4 16 0" stroke="#8AB4D8" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(100,46,6)));
FORM_TITLE["Mahjongite"]="Strut Manta";

/* 8. Maybe Metal (tin and silver solder: it melts before most things are warm) — a snail that leaves a gleaming solder trail behind it,
   its shell a leaded panel of coloured glass, eye-stalks that stretch out and pull back. */
addForm("Maybe Metal",{n:"#E8C8A0",a:"#3B7BF0",rn:"#9FE8D0",rb:"#C8A0F0",ra:"#E8412C"},"slink",(P,g,rad)=>{const pn=rad?["#C8A0F0","#7A3FA0","#F0C8E8","#9A6AD0"]:["#E8412C","#3B7BF0","#FFD23F","#2FB463"];return fShadow(70)+
 `<path d="M140 146 Q170 146 190 140" stroke="${P.ll}" stroke-width="5" fill="none" stroke-linecap="round" opacity=".9"/><path d="M150 144 Q170 144 186 140" stroke="#FFFFFF" stroke-width="1.6" fill="none"/>`+
 `<path d="M30 140 Q36 122 60 118 L150 120 Q160 132 150 144 L40 146 Q28 146 30 140 Z" fill="${P.n}" ${SW}/><path d="M40 144 L150 144" stroke="${P.nd}" stroke-width="2"/>`+
 pt("sway",104,120,`<circle cx="106" cy="86" r="36" fill="${P.b}" ${SW}/><path d="M106 50 V122 M70 86 H142" stroke="${P.dd}" stroke-width="4"/><path d="M107 51 A35 35 0 0 1 141 85 H107 Z" fill="${pn[0]}"/><path d="M105 51 A35 35 0 0 0 71 85 H105 Z" fill="${pn[1]}"/><path d="M71 87 A35 35 0 0 0 105 121 V87 Z" fill="${pn[2]}"/><path d="M107 121 A35 35 0 0 0 141 87 H107 Z" fill="${pn[3]}"/><path d="M106 50 V122 M70 86 H142" stroke="${P.dd}" stroke-width="3.4"/><circle cx="106" cy="86" r="12" fill="${P.b}" stroke="${P.dd}" stroke-width="3"/><circle cx="106" cy="86" r="35" fill="none" stroke="${P.dd}" stroke-width="3"/><path d="M84 62 Q94 54 106 54" stroke="#FFFFFF" stroke-width="3" fill="none" opacity=".7"/>`)+
 pt("head",48,122,`<path d="M30 132 Q22 112 40 104 Q56 102 60 120 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M28 128 L40 130 L38 134 L30 132 Z" fill="${FMOUTH}"/>`+pt("jaw",40,130,`<path d="M40 130 Q32 138 26 132 Q32 136 40 134 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ant",40,106,`<path d="M40 106 L30 74" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/>${fE(30,72,5,{iris:"#3A2A1A",look:[-.4,0]})}`)+
  pt("ant",48,106,`<path d="M48 106 L50 70" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/>${fE(50,68,5,{iris:"#3A2A1A",look:[-.4,0]})}`,.6))+
 fG(g,1,`<path d="M154 136 q4 -6 8 0" stroke="#FFFFFF" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="106" cy="86" r="5" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(106,40,6))});
FORM_TITLE["Maybe Metal"]="Solder Snail";

/* 9. Riddlite (titanium-zirconium: afterburner liners and rocket nozzles) — a small wyvern with a jet nozzle at the root of its tail,
   pale titanium armour, a mouth that opens to a blue flame. */
addForm("Riddlite",{n:"#5A6A8A",a:"#5FE0F0",rn:"#E8E4F2",rb:"#E8604A",ra:"#FFD23F"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="54" ry="5" fill="#000" opacity=".15"/>`+
 pt("tail",142,98,`<path d="M142 98 Q166 108 172 126" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M168 122 L178 140 L162 132 Z" fill="${P.b}" ${SW2}/><g class="p-glow"><path d="M150 104 L168 96 L172 108 Z" fill="${P.ac}" opacity=".8"/></g>`)+
 pt("wingB",116,76,`<path d="M116 76 L150 26 L158 40 L170 34 L164 60 L176 62 L132 90 Z" fill="${P.b}" ${SW}/><path d="M118 78 L154 36 M124 84 L166 60" stroke="${P.dd}" stroke-width="2"/>`)+
 `<path d="M78 112 Q74 82 104 76 Q138 76 146 100 Q144 120 116 124 Q90 126 78 112 Z" fill="${P.n}" ${SW}/><path d="M86 108 Q104 116 128 110" stroke="${P.nl}" stroke-width="6" fill="none" opacity=".7"/>`+
 `<path d="M96 80 L104 76 L112 80 L120 78 L126 84" stroke="${P.b}" stroke-width="5" fill="none" stroke-linejoin="round"/>`+
 pt("legF",96,118,`<path d="M96 118 L90 136 L82 140 M90 136 L94 142" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("legB",122,120,`<path d="M122 120 L120 138 L112 142 M120 138 L126 142" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.4)+
 pt("wingF",104,84,`<path d="M104 84 L64 40 L62 56 L48 52 L58 72 L44 76 L92 98 Z" fill="${P.b}" ${SW}/><path d="M100 86 L64 48 M96 92 L52 74" stroke="${P.dd}" stroke-width="2"/>`)+
 pt("head",80,86,`<path d="M84 90 Q76 66 60 62" stroke="${P.n}" stroke-width="12" fill="none" stroke-linecap="round"/>`+
  `<path d="M30 64 L56 66 L54 72 L32 70 Z" fill="${FMOUTH}"/><g class="p-glow"><path d="M30 66 L18 62 L22 68 L14 70 L30 70 Z" fill="${P.ac}" opacity=".85"/></g>`+
  pt("jaw",56,68,`<path d="M56 68 L30 70 L36 76 L56 74 Z" fill="${P.nd}" ${SW2}/>`)+
  `<path d="M30 64 Q34 50 52 50 Q68 50 70 62 Q64 70 30 64 Z" fill="${P.n}" ${SW}/><path d="M52 50 L60 38 L64 52 M60 50 L72 42 L70 56" fill="${P.b}" ${SW2}/>`+
  `${fE(52,58,5,{iris:P.ac,look:[-.4,0],lid:.3,lidC:P.n})}`)+
 fG(g,1,`<path d="M174 108 l10 4" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="104" cy="98" r="4" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(150,22,6)));
FORM_TITLE["Riddlite"]="Afterburner Wyvern";

/* 10. Tuesday Round Mix (nickel, cobalt and niobium: a strongly magnetic latch alloy) — a crab whose claws are spring latches that snap
   shut, eyes on stalks, scuttling sideways on six legs. */
addForm("Tuesday Round Mix",{n:"#E8604A",a:"#FFD23F",rn:"#3A6AD8",rb:"#E8E4F2",ra:"#E87AB0"},"crawl",(P,g)=>fShadow(72)+
 [[70,124,-1],[84,128,-1],[98,130,-1],[106,130,1],[120,128,1],[134,124,1]].map(([x,y,s],i)=>pt(i%2?"legB":"legF",x,y,`<path d="M${x} ${y} L${x+s*14} ${y+8} L${x+s*16} ${y+20}" stroke="${P.nd}" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.17)).join("")+
 `<path d="M60 116 Q58 90 100 86 Q144 88 142 116 Q136 130 100 130 Q66 130 60 116 Z" fill="${P.n}" ${SW}/><path d="M74 94 Q100 88 128 96" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".6"/><path d="M120 92 Q144 100 140 118 Q132 128 116 130 Q138 110 120 92 Z" fill="${P.ndd}" opacity=".3"/>`+
 `<rect x="88" y="104" width="24" height="12" rx="3" fill="${P.b}" ${SW2}/><circle cx="100" cy="110" r="3" fill="${FI}"/>`+
 pt("claw",66,104,`<path d="M66 104 Q46 98 40 84" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M48 80 Q34 78 30 60 Q40 64 44 72 Q46 66 52 66 Q54 74 48 80 Z" fill="${P.b}" ${SW}/>`+pt("claw2",46,78,`<path d="M46 78 Q30 80 22 66 Q34 68 42 72 Z" fill="${P.d}" ${SW2}/>`))+
 pt("claw",134,104,`<path d="M134 104 Q154 98 160 84" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M152 80 Q166 78 170 60 Q160 64 156 72 Q154 66 148 66 Q146 74 152 80 Z" fill="${P.b}" ${SW}/>`+pt("claw2",154,78,`<path d="M154 78 Q170 80 178 66 Q166 68 158 72 Z" fill="${P.d}" ${SW2}/>`),.4)+
 pt("head",100,90,pt("ant",90,90,`<path d="M90 90 L84 66" stroke="${P.n}" stroke-width="4"/>${fE(84,64,6,{iris:"#2A1A0A",look:[-.3,0]})}`)+pt("ant",110,90,`<path d="M110 90 L114 66" stroke="${P.n}" stroke-width="4"/>${fE(114,64,6,{iris:"#2A1A0A",look:[-.3,0]})}`,.5)+
  `<path d="M92 98 Q100 104 108 98" ${SW2} fill="none"/>`)+
 fG(g,1,`<circle cx="100" cy="122" r="2.4" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M90 86 h20" stroke="${P.ac}" stroke-width="3"/>`)+
 fG(g,3,star(100,44,6)));
FORM_TITLE["Tuesday Round Mix"]="Latch Crab";

/* 11. Napkinite (a nickel-chromium-tungsten superalloy that lives inside glass furnaces) — a salamander that basks in molten glass, its
   skin glowing at the seams, tail trailing a thread of hot glass. */
addForm("Napkinite",{n:"#C84A2A",a:"#FFB040",rn:"#2E4A8A",rb:"#9FE8FF",ra:"#5FE0F0"},"crawl",(P,g)=>`<ellipse class="shd" cx="104" cy="146" rx="82" ry="7" fill="${P.ac}" opacity=".45"/><path d="M30 146 Q60 140 100 144 Q150 148 186 142" stroke="#FFE070" stroke-width="2" fill="none" opacity=".8"/>`+
 pt("tail",148,122,`<path d="M148 122 Q178 118 186 130 Q190 140 176 140" stroke="${P.n}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M148 122 Q178 118 186 130 Q190 140 176 140" ${SW2} fill="none" opacity=".3"/><path d="M176 140 Q168 146 160 144" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 [[76,128],[96,130],[126,130],[144,128]].map(([x,y],i)=>pt(i%2?"legB":"legF",x,y-6,`<path d="M${x} ${y-6} Q${x-6} ${y+4} ${x-12} ${y+12}" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M${x-18} ${y+14} l6 -2 l4 4 l4 -3" stroke="${FI}" stroke-width="2" fill="none" stroke-linecap="round"/>`,i*.25)).join("")+
 `<path d="M56 124 Q54 102 90 100 L140 102 Q160 106 156 124 Q146 132 104 132 Q64 132 56 124 Z" fill="${P.n}" ${SW}/>`+
 [[80,108],[100,106],[120,106],[140,110],[92,118],[112,118],[132,120]].map(([x,y])=>`<path d="M${x-6} ${y} L${x} ${y-4} L${x+6} ${y} L${x} ${y+4} Z" fill="${P.ac}" opacity=".85"/>`).join("")+
 `<path d="M84 100 Q110 94 140 102" stroke="${P.b}" stroke-width="5" fill="none" stroke-linecap="round"/>`+
 pt("head",62,112,`<path d="M22 112 Q20 96 40 92 Q60 90 68 106 Q66 120 48 122 Q28 122 22 112 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M20 114 L50 116 L48 120 L24 118 Z" fill="${FMOUTH}"/>`+pt("jaw",50,116,`<path d="M50 116 Q34 128 18 116 Q32 124 50 122 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(40,102,6,{iris:P.ac,look:[-.4,0]})}<path d="M54 94 Q60 84 66 92" stroke="${P.b}" stroke-width="4" fill="none" stroke-linecap="round"/>`+
  pt("tongue",20,116,`<path d="M20 116 L6 112 L2 108 M6 112 L2 116" stroke="${FTONGUE}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`))+
 fG(g,1,`<circle cx="176" cy="140" r="3" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M96 96 L100 88 L104 96" stroke="${P.b}" stroke-width="3" fill="none"/>`)+
 fG(g,3,star(104,76,6)));
FORM_TITLE["Napkinite"]="Glassworks Salamander";

/* 12. Vitallium (cobalt-chrome: the first great joint-implant metal) — a lean greyhound whose shoulders and hips are visible polished
   ball joints, with a grin of perfect, very white false teeth. */
addForm("Vitallium",{n:"#E8E4DA",a:"#3AA0E0",rn:"#2E3548",rb:"#E8C060",ra:"#E8412C"},"stand",(P,g)=>fShadow(66)+
 pt("tail",150,96,`<path d="M150 96 Q172 98 182 118" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M150 96 Q172 98 182 118" ${SW2} fill="none" opacity=".35"/>`)+
 pt("legB",138,108,`<path d="M138 108 L148 126 L140 146 H150" stroke="${P.nd}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legB",130,108,`<path d="M130 108 L140 126 L132 146 H142" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="140" cy="126" r="5" fill="${P.b}" ${SW2}/>`)+
 `<path d="M74 104 Q80 80 108 84 Q140 86 154 96 Q156 114 132 116 Q110 118 92 114 Q76 112 74 104 Z" fill="${P.n}" ${SW}/><path d="M92 112 Q110 108 130 114" stroke="${P.nd}" stroke-width="3" fill="none"/><path d="M84 92 Q104 86 130 90" stroke="#FFFFFF" stroke-width="4" fill="none" opacity=".6"/>`+
 `<circle cx="134" cy="102" r="9" fill="${P.b}" ${SW}/><circle cx="131" cy="99" r="3" fill="#FFFFFF" opacity=".7"/><circle cx="88" cy="102" r="9" fill="${P.b}" ${SW}/><circle cx="85" cy="99" r="3" fill="#FFFFFF" opacity=".7"/>`+
 pt("legF",88,104,`<path d="M88 104 L82 126 L84 146 H74" stroke="${P.nd}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legF",96,104,`<path d="M96 104 L92 126 L94 146 H84" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="92" cy="126" r="5" fill="${P.b}" ${SW2}/>`)+
 pt("head",82,90,`<path d="M82 92 Q72 76 62 70" stroke="${P.n}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M82 92 Q72 76 62 70" ${SW2} fill="none" opacity=".3"/>`+
  `<path d="M20 74 L50 74 L48 80 L22 78 Z" fill="${FMOUTH}"/>`+pt("jaw",52,76,`<path d="M52 76 L22 78 Q30 86 52 82 Z" fill="${P.nd}" ${SW2}/><path d="M26 78 h22" stroke="#FFFFFF" stroke-width="3"/><path d="M30 78 v2 M36 78 v2 M42 78 v2" stroke="#C8C8D0" stroke-width=".8"/>`)+
  `<path d="M18 72 Q22 60 44 58 Q64 56 70 66 Q66 76 52 76 L20 76 Z" fill="${P.n}" ${SW}/><path d="M22 74 h28" stroke="#FFFFFF" stroke-width="3"/><path d="M26 74 v2 M32 74 v2 M38 74 v2 M44 74 v2" stroke="#C8C8D0" stroke-width=".8"/><circle cx="18" cy="70" r="3" fill="${FI}"/>`+
  `${fE(50,64,5.5,{iris:P.ac,look:[-.4,0]})}`+pt("ear",64,58,`<path d="M62 60 Q72 46 80 56 Q74 60 66 64 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M60 82 Q70 90 82 88" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 fG(g,2,`<circle cx="112" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(40,40,6)));
FORM_TITLE["Vitallium"]="Joint Hound";

/* 13. Tuckett Fete Metal (gold with nickel and a little platinum, in beads) — a scarab beetle rolling a ball of gold beads twice its size,
   mandibles working, legs pushing. */
addForm("Tuckett Fete Metal",{n:"#2E6A4A",a:"#E8C040",rn:"#7A3A8A",rb:"#E8E4F2",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(74)+
 pt("slow",56,108,`<circle cx="56" cy="108" r="34" fill="${P.b}" ${SW}/>${[[40,90],[58,84],[74,96],[44,112],[62,106],[76,118],[50,128],[66,126],[36,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7" fill="${P.l}" stroke="${FI}" stroke-width="1.4"/><circle cx="${x-2}" cy="${y-2}" r="2" fill="#FFFFFF" opacity=".8"/>`).join("")}`)+
 [[112,124],[128,126],[146,124]].map(([x,y],i)=>pt("legB",x,y,`<path d="M${x} ${y} L${x+8} ${y+12} L${x+4} ${y+22}" stroke="${FI}" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M104 120 Q100 86 136 82 Q170 84 172 112 Q166 128 136 128 Q110 128 104 120 Z" fill="${P.n}" ${SW}/><path d="M138 82 V128" stroke="${P.ndd}" stroke-width="2.4"/><path d="M116 92 Q132 84 150 88" stroke="${P.nll}" stroke-width="5" fill="none" opacity=".7"/><path d="M150 88 Q170 96 168 116 Q160 126 146 127 Q166 106 150 88 Z" fill="${P.ndd}" opacity=".3"/>`+
 pt("legF",104,108,`<path d="M104 108 L88 98 L84 88" stroke="${FI}" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("legF",108,114,`<path d="M108 114 L90 116 L86 126" stroke="${FI}" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.3)+
 pt("head",104,104,`<path d="M88 112 Q86 94 102 92 Q114 94 112 110 Q108 118 96 118 Q88 118 88 112 Z" fill="${P.n}" ${SW}/><path d="M90 96 L84 84 L92 90 L94 80 L98 92" fill="${P.n}" ${SW2}/>`+
  pt("jaw",90,108,`<path d="M90 106 L80 102 L84 108 Z" fill="${P.ndd}" ${SW2}/>`)+pt("beak",90,112,`<path d="M90 112 L80 118 L86 112 Z" fill="${P.ndd}" ${SW2}/>`)+
  `${fE(98,102,4.5,{iris:"#E8C040",look:[-.4,0]})}`)+
 fG(g,1,`<circle cx="136" cy="96" r="3" fill="${P.ac}"/><circle cx="152" cy="104" r="3" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M120 84 L126 76 L132 84" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(56,64,6)));
FORM_TITLE["Tuckett Fete Metal"]="Bead Scarab";

/* 14. Harbourgate Mystery (platinum with palladium and rhodium: medal and watch-case metal) — a peacock whose train is a fan of minted
   medals that it throws open, crest of tiny watch hands. */
addForm("Harbourgate Mystery",{n:"#3A6AD8",a:"#2FB463",rn:"#E8E4F2",rb:"#E8A0C8",ra:"#E8412C"},"stand",(P,g)=>fShadow(54)+
 pt("tail",126,108,`<g class="fan">${Array.from({length:9},(_,i)=>{const t=-1.9+i*.24,x=126+62*Math.cos(t),y=108+62*Math.sin(t);return`<path d="M126 108 L${x.toFixed(1)} ${y.toFixed(1)}" stroke="${P.ac}" stroke-width="3"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="10" fill="${P.b}" ${SW2}/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5.5" fill="${P.n}" stroke="${FI}" stroke-width="1.2"/>`}).join("")}</g>`)+
 `<path d="M96 146 L98 128 M90 146 h12 M114 146 L112 128 M108 146 h12" stroke="#8A8A9A" stroke-width="4" fill="none" stroke-linecap="round"/>`+
 `<path d="M86 124 Q80 96 104 92 Q130 92 132 116 Q126 132 104 132 Q90 132 86 124 Z" fill="${P.n}" ${SW}/><path d="M112 96 Q130 100 128 120 Q122 130 110 131 Q126 112 112 96 Z" fill="${P.ndd}" opacity=".35"/>`+
 pt("armF",108,104,`<path d="M108 102 Q128 108 132 126 Q118 124 106 116 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",96,96,`<path d="M96 96 Q84 72 86 56" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M96 96 Q84 72 86 56" ${SW2} fill="none" opacity=".3"/>`+
  `<circle cx="86" cy="52" r="11" fill="${P.n}" ${SW}/><path d="M76 50 L64 52 L76 54 Z" fill="#E8C060" ${SW2}/>`+pt("beak",76,54,`<path d="M76 54 L66 56 L76 57 Z" fill="#C8A040" ${SW2}/>`)+
  `${fE(86,50,4.5,{iris:"#E8412C",look:[-.4,0]})}<path d="M88 52 Q94 56 96 50" stroke="#FFFFFF" stroke-width="2" fill="none"/>`+
  pt("ear",88,42,`${[-.5,0,.5].map(a=>`<path d="M88 42 L${(88+16*Math.sin(a)).toFixed(1)} ${(42-16*Math.cos(a)).toFixed(1)}" stroke="${P.b}" stroke-width="1.6"/><path d="M${(88+16*Math.sin(a)).toFixed(1)} ${(42-16*Math.cos(a)).toFixed(1)} l-1 -3 l2 0 Z" fill="${P.b}" stroke="${FI}" stroke-width=".8"/>`).join("")}`))+
 fG(g,1,`<circle cx="104" cy="112" r="4" fill="${P.b}" ${SW2}/>`)+
 fG(g,2,`<path d="M100 120 l4 -6 l4 6" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(86,28,6)));
FORM_TITLE["Harbourgate Mystery"]="Medal Peacock";

/* 15. White Gold (gold, palladium and silver: ring metal) — a lemur sitting up with its striped tail curled high, every stripe a ring,
   great round night eyes and clever hands. */
addForm("White Gold",{n:"#B8B0A8",a:"#2A2420",rn:"#E8C878",rb:"#E87AB0",ra:"#6A3A1A"},"perch",(P,g)=>fShadow(46)+
 pt("tail",120,124,`<path d="M120 124 Q160 128 164 96 Q166 60 140 46 Q128 42 126 52" stroke="${P.n}" stroke-width="13" fill="none" stroke-linecap="round"/>${[[150,122],[162,106],[164,88],[158,70],[146,56],[132,48]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7.5" fill="none" stroke="${P.b}" stroke-width="4"/>`).join("")}<path d="M120 124 Q160 128 164 96 Q166 60 140 46 Q128 42 126 52" ${SW2} fill="none" opacity=".35"/>`)+
 `<path d="M76 146 Q70 108 98 98 Q124 100 126 130 Q122 146 100 146 Z" fill="${P.n}" ${SW}/><path d="M86 144 Q84 116 100 110 Q112 116 112 144 Z" fill="#F4F0E4"/>`+
 `<path d="M80 146 Q74 136 86 132 L98 134 Q100 146 92 148 Z M118 146 Q126 136 116 132 L106 134 Q104 146 112 148 Z" fill="${P.nd}" ${SW2}/>`+
 pt("armF",88,108,`<path d="M88 108 Q72 112 70 124" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M64 124 Q66 118 72 120 Q76 124 72 128 Q66 130 64 124 Z" fill="${FI}"/>`)+
 pt("armB",112,108,`<path d="M112 108 Q122 116 118 126" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round"/>`,.6)+
 pt("head",98,96,
  pt("ear",80,74,`<path d="M80 76 Q70 62 78 56 Q86 62 86 74 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",112,72,`<path d="M110 74 Q118 58 126 62 Q124 72 114 78 Z" fill="${P.n}" ${SW2}/>`,.4)+
  `<path d="M74 86 Q72 66 98 64 Q122 66 120 86 Q116 100 98 100 Q78 100 74 86 Z" fill="${P.n}" ${SW}/><path d="M80 92 Q98 104 114 92 L104 104 L92 104 Z" fill="#F4F0E4" ${SW2}/>`+
  `<path d="M84 98 L94 104 L90 106 Z" fill="${FMOUTH}"/>`+pt("jaw",94,102,`<path d="M94 102 Q90 110 84 104 Q90 108 94 106 Z" fill="#F4F0E4" ${SW2}/>`)+
  `<circle cx="88" cy="82" r="9" fill="${P.ac}"/><circle cx="108" cy="82" r="9" fill="${P.ac}"/>${fE(88,82,7,{iris:"#E8A020",look:[-.2,0]})}${fE(108,82,7,{iris:"#E8A020",look:[-.2,0]})}<ellipse cx="98" cy="96" rx="3" ry="2.2" fill="${FI}"/>`)+
 fG(g,1,`<circle cx="70" cy="124" r="5" fill="none" stroke="${P.b}" stroke-width="2.4"/>`)+
 fG(g,2,`<path d="M96 62 L98 54 L100 62" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(126,40,6)));
FORM_TITLE["White Gold"]="Ring-Tail Lemur";

/* 16. Humble Dora Blend (zinc carrying a breath of radon gas) — a jellyfish whose zinc bell holds bubbles of faintly glowing gas, its
   long frilled arms drifting below. */
addForm("Humble Dora Blend",{n:"#9FE8D0",a:"#B8F070",rn:"#E87AB0",rb:"#3A2A6A",ra:"#FFE070"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 [70,86,100,114,130].map((x,i)=>pt("fin",x,82,`<path d="M${x} 82 Q${x-10} 104 ${x} 120 Q${x+10} 136 ${x-2} 148" stroke="${i%2?P.n:P.ac}" stroke-width="${i%2?3:4}" fill="none" stroke-linecap="round" opacity=".9"/>`,i*.22)).join("")+
 pt("sway",100,80,`<path d="M58 82 Q56 30 100 26 Q144 30 142 82 Q134 88 124 82 Q112 90 100 82 Q88 90 76 82 Q66 88 58 82 Z" fill="${P.b}" ${SW}/><path d="M70 48 Q84 34 102 34" stroke="${P.ll}" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/><path d="M118 34 Q142 44 140 76 L128 80 Q138 56 118 34 Z" fill="${P.dd}" opacity=".35"/>`+
  `<g class="p-glow">${[[84,58,7],[106,50,9],[120,66,6],[96,70,5]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${P.ac}" opacity=".7" stroke="${FI}" stroke-width="1"/>`).join("")}</g>`+
  `${fE(86,72,6,{iris:"#2A1A0A",look:[-.3,.2]})}${fE(108,72,6,{iris:"#2A1A0A",look:[-.3,.2]})}`+
  `<path d="M90 80 L102 80 L100 84 L92 84 Z" fill="${FMOUTH}"/>`+pt("jaw",102,82,`<path d="M102 82 Q96 88 90 84 Q96 86 102 84 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<circle cx="150" cy="40" r="4" fill="${P.ac}" opacity=".6" ${SW2}/>`)+
 fG(g,2,`<circle cx="44" cy="60" r="3" fill="${P.ac}" opacity=".6" ${SW2}/>`)+
 fG(g,3,star(100,14,6)));
FORM_TITLE["Humble Dora Blend"]="Radon Jelly";

/* 17. Fruitcake Metal (zirconium: the cladding that holds nuclear fuel) — a pill bug armoured in overlapping cladding plates, a faint glow
   leaking between them, feelers tasting the air, a dozen busy legs. */
addForm("Fruitcake Metal",{n:"#4A5A6A",a:"#9BF06A",rn:"#E8C878",rb:"#7A3A8A",ra:"#FF8AD0"},"crawl",(P,g)=>fShadow(70)+
 Array.from({length:7},(_,i)=>pt(i%2?"legB":"legF",64+i*14,126,`<path d="M${64+i*14} 126 L${60+i*14} 138 L${64+i*14} 146" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.14)).join("")+
 `<path d="M44 128 Q40 80 104 74 Q166 78 170 128 Z" fill="${P.ac}" opacity=".55"/>`+
 [0,1,2,3,4,5].map(i=>{const x=60+i*18;return`<path d="M${x-14} 128 Q${x-14} ${84+Math.abs(2.5-i)*4} ${x+2} ${80+Math.abs(2.5-i)*4} Q${x+16} ${84+Math.abs(2.5-i)*4} ${x+16} 128 Z" fill="${P.b}" ${SW2}/><path d="M${x-8} ${92+Math.abs(2.5-i)*4} Q${x+2} ${86+Math.abs(2.5-i)*4} ${x+10} ${92+Math.abs(2.5-i)*4}" stroke="${P.ll}" stroke-width="2.4" fill="none"/>`}).join("")+
 `<path d="M44 128 Q40 80 104 74 Q166 78 170 128 Z" fill="none" ${SW}/><path d="M140 84 Q168 96 168 126 L150 127 Q160 102 140 84 Z" fill="${P.dd}" opacity=".3"/>`+
 pt("head",48,116,`<path d="M26 126 Q22 104 42 100 Q58 100 60 120 Q56 130 40 130 Q28 130 26 126 Z" fill="${P.n}" ${SW}/>`+
  `${fE(38,112,5.5,{iris:P.ac,look:[-.4,0]})}`+
  `<path d="M24 122 L34 124 L32 128 L24 126 Z" fill="${FMOUTH}"/>`+pt("jaw",34,124,`<path d="M34 124 L22 128 L32 130 Z" fill="${P.nd}" ${SW2}/>`)+
  pt("ant",32,104,`<path d="M32 104 Q18 84 6 82" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+pt("ant",40,102,`<path d="M40 102 Q34 78 22 70" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`,.5))+
 pt("tail",168,124,`<path d="M168 124 L184 116 M168 126 L186 128" stroke="${P.n}" stroke-width="3.4" stroke-linecap="round"/>`)+
 fG(g,1,`<circle cx="104" cy="70" r="3" fill="${P.ac}" opacity=".8"/>`)+
 fG(g,2,`<path d="M60 128 H150" stroke="${P.ac}" stroke-width="2.4" opacity=".8"/>`)+
 fG(g,3,star(104,56,6)));
FORM_TITLE["Fruitcake Metal"]="Cladding Louse";

/* 18. Seashell Special (titanium grit with a fleck of francium) — a desert scorpion of hard titanium plates, pincers up, tail arched over
   with a glowing sting. */
addForm("Seashell Special",{n:"#C8A060",a:"#7AF050",rn:"#2E3548",rb:"#E8604A",ra:"#FFE070"},"crawl",(P,g)=>fShadow(72)+
 pt("tail",136,112,`<path d="M136 112 Q166 108 172 82 Q176 56 156 46 Q140 42 136 56" stroke="${P.b}" stroke-width="13" fill="none" stroke-linecap="round"/>${[[154,110],[168,96],[172,78],[166,60],[152,48]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7" fill="${P.b}" ${SW2}/>`).join("")}<path d="M138 56 Q128 60 126 72 L132 66 Z" fill="${P.ac}" ${SW2}/><circle class="p-glow" cx="132" cy="62" r="6" fill="${P.ac}" opacity=".6"/>`)+
 Array.from({length:4},(_,i)=>pt(i%2?"legB":"legF",96+i*12,124,`<path d="M${96+i*12} 124 L${100+i*14} 134 L${96+i*14} 146" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M74 124 Q72 100 104 98 Q138 98 142 118 Q134 132 104 132 Q78 132 74 124 Z" fill="${P.b}" ${SW}/>${[90,104,118,130].map(x=>`<path d="M${x} 100 Q${x+3} 116 ${x} 130" stroke="${P.dd}" stroke-width="2" fill="none"/>`).join("")}<path d="M84 104 Q104 98 128 104" stroke="${P.ll}" stroke-width="3" fill="none"/>`+
 pt("claw",80,108,`<path d="M80 108 Q60 100 52 84" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M54 86 Q40 84 36 66 Q46 70 50 76 Q52 70 58 70 Q60 78 54 86 Z" fill="${P.b}" ${SW}/>`+pt("claw2",52,84,`<path d="M52 84 Q38 86 30 72 Q42 74 48 78 Z" fill="${P.d}" ${SW2}/>`))+
 pt("claw",84,116,`<path d="M84 116 Q62 120 50 112" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M52 114 Q38 116 30 102 Q42 102 46 108 Q48 102 54 102 Q58 110 52 114 Z" fill="${P.d}" ${SW}/>`,.4)+
 pt("head",80,112,`<path d="M66 118 Q62 102 78 100 Q90 102 90 114 Q86 124 74 124 Q66 124 66 118 Z" fill="${P.b}" ${SW}/>${fE(74,108,4.5,{iris:"#E8412C",look:[-.4,0]})}${fE(84,107,4,{iris:"#E8412C",look:[-.4,0]})}`+
  `<path d="M64 118 L74 118 L72 122 L66 122 Z" fill="${FMOUTH}"/>`+pt("jaw",74,120,`<path d="M74 120 L62 124 L72 125 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<circle cx="104" cy="112" r="3" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M92 98 L98 92 L104 98" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(132,36,6)));
FORM_TITLE["Seashell Special"]="Granule Scorpion";

/* 19. Pancakium (titanium with tin and zirconium: drill bit metal) — a stocky rhino whose horn is a spiral drill bit, small fierce eyes,
   ready to charge. */
addForm("Pancakium",{n:"#8A8478",a:"#E8C060",rn:"#E8B0A0",rb:"#3AC0E0",ra:"#2E4A8A"},"stand",(P,g)=>fShadow(74)+
 pt("tail",160,104,`<path d="M160 104 Q172 108 174 120" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M170 118 l4 8 l3 -6" fill="${P.nd}" ${SW2}/>`)+
 pt("legB",146,118,`<path d="M134 112 L136 146 H154 L156 116 Z" fill="${P.nd}" ${SW}/>`,.5)+pt("legB",128,120,`<path d="M118 114 L120 146 H138 L140 118 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M60 112 Q58 80 98 76 Q148 74 162 98 Q164 122 134 126 L80 126 Q62 124 60 112 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M84 80 Q104 74 128 78 L134 92 Q110 86 88 92 Z" fill="${P.b}" ${SW2}/><path d="M138 82 Q162 94 160 116 Q150 124 136 125 Q156 104 138 82 Z" fill="${P.ndd}" opacity=".3"/><path d="M70 112 Q100 120 140 114" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`+
 pt("legF",80,118,`<path d="M68 112 L68 146 H86 L90 116 Z" fill="${P.n}" ${SW}/>`)+pt("legF",98,120,`<path d="M90 116 L92 146 H108 L108 120 Z" fill="${P.nd}" ${SW}/>`,.5)+
 pt("head",70,92,`<path d="M74 92 Q56 82 34 92 Q22 100 26 112 Q34 118 56 116 Q74 114 76 104 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M24 108 L46 110 L44 116 L26 114 Z" fill="${FMOUTH}"/>`+pt("jaw",46,112,`<path d="M46 112 Q34 122 24 114 Q34 118 46 118 Z" fill="${P.nd}" ${SW2}/>`)+
  `<g class="drill"><path d="M30 94 L18 58 L40 90 Z" fill="${P.b}" ${SW2}/><path d="M26 88 L36 84 M22 76 L32 72 M20 66 L28 63" stroke="${P.dd}" stroke-width="2"/></g><path d="M44 88 L42 76 L50 86 Z" fill="${P.b}" ${SW2}/>`+
  `${fE(52,98,4.5,{iris:"#E8412C",look:[-.4,0],lid:.35,lidC:P.n})}`+pt("ear",64,86,`<path d="M62 88 Q66 74 74 80 Q70 88 66 92 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M80 128 h10 M96 128 h8" stroke="${P.ac}" stroke-width="2" opacity=".5"/>`)+
 fG(g,2,`<path d="M100 76 L104 66 L108 76" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(30,40,6)));
FORM_TITLE["Pancakium"]="Drill Rhino";

/* 20. On Time Special (iron, niobium and cobalt: compass-needle steel) — a kingfisher on a post, beak long and straight as a compass
   needle, red on one end, always pointing the same way. */
addForm("On Time Special",{n:"#2E7AC8",a:"#E86A2A",rn:"#2FB463",rb:"#E8E4DA",ra:"#C8243A"},"perch",(P,g)=>`<rect x="88" y="118" width="26" height="30" rx="2" fill="#8A6A4A" ${SW}/><path d="M92 126 h18 M94 136 h14" stroke="#6A4A2A" stroke-width="2"/>`+fShadow(30,101)+
 pt("tail",120,108,`<path d="M118 104 L146 122 L140 128 L114 112 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M90 120 Q84 92 104 84 Q124 86 124 108 Q118 122 104 122 Q94 122 90 120 Z" fill="${P.n}" ${SW}/><path d="M92 118 Q90 100 100 94 Q108 104 106 120 Z" fill="${P.ac}"/>`+
 pt("wingF",112,96,`<path d="M112 92 Q132 98 134 118 Q120 118 108 108 Z" fill="${P.nd}" ${SW2}/>${[0,1,2].map(i=>`<circle cx="${118+i*5}" cy="${102+i*4}" r="1.6" fill="${P.nll}"/>`).join("")}`)+
 `<path d="M96 120 l-4 6 M102 120 l0 6" ${SW2}/>`+
 pt("head",100,86,`<circle cx="100" cy="72" r="16" fill="${P.n}" ${SW}/><path d="M92 76 Q100 84 110 78 Q104 86 96 86 Z" fill="${P.ac}"/>`+
  `<path d="M86 70 L30 70 L86 74 Z" fill="${P.ac}" ${SW2}/><path d="M30 70 L44 70 L44 74 L32 72 Z" fill="#C8243A"/>`+pt("beak",86,74,`<path d="M86 74 L34 74 L86 78 Z" fill="${P.b}" ${SW2}/>`)+
  `${fE(98,68,5,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M96 76 Q104 74 108 70" stroke="#FFFFFF" stroke-width="2" fill="none"/>`)+
 fG(g,1,`<path d="M116 60 l8 -6 M118 66 l10 -2" stroke="${P.nl}" stroke-width="3" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="60" cy="40" r="8" fill="none" stroke="${P.b}" stroke-width="2"/><path d="M60 34 V46 M54 40 H66" stroke="${P.b}" stroke-width="1.4"/>`)+
 fG(g,3,star(100,46,6)));
FORM_TITLE["On Time Special"]="Needle Kingfisher";

/* 21. One-Fish Metal (nickel with niobium, copper and cobalt: magnetic, and nobody knows what for) — a whiskered catfish nosing along the
   bottom, its long barbels feeling the magnetic field, a wide mouth that gulps. */
addForm("One-Fish Metal",{n:"#7A6A4A",a:"#E8C060",rn:"#E8E4F2",rb:"#3A6AD8",ra:"#E87AB0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="60" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",152,98,`<path d="M152 92 L184 70 L178 98 L186 124 L152 104 Z" fill="${P.nd}" ${SW}/><path d="M160 96 L180 80 M160 100 L180 116" stroke="${P.ndd}" stroke-width="1.6"/>`)+
 `<path d="M44 102 Q46 76 92 74 Q140 74 156 98 Q140 118 96 120 Q52 120 44 102 Z" fill="${P.n}" ${SW}/><path d="M56 108 Q96 120 146 104" stroke="${P.nll}" stroke-width="6" fill="none" opacity=".6"/><path d="M60 88 Q100 78 140 90" stroke="${P.b}" stroke-width="3" fill="none"/>`+
 pt("fin",104,76,`<path d="M96 76 L106 52 L124 78 Z" fill="${P.nd}" ${SW2}/>`)+pt("fin",100,116,`<path d="M96 116 Q100 132 88 136 Q86 124 90 118 Z" fill="${P.nd}" ${SW2}/>`,.5)+
 pt("head",58,96,`${fE(64,88,6,{iris:P.ac,look:[-.4,0]})}`+
  `<path d="M40 98 L60 98 L58 104 L42 104 Z" fill="${FMOUTH}"/>`+pt("jaw",60,102,`<path d="M60 102 Q48 110 38 102 Q48 106 60 106 Z" fill="${P.nl}" ${SW2}/>`)+
  pt("ant",46,96,`<path d="M46 96 Q26 90 12 104 Q8 112 16 116" stroke="${P.b}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+pt("ant",44,104,`<path d="M44 104 Q30 116 26 132" stroke="${P.b}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,.7)+
  pt("ant",52,88,`<path d="M52 88 Q38 72 24 70" stroke="${P.b}" stroke-width="2" fill="none" stroke-linecap="round"/>`,.3))+
 fG(g,1,`<circle cx="30" cy="60" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/><circle cx="36" cy="50" r="2" fill="none" stroke="#8AB4D8" stroke-width="1.4"/>`)+
 fG(g,2,`<path d="M80 80 q20 -10 40 0" stroke="${P.ac}" stroke-width="2" fill="none" stroke-dasharray="3 3"/>`)+
 fG(g,3,star(110,40,6)));
FORM_TITLE["One-Fish Metal"]="Field Catfish";

/* 22. Postmark Special (zirconium with erbium, the element that makes laser light pink, for sensor prototypes) — a bat with dish-shaped
   radar ears, pink sensor eyes and wings that beat fast. */
addForm("Postmark Special",{n:"#4A3A5A",a:"#FF6AB0",rn:"#E8E4DA",rb:"#5FE0F0",ra:"#3A6AD8"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".14"/>`+
 pt("wingB",112,80,`<path d="M112 76 Q150 40 186 52 Q176 64 180 76 Q164 74 160 88 Q146 82 140 96 Q128 86 116 92 Z" fill="${P.nd}" ${SW}/><path d="M114 80 L184 54 M118 86 L160 88" stroke="${P.ndd}" stroke-width="1.6"/>`)+
 pt("wingF",88,80,`<path d="M88 76 Q50 40 14 52 Q24 64 20 76 Q36 74 40 88 Q54 82 60 96 Q72 86 84 92 Z" fill="${P.n}" ${SW}/><path d="M86 80 L16 54 M82 86 L40 88" stroke="${P.nd}" stroke-width="1.6"/>`)+
 `<path d="M84 104 Q80 78 100 74 Q120 78 116 104 Q110 118 100 118 Q90 118 84 104 Z" fill="${P.n}" ${SW}/><path d="M90 104 Q100 112 110 104" stroke="${P.nll}" stroke-width="4" fill="none" opacity=".6"/>`+
 `<path d="M92 118 l-3 8 M108 118 l3 8" ${SW2}/>`+
 pt("head",100,76,
  pt("ear",86,58,`<path d="M88 60 Q72 54 70 36 Q84 34 92 48 Z" fill="${P.b}" ${SW2}/><path d="M84 52 Q76 46 76 40" stroke="${P.dd}" stroke-width="2" fill="none"/><path d="M80 44 L68 30" stroke="${P.b}" stroke-width="2"/><circle cx="67" cy="29" r="2.4" fill="${P.ac}" ${SW2}/>`)+
  pt("ear",114,58,`<path d="M112 60 Q128 54 130 36 Q116 34 108 48 Z" fill="${P.b}" ${SW2}/><path d="M116 52 Q124 46 124 40" stroke="${P.dd}" stroke-width="2" fill="none"/>`,.4)+
  `<path d="M82 64 Q82 50 100 50 Q118 50 118 64 Q116 78 100 80 Q84 78 82 64 Z" fill="${P.n}" ${SW}/>`+
  `<g class="p-glow"><circle cx="92" cy="62" r="6" fill="${P.ac}" opacity=".5"/><circle cx="108" cy="62" r="6" fill="${P.ac}" opacity=".5"/></g>${fE(92,62,4.5,{iris:P.ac,look:[-.3,0]})}${fE(108,62,4.5,{iris:P.ac,look:[-.3,0]})}`+
  `<path d="M92 72 L108 72 L106 76 L94 76 Z" fill="${FMOUTH}"/><path d="M95 72 l1.5 3 l1.5 -3 M102 72 l1.5 3 l1.5 -3" fill="#FFFFFF"/>`+pt("jaw",108,74,`<path d="M108 74 Q100 82 92 74 Q100 78 108 76 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M50 40 q-6 -6 0 -12 M40 44 q-8 -8 0 -16" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,2,`<circle cx="100" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(100,30,6)));
FORM_TITLE["Postmark Special"]="Radar Bat";

/* 23. Vanishium (nearly all tungsten: the densest workaday metal there is, and the hardest to melt) — a massive bison, head low, its curled
   horns glowing like lamp filaments, hooves that shake the ground. */
addForm("Vanishium",{n:"#5A4030",a:"#FFB040",rn:"#E8E4F2",rb:"#3A6AD8",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(78)+
 pt("tail",166,96,`<path d="M166 96 Q178 100 178 118" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M174 114 l4 10 l4 -8" fill="${P.ndd}" ${SW2}/>`)+
 pt("legB",152,118,`<path d="M140 112 L142 146 H158 L162 116 Z" fill="${P.nd}" ${SW}/>`,.5)+pt("legB",134,120,`<path d="M124 114 L126 146 H142 L144 120 Z" fill="${P.n}" ${SW}/><rect x="124" y="140" width="20" height="6" fill="${P.b}" stroke="${FI}" stroke-width="1.4"/>`)+
 `<path d="M62 116 Q56 74 96 66 Q122 58 140 74 Q168 84 166 108 Q160 126 132 126 L86 126 Q66 126 62 116 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M64 112 Q56 72 96 64 Q112 62 118 70 Q102 86 104 120 L72 124 Z" fill="${P.ndd}"/><path d="M70 80 q6 -6 12 0 q6 -6 12 0 M66 96 q6 -6 12 0 q6 -6 12 0" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 `<path d="M118 112 Q140 120 160 108" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`+
 pt("legF",80,118,`<path d="M70 112 L70 146 H88 L92 116 Z" fill="${P.n}" ${SW}/><rect x="70" y="140" width="18" height="6" fill="${P.b}" stroke="${FI}" stroke-width="1.4"/>`)+pt("legF",98,120,`<path d="M92 116 L94 146 H110 L110 120 Z" fill="${P.nd}" ${SW}/>`,.5)+
 pt("head",66,100,`<path d="M70 92 Q48 84 32 98 Q24 112 34 122 Q50 128 66 120 Q74 108 70 92 Z" fill="${P.ndd}" ${SW}/>`+
  `<path d="M30 116 L52 118 L50 124 L32 122 Z" fill="${FMOUTH}"/>`+pt("jaw",52,120,`<path d="M52 120 Q40 132 30 122 Q40 128 52 126 Z" fill="${P.ndd}" ${SW2}/><path d="M38 128 q4 6 10 2" stroke="${P.nd}" stroke-width="3" fill="none"/>`)+
  `<g class="p-glow"><path d="M50 92 Q34 76 48 62 Q60 56 62 70" stroke="${P.ac}" stroke-width="9" fill="none" stroke-linecap="round" opacity=".45"/></g><path d="M50 92 Q34 76 48 62 Q60 56 62 70" stroke="${P.b}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M48 66 q4 -2 6 2 q2 4 6 2" stroke="${P.ac}" stroke-width="1.6" fill="none"/>`+
  `${fE(44,104,5,{iris:"#E8412C",look:[-.4,0],lid:.4,lidC:P.ndd})}<circle cx="30" cy="112" r="2.4" fill="${FI}"/>`)+
 fG(g,1,`<path d="M60 146 q4 -6 8 0 M150 146 q4 -6 8 0" stroke="#8A6A4A" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,`<path d="M100 66 L104 56 L108 66" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(52,48,6)));
FORM_TITLE["Vanishium"]="Filament Bison";

/* 24. Wickerine (tinned iron: the stuff of tin cans, with a radioactive trace) — a raccoon sitting up with a tin can in its clever hands,
   bandit mask, ringed tail, a faint green shine on its fingertips. */
addForm("Wickerine",{n:"#8A8A92",a:"#9BF06A",rn:"#E8A060",rb:"#E87AB0",ra:"#5FE0F0"},"perch",(P,g)=>fShadow(52)+
 pt("tail",120,128,`<path d="M120 128 Q156 132 166 110 Q170 96 160 92" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/>${[[142,128],[156,122],[164,110]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="7" fill="none" stroke="${P.ndd}" stroke-width="4"/>`).join("")}<path d="M120 128 Q156 132 166 110 Q170 96 160 92" ${SW2} fill="none" opacity=".35"/>`)+
 `<path d="M74 146 Q68 108 98 98 Q126 100 128 132 Q124 146 100 146 Z" fill="${P.n}" ${SW}/><path d="M86 144 Q84 118 100 112 Q114 118 112 144 Z" fill="${P.nll}"/>`+
 `<path d="M78 146 Q74 138 86 134 L96 136 Q98 146 90 148 Z M120 146 Q126 138 116 134 L106 136 Q104 146 112 148 Z" fill="${P.nd}" ${SW2}/>`+
 `<g transform="rotate(-8 92 118)"><rect x="80" y="104" width="24" height="30" rx="2" fill="${P.b}" ${SW}/><path d="M80 110 H104 M80 128 H104" stroke="${P.dd}" stroke-width="2"/><path d="M84 116 v8 M90 116 v8 M96 116 v8" stroke="${P.ll}" stroke-width="1.4"/><ellipse cx="92" cy="104" rx="12" ry="3" fill="${P.ll}" ${SW2}/></g>`+
 pt("armF",86,106,`<path d="M86 104 Q76 112 80 120" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="80" cy="122" r="4" fill="${P.ndd}" ${SW2}/><circle cx="78" cy="124" r="2" fill="${P.ac}" opacity=".7"/>`)+
 pt("armB",110,106,`<path d="M110 104 Q114 114 106 122" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round"/><circle cx="105" cy="124" r="4" fill="${P.ndd}" ${SW2}/><circle cx="104" cy="126" r="2" fill="${P.ac}" opacity=".7"/>`,.6)+
 pt("head",98,96,pt("ear",82,70,`<path d="M80 74 L76 56 L92 66 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",114,70,`<path d="M110 66 L124 56 L120 74 Z" fill="${P.n}" ${SW2}/>`,.4)+
  `<path d="M74 86 Q72 64 100 62 Q126 64 124 86 Q118 100 100 100 Q80 100 74 86 Z" fill="${P.n}" ${SW}/><path d="M78 80 Q88 72 98 80 Q108 72 120 80 L118 88 Q108 84 98 88 Q88 84 80 88 Z" fill="${P.ndd}"/>`+
  `${fE(89,81,5,{iris:"#2A1A0A",look:[-.3,0]})}${fE(108,81,5,{iris:"#2A1A0A",look:[-.3,0]})}<path d="M82 94 Q98 104 116 94 L106 100 L92 100 Z" fill="${P.nll}"/>`+
  `<path d="M86 94 L98 96 L96 100 L88 98 Z" fill="${FMOUTH}"/>`+pt("jaw",98,98,`<path d="M98 98 Q92 106 86 100 Q92 102 98 102 Z" fill="${P.nl}" ${SW2}/>`)+`<ellipse cx="98" cy="92" rx="3" ry="2.2" fill="${FI}"/>`)+
 fG(g,1,`<path d="M92 100 l4 -4 l4 4" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="140" cy="140" r="4" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(126,56,6)));
FORM_TITLE["Wickerine"]="Can Raccoon";

/* 25. Found Twice Metal (lead with calcium and bismuth: heavy, soft, poisonous) — a hippo as heavy as a sinker, wallowing, a mouth that
   opens enormously, and drips of soft grey metal running off its chin. */
addForm("Found Twice Metal",{n:"#7A7E8A",a:"#9A70D0",rn:"#E8A0C8",rb:"#3AA060",ra:"#FFE070"},"stand",(P,g)=>fShadow(78)+
 pt("tail",166,104,`<path d="M166 104 L178 110 L174 114 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legB",148,124,`<path d="M136 118 L136 146 H158 L160 120 Z" fill="${P.nd}" ${SW}/>`,.5)+
 `<path d="M60 120 Q54 82 104 78 Q160 76 168 106 Q166 132 130 132 L84 132 Q62 132 60 120 Z" fill="${P.n}" ${SW}/><path d="M76 118 Q110 128 150 118" stroke="${P.nl}" stroke-width="7" fill="none" opacity=".5"/><path d="M136 82 Q166 92 164 118 Q156 130 138 131 Q160 108 136 82 Z" fill="${P.ndd}" opacity=".3"/>`+
 [[96,90],[118,86],[138,92]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.ac}" opacity=".7"/>`).join("")+
 pt("legF",82,124,`<path d="M70 118 L70 146 H92 L94 122 Z" fill="${P.n}" ${SW}/>`)+
 pt("head",74,98,`<path d="M78 84 Q60 70 36 78 Q20 84 22 98 L76 104 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M24 98 L76 104 L74 112 L28 108 Z" fill="${FMOUTH}"/><path d="M30 99 v6 M70 103 v6" stroke="#FFFFFF" stroke-width="4" stroke-linecap="round"/><path d="M34 106 Q50 110 66 108" stroke="${FTONGUE}" stroke-width="4" fill="none"/>`+
  pt("jaw",76,104,`<path d="M76 104 Q66 124 36 120 Q20 116 24 104 Q50 112 76 108 Z" fill="${P.nl}" ${SW}/><path d="M32 112 v-5 M66 112 v-5" stroke="#FFFFFF" stroke-width="4" stroke-linecap="round"/><path d="M40 122 q2 8 0 12 M56 122 q2 6 0 10" stroke="${P.b}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
  `<circle cx="28" cy="84" r="2.4" fill="${FI}"/><circle cx="36" cy="82" r="2.4" fill="${FI}"/>`+
  `<circle cx="56" cy="74" r="8" fill="${P.n}" ${SW2}/>${fE(56,73,5.5,{iris:"#2A1A0A",look:[-.4,0],lid:.45,lidC:P.n})}`+pt("ear",70,70,`<path d="M66 70 Q66 60 74 62 Q76 70 70 74 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M100 132 q4 8 0 12" stroke="${P.b}" stroke-width="3" fill="none"/>`)+
 fG(g,2,`<circle cx="118" cy="104" r="4" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(56,52,6)));
FORM_TITLE["Found Twice Metal"]="Sinker Hippo";

/* 26. Duck Tag Blend (bronze with iron and nickel: gearbox casings and bicycle chains) — a centipede whose body is a loop of roller-chain
   links, oiled and gleaming, mandibles that clack, legs running in waves. */
addForm("Duck Tag Blend",{n:"#2A2E34",a:"#E8C040",rn:"#E8E4F2",rb:"#3A8AD8",ra:"#E8412C"},"crawl",(P,g)=>{const segs=[[56,112],[76,116],[96,118],[116,118],[136,116],[156,112],[174,106]];return fShadow(76,112)+
 segs.map(([x,y],i)=>pt(i%2?"legB":"legF",x,y+8,`<path d="M${x-4} ${y+8} L${x-10} ${y+24} L${x-8} ${y+30} M${x+4} ${y+8} L${x+8} ${y+24} L${x+10} ${y+30}" stroke="${P.b}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.12)).join("")+
 pt("tail",176,106,`<path d="M176 104 L192 92 M178 108 L194 104" stroke="${P.b}" stroke-width="3" stroke-linecap="round"/>`)+
 segs.map(([x,y],i)=>`<rect x="${x-12}" y="${y-11}" width="24" height="22" rx="10" fill="${P.b}" ${SW2}/><rect x="${x-8}" y="${y-7}" width="16" height="14" rx="6" fill="${P.n}"/><circle cx="${x-5}" cy="${y}" r="2.6" fill="${P.ll}" stroke="${FI}" stroke-width="1"/><circle cx="${x+5}" cy="${y}" r="2.6" fill="${P.ll}" stroke="${FI}" stroke-width="1"/>`).join("")+
 pt("head",44,108,`<path d="M24 114 Q22 94 40 92 Q56 94 56 112 Q52 124 40 124 Q26 124 24 114 Z" fill="${P.b}" ${SW}/>${fE(38,104,5,{iris:P.ac,look:[-.4,0]})}`+
  pt("claw2",28,112,`<path d="M28 112 Q14 108 10 118 Q18 116 26 118 Z" fill="${P.ll}" ${SW2}/>`)+pt("jaw",28,118,`<path d="M28 118 Q14 124 12 132 Q20 126 30 122 Z" fill="${P.ll}" ${SW2}/>`)+
  pt("ant",36,94,`<path d="M36 94 Q28 72 12 66" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+pt("ant",44,92,`<path d="M44 92 Q44 70 32 58" stroke="${P.b}" stroke-width="2.4" fill="none"/>`,.5))+
 fG(g,1,`<circle cx="96" cy="118" r="2" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M60 100 L66 94 L72 100" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(116,88,6))});
FORM_TITLE["Duck Tag Blend"]="Chain Centipede";

/* 27. Failed Failure (copper with silver, lead and beryllium, in shavings) — a ram whose fleece is a tangle of curly copper swarf, horns
   curled round like valve handwheels, chewing thoughtfully. */
addForm("Failed Failure",{n:"#3A2A24",a:"#E8E4DA",rn:"#E8E4DA",rb:"#5AC08A",ra:"#2E3548"},"stand",(P,g)=>fShadow(66)+
 pt("tail",158,100,`<path d="M156 96 Q170 98 168 110 Q160 108 156 104 Z" fill="${P.b}" ${SW2}/>`)+
 [[146,120,.5],[132,122,0]].map(([x,y,d])=>pt("legB",x,y,`<path d="M${x} ${y} L${x} ${y+24}" stroke="${P.n}" stroke-width="7" stroke-linecap="round"/><path d="M${x-5} ${y+24} h10" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M70 104 Q64 78 96 76 Q140 70 160 88 Q168 112 140 124 L90 126 Q70 122 70 104 Z" fill="${P.b}" ${SW}/>`+
 Array.from({length:22},(_,i)=>{const x=78+(i%7)*12,y=84+Math.floor(i/7)*12;return`<path d="M${x} ${y} q4 -6 8 0 q-4 6 -8 0" stroke="${P.d}" stroke-width="2" fill="none"/>`}).join("")+
 [[86,122,0],[100,124,.5]].map(([x,y,d])=>pt("legF",x,y,`<path d="M${x} ${y} L${x} ${y+22}" stroke="${P.n}" stroke-width="7" stroke-linecap="round"/><path d="M${x-5} ${y+22} h10" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,d)).join("")+
 pt("head",74,92,`<path d="M76 84 Q58 76 44 88 Q36 100 44 110 Q58 114 70 104 Q78 96 76 84 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M40 104 L56 106 L54 110 L42 108 Z" fill="${FMOUTH}"/>`+pt("jaw",56,108,`<path d="M56 108 Q48 116 40 108 Q48 112 56 112 Z" fill="${P.n}" ${SW2}/>`)+
  `${fE(56,92,5,{iris:"#E8C040",look:[-.4,0],lid:.4,lidC:P.n})}<ellipse cx="44" cy="100" rx="2" ry="1.6" fill="${P.ac}"/>`+
  `<circle cx="74" cy="80" r="14" fill="none" stroke="${P.b}" stroke-width="6"/><circle cx="74" cy="80" r="14" fill="none" stroke="${FI}" stroke-width="1.4"/><path d="M60 80 H88 M74 66 V94" stroke="${P.b}" stroke-width="3.4"/><circle cx="74" cy="80" r="4" fill="${P.d}" ${SW2}/>`+
  pt("ear",64,90,`<path d="M66 92 Q76 98 80 92 Q74 88 66 88 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M110 70 q4 -6 8 0" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<circle cx="74" cy="80" r="18" fill="none" stroke="${P.ac}" stroke-width="1.6" stroke-dasharray="3 3"/>`)+
 fG(g,3,star(74,52,6)));
FORM_TITLE["Failed Failure"]="Swarf Ram";

/* 28. Stilbyite (iron with titanium and manganese, in shavings) — an iguana whose spiny crest is iron shavings standing on end in its own
   magnetic field; when it rears, the crest bristles taller. */
addForm("Stilbyite",{n:"#4A8A5A",a:"#E8A040",rn:"#E8D0F0",rb:"#D8A040",ra:"#3A6AD8"},"crawl",(P,g)=>fShadow(74)+
 pt("tail",150,124,`<path d="M150 124 Q176 128 188 116 Q194 108 186 104" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>${[160,170,180].map(x=>`<path d="M${x} ${122-(x-160)*.2} v6" stroke="${P.ndd}" stroke-width="2.4"/>`).join("")}<path d="M150 124 Q176 128 188 116" ${SW2} fill="none" opacity=".3"/>`)+
 [[82,128],[100,130],[126,130],[144,128]].map(([x,y],i)=>pt(i%2?"legB":"legF",x,y-6,`<path d="M${x} ${y-6} L${x-8} ${y+6} L${x-14} ${y+14}" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M${x-20} ${y+16} l4 -2 l2 4 l4 -3 l2 3" stroke="${FI}" stroke-width="1.8" fill="none"/>`,i*.25)).join("")+
 `<path d="M60 124 Q60 100 96 98 L140 100 Q160 106 154 124 Q144 132 106 132 Q66 132 60 124 Z" fill="${P.n}" ${SW}/>`+
 [0,1,2].map(r=>Array.from({length:16},(_,i)=>`<circle cx="${70+i*5}" cy="${108+r*7+(i%2)*2}" r="1.4" fill="${P.ndd}"/>`).join("")).join("")+
 pt("sway",100,100,Array.from({length:16},(_,i)=>{const x=68+i*5.5,h=12+Math.sin(i/15*Math.PI)*16;return`<path d="M${x} 100 L${x-3} ${100-h}" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`}).join(""))+
 pt("head",62,112,`<path d="M24 112 Q22 96 42 92 Q62 92 66 110 Q62 122 46 122 Q28 122 24 112 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M48 120 Q44 134 56 136 Q62 128 60 120 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M22 112 L44 114 L42 118 L26 116 Z" fill="${FMOUTH}"/>`+pt("jaw",44,116,`<path d="M44 116 Q32 124 22 116 Q32 120 44 120 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(42,102,5.5,{iris:"#E8412C",look:[-.4,0],lid:.3,lidC:P.n})}<circle cx="52" cy="110" r="5" fill="${P.nll}" ${SW2}/>`+
  pt("tongue",22,114,`<path d="M22 114 L8 112" stroke="${FTONGUE}" stroke-width="3" stroke-linecap="round"/>`))+
 fG(g,1,`<circle cx="100" cy="84" r="2" fill="${P.ac}"/>`)+
 fG(g,2,`<path d="M80 74 q20 -12 40 0" stroke="${P.b}" stroke-width="1.4" fill="none" stroke-dasharray="2 3"/>`)+
 fG(g,3,star(100,66,6)));
FORM_TITLE["Stilbyite"]="Shaving Iguana";

/* 29. Sixth Prize Metal (silicon steel: the laminated cores of transformers) — an eel whose body is banded like a stack of transformer
   laminations, sparks crackling along it, a gaping snapping jaw. */
addForm("Sixth Prize Metal",{n:"#3A4A3A",a:"#FFE070",rn:"#E8E4F2",rb:"#E87AB0",ra:"#5FE0F0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="70" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",150,104,`<path d="M150 104 Q170 92 182 108 Q190 124 176 132 Q186 120 174 114 Q164 112 156 118 Z" fill="${P.n}" ${SW}/>`)+
 `<path d="M40 98 Q70 84 110 96 Q140 104 156 98 L160 114 Q140 122 108 114 Q72 104 46 114 Z" fill="${P.n}" ${SW}/>`+
 Array.from({length:12},(_,i)=>{const x=56+i*8.5;return`<path d="M${x} ${91+Math.abs(5.5-i)*.6} Q${x+2} 106 ${x} ${114+Math.abs(5.5-i)*.4}" stroke="${P.b}" stroke-width="3.4" fill="none"/>`}).join("")+
 `<g class="p-glow">${[[70,82],[96,84],[124,92],[146,92]].map(([x,y])=>`<path d="M${x} ${y} l3 -6 l2 5 l4 -7" stroke="${P.ac}" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`).join("")}</g>`+
 pt("fin",110,94,`<path d="M100 94 Q114 78 132 96" fill="${P.nd}" ${SW2}/>`)+
 pt("head",48,104,`<path d="M18 100 Q22 86 40 86 Q58 88 60 102 Q56 112 40 112 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M16 102 L46 104 L44 108 L20 106 Z" fill="${FMOUTH}"/><path d="M22 103 l2 3 l2 -3 M30 104 l2 3 l2 -3 M38 104 l2 3 l2 -3" fill="#FFFFFF"/>`+
  pt("jaw",48,106,`<path d="M48 106 Q30 118 14 106 Q30 112 48 110 Z" fill="${P.nl}" ${SW2}/>`)+
  `${fE(38,94,5,{iris:P.ac,look:[-.4,0],lid:.3,lidC:P.n})}`)+
 fG(g,1,`<circle cx="30" cy="70" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<path d="M60 120 l4 6 l4 -6" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(100,64,6)));
FORM_TITLE["Sixth Prize Metal"]="Transformer Eel";

/* 30. Stiltwalker's Metal (iron-cobalt with titanium: induction cooktop plates) — a meerkat sentry standing bolt upright, the rings of an
   induction coil showing on its warm belly, head turning to keep watch. */
addForm("Stiltwalker's Metal",{n:"#C8A070",a:"#E8604A",rn:"#7A8ACF",rb:"#3A6AD8",ra:"#FFE070"},"perch",(P,g)=>fShadow(40)+
 pt("tail",108,140,`<path d="M108 140 Q132 144 140 134" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M136 132 Q142 128 144 134 Z" fill="${P.ndd}" ${SW2}/>`)+
 `<path d="M86 146 Q80 104 92 82 Q100 72 110 82 Q122 104 114 146 Z" fill="${P.n}" ${SW}/>`+
 `<ellipse cx="100" cy="118" rx="10" ry="18" fill="${P.b}" stroke="${FI}" stroke-width="1.6"/>${[4,8,12].map(r=>`<ellipse cx="100" cy="118" rx="${r*.7}" ry="${r*1.3}" fill="none" stroke="${P.ac}" stroke-width="1.6"/>`).join("")}`+
 `<path d="M88 146 h10 M104 146 h10" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`+
 pt("armF",92,96,`<path d="M92 96 Q84 104 88 112" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M86 112 l-2 4 M90 113 l0 4" ${SW2}/>`)+
 pt("armB",108,96,`<path d="M108 96 Q116 104 112 112" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round"/>`,.6)+
 pt("head",100,80,`<path d="M86 70 Q84 52 102 50 Q118 52 116 70 Q110 82 100 82 Q90 82 86 70 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M86 66 Q74 66 70 70 Q76 74 86 74 Z" fill="${P.n}" ${SW2}/><circle cx="70" cy="70" r="2.6" fill="${FI}"/>`+
  `<path d="M74 72 L86 74 L84 76 L76 75 Z" fill="${FMOUTH}"/>`+pt("jaw",86,75,`<path d="M86 75 Q80 80 74 76 Q80 78 86 77 Z" fill="${P.nl}" ${SW2}/>`)+
  `<ellipse cx="94" cy="62" rx="7" ry="6" fill="${P.ndd}"/>${fE(94,62,4.5,{iris:"#2A1A0A",look:[-.4,0]})}<ellipse cx="110" cy="62" rx="6" ry="5" fill="${P.ndd}"/>${fE(110,62,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("ear",116,58,`<path d="M114 58 Q122 52 122 62 Q118 64 114 62 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M76 146 h48" stroke="#C8A060" stroke-width="3" opacity=".6"/>`)+
 fG(g,2,`<circle cx="100" cy="118" r="2.4" fill="${P.ac}"/>`)+
 fG(g,3,star(100,36,6)));
FORM_TITLE["Stiltwalker's Metal"]="Coil Meerkat";

/* 31. Contrabandine (aluminium-lithium: glider struts and drone frames) — a flying squirrel spread out mid-glide, its gliding membrane
   stretched between strut-like limbs, flat tail steering. */
addForm("Contrabandine",{n:"#8A6A4A",a:"#F4F0E4",rn:"#3A3E58",rb:"#E87AB0",ra:"#FFE070"},"hover",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="50" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",126,104,`<path d="M124 104 Q150 112 170 104 Q178 118 156 122 Q138 122 124 112 Z" fill="${P.n}" ${SW}/><path d="M134 112 Q150 116 166 110" stroke="${P.nl}" stroke-width="2" fill="none"/>`)+
 pt("wingB",112,90,`<path d="M112 84 L156 64 L150 104 L118 110 Z" fill="${P.nd}" ${SW}/><path d="M114 86 L154 66" stroke="${P.b}" stroke-width="3"/>`)+
 `<path d="M76 104 Q72 82 96 78 Q122 78 124 100 Q120 116 100 116 Q80 116 76 104 Z" fill="${P.n}" ${SW}/><path d="M84 102 Q100 112 116 102" stroke="${P.ac}" stroke-width="7" fill="none" opacity=".8"/>`+
 pt("wingF",86,92,`<path d="M86 86 L38 66 L48 108 L82 112 Z" fill="${P.n}" ${SW}/><path d="M84 88 L40 68 M82 110 L48 106" stroke="${P.b}" stroke-width="3"/><path d="M60 80 Q56 96 62 106" stroke="${P.nl}" stroke-width="2" fill="none" opacity=".7"/><circle cx="38" cy="66" r="3" fill="${P.nd}" ${SW2}/><circle cx="48" cy="108" r="3" fill="${P.nd}" ${SW2}/>`)+
 pt("head",88,80,pt("ear",82,62,`<path d="M80 64 Q78 52 86 52 Q90 60 86 66 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",100,60,`<path d="M98 62 Q102 50 110 54 Q108 62 102 66 Z" fill="${P.n}" ${SW2}/>`,.4)+
  `<path d="M70 76 Q70 58 90 58 Q108 60 106 76 Q100 88 88 88 Q72 88 70 76 Z" fill="${P.n}" ${SW}/><path d="M72 80 Q86 90 100 82 L92 88 L80 88 Z" fill="${P.ac}"/>`+
  `${fE(82,72,6.5,{iris:"#2A1A0A",look:[-.3,.1]})}${fE(98,71,6,{iris:"#2A1A0A",look:[-.3,.1]})}<ellipse cx="74" cy="80" rx="2.4" ry="1.8" fill="${FI}"/>`+
  `<path d="M74 84 L86 86 L84 89 L76 88 Z" fill="${FMOUTH}"/>`+pt("jaw",86,87,`<path d="M86 87 Q80 92 74 88 Q80 90 86 89 Z" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 50 h12 M24 60 h12" stroke="#8AB4D8" stroke-width="2.4" stroke-linecap="round" opacity=".6"/>`)+
 fG(g,2,`<circle cx="100" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(90,40,6)));
FORM_TITLE["Contrabandine"]="Strut Glider";

/* 32. Lowburite (almost pure aluminium, made into racing bike frames) — a cheetah pared down to speed: deep chest, narrow waist, long
   rudder of a tail, tear-marks running from its eyes like aero lines. */
addForm("Lowburite",{n:"#E8C070",a:"#2A2420",rn:"#C8D8E8",rb:"#3A3E58",ra:"#3A6AD8"},"slink",(P,g)=>fShadow(76)+
 pt("tail",156,98,`<path d="M156 98 Q182 104 190 124" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>${[166,176,184].map(x=>`<circle cx="${x}" cy="${104+(x-166)*.9}" r="2.6" fill="${P.ac}"/>`).join("")}<path d="M188 122 l4 6" stroke="${P.ac}" stroke-width="6" stroke-linecap="round"/>`)+
 pt("legB",146,112,`<path d="M146 108 L160 128 L150 146 H160" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legB",138,110,`<path d="M138 106 L150 126 L140 146 H150" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 `<path d="M70 100 Q74 78 106 82 Q140 84 158 96 Q160 110 140 112 Q120 112 104 116 Q78 118 70 100 Z" fill="${P.n}" ${SW}/>`+
 [[90,92],[104,96],[118,90],[132,96],[146,100],[96,106],[124,104]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.ac}"/>`).join("")+
 `<path d="M78 92 Q110 84 150 96" stroke="${P.b}" stroke-width="3" fill="none"/><path d="M80 108 Q100 114 120 110" stroke="#FFFFFF" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("legF",84,104,`<path d="M84 104 L74 124 L80 146 H70" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legF",92,106,`<path d="M92 106 L86 126 L92 146 H82" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("head",76,92,`<path d="M78 94 Q66 80 56 78" stroke="${P.n}" stroke-width="12" fill="none" stroke-linecap="round"/>`+
  `<path d="M26 84 Q28 70 46 68 Q62 68 66 80 Q62 90 48 90 Z" fill="${P.n}" ${SW}/><circle cx="28" cy="82" r="2.6" fill="${FI}"/>`+
  `<path d="M28 86 L50 88 L48 92 L30 90 Z" fill="${FMOUTH}"/><path d="M34 87 l2 3 l2 -3" fill="#FFFFFF"/>`+pt("jaw",50,90,`<path d="M50 90 Q38 98 28 90 Q38 94 50 94 Z" fill="${P.nl}" ${SW2}/>`)+
  `${fE(46,76,5,{iris:"#E8A020",look:[-.4,0],lid:.25,lidC:P.n})}<path d="M42 80 Q38 88 32 90" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
  pt("ear",58,68,`<path d="M56 70 Q58 60 66 62 Q66 70 60 72 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M164 70 h18 M160 80 h22" stroke="${P.d}" stroke-width="2.4" stroke-linecap="round" opacity=".5"/>`)+
 fG(g,2,`<path d="M100 82 L104 74 L108 82" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(46,50,6)));
FORM_TITLE["Lowburite"]="Slipstream Cheetah";

/* 33. Palisadex (titanium with aluminium, molybdenum and niobium: light, tough frame metal) — a mountain ibex planted on a crag, swept
   titanium horns, beard in the wind. */
addForm("Palisadex",{n:"#B89A7A",a:"#6A5040",rn:"#2E3548",rb:"#D8A040",ra:"#E8E4DA"},"stand",(P,g)=>`<path d="M40 148 L60 124 L120 120 L160 148 Z" fill="#8A8478" ${SW}/><path d="M60 124 L80 132 L120 120" stroke="#6A645A" stroke-width="2" fill="none"/>`+fShadow(40,104)+
 pt("tail",142,94,`<path d="M140 92 Q150 88 152 96 Q146 98 140 98 Z" fill="${P.n}" ${SW2}/>`)+
 pt("legB",132,108,`<path d="M132 106 L138 122 L134 132" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legB",126,108,`<path d="M126 106 L130 122 L124 130" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 `<path d="M80 102 Q80 82 106 82 Q138 82 144 96 Q142 112 120 112 L96 112 Q82 112 80 102 Z" fill="${P.n}" ${SW}/><path d="M86 108 Q110 114 136 106" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".6"/><path d="M90 86 Q110 82 134 88" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 pt("legF",90,108,`<path d="M90 106 L86 122 L90 126" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legF",98,108,`<path d="M98 106 L96 122 L100 124" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("head",86,88,`<path d="M88 90 Q78 74 70 70" stroke="${P.n}" stroke-width="12" fill="none" stroke-linecap="round"/>`+
  `<path d="M74 66 Q78 30 108 24 Q130 22 136 40 Q124 32 112 36 Q92 40 84 70 Z" fill="${P.b}" ${SW}/>${[0,1,2,3,4].map(i=>`<path d="M${84+i*8} ${60-i*7} l6 -4" stroke="${P.dd}" stroke-width="2"/>`).join("")}`+
  `<path d="M48 74 Q48 62 62 60 Q76 60 78 72 Q74 80 62 82 Z" fill="${P.n}" ${SW}/><circle cx="50" cy="72" r="2.4" fill="${FI}"/>`+
  `<path d="M50 78 L64 80 L62 83 L52 82 Z" fill="${FMOUTH}"/>`+pt("jaw",64,82,`<path d="M64 82 Q56 88 50 82 Q56 86 64 85 Z" fill="${P.nl}" ${SW2}/><path d="M56 86 Q54 98 60 102 Q62 94 62 86 Z" fill="${P.ac}" ${SW2}/>`)+
  `${fE(66,68,4.5,{iris:"#E8A020",look:[-.4,0]})}`+pt("ear",76,66,`<path d="M74 68 Q86 62 90 68 Q84 72 76 72 Z" fill="${P.n}" ${SW2}/>`))+
 fG(g,1,`<path d="M30 60 q8 -4 16 0 M24 70 q8 -4 16 0" stroke="#FFFFFF" stroke-width="2" fill="none" opacity=".7"/>`)+
 fG(g,2,`<circle cx="112" cy="96" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(110,12,6)));
FORM_TITLE["Palisadex"]="Summit Ibex";

/* 34. Sorry Metal (a cobalt-chrome-tungsten hardfacing alloy, used for files and drill bits) — a beaver with great hard-faced orange
   incisors that gnaw through anything, broad paddle tail it slaps down. */
addForm("Sorry Metal",{n:"#7A5030",a:"#E8A040",rn:"#E8E4F2",rb:"#6AB0E8",ra:"#E8604A"},"stand",(P,g)=>fShadow(70)+
 pt("tail",146,126,`<path d="M144 120 Q176 112 188 128 Q182 144 156 138 Z" fill="#3A3A42" ${SW}/>${[160,170,180].map(x=>`<path d="M${x} ${118+(x-160)*.3} l-4 18 M${x-6} ${124} h12" stroke="#5A5A62" stroke-width="1.4"/>`).join("")}`)+
 `<path d="M64 128 Q56 88 100 82 Q144 84 150 118 Q146 138 110 140 Q72 140 64 128 Z" fill="${P.n}" ${SW}/><path d="M76 130 Q100 138 130 130" stroke="${P.nl}" stroke-width="7" fill="none" opacity=".5"/><path d="M124 88 Q150 98 146 124 Q138 136 124 138 Q144 114 124 88 Z" fill="${P.ndd}" opacity=".3"/>`+
 `<path d="M80 140 Q76 132 88 130 L98 132 Q100 142 92 144 Z M118 140 Q128 132 116 130 L106 132 Q104 142 112 144 Z" fill="#3A3A42" ${SW2}/>`+
 pt("armF",84,108,`<path d="M84 106 Q72 114 74 124" stroke="${P.nd}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M70 124 l-2 4 M74 126 l0 4 M78 125 l2 4" ${SW2}/>`)+
 pt("head",82,92,pt("ear",88,70,`<circle cx="88" cy="70" r="5" fill="${P.n}" ${SW2}/>`)+
  `<path d="M50 94 Q46 72 70 68 Q94 68 96 88 Q92 104 72 106 Q54 106 50 94 Z" fill="${P.n}" ${SW}/><path d="M46 90 Q44 82 52 82 L60 86 Q56 94 46 90 Z" fill="#3A3A42" ${SW2}/>`+
  `<path d="M48 96 L66 98 L64 102 L50 100 Z" fill="${FMOUTH}"/>`+
  `<rect x="52" y="94" width="10" height="11" rx="1.5" fill="${P.ac}" stroke="${FI}" stroke-width="1.6"/><path d="M57 94 v11" stroke="${FI}" stroke-width="1.2"/><rect x="52" y="103" width="10" height="2" fill="${P.b}"/>`+
  pt("jaw",66,100,`<path d="M66 100 Q58 110 48 104 Q56 106 66 104 Z" fill="${P.nl}" ${SW2}/>`)+
  `${fE(72,82,5.5,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M48 90 l-8 -2 M48 92 l-8 1" stroke="${FI}" stroke-width="1"/>`)+
 fG(g,1,`<path d="M30 144 q4 -8 10 -2 M36 140 q2 -6 6 -4" stroke="#C8A060" stroke-width="2" fill="none"/>`)+
 fG(g,2,`<rect x="52" y="103" width="10" height="2" fill="#FFFFFF"/>`)+
 fG(g,3,star(70,50,6)));
FORM_TITLE["Sorry Metal"]="Carbide Beaver";

/* 35. Plumleyite (cobalt, nickel and tungsten: a compass-needle alloy) — a sea turtle that steers by the earth's magnetic field, a compass
   rose worked into its shell, flippers rowing. */
addForm("Plumleyite",{n:"#5A8A6A",a:"#E8C060",rn:"#E8A0C8",rb:"#E8C878",ra:"#3A6AD8"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="56" ry="4" fill="#000" opacity=".14"/>`+
 pt("wingB",124,96,`<path d="M124 96 Q146 82 164 90 Q150 100 128 106 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legB",140,112,`<path d="M140 112 Q156 122 160 134 Q148 132 136 120 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M58 108 Q62 70 106 68 Q148 70 152 108 Q130 122 104 122 Q76 122 58 108 Z" fill="${P.b}" ${SW}/>`+
 `<circle cx="104" cy="94" r="18" fill="none" stroke="${P.dd}" stroke-width="2"/><path d="M104 74 L108 92 L104 114 L100 92 Z" fill="${P.ac}" stroke="${FI}" stroke-width="1.4"/><path d="M84 94 L102 98 L124 94 L102 90 Z" fill="${P.ll}" stroke="${FI}" stroke-width="1.4"/><path d="M104 74 L108 92 L104 92 Z" fill="#C8243A"/>`+
 [[72,96],[136,96],[88,78],[120,78]].map(([x,y])=>`<path d="M${x-8} ${y} L${x} ${y-6} L${x+8} ${y} L${x} ${y+6} Z" fill="none" stroke="${P.dd}" stroke-width="1.6"/>`).join("")+
 `<path d="M60 108 Q104 128 150 108" stroke="${P.nl}" stroke-width="5" fill="none"/>`+
 pt("wingF",76,104,`<path d="M76 104 Q50 112 32 130 Q56 132 82 116 Z" fill="${P.n}" ${SW}/><path d="M64 112 l-6 10 M54 118 l-6 8" stroke="${P.nd}" stroke-width="1.6"/>`)+
 pt("head",62,98,`<path d="M62 98 Q50 92 36 94" stroke="${P.n}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M18 92 Q20 78 36 78 Q50 80 50 94 Q46 104 32 104 Q20 102 18 92 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M18 96 L32 98 L30 101 L20 100 Z" fill="${FMOUTH}"/>`+pt("beak",32,100,`<path d="M32 100 Q24 106 18 100 Q24 102 32 102 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(34,88,5.5,{iris:"#2A1A0A",look:[-.4,0],lid:.3,lidC:P.n})}<path d="M40 82 l4 -2 M46 86 l4 -1" stroke="${P.nd}" stroke-width="1.6"/>`)+
 fG(g,1,`<circle cx="160" cy="70" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/><circle cx="168" cy="60" r="2" fill="none" stroke="#8AB4D8" stroke-width="1.4"/>`)+
 fG(g,2,`<circle cx="104" cy="94" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,54,6)));
FORM_TITLE["Plumleyite"]="Compass Turtle";

/* 36. Riddlemere Mix (niobium with hafnium and zirconium: rocket-nozzle alloy, here made into cutting dies) — a praying mantis whose
   forelegs are blades sharp enough to cut sheet metal, head swivelling on its thin neck. */
addForm("Riddlemere Mix",{n:"#6AA04A",a:"#E8604A",rn:"#E8A0C8",rb:"#E8604A",ra:"#FFE070"},"perch",(P,g)=>fShadow(54)+
 [[112,118],[124,120],[138,118]].map(([x,y],i)=>pt("legB",x,y,`<path d="M${x} ${y} L${x+10} ${y+10} L${x+6} ${y+28}" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.25)).join("")+
 pt("tail",120,116,`<path d="M108 112 Q130 100 170 110 Q176 122 160 128 Q128 130 108 122 Z" fill="${P.n}" ${SW}/>${[124,136,148,160].map(x=>`<path d="M${x} 106 Q${x+2} 116 ${x} 126" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`)+
 pt("wingF",118,104,`<path d="M114 104 Q150 92 172 102 Q148 110 116 112 Z" fill="${P.nll}" opacity=".85" ${SW2}/>`)+
 `<path d="M96 120 Q92 98 100 72 Q106 66 110 72 Q114 100 112 120 Z" fill="${P.n}" ${SW}/>`+
 pt("armF",100,80,`<path d="M100 80 L76 98" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/>`+pt("claw",76,98,`<path d="M76 98 L56 74 L60 72 L80 94 Z" fill="${P.n}" ${SW2}/><path d="M58 76 L78 94" stroke="${P.b}" stroke-width="3"/>${[0,1,2,3].map(i=>`<path d="M${62+i*4} ${80+i*4} l-4 2" stroke="${FI}" stroke-width="1.4"/>`).join("")}`))+
 pt("armB",106,84,`<path d="M106 84 L92 102" stroke="${P.nd}" stroke-width="5" stroke-linecap="round"/>`+pt("claw",92,102,`<path d="M92 102 L80 80 L84 78 L96 98 Z" fill="${P.nd}" ${SW2}/><path d="M82 82 L94 98" stroke="${P.b}" stroke-width="2.4"/>`,.3))+
 pt("head",104,68,`<path d="M88 58 L120 58 L108 76 L100 76 Z" fill="${P.n}" ${SW}/>`+fE(90,58,5.5,{iris:"#2A1A0A",look:[-.4,0]})+fE(118,58,5.5,{iris:"#2A1A0A",look:[-.4,0]})+
  `<path d="M100 76 L108 76 L106 80 L102 80 Z" fill="${FMOUTH}"/>`+pt("jaw",104,78,`<path d="M100 78 L98 84 M108 78 L110 84" stroke="${P.nd}" stroke-width="2.4" stroke-linecap="round"/>`)+
  pt("ant",96,56,`<path d="M96 56 Q84 36 70 32" stroke="${P.nd}" stroke-width="2" fill="none"/>`)+pt("ant",112,56,`<path d="M112 56 Q116 34 130 26" stroke="${P.nd}" stroke-width="2" fill="none"/>`,.5))+
 fG(g,1,`<path d="M40 146 h30" stroke="#6A9A3A" stroke-width="3" opacity=".6"/>`)+
 fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,36,6)));
FORM_TITLE["Riddlemere Mix"]="Die-Cut Mantis";

/* 37. Lobster's Luck (gold, palladium, silver and nickel: jewellery metal) — a magpie hopping about with a beakful of jewellery, glossy
   pied plumage, tail cocked high. */
addForm("Lobster's Luck",{n:"#1A1E2A",a:"#3A8AD8",rn:"#E8E4F2",rb:"#E8C060",ra:"#E87AB0"},"hop",(P,g)=>fShadow(46)+
 pt("tail",122,104,`<path d="M120 102 L176 66 L180 74 L126 112 Z" fill="${P.n}" ${SW}/><path d="M130 100 L172 72" stroke="${P.ac}" stroke-width="3"/>`)+
 pt("legB",100,124,`<path d="M100 124 L96 146 M88 146 h14 M106 124 L108 146 M104 146 h12" stroke="#2A2E34" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 `<path d="M76 118 Q70 88 98 82 Q126 84 128 108 Q120 128 98 128 Q80 128 76 118 Z" fill="${P.n}" ${SW}/><path d="M80 114 Q84 96 98 96 Q110 100 108 122 Q92 126 80 114 Z" fill="#F4F0E4"/>`+
 pt("wingF",106,96,`<path d="M106 92 Q132 98 134 116 Q118 118 104 108 Z" fill="${P.n}" ${SW2}/><path d="M110 98 Q124 102 128 112" stroke="${P.ac}" stroke-width="3" fill="none"/><path d="M108 104 Q118 108 122 114" stroke="#F4F0E4" stroke-width="3" fill="none"/>`)+
 pt("head",92,86,`<circle cx="88" cy="74" r="15" fill="${P.n}" ${SW}/>`+
  `<path d="M74 70 L52 74 L74 76 Z" fill="#3A3E48" ${SW2}/>`+pt("beak",74,76,`<path d="M74 76 L54 76 L74 80 Z" fill="#2A2E34" ${SW2}/>`)+
  `<g transform="translate(56 78)"><circle r="6" fill="none" stroke="${P.b}" stroke-width="2.6"/><circle cx="0" cy="-6" r="2.4" fill="#E8412C" stroke="${FI}" stroke-width=".8"/><path d="M4 4 Q10 14 4 20" stroke="${P.b}" stroke-width="1.4" fill="none"/><circle cx="4" cy="20" r="2" fill="#FFFFFF" stroke="${FI}" stroke-width=".8"/></g>`+
  `${fE(86,70,5,{iris:"#2A1A0A",look:[-.4,0]})}`)+
 fG(g,1,star(40,60,4,"#FFFFFF"))+
 fG(g,2,`<circle cx="120" cy="140" r="4" fill="${P.b}" ${SW2}/><circle cx="130" cy="142" r="3" fill="#E8412C" ${SW2}/>`)+
 fG(g,3,star(88,46,6)));
FORM_TITLE["Lobster's Luck"]="Trinket Magpie";

/* 38. Coin Silver (silver with a little copper: coin silver, the best conductor going) — a fox with a mirror-bright coat that throws
   back the light, sparks running along its brush when it swishes. */
addForm("Coin Silver",{n:"#D8DCE4",a:"#5FB0F0",rn:"#E8A060",rb:"#C8243A",ra:"#FFE070"},"stand",(P,g)=>fShadow(66)+
 pt("tail",148,100,`<path d="M146 98 Q178 88 190 64 Q192 84 178 104 Q164 116 146 112 Z" fill="${P.n}" ${SW}/><path d="M186 70 Q190 66 190 64 Q192 76 186 84 Z" fill="#FFFFFF" ${SW2}/><g class="p-glow"><path d="M160 96 l4 -6 l2 5 l4 -6 M172 86 l3 -5 l2 4" stroke="${P.ac}" stroke-width="1.6" fill="none"/></g>`)+
 pt("legB",138,114,`<path d="M138 110 L144 130 L138 146 H148" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legB",130,112,`<path d="M130 110 L136 130 L130 146 H140" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M126 144 h14" stroke="#2A2E34" stroke-width="4" stroke-linecap="round"/>`)+
 `<path d="M74 106 Q74 84 104 84 Q140 84 150 100 Q148 116 126 116 L94 116 Q78 116 74 106 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M86 92 Q110 86 138 94" stroke="#FFFFFF" stroke-width="5" fill="none" stroke-linecap="round" opacity=".9"/><path d="M96 100 L104 92 M112 102 L120 94" stroke="#FFFFFF" stroke-width="2.4" opacity=".8"/><path d="M84 110 Q104 118 124 112" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`+
 pt("legF",88,112,`<path d="M88 110 L82 130 L86 146 H76" stroke="${P.nd}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,.5)+
 pt("legF",96,112,`<path d="M96 110 L92 130 L96 146 H86" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M84 144 h14" stroke="#2A2E34" stroke-width="4" stroke-linecap="round"/>`)+
 pt("head",84,94,pt("ear",72,66,`<path d="M70 70 L68 46 L84 64 Z" fill="${P.n}" ${SW2}/><path d="M72 64 L71 52 L79 62" fill="#2A2E34"/>`)+pt("ear",86,64,`<path d="M84 66 L94 44 L98 66 Z" fill="${P.nd}" ${SW2}/>`,.4)+
  `<path d="M30 84 Q34 70 56 66 Q80 62 88 78 Q86 92 66 94 Q46 94 30 84 Z" fill="${P.n}" ${SW}/><circle cx="30" cy="84" r="3" fill="${FI}"/><path d="M40 88 Q58 96 76 90" stroke="#FFFFFF" stroke-width="5" fill="none" opacity=".8"/>`+
  `<path d="M32 88 L54 90 L52 94 L34 92 Z" fill="${FMOUTH}"/>`+pt("jaw",54,92,`<path d="M54 92 Q42 100 32 92 Q42 96 54 96 Z" fill="#F4F0E4" ${SW2}/>`)+
  `${fE(62,76,5.5,{iris:P.ac,look:[-.4,0],lid:.2,lidC:P.n})}`)+
 fG(g,1,`<path d="M110 76 l4 -6 l4 6" stroke="#FFFFFF" stroke-width="2.4" fill="none"/>`)+
 fG(g,2,star(140,70,4,"#FFFFFF"))+
 fG(g,3,star(60,40,6)));
FORM_TITLE["Coin Silver"]="Mirror Fox";

/* 39. Pikeon (platinum-rhodium: the wire inside furnace thermocouples) — an anteater with a long, fine probe of a snout and a tongue that
   reaches out to take the temperature of everything, heavy curved digging claws. */
addForm("Pikeon",{n:"#8A6A5A",a:"#E8412C",rn:"#2E3548",rb:"#E0B820",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(74)+
 pt("tail",150,100,`<path d="M148 96 Q186 82 192 108 Q190 124 160 118 Z" fill="${P.nd}" ${SW}/>${[162,172,182].map(x=>`<path d="M${x} ${96-(x-162)*.2} l2 14" stroke="${P.n}" stroke-width="2"/>`).join("")}`)+
 [[132,116],[146,114]].map(([x,y],i)=>pt("legB",x,y,`<path d="M${x} ${y} L${x+2} ${y+30}" stroke="${P.nd}" stroke-width="9" stroke-linecap="round"/>`,i*.5)).join("")+
 `<path d="M70 110 Q70 80 108 78 Q148 78 156 104 Q150 124 120 124 L90 124 Q72 122 70 110 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M84 86 Q120 74 150 98 L146 108 Q116 88 88 96 Z" fill="${P.b}" ${SW2}/><path d="M90 92 L146 102" stroke="#FFFFFF" stroke-width="1.6" opacity=".7"/>`+
 [[86,116],[102,118]].map(([x,y],i)=>pt("legF",x,y,`<path d="M${x} ${y} L${x-2} ${y+28}" stroke="${P.n}" stroke-width="9" stroke-linecap="round"/><path d="M${x-6} ${y+28} q-6 -2 -8 2 M${x-4} ${y+30} q-6 2 -6 6" stroke="${P.b}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`,i*.5)).join("")+
 pt("head",76,98,`<path d="M78 92 Q60 88 46 96 L16 108 Q12 112 18 112 L50 110 Q70 110 78 104 Z" fill="${P.n}" ${SW}/><path d="M16 108 L30 104 L30 110 Z" fill="${P.b}"/>`+
  pt("tongue",16,110,`<path d="M16 110 Q4 110 -4 116" stroke="${FTONGUE}" stroke-width="2.4" fill="none" stroke-linecap="round"/>`)+
  `${fE(60,96,4.5,{iris:"#2A1A0A",look:[-.4,0],lid:.35,lidC:P.n})}`+pt("ear",70,88,`<path d="M68 88 Q72 80 78 84 Q76 90 70 92 Z" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<path d="M10 100 l-4 -4 M8 106 l-6 -1" stroke="${P.ac}" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="120" cy="84" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(110,56,6)));
FORM_TITLE["Pikeon"]="Probe Anteater";

/* 40. Trowelite (silver with plutonium) — a deep-sea anglerfish with a silver hide, its lure a little glowing core on a stalk, a cavernous
   jaw of needle teeth. */
addForm("Trowelite",{n:"#3A3E58",a:"#9BF06A",rn:"#E8D0F0",rb:"#E8C060",ra:"#FF6AB0"},"swim",(P,g)=>`<ellipse class="shd" cx="100" cy="150" rx="50" ry="4" fill="#000" opacity=".14"/>`+
 pt("tail",146,96,`<path d="M144 92 L176 72 L170 96 L178 122 L144 104 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M54 98 Q56 58 104 56 Q148 58 150 98 Q146 128 104 132 Q60 130 54 98 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M70 70 Q100 58 130 68" stroke="${P.b}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M120 62 Q148 76 146 104 Q138 124 116 130 Q140 100 120 62 Z" fill="${P.ndd}" opacity=".35"/>`+
 pt("fin",122,110,`<path d="M120 108 Q134 124 126 136 Q118 128 116 116 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M48 92 L96 94 L94 116 L52 112 Z" fill="${FMOUTH}"/>${[54,62,70,78,86].map(x=>`<path d="M${x} 93 l3 8 l3 -8" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`).join("")}`+
 pt("jaw",96,112,`<path d="M96 110 Q74 132 44 114 L48 110 Q72 120 96 116 Z" fill="${P.nd}" ${SW2}/>${[54,62,70,78,86].map(x=>`<path d="M${x} ${113+(x-50)*.05} l3 -8 l3 8" fill="#FFFFFF" stroke="${FI}" stroke-width=".6"/>`).join("")}`)+
 `${fE(92,78,7,{iris:P.ac,look:[-.4,0]})}`+
 pt("ant",84,60,`<path d="M84 60 Q70 30 46 36 Q38 42 40 52" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/><circle class="p-glow" cx="40" cy="56" r="9" fill="${P.ac}" opacity=".5"/><circle cx="40" cy="56" r="5" fill="${P.ac}" ${SW2}/>`)+
 fG(g,1,`<circle cx="30" cy="80" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<path d="M110 86 l4 -4 l4 4" stroke="${P.b}" stroke-width="2" fill="none"/>`)+
 fG(g,3,star(104,40,6)));
FORM_TITLE["Trowelite"]="Core Angler";

/* 41. Vellane (magnesium-thorium: featherweight engine metal that burns with a white flare) — a quick little gecko clinging to nothing,
   tail tip burning bright white, toes spread. */
addForm("Vellane",{n:"#E8E4DA",a:"#FFF4C0",rn:"#3A2A5A",rb:"#5FE0F0",ra:"#FF8AD0"},"crawl",(P,g)=>fShadow(66)+
 pt("tail",144,118,`<path d="M144 118 Q176 120 184 100 Q188 86 176 80" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M144 118 Q176 120 184 100" ${SW2} fill="none" opacity=".3"/><g class="p-glow"><circle cx="176" cy="78" r="12" fill="${P.ac}" opacity=".6"/><path d="M172 80 Q168 66 178 60 Q180 70 186 66 Q188 78 178 84 Z" fill="#FFFFFF" ${SW2}/></g>`)+
 [[84,122],[100,124],[124,124],[140,122]].map(([x,y],i)=>pt(i%2?"legB":"legF",x,y-6,`<path d="M${x} ${y-6} L${x-8} ${y+6} L${x-12} ${y+16}" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>${[-6,-1,4].map(d=>`<circle cx="${x-12+d}" cy="${y+18}" r="2.4" fill="${P.nd}" ${SW2}/>`).join("")}`,i*.25)).join("")+
 `<path d="M64 118 Q64 98 96 96 L136 98 Q152 104 146 120 Q136 128 104 128 Q70 128 64 118 Z" fill="${P.n}" ${SW}/>${[[84,104],[100,102],[116,104],[132,106],[92,114],[124,116]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.b}" opacity=".9"/>`).join("")}`+
 pt("head",66,110,`<path d="M24 108 Q24 90 46 88 Q66 90 70 106 Q64 120 46 120 Q28 120 24 108 Z" fill="${P.n}" ${SW}/>`+
  `<path d="M24 110 L48 112 L46 116 L28 114 Z" fill="${FMOUTH}"/>`+pt("jaw",48,114,`<path d="M48 114 Q36 122 24 114 Q36 118 48 118 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(46,98,8,{iris:"#E8A020",look:[-.4,0]})}`+pt("tongue",24,112,`<path d="M24 112 L12 110" stroke="${FTONGUE}" stroke-width="3" stroke-linecap="round"/>`))+
 fG(g,1,`<path d="M190 70 l6 -4 M192 82 l6 0" stroke="#FFFFFF" stroke-width="2.4" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="108" cy="110" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,3,star(104,76,6)));
FORM_TITLE["Vellane"]="Flare Gecko";

/* 42. Between Hoots (cobalt with curium, the warm heart of a space probe's power pack) — a tardigrade, the toughest animal there is,
   paddling along on eight stubby clawed legs, a warm glow at its core, a little tube of a mouth. */
addForm("Between Hoots",{n:"#C8B8A0",a:"#FF8A3A",rn:"#9FE8D0",rb:"#3A6AD8",ra:"#FFE070"},"crawl",(P,g)=>fShadow(66)+
 [[66,124],[88,128],[112,128],[134,124]].map(([x,y],i)=>pt(i%2?"legB":"legF",x,y-6,`<path d="M${x-6} ${y-6} Q${x-8} ${y+8} ${x} ${y+12} Q${x+8} ${y+8} ${x+6} ${y-6} Z" fill="${P.n}" ${SW2}/><path d="M${x-4} ${y+12} l-3 4 M${x} ${y+13} v5 M${x+4} ${y+12} l3 4" stroke="${P.b}" stroke-width="2" stroke-linecap="round"/>`,i*.25)).join("")+
 `<path d="M50 112 Q46 76 100 72 Q154 76 156 112 Q150 128 100 128 Q54 128 50 112 Z" fill="${P.n}" ${SW}/>`+
 [70,88,106,124,140].map(x=>`<path d="M${x} ${78+Math.abs(x-104)*.08} Q${x+4} 100 ${x} 126" stroke="${P.nd}" stroke-width="2.4" fill="none"/>`).join("")+
 `<circle class="p-glow" cx="106" cy="102" r="14" fill="${P.ac}" opacity=".45"/><circle cx="106" cy="102" r="7" fill="${P.b}" ${SW2}/><path d="M102 98 l8 8 M110 98 l-8 8" stroke="${P.ac}" stroke-width="1.6"/>`+
 pt("head",54,104,`<path d="M18 104 Q18 86 40 84 Q58 86 60 104 Q56 118 40 118 Q22 118 18 104 Z" fill="${P.n}" ${SW}/>${fE(36,96,4.5,{iris:"#2A1A0A",look:[-.4,0]})}${fE(48,95,4,{iris:"#2A1A0A",look:[-.4,0]})}`+
  pt("tongue",18,106,`<path d="M18 104 L8 104 L8 110 L18 110 Z" fill="${P.nd}" ${SW2}/><circle cx="8" cy="107" r="2" fill="${FMOUTH}"/>`)+
  `<path d="M16 104 L22 104 L22 110 L16 110 Z" fill="${P.nd}" ${SW2}/><circle cx="16" cy="107" r="2.2" fill="${FMOUTH}"/>`)+
 fG(g,1,`<circle cx="160" cy="80" r="3" fill="${P.ac}" opacity=".6"/>`)+
 fG(g,2,`<path d="M92 72 L96 64 L100 72" stroke="${P.b}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(104,52,6)));
FORM_TITLE["Between Hoots"]="Ember Tardigrade";

/* 43. Captain's Spare (iron with tungsten and chromium: motor-core and tool steel) — a stag beetle whose great antler-jaws clamp like a
   vice, the copper windings of a motor showing on its wing cases. */
addForm("Captain's Spare",{n:"#3A2A24",a:"#C87333",rn:"#E8E4F2",rb:"#2E4A8A",ra:"#E8C060"},"crawl",(P,g)=>fShadow(72)+
 [[110,124],[126,126],[142,124]].map(([x,y],i)=>pt("legB",x,y,`<path d="M${x} ${y} L${x+10} ${y+10} L${x+6} ${y+22}" stroke="${FI}" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`,i*.2)).join("")+
 `<path d="M96 118 Q92 84 130 80 Q168 82 170 114 Q164 128 132 128 Q100 128 96 118 Z" fill="${P.n}" ${SW}/><path d="M132 80 V128" stroke="${P.ndd}" stroke-width="2.4"/>`+
 [92,100,108,116].map(y=>`<path d="M${104+(y-92)*.2} ${y} Q118 ${y-4} 130 ${y}" stroke="${P.ac}" stroke-width="2.4" fill="none"/><path d="M134 ${y} Q148 ${y-4} ${162-(y-92)*.3} ${y}" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`).join("")+
 `<path d="M108 88 Q122 82 138 84" stroke="${P.nll}" stroke-width="4" fill="none" opacity=".6"/>`+
 pt("legF",96,110,`<path d="M96 110 L80 116 L76 130" stroke="${FI}" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`)+
 pt("head",90,102,`<path d="M66 108 Q64 90 82 88 Q98 90 98 106 Q94 116 80 116 Q68 116 66 108 Z" fill="${P.b}" ${SW}/>${fE(80,98,4.5,{iris:"#E8412C",look:[-.4,0]})}`+
  pt("claw2",70,94,`<path d="M70 94 Q48 76 26 80 Q36 84 44 86 L36 90 Q52 90 66 100 Z" fill="${P.b}" ${SW2}/><path d="M40 86 l-4 -6" stroke="${FI}" stroke-width="2"/>`)+
  pt("jaw",70,110,`<path d="M70 110 Q50 124 28 120 Q38 118 46 116 L38 112 Q54 112 68 104 Z" fill="${P.d}" ${SW2}/>`)+
  pt("ant",76,90,`<path d="M76 90 L66 74 L60 76" stroke="${P.dd}" stroke-width="2" fill="none"/>`))+
 fG(g,1,`<circle cx="132" cy="122" r="3" fill="${P.ac}" ${SW2}/>`)+
 fG(g,2,`<path d="M118 78 L122 70 L126 78" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(132,62,6)));
FORM_TITLE["Captain's Spare"]="Vice Stag Beetle";

/* 44. Sandwich Price Metal (nickel with a little tungsten and chromium) — a woodpecker clamped to a post, drumming away like a little motor,
   red cap, chisel bill, stiff tail propping it up. */
addForm("Sandwich Price Metal",{n:"#2A2E38",a:"#E8412C",rn:"#E8E4F2",rb:"#E8C060",ra:"#2FB463"},"perch",(P,g)=>`<rect x="104" y="10" width="26" height="140" rx="3" fill="#8A6A4A" ${SW}/><path d="M110 20 v120 M122 30 v100" stroke="#6A4A2A" stroke-width="2"/><circle cx="104" cy="60" r="4" fill="#5A3A20"/>`+
 pt("tail",108,120,`<path d="M106 112 L112 144 L102 142 L100 116 Z" fill="${P.n}" ${SW2}/>`)+
 `<path d="M86 116 Q78 84 98 72 Q114 72 112 100 Q110 120 98 122 Q88 122 86 116 Z" fill="${P.n}" ${SW}/><path d="M88 112 Q86 92 96 84 Q102 94 100 116 Z" fill="#F4F0E4"/>`+
 pt("wingF",104,88,`<path d="M104 84 Q116 98 112 118 Q102 110 98 96 Z" fill="${P.n}" ${SW2}/>${[0,1,2].map(i=>`<circle cx="${106}" cy="${94+i*7}" r="1.6" fill="#F4F0E4"/>`).join("")}`)+
 `<path d="M100 122 L108 126 M98 124 L106 132" stroke="#5A5A62" stroke-width="2.4" stroke-linecap="round"/>`+
 pt("head",100,72,`<g class="peck" style="transform-origin:100px 74px"><circle cx="96" cy="62" r="13" fill="${P.n}" ${SW}/><path d="M88 52 Q96 44 106 52 Q100 56 92 56 Z" fill="${P.ac}" ${SW2}/><path d="M86 66 Q94 70 102 66" stroke="#F4F0E4" stroke-width="3" fill="none"/>`+
  `<path d="M84 60 L62 62 L84 64 Z" fill="${P.b}" ${SW2}/>`+pt("beak",84,64,`<path d="M84 64 L64 63 L84 67 Z" fill="${P.d}" ${SW2}/>`)+`${fE(94,60,4.5,{iris:"#2A1A0A",look:[-.4,0]})}</g>`)+
 fG(g,1,`<path d="M58 54 l-6 -4 M56 62 l-8 0 M58 70 l-6 4" stroke="#C8A060" stroke-width="2" stroke-linecap="round"/>`)+
 fG(g,2,`<circle cx="96" cy="100" r="3" fill="${P.b}" ${SW2}/>`)+
 fG(g,3,star(80,34,6)));
FORM_TITLE["Sandwich Price Metal"]="Drum Woodpecker";

/* 45. Hamperite (molybdenum: its sulfide is the slipperiest dry lubricant there is) — a sleek seal so slick it slides everywhere, flippers
   slapping, whiskers twitching, barking. */
addForm("Hamperite",{n:"#6A7A8A",a:"#E8E4DA",rn:"#E8C878",rb:"#3AC0E0",ra:"#E8604A"},"slink",(P,g)=>`<path d="M20 146 Q100 140 190 146" stroke="#BFE3F4" stroke-width="4" fill="none" stroke-linecap="round"/>`+fShadow(70)+
 pt("tail",154,128,`<path d="M152 126 L178 116 L174 130 L182 142 L152 136 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M50 120 Q52 90 90 88 Q140 90 156 124 Q150 140 100 140 Q56 140 50 120 Z" fill="${P.n}" ${SW}/><path d="M64 108 Q96 94 130 104" stroke="#FFFFFF" stroke-width="6" fill="none" stroke-linecap="round" opacity=".6"/><path d="M60 132 Q100 140 144 132" stroke="${P.nl}" stroke-width="5" fill="none" opacity=".6"/>`+
 [[86,104],[106,100],[120,110],[96,120]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.nd}"/>`).join("")+
 pt("fin",82,124,`<path d="M82 122 Q68 136 58 146 Q74 146 88 132 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",60,104,`<path d="M24 92 Q26 72 48 70 Q70 72 72 94 Q66 108 48 108 Q28 108 24 92 Z" fill="${P.n}" ${SW}/><ellipse cx="26" cy="92" rx="5" ry="4" fill="${P.ac}" ${SW2}/><ellipse cx="24" cy="90" rx="2.4" ry="1.8" fill="${FI}"/>`+
  `<path d="M24 98 L42 100 L40 104 L26 102 Z" fill="${FMOUTH}"/>`+pt("jaw",42,102,`<path d="M42 102 Q32 110 24 102 Q32 106 42 106 Z" fill="${P.nd}" ${SW2}/>`)+
  `${fE(46,84,7,{iris:"#2A1A0A",look:[-.3,0]})}`+pt("ant",30,94,`<path d="M30 94 L10 90 M30 96 L10 98 M30 98 L12 106" stroke="${P.ac}" stroke-width="1.4"/>`))+
 fG(g,1,`<circle cx="150" cy="100" r="5" fill="#BFE3F4" ${SW2}/>`)+
 fG(g,2,`<path d="M88 88 L92 80 L96 88" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(48,52,6)));
FORM_TITLE["Hamperite"]="Slick Seal";

/* 46. Penguinite (magnesium with tin and a speck of moscovium: light, and it burns brilliantly) — a flying fish leaping clear of the water
   on long, bright wing-fins, a trail of white sparks behind it. */
addForm("Penguinite",{n:"#2E6AB0",a:"#FFF0A0",rn:"#E87AB0",rb:"#F4F0E4",ra:"#5FE0F0"},"hover",(P,g)=>`<path d="M20 146 Q60 138 100 146 Q140 154 190 144" stroke="#8AB4D8" stroke-width="3" fill="none" opacity=".7"/><ellipse class="shd" cx="100" cy="150" rx="40" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",142,92,`<path d="M140 90 L172 70 L164 94 L174 116 L140 100 Z" fill="${P.n}" ${SW}/><g class="p-glow">${[[180,96],[188,84],[184,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.ac}"/>`).join("")}</g>`)+
 pt("wingB",108,86,`<path d="M108 86 Q130 46 160 40 Q150 72 120 96 Z" fill="${P.b}" opacity=".9" ${SW}/>${[0,1,2].map(i=>`<path d="M112 ${88-i*2} L${146+i*4} ${48+i*8}" stroke="${P.dd}" stroke-width="1.6"/>`).join("")}`)+
 `<path d="M48 92 Q52 76 92 74 Q132 76 146 94 Q130 108 92 108 Q56 108 48 92 Z" fill="${P.n}" ${SW}/><path d="M56 98 Q96 108 136 98" stroke="#F4F0E4" stroke-width="6" fill="none" opacity=".8"/>`+
 pt("wingF",92,92,`<path d="M92 92 Q70 124 34 132 Q48 106 80 92 Z" fill="${P.b}" ${SW}/>${[0,1,2].map(i=>`<path d="M${88-i*4} ${94+i} L${44+i*8} ${126-i*6}" stroke="${P.dd}" stroke-width="1.6"/>`).join("")}`)+
 pt("head",58,90,`${fE(64,86,6,{iris:"#2A1A0A",look:[-.4,0]})}<path d="M46 92 L58 92 L56 96 L48 96 Z" fill="${FMOUTH}"/>`+pt("jaw",58,95,`<path d="M58 95 Q52 100 46 95 Q52 98 58 97 Z" fill="${P.nl}" ${SW2}/>`))+
 fG(g,1,`<circle cx="30" cy="140" r="3" fill="#FFFFFF" ${SW2}/>`)+
 fG(g,2,`<path d="M96 76 L100 68 L104 76" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`)+
 fG(g,3,star(132,40,6)));
FORM_TITLE["Penguinite"]="Spark Flyingfish";

/* 47. Old Well Blend (almost pure tungsten: the heaviest everyday metal) — a hammerhead shark built like an anvil, its broad head a solid
   block, cruising slow and heavy along the bottom. */
addForm("Old Well Blend",{n:"#5A6070",a:"#FFB040",rn:"#E8D0F0",rb:"#3A6AD8",ra:"#5FE0F0"},"swim",(P,g)=>`<ellipse class="shd" cx="104" cy="150" rx="66" ry="4" fill="#000" opacity=".16"/>`+
 pt("tail",156,98,`<path d="M154 96 L186 60 L180 98 L188 132 L154 104 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M56 100 Q60 80 104 78 Q146 80 160 98 Q146 118 104 120 Q64 118 56 100 Z" fill="${P.n}" ${SW}/><path d="M64 106 Q104 120 150 106" stroke="#F4F0E4" stroke-width="7" fill="none" opacity=".6"/>`+
 [90,96,102].map(x=>`<path d="M${x} 90 Q${x+2} 98 ${x} 106" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")+
 pt("fin",110,80,`<path d="M100 80 L118 46 L130 82 Z" fill="${P.nd}" ${SW}/>`)+pt("fin",104,116,`<path d="M100 116 Q96 136 80 142 Q84 126 92 116 Z" fill="${P.nd}" ${SW2}/>`,.5)+
 pt("head",60,96,`<path d="M30 76 L74 82 L74 112 L30 116 Q24 96 30 76 Z" fill="${P.b}" ${SW}/><path d="M32 80 L72 84 M32 112 L72 110" stroke="${P.ll}" stroke-width="2"/>`+
  `${fE(30,80,5.5,{iris:P.ac,look:[-.4,0]})}${fE(30,112,5.5,{iris:P.ac,look:[-.4,0]})}`+
  `<path d="M44 100 L66 100 L64 106 L46 106 Z" fill="${FMOUTH}"/><path d="M48 100 l2 3 l2 -3 M56 100 l2 3 l2 -3" fill="#FFFFFF"/>`+pt("jaw",66,104,`<path d="M66 104 Q56 114 44 106 Q56 110 66 108 Z" fill="${P.d}" ${SW2}/>`))+
 fG(g,1,`<circle cx="40" cy="60" r="3" fill="none" stroke="#8AB4D8" stroke-width="1.6"/>`)+
 fG(g,2,`<path d="M100 96 h20" stroke="${P.ac}" stroke-width="2.4"/>`)+
 fG(g,3,star(118,30,6)));
FORM_TITLE["Old Well Blend"]="Anvil Shark";
