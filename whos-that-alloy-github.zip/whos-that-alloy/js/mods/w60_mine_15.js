/* ---- Rustvein Mine, 15 ---- */
/* Unit Nine No. 3: the sorting robot tried this recipe forty-one times. A tracked robo-tortoise with a sorting arm, still trying. */
addForm("Unit Nine No. 3",{n:"#8A9AA8",a:"#E8A040",rn:"#3A3A4A",rb:"#5AB04A",ra:"#5FE0F0"},"crawl",(P,g)=>fShadow(70)+
 `<rect x="62" y="122" width="96" height="20" rx="10" fill="#2A2A30" ${SW}/>${[72,88,104,120,136,148].map(x=>`<circle cx="${x}" cy="132" r="5" fill="${P.d}" ${SW2}/>`).join("")}`+pt("spin",72,132,`<path d="M66 132 h12 M72 126 v12" stroke="${P.ll}" stroke-width="1.6"/>`)+
 `<path d="M68 124 Q70 84 112 82 Q154 84 156 124 Z" fill="${P.n}" ${SW}/>${[[96,98],[112,92],[128,98],[104,112],[122,112]].map(([x,y])=>`<path d="M${x-7} ${y} l3.5 -6 h7 l3.5 6 l-3.5 6 h-7 Z" fill="${P.nd}" ${SW2}/>`).join("")}<rect x="132" y="104" width="16" height="10" rx="2" fill="#1A2A3A" ${SW2}/><text x="134" y="112" font-size="6" fill="#5AB04A" font-family="monospace">41</text>`+
 pt("armB",120,84,`<path d="M120 84 L132 56 L156 52" stroke="${FI}" stroke-width="6" fill="none" stroke-linejoin="round"/><path d="M120 84 L132 56 L156 52" stroke="${P.ac}" stroke-width="3.6" fill="none" stroke-linejoin="round"/><circle cx="132" cy="56" r="4" fill="${P.d}" ${SW2}/><path d="M156 52 l8 -6 M156 52 l8 6" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><rect x="164" y="44" width="12" height="12" fill="#B88A50" ${SW2}/>`,.3)+
 pt("head",68,108,`<path d="M72 112 L52 104" stroke="${FI}" stroke-width="9" stroke-linecap="round"/><path d="M72 112 L52 104" stroke="${P.nd}" stroke-width="6" stroke-linecap="round"/><rect x="26" y="88" width="32" height="24" rx="5" fill="${P.n}" ${SW}/><rect x="30" y="92" width="22" height="9" rx="3" fill="#1A2A3A" ${SW2}/><circle cx="36" cy="96.5" r="2.4" fill="#5FE0F0"/><circle cx="46" cy="96.5" r="2.4" fill="#5FE0F0"/>`+pt("jaw",42,108,`<rect x="30" y="104" width="22" height="5" rx="2" fill="${P.nd}" ${SW2}/>`))+
 fG(g,1,`<text x="20" y="40" font-family="monospace" font-size="11" font-weight="bold" fill="${P.ac}">RETRY</text>`)+fG(g,2,`<circle cx="112" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,50,6)));
FORM_TITLE["Unit Nine No. 3"]="Tracked Robo-Tortoise";SM("Unit Nine No. 3","Forty-First Try","STR","a",60,100,"acc+1","Change one thing. Try again. And again. And again.");

/* Unknown Snack: shortbread crumbs made the scanner read everything as 'unknown snack'. A little snack goblin, cheeks full of crumbs. */
addForm("Unknown Snack",{n:"#7AA85A",a:"#E8C890",rn:"#3A3A4A",rb:"#B85AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",116,124,fOL("M114 120 L120 140 H130",P.nd,8),.5)+
 `<path d="M82 124 Q78 96 104 92 Q130 96 128 124 Q122 140 104 140 Q86 140 82 124 Z" fill="${P.n}" ${SW}/><path d="M88 110 Q104 104 122 110 L120 132 Q104 136 90 132 Z" fill="#8A5A3A" ${SW2}/>`+
 pt("legF",92,124,fOL("M94 120 L88 140 H76",P.n,8))+
 pt("armB",124,108,fOL("M124 108 Q138 114 140 104",P.nd,6),.4)+
 pt("armF",86,106,fOL("M86 106 Q70 104 66 92",P.n,6)+`<rect x="54" y="78" width="20" height="14" rx="2" fill="${P.ac}" ${SW2}/><path d="M56 82 h16 M56 86 h16" stroke="#C8A060" stroke-width="1"/><path d="M68 78 l4 -4 l4 6 Z" fill="#fff"/>`)+
 pt("head",104,74,`<path d="M78 76 Q76 50 104 48 Q132 50 130 76 Q126 94 104 94 Q82 94 78 76 Z" fill="${P.n}" ${SW}/><ellipse cx="88" cy="80" rx="9" ry="7" fill="${P.nl}" opacity=".8"/><ellipse cx="120" cy="80" rx="9" ry="7" fill="${P.nl}" opacity=".8"/>${E2(94,68,4.4,"#E8A020")}${E2(114,68,4.4,"#E8A020")}`+HMOUTH(98,82,110,P,3)+`${[[96,90],[104,92],[112,90]].map(([x,y])=>`<rect x="${x}" y="${y}" width="3" height="3" fill="${P.ac}" ${SW2}/>`).join("")}`+
  pt("ear",78,64,`<path d="M80 64 L56 52 L78 72 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",130,64,`<path d="M128 64 L152 52 L130 72 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`${[[30,130],[40,136],[160,132],[150,138],[170,138]].map(([x,y])=>`<rect x="${x}" y="${y}" width="4" height="4" fill="${P.ac}" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="104" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Unknown Snack"]="Snack Goblin";SM("Unknown Snack","Crumb Clog","RES","a",50,100,"tacc-1,tspd-1@30","Crumbs in the works. Nothing reads right for an hour.");

/* Unlabelled Tallis: every crate labelled but one. A kiwi with a blank luggage tag tied round its neck. */
addForm("Unlabelled Tallis",{n:"#7A5A3A",a:"#E8D8C0",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(54)+
 pt("legB",116,118,`<path d="M114 116 L118 140" stroke="${FI}" stroke-width="5"/><path d="M114 116 L118 140" stroke="#C8A080" stroke-width="3"/><path d="M110 142 h16 M118 140 l-4 4" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M74 100 Q76 66 112 64 Q146 68 148 100 Q142 124 112 124 Q80 124 74 100 Z" fill="${P.n}" ${SW}/>${Array.from({length:14},(_,i)=>`<path d="M${82+(i%7)*9} ${76+Math.floor(i/7)*18} q2 8 -1 14" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("legF",100,118,`<path d="M100 116 L98 140" stroke="${FI}" stroke-width="5"/><path d="M100 116 L98 140" stroke="#C8A080" stroke-width="3"/><path d="M90 142 h16 M98 140 l4 4" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",78,80,`<circle cx="74" cy="78" r="13" fill="${P.n}" ${SW}/>${E2(70,74,2.8,"#1A1A1A")}<path d="M62 78 Q40 86 22 108" stroke="${FI}" stroke-width="5.4" fill="none" stroke-linecap="round"/>`+pt("beak",44,92,`<path d="M62 80 Q42 90 24 110" stroke="#E8D8B8" stroke-width="3" fill="none" stroke-linecap="round"/>`)+`<path d="M62 78 Q40 86 22 108" stroke="#E8D8B8" stroke-width="3.4" fill="none" stroke-linecap="round"/>`+
  `<path d="M80 88 Q84 96 90 98" stroke="${FI}" stroke-width="1.4" fill="none"/><g transform="rotate(12 96 104)"><path d="M88 96 H108 V112 H88 L84 104 Z" fill="${P.ac}" ${SW2}/><circle cx="88" cy="104" r="1.6" fill="${FI}"/></g>`)+
 fG(g,1,`${[0,1,2].map(i=>`<rect x="${150+i*14}" y="124" width="12" height="12" fill="#B88A50" ${SW2}/><rect x="${152+i*14}" y="127" width="8" height="4" fill="#F4F0E4"/>`).join("")}`)+fG(g,2,`<circle cx="112" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(130,40,6)));
FORM_TITLE["Unlabelled Tallis"]="Blank-Tag Kiwi";SM("Unlabelled Tallis","No Label","RES","s",0,100,"dodge,tacc-1","If there's no label, nobody knows what to expect.");


/* Unrhymium: nobody can rhyme with its catalogue number. A nightingale with a quill, a long scroll of crossed-out attempts. */
addForm("Unrhymium",{n:"#8A6A5A",a:"#F4E8D0",rn:"#3A3A4A",rb:"#5A3A8A",ra:"#E8412C"},"stand",(P,g)=>`<path d="M20 146 Q20 120 34 118 L72 118 Q60 128 60 146 Z" fill="${P.ac}" ${SW}/>${[124,130,136,142].map((y,i)=>`<path d="M${30} ${y} h${22-i*3}" stroke="#6A6A7A" stroke-width="1"/><path d="M${28} ${y-1} l${24-i*3} 2" stroke="#C8302A" stroke-width="1"/>`).join("")}`+fShadow(50,110)+
 pt("tail",136,92,`<path d="M130 88 L160 84 L156 98 L132 100 Z" fill="#B8603A" ${SW}/>`)+
 pt("legB",116,110,`<path d="M116 108 L118 140" stroke="#C8A0A0" stroke-width="3"/><path d="M110 142 h14" stroke="#C8A0A0" stroke-width="2.4" stroke-linecap="round"/>`,.5)+
 `<path d="M86 98 Q88 74 112 72 Q134 76 136 98 Q128 114 108 114 Q90 112 86 98 Z" fill="${P.n}" ${SW}/><path d="M90 100 Q104 112 122 108 Q110 100 100 90 Z" fill="${P.ac}"/>`+
 pt("wingF",112,90,`<path d="M102 86 Q126 82 138 98 Q122 108 106 102 Z" fill="${P.nd}" ${SW}/>`)+
 pt("legF",102,110,`<path d="M102 108 L100 140" stroke="#C8A0A0" stroke-width="3"/><path d="M92 142 h14" stroke="#C8A0A0" stroke-width="2.4" stroke-linecap="round"/>`)+
 pt("head",94,72,`<circle cx="90" cy="66" r="13" fill="${P.n}" ${SW}/>${E2(86,62,3.6,"#1A1A1A")}<circle cx="86" cy="62" r="5.4" fill="none" stroke="${P.ac}" stroke-width="1.6"/>`+
  `<path d="M78 64 L66 66 L78 70 Z" fill="${FMOUTH}"/>`+pt("beak",78,70,`<path d="M78 70 L67 70 L78 73 Z" fill="${FI}"/>`)+`<path d="M78 62 L64 66 L78 66 Z" fill="${FI}"/>`+
  `<path d="M100 54 L124 26" stroke="${FI}" stroke-width="3" stroke-linecap="round"/><path d="M106 48 Q120 20 132 18 Q126 34 112 48 Z" fill="#F4F0F4" ${SW2}/>`)+
 fG(g,1,`<path d="M150 40 v-14 l8 3 M164 46 v-14 l8 3" stroke="${FI}" stroke-width="2" fill="none"/><circle cx="148" cy="40" r="3" fill="${FI}"/><circle cx="162" cy="46" r="3" fill="${FI}"/>`)+fG(g,2,`<circle cx="110" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Unrhymium"]="Quill Nightingale";SM("Unrhymium","Eleven Stanzas","RES","a",30,100,"multi:2-4","It doesn't rhyme. It never rhymes. It keeps going anyway.");

/* Unspellium: eleven spelling-bee finalists cried; the twelfth spelled it perfectly. A bee carrying letter tiles, spelling as it buzzes. */
addForm("Unspellium",{n:"#E8B030",a:"#2A2A30",rn:"#E8E0D0",rb:"#5A8AC8",ra:"#E8412C"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="28" ry="3" fill="#000" opacity=".1"/>`+
 pt("wingB",112,62,`<ellipse cx="124" cy="48" rx="20" ry="12" fill="#E8F4F8" opacity=".75" ${SW2} transform="rotate(-24 124 48)"/>`,.2)+
 pt("tail",140,84,`<path d="M136 80 L152 86 L136 92 Z" fill="${FI}"/>`)+
 `<ellipse cx="112" cy="84" rx="28" ry="20" fill="${P.n}" ${SW}/>${[100,112,124].map(x=>`<path d="M${x} 66 Q${x+4} 84 ${x} 102" stroke="${P.ac}" stroke-width="6" fill="none"/>`).join("")}<path d="M88 76 Q92 70 100 70" stroke="#fff" stroke-width="2.4" fill="none" opacity=".6"/>`+
 pt("wingF",100,62,`<ellipse cx="92" cy="46" rx="20" ry="12" fill="#E8F4F8" opacity=".8" ${SW2} transform="rotate(20 92 46)"/>`)+
 [[96,"legF",0],[108,"legB",.3],[120,"legB",.6]].map(([x,c,d])=>pt(c,x,102,`<path d="M${x} 102 L${x-4} 112 L${x} 118" stroke="${FI}" stroke-width="2" fill="none"/>`,d)).join("")+
 `${[["S",80,124],["P",96,128],["E",112,126],["L",128,130]].map(([l,x,y],i)=>`<rect x="${x-7}" y="${y-7}" width="14" height="14" rx="2" fill="#F4E8C0" ${SW2} transform="rotate(${(i-1.5)*8} ${x} ${y})"/><text x="${x-4}" y="${y+4}" font-size="10" font-weight="bold" fill="${FI}">${l}</text>`).join("")}`+
 pt("head",80,80,`<circle cx="78" cy="78" r="13" fill="${P.n}" ${SW}/>${E2(72,74,4.4,"#1A1A1A")}${E2(84,74,4,"#1A1A1A")}`+HMOUTH(70,84,80,P,2.4)+pt("ant",78,66,`<path d="M74 66 Q68 50 60 48 M82 66 Q84 50 92 46" stroke="${FI}" stroke-width="1.6" fill="none"/><circle cx="60" cy="48" r="2.4" fill="${FI}"/><circle cx="92" cy="46" r="2.4" fill="${FI}"/>`))+
 fG(g,1,`<path d="M20 100 q6 -6 12 0 q6 6 12 0" stroke="${FI}" stroke-width="1.6" stroke-dasharray="2 3" fill="none"/>`)+fG(g,2,`<circle cx="112" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Unspellium"]="Spelling Bee";SM("Unspellium","Spell It Out","SCR","a",65,100,"crit","Every letter in the right place. Every single one.");

/* Wendellium: filed by a temp worker on her first and last day. A meerkat in a lanyard, standing very straight at its post. */
addForm("Wendellium",{n:"#C8A070",a:"#3A3A40",rn:"#E8D8C8",rb:"#3A6AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,110)+
 pt("tail",116,128,`<path d="M114 128 Q138 132 146 120" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M114 128 Q138 132 146 120" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M142 122 l6 -4" stroke="${P.ac}" stroke-width="5" stroke-linecap="round"/>`)+
 pt("legB",110,134,`<ellipse cx="112" cy="140" rx="9" ry="4" fill="${P.nd}" ${SW2}/>`,.5)+
 `<path d="M92 134 Q86 96 98 76 Q106 70 114 76 Q124 98 118 136 Q104 142 92 134 Z" fill="${P.n}" ${SW}/><path d="M98 92 Q104 86 112 92 Q114 112 110 130 Q102 132 98 126 Q96 108 98 92 Z" fill="${P.nl}" opacity=".8"/>`+
 `<path d="M98 78 L104 104 L112 78" stroke="#C8302A" stroke-width="2.4" fill="none"/><rect x="98" y="104" width="14" height="18" rx="2" fill="#F4F0E4" ${SW2}/><rect x="101" y="107" width="8" height="6" fill="#A8C8E8"/><path d="M101 116 h8 M101 119 h6" stroke="${FI}" stroke-width="1"/>`+
 pt("legF",96,134,`<ellipse cx="94" cy="140" rx="9" ry="4" fill="${P.n}" ${SW2}/>`)+
 pt("armF",98,90,`<path d="M98 88 Q90 94 94 100" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M98 88 Q90 94 94 100" stroke="${P.n}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+pt("armB",114,90,`<path d="M114 88 Q122 94 118 100" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M114 88 Q122 94 118 100" stroke="${P.nd}" stroke-width="3.4" fill="none" stroke-linecap="round"/>`,.4)+
 pt("head",104,64,`<path d="M86 64 Q86 46 104 44 Q120 46 120 60 Q116 72 104 74 L90 70 Z" fill="${P.n}" ${SW}/><path d="M86 64 L78 66 L88 70 Z" fill="${P.n}" ${SW2}/><circle cx="79" cy="66" r="2" fill="${FI}"/><path d="M92 56 Q98 50 104 58 Q98 62 92 56 Z" fill="${P.ac}"/>${E2(98,56,3,"#1A1A1A")}`+HMOUTH(82,70,90,P,2)+pt("ear",112,50,`<circle cx="114" cy="52" r="3.4" fill="${P.ac}" ${SW2}/>`))+
 fG(g,1,`<rect x="150" y="110" width="30" height="30" fill="#8A6A4A" ${SW2}/><rect x="154" y="114" width="22" height="10" fill="#F4F0E4" ${SW2}/>`)+fG(g,2,`<circle cx="105" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Wendellium"]="Temp-Worker Meerkat";SM("Wendellium","First And Last Day","STR","a",85,100,"selfspd-1","Do one thing perfectly, then never come back.");

/* Whisperite: the night guards hear whispering in the vents; it only ever asks one thing. A small dragon curled in the ductwork, whispering through the grille. */
addForm("Whisperite",{n:"#5A6A8A",a:"#B8C8E8",rn:"#3A3A4A",rb:"#E8A060",ra:"#5FE0A0"},"perch",(P,g)=>`<rect x="40" y="40" width="140" height="80" rx="4" fill="#B8B8C0" ${SW}/><rect x="48" y="48" width="124" height="64" fill="#6A6A74" ${SW2}/>`+fShadow(66)+
 pt("tail",150,92,`<path d="M146 96 Q170 92 168 70 Q164 58 156 62" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M146 96 Q170 92 168 70 Q164 58 156 62" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M152 60 l6 -8 l2 8 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("wingB",128,70,`<path d="M124 74 Q136 50 160 50 Q150 62 152 70 Q140 72 132 82 Z" fill="${P.nd}" ${SW}/>`,.3)+
 `<path d="M80 98 Q82 74 112 72 Q144 74 148 96 Q142 110 112 110 Q84 110 80 98 Z" fill="${P.n}" ${SW}/>${[90,100,110,120,130].map(x=>`<path d="M${x} 74 l3 -6 l3 6" fill="${P.ac}" ${SW2}/>`).join("")}`+
 pt("head",80,86,`<path d="M54 90 Q54 72 72 70 Q90 72 92 88 Q88 102 72 102 Z" fill="${P.n}" ${SW}/>${E2(70,82,4.4,"#E8A020",[-.6,0])}<path d="M64 72 l-6 -8 M74 70 l2 -10" stroke="${P.ac}" stroke-width="3" stroke-linecap="round"/>`+HMOUTH(56,94,64,P,2.4)+
  pt("slow",48,92,`<path d="M48 92 q-8 -4 -12 2 q-4 6 -12 2" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/><path d="M48 98 q-10 0 -14 6" stroke="${P.ac}" stroke-width="1.6" fill="none" opacity=".5"/>`))+
 `<g opacity=".9">${[52,60,68,76,84,92,100,108,116,124,132,140,148,156,164].map(x=>`<path d="M${x} 48 V112" stroke="#C8C8D0" stroke-width="3"/>`).join("")}</g>`+
 fG(g,1,`<text x="18" y="140" font-family="Georgia,serif" font-size="11" font-style="italic" fill="${P.ac}">...where?</text>`)+fG(g,2,`<circle cx="112" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,30,6)));
FORM_TITLE["Whisperite"]="Ductwork Dragonet";SM("Whisperite","Whisper In The Vents","RES","s",0,100,"tatk-1,tacc-1,irr@20","It's only the building settling. Probably.");

/* Wreckite: from a wreck whose name had been painted over. A moray eel looking out of the wreck's porthole. */
addForm("Wreckite",{n:"#5A6A3A",a:"#E8D040",rn:"#3A3A4A",rb:"#7AB8C8",ra:"#E8412C"},"swim",(P,g)=>`<path d="M60 146 L70 30 Q130 20 190 40 L194 146 Z" fill="#5A4A3A" ${SW}/>${[50,70,90,110,130].map(y=>`<path d="M${66+(y-30)*-.08} ${y} H194" stroke="#4A3A2A" stroke-width="2"/>`).join("")}<rect x="100" y="34" width="60" height="12" fill="#7A6A5A" ${SW2}/><path d="M104 36 h52 v8 h-52 Z" fill="#3A3A44" opacity=".7"/>`+
 `<circle cx="104" cy="96" r="34" fill="${P.b}" ${SW}/><circle cx="104" cy="96" r="26" fill="#1A2A3A" ${SW2}/>${[0,1,2,3,4,5,6,7].map(i=>`<circle cx="${104+Math.cos(i*.785)*30}" cy="${96+Math.sin(i*.785)*30}" r="2.4" fill="${P.d}" ${SW2}/>`).join("")}`+
 pt("sway",96,100,`<path d="M120 112 Q100 120 86 110 Q72 98 68 82" stroke="${FI}" stroke-width="24" fill="none" stroke-linecap="round"/><path d="M120 112 Q100 120 86 110 Q72 98 68 82" stroke="${P.n}" stroke-width="20" fill="none" stroke-linecap="round"/>${[[90,110],[100,114],[80,100],[74,90]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.4" fill="${P.ac}" opacity=".7"/>`).join("")}`+
  pt("head",60,74,`<path d="M40 74 Q40 60 58 58 Q76 60 78 74 Q76 86 60 88 Z" fill="${P.n}" ${SW}/>${E2(62,66,3.6,"#E8D040")}<path d="M42 76 L62 76 L60 80 L44 80 Z" fill="${FMOUTH}"/>`+pt("jaw",58,80,`<path d="M42 80 L62 80 Q56 90 44 86 Z" fill="${P.nd}" ${SW2}/><path d="M46 80 l2 3 l2 -3 l2 3 l2 -3" stroke="#fff" stroke-width="1.2" fill="none"/>`)))+
 fG(g,1,`<circle cx="30" cy="40" r="4" fill="#E8F4F8" ${SW2}/><circle cx="24" cy="54" r="2.6" fill="#E8F4F8" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,110,6)));
FORM_TITLE["Wreckite"]="Porthole Moray";SM("Wreckite","From The Deep","SCR","a",80,95,"crit","It waits in the dark of the wreck, and doesn't miss.");

/* Year Three Mix: a swapped date means it was technically made in the year 3. A trilobite, from a very long time before the year 3. */
addForm("Year Three Mix",{n:"#8A7A6A",a:"#C8B090",rn:"#3A3A4A",rb:"#5AB0C8",ra:"#E8604A"},"crawl",(P,g)=>`<path d="M14 140 H194 V148 H14 Z" fill="#C8B8A0" ${SW2}/>`+fShadow(60)+
 Array.from({length:8},(_,i)=>pt(i%2?"legB":"legF",76+i*10,130,`<path d="M${76+i*10} 128 L${72+i*10} 140" stroke="${FI}" stroke-width="2"/>`,i*.12)).join("")+
 pt("tail",150,126,`<path d="M148 122 Q166 124 172 132 Q160 136 148 132 Z" fill="${P.nd}" ${SW}/>`)+
 `<path d="M60 128 Q62 92 104 88 Q146 92 152 128 Z" fill="${P.n}" ${SW}/>${[0,1,2,3,4,5,6,7].map(i=>`<path d="M${66+i*10.5} 128 Q${68+i*10.5} ${100} ${76+i*10} ${94}" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}<path d="M60 112 Q104 104 150 112" stroke="${P.ac}" stroke-width="4" fill="none" opacity=".6"/><path d="M78 92 Q104 86 130 92" stroke="${P.ndd}" stroke-width="10" fill="none" opacity=".3"/>`+
 pt("head",60,118,`<path d="M30 130 Q30 102 58 100 Q76 102 78 128 Z" fill="${P.n}" ${SW}/><path d="M30 130 L22 138 M78 128 L88 138" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/><ellipse cx="44" cy="110" rx="6" ry="5" fill="${P.nd}" ${SW2}/><ellipse cx="62" cy="108" rx="6" ry="5" fill="${P.nd}" ${SW2}/>${[[42,108],[46,111],[60,106],[64,109]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1" fill="${FI}"/>`).join("")}<circle cx="44" cy="110" r="2.4" fill="${FI}"/><circle cx="62" cy="108" r="2.4" fill="${FI}"/>`+pt("ant",40,104,`<path d="M40 104 Q26 92 16 96 M54 102 Q48 86 36 80" stroke="${FI}" stroke-width="1.6" fill="none"/>`))+
 fG(g,1,`<text x="150" y="40" font-size="14" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">AD 3</text>`)+fG(g,2,`<circle cx="104" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,40,6)));
FORM_TITLE["Year Three Mix"]="Misdated Trilobite";SM("Year Three Mix","Ancient Armour","RES","s",0,100,"def+2","Older than anyone thought. Much, much older.");
