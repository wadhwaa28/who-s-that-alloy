/* ---- wisps, ghosts, spirits and other floating presences ---- */
FGP.wisp={hab:{"z-crater":3.5,"z-reactor":3,"z-glacier":1.4,"z-vault":1.6,"z-volcano":1.4,"z-mine":1,"z-scrap":.8,"z-wreck":1.2},loco:"hover",want:(tr,a)=>(tr.rad?2.2:1)*(tr.light?1.4:1)*(a.rar==="legendary"?2:a.rar==="rare"?1.4:.8),
 sp:["Wisp","Will-o'-the-Wisp","Spook","Shade","Phantom","Wraith","Banshee","Poltergeist","Fetch","Lantern Spirit","Kodama","Djinn","Ifrit","Sylph","Undine","Ember Spirit","Hitodama","Ignis Fatuus","Fogling","Glimmer","Echo","Revenant","Spectre","Boggart","Mote","Bogle","Nymph","Kami","Yokai","Will-o'-Wick"],
 gen(r,tr,a){const o={sp:fgPick(r,this.sp)};o.shape=fgPick(r,["flame","sheet","orb","teardrop","cloud","star"]);o.arms=fgPick(r,["none","wisps","hands","sleeves"]);o.face=fgPick(r,["eyes","hollow","one","mask","smile"]);
  o.crown=fgPick(r,["none","none","flames","halo","horns","antenna","embers"]);o.trail=fgPick(r,["curl","fork","fade","chain","sparks"]);o.orbit=r()<.4;o.H=R1(48+r()*16);return o},
 draw(P,g,o){const cx=104,cy=84,H=o.H,W=H*.82;let s=`<ellipse class="shd" cx="${cx}" cy="150" rx="${R1(W*.5)}" ry="4" fill="#000" opacity=".14"/><circle cx="${cx}" cy="${cy}" r="${R1(H*.7)}" fill="${P.ac}" opacity=".14"/>`;
  const tr={curl:`M${cx-W*.3} ${cy+H*.3} Q${cx-W*.1} ${cy+H*.9} ${cx+W*.3} ${cy+H*.75} Q${cx+W*.7} ${cy+H*.6} ${cx+W*.5} ${cy+H*.35} Q${cx+W*.35} ${cy+H*.55} ${cx+W*.1} ${cy+H*.55} Q${cx+W*.2} ${cy+H*.35} ${cx+W*.3} ${cy+H*.3} Z`,
   fork:`M${cx-W*.35} ${cy+H*.25} L${cx-W*.2} ${cy+H*.9} L${cx} ${cy+H*.45} L${cx+W*.2} ${cy+H*.95} L${cx+W*.35} ${cy+H*.25} Z`,fade:`M${cx-W*.38} ${cy+H*.25} Q${cx} ${cy+H*1.1} ${cx+W*.38} ${cy+H*.25} Z`,
   chain:`M${cx-W*.3} ${cy+H*.3} Q${cx} ${cy+H*.6} ${cx+W*.3} ${cy+H*.3} Z`,sparks:`M${cx-W*.34} ${cy+H*.28} Q${cx-W*.1} ${cy+H*.8} ${cx+W*.05} ${cy+H*.95} Q${cx+W*.1} ${cy+H*.6} ${cx+W*.34} ${cy+H*.28} Z`}[o.trail];
  s+=pt("tail",cx,R1(cy+H*.3),`<path d="${tr}" fill="${P.nd}" ${SW}/>`+(o.trail==="chain"?[0,1,2].map(i=>`<ellipse cx="${cx+4}" cy="${R1(cy+H*.6+i*9)}" rx="4" ry="5.6" fill="none" stroke="${FI}" stroke-width="3"/><ellipse cx="${cx+4}" cy="${R1(cy+H*.6+i*9)}" rx="4" ry="5.6" fill="none" stroke="${P.l}" stroke-width="1.4"/>`).join(""):o.trail==="sparks"?`<g class="p-glow">${[[-10,40],[12,46],[2,56]].map(([dx,dy])=>`<circle cx="${cx+dx}" cy="${R1(cy+dy*H/56)}" r="2.4" fill="${P.ac}"/>`).join("")}</g>`:""));
  if(o.arms!=="none"){const A=(side,c)=>o.arms==="wisps"?`<path d="M${R1(cx+side*W*.4)} ${R1(cy)} Q${R1(cx+side*W*.9)} ${R1(cy-H*.1)} ${R1(cx+side*W*.8)} ${R1(cy+H*.3)} Q${R1(cx+side*W*.7)} ${R1(cy+H*.1)} ${R1(cx+side*W*.4)} ${R1(cy+H*.15)} Z" fill="${c}" ${SW2}/>`
    :o.arms==="hands"?fOL(`M${R1(cx+side*W*.4)} ${R1(cy)} Q${R1(cx+side*W*.75)} ${R1(cy+H*.05)} ${R1(cx+side*W*.8)} ${R1(cy+H*.3)}`,c,4)+`<path d="M${R1(cx+side*W*.8-4)} ${R1(cy+H*.3)} l-3 6 M${R1(cx+side*W*.8)} ${R1(cy+H*.32)} l0 7 M${R1(cx+side*W*.8+4)} ${R1(cy+H*.3)} l3 6" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`
    :`<path d="M${R1(cx+side*W*.35)} ${R1(cy-H*.1)} Q${R1(cx+side*W*.95)} ${R1(cy)} ${R1(cx+side*W*.85)} ${R1(cy+H*.35)} L${R1(cx+side*W*.55)} ${R1(cy+H*.25)} Q${R1(cx+side*W*.5)} ${R1(cy+H*.1)} ${R1(cx+side*W*.35)} ${R1(cy+H*.15)} Z" fill="${c}" ${SW2}/>`;
   s+=pt("armB",R1(cx+W*.4),R1(cy),A(1,P.nd),.5)}
  const body={flame:`M${cx} ${cy-H*.75} Q${cx+W*.12} ${cy-H*.45} ${cx+W*.3} ${cy-H*.55} Q${cx+W*.5} ${cy-H*.1} ${cx+W*.45} ${cy+H*.2} Q${cx+W*.3} ${cy+H*.45} ${cx} ${cy+H*.45} Q${cx-W*.3} ${cy+H*.45} ${cx-W*.45} ${cy+H*.2} Q${cx-W*.5} ${cy-H*.15} ${cx-W*.25} ${cy-H*.45} Q${cx-W*.15} ${cy-H*.3} ${cx} ${cy-H*.75} Z`,
   sheet:`M${cx-W*.45} ${cy+H*.35} Q${cx-W*.5} ${cy-H*.6} ${cx} ${cy-H*.6} Q${cx+W*.5} ${cy-H*.6} ${cx+W*.45} ${cy+H*.35} Q${cx+W*.3} ${cy+H*.25} ${cx+W*.15} ${cy+H*.4} Q${cx} ${cy+H*.25} ${cx-W*.15} ${cy+H*.4} Q${cx-W*.3} ${cy+H*.25} ${cx-W*.45} ${cy+H*.35} Z`,
   orb:fgEll(cx,cy-H*.05,W*.45,H*.45),teardrop:`M${cx} ${cy-H*.75} Q${cx+W*.5} ${cy-H*.05} ${cx+W*.42} ${cy+H*.2} Q${cx+W*.3} ${cy+H*.45} ${cx} ${cy+H*.45} Q${cx-W*.3} ${cy+H*.45} ${cx-W*.42} ${cy+H*.2} Q${cx-W*.5} ${cy-H*.05} ${cx} ${cy-H*.75} Z`,
   cloud:`M${cx-W*.45} ${cy+H*.3} Q${cx-W*.6} ${cy} ${cx-W*.35} ${cy-H*.2} Q${cx-W*.3} ${cy-H*.6} ${cx} ${cy-H*.5} Q${cx+W*.3} ${cy-H*.65} ${cx+W*.38} ${cy-H*.2} Q${cx+W*.6} ${cy} ${cx+W*.45} ${cy+H*.3} Z`,
   star:`M${cx} ${cy-H*.65} L${cx+W*.14} ${cy-H*.2} L${cx+W*.5} ${cy-H*.15} L${cx+W*.22} ${cy+H*.12} L${cx+W*.32} ${cy+H*.48} L${cx} ${cy+H*.28} L${cx-W*.32} ${cy+H*.48} L${cx-W*.22} ${cy+H*.12} L${cx-W*.5} ${cy-H*.15} L${cx-W*.14} ${cy-H*.2} Z`}[o.shape];
  s+=`<path d="${body}" fill="${P.n}" ${SW}/><path d="M${R1(cx-W*.25)} ${R1(cy-H*.25)} Q${R1(cx-W*.1)} ${R1(cy-H*.45)} ${R1(cx+W*.1)} ${R1(cy-H*.4)}" stroke="${P.nll}" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/>`;
  if(o.crown==="flames")s+=pt("ear",cx,R1(cy-H*.55),`<path class="p-glow" d="M${R1(cx-W*.2)} ${R1(cy-H*.5)} Q${R1(cx-W*.2)} ${R1(cy-H*.95)} ${R1(cx-W*.05)} ${R1(cy-H*.75)} Q${cx} ${R1(cy-H*1.05)} ${R1(cx+W*.08)} ${R1(cy-H*.7)} Q${R1(cx+W*.22)} ${R1(cy-H*.9)} ${R1(cx+W*.2)} ${R1(cy-H*.5)} Z" fill="${P.ac}" ${SW2}/>`);
  if(o.crown==="halo")s+=pt("ear",cx,R1(cy-H*.8),`<ellipse class="p-glow" cx="${cx}" cy="${R1(cy-H*.8)}" rx="${R1(W*.3)}" ry="5" fill="none" stroke="${FI}" stroke-width="5"/><ellipse cx="${cx}" cy="${R1(cy-H*.8)}" rx="${R1(W*.3)}" ry="5" fill="none" stroke="${P.ac}" stroke-width="2.6"/>`);
  if(o.crown==="horns")s+=fgHorn("curve",R1(cx+W*.2),R1(cy-H*.5),P,.9,1)+fgHorn("curve",R1(cx-W*.2),R1(cy-H*.5),P,.9,-1);
  if(o.crown==="antenna")s+=pt("ant",cx,R1(cy-H*.55),`<path d="M${cx} ${R1(cy-H*.55)} Q${R1(cx-6)} ${R1(cy-H*.85)} ${R1(cx+4)} ${R1(cy-H*.95)}" stroke="${FI}" stroke-width="2" fill="none"/><circle class="p-glow" cx="${R1(cx+4)}" cy="${R1(cy-H*.98)}" r="4" fill="${P.ac}" ${SW2}/>`);
  if(o.crown==="embers")s+=`<g class="p-glow">${[[-.2,-.8],[.1,-.95],[.25,-.75]].map(([dx,dy])=>`<circle cx="${R1(cx+dx*W)}" cy="${R1(cy+dy*H)}" r="2.6" fill="${P.ac}"/>`).join("")}</g>`;
  if(o.orbit)s+=`<g class="p-slow" style="transform-origin:${cx}px ${cy}px">${[0,2.1,4.2].map(a=>`<circle cx="${R1(cx+Math.cos(a)*W*.7)}" cy="${R1(cy+Math.sin(a)*H*.5)}" r="3.4" fill="${P.ll}" ${SW2}/>`).join("")}</g>`;
  let h="";const fx=cx-W*.06,fy=cy-H*.08;
  if(o.face==="eyes")h+=fgEye(R1(fx-W*.13),R1(fy),R1(W*.1),P.ac)+fgEye(R1(fx+W*.13),R1(fy),R1(W*.1),P.ac);
  if(o.face==="hollow")h+=`<ellipse cx="${R1(fx-W*.13)}" cy="${R1(fy)}" rx="${R1(W*.08)}" ry="${R1(W*.12)}" fill="${FI}"/><ellipse cx="${R1(fx+W*.13)}" cy="${R1(fy)}" rx="${R1(W*.08)}" ry="${R1(W*.12)}" fill="${FI}"/><circle class="p-glow" cx="${R1(fx-W*.13)}" cy="${R1(fy)}" r="2" fill="${P.ac}"/><circle class="p-glow" cx="${R1(fx+W*.13)}" cy="${R1(fy)}" r="2" fill="${P.ac}"/>`;
  if(o.face==="one")h+=fgEye(R1(fx),R1(fy),R1(W*.16),P.ac);
  if(o.face==="mask")h+=`<path d="M${R1(fx-W*.3)} ${R1(fy-W*.12)} Q${R1(fx)} ${R1(fy-W*.2)} ${R1(fx+W*.3)} ${R1(fy-W*.12)} Q${R1(fx+W*.25)} ${R1(fy+W*.25)} ${R1(fx)} ${R1(fy+W*.28)} Q${R1(fx-W*.25)} ${R1(fy+W*.25)} ${R1(fx-W*.3)} ${R1(fy-W*.12)} Z" fill="#F4F0E4" ${SW2}/><path d="M${R1(fx-W*.18)} ${R1(fy)} q4 -4 8 0 M${R1(fx+W*.08)} ${R1(fy)} q4 -4 8 0" stroke="${FI}" stroke-width="2.4" fill="none"/><path d="M${R1(fx-W*.15)} ${R1(fy-W*.2)} l3 -5 M${R1(fx+W*.15)} ${R1(fy-W*.2)} l-3 -5" stroke="#E8412C" stroke-width="1.6"/>`;
  if(o.face==="smile")h+=`<path d="M${R1(fx-W*.18)} ${R1(fy-2)} q4 -5 8 0 M${R1(fx+W*.08)} ${R1(fy-2)} q4 -5 8 0" stroke="${FI}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`;
  h+=`<path d="M${R1(fx-W*.12)} ${R1(fy+W*.18)} Q${R1(fx)} ${R1(fy+W*.3)} ${R1(fx+W*.12)} ${R1(fy+W*.18)} Z" fill="${FMOUTH}" ${SW2}/>`+pt("jaw",R1(fx+W*.12),R1(fy+W*.2),`<path d="M${R1(fx+W*.12)} ${R1(fy+W*.2)} Q${R1(fx)} ${R1(fy+W*.38)} ${R1(fx-W*.12)} ${R1(fy+W*.2)}" stroke="${FI}" stroke-width="1.6" fill="none"/>`);
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,cx,cy-H*.75,15,0);
  s+=pt("head",cx,R1(cy+H*.3),h);
  if(o.arms!=="none")s+=pt("armF",R1(cx-W*.4),R1(cy),(o.arms==="wisps"?`<path d="M${R1(cx-W*.4)} ${R1(cy)} Q${R1(cx-W*.9)} ${R1(cy-H*.1)} ${R1(cx-W*.8)} ${R1(cy+H*.3)} Q${R1(cx-W*.7)} ${R1(cy+H*.1)} ${R1(cx-W*.4)} ${R1(cy+H*.15)} Z" fill="${P.n}" ${SW2}/>`:o.arms==="hands"?fOL(`M${R1(cx-W*.4)} ${R1(cy)} Q${R1(cx-W*.75)} ${R1(cy+H*.05)} ${R1(cx-W*.8)} ${R1(cy+H*.3)}`,P.n,4):`<path d="M${R1(cx-W*.35)} ${R1(cy-H*.1)} Q${R1(cx-W*.95)} ${R1(cy)} ${R1(cx-W*.85)} ${R1(cy+H*.35)} L${R1(cx-W*.55)} ${R1(cy+H*.25)} Q${R1(cx-W*.5)} ${R1(cy+H*.1)} ${R1(cx-W*.35)} ${R1(cy+H*.15)} Z" fill="${P.n}" ${SW2}/>`)+(o.acc&&FG_SLOT[o.acc]==="hold"?fgAcc(o.acc,P,cx-W*.85,cy+H*.4,15,-10):""));
  if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[cx,cy+H*.3],back:[cx+W*.45,cy-H*.45],side:[cx+W*.25,cy+H*.15],hold:[cx-W*.8,cy+H*.4],floor:[cx,146]});
  s+=fG(g,1,`<g class="p-glow"><circle cx="30" cy="40" r="2.4" fill="${P.ac}"/><circle cx="176" cy="60" r="2" fill="${P.ac}"/></g>`)+fG(g,2,`<circle cx="${R1(cx+W*.25)}" cy="${R1(cy+H*.1)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+W*.5),R1(Math.max(14,cy-H)),6));
  return s},
 parts:o=>o.arms==="none"?["head","jaw","tail","glow"]:["head","jaw","tail","arm"],
 sig:o=>[o.sp,o.shape,o.arms,o.face,o.crown,o.trail,o.orbit?1:0].join(".")};

/* ---- bats, gliders and the winged things of legend ---- */
FGP.flyer={hab:{"z-crater":2.5,"z-mine":2,"z-volcano":2,"z-vault":1.4,"z-reactor":1.2,"z-scrap":1,"z-glacier":1,"z-wreck":.8},loco:"hover",want:(tr,a)=>(tr.light?1.8:tr.heavy?.5:1)*(a.rar==="legendary"?2.4:1),
 kinds:{bat:["Bat","Fruit Bat","Flying Fox","Pipistrelle","Horseshoe Bat","Vampire Bat","Noctule","Long-Eared Bat"],glider:["Sugar Glider","Flying Squirrel","Colugo","Flying Lemur"],
  myth:["Gargoyle","Griffin Chick","Hippogriff Foal","Manticore Cub","Chimera Whelp","Wyvern","Dragonet","Pegasus Foal","Sphinx Cub","Lamassu Calf","Firebird","Thunderbird Chick","Peryton","Strix","Harpy"]},
 gen(r,tr,a){const kind=fgW(r,{bat:3,glider:1.4,myth:a.rar==="uncommon"?1.2:4});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.wing=kind==="bat"?"web":kind==="glider"?"skin":fgPick(r,["web","feather","feather","web","insect"]);o.ear=fgPick(r,kind==="bat"?["point","long","tuft"]:["point","round","tuft","fan"]);o.horn=kind==="myth"?fgPick(r,["none","curve","crystal","straight","branch"]):"none";
  o.tail=fgPick(r,kind==="bat"?["thin","none","stub"]:["thin","tuft","spiked","flame","fork","brush"]);o.face=fgPick(r,["snout","flat","beak","leaf"]);if(kind==="bat")o.face=fgPick(r,["snout","flat","leaf"]);o.legs=r()<.5;o.br=R1(20+r()*8);o.pat=fgPick(r,["none","spots","bands","patch"]);return o},
 draw(P,g,o){const cx=104,cy=86,br=o.br;let s=`<ellipse class="shd" cx="${cx}" cy="150" rx="${R1(br*1.6)}" ry="4" fill="#000" opacity=".12"/>`;
  const wing=(side,cls,c)=>{const x=cx+side*br*.3,y=cy-br*.3;let p;
   if(o.wing==="web")p=`<path d="M${x} ${y} L${R1(x+side*br*1.4)} ${R1(y-br*1.6)} L${R1(x+side*br*2.6)} ${R1(y-br*.9)} Q${R1(x+side*br*2.2)} ${R1(y-br*.2)} ${R1(x+side*br*2.4)} ${R1(y+br*.4)} Q${R1(x+side*br*1.8)} ${R1(y)} ${R1(x+side*br*1.6)} ${R1(y+br*.6)} Q${R1(x+side*br*1.1)} ${R1(y+br*.2)} ${R1(x+side*br*.8)} ${R1(y+br*.8)} Q${R1(x+side*br*.4)} ${R1(y+br*.4)} ${x} ${R1(y+br*.5)} Z" fill="${c}" ${SW}/><path d="M${x} ${y} L${R1(x+side*br*1.4)} ${R1(y-br*1.6)} M${R1(x+side*br*1.4)} ${R1(y-br*1.6)} L${R1(x+side*br*2.4)} ${R1(y+br*.4)} M${R1(x+side*br*1.4)} ${R1(y-br*1.6)} L${R1(x+side*br*1.6)} ${R1(y+br*.6)} M${R1(x+side*br*1.4)} ${R1(y-br*1.6)} L${R1(x+side*br*.8)} ${R1(y+br*.8)}" stroke="${FI}" stroke-width="1.6"/>`;
   else if(o.wing==="feather")p=`<path d="M${x} ${y} Q${R1(x+side*br*1)} ${R1(y-br*2)} ${R1(x+side*br*2.6)} ${R1(y-br*1.8)} Q${R1(x+side*br*2.1)} ${R1(y-br*1.2)} ${R1(x+side*br*2.4)} ${R1(y-br*.8)} Q${R1(x+side*br*1.9)} ${R1(y-br*.5)} ${R1(x+side*br*2.1)} ${R1(y-br*.1)} Q${R1(x+side*br*1.3)} ${R1(y)} ${x} ${R1(y+br*.5)} Z" fill="${c}" ${SW}/>${[0,1,2].map(i=>`<path d="M${R1(x+side*br*(.5+i*.4))} ${R1(y-br*(.2+i*.3))} l${R1(side*br*.5)} ${R1(-br*.4)}" stroke="${P.ndd}" stroke-width="1.4"/>`).join("")}`;
   else if(o.wing==="insect")p=`<path d="M${x} ${y} Q${R1(x+side*br*1.4)} ${R1(y-br*2.2)} ${R1(x+side*br*2.4)} ${R1(y-br*1.2)} Q${R1(x+side*br*1.6)} ${R1(y)} ${x} ${R1(y+br*.3)} Z" fill="${P.ll}" opacity=".75" ${SW2}/>`;
   else p=`<path d="M${x} ${R1(y-br*.3)} Q${R1(x+side*br*.9)} ${R1(y-br*.5)} ${R1(x+side*br*1.6)} ${R1(y-br*.1)} Q${R1(x+side*br*1.4)} ${R1(y+br*.4)} ${R1(x+side*br*1.6)} ${R1(y+br*.9)} Q${R1(x+side*br*.8)} ${R1(y+br*.6)} ${x} ${R1(y+br*.8)} Z" fill="${c}" ${SW}/><path d="M${R1(x+side*br*.3)} ${R1(y-br*.2)} Q${R1(x+side*br*1)} ${R1(y+br*.2)} ${R1(x+side*br*1.4)} ${R1(y+br*.7)}" stroke="${P.ndd}" stroke-width="1.2" fill="none"/>`;
   return pt(cls,x,y,p)};
  s+=wing(1,"wingB",P.nd);
  if(o.tail!=="none")s+=pt("tail",R1(cx+br*.3),R1(cy+br*.6),fgTail(o.tail,R1(cx+br*.3),R1(cy+br*.6),P,.9,1));
  if(o.legs)s+=pt("legB",R1(cx+6),R1(cy+br*.7),fOL(`M${R1(cx+6)} ${R1(cy+br*.7)} L${R1(cx+10)} ${R1(cy+br*1.5)}`,P.nd,4)+`<path d="M${R1(cx+10)} ${R1(cy+br*1.5)} l-3 4 M${R1(cx+10)} ${R1(cy+br*1.5)} l3 4" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`,.4);
  s+=`<path d="${fgBody(cx,cy,br*.8,br*.95,2)}" fill="${P.n}" ${SW}/><path d="M${R1(cx-br*.5)} ${R1(cy+br*.6)} Q${cx} ${R1(cy+br*1.05)} ${R1(cx+br*.5)} ${R1(cy+br*.6)}" stroke="${P.nl}" stroke-width="4" fill="none" opacity=".7"/>`+fgPattern(o.pat,cx,cy+br*.1,br*.6,br*.7,P,fgRng(o.seed||29));
  if(o.legs)s+=pt("legF",R1(cx-6),R1(cy+br*.7),fOL(`M${R1(cx-6)} ${R1(cy+br*.7)} L${R1(cx-8)} ${R1(cy+br*1.5)}`,P.n,4)+`<path d="M${R1(cx-8)} ${R1(cy+br*1.5)} l-3 4 M${R1(cx-8)} ${R1(cy+br*1.5)} l3 4" stroke="${FI}" stroke-width="2" stroke-linecap="round"/>`);
  s+=wing(-1,"wingF",P.nd);
  const hx=cx-br*.1,hy=cy-br*1.05,hr=br*.62;let h="";
  if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx+hr*.5),R1(hy-hr*.6),P,.8,1);
  h+=fgEar(o.ear,R1(hx+hr*.6),R1(hy-hr*.6),P,hr/12);
  h+=`<path d="${fgEll(hx,hy,hr,hr*.9)}" fill="${P.n}" ${SW}/>`;
  const sx=hx-hr*.85,sy=hy+hr*.2;
  if(o.face==="snout")h+=`<path d="M${R1(sx+4)} ${R1(sy-5)} Q${R1(sx-10)} ${R1(sy-4)} ${R1(sx-10)} ${R1(sy+1)} Q${R1(sx-8)} ${R1(sy+5)} ${R1(sx+4)} ${R1(sy+5)} Z" fill="${P.n}" ${SW2}/><ellipse cx="${R1(sx-9)}" cy="${R1(sy-2)}" rx="2.4" ry="1.8" fill="${FI}"/>`;
  if(o.face==="leaf")h+=`<path d="M${R1(sx-2)} ${R1(sy-2)} L${R1(sx-6)} ${R1(sy-14)} L${R1(sx+2)} ${R1(sy-4)} Z" fill="${P.nl}" ${SW2}/>`;
  if(o.face==="beak")h+=`<path d="M${R1(sx+2)} ${R1(sy-4)} Q${R1(sx-12)} ${R1(sy-4)} ${R1(sx-14)} ${R1(sy+4)} Q${R1(sx-8)} ${R1(sy)} ${R1(sx+2)} ${R1(sy+2)} Z" fill="${P.b}" ${SW2}/>`;
  const mx=o.face==="snout"?sx-8:sx-2;
  h+=`<path d="M${R1(mx)} ${R1(sy+3)} L${R1(sx+6)} ${R1(sy+4)} L${R1(sx+5)} ${R1(sy+7)} Z" fill="${FMOUTH}"/><path d="M${R1(mx+2)} ${R1(sy+3)} l1.4 3 l1.4 -3 M${R1(mx+7)} ${R1(sy+3.5)} l1.4 3 l1.4 -3" fill="#FFFFFF"/>`;
  h+=pt("jaw",R1(sx+6),R1(sy+5),`<path d="M${R1(sx+6)} ${R1(sy+5)} Q${R1(mx+4)} ${R1(sy+11)} ${R1(mx)} ${R1(sy+4)} Q${R1(mx+4)} ${R1(sy+7)} ${R1(sx+6)} ${R1(sy+7)} Z" fill="${P.nl}" ${SW2}/>`);
  h+=fgEar(o.ear,R1(hx-hr*.1),R1(hy-hr*.7),P,hr/11);
  h+=fgEye(R1(hx-hr*.3),R1(hy-hr*.15),R1(hr*.34),o.kind==="myth"?P.ac:"#C8A040");
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-hr-4,13,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,mx-6,sy+6,13,0);
  s+=pt("head",R1(hx),R1(hy+hr*.8),h);
  if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+2,hy+hr*1.1],back:[cx+br*.5,cy-br*.8],side:[cx+br*.2,cy+br*.2],floor:[cx,146]});
  s+=fG(g,1,`<path d="M20 60 q8 -8 16 0 M164 120 q6 -6 12 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="${R1(cx+br*.2)}" cy="${R1(cy+br*.3)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+br*1.4),R1(Math.max(14,cy-br*2.4)),6));
  return s},
 parts:["head","jaw","wing","ear"],
 sig:o=>[o.kind,o.sp,o.wing,o.ear,o.horn,o.tail,o.face,o.legs?1:0,o.pat].join(".")};

/* ---- shells: snails, tortoises, armoured things that carry their house ---- */
FGP.shell={hab:{"z-wreck":2.5,"z-glacier":1.5,"z-mine":1.5,"z-vault":1.5,"z-scrap":1.2,"z-volcano":1.2,"z-crater":.8,"z-reactor":.8},loco:"crawl",want:tr=>tr.heavy||tr.tough?1.8:1,
 kinds:{snail:["Snail","Whelk","Periwinkle","Nautilus","Conch","Slug","Cone Snail","Limpet","Ammonite","Murex","Cowrie","Abalone"],tort:["Tortoise","Terrapin","Box Turtle","Softshell","Mata Mata","Sideneck","Slider"],
  armour:["Armadillo","Pangolin","Glyptodont","Ankylo Whelp"],myth:["Shell Golem","Hermit Spirit","Genbu","Zaratan Whelp","Bakekujira"]},
 gen(r,tr,a){const kind=fgW(r,{snail:3,tort:2.5,armour:1.4,myth:a.rar==="uncommon"?.3:2});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.shell=kind==="snail"?fgPick(r,["spiral","cone","coil","ridged","flat"]):fgPick(r,["dome","plates","spiked","high","flat"]);o.horn=kind==="myth"?fgPick(r,["crystal","curve","branch"]):"none";
  o.stalks=kind==="snail"&&r()<.8;o.pat=fgPick(r,["rings","spots","bands","none"]);o.L=R1(kind==="snail"?78:70+r()*16);o.sH=R1(32+r()*12);return o},
 draw(P,g,o){const cx=110,L=o.L,gy=144;let s=fShadow(L*.55,cx);
  if(o.kind==="snail"){s+=pt("tail",R1(cx+L*.42),gy-4,`<path d="M${R1(cx+L*.3)} ${gy-10} Q${R1(cx+L*.6)} ${gy-6} ${R1(cx+L*.62)} ${gy} L${R1(cx+L*.3)} ${gy} Z" fill="${P.nd}" ${SW2}/>`);
   s+=`<path d="M${R1(cx-L*.55)} ${gy} Q${R1(cx-L*.6)} ${gy-20} ${R1(cx-L*.4)} ${gy-24} L${R1(cx+L*.35)} ${gy-10} Q${R1(cx+L*.4)} ${gy} ${R1(cx+L*.3)} ${gy} Z" fill="${P.n}" ${SW}/><path d="M${R1(cx-L*.5)} ${gy-4} H${R1(cx+L*.3)}" stroke="${P.nl}" stroke-width="3" opacity=".6"/>`;
   const sx=cx+L*.05,sy=gy-12-o.sH*.55,R=o.sH*.6;
   if(o.shell==="cone")s+=`<path d="M${R1(sx-R)} ${R1(sy+R*.7)} L${R1(sx+R*.2)} ${R1(sy-R*1.4)} L${R1(sx+R*1.1)} ${R1(sy+R*.7)} Z" fill="${P.b}" ${SW}/>${[0,1,2].map(i=>`<path d="M${R1(sx-R*(.8-i*.25))} ${R1(sy+R*(.4-i*.5))} L${R1(sx+R*(.9-i*.2))} ${R1(sy+R*(.4-i*.5))}" stroke="${P.dd}" stroke-width="1.6"/>`).join("")}`;
   else if(o.shell==="flat")s+=`<path d="M${R1(sx-R*1.1)} ${R1(sy+R*.7)} Q${R1(sx)} ${R1(sy-R*.6)} ${R1(sx+R*1.1)} ${R1(sy+R*.7)} Z" fill="${P.b}" ${SW}/>${[0,1,2].map(i=>`<path d="M${R1(sx-R*.2+i*R*.4)} ${R1(sy+R*.6)} L${R1(sx-R*.1+i*R*.3)} ${R1(sy-R*.1)}" stroke="${P.dd}" stroke-width="1.4"/>`).join("")}`;
   else s+=`<circle cx="${R1(sx)}" cy="${R1(sy)}" r="${R1(R)}" fill="${P.b}" ${SW}/><path d="M${R1(sx)} ${R1(sy)} m${R1(-R*.75)} 0 a${R1(R*.75)} ${R1(R*.75)} 0 1 1 ${R1(R*.75)} ${R1(R*.75)} a${R1(R*.5)} ${R1(R*.5)} 0 1 1 ${R1(-R*.2)} ${R1(-R*.95)} a${R1(R*.25)} ${R1(R*.25)} 0 1 1 ${R1(R*.18)} ${R1(R*.45)}" stroke="${P.dd}" stroke-width="2.4" fill="none"/>`+(o.shell==="ridged"?Array.from({length:9},(_,i)=>`<path d="M${R1(sx+Math.cos(i*.7)*R*.95)} ${R1(sy+Math.sin(i*.7)*R*.95)} l${R1(Math.cos(i*.7)*5)} ${R1(Math.sin(i*.7)*5)}" stroke="${FI}" stroke-width="3" stroke-linecap="round"/>`).join(""):"");
   const hx=cx-L*.48,hy=gy-24;let h="";
   if(o.stalks)h+=pt("ant",R1(hx+4),R1(hy-6),fOL(`M${R1(hx+2)} ${R1(hy-4)} L${R1(hx-6)} ${R1(hy-26)}`,P.n,3.4)+fOL(`M${R1(hx+8)} ${R1(hy-4)} L${R1(hx+8)} ${R1(hy-28)}`,P.n,3.4)+fgEye(R1(hx-6),R1(hy-28),4,"#2A1A0A")+fgEye(R1(hx+8),R1(hy-30),4,"#2A1A0A"));
   else h+=fgEye(R1(hx),R1(hy-4),4.6,"#2A1A0A");
   h+=`<path d="M${R1(hx-12)} ${R1(hy+10)} L${R1(hx)} ${R1(hy+10)} L${R1(hx-2)} ${R1(hy+14)} Z" fill="${FMOUTH}"/>`+pt("jaw",R1(hx),R1(hy+12),`<path d="M${R1(hx)} ${R1(hy+12)} Q${R1(hx-6)} ${R1(hy+18)} ${R1(hx-12)} ${R1(hy+11)} Q${R1(hx-6)} ${R1(hy+14)} ${R1(hx)} ${R1(hy+14)} Z" fill="${P.nl}" ${SW2}/>`);
   if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,hy-34,13,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,hx-16,hy+16,13,0);
   s+=pt("head",R1(hx+6),R1(hy+12),h);
   if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+8,hy+14],back:[sx,sy-R-6],side:[sx+R*.5,sy+R*.3],floor:[cx,146]});
  }else{const sh=o.sH,top=gy-14-sh;
   s+=pt("tail",R1(cx+L*.48),R1(gy-18),fgTail(o.kind==="armour"?"spiked":"stub",R1(cx+L*.48),R1(gy-18),P,.9,1));
   [[cx+L*.32,"legB",.5],[cx-L*.1,"legB",0]].forEach(([x,c,d])=>{s+=pt(c,R1(x),gy-16,`<path d="M${R1(x-6)} ${gy-18} L${R1(x-8)} ${gy} H${R1(x+6)} L${R1(x+6)} ${gy-18} Z" fill="${P.nd}" ${SW2}/>`,d)});
   const shp={dome:`M${R1(cx-L*.48)} ${gy-14} Q${R1(cx-L*.45)} ${R1(top)} ${cx} ${R1(top)} Q${R1(cx+L*.45)} ${R1(top)} ${R1(cx+L*.48)} ${gy-14} Z`,high:`M${R1(cx-L*.42)} ${gy-14} Q${R1(cx-L*.4)} ${R1(top-10)} ${cx} ${R1(top-12)} Q${R1(cx+L*.4)} ${R1(top-10)} ${R1(cx+L*.42)} ${gy-14} Z`,
    flat:`M${R1(cx-L*.5)} ${gy-14} Q${R1(cx-L*.4)} ${R1(top+12)} ${cx} ${R1(top+10)} Q${R1(cx+L*.4)} ${R1(top+12)} ${R1(cx+L*.5)} ${gy-14} Z`,plates:`M${R1(cx-L*.48)} ${gy-14} Q${R1(cx-L*.45)} ${R1(top)} ${cx} ${R1(top)} Q${R1(cx+L*.45)} ${R1(top)} ${R1(cx+L*.48)} ${gy-14} Z`,spiked:`M${R1(cx-L*.48)} ${gy-14} Q${R1(cx-L*.45)} ${R1(top)} ${cx} ${R1(top)} Q${R1(cx+L*.45)} ${R1(top)} ${R1(cx+L*.48)} ${gy-14} Z`}[o.shell];
   s+=`<path d="${shp}" fill="${P.b}" ${SW}/><path d="M${R1(cx-L*.5)} ${gy-14} H${R1(cx+L*.5)}" stroke="${FI}" stroke-width="4" stroke-linecap="round"/><path d="M${R1(cx-L*.5)} ${gy-14} H${R1(cx+L*.5)}" stroke="${P.d}" stroke-width="2" stroke-linecap="round"/>`;
   if(o.kind==="armour")for(let i=-3;i<=3;i++)s+=`<path d="M${R1(cx+i*L*.12)} ${gy-15} Q${R1(cx+i*L*.12+3)} ${R1(top+sh*.3)} ${R1(cx+i*L*.1)} ${R1(top+3+Math.abs(i)*3)}" stroke="${P.dd}" stroke-width="2.4" fill="none"/>`;
   else{const hex=(x,y,r)=>`<path d="M${R1(x-r)} ${R1(y)} L${R1(x-r*.5)} ${R1(y-r*.86)} L${R1(x+r*.5)} ${R1(y-r*.86)} L${R1(x+r)} ${R1(y)} L${R1(x+r*.5)} ${R1(y+r*.86)} L${R1(x-r*.5)} ${R1(y+r*.86)} Z" fill="${P.d}" opacity=".6" ${SW2}/>`;s+=hex(cx,top+sh*.45,sh*.24)+hex(cx-L*.2,top+sh*.6,sh*.2)+hex(cx+L*.2,top+sh*.6,sh*.2)}
   if(o.shell==="spiked")s+=Array.from({length:5},(_,i)=>{const a=Math.PI*(1.15+i*.17),x=cx+Math.cos(a)*L*.44,y=gy-14+Math.sin(a)*sh*1.0;return`<path d="M${R1(x-4)} ${R1(y+3)} L${R1(x+Math.cos(a)*10)} ${R1(y+Math.sin(a)*10)} L${R1(x+4)} ${R1(y+3)} Z" fill="${P.ll}" ${SW2}/>`}).join("");
   s+=`<path d="M${R1(cx-L*.35)} ${R1(top+sh*.35)} Q${R1(cx-L*.1)} ${R1(top+4)} ${R1(cx+L*.15)} ${R1(top+6)}" stroke="${P.ll}" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>`;
   [[cx+L*.24,"legF",.5],[cx-L*.25,"legF",0]].forEach(([x,c,d])=>{s+=pt(c,R1(x),gy-14,`<path d="M${R1(x-7)} ${gy-16} L${R1(x-9)} ${gy+1} H${R1(x+7)} L${R1(x+6)} ${gy-16} Z" fill="${P.n}" ${SW2}/>`,d)});
   const hx=cx-L*.62,hy=gy-24;let h=fOL(`M${R1(cx-L*.42)} ${gy-18} Q${R1(hx+10)} ${R1(hy+4)} ${R1(hx+6)} ${R1(hy)}`,P.n,10);
   if(o.horn!=="none")h+=fgHorn(o.horn,R1(hx),R1(hy-9),P,.8,-1);
   h+=`<path d="M${R1(hx-14)} ${R1(hy+1)} L${R1(hx+4)} ${R1(hy+2)} L${R1(hx+2)} ${R1(hy+6)} Z" fill="${FMOUTH}"/>`+pt("beak",R1(hx+4),R1(hy+4),`<path d="M${R1(hx+4)} ${R1(hy+4)} Q${R1(hx-6)} ${R1(hy+10)} ${R1(hx-14)} ${R1(hy+2)} Q${R1(hx-6)} ${R1(hy+6)} ${R1(hx+4)} ${R1(hy+7)} Z" fill="${P.nd}" ${SW2}/>`);
   h+=`<path d="M${R1(hx+10)} ${R1(hy-4)} Q${R1(hx)} ${R1(hy-12)} ${R1(hx-14)} ${R1(hy-2)} Q${R1(hx-16)} ${R1(hy+2)} ${R1(hx-12)} ${R1(hy+2)} L${R1(hx+10)} ${R1(hy+4)} Z" fill="${P.n}" ${SW}/>`+fgEye(R1(hx-3),R1(hy-5),3.6,o.kind==="myth"?P.ac:"#2A1A0A",[-.4,0],.25,P.n);
   if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx-2,hy-16,12,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,hx-18,hy+6,12,0);
   s+=pt("head",R1(cx-L*.42),gy-18,h);
   if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+10,hy+8],back:[cx,top-8],side:[cx+L*.2,gy-26],floor:[cx,146]})}
  s+=fG(g,1,`<path d="M20 140 q4 -6 8 0 q4 -6 8 0" stroke="${P.l}" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="${R1(cx+10)}" cy="${gy-34}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(cx+L*.3),R1(gy-o.sH-40),6));
  return s},
 parts:o=>o.kind==="snail"?["head","jaw","ant","tail"]:["head","jaw","leg","tail"],
 sig:o=>[o.kind,o.sp,o.shell,o.horn,o.stalks?1:0,o.pat].join(".")};
