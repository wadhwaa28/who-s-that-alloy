/* ---- the register shows the battle form too. One button flips specimen <-> battle form; the ✦ RADIANT button colours
   whichever of the two is showing, so the radiant battle form needs no button of its own. ---- */
{const _od=openDex;openDex=function(no){_od(no);const a=ALLOYS[no-1];if(!a||(a.threat&&!hasForm(a))||statusOf(a)!=="caught"||!ocKnown())return;const bt=document.querySelector("#dexdetail .ddbtns"),spec=document.querySelector("#dexdetail .ddspec"),sc=document.querySelector("#ddscreen");if(!bt||!spec||!sc)return;
  const b=document.createElement("button");b.className="btn";b.id="dd-form";const rb=document.querySelector("#dd-rad");bt.insertBefore(b,rb||null);let on=false,saved=null,busy=false;const g=bestGradeOf(a.name);
  const isRad=()=>radOwned(a)&&sc.classList.contains("radiant");
  const lab=()=>{b.textContent=on?"SPECIMEN":"OVERCLOCK";b.setAttribute("aria-pressed",on?"true":"false")};lab();
  const formHTML=()=>hasForm(a)?BATTLE_FORMS[a.name](a,g,isRad()):specimenSVG(a);
  const note=()=>{const n=sc.querySelector(".ddform-note");if(n)n.remove();if(on&&!hasForm(a)){const t=document.createElement("div");t.className="ddform-note";t.textContent="NOT YET SEEN OVERCLOCKED";sc.appendChild(t)}};
  b.onclick=async()=>{if(busy)return;busy=true;b.disabled=true;on=!on;
    if(typeof removeGlint==="function")removeGlint(spec);
    if(on){saved=spec.innerHTML.replace(/<g class="glint"[\s\S]*?<\/g>/,"");if(hasForm(a)){await ocMorph(spec,saved,formHTML(),{up:1});spec.classList.add("bform");formCry(spec,a)}else{spec.innerHTML=formHTML();spec.classList.add("bform")}}
    else{if(hasForm(a)){await ocMorph(spec,spec.innerHTML,saved,{up:0})}else spec.innerHTML=saved;spec.classList.remove("bform");if(isRad()&&typeof addGlint==="function")addGlint(spec)}
    note();lab();busy=false;b.disabled=false};
  if(rb){const _rc=rb.onclick;rb.onclick=function(e){if(busy)return;_rc&&_rc.call(this,e);if(on){spec.innerHTML=formHTML();formCry(spec,a)}}}}}
/* ---- what each one is, now that it has a body ---- */

{const _od=openDex;openDex=function(no){_od(no);const a=ALLOYS[no-1];if(!a||statusOf(a)!=="caught"||!FORM_TITLE[a.name]||!ocKnown())return;const c=document.querySelector("#dexdetail .ddtitle .cat");if(c)c.textContent=`The ${FORM_TITLE[a.name]} Alloy`}}
/* ---- cries: in battle form, each one does its own thing ---- */
const crySlug=n=>n.toLowerCase().replace(/[^a-z0-9]+/g,"_");
function formCry(el,a){if(!el||!hasForm(a))return;el.dataset.cry=crySlug(a.name);el.classList.remove("fcry");void el.offsetWidth;el.classList.add("fcry");clearTimeout(el._ft);el._ft=setTimeout(()=>el.classList.remove("fcry"),1700)}
{const _ca=cryAnim;cryAnim=function(a,auto){const spec=document.querySelector("#ddscreen .ddspec");
  if(!spec||!spec.classList.contains("bform")||!hasForm(a))return _ca(a,auto);
  if(!auto&&!gate("cryAnim",1100))return;if(typeof cry==="function")cry(a);formCry(spec,a)}}
