/* ---- insects, spiders, crabs and other many-legged things ---- */
FGP.bug={hab:{"z-mine":3,"z-scrap":3,"z-volcano":2,"z-crater":1.6,"z-reactor":2,"z-vault":1.2,"z-wreck":1.6,"z-glacier":.5},loco:o=>o.fly?"hover":"crawl",
 kinds:{beetle:["Beetle","Weevil","Scarab","Chafer","Longhorn","Ladybird","Dor Beetle","Tiger Beetle","Rhino Beetle","Jewel Beetle","Rove Beetle","Bess Beetle"],ant:["Ant","Termite","Bullet Ant","Weaver Ant","Velvet Ant"],
  bug:["Shieldbug","Cicada","Leafhopper","Treehopper","Water Strider","Lacewing","Cricket","Katydid","Locust","Earwig","Mayfly","Stonefly","Silverfish","Firebrat"],arach:["Tarantula","Jumping Spider","Harvestman","Vinegaroon","Sun Spider","Tick","Mite","Pseudoscorpion","Wolf Spider","Trapdoor Spider"],
  crust:["Fiddler Crab","Hermit Crab","Woodlouse","Isopod","Crayfish","Krill","Coconut Crab","Spider Crab","Horseshoe Crab","Trilobite"],fly:["Moth","Hawkmoth","Hoverfly","Damselfly","Bee","Hornet","Firefly","Sawfly","Caddisfly","Antlion Fly"],
  myth:["Myrmecoleon","Scarab Spirit","Gold-Digging Ant","Khepri","Jorogumo","Anansi","Bonelord"]},
 gen(r,tr,a){const kind=fgW(r,{beetle:4,ant:1.5,bug:2.5,arach:2,crust:a.hab==="z-wreck"?4:1.4,fly:tr.light?3:1.5,myth:a.rar==="legendary"?5:a.rar==="rare"?1.2:.3});const o={kind,sp:fgPick(r,this.kinds[kind])};
  o.fly=kind==="fly"||(kind==="myth"&&r()<.4);o.legs=kind==="arach"?8:kind==="crust"?(r()<.5?6:8):6;o.L=R1(kind==="ant"?66:58+r()*22);o.H=R1(kind==="arach"?26:20+r()*8);
  o.horn=kind==="beetle"?fgPick(r,["none","rhino","stag","pronged","none"]):"none";o.claws=kind==="crust"||(kind==="arach"&&r()<.4)||(kind==="myth"&&r()<.4);o.ant=kind==="arach"?"none":fgPick(r,["thread","club","comb","elbow","feather"]);
  o.pat=fgPick(r,["spots","bands","stripe","none","rivets","split"]);o.segs=kind==="ant"||kind==="crust"&&r()<.5;o.stinger=kind==="fly"&&r()<.4||kind==="ant"&&r()<.4;return o},
 draw(P,g,o){const cx=112,L=o.L,H=o.H,cy=o.fly?84:144-H*1.05;let s=o.fly?`<ellipse class="shd" cx="${cx}" cy="150" rx="${R1(L*.4)}" ry="3.4" fill="#000" opacity=".12"/>`:fShadow(L*.6+10,cx);
  const bx=cx+L*.12,hx=cx-L*.38;
  if(o.fly)s+=pt("wingB",R1(bx),R1(cy-H*.6),`<path d="M${R1(bx)} ${R1(cy-H*.6)} Q${R1(bx+L*.4)} ${R1(cy-H*3.4)} ${R1(bx+L*.9)} ${R1(cy-H*2.6)} Q${R1(bx+L*.6)} ${R1(cy-H)} ${R1(bx+6)} ${R1(cy-H*.2)} Z" fill="${P.ll}" opacity=".7" ${SW2}/>`);
  const nl=o.legs/2;for(let i=0;i<nl;i++){const x=cx-L*.18+i*(L*.42/(nl-1||1)),cls=i%2?"legB":"legF";const far=`M${R1(x+3)} ${R1(cy+H*.3)} L${R1(x+12+i*2)} ${R1(cy-H*(o.legs===8?.9:.2))} L${R1(x+16+i*3)} ${o.fly?R1(cy+H*1.8):143}`;s+=pt(cls,R1(x+3),R1(cy+H*.3),fOL(far,P.nd,2.8),i*.15)}
  if(o.stinger)s+=pt("tail",R1(bx+L*.42),R1(cy),`<path d="M${R1(bx+L*.4)} ${R1(cy-3)} L${R1(bx+L*.56)} ${R1(cy+2)} L${R1(bx+L*.4)} ${R1(cy+5)} Z" fill="${P.d}" ${SW2}/>`);
  if(o.kind==="ant")s+=`<path d="${fgEll(bx+L*.2,cy,L*.24,H*.95)}" fill="${P.n}" ${SW}/><path d="${fgEll(cx-L*.05,cy,L*.13,H*.6)}" fill="${P.n}" ${SW}/>`;
  else if(o.kind==="arach")s+=`<path d="${fgEll(bx+L*.12,cy-H*.15,L*.32,H*1.05)}" fill="${P.n}" ${SW}/><path d="${fgEll(cx-L*.12,cy,L*.17,H*.65)}" fill="${P.n}" ${SW}/>`;
  else s+=`<path d="M${R1(cx-L*.2)} ${R1(cy+H*.2)} Q${R1(cx-L*.18)} ${R1(cy-H*1.2)} ${R1(bx+L*.08)} ${R1(cy-H*1.15)} Q${R1(bx+L*.42)} ${R1(cy-H*.9)} ${R1(bx+L*.42)} ${R1(cy+H*.1)} Q${R1(bx+L*.3)} ${R1(cy+H*.8)} ${R1(cx)} ${R1(cy+H*.8)} Q${R1(cx-L*.2)} ${R1(cy+H*.7)} ${R1(cx-L*.2)} ${R1(cy+H*.2)} Z" fill="${P.n}" ${SW}/>`;
  if(o.pat==="split")s+=`<path d="M${R1(cx-L*.12)} ${R1(cy-H*.7)} Q${R1(bx+L*.1)} ${R1(cy-H*1.05)} ${R1(bx+L*.4)} ${R1(cy)}" stroke="${FI}" stroke-width="2" fill="none"/>`;
  else if(o.segs)for(let i=0;i<3;i++)s+=`<path d="M${R1(bx+i*L*.1)} ${R1(cy-H*.9)} Q${R1(bx+4+i*L*.1)} ${R1(cy)} ${R1(bx+i*L*.1)} ${R1(cy+H*.75)}" stroke="${P.nd}" stroke-width="2" fill="none"/>`;
  else s+=fgPattern(o.pat,bx+L*.08,cy-H*.15,L*.32,H*.8,P,fgRng(o.seed||23));
  s+=`<path d="M${R1(cx-L*.1)} ${R1(cy-H*.75)} Q${R1(bx)} ${R1(cy-H*1.1)} ${R1(bx+L*.3)} ${R1(cy-H*.6)}" stroke="${P.nll}" stroke-width="3" fill="none" opacity=".7"/>`;
  if(o.fly)s+=pt("wingF",R1(cx),R1(cy-H*.6),`<path d="M${R1(cx)} ${R1(cy-H*.6)} Q${R1(cx-L*.2)} ${R1(cy-H*3.8)} ${R1(cx+L*.5)} ${R1(cy-H*3.2)} Q${R1(cx+L*.4)} ${R1(cy-H*1.4)} ${R1(cx+8)} ${R1(cy-H*.2)} Z" fill="${P.ll}" opacity=".85" ${SW2}/>${[0,1].map(i=>`<path d="M${R1(cx+2)} ${R1(cy-H*.7)} Q${R1(cx+L*(.05+i*.15))} ${R1(cy-H*2.4)} ${R1(cx+L*(.25+i*.15))} ${R1(cy-H*(3-i*.4))}" stroke="${P.nd}" stroke-width="1" fill="none"/>`).join("")}`);
  for(let i=0;i<nl;i++){const x=cx-L*.25+i*(L*.42/(nl-1||1));s+=pt(i%2?"legF":"legB",R1(x),R1(cy+H*.3),fOL(`M${R1(x)} ${R1(cy+H*.3)} L${R1(x-10-i)} ${R1(cy+H*(o.legs===8?-.6:.9))} L${R1(x-14-i*2)} ${o.fly?R1(cy+H*1.9):143}`,P.n,3),i*.15+.07)}
  let h="";const hr=H*.7;
  if(o.claws)h+=pt("claw",R1(hx+4),R1(cy+2),fOL(`M${R1(hx+6)} ${R1(cy+H*.3)} L${R1(hx-12)} ${R1(cy+H*.1)}`,P.nd,3.4)+`<path d="M${R1(hx-12)} ${R1(cy+H*.1)} Q${R1(hx-28)} ${R1(cy-H*.8)} ${R1(hx-30)} ${R1(cy+H*.1)} L${R1(hx-20)} ${R1(cy)} L${R1(hx-28)} ${R1(cy+H*.6)} Q${R1(hx-18)} ${R1(cy+H*.9)} ${R1(hx-10)} ${R1(cy+H*.4)} Z" fill="${P.n}" ${SW2}/>`);
  if(o.horn==="rhino")h+=`<path d="M${R1(hx-hr*.4)} ${R1(cy-hr*.3)} Q${R1(hx-hr*1.6)} ${R1(cy-hr*1.4)} ${R1(hx-hr*1.2)} ${R1(cy-hr*2.4)} Q${R1(hx-hr*.6)} ${R1(cy-hr*1.4)} ${R1(hx+hr*.4)} ${R1(cy-hr*.6)} Z" fill="${P.d}" ${SW2}/>`;
  if(o.horn==="stag")h+=pt("claw2",R1(hx-hr*.5),R1(cy),`<path d="M${R1(hx-hr*.5)} ${R1(cy-hr*.2)} Q${R1(hx-hr*2.4)} ${R1(cy-hr*1.6)} ${R1(hx-hr*2.8)} ${R1(cy-hr*.4)} L${R1(hx-hr*2.2)} ${R1(cy-hr*.6)} Q${R1(hx-hr*1.6)} ${R1(cy-hr*.4)} ${R1(hx-hr*.4)} ${R1(cy+hr*.3)} Z" fill="${P.d}" ${SW2}/>`);
  if(o.horn==="pronged")h+=`<path d="M${R1(hx-hr*.2)} ${R1(cy-hr*.6)} L${R1(hx-hr*.4)} ${R1(cy-hr*2)} L${R1(hx-hr*.8)} ${R1(cy-hr*1.6)} M${R1(hx-hr*.4)} ${R1(cy-hr*2)} L${R1(hx)} ${R1(cy-hr*2.4)}" stroke="${FI}" stroke-width="4.4" stroke-linecap="round" fill="none"/><path d="M${R1(hx-hr*.2)} ${R1(cy-hr*.6)} L${R1(hx-hr*.4)} ${R1(cy-hr*2)} L${R1(hx-hr*.8)} ${R1(cy-hr*1.6)} M${R1(hx-hr*.4)} ${R1(cy-hr*2)} L${R1(hx)} ${R1(cy-hr*2.4)}" stroke="${P.d}" stroke-width="2.4" stroke-linecap="round" fill="none"/>`;
  const AN={thread:`M0 0 Q-8 -14 -20 -16`,club:`M0 0 Q-6 -12 -14 -16`,comb:`M0 0 L-14 -14`,elbow:`M0 0 L-6 -10 L-18 -12`,feather:`M0 0 Q-6 -14 -16 -18`}[o.ant];
  if(AN)h+=pt("ant",R1(hx-hr*.2),R1(cy-hr*.7),[0,6].map(d=>`<path d="${AN}" transform="translate(${R1(hx-hr*.2+d)} ${R1(cy-hr*.7)})" stroke="${FI}" stroke-width="1.8" fill="none" stroke-linecap="round"/>`).join("")+
    (o.ant==="club"?`<circle cx="${R1(hx-hr*.2-14)}" cy="${R1(cy-hr*.7-16)}" r="2.6" fill="${P.d}" ${SW2}/>`:o.ant==="feather"?`<path d="M${R1(hx-hr*.2-4)} ${R1(cy-hr*.7-6)} l-6 -2 M${R1(hx-hr*.2-8)} ${R1(cy-hr*.7-11)} l-6 -1 M${R1(hx-hr*.2-12)} ${R1(cy-hr*.7-15)} l-5 0" stroke="${FI}" stroke-width="1.2"/>`:""));
  h+=`<path d="${fgEll(hx,cy,hr,hr*.92)}" fill="${P.n}" ${SW}/>`;
  if(o.kind==="arach")h+=[[-.4,-.3,.24],[-.05,-.45,.2],[-.55,.05,.16],[.15,-.2,.15]].map(([dx,dy,rr])=>fgEye(R1(hx+dx*hr),R1(cy+dy*hr),R1(hr*rr),P.ac)).join("");
  else h+=fgEye(R1(hx-hr*.3),R1(cy-hr*.25),R1(hr*.38),o.kind==="myth"?P.ac:"#2A1A0A");
  h+=`<path d="M${R1(hx-hr*.95)} ${R1(cy+hr*.2)} L${R1(hx-hr*.4)} ${R1(cy+hr*.35)} L${R1(hx-hr*.5)} ${R1(cy+hr*.7)} Z" fill="${FMOUTH}"/>`;
  h+=pt("claw2",R1(hx-hr*.7),R1(cy+hr*.35),`<path d="M${R1(hx-hr*.7)} ${R1(cy+hr*.35)} Q${R1(hx-hr*1.5)} ${R1(cy+hr*.5)} ${R1(hx-hr*1.3)} ${R1(cy+hr*1)} Q${R1(hx-hr*1)} ${R1(cy+hr*.7)} ${R1(hx-hr*.5)} ${R1(cy+hr*.65)} Z" fill="${P.nd}" ${SW2}/>`);
  if(o.acc&&FG_SLOT[o.acc]==="head")h+=fgAcc(o.acc,P,hx,cy-hr-6,13,0);if(o.acc&&FG_SLOT[o.acc]==="hold")h+=fgAcc(o.acc,P,hx-hr*1.6,cy+hr*.9,13,0);
  s+=pt("head",R1(hx+hr*.5),R1(cy),h);
  if(o.acc&&!["head","hold"].includes(FG_SLOT[o.acc]))s+=fgPlace(o,P,{neck:[hx+hr*.8,cy+hr],back:[bx+L*.1,cy-H*1.25-6],side:[bx+L*.1,cy-H*.1],floor:[cx,146]});
  s+=fG(g,1,`<path d="M20 128 l6 -6 M24 134 l8 -4" stroke="${P.l}" stroke-width="2" stroke-linecap="round"/>`)+fG(g,2,`<circle cx="${R1(bx+L*.1)}" cy="${R1(cy-H*.2)}" r="2.6" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(R1(bx),R1(Math.max(14,cy-H*2.4)),6));
  return s},
 parts:o=>o.fly?["head","ant","wing","leg"]:o.claws?["head","claw","ant","leg"]:["head","ant","claw","leg"],
 sig:o=>[o.kind,o.sp,o.horn,o.claws?1:0,o.ant,o.pat,o.fly?1:0,o.stinger?1:0,o.legs].join(".")};
