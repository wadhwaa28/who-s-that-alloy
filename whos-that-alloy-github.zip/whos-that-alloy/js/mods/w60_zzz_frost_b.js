/* =============== FROSTBITE CAVERN: forty-two more, continued =============== */

/* 22 Flaskwarm: a dormouse curled round a big thermos flask, hugging it */
addForm("Flaskwarm",{n:"#C8964E",a:"#F4E8C8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50,100)+
 `<rect x="96" y="54" width="34" height="90" rx="10" fill="#3A6A8A" ${SW}/><rect x="98" y="46" width="30" height="12" rx="3" fill="#C8CCD4" ${SW2}/><path d="M100 80 H126 M100 118 H126" stroke="#9AC8E8" stroke-width="3"/><path d="M106 40 Q104 30 110 24 M118 40 Q122 30 116 22" stroke="#E8ECF0" stroke-width="2.4" fill="none" stroke-linecap="round"/>`+
 pt("tail",76,130,`<path d="M80 136 Q50 142 44 120 Q42 100 58 96 Q64 110 72 118" stroke="${FI}" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M80 136 Q50 142 44 120 Q42 100 58 96 Q64 110 72 118" stroke="${P.n}" stroke-width="9" fill="none" stroke-linecap="round"/>`)+
 `<path d="M74 138 Q66 108 88 96 Q110 96 110 132 Q102 146 88 146 Q76 146 74 138 Z" fill="${P.n}" ${SW}/><path d="M84 136 Q82 116 94 110 Q104 116 102 136 Z" fill="${P.ac}"/>`+
 pt("armF",100,110,`${FLIMB("M92 112 Q104 106 112 112",P.n,5)}<circle cx="113" cy="112" r="3" fill="#E8A8A0" ${SW2}/>`)+pt("armB",100,126,`${FLIMB("M94 126 Q106 124 114 128",P.n,5)}`,.3)+
 pt("head",88,84,`<circle cx="88" cy="82" r="17" fill="${P.n}" ${SW}/>`+pt("ear",76,66,`<circle cx="76" cy="66" r="7" fill="${P.n}" ${SW2}/><circle cx="76" cy="66" r="3.6" fill="#E8A8A0"/>`)+
  `<path d="M78 82 Q82 79 86 82 M92 82 Q96 79 100 82" stroke="${FI}" stroke-width="2" fill="none" stroke-linecap="round"/><circle cx="74" cy="90" r="2.6" fill="#E8708A"/><path d="M76 90 l-10 -2 M76 92 l-10 2" stroke="${FI}" stroke-width="1"/>`+pt("jaw",82,96,`<path d="M78 94 Q82 99 86 94 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="92" cy="128" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Flaskwarm"]="Thermos-Hugging Dormouse";SM("Flaskwarm","Three Days Hot","HEA","s",0,100,"heal:35,cure","Still warm. Still warm. Still warm. Fourth day: off it clicks, and everyone agrees that's fair.");

/* 23 Hibernation Clause: a grizzly bear in a nightcap, a rolled-up lease under its arm, eyes shut */
addForm("Hibernation Clause",{n:"#8A5A34",a:"#E8E0F0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(60,100)+
 [[84,"legB",.25],[114,"legF",0]].map(([x,c,d])=>pt(c,x,138,`<ellipse cx="${x}" cy="142" rx="13" ry="7" fill="${P.n}" ${SW2}/>`,d)).join("")+
 `<path d="M66 136 Q56 92 100 84 Q144 92 134 136 Q122 148 100 148 Q78 148 66 136 Z" fill="${P.n}" ${SW}/><path d="M80 132 Q76 104 100 100 Q124 104 120 132 Z" fill="${P.nl}"/>`+
 pt("armF",76,106,`${FLIMB("M78 102 Q64 116 76 128",P.n,9)}<rect x="68" y="118" width="40" height="12" rx="6" fill="#F4ECD8" ${SW2}/><circle cx="104" cy="124" r="4" fill="#C83A2A" ${SW2}/>`)+
 pt("head",100,70,`<circle cx="100" cy="68" r="22" fill="${P.n}" ${SW}/>`+pt("ear",80,52,`<circle cx="80" cy="52" r="7" fill="${P.n}" ${SW2}/>`)+
  `<path d="M80 54 Q96 30 128 38 Q140 44 146 62 Q140 66 136 58 Q120 44 84 58 Z" fill="${P.ac}" ${SW2}/><circle cx="148" cy="66" r="6" fill="#F4F0E6" ${SW2}/>${[[96,44],[112,40],[126,46]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="#9A8AC8"/>`).join("")}`+
  `<path d="M88 68 Q92 64 96 68 M104 68 Q108 64 112 68" stroke="${FI}" stroke-width="2.2" fill="none" stroke-linecap="round"/><ellipse cx="100" cy="78" rx="9" ry="7" fill="${P.nl}"/><ellipse cx="100" cy="75" rx="4" ry="3" fill="#1A1A1A"/>`+pt("jaw",100,84,`<path d="M94 82 Q100 90 106 82 Z" fill="${FMOUTH}"/>`)+
  pt("slow",124,74,`<text x="120" y="76" font-size="10" font-weight="bold" fill="#8AA0C8">z</text><text x="128" y="66" font-size="8" font-weight="bold" fill="#8AA0C8">z</text>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,110,6)));
FORM_TITLE["Hibernation Clause"]="Nightcapped Grizzly Bear";SM("Hibernation Clause","See You In March","RES","s",0,100,"heal:60","Clause four: the tenant may sleep through any month colder than the last. It's very cold. Goodnight.");

/* 24 Coldstore Count: a lobster with a clipboard in one claw and a melt-tag on the other */
addForm("Coldstore Count",{n:"#3A5A7A",a:"#E8C040",rn:"#E8E4F0",rb:"#C83A2A",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(60,104)+
 `<rect x="128" y="110" width="44" height="36" fill="#A8784E" ${SW}/><path d="M128 122 H172 M150 110 V146" stroke="#6A4A2A" stroke-width="1.6"/><path d="M134 104 H166 V110 H134 Z" fill="#DCEFFA" ${SW2}/>`+
 [[84,"legF",0],[94,"legB",.15],[104,"legF",.3],[114,"legB",.1]].map(([x,c,d])=>pt(c,x,134,`<path d="M${x} 130 L${x-6} 144 M${x+2} 130 L${x+8} 144" stroke="${FI}" stroke-width="2.2" stroke-linecap="round"/>`,d)).join("")+
 pt("tail",128,126,`<path d="M124 120 Q146 126 150 140 Q140 146 126 134 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M70 126 Q74 108 100 106 Q126 108 128 126 Q120 138 98 138 Q76 138 70 126 Z" fill="${P.n}" ${SW}/>${[84,96,108,118].map(x=>`<path d="M${x} 108 Q${x+2} 122 ${x} 136" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("armF",72,112,`${FLIMB("M76 116 Q60 100 52 84",P.n,5)}<path d="M44 84 Q40 66 52 62 L56 76 L60 62 Q70 68 62 86 Z" fill="${P.n}" ${SW2}/><rect x="28" y="56" width="22" height="28" rx="2" fill="#B8864A" ${SW2}/><rect x="31" y="62" width="16" height="20" fill="#FFF"/><path d="M33 66 h10 M33 70 h12 M33 74 h8" stroke="#8A94A8" stroke-width="1"/>`)+
 pt("armB",122,108,`${FLIMB("M118 112 Q130 92 132 78",P.nd,5)}<path d="M128 78 Q124 60 134 56 L138 70 L142 56 Q152 64 142 80 Z" fill="${P.nd}" ${SW2}/><rect x="140" y="80" width="10" height="7" fill="${P.ac}" ${SW2}/>`,.3)+
 pt("head",80,104,`<path d="M74 104 Q80 94 90 98" stroke="${FI}" stroke-width="2" fill="none"/>${E2(78,98,3,"#1A1A1A",[-.3,0])}${E2(90,96,3,"#1A1A1A",[-.3,0])}<path d="M74 96 Q50 70 40 40 M88 94 Q80 60 92 30" stroke="${FI}" stroke-width="1.6" fill="none"/>`+pt("jaw",80,112,`<path d="M74 110 Q80 116 86 110 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Coldstore Count"]="Cold-Store Lobster";SM("Coldstore Count","Every Tag Checked","SCR","s",0,100,"tacc-1@50,def+1","Crate one, tag intact. Crate two, tag intact. Crate three thousand and six, tag intact. Suspicious.");

/* 25 Drip Tray Mix (vial): an octopus wound round a leaky valve, one arm holding a tray of oil under the drip */
addForm("Drip Tray Mix",{n:"#B86A8A",a:"#F4E8C8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"swim",(P,g)=>fShadow(56,100)+
 `<path d="M20 40 H90 M110 40 H184" stroke="#8A8A92" stroke-width="12"/><path d="M20 40 H90 M110 40 H184" stroke="${FI}" stroke-width="1.6" fill="none"/><rect x="88" y="28" width="24" height="24" rx="3" fill="#6A6A70" ${SW}/><path d="M100 28 V16 M90 16 H110" stroke="${FI}" stroke-width="4" stroke-linecap="round"/>`+
 pt("slow",100,58,`<path d="M100 54 Q97 60 100 64 Q103 60 100 54 Z" fill="#E8E0C8" ${SW2}/>`)+
 `<path d="M60 140 H140 L134 148 H66 Z" fill="#8A8A92" ${SW2}/><path d="M64 140 H136" stroke="#C8A040" stroke-width="3"/>`+
 [[70,"legB",0,"M80 116 Q60 124 54 142"],[86,"legF",.2,"M88 120 Q80 134 86 146"],[112,"legF",.1,"M112 120 Q120 134 114 146"],[130,"legB",.3,"M120 116 Q140 124 146 142"]].map(([x,c,d,p])=>pt(c,x,120,FLIMB(p,P.n,7),d)).join("")+
 pt("armF",120,80,FLIMB("M116 88 Q130 70 114 48",P.n,7),.2)+pt("armB",80,80,FLIMB("M84 88 Q70 66 86 46",P.nd,7),.4)+
 pt("head",100,96,`<path d="M74 104 Q70 66 100 62 Q130 66 126 104 Q116 120 100 120 Q84 120 74 104 Z" fill="${P.n}" ${SW}/>${[[88,76],[110,74],[100,88]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3" fill="${P.nl}"/>`).join("")}`+
  `${E2(90,98,4.6,"#1A1A1A",[0,-.5])}${E2(110,98,4.6,"#1A1A1A",[0,-.5])}`+pt("jaw",100,112,`<path d="M94 110 Q100 118 106 110 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M30 110 q4 -6 8 0 M162 110 q4 -6 8 0" stroke="#E8A040" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="100" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,80,6)));
FORM_TITLE["Drip Tray Mix"]="Leaky-Valve Octopus";SM("Drip Tray Mix","Keep It Under Oil","CUR","s",0,100,"tacc-1@40,tspd-1@40","One drop. Into the tray, under the oil, where it can't find any air. Good. Now the next one.");

/* 26 Featherrun: a snow bunting so light it's lifting off a sledge runner */
addForm("Featherrun",{n:"#F4F2EC",a:"#8A6A44",rn:"#3A3A4A",rb:"#C8B8F0",ra:"#F2C94C"},"hover",(P,g)=>
 `<path d="M30 140 H150 Q168 140 170 126" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M30 140 H150 Q168 140 170 126" stroke="#D8DCE0" stroke-width="3" fill="none" stroke-linecap="round"/><path d="M40 134 h6 M80 134 h6 M120 134 h6" stroke="#8A6A44" stroke-width="3"/>`+
 `<ellipse cx="100" cy="148" rx="22" ry="4" fill="#000" opacity=".12"/>`+
 pt("tail",124,82,`<path d="M120 84 L150 76 L144 86 L150 94 L122 90 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("wingB",108,72,`<path d="M104 76 Q118 40 150 34 Q140 58 112 82 Z" fill="${P.ac}" ${SW}/><path d="M118 62 Q132 48 146 40" stroke="${P.n}" stroke-width="3" fill="none"/>`,.25)+
 `<path d="M80 86 Q82 66 102 64 Q122 66 126 84 Q118 98 102 98 Q86 98 80 86 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",96,78,`<path d="M98 80 Q74 44 42 42 Q56 66 90 88 Z" fill="${P.n}" ${SW}/><path d="M60 50 Q76 60 88 76" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 pt("legF",100,100,`<path d="M96 96 l-2 8 M104 96 l2 8" stroke="${FI}" stroke-width="2.2" stroke-linecap="round"/>`)+
 pt("head",84,64,`<circle cx="84" cy="62" r="12" fill="${P.n}" ${SW}/><path d="M76 54 Q84 48 92 54" stroke="${P.ac}" stroke-width="3" fill="none"/>${E2(80,60,2.8,"#1A1A1A",[-.4,0])}`+
  `<path d="M73 64 L64 64 L72 67 Z" fill="${FMOUTH}"/>`+pt("beak",72,66,`<path d="M72 66 L64 66 L72 70 Z" fill="#E8A030" ${SW2}/>`)+`<path d="M73 62 L62 64 L73 64 Z" fill="#E8A030" ${SW2}/>`)+
 SNOW(g)+fG(g,2,`<circle cx="104" cy="88" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Featherrun"]="Featherweight Snow Bunting";SM("Featherrun","Lift Off","STR","a",55,100,"spd+2","It weighs nothing at all. The first bump in the snow and it's away into the air, sledge and all.");

/* 27 Fizzwell (vial): a water beetle surrounded by fizz, bubbles streaming off it */
addForm("Fizzwell",{n:"#4A6A5A",a:"#E8E4C0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#FF8A2A"},"swim",(P,g)=>fShadow(54,100)+
 `<ellipse cx="100" cy="118" rx="86" ry="30" fill="#6A9AB8" opacity=".5"/><path d="M30 96 q6 -3 12 0 M140 96 q6 -3 12 0" stroke="#FFF" stroke-width="1.6" fill="none"/>`+
 pt("spin",100,80,[[60,70,4],[72,56,3],[132,62,4],[146,76,3],[84,46,2.4],[120,44,2.4],[100,36,3]].map(([x,y,r])=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#F4FFFF" stroke="#6A9AB8" stroke-width="1"/>`).join(""))+
 [[80,"legF",0,"M84 112 L62 126 L54 120"],[96,"legB",.2,"M96 116 L88 134"],[112,"legF",.3,"M112 116 L120 134"],[126,"legB",.1,"M120 112 L142 126 L150 120"]].map(([x,c,d,p])=>pt(c,x,116,`<path d="${p}" stroke="${FI}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M72 108 Q72 86 100 84 Q128 86 130 108 Q124 126 100 126 Q76 126 72 108 Z" fill="${P.n}" ${SW}/><path d="M100 86 V124" stroke="${FI}" stroke-width="2"/><path d="M80 100 Q90 92 98 94 M102 94 Q112 92 120 100" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 pt("head",100,82,`<path d="M88 88 Q88 72 100 70 Q112 72 112 88 Z" fill="${P.nd}" ${SW}/>${E2(94,80,2.8,"#1A1A1A",[0,-.3])}${E2(106,80,2.8,"#1A1A1A",[0,-.3])}`+
  pt("ant",100,70,`<path d="M94 72 Q88 60 80 58 M106 72 Q112 60 120 58" stroke="${FI}" stroke-width="1.8" fill="none"/>`)+pt("jaw",100,88,`<path d="M95 86 Q100 92 105 86 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<circle cx="30" cy="60" r="3" fill="#F4FFFF" stroke="#6A9AB8" stroke-width="1"/><circle cx="170" cy="50" r="3" fill="#F4FFFF" stroke="#6A9AB8" stroke-width="1"/>`)+fG(g,2,`<circle cx="100" cy="112" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,130,6)));
FORM_TITLE["Fizzwell"]="Fizzing Water Beetle";SM("Fizzwell","Not Near The Sink","DRP","a",80,85,"tacc-1@50","Water touches it and the whole thing goes off like a shaken bottle. Dr. Holm has a crater to prove it.");

/* 28 Shakeup (vial): a guppy swimming inside a snow globe, flakes whirling round it */
addForm("Shakeup",{n:"#E8A040",a:"#5AA8E8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#FF5A8A"},"swim",(P,g)=>fShadow(46,100)+
 `<path d="M60 130 H140 L134 148 H66 Z" fill="#6A4A2A" ${SW}/><path d="M62 136 H138" stroke="#C8A060" stroke-width="2"/>`+
 `<circle cx="100" cy="82" r="50" fill="#DCEFFA" fill-opacity=".45" ${SW}/><path d="M56 104 Q100 120 144 104 Q140 130 100 132 Q60 130 56 104 Z" fill="#F4FAFF" ${SW2}/><path d="M68 50 Q80 36 96 34" stroke="#FFF" stroke-width="4" fill="none" stroke-linecap="round" opacity=".8"/>`+
 pt("spin",100,82,[[70,70],[128,60],[118,104],[78,96],[100,48],[136,84]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2" fill="#FFF" stroke="#9ACBE6" stroke-width=".6"/>`).join(""))+
 pt("tail",120,82,`<path d="M114 82 Q136 66 140 74 Q134 82 140 92 Q134 98 114 86 Z" fill="${P.ac}" ${SW2}/><path d="M122 80 L136 74 M122 84 L136 90" stroke="${P.n}" stroke-width="1.4"/>`)+
 `<path d="M76 84 Q82 70 100 70 Q116 72 118 84 Q114 96 100 96 Q84 96 76 84 Z" fill="${P.n}" ${SW}/>`+
 pt("wingF",98,90,`<path d="M96 90 Q100 102 108 100 Q106 92 100 88 Z" fill="${P.ac}" ${SW2}/>`)+
 pt("head",84,82,`${E2(86,80,3.4,"#1A1A1A",[-.4,0])}`+pt("jaw",78,86,`<path d="M76 84 Q78 90 82 87 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M30 40 h8 M34 36 v8 M166 120 h8 M170 116 v8" stroke="#BFE2F4" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="100" cy="80" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Shakeup"]="Snowglobe Guppy";SM("Shakeup","Give It A Shake","CUR","s",0,100,"tacc-2","Shake it and the snow goes everywhere. When it settles, everything's in a slightly different place.");

/* 29 Dripchime: a pine marten hanging from a row of icicles, tapping them like a xylophone */
addForm("Dripchime",{n:"#7A4A2A",a:"#F2C080",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(40,100)+
 `<path d="M24 20 H176" stroke="#9ACBE6" stroke-width="8" stroke-linecap="round"/>${[[40,52],[58,70],[76,88],[94,60],[124,80],[142,64],[160,48]].map(([x,l],i)=>`<path d="M${x-6} 22 L${x} ${22+l} L${x+6} 22 Z" fill="#DCEFFA" ${SW2}/><path d="M${x-2} 26 L${x} ${16+l*.7}" stroke="#FFF" stroke-width="1.6"/>`).join("")}`+
 pt("tail",120,44,`<path d="M118 40 Q146 30 150 50" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M118 40 Q146 30 150 50" stroke="${P.n}" stroke-width="7" fill="none" stroke-linecap="round"/>`)+
 pt("legB",116,26,`<path d="M114 38 L112 24" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`)+pt("legF",98,26,`<path d="M100 40 L102 24" stroke="${FI}" stroke-width="5" stroke-linecap="round"/>`,.3)+
 `<path d="M92 44 Q100 30 116 36 Q124 54 112 74 Q102 82 94 74 Q86 60 92 44 Z" fill="${P.n}" ${SW}/><path d="M96 56 Q100 70 108 72 Q110 60 104 50 Z" fill="${P.ac}"/>`+
 pt("armF",92,74,`${FLIMB("M96 72 Q84 82 76 76",P.n,4)}<path d="M76 76 L64 66" stroke="#8A6A44" stroke-width="2.4"/><circle cx="62" cy="64" r="3" fill="#E8E4DA" ${SW2}/>`)+
 pt("head",100,92,`<path d="M88 78 Q84 98 100 104 Q116 98 112 78 Z" fill="${P.n}" ${SW}/><path d="M92 92 Q100 100 108 92 Q104 100 100 102 Q96 100 92 92 Z" fill="${P.ac}"/>${E2(94,88,2.8,"#1A1A1A",[-.4,.2])}${E2(106,88,2.8,"#1A1A1A",[-.4,.2])}`+
  pt("ear",90,80,`<circle cx="88" cy="80" r="4" fill="${P.n}" ${SW2}/>`)+pt("jaw",100,100,`<path d="M96 98 Q100 104 104 98 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M40 100 q4 -4 8 0 M60 110 l2 -6 M150 110 q4 -4 8 0" stroke="#9ACBE6" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="60" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,120,6)));
FORM_TITLE["Dripchime"]="Icicle-Xylophone Marten";SM("Dripchime","The Same Tune","CUR","s",0,100,"tacc-1,tatk-1","Tap, tap, tap along the icicles. Somewhere further in, the icicles play it back.");

/* 30 Fishblock: a pike frozen mid-snap in a block of ice, looking very surprised */
addForm("Fishblock",{n:"#6A7A4A",a:"#E8E0A0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"swim",(P,g)=>fShadow(66,100)+
 `<path d="M24 146 V76 H170 V146 Z" fill="#DCEFFA" fill-opacity=".55" ${SW}/><path d="M24 76 L40 62 H186 L170 76 Z" fill="#EAF6FF" fill-opacity=".8" ${SW2}/><path d="M170 76 L186 62 V132 L170 146 Z" fill="#BFE2F4" fill-opacity=".8" ${SW2}/>`+
 pt("tail",146,110,`<path d="M140 110 L166 92 L160 110 L166 128 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M54 112 Q60 94 100 94 Q138 96 146 110 Q138 124 100 126 Q62 126 54 112 Z" fill="${P.n}" ${SW}/>${[[80,104],[96,102],[112,104],[126,108],[90,114],[108,116]].map(([x,y])=>`<ellipse cx="${x}" cy="${y}" rx="3" ry="2" fill="${P.ac}"/>`).join("")}`+
 pt("wingF",100,118,`<path d="M100 120 Q104 132 114 130 Q110 122 104 118 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",60,110,`${E2(68,104,4,"#1A1A1A",[0,0])}<path d="M54 106 L32 104 L54 110 Z" fill="${P.n}" ${SW2}/>`+pt("jaw",50,116,`<path d="M54 112 L30 116 L54 118 Z" fill="${FMOUTH}"/><path d="M54 112 L30 118 L54 120 Z" fill="${P.n}" ${SW2}/>${[36,42,48].map(x=>`<path d="M${x} 116 l1 -2" stroke="#FFF" stroke-width="1"/>`).join("")}`)+`<rect x="34" y="110" width="8" height="5" fill="#C8CCD4" ${SW2}/>`)+
 `<path d="M34 92 L60 84 M120 136 L150 128" stroke="#FFF" stroke-width="3" opacity=".75"/>`+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Fishblock"]="Ice-Block Pike";SM("Fishblock","Frozen Mid-Snap","DRP","a",75,90,"tspd-1@50","It went for the bait just as the ice closed. It's been surprised about it ever since.");

/* 31 Lost Mitten Box: a vole that has moved into an odd mitten, poking its head out of the cuff */
addForm("Lost Mitten Box",{n:"#9A7A5A",a:"#C83A4A",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(56,104)+
 `<path d="M76 146 Q62 120 70 96 Q80 76 104 78 Q118 66 130 76 Q136 86 128 96 Q150 104 150 128 Q148 146 120 146 Z" fill="${P.ac}" ${SW}/>${[84,96,108,120,132].map(x=>`<path d="M${x} 100 l4 6 l4 -6" stroke="#F4ECD8" stroke-width="1.6" fill="none"/>`).join("")}<path d="M74 132 Q100 140 146 130" stroke="#F4ECD8" stroke-width="5" fill="none"/>`+
 `<path d="M64 146 H96 Q98 128 82 124 Q68 126 64 146 Z" fill="#F4ECD8" ${SW}/>`+
 pt("tail",136,132,`<path d="M146 134 Q170 140 176 126" stroke="${FI}" stroke-width="4" fill="none" stroke-linecap="round"/><path d="M146 134 Q170 140 176 126" stroke="#D8A090" stroke-width="2" fill="none" stroke-linecap="round"/>`)+
 pt("armF",72,136,`<path d="M66 138 Q60 146 68 146" stroke="#D8A090" stroke-width="3" fill="none"/>`)+
 pt("head",78,118,`<path d="M92 128 Q92 106 74 106 Q56 108 54 122 Q58 132 74 132 Q90 132 92 128 Z" fill="${P.n}" ${SW}/><circle cx="55" cy="122" r="2.6" fill="#E8708A"/>${E2(68,116,3.2,"#1A1A1A",[-.3,0])}`+
  `<path d="M58 124 l-10 -2 M58 126 l-10 2" stroke="${FI}" stroke-width="1"/>`+pt("ear",80,106,`<circle cx="80" cy="106" r="5" fill="${P.n}" ${SW2}/><circle cx="80" cy="106" r="2.4" fill="#E8A8A0"/>`)+pt("jaw",62,130,`<path d="M58 128 Q62 134 68 130 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="118" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Lost Mitten Box"]="Mitten-Nesting Vole";SM("Lost Mitten Box","Nobody's Mitten","RES","s",0,100,"def+2","Nobody has ever found the other one. Nobody needs to. Somebody lives in this one now.");

/* 32 Draughtstop: a long dachshund lying across the bottom of a hut door, a breeze curling off it */
addForm("Draughtstop",{n:"#8A4A2A",a:"#E8C890",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(80,100)+
 `<rect x="40" y="30" width="120" height="104" fill="#7A5A3A" ${SW}/><path d="M60 46 H140 V82 H60 Z M60 92 H140 V124 H60 Z" fill="none" stroke="#5A3A20" stroke-width="2.4"/><circle cx="146" cy="88" r="4" fill="#C8A040" ${SW2}/>`+
 `<path d="M8 120 q8 -6 16 0 q8 6 16 0 M164 118 q8 -6 16 0" stroke="#BFE2F4" stroke-width="2" fill="none"/>`+
 [[56,"legF",0],[72,"legB",.2],[128,"legF",.3],[144,"legB",.1]].map(([x,c,d])=>pt(c,x,140,`<path d="M${x} 136 V146" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M${x} 136 V146" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/>`,d)).join("")+
 pt("tail",160,128,`<path d="M156 130 Q172 122 178 110" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M156 130 Q172 122 178 110" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 `<path d="M44 136 Q40 120 64 118 H140 Q164 120 160 136 Q156 144 140 144 H64 Q46 144 44 136 Z" fill="${P.n}" ${SW}/><path d="M60 140 H146" stroke="${P.ac}" stroke-width="4"/>`+
 pt("head",40,124,`<path d="M58 128 Q54 108 36 110 Q20 112 16 124 Q22 134 40 134 Q54 134 58 128 Z" fill="${P.n}" ${SW}/><circle cx="17" cy="124" r="3" fill="#1A1A1A"/>${E2(34,118,3.2,"#1A1A1A",[-.4,0])}`+
  pt("ear",46,114,`<path d="M42 112 Q56 110 54 134 Q46 130 42 120 Z" fill="${P.nd}" ${SW2}/>`)+pt("jaw",26,132,`<path d="M20 130 Q26 138 34 132 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="130" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(180,40,6)));
FORM_TITLE["Draughtstop"]="Draught-Excluder Dachshund";SM("Draughtstop","Not Under This Door","RES","s",0,100,"ward+2","It lies down across the bottom of the door, and not one breath of cold gets past it.");

/* 33 Stillfall (vial): a salmon frozen mid-leap up a frozen waterfall */
addForm("Stillfall",{n:"#A8B0B8",a:"#E88A6A",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"swim",(P,g)=>fShadow(50,100)+
 `<path d="M40 0 H160 L156 148 H44 Z" fill="#DCEFFA" ${SW}/>${[56,74,92,110,128,146].map((x,i)=>`<path d="M${x} 0 Q${x+4} 70 ${x-2} 148" stroke="#9ACBE6" stroke-width="${i%2?2:3}" fill="none"/>`).join("")}<path d="M30 148 Q100 136 170 148" stroke="#9ACBE6" stroke-width="4" fill="none"/>`+
 `<g transform="rotate(-50 100 84)">`+pt("tail",132,84,`<path d="M128 84 L152 70 L146 84 L152 98 Z" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M60 84 Q66 68 100 68 Q126 70 132 84 Q126 98 100 100 Q66 100 60 84 Z" fill="${P.n}" ${SW}/><path d="M72 90 Q100 98 126 88" stroke="${P.ac}" stroke-width="4" fill="none"/>${[[88,76],[104,74],[116,78]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.6" fill="${P.nd}"/>`).join("")}`+
 pt("wingF",100,94,`<path d="M98 96 Q102 108 112 106 Q108 98 102 94 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("head",66,84,`${E2(72,80,3.6,"#1A1A1A",[0,0])}`+pt("jaw",58,88,`<path d="M62 86 L50 88 L60 92 Z" fill="${FMOUTH}"/>`)+`<path d="M62 82 L48 86 L62 86 Z" fill="${P.n}" ${SW2}/>`)+`</g>`+
 fG(g,1,`<path d="M20 40 h8 M24 36 v8 M172 60 h8 M176 56 v8" stroke="#BFE2F4" stroke-width="1.6"/>`)+fG(g,2,`<circle cx="100" cy="84" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(176,120,6)));
FORM_TITLE["Stillfall"]="Frozen-Falls Salmon";SM("Stillfall","Halfway Up","RES","s",0,100,"def+1,ward+1","Mid-leap, mid-fall, mid-everything, and it has stayed exactly there for longer than anyone can remember.");

/* 34 Angelprint: a sloth lying on its back in the snow, arms and legs swept out in a snow angel */
addForm("Angelprint",{n:"#9A8A6A",a:"#E8DCC0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"crawl",(P,g)=>fShadow(70,100)+
 `<ellipse cx="100" cy="122" rx="86" ry="26" fill="#F4FAFF" ${SW2}/><path d="M30 122 Q50 92 76 110 M170 122 Q150 92 124 110 M48 140 Q70 150 84 136 M152 140 Q130 150 116 136" stroke="#C8DCEC" stroke-width="6" fill="none" stroke-linecap="round"/>`+
 pt("armF",76,112,FLIMB("M80 114 Q60 104 42 112",P.n,7)+`<path d="M42 112 l-6 -4 M42 112 l-6 2 M42 112 l-4 6" stroke="${FI}" stroke-width="2"/>`)+pt("armB",124,112,FLIMB("M120 114 Q140 104 158 112",P.n,7)+`<path d="M158 112 l6 -4 M158 112 l6 2 M158 112 l4 6" stroke="${FI}" stroke-width="2"/>`,.3)+
 pt("legF",88,130,FLIMB("M90 130 Q76 140 62 140",P.n,7))+pt("legB",112,130,FLIMB("M110 130 Q124 140 138 140",P.n,7),.2)+
 `<path d="M78 124 Q78 104 100 102 Q122 104 122 124 Q116 136 100 136 Q84 136 78 124 Z" fill="${P.n}" ${SW}/>`+
 pt("head",100,94,`<circle cx="100" cy="92" r="15" fill="${P.n}" ${SW}/><path d="M88 90 Q100 80 112 90 Q110 100 100 102 Q90 100 88 90 Z" fill="${P.ac}"/><path d="M88 88 Q94 92 98 88 M102 88 Q106 92 112 88" stroke="#4A3A2A" stroke-width="4" fill="none" stroke-linecap="round"/>`+
  `<path d="M92 89 Q94 87 96 89 M104 89 Q106 87 108 89" stroke="${FI}" stroke-width="1.6" fill="none"/>`+pt("jaw",100,98,`<path d="M96 96 Q100 101 104 96" stroke="${FI}" stroke-width="1.6" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Angelprint"]="Snow-Angel Sloth";SM("Angelprint","Arms Out, Arms In","HEA","s",0,100,"heal:30","Arms out, arms in. Legs out, legs in. Very slowly. The angel comes out perfect every time.");

/* 35 Kicksled Post: a reindeer pushing a kicksled loaded with letters */
addForm("Kicksled Post",{n:"#8A6A4A",a:"#E8DCC0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(70,104)+
 `<path d="M20 144 H90 Q100 144 102 136" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M20 144 H90 Q100 144 102 136" stroke="#C8CCD4" stroke-width="2.4" fill="none" stroke-linecap="round"/><path d="M84 144 V96 H92" stroke="#6A4A2A" stroke-width="4" fill="none"/><rect x="26" y="110" width="58" height="10" fill="#8A6A44" ${SW2}/><path d="M30 120 V144 M78 120 V144" stroke="#6A4A2A" stroke-width="3"/>`+
 `${[[30,98,0],[44,96,4],[58,100,-6],[40,86,8],[54,84,-3]].map(([x,y,r])=>`<rect x="${x}" y="${y}" width="18" height="12" fill="#F4ECD8" stroke="${FI}" stroke-width="1.4" transform="rotate(${r} ${x+9} ${y+6})"/><path d="M${x} ${y} L${x+9} ${y+6} L${x+18} ${y}" stroke="${FI}" stroke-width="1" fill="none" transform="rotate(${r} ${x+9} ${y+6})"/>`).join("")}`+
 [[118,"legF",0],[132,"legB",.2],[156,"legF",.3],[168,"legB",.1]].map(([x,c,d])=>pt(c,x,126,`<path d="M${x} 112 V142" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M${x} 112 V142" stroke="${P.n}" stroke-width="4" stroke-linecap="round"/><path d="M${x-3} 142 h6" stroke="${FI}" stroke-width="4"/>`,d)).join("")+
 pt("tail",174,98,`<path d="M172 98 Q182 94 180 104 Z" fill="${P.ac}" ${SW2}/>`)+
 `<path d="M108 108 Q110 88 140 86 Q172 86 176 104 Q170 118 140 118 Q112 118 108 108 Z" fill="${P.n}" ${SW}/><path d="M112 100 Q120 112 132 112" stroke="${P.ac}" stroke-width="6" fill="none"/>`+
 pt("armF",112,96,`<path d="M108 96 Q100 98 92 96" stroke="#5A3A20" stroke-width="3" stroke-linecap="round"/>`)+
 pt("head",104,70,`<path d="M116 88 Q120 70 108 62 Q94 56 88 70 Q84 80 92 84 Q104 90 116 88 Z" fill="${P.n}" ${SW}/><circle cx="88" cy="74" r="4" fill="#3A2A20"/>${E2(100,68,3.2,"#1A1A1A",[-.4,0])}`+
  pt("ant",108,58,`<path d="M106 60 Q100 40 108 28 M104 46 Q94 40 90 30 M108 36 Q118 30 120 22 M112 60 Q124 46 134 44 M126 46 Q130 36 138 34" stroke="${FI}" stroke-width="5" fill="none" stroke-linecap="round"/><path d="M106 60 Q100 40 108 28 M104 46 Q94 40 90 30 M108 36 Q118 30 120 22 M112 60 Q124 46 134 44 M126 46 Q130 36 138 34" stroke="#C8A878" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
  `<path d="M98 82 Q110 94 122 84" stroke="#C83A2A" stroke-width="4" fill="none"/><circle cx="110" cy="92" r="3" fill="#E8C040" ${SW2}/>`+pt("jaw",92,82,`<path d="M88 80 Q92 86 98 82 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="140" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Kicksled Post"]="Mail-Sledge Reindeer";SM("Kicksled Post","Delivered Cold","QUE","a",60,100,"tacc-1@30","Kick, glide, kick, glide, and every letter in the cavern arrives stamped DELIVERED COLD.");

/* 36 Gustcount: a red squirrel whose bushy tail is an anemometer, cups spinning */
addForm("Gustcount",{n:"#B8643A",a:"#F4E8D0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(46,100)+
 `<path d="M136 146 V60" stroke="#6A6A70" stroke-width="4"/><rect x="128" y="136" width="16" height="10" fill="#8A8A92" ${SW2}/>`+
 pt("tail",136,58,`<path d="M120 120 Q150 110 140 80 Q136 64 136 58" stroke="${FI}" stroke-width="15" fill="none" stroke-linecap="round"/><path d="M120 120 Q150 110 140 80 Q136 64 136 58" stroke="${P.n}" stroke-width="11" fill="none" stroke-linecap="round"/>`+
  `<g class="pt p-spin" style="transform-origin:136px 50px">${[0,1,2].map(i=>{const a=i*2.09,x=136+Math.cos(a)*24,y=50+Math.sin(a)*9;return`<path d="M136 50 L${x.toFixed(1)} ${y.toFixed(1)}" stroke="${FI}" stroke-width="2"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="6" fill="#C8CCD4" ${SW2}/>`}).join("")}</g><circle cx="136" cy="50" r="3" fill="${FI}"/>`)+
 [[92,"legB",.25],[108,"legF",0]].map(([x,c,d])=>pt(c,x,138,`<ellipse cx="${x}" cy="143" rx="8" ry="4" fill="${P.n}" ${SW2}/>`,d)).join("")+
 `<path d="M80 136 Q74 106 98 98 Q122 102 122 132 Q114 146 98 146 Q82 146 80 136 Z" fill="${P.n}" ${SW}/><path d="M88 134 Q86 114 98 110 Q110 114 110 134 Z" fill="${P.ac}"/>`+
 pt("armF",88,112,`${FLIMB("M90 112 Q80 106 74 98",P.n,4)}<rect x="62" y="84" width="16" height="18" rx="2" fill="#F4ECD8" ${SW2}/><path d="M65 89 h10 M65 93 h10 M65 97 h7" stroke="#8A94A8" stroke-width="1"/>`)+
 pt("head",96,86,`<circle cx="96" cy="84" r="16" fill="${P.n}" ${SW}/>`+pt("ear",88,66,`<path d="M84 72 L84 58 L94 68 Z" fill="${P.n}" ${SW2}/><path d="M84 58 l-2 -4" stroke="${P.n}" stroke-width="2"/>`)+pt("ear",106,66,`<path d="M100 68 L108 56 L110 72 Z" fill="${P.n}" ${SW2}/>`,.3)+
  `${E2(90,82,3.4,"#1A1A1A",[-.3,0])}${E2(102,82,3.4,"#1A1A1A",[-.3,0])}<circle cx="82" cy="90" r="2.4" fill="#1A1A1A"/>`+pt("jaw",86,96,`<path d="M82 94 Q86 100 92 96 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="98" cy="126" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Gustcount"]="Anemometer-Tailed Squirrel";SM("Gustcount","Eighteen Million And One","SCR","s",0,100,"tacc-1,spd+1","Another gust. Count it. Another. Count it. It's counting towards something. It'll know when it gets there.");

/* 37 Bottlewarm: a capybara sitting on the team bench with a stone hot-water bottle on its lap */
addForm("Bottlewarm",{n:"#9A6A44",a:"#C8C4BA",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(60,100)+
 `<rect x="40" y="118" width="124" height="8" fill="#8A6A44" ${SW2}/><path d="M50 126 V146 M154 126 V146" stroke="#5A3A20" stroke-width="5"/>`+
 [[86,"legB",.25],[112,"legF",0]].map(([x,c,d])=>pt(c,x,132,`<path d="M${x} 124 V144" stroke="${FI}" stroke-width="10" stroke-linecap="round"/><path d="M${x} 124 V144" stroke="${P.n}" stroke-width="6" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M70 120 Q64 86 100 78 Q136 86 130 120 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M84 102 Q84 92 100 92 Q116 92 116 102 V116 Q116 122 100 122 Q84 122 84 116 Z" fill="${P.ac}" ${SW}/><rect x="96" y="86" width="8" height="7" fill="#6A4A2A" ${SW2}/><path d="M86 104 H114" stroke="#8A867C" stroke-width="1.6"/>`+
 pt("armF",80,104,`${FLIMB("M76 98 Q74 110 86 112",P.n,6)}`)+pt("armB",124,104,`${FLIMB("M124 98 Q126 110 114 112",P.n,6)}`,.3)+
 pt("head",100,62,`<path d="M74 66 Q72 44 98 40 Q126 40 128 62 Q130 78 112 82 Q90 86 78 80 Q72 76 74 66 Z" fill="${P.n}" ${SW}/><path d="M74 66 Q74 76 84 78 Q96 80 100 74" fill="${P.nd}"/>`+
  `<path d="M88 58 Q92 55 96 58 M106 58 Q110 55 114 58" stroke="${FI}" stroke-width="2" fill="none" stroke-linecap="round"/><ellipse cx="82" cy="70" rx="2" ry="1.4" fill="#1A1A1A"/>`+pt("ear",118,44,`<ellipse cx="118" cy="44" rx="5" ry="4" fill="${P.nd}" ${SW2}/>`)+pt("jaw",88,78,`<path d="M82 76 Q88 82 94 78 Z" fill="${FMOUTH}"/>`)+
  pt("slow",100,30,`<path d="M96 30 Q92 22 98 16 M106 30 Q110 22 104 14" stroke="#E8ECF0" stroke-width="2.4" fill="none" stroke-linecap="round"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="100" cy="110" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Bottlewarm"]="Hot-Water-Bottle Capybara";SM("Bottlewarm","On The Bench","HEA","s",0,100,"heal:40","A stone bottle, a warm lap, and nowhere to be until the second half. It could do this all winter.");

/* 38 Thawday: a marmot just out of its burrow, a crocus sprouting from its head */
addForm("Thawday",{n:"#9A7A54",a:"#B88AE8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50,100)+
 `<ellipse cx="100" cy="146" rx="60" ry="10" fill="#6A5A3A" ${SW2}/><ellipse cx="100" cy="146" rx="34" ry="6" fill="#2A1A10"/><path d="M42 146 q10 -10 20 0 M140 146 q10 -10 20 0" fill="#F4FAFF" stroke="#9ACBE6" stroke-width="1.6"/>`+
 `<path d="M74 146 Q70 108 100 98 Q130 108 126 146 Z" fill="${P.n}" ${SW}/><path d="M86 146 Q84 118 100 112 Q116 118 114 146 Z" fill="#D8C8A8"/>`+
 pt("armF",84,118,`${FLIMB("M84 116 Q76 124 82 130",P.n,5)}`)+pt("armB",116,118,`${FLIMB("M116 116 Q124 124 118 130",P.n,5)}`,.3)+
 pt("head",100,84,`<circle cx="100" cy="82" r="18" fill="${P.n}" ${SW}/>`+pt("ear",86,68,`<circle cx="86" cy="68" r="4" fill="${P.n}" ${SW2}/>`)+pt("ear",114,68,`<circle cx="114" cy="68" r="4" fill="${P.n}" ${SW2}/>`,.3)+
  `<path d="M90 90 Q100 96 110 90 Q106 98 100 98 Q94 98 90 90 Z" fill="#D8C8A8"/>${E2(92,80,3.6,"#1A1A1A",[0,-.6])}${E2(108,80,3.6,"#1A1A1A",[0,-.6])}<ellipse cx="100" cy="88" rx="3" ry="2" fill="#1A1A1A"/>`+
  pt("jaw",100,94,`<path d="M96 92 Q100 98 104 92 Z" fill="${FMOUTH}"/><rect x="98" y="92" width="4" height="4" fill="#F4E8C8" stroke="${FI}" stroke-width=".8"/>`)+
  pt("sway",100,64,`<path d="M100 64 Q98 52 102 42" stroke="#5A8A3A" stroke-width="2.4" fill="none"/><path d="M100 58 Q92 52 94 46" stroke="#5A8A3A" stroke-width="2" fill="none"/><path d="M102 42 Q94 30 98 22 Q102 30 102 22 Q106 30 110 22 Q112 34 102 42 Z" fill="${P.ac}" ${SW2}/><path d="M102 40 V30" stroke="#E8C040" stroke-width="1.6"/>`))+
 fG(g,1,`<circle cx="160" cy="40" r="10" fill="#F2C94C" opacity=".5"/>`)+fG(g,2,`<circle cx="100" cy="126" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,50,6)));
FORM_TITLE["Thawday"]="Crocus-Sprouting Marmot";SM("Thawday","First Drip","HEA","s",0,100,"heal:20,spd+1,cure","The cavern mouth drips instead of freezing, and out it comes, blinking, with a crocus on its head.");

/* 39 Frostfair: the pig who escaped the roast, at the frost fair, with a ribbon of tokens round its neck and a toffee apple */
addForm("Frostfair",{n:"#E8A0A0",a:"#C8A040",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(56,100)+ICEFLOOR(100,76)+
 `<path d="M150 146 V70 M180 146 V70 M146 70 H184 L174 56 H156 Z" fill="#C83A2A" stroke="${FI}" stroke-width="2"/><path d="M150 84 H180" stroke="#F4ECD8" stroke-width="3"/><rect x="152" y="100" width="26" height="10" fill="#F4ECD8" ${SW2}/>`+
 [[84,"legB",.25],[96,"legF",0],[118,"legB",.15],[130,"legF",.3]].map(([x,c,d])=>pt(c,x,134,`<path d="M${x} 124 V142" stroke="${FI}" stroke-width="8" stroke-linecap="round"/><path d="M${x} 124 V142" stroke="${P.n}" stroke-width="5" stroke-linecap="round"/><path d="M${x-3} 142 h6" stroke="${FI}" stroke-width="3"/>`,d)).join("")+
 pt("tail",142,106,`<path d="M140 106 q8 -6 4 -10 q-6 -2 -2 -8" stroke="${FI}" stroke-width="2.6" fill="none" stroke-linecap="round"/>`)+
 `<path d="M72 112 Q72 90 104 88 Q140 88 144 112 Q140 130 106 130 Q74 130 72 112 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M72 98 Q86 112 102 104" stroke="#3A6AC8" stroke-width="4" fill="none"/>${[[78,104],[86,108],[94,108]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="3.4" fill="${P.ac}" ${SW2}/>`).join("")}`+
 pt("head",66,96,`<path d="M84 100 Q84 78 64 76 Q44 76 42 94 Q44 110 62 112 Q80 112 84 100 Z" fill="${P.n}" ${SW}/><ellipse cx="44" cy="98" rx="7" ry="9" fill="${P.nd}" ${SW2}/><circle cx="42" cy="95" r="1.6" fill="${FI}"/><circle cx="42" cy="101" r="1.6" fill="${FI}"/>${E2(60,88,3.2,"#1A1A1A",[-.3,0])}`+
  pt("ear",72,76,`<path d="M68 80 L64 62 L80 74 Z" fill="${P.n}" ${SW2}/>`)+pt("jaw",54,108,`<path d="M48 106 Q54 114 62 108 Z" fill="${FMOUTH}"/><path d="M54 108 L44 124" stroke="#8A6A44" stroke-width="2"/><circle cx="42" cy="128" r="7" fill="#C83A2A" ${SW2}/><path d="M38 124 Q42 122 46 124" stroke="#E8C040" stroke-width="2" fill="none"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="110" cy="114" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Frostfair"]="Frost-Fair Piglet";SM("Frostfair","Got Away","QUE","a",65,100,"spd+1,tacc-1@30","Off the spit, off the stall, and halfway across the frozen pool before anyone's put down their toffee apple.");

/* 40 Underice (vial): a jellyfish glowing under a sheet of ice, trailing light */
addForm("Underice",{n:"#8AD8E8",a:"#E8F4FF",rn:"#3A3A6A",rb:"#C8E8F0",ra:"#F2C94C"},"hover",(P,g)=>
 `<path d="M0 30 H200 V44 H0 Z" fill="#DCEFFA" fill-opacity=".8" ${SW2}/><path d="M20 36 L60 34 M120 38 L170 36" stroke="#FFF" stroke-width="2.4"/><ellipse cx="100" cy="100" rx="96" ry="56" fill="#2A4A6A" opacity=".45"/>`+
 `<circle cx="100" cy="82" r="44" fill="${P.n}" opacity=".18"/>`+
 [[80,0],[92,.2],[104,.4],[116,.1],[126,.3]].map(([x,d],i)=>pt(i%2?"legB":"legF",x,94,`<path d="M${x} 94 Q${x-8} 112 ${x+2} 126 Q${x+10} 140 ${x-2} 152" stroke="${P.nd}" stroke-width="2.4" fill="none" stroke-linecap="round" opacity=".9"/>`,d)).join("")+
 pt("armF",96,96,`<path d="M92 94 Q86 116 96 130 M108 94 Q114 116 104 132" stroke="${P.ac}" stroke-width="5" fill="none" stroke-linecap="round" opacity=".8"/>`)+
 `<path d="M62 92 Q62 56 100 54 Q138 56 138 92 Q130 98 120 94 Q110 100 100 94 Q90 100 80 94 Q70 98 62 92 Z" fill="${P.n}" fill-opacity=".9" ${SW}/><path d="M74 78 Q100 62 126 78" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".8"/>`+
 pt("head",100,80,`${E2(90,80,3.6,"#1A1A1A",[0,-.4])}${E2(110,80,3.6,"#1A1A1A",[0,-.4])}`+pt("jaw",100,88,`<path d="M96 86 Q100 92 104 86 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<circle cx="40" cy="110" r="2" fill="${P.ac}"/><circle cx="160" cy="120" r="2" fill="${P.ac}"/><circle cx="150" cy="70" r="1.6" fill="${P.ac}"/>`)+fG(g,2,`<circle cx="100" cy="70" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,140,6)));
FORM_TITLE["Underice"]="Under-Ice Jellyfish";SM("Underice","Never Opened","RAD","s",0,100,"tacc-2@50","Down under the ice something drifts and glows. Everyone has agreed it stays down there.");

/* 41 Firsthut (legendary): a snail whose shell is Research Hut No. 1, chimney smoking, door sealed */
addForm("Firsthut",{n:"#9A8A7A",a:"#C8A060",rn:"#F4F0E6",rb:"#3A4A8A",ra:"#FFD66B"},"crawl",(P,g)=>fShadow(66,104)+ICEFLOOR(104,84)+
 `<path d="M30 140 Q34 124 60 124 H150 Q172 124 176 140 Z" fill="${P.n}" ${SW}/><path d="M40 134 Q100 140 168 134" stroke="${P.nl}" stroke-width="3" fill="none"/>`+
 /* the hut on its back */
 `<path d="M70 124 V80 H150 V124 Z" fill="#8A3A2A" ${SW}/><path d="M64 82 L110 50 L156 82 Z" fill="#F4FAFF" ${SW}/><path d="M70 92 H150 M70 104 H150 M70 116 H150" stroke="#6A2A1A" stroke-width="1.6"/>`+
 `<rect x="100" y="92" width="22" height="32" fill="#5A3A20" ${SW2}/><rect x="100" y="92" width="22" height="32" fill="none" stroke="${P.ac}" stroke-width="2"/><circle cx="118" cy="108" r="1.8" fill="#E8C040"/><text x="104" y="89" font-size="7" font-weight="bold" fill="#F4ECD8">No.1</text>`+
 `<rect x="78" y="94" width="14" height="12" fill="#FFE6A0" ${SW2}/><path d="M85 94 V106 M78 100 H92" stroke="${FI}" stroke-width="1"/>`+
 `<rect x="134" y="54" width="10" height="20" fill="#6A6A70" ${SW2}/>`+pt("slow",139,50,`<path d="M139 50 Q134 40 140 32 Q146 24 140 14" stroke="#E8ECF0" stroke-width="3.4" fill="none" stroke-linecap="round" opacity=".85"/>`)+
 pt("head",40,116,`<path d="M58 132 Q54 104 40 100 Q24 100 22 114 Q24 128 40 132 Z" fill="${P.n}" ${SW}/>${E2(34,110,3,"#1A1A1A",[-.3,0])}`+
  pt("ant",36,100,`<path d="M32 102 Q26 84 30 74 M42 102 Q44 84 52 76" stroke="${FI}" stroke-width="2.4" fill="none"/><circle cx="30" cy="72" r="3" fill="${P.n}" ${SW2}/><circle cx="52" cy="74" r="3" fill="${P.n}" ${SW2}/>`)+pt("jaw",28,126,`<path d="M24 122 Q28 130 36 126 Z" fill="${FMOUTH}"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="160" cy="132" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Firsthut"]="Hut-Shelled Snail";SM("Firsthut","The First Winter","RES","s",0,100,"def+1,ward+1,heal:30","Ninety thousand openings of one door, and the seal melts and sets, melts and sets, and the cold never gets in.");

/* 42 Deepthaw (legendary, vial): a mammoth calf half out of a block of ice, one eye just opened */
addForm("Deepthaw",{n:"#7A5A3A",a:"#F4F0E6",rn:"#F4F0E6",rb:"#3A4A8A",ra:"#7AE8FF"},"stand",(P,g)=>fShadow(66,100)+
 `<path d="M26 146 V58 L44 40 H184 V128 L166 146 Z" fill="#DCEFFA" fill-opacity=".4" ${SW}/><path d="M26 58 H166 V146 M166 58 L184 40" fill="none" stroke="${FI}" stroke-width="2"/><path d="M40 70 L70 64 M140 130 L160 124" stroke="#FFF" stroke-width="3" opacity=".75"/>`+
 `<path d="M90 146 Q96 136 106 146 M132 146 Q138 138 146 146" fill="#9ACBE6" stroke="${FI}" stroke-width="1.6"/>`+
 [[86,"legB",.25],[104,"legF",0],[132,"legB",.15],[148,"legF",.3]].map(([x,c,d])=>pt(c,x,130,`<path d="M${x} 116 V144" stroke="${FI}" stroke-width="13" stroke-linecap="round"/><path d="M${x} 116 V144" stroke="${P.n}" stroke-width="9" stroke-linecap="round"/>`,d)).join("")+
 pt("tail",160,104,`<path d="M158 102 Q168 108 166 120" stroke="${FI}" stroke-width="4" fill="none"/><path d="M166 120 l-3 6 M166 120 l3 6" stroke="${P.nd}" stroke-width="2"/>`)+
 `<path d="M74 110 Q72 76 116 72 Q160 72 162 106 Q156 124 116 124 Q78 124 74 110 Z" fill="${P.n}" ${SW}/>${[[96,80],[112,78],[128,80],[144,86],[104,92],[124,92],[140,98]].map(([x,y])=>`<path d="M${x} ${y} q-2 6 1 10" stroke="${P.nd}" stroke-width="2" fill="none"/>`).join("")}`+
 pt("head",74,86,`<path d="M96 92 Q98 62 76 58 Q54 58 52 80 Q52 94 64 100 Q84 104 96 92 Z" fill="${P.n}" ${SW}/>`+pt("ear",88,70,`<path d="M86 66 Q102 64 100 86 Q90 84 86 76 Z" fill="${P.nd}" ${SW2}/>`)+
  `${E2(68,76,3.6,"#4A2A10",[-.4,0])}<path d="M72 74 Q78 72 80 76" stroke="${FI}" stroke-width="1.6" fill="none"/>`+
  pt("jaw",62,98,`<path d="M58 96 Q64 104 70 98 Z" fill="${FMOUTH}"/><path d="M60 96 Q48 104 52 116 Q56 110 64 104 Z M70 98 Q66 110 72 118 Q74 108 74 100 Z" fill="${P.ac}" ${SW2}/>`)+
  pt("sway",54,96,`<path d="M56 94 Q42 100 40 116 Q38 128 46 132" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M56 94 Q42 100 40 116 Q38 128 46 132" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/>`))+
 SNOW(g)+fG(g,2,`<circle cx="116" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(176,20,6)));
FORM_TITLE["Deepthaw"]="Thawing Mammoth Calf";SM("Deepthaw","Ice Age Over","STR","a",85,90,"crit,spd+1","The ice runs off it in sheets. One eye opens. Then the other. It has been waiting a very, very long time to stretch its legs.");
