/* =============== HOLLOWMERE: MORE TO DO, AND SOMEBODY WHO NEVER CAME HOME ===============
   Nine new things to do in the village, each with its own prize, and one at the bog gate at the top of the moor.
   Scattered through them, and through what people say, are scraps of one old story. Nothing ever tells it straight out. */

/* ---- the map: three new pieces of furniture ---- */
{const put=(x,y,c)=>{const r=MAPS["z-hollow"][y];MAPS["z-hollow"][y]=r.slice(0,x)+c+r.slice(x+1)};
  put(1,7,"A");put(37,11,"A");put(38,14,"A");HOLLOW_ZONE.map=MAPS["z-hollow"].slice()}
const HMX={bell:[1,7],ledger:[37,11],barrel:[38,14],gate:[36,0],bog:[2,0],chalk:[35,20],grave:[3,13],burn:[[37,18],[37,19]],
  morag:[23,14],judge:[20,10],bel:[36,14]};
const hmA=n=>LNT_MORE.find(o=>o.name===n);
const hmPrize=n=>storyFight(n,{intro:"It wriggles out of your hands as soon as you've got it. Identify it before it's off!"});

/* ---- scraps of the story ---- */
const HM_FRAGS={
 ledger:"A lamplighter's round book: 'Bog gate lamp out again. Relit.' Every night, for years. The last entry is Lantern Night, 1889: 'All lit but the gate. Going back up for it.'",
 chalk:"Chalk gone into the stone on the end wall of the last cottage: a tall figure with a lamp on a pole, holding a little one by the hand. Underneath, half rubbed away: 'DA'.",
 grave:"A rubbing of the worn stone in the kirkyard: 'J.H. · KEEPER OF THE LANTERNS · HE WENT BACK UP FOR THE LAST ONE.' No dates. Underneath, smaller: 'NOT HERE.'",
 register:"The parish book, 1 November 1889: 'Ada H., aged seven, came down off the moor at first light, wet to the waist, unharmed. Says a man with a lamp walked her to the gate and would not come through it. Search for J.H. called off on the 9th.'",
 tags:"Card tags tied along the top bar of the bog gate, years and years of them, faded past reading. The newest still says 'HOME. A.' It's dated 1970. There are none after that.",
 chimney:"Hauled up from the bottom of the well: a lamp chimney black with old soot, scratched near the base: 'for A., so you can see me coming.'",
 peel:"Every apple peel thrown in the cider yard lands as an A. 'Every year, everybody's,' says Bel Ormerod. 'Long before my time.'",
 story:"Every story told round the fire on the green ends the same way: 'And he's out there still.'",
 marlow:"An Institute field note from Lantern Night, 1889: 'A single lamp moving along the bog edge in the small hours, against the wind. Stopping, starting. Assumed a search party. There was no search party out until morning.'",
 voice:"Somebody with a shadow in them asked you, in a voice that wasn't their own: 'Is she home? Has anybody looked to see if she got home?'"};
const HM_FRAG_ORDER=["ledger","chalk","grave","register","tags","chimney","peel","story","marlow","voice"];
const hmFrags=()=>lntF("frags")||[];
function hmFrag(k){const f=hmFrags();if(f.includes(k))return false;lntSet("frags",[...f,k]);setTimeout(()=>say0("You'll remember that. (It's in your journal.)"),60);return true}
const hmBG=()=>lntF("bg")||0;  /* 0 nobody asked, 1 carrying the tag up, 2 the lamp is lit on the gate */

/* ---- drawings ---- */
const HMX_SVG={
 bell:`<ellipse cx="20" cy="37" rx="12" ry="2.4" fill="#000" opacity=".3"/><path d="M8 37 V0 M32 37 V0" stroke="#4A3422" stroke-width="3"/><path d="M5 0 H35" stroke="#4A3422" stroke-width="4" stroke-linecap="round"/><path d="M4 -2 L20 -10 L36 -2" fill="none" stroke="#3A2A1A" stroke-width="2"/>
  <g class="hmx-bell"><path d="M14 2 Q13.6 12 11 16 H29 Q26.4 12 26 2 Q20 -1 14 2 Z" fill="#C8A060" stroke="#2A1A0A" stroke-width="1.2"/><path d="M11 16 Q20 19 29 16" stroke="#2A1A0A" stroke-width="1.2" fill="none"/><circle cx="20" cy="18" r="1.6" fill="#5A4A3A"/></g>
  <path d="M20 16 V30" stroke="#B8A880" stroke-width="1.4"/><rect x="18" y="24" width="4" height="7" rx="1.5" fill="#C83A2A" stroke="#2A1A0A" stroke-width=".7"/>`,
 ledger:`<ellipse cx="20" cy="36" rx="14" ry="2.4" fill="#000" opacity=".3"/><path d="M6 20 H34 V35 H6 Z" fill="#7A5A3A" stroke="#2A1A0A" stroke-width="1.2"/><path d="M6 27 H34 M13 20 V35 M27 20 V35" stroke="#5A3A20" stroke-width=".8"/><path d="M10 20 L12 13 H30 L28 20 Z" fill="#E8E0C8" stroke="#2A1A0A" stroke-width="1"/><path d="M20 13 V20" stroke="#8A7A5A" stroke-width=".8"/><path d="M14 15 H18 M14 17 H19 M22 15 H27 M22 17 H26" stroke="#6A6A70" stroke-width=".6"/><path d="M12 13 L14 10 H30 V13" fill="#5A3A20" stroke="#2A1A0A" stroke-width=".8"/>`,
 barrel:`<ellipse cx="20" cy="37" rx="12" ry="2.4" fill="#000" opacity=".3"/><path d="M8 12 Q6 24 8 36 H32 Q34 24 32 12 Z" fill="#8A5A30" stroke="#2A1A0A" stroke-width="1.2"/><path d="M7 18 H33 M7 30 H33" stroke="#4A4A50" stroke-width="2"/><ellipse cx="20" cy="12" rx="12" ry="3.6" fill="#5A3A1A" stroke="#2A1A0A" stroke-width="1"/>${[[14,10],[20,9],[26,10],[17,12],[23,12]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="#C83A2A" stroke="#2A1A0A" stroke-width=".6"/>`).join("")}<path d="M30 6 h8 v6 h-8 Z" fill="#2A2A30" stroke="#121216" stroke-width=".6"/><path d="M31 8 h6 M31 10 h4" stroke="#E8E4DA" stroke-width=".5"/>`,
 chalk:`<g opacity=".72" stroke="#E8E8E0" stroke-width=".9" fill="none" stroke-linecap="round"><circle cx="13" cy="12" r="2.2"/><path d="M13 14 V24 M13 24 L10 30 M13 24 L16 30 M13 17 L19 20"/><path d="M8 14 V4 M8 4 h-3 v4 h3"/><circle cx="22" cy="19" r="1.6"/><path d="M22 21 V26 M22 26 L20 30 M22 26 L24 30 M22 22 L19 20"/><path d="M9 34 l1.4 -4 l1.4 4 M10 33 h1 M14 30 v4 q2 0 2 -2 q0 -2 -2 -2" stroke-width=".8"/></g>`,
 gate:(lit)=>`<path d="M4 38 V6 M36 38 V6" stroke="#4A3422" stroke-width="3.4"/><path d="M4 12 H36 M4 22 H36 M4 32 H36 M4 32 L36 12" stroke="#6A4A30" stroke-width="2.6" stroke-linecap="round"/>
  ${Array.from({length:7},(_,i)=>`<rect x="${7+i*4}" y="12.6" width="2.4" height="3.4" rx=".4" fill="#D8D0B8" stroke="#6A6450" stroke-width=".3" transform="rotate(${(i*7)%13-6} ${8+i*4} 13)"/>`).join("")}
  <path d="M36 8 Q40 8 40 12" stroke="#2A2A30" stroke-width="1.4" fill="none"/>${lit?`<circle cx="40" cy="18" r="10" fill="#FFD66B" opacity=".25"/><path d="M40 12 V13.4" stroke="#2A2A30" stroke-width=".9"/><path d="M37 13.4 H43 L44 15 V21 H36 V15 Z" fill="#FFE6A0" stroke="#2A1A0A" stroke-width=".9"/><path d="M40 15.6 Q41.4 17.6 40 19.6 Q38.6 17.6 40 15.6 Z" fill="#FF8A2A"/>`:""}`,
 bog:`<path d="M2 38 Q4 26 2 16 M7 38 Q8 24 10 14 M12 38 Q12 28 15 18 M27 38 Q28 26 25 15 M32 38 Q33 28 36 20 M36 38 Q37 30 39 24" stroke="#5A6A3A" stroke-width="1.6" fill="none"/><path d="M10 14 q1 -3 2 0 q-1 2 -2 0 Z M25 15 q1 -3 2 0 q-1 2 -2 0 Z" fill="#6A4A2A"/><circle cx="20" cy="8" r="1.6" fill="#B8FFB0" opacity=".8"/><circle cx="31" cy="3" r="1.1" fill="#B8FFB0" opacity=".6"/>`};

/* ---- the furniture and the people, placed on top of what's already there ---- */
{const _hp=hollowPlace;hollowPlace=function(){_hp();if(!inHollow())return;
  const add=(x,y,use)=>{const o={x,y,use};EXP.objs.push(o);return o},ob=(k,x,y,svg,w,h,cls)=>lntEl("mapobj hmx hmx-"+k+(cls?" "+cls:""),x,y,lntSvg(svg),w,h);
  ob("bell",...HMX.bell,HMX_SVG.bell);add(...HMX.bell,hmBell);
  ob("ledger",...HMX.ledger,HMX_SVG.ledger);add(...HMX.ledger,hmLedger);
  ob("barrel",...HMX.barrel,HMX_SVG.barrel);add(...HMX.barrel,hmBarrel);
  ob("chalk",...HMX.chalk,HMX_SVG.chalk);add(...HMX.chalk,hmChalk);
  ob("bog",...HMX.bog,HMX_SVG.bog);add(...HMX.bog,hmBogEdge);
  if(hmBG()===1){EXP.hmWatcher=lntEl("mapobj hmx hmx-watch",HMX.gate[0]+1.06,-.2,shadeSVG({t:"slender"}),.88,2.2);add(HMX.gate[0]+1,1,hmGate)}else EXP.hmWatcher=null;
  EXP.hmGateEl=ob("gate",...HMX.gate,HMX_SVG.gate(hmBG()===2));add(...HMX.gate,hmGate);
  HMX.burn.forEach(([x,y])=>add(x,y,hmBurn));
  /* the worn stone, the bonfire and the well now do more than they used to */
  EXP.objs.forEach(o=>{if(o.x===HMX.grave[0]&&o.y===HMX.grave[1])o.use=hmGrave;if(o.x>=16&&o.x<=18&&o.y>=11&&o.y<=12)o.use=hmChestnuts});
  const P=(look,n,at,t)=>{const o=storyNPC({n,look,talks:[["..."]]},at);o.quest=()=>t(o);return o};
  P({coat:"#3A2A3A",hair:"#E8E4DA",hs:"bun",acc:["scarf"],scarf:"#8A3A4A",skin:"#E8C0A0"},"Old Morag",HMX.morag,hmMorag);
  P({coat:"#2A3A2A",hair:"#5A4A3A",hs:"short",acc:["badge","mustache"],skin:"#E8B898"},"Councillor Bede Hask",HMX.judge,hmJudge);
  P({coat:"#6A3A22",hair:"#C86A2A",hs:"long",acc:["apron"],skin:"#F2C7A5"},"Bel Ormerod",HMX.bel,hmBel);
  lntNight()}}

/* ---- extra pools of light on the night sheet ---- */
function hmXLights(){const L=[];if(hmBG()===2)L.push([HMX.gate[0]+1,HMX.gate[1]+.4,1.6,"rgba(255,220,160,1)"]);L.push([HMX.morag[0]-1,HMX.morag[1],1.4,"rgba(255,200,130,.85)"]);return L}

/* ---- a small shared game box (same look as the fair's) ---- */
function hmGame(cls,title,msg,done){EXP.busy=true;let box=$("#lnt-mg");if(box)box.remove();box=document.createElement("div");box.id="lnt-mg";box.className="lnt-mg hmg "+cls;document.body.appendChild(box);
  box.innerHTML=`<div class="lnt-mg-card"><h3>${title}</h3><p class="lnt-mg-msg" id="mg-msg">${msg}</p><div class="lnt-mg-play" id="mg-play"></div><div class="lnt-mg-bar" id="mg-bar"></div><button class="btn" id="mg-quit">WALK AWAY</button></div>`;
  const G={box,play:box.querySelector("#mg-play"),over:false,
    msg:t=>box.querySelector("#mg-msg").textContent=t,bar:t=>box.querySelector("#mg-bar").textContent=t,
    end:w=>{if(G.over)return;G.over=true;cancelAnimationFrame(G.raf);clearInterval(G.iv);(G.timers||[]).forEach(clearTimeout);if(G.key)document.removeEventListener("keydown",G.key);if(G.keyup)document.removeEventListener("keyup",G.keyup);
      setTimeout(()=>{box.remove();EXP.busy=false;done(w)},w?900:700)},
    loop:f=>{let last=performance.now();const t=n=>{if(G.over)return;const dt=Math.min(.05,(n-last)/1000);last=n;f(dt,n);G.raf=requestAnimationFrame(t)};G.raf=requestAnimationFrame(t)},
    later:(f,ms)=>{(G.timers=G.timers||[]).push(setTimeout(()=>{if(!G.over)f()},ms))},
    keys:(down,up)=>{G.key=down;document.addEventListener("keydown",down);if(up){G.keyup=up;document.addEventListener("keyup",up)}}};
  box.querySelector("#mg-quit").onclick=()=>G.end(false);return G}
/* one shape for every prize: first win flagged, every win after gets another of the same */
function hmWin(k,who,name,first,again){const got=lntGot(name);if(gate("lntok",500))sfx("pickup");
  if(!got&&!lntF("w_"+k)){lntSet("w_"+k,1);talk(who,[].concat(first),()=>hmPrize(name));return}
  talk(who,[].concat(again||"Well done! There's always another one off the same lot. Here."),()=>hmPrize(name))}

/* =============== 1. THE WORN STONE: a grave rubbing =============== */
function hmGrave(){if(DLG.open)return;
  talk("",hmFrags().includes("grave")?["The worn stone. You've a rubbing of it already, but the paper and charcoal are still tucked behind it if you want another."]
   :["The stone's so worn you can only read one word of it: LANTERNS.","Somebody has tucked a roll of paper and a stick of charcoal behind it, out of the wet. A rubbing might bring up more than your eyes can."],
   ()=>hmGame("rub","GRAVE RUBBING","Rub the charcoal over the paper and bring the letters up. Be quick, before the wind takes the paper.",w=>{
     if(!w){talk("",["The wind gets under the paper and it's off across the kirkyard. There's another roll behind the stone."]);return}
     const first=hmFrag("grave");talk("",["The letters come up white out of the charcoal:","'J.H. · KEEPER OF THE LANTERNS · HE WENT BACK UP FOR THE LAST ONE.'","No dates. And underneath, much smaller, as if added later by somebody else: 'NOT HERE.'"],
       ()=>hmWin("rub","",hmA("Lychmark").name,["Something fell out of the back of the paper as you rolled it up. It's warm."],["Something has come off on the paper again. It's warm."]))}))}
/* the games themselves start from here, so each one's setup sits next to its prize */
const HMG={};
HMG.rub=G=>{G.play.innerHTML=`<div class="rb-stone"><div class="rb-words"><b>J.H.</b><span>KEEPER OF THE LANTERNS</span><span>HE WENT BACK UP</span><span>FOR THE LAST ONE</span><i>NOT HERE</i></div><canvas class="rb-paper" width="320" height="200"></canvas></div>`;
  const cv=G.play.querySelector("canvas"),cx=cv.getContext("2d",{willReadFrequently:true});cx.fillStyle="#F2EEE0";cx.fillRect(0,0,320,200);cx.globalCompositeOperation="destination-out";
  let t=15,down=false,lx=0,ly=0;const pos=e=>{const r=cv.getBoundingClientRect(),p=e.touches?e.touches[0]:e;return[(p.clientX-r.left)*320/r.width,(p.clientY-r.top)*200/r.height]};
  const rub=(x,y)=>{cx.lineCap="round";cx.lineWidth=26;cx.strokeStyle="rgba(0,0,0,.55)";cx.beginPath();cx.moveTo(lx,ly);cx.lineTo(x,y);cx.stroke();lx=x;ly=y};
  cv.onpointerdown=e=>{down=true;[lx,ly]=pos(e);rub(lx,ly);cv.setPointerCapture(e.pointerId)};cv.onpointermove=e=>{if(down){const[x,y]=pos(e);rub(x,y)}};cv.onpointerup=cv.onpointercancel=()=>down=false;
  const done=()=>{const d=cx.getImageData(0,0,320,200).data;let n=0,c=0;for(let y=8;y<200;y+=12)for(let x=8;x<320;x+=12){c++;if(d[(y*320+x)*4+3]<90)n++}return n/c};
  G.iv=setInterval(()=>{t-=.25;const f=done();G.bar(`REVEALED ${Math.round(f*100)}% · WIND IN ${Math.max(0,Math.ceil(t))}s`);if(f>=.8){G.msg("That's it. Every letter's up.");G.end(true)}else if(t<=0){G.msg("A gust! The paper's off across the kirkyard.");G.end(false)}},250)};

/* =============== 2. THE BONFIRE: chestnuts on the shovel =============== */
function hmChestnuts(){if(DLG.open)return;
  talk("",["The Lantern Night bonfire. It's taller than a house, and it smells of toffee and wet leaves.","There's a long-handled shovel of chestnuts propped at the edge of the heat, and a chalked board: TAKE THEM OFF WHEN THEY SPLIT. NOT BEFORE. NOT AFTER."],
   ()=>hmGame("chest","CHESTNUTS ON THE SHOVEL","Each chestnut splits when it's done. Flick it off the shovel then: too soon it's raw, too late it's charcoal. Six good ones out of eight.",w=>{
     if(!w){talk("",["A shovel of charcoal and two raw ones. The board seems to be looking at you. You fill the shovel again."]);return}
     hmWin("chest","",hmA("Roastling").name,["Six perfect chestnuts. You count them off the shovel, and there are seven. The seventh didn't crack when it popped."],["You count them off again. One too many, again."])}))}
HMG.chest=G=>{G.play.innerHTML=`<div class="cn-shovel">${Array.from({length:8},(_,i)=>`<button class="cn-nut" data-i="${i}"><i></i></button>`).join("")}</div>`;
  const N=[...G.play.querySelectorAll(".cn-nut")].map((e,i)=>({e,t0:.8+i*.9+Math.random()*1.4,cook:2.2+Math.random()*1.6,win:1.25,st:"raw",t:0}));let good=0,bad=0,T=0;
  const bar=()=>G.bar(`GOOD ${good}/6 · SPOILT ${bad} (THREE AND IT'S OVER)`);bar();
  const set=(n,s)=>{n.st=s;n.e.className="cn-nut "+s};
  const check=()=>{if(good>=6){G.msg("Six good ones!");G.end(true)}else if(bad>=3){G.msg("That's three spoilt. Start again.");G.end(false)}else if(N.every(n=>n.st==="off"||n.st==="burnt"||n.st==="raw-off")&&good<6){G.msg("The shovel's empty.");G.end(false)}};
  N.forEach(n=>n.e.onclick=()=>{if(n.st==="ready"){set(n,"off");good++;if(gate("cnok",150))sfx("pickup");G.msg("Off it comes, split and steaming.")}
    else if(n.st==="raw"||n.st==="heat"){set(n,"raw-off");bad++;if(gate("cnno",150))sfx("miss");G.msg("Too soon! It's raw.")}bar();check()});
  G.loop(dt=>{T+=dt;N.forEach(n=>{if(n.st==="raw"&&T>n.t0)set(n,"heat");if(n.st==="heat"&&T>n.t0+n.cook){set(n,"ready")}if(n.st==="ready"&&T>n.t0+n.cook+n.win){set(n,"burnt");bad++;bar();G.msg("Too late! That one's charcoal.");check()}})})};

/* =============== 3. THE WELL: haul up what glints =============== */
function hmWell(){if(DLG.open)return;
  talk("",["The village well. A bucket on a chain, and a long way down, a little round piece of night sky.","Down in the water, something glints, and moves, and glints again."],
   ()=>hmGame("well","THE WELL BUCKET","The bucket goes down on its own. HAUL when it's level with the glint. Three things up before five hauls.",w=>{
     if(!w){talk("",["Five buckets of cold water and nothing in them. Your arms ache. The glint is still down there."]);return}
     const first=!hmFrags().includes("chimney");
     const go=()=>hmWin("well","",hmA("Wellwisher").name,["The third bucket comes up with something sitting in it, quite calmly, as if it had been waiting for a lift."],["The bucket comes up with another passenger."]);
     if(first){hmFrag("chimney");talk("",["The second bucket brought up a lamp chimney, the glass kind, black with old soot.","Near the base, somebody has scratched: 'for A., so you can see me coming.'"],go)}else go()}))}
HMG.well=G=>{G.play.innerHTML=`<div class="wl-shaft"><div class="wl-water"></div><i class="wl-glint"></i><div class="wl-chain"></div><div class="wl-bucket"></div></div><button class="btn go" id="wl-go">HAUL!</button>`;
  const sh=G.play.querySelector(".wl-shaft"),gl=sh.querySelector(".wl-glint"),bk=sh.querySelector(".wl-bucket"),ch=sh.querySelector(".wl-chain");let b=0,v=.3,g=.6,gp=0,got=0,tries=5,haul=false;
  const bar=()=>G.bar(`UP ${got}/3 · HAULS LEFT ${tries}`);bar();
  G.loop(dt=>{gp+=dt*(1+got*.4);g=.55+Math.sin(gp*1.3)*.3+Math.sin(gp*.47)*.08;gl.style.top=(g*100)+"%";if(!haul){b+=v*dt*(1+got*.25);if(b>1){b=0}}const y=(b*100).toFixed(1)+"%";bk.style.top=y;ch.style.height=y});
  const go=()=>{if(haul||tries<=0||got>=3)return;haul=true;tries--;const hit=Math.abs(b-g)<.07;if(gate("wl",200))sfx(hit?"pickup":"miss");
    G.msg(hit?(got===1&&!hmFrags().includes("chimney")?"Something heavy! You haul it up hand over hand.":"Got it! Up it comes, dripping."):"Nothing but cold water.");if(hit)got++;bar();
    G.later(()=>{haul=false;b=0;if(got>=3)G.end(true);else if(tries<=0)G.end(false)},600)};
  G.play.querySelector("#wl-go").onclick=go;G.keys(e=>{if(e.key===" "||e.key==="Enter"){e.preventDefault();go()}})};

/* =============== 4. THE KIRKYARD BELL =============== */
function hmBell(){if(DLG.open)return;
  talk("",["A bell on a wooden frame, at the corner of the kirkyard. The rope's sally is worn smooth at a height that would suit a tall man.","A card pinned to the frame: 'DUSK PEAL. PULL AT THE BALANCE, WHERE IT HANGS STILL AT THE TOP. NOT IN THE MIDDLE OF THE SWING. — The Sexton.'"],
   ()=>hmGame("bell","THE DUSK PEAL","Pull when the bell is right at the top of its swing, where it hangs still for a moment. Eight good pulls. Three bad ones and it clangs.",w=>{
     if(!w){talk("Sexton Pyke",["(From across the kirkyard.) That's not a peal, that's a cutlery drawer falling down the stairs. Try again."]);return}
     hmWin("bell","Sexton Pyke",hmA("Changeringer").name,["(The sexton comes over, slowly.) Now that was a peal. You've the knack.","Something shook loose out of the bell when you rang it. It does that, for the good ringers. Here."],["Another fine peal. And another something out of the bell."])}))}
HMG.bell=G=>{G.play.innerHTML=`<div class="bl-frame"><div class="bl-bell"><svg viewBox="0 0 80 80"><path d="M26 8 Q24 34 14 46 H66 Q56 34 54 8 Q40 0 26 8 Z" fill="#C8A060" stroke="#2A1A0A" stroke-width="3"/><path d="M14 46 Q40 54 66 46" stroke="#2A1A0A" stroke-width="3" fill="none"/><circle cx="40" cy="52" r="5" fill="#5A4A3A"/><path d="M32 12 Q30 30 26 40" stroke="#F4E0A8" stroke-width="3" fill="none"/></svg></div><i class="bl-zone l"></i><i class="bl-zone r"></i></div><button class="btn go" id="bl-go">PULL!</button>`;
  const bl=G.play.querySelector(".bl-bell");let ph=0,w=2.2,good=0,bad=0,lock=false;const A=58;
  const bar=()=>G.bar(`GOOD PULLS ${good}/8 · BAD ${bad}/3`);bar();
  G.loop(dt=>{ph+=dt*w;bl.style.transform=`rotate(${(Math.sin(ph)*A).toFixed(1)}deg)`});
  const go=()=>{if(lock)return;lock=true;G.later(()=>lock=false,220);const s=Math.abs(Math.sin(ph));if(s>.9){good++;w+=.18;if(gate("blok",150))sfx("right");G.msg(["DONG.","Right at the balance!","Lovely. It sings."][good%3])}else{bad++;if(gate("blno",150))sfx("miss");G.msg("CLANK. Middle of the swing.")}
    bar();if(good>=8)G.end(true);else if(bad>=3)G.end(false)};
  G.play.querySelector("#bl-go").onclick=go;G.keys(e=>{if(e.key===" "||e.key==="Enter"){e.preventDefault();go()}})};

/* =============== 5. THE COSTUME JUDGING =============== */
const HM_THEMES=[{t:"Something from the kirkyard",ok:"sheet",yes:"A ghost! Proper old-fashioned. The sheet's even got a darn in it. That's the spirit."},
 {t:"Something from the top field",ok:"bogle",yes:"A tattie bogle! Straw out the sleeves and everything. The crows will be beside themselves."},
 {t:"Something with a light in it",ok:"neep",yes:"A neep-head, lit! Can you see anything in there? No? Perfect. That's the true Hollowmere look."}];
function hmJudge(p){const i=(lntF("theme")||0)%HM_THEMES.length,T=HM_THEMES[i],c=lntCos();
  if(!lntF("jmet")){lntSet("jmet",1);talk(p.n,["Councillor Hask, chair of the Lantern Night judging. Best costume on the green wins the rosette.","There's a theme, and it changes. Tonight's is: "+T.t.toUpperCase()+".","And there's one rule we've never broken since 1890, so don't you be the first: nobody comes dressed as a lamplighter. Don't ask me why. Nobody knows. Nobody's going to change it.","Come back in costume and I'll judge you."]);return}
  if(!c){talk(p.n,["No costume, no judging. Tonight's theme is "+T.t.toLowerCase()+". The trunk's on the green."]);return}
  if(c!==T.ok){if(gate("lntno",500))sfx("miss");talk(p.n,[`A ${COSTUMES[c].name}. Very nice. But tonight's theme is ${T.t.toLowerCase()}.`,"Off you go and have a rethink. The trunk's not going anywhere."]);return}
  lntSet("theme",i+1);talk(p.n,[T.yes,"Best on the green! The rosette is yours. And the theme changes, so come back and try for it again."],()=>hmWin("contest",p.n,hmA("Rosettine").name,["Hold still while I pin it on. Oh! The pin's come off in my hand. Wait, that's not a pin."],["Pinned on again! And the pin's come off again. Some things are traditions."]))}

/* =============== 6. THE CIDER YARD: one long peel =============== */
function hmBarrel(){if(DLG.open)return;
  talk("",["A barrel of apples in the cider yard, with a paring knife on a string and a slate: 'PEEL ONE IN ONE LONG STRIP. THROW IT OVER YOUR SHOULDER. SEE WHO YOU'LL MARRY.'"],
   ()=>hmGame("peel","ONE LONG PEEL","Hold PEEL to turn the apple. Press too hard and the peel snaps; let go and it stops. Keep the knife in the band until the whole apple's peeled.",w=>{
     if(!w){talk("",["Snap. The peel drops in a little curl on the cobbles. Bel Ormerod tuts and hands you another apple."]);return}
     const first=hmFrag("peel");
     talk("",["One long unbroken strip! You throw it over your shoulder, and it lands on the cobbles in an A.","You try another. An A."],()=>talk("Bel Ormerod",first?["Don't look so surprised. It's always an A. Every year, everybody's.","Long before my time. My mam's, and hers. Nobody's ever married anyone with an A. I think it's somebody else's letter."]:["An A again? Course it is."],
       ()=>hmWin("peel","Bel Ormerod",hmA("Longpeel").name,["And look, there's something curled up in the peel. Go on, it's yours."],["Something curled up in that one too."])))}))}
HMG.peel=G=>{G.play.innerHTML=`<div class="pl-wrap"><svg viewBox="0 0 120 120" class="pl-apple"><circle cx="60" cy="64" r="40" fill="#F4ECC0" stroke="#2A1A0A" stroke-width="3"/><path id="pl-skin" d="M60 44 A20 20 0 1 1 59.9 44" fill="none" stroke="#C83A2A" stroke-width="40" stroke-dasharray="252 252" stroke-dashoffset="0" opacity=".9" transform="rotate(-90 60 64)" pathLength="252"/><circle cx="60" cy="64" r="40" fill="none" stroke="#2A1A0A" stroke-width="3"/><path d="M60 24 Q58 14 64 10" stroke="#5A3A1A" stroke-width="4" fill="none"/></svg>
  <div class="pl-gauge"><i class="pl-band"></i><i class="pl-needle"></i></div></div><button class="btn go" id="pl-go">HOLD TO PEEL</button>`;
  const sk=G.play.querySelector("#pl-skin"),band=G.play.querySelector(".pl-band"),nd=G.play.querySelector(".pl-needle"),btn=G.play.querySelector("#pl-go");let p=.2,hold=false,prog=0,bc=.5,bp=0,nz=0;
  const bar=()=>G.bar(`PEELED ${Math.round(prog*100)}%`);bar();
  G.loop(dt=>{bp+=dt;bc=.5+Math.sin(bp*.9)*.17;nz+=(Math.random()-.5)*dt*3;nz*=.96;p+=(hold?.55:-.6)*dt+nz*dt;p=Math.max(0,Math.min(1,p));
    const inB=Math.abs(p-bc)<.13;if(hold&&inB)prog+=dt/6;band.style.left=((bc-.13)*100)+"%";nd.style.left=(p*100)+"%";nd.classList.toggle("ok",inB);sk.setAttribute("stroke-dashoffset",(prog*252).toFixed(1));bar();
    if(p>=.97){G.msg("SNAP! Too hard.");G.end(false)}else if(prog>=1){G.msg("All in one piece!");G.end(true)}});
  const on=e=>{e&&e.preventDefault&&e.preventDefault();hold=true},off=()=>hold=false;btn.onpointerdown=on;btn.onpointerup=btn.onpointerleave=btn.onpointercancel=off;
  G.keys(e=>{if(e.key===" "||e.key==="Enter"){e.preventDefault();hold=true}},e=>{if(e.key===" "||e.key==="Enter")hold=false})};
function hmBel(p){talk(p.n,hmFrags().includes("peel")?["Peeled your A yet? Everybody gets one. Ask Morag by the fire whose it is and she'll tell you a different story every time."]
  :["Bel Ormerod. The cider yard's mine, the apples are the village's. Peel one in one go and throw it, it's tradition.","The barrel's just there. Mind the knife, it's sharper than it looks, and it looks very sharp."])}

/* =============== 7. STORIES BY THE FIRE =============== */
const HM_STORIES=[
 {t:"The Lamplighter's Round",L:["This one's old. My granny had it off hers.","Hollowmere had a man for the lamps, once. Thirty-one lamps, every dusk, up one side of the village and down the other, and the last one up at the bog gate, because that's where folk come down off the moor in the dark.",
   "Now, the gate lamp would never stay lit. Every night he lit it, and every night something put it out, so every night he went back up and lit it again.","One Lantern Night the lights were dancing out on the bog, and a little one followed them. He saw her go off the path, and he went up after her with his lamp.","She came down in the morning, wet to the knees. He didn't.","And he's out there still."],
  Q:[["How many lamps did he light every dusk?",["31","thirty one","thirty-one","thirtyone"]],["Which lamp would never stay lit?",["gate","bog"]],["Who came down off the moor in the morning?",["little","girl","she","her","child","daughter","ada","kid","one"]]]},
 {t:"The Penny On The Post",L:["Children used to leave a penny on the bog gatepost on Lantern Night. 'For the lamp oil,' they said. Their mams told them to say it.","Gone by morning, every one. And never a footprint in the frost round that post but the children's own.",
   "Then the old lady at the end cottage died, and nobody took a lamp up to the gate, and the children stopped leaving pennies. That was the year the shadows started coming down into the village.","Make of that what you like. He's out there still."],
  Q:[["What did the children leave on the gatepost?",["penny","pennies","coin","money"]],["What did they say it was for?",["oil","lamp"]],["What came down into the village the year it all stopped?",["shadow","shadows"]]]},
 {t:"Masks Down",L:["Why do Hollowmere guisers wear masks? You'll think it's for the fun of it. It isn't.","Something goes along the lanes on Lantern Night looking into faces. One face, it's after. It's not cruel. It's only looking.",
   "But if it finds a face that's nearly right, it stops. And it looks closer. And it doesn't like to stop looking, once it's started.","So you wear your mask, and you keep it down, and it goes on past you to the next. And he's out there still."],
  Q:[["What do Hollowmere guisers wear?",["mask","masks","costume","disguise"]],["What is the thing on the lanes looking into?",["face","faces"]],["What does it do when it finds a face that's nearly right?",["stop","stops","look","looks","closer","stare"]]]}];
function hmMorag(p){if(DLG.open)return;const i=(lntF("story")||0)%HM_STORIES.length,S0=HM_STORIES[i];
  talk(p.n,[lntF("mmet")?"Back for another? Sit down, then. This one's called "+S0.t.toUpperCase()+".":"Sit by the fire, pet. I tell the stories on Lantern Night. Listen properly, mind: I'll be asking you about it after. This one's called "+S0.t.toUpperCase()+".",...S0.L],()=>{
    lntSet("mmet",1);hmFrag("story");let right=0,q=0;
    const ask=()=>{if(q>=S0.Q.length){lntSet("story",i+1);if(right>=2)hmWin("story",p.n,hmA("Hearthtale").name,["You were listening! Good. Here, this came out of the fire at the end of the last story, same as it always does. Take it."],["Listening again! Here's another out of the fire."]);else{if(gate("lntno",500))sfx("miss");talk(p.n,[`${right} out of three. You were looking at the fire, weren't you. Come back and I'll tell you another.`])}return}
      const[qq,ok]=S0.Q[q];talk(p.n,[qq],null,ans=>{const n=lntNorm(ans);const hit=ok.some(w=>n.split(" ").includes(w)||n===w||n.includes(w));if(hit)right++;q++;talk(p.n,[hit?["That's it.","Good.","Mm-hm."][q%3]:["No...","Not quite.","Hm. No."][q%3]],ask)})};ask()})}

/* =============== 8. THE LANTERN FLOAT, on the burn =============== */
function hmBurn(){if(DLG.open)return;
  talk("",["The burn runs out under the hedge and away up towards the bog. A stack of paper lanterns sits on the bank, each one with a little card: 'FOR WHOEVER IS STILL OUT THERE.'","Steer it past the stones and it'll float all the way."],
   ()=>hmGame("float","THE LANTERN FLOAT","Steer your paper lantern down the burn with ◀ ▶. Stones put it out: three and it's gone. Get it all the way to the bog.",w=>{
     if(!w){talk("",["The lantern catches on a stone, tips, and goes out with a hiss. There are more on the bank."]);return}
     hmWin("float","",hmA("Driftlight").name,["Your lantern floats out past the hedge, small and steady, all the way to the bog.","A minute later, something comes back down the burn against the current, still glowing, and bumps against your boots."],["Out to the bog it goes, and back down the burn comes something else."])}))}
HMG.float=G=>{G.play.innerHTML=`<div class="fl-burn"><i class="fl-bank l"></i><i class="fl-bank r"></i><div class="fl-lan"></div></div><div class="fl-btns"><button class="btn" id="fl-l">◀</button><button class="btn" id="fl-r">▶</button></div>`;
  const B=G.play.querySelector(".fl-burn"),L=B.querySelector(".fl-lan");let lane=1,hits=0,T=0,next=.6,R=[];const DUR=22;
  const bar=()=>G.bar(`DISTANCE ${Math.min(100,Math.round(T/DUR*100))}% · STONES HIT ${hits}/3`);bar();
  const mv=d=>{lane=Math.max(0,Math.min(2,lane+d));L.style.left=(lane*33.3+16.6)+"%"};mv(0);
  G.play.querySelector("#fl-l").onclick=()=>mv(-1);G.play.querySelector("#fl-r").onclick=()=>mv(1);
  G.keys(e=>{if(e.key==="ArrowLeft"||e.key==="a"){e.preventDefault();mv(-1)}if(e.key==="ArrowRight"||e.key==="d"){e.preventDefault();mv(1)}});
  G.loop(dt=>{T+=dt;next-=dt;const sp=.42+T*.012;
    if(next<=0&&T<DUR-1.5){const free=Math.random()*3|0,ln=[0,1,2].filter(k=>k!==free),n=Math.random()<.35?2:1;ln.sort(()=>Math.random()-.5).slice(0,n).forEach(k=>{const e=document.createElement("i");e.className="fl-rock";e.style.left=(k*33.3+16.6)+"%";B.appendChild(e);R.push({e,k,y:-.1})});next=Math.max(.55,1.1-T*.025)}
    R.forEach(r=>{r.y+=sp*dt;r.e.style.top=(r.y*100)+"%";if(!r.hit&&r.y>.74&&r.y<.88&&r.k===lane){r.hit=1;hits++;L.classList.remove("bump");void L.offsetWidth;L.classList.add("bump");if(gate("flh",200))sfx("miss");G.msg(hits>=3?"It's out.":"Bump! The flame gutters.")}});
    R=R.filter(r=>{if(r.y>1.1){r.e.remove();return false}return true});bar();
    if(hits>=3)G.end(false);else if(T>=DUR){G.msg("Out past the hedge and away to the bog!");G.end(true)}})};

/* =============== 9. THE LIGHTS ON THE BOG =============== */
function hmBogEdge(){if(DLG.open)return;
  talk("",["A gap in the dyke where you can see out over Hollowmere bog. Out in the dark, small lights are moving: drifting, dipping, flaring, going out and coming back.","There's an old saying carved into the dyke stone, half under moss: 'FOLLOW NONE THAT DANCE.'"],
   ()=>hmGame("bog","THE LIGHTS ON THE BOG","Most of the lights out there flicker and dance. One burns perfectly steady. When they come back after going dark, pick the steady one. Three times. One mistake allowed.",w=>{
     if(!w){talk("",["The light you chose gutters and dances off, laughing, if a light can laugh. You decide to stay this side of the dyke."]);return}
     hmWin("bog","",hmA("Steadyflame").name,["You watch the steady light. It doesn't dance. It just waits, the way a lamp on a hook waits.","When you look down, there's a jar at your feet that wasn't there before, and something in it is glowing, perfectly still."],["The steady light again. And another jar at your feet."])}))}
HMG.bog=G=>{G.play.innerHTML=`<div class="bg-bog"></div>`;const box=G.play.querySelector(".bg-bog");let round=0,miss=0,lights=[],ready=false;
  const bar=()=>G.bar(`ROUND ${Math.min(round+1,3)}/3 · MISTAKES ${miss}/1`);bar();
  const deal=()=>{ready=false;box.innerHTML="";const n=5+round,tr=Math.random()*n|0;lights=[];
    for(let i=0;i<n;i++){const e=document.createElement("button");e.className="bg-l"+(i===tr?" true":" fake");e.style.setProperty("--fd",(.35+Math.random()*.5-round*.06).toFixed(2)+"s");e.style.setProperty("--fo",(.25+round*.15).toFixed(2));
      const o={e,x:.1+Math.random()*.8,y:.15+Math.random()*.7,ph:Math.random()*6,tr:i===tr};box.appendChild(e);lights.push(o);e.onclick=()=>pick(o)}
    G.msg("They're going dark...");box.classList.add("dark");G.later(()=>{box.classList.remove("dark");ready=true;G.msg("Which one is steady?")},900)};
  const pick=o=>{if(!ready)return;ready=false;if(o.tr){round++;if(gate("bgok",200))sfx("right");G.msg("That's the one. It doesn't move a hair.")}else{miss++;if(gate("bgno",200))sfx("miss");G.msg("That one dances off, laughing.");lights.find(q=>q.tr).e.classList.add("show")}
    bar();if(round>=3)G.end(true);else if(miss>1)G.end(false);else G.later(deal,1100)};
  G.loop(dt=>lights.forEach(o=>{o.ph+=dt*(o.tr?.5:.9);o.e.style.left=((o.x+Math.sin(o.ph)*.05)*100).toFixed(1)+"%";o.e.style.top=((o.y+Math.cos(o.ph*1.3)*.05)*100).toFixed(1)+"%"}));deal()};

/* wire the game builders into hmGame: each game box picks its builder by its class */
{const _g=hmGame;hmGame=function(cls,title,msg,done){const G=_g(cls,title,msg,done);if(HMG[cls])HMG[cls](G);return G}}

/* =============== THE STORY'S OTHER SCRAPS =============== */
function hmLedger(){if(DLG.open)return;const first=hmFrag("ledger");
  talk("",first?["A crate with a book on it, swollen with damp. A lamplighter's round book.","Thirty-one lamps a night, ticked off in a neat hand, for years. Every Lantern Night the same line: 'Bog gate lamp out again. Relit.'","The last entry is Lantern Night, 1889: 'All lit but the gate. Going back up for it.' The rest of the book is empty."]
   :["The lamplighter's round book. 'All lit but the gate. Going back up for it.' The rest of the pages are empty."])}
function hmChalk(){if(DLG.open)return;const first=hmFrag("chalk");
  talk("",first?["Chalk on the end wall of the last cottage, so old it's gone into the stone. Nobody's ever scrubbed it off.","A tall stick figure with a lamp on a pole, holding a little one by the hand. Underneath, in a child's capitals, one word with its end rubbed away: 'DA'."]
   :["The old chalk drawing: the tall one with the lamp, the little one holding on. 'DA'."])}
function hmGate(){if(DLG.open)return;const st=hmBG();
  if(st===1){if(gate("lntgw",800))sfx("alert");
    talk("",["The bog gate. Beyond it there's nothing but dark and the smell of peat. And somebody is standing beside the gate, between you and the bog.","It's very tall and very still, the way the shadows stand. It doesn't come closer. It doesn't go. Its head is turned towards the hook on the gatepost, where there's no lamp.",
      "You light Ada's lamp and hang it on the hook, and tie her last tag on the top bar under it: HOME SAFE. A.","For a long time nothing happens. Then the tall shape bends, slowly, the way you'd bend to read something small.",
      "It stays like that a long while. Then it straightens, steps through the gate as if it wasn't there, and there's only fog where it was, and the frost on the top bar is running off the wood in drops.","In the morning there's something hanging on the hook beside the lamp."],
      ()=>{lntSet("bg",2);if(EXP.hmWatcher){EXP.hmWatcher.remove();EXP.hmWatcher=null}if(EXP.hmGateEl)EXP.hmGateEl.innerHTML=lntSvg(HMX_SVG.gate(true));lntNight();
        storyFight(hmA("Homeward").name,{intro:"It slips off the hook and away up the path towards home. Identify it before it's gone!"})});return}
  if(st===2){const again=!EXP.hmGateDone;EXP.hmGateDone=1;
    talk("",["The lamp on the bog gate is still burning. The tag has gone from the bar, string and all.",again?"There's something hanging on the hook again.":"Nothing on the hook tonight. Maybe tomorrow."],again?()=>storyFight(hmA("Homeward").name,{intro:"It slips off the hook and away up the path towards home. Identify it before it's gone!"}):null);return}
  const first=hmFrag("tags");
  talk("",first?["The bog gate, at the top of the moor. Beyond it there's nothing but dark and the smell of peat.","There's an iron hook on the gatepost, worn smooth, with nothing hanging on it. Under the hook, the wood is worn into a hollow about the size of a hand.","Along the top bar, dozens of little card tags are tied on with string, years and years of them, faded past reading. The newest still says 'HOME. A.' It's dated 1970.","There are none after that."]
   :["The bog gate. The empty hook, the hollow in the wood, and the old tags along the bar. 'HOME. A.' 1970. None after."])}
/* the sexton has the parish book, once you've a rubbing of the stone */
{const _s=lntSextonTalk;lntSextonTalk=function(p){const f=hmFrags();
  if(f.includes("grave")&&!f.includes("register")){hmFrag("register");
    talk(p.n,["You've a rubbing of the old worn stone? Let me see that.","(He reads it twice, then goes into the vestry and comes back with a book as big as a gravestone.)","The parish book. My predecessor's predecessor wrote this. First of November, 1889:",
      "'Ada H., aged seven, came down off the moor at first light, wet to the waist, unharmed. Says a man with a lamp walked her as far as the gate and would not come through it. Search for J.H. called off on the 9th.'","(He shuts the book.) There's nobody under that stone, you know. There never was. We just thought he ought to have one."]);return}
  if(hmBG()===2){talk(p.n,["Somebody took a lamp up to the bog gate. First time since Ada. I could see it from the vestry window all night.","Kept me up, watching it. In a good way. I think it's the quietest Lantern Night I've known."]);return}
  if(f.length>=6&&hmBG()===0&&!lntF("sx6")){lntSet("sx6",1);talk(p.n,["You've been asking all round the village. Folk have noticed. They don't mind.","Granny Moffat, along the lane. She was a girl when the old lady at the end cottage was still alive. If anybody's been waiting for somebody to ask, it's her."]);return}
  _s(p)}}
/* Dr. Marlow found something in the Institute's papers */
{const _m=lntMarlowTalk;lntMarlowTalk=function(m){const f=hmFrags();
  if(lntF("hm")&&!lntF("more")){lntSet("more",1);talk(m.n,["Recruit! There's more going on in Hollowmere this year than I've ever seen.","The sexton's put the old bell back up, there's a costume judging on the green, Bel Ormerod has her cider yard open, Old Morag's telling stories by the fire, and somebody's floating lanterns down the burn.","Try your hand at all of it. Everything in this village has a prize, if you're good enough."]);return}
  if(f.length>=3&&!f.includes("marlow")){hmFrag("marlow");
    talk(m.n,["Recruit. Wren tells me you've been reading gravestones. I went through the Institute's papers for Hollowmere, out of curiosity.","There was a survey party up on the moor in 1889, on Lantern Night of all nights. One field note, in pencil:",
      "'A single lamp moving along the bog edge in the small hours, against the wind. Stopping, starting. Assumed a search party. There was no search party out until morning.'","(He folds the note away.) Science has nothing to say about that. I just thought you'd want to know."]);return}
  _m(m)}}
/* Granny Moffat has been waiting for somebody to ask */
{const _g=lntGuise;lntGuise=function(i){if(i===1&&hmFrags().length>=6&&hmBG()===0){
    talk("Granny Moffat",["(Granny Moffat opens the door and looks at you for a long moment, and then past you, up the lane towards the moor.)","You've been asking about the lamplighter. Don't look like that, pet. It's a very small village.",
      "When I was a girl there was an old lady at the end cottage. Ada. Every Lantern Night, she walked a lamp up to the bog gate and tied a tag on the top bar, and in the morning she'd come down and say, 'He's had it.'",
      "She made us keep our masks right down, guising. 'He's still looking,' she'd say, and she'd never say for what.","She went in the spring of '71. Nobody took the lamp up that year. Nor any year since. And Lantern Night's been a bad night ever since, hasn't it.",
      "She left me this tin. 'For when somebody asks,' she said. Fifty-odd years, and you're the first.","(Inside the tin: a little lamp, cleaned and filled, and one card tag, written but never tied. It says HOME SAFE. A.)","Take it up to the gate, pet. Somebody ought to."],
      ()=>{lntSet("bg",1);say0("Granny Moffat gave you ADA'S LAMP and a tag that says HOME SAFE. A.")});return}
  if(i===1&&hmBG()===1){talk("Granny Moffat",["Up to the bog gate with it, pet. Top of the moor. Hang the lamp on the hook."]);return}
  if(i===1&&hmBG()===2&&!lntF("gm2")){lntSet("gm2",1);talk("Granny Moffat",["I saw it from my window. The lamp on the gate.","(She's quiet for a moment.) That's that, then. Thank you, pet. Go on, do your turn, I've treats in."],()=>_g(i));return}
  _g(i)}}
/* somebody with a shadow in them, in Hollowmere, sometimes says something that isn't theirs */
{const _tt=talkTo;talkTo=function(p){if(p&&p.possessed&&inHollow()&&hmBG()<2&&Math.random()<.45){
    const L=["(It isn't their voice.) Is she home? Has anybody looked to see if she got home?","(It isn't their voice.) It's cold out. She'll be cold. Is the gate lit?","(Their head turns, slowly, and they look at your face very closely. Then away.) Not her."];
    const k=hmFrags().includes("voice")?L[Math.random()*L.length|0]:L[0];hmFrag("voice");talk(p.n,[k,"...Sorry. Where was I? I came over all cold for a second."],()=>{});return}
  _tt(p)}}
/* the well is a game now (unless the cold prints lead there tonight) */
{const _sp=lntSpot;lntSpot=function(k){if(k==="well"&&!(EXP.gwSpot==="well"&&lntF("gwOn")&&!lntGot(WW_NAME))){hmWell();return}_sp(k)}}

/* ---- the journal ---- */
{const _oj=openJournal;openJournal=function(){_oj();if(!lntOn()||!lntF("hm"))return;const m=$("#journal");if(!m)return;const list=m.querySelector(".bag-list");if(!list)return;
  const it=(t,p)=>{const d=document.createElement("div");d.className="bag-item key obj lnt-obj";d.innerHTML=`<b>${t}</b><p>${p}</p>`;return d},out=[],f=hmFrags(),st=hmBG();
  const todo=[["rub","Lychmark","a rubbing of the worn stone in the kirkyard"],["chest","Roastling","chestnuts at the bonfire"],["well","Wellwisher","the well"],["bell","Changeringer","the dusk peal on the kirkyard bell"],["contest","Rosettine","the costume judging on the green"],["peel","Longpeel","an apple peel in the cider yard"],["story","Hearthtale","Old Morag's stories by the fire"],["float","Driftlight","the lantern float on the burn"],["bog","Steadyflame","the lights on the bog"]].filter(([k,n])=>!lntGot(n));
  if(todo.length)out.push(it("LANTERN NIGHT · ABOUT THE VILLAGE",`Still a prize in: ${todo.map(t=>t[2]).join(", ")}.`));
  if(f.length)out.push(it(`LANTERN NIGHT · SCRAPS (${f.length} of ${HM_FRAG_ORDER.length})`,"Bits of an old Hollowmere story, picked up here and there:<br>"+HM_FRAG_ORDER.filter(k=>f.includes(k)).map(k=>"· "+HM_FRAGS[k]).join("<br>")));
  if(f.length>=6&&st===0)out.push(it("LANTERN NIGHT · SOMEBODY'S WAITING","Somebody along the lane has been waiting a long time for anyone to ask."));
  if(st===1)out.push(it("LANTERN NIGHT · THE BOG GATE","Take Ada's lamp and her tag, HOME SAFE. A., up to the bog gate at the top of the moor, and hang the lamp on the hook."));
  if(st===2&&!lntGot("Homeward"))out.push(it("LANTERN NIGHT · THE BOG GATE","Something was left hanging on the hook of the bog gate, beside the lamp."));
  const none=list.querySelector(".obj-none");if(none)none.remove();const kids=[...list.children],lastObj=kids.filter(e=>e.classList.contains("obj")&&!e.classList.contains("fav")).pop(),after=lastObj?lastObj.nextSibling:list.firstChild;out.forEach(e=>list.insertBefore(e,after))}}
