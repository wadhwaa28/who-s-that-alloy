/* =============== LANTERN NIGHT AT HOLLOWMERE ===============
   From 24 October to the end of 15 November, a hole into nothing opens in the floor of the Quillmoor specimen hall. Climb down it and you
   come out in Hollowmere, on the one night of the year it keeps for lanterns. That hole is the ONLY way in: Hollowmere is never on the
   zone list, so no random pick, trail marker, survey map or quest can send anybody there.
   Every map gets hand-placed decorations while it's on, and all of them do something: neeps you can light, bunting you can tug,
   bats that scatter, spiders that climb, candles you can blow out, and tattie bogles that turn to watch you go by. */
let LNT_FORCE=null;   // tests only: true or false overrides the calendar
function lntOn(){if(LNT_FORCE!=null)return LNT_FORCE;const d=new Date(),m=d.getMonth()+1,day=d.getDate();return(m===10&&day>=24)||(m===11&&day<=15)}
const LS=()=>store.get("wta_lnt",{});
function lntSet(k,v){const s=LS();s[k]=v;store.set("wta_lnt",s);store.set("wta_qf_seenJ",0);if(typeof journalDot==="function")journalDot()}
const lntF=k=>LS()[k];
const lntGot=n=>S.caught.has(n);

/* ---- Hollowmere ---- */
MAPS["z-hollow"]=[
"########################################",
"#::::::X:::,,,:::::::k::::,,,::::X:::::#",
"#:::,,,::::,,,,::t:::::::::,,,,::::::,:#",
"#::,,,,:::::::::::::::O:::::::::::::,,:#",
"#:X:,,::::::,,,:::::::::::::,,,::k:::::#",
"#::::::::k:::,,,:::::::::::::,,,:::::::#",
"##########.######.#########.############",
"#..G..G..#.......J.........#BBBBBBBBBBB#",
"#.G..G..Y#..AA...=....NN...#B,,,..,,,CB#",
"#..G...G.#..AA...=....NN...#B,,....,,,B#",
"#.G..G...#.......=.........#B...,,....B#",
"#........#..J...FFF....J...#B,,..,,,..B#",
"#.G..G..G.......FFF........#B,,,...,,.B#",
"#..G.....#.......=.........#BBBB..BBBBB#",
"#.G...G..#..MM...=....b..Q.#...........#",
"#........#..MM...=.........#..,,,..,,,.#",
"####.#####.......=.........####.########",
"#======================================#",
"#HHHHHHHH.HHHHHHHH.HHHHHHHH.HHHHHHHH.~~#",
"#HHHHHHHH.HHHHHHHH.HHHHHHHH.HHHHHHHH.~~#",
"#HHHDHHHH.HHHHDHHH.HHHDHHHH.HHHHHDHH..~#",
"#======================================#",
"#..,,,.....,,,........,,,....,,,..S.VV.#",
"#.,,,,,..T..,,,,..T..,,,,,.....T..P.VV.#",
"#..,,,..............,,,,.........,,,...#",
"########################################"];
const HOLLOW_ZONE={name:"HOLLOWMERE · LANTERN NIGHT",sub:"A moorland village on the one night of the year it keeps for lanterns. The fair's on the green, the guisers are out, and every window is lit.",cls:"z-hollow",map:MAPS["z-hollow"].slice()};
SPOTS["z-hollow"]={marlow:[19,13],wren:[30,14],dook:[14,9],shuffle:[24,9],memory:[14,15],sexton:[5,11],hole:[36,22],arrive:[34,23]};
SIGNS["z-hollow"]={"34,22":["HOLLOWMERE. Mind the hole.","Underneath, in chalk, in a child's writing: 'IT DOES NOT GO TO AUSTRALIA. WE CHECKED.'"]};
const HM_DOORS=[[4,20],[14,20],[22,20],[33,20]];
const HM_COTS=[[1,18,0],[10,18,1],[19,18,2],[28,18,3]];
const HM_SPOTS={yew:{at:[8,8],from:[7,8],n:"the old yew"},hay:{at:[33,4],from:[32,4],n:"the haystack on the hill"},tent:{at:[17,2],from:[17,3],n:"the old eclipse tent"},chair:{at:[37,8],from:[36,8],n:"the storeroom chair"},well:{at:[25,14],from:[24,14],n:"the village well"}};
const QUILL_HOLE=[24,22];
const inHollow=()=>EXP.zone&&EXP.zone.cls==="z-hollow";

/* ---- only the hole leads there ---- */
{const _gz=goZone;goZone=function(z){if(z&&z.cls==="z-hollow"&&!goZone.viaHole&&!inHollow())z=ZONES.find(q=>q.cls==="z-quill");goZone.viaHole=false;_gz(z)}}
{const _se=startExplore;startExplore=function(){if(EXP.forceZone&&EXP.forceZone.cls==="z-hollow"&&!lntOn()){EXP.forceZone=ZONES.find(q=>q.cls==="z-quill");EXP.spawn=null;EXP.resume=null}
  if(EXP.forceZone===HOLLOW_ZONE)HOLLOW_ZONE.map=lntStamp("z-hollow",MAPS["z-hollow"].slice());_se()}}
{const _pt=placeTrail;placeTrail=function(){if(inHollow())return;_pt()}}
{const _ra=renderActions;renderActions=function(){_ra();if(inHollow()){const w=$("#btn-wander");if(w)w.remove()}}}
function lntEnterHollow(){EXP.stash=null;EXP.resume=null;EXP.spawn=null;EXP.forceZone=HOLLOW_ZONE;startExplore()}
function lntLeaveHollow(){EXP.stash=null;EXP.resume=null;EXP.forceZone=ZONES.find(q=>q.cls==="z-quill");EXP.spawn=[QUILL_HOLE[0],QUILL_HOLE[1]+1];startExplore()}
/* encounters in the leaf piles are always one of the five that live there, in recipe mode: these were never in anybody's book */
const LNT_LEAF=()=>LNT_ALLOYS.filter(o=>o.how==="leaf").map(o=>lntAlloy(o.name)).filter(Boolean);
{const _pa=pickAlloy;pickAlloy=function(kind,used){
  if(!EXP.storyAlloy&&inHollow()){const pool=LNT_LEAF().filter(a=>!used.has(a.name));const P=pool.length?pool:LNT_LEAF();let tot=P.reduce((t,a)=>t+RARITY[a.rar].w,0),r=Math.random()*tot;for(const a of P){r-=RARITY[a.rar].w;if(r<=0)return a}return P[P.length-1]}
  for(let i=0;i<40;i++){const a=_pa(kind,used);if(EXP.storyAlloy||(!a.event))return a}return _pa(kind,used)}}
{const _sr=startRound;startRound=function(){const m=S.mode;if(inHollow()&&!EXP.storyAlloy)S.mode="recipe";_sr();S.mode=m}}

/* ---- decorations, placed by hand, one list per map ----
   floor pieces (neep, trail, bogle, cand) stand on their own tile and can't be walked through; wall pieces (bunt, bats, web) hang on a wall face */
const LNT_DECOR={
 "z-mine":[["bunt",12,7,5],["strg",18,7,5],["bats",33,10],["web",17,10],["skel",32,7],["eyes",2,6],["crow",34,6],["ghost",19,20],["wisp",32,14],["neep",30,23],["neep",12,23],["cand",17,15],["trail",29,16,0]],
 "z-scrap":[["bunt",14,0,6],["strg",1,0,4],["bats",35,11],["eyes",38,11],["web",28,19],["crow",8,2],["crow",11,6],["ghost",8,18],["wisp",31,2],["neep",20,22],["neep",26,2],["bogle",29,7],["cand",29,22],["pot",15,13]],
 "z-wreck":[["bunt",31,4,2],["bats",33,5],["web",4,9],["crow",7,1],["crow",3,6],["ghost",18,15],["wisp",14,9],["wisp",22,2],["neep",6,21],["neep",2,14],["bogle",6,17],["pot",7,19],["trail",33,17,1]],
 "z-volcano":[["bunt",5,0,3],["bats",4,6],["skel",30,1],["crow",13,7],["ghost",28,21],["wisp",18,9],["wisp",33,15],["neep",10,22],["neep",37,10],["neep",15,4],["cand",21,2],["bogle",10,15],["pot",5,8],["trail",21,12,2]],
 "z-glacier":[["bunt",23,0,5],["strg",29,0,4],["bats",10,0],["eyes",2,20],["crow",15,2],["crow",36,7],["ghost",20,4],["wisp",20,8],["wisp",24,12],["neep",10,24],["neep",37,5],["cand",4,7],["bogle",26,16],["trail",32,11,3]],
 "z-vault":[["bunt",12,8,3],["strg",29,8,3],["bats",30,14],["skel",28,14],["eyes",6,14],["web",4,20],["crow",16,3],["ghost",8,11],["neep",19,18],["neep",24,18],["cand",12,24],["cand",19,10],["cand",24,10],["trail",19,4,4]],
 "z-reactor":[["bunt",9,0,6],["skel",25,0],["bats",33,6],["eyes",7,18],["web",11,18],["crow",18,1],["ghost",21,4],["wisp",15,10],["wisp",26,13],["neep",14,24],["neep",38,17],["cand",9,8],["pot",27,23]],
 "z-crater":[["bunt",31,7,4],["strg",25,7,5],["bats",28,1],["crow",4,6],["crow",36,13],["ghost",26,17],["wisp",14,11],["wisp",19,13],["neep",6,23],["neep",38,21],["cand",26,3],["bogle",15,20],["pot",31,19],["trail",10,12,5]],
 "z-quill":[["bunt",20,0,6],["bunt",32,0,4],["bats",12,0],["web",18,9],["skel",10,9],["ghost",10,6],["neep",21,32],["neep",34,32],["cand",35,21],["pot",40,16]],
 "z-slag":[["neep",3,4],["bats",34,14],["skel",16,14],["cand",8,23]],
 "z-hollow":[["bunt",11,6,6],["bunt",18,6,9],["strg",35,13,3],["bats",30,7],["web",36,7],["crow",6,7],["crow",8,12],["crow",7,1],["wisp",37,19],["wisp",4,12],["wisp",25,2],
   ["eyes",0,9],["eyes",0,14],["eyes",39,3],["eyes",39,23],["eyes",9,25],["eyes",25,25],["eyes",16,0],["eyes",30,0],
   ["neep",16,7],["neep",26,7],["neep",1,12],["neep",10,15],["neep",26,15],["neep",38,15],["neep",6,1],["cand",4,14],["pot",20,15],["bogle",32,2],["trail",22,4,6]]};
const LNT_FLOOR_K=new Set(["neep","trail","bogle","cand","pot"]);
let LNT_NEEPS=()=>Object.entries(LNT_DECOR).flatMap(([z,L])=>L.filter(d=>d[0]==="neep").map(d=>z+":"+d[1]+","+d[2]));
/* stamp the floor pieces (and, in the hall, the hole) into a map so nobody walks through them */
const LNT_UNDER={};
function lntStamp(cls,M){if(!lntOn())return M;
  const put=(x,y,ch)=>{const r=M[y];if(!r)return;LNT_UNDER[cls+":"+x+","+y]=r[x];M[y]=r.slice(0,x)+ch+r.slice(x+1)};
  (LNT_DECOR[cls]||[]).forEach(d=>{if(LNT_FLOOR_K.has(d[0]))put(d[1],d[2],"¤")});
  if(cls==="z-quill")put(QUILL_HOLE[0],QUILL_HOLE[1],"¥");
  return M}
{const _om=openedMap;openedMap=function(cls){return lntStamp(cls,_om(cls))}}
{const _cw=canWalk;canWalk=function(c){return c==="¤"||c==="¥"?false:_cw(c)}}
{const _tl=tileLook;tileLook=function(c,x,y,seed,M){const z=EXP.zone.cls;
  if(c==="¤"||c==="¥"){let u=LNT_UNDER[z+":"+x+","+y]||".";if(u==="P")u=".";return z==="z-hollow"?hmChain(u,x,y,seed,M,_tl):_tl(u,x,y,seed,M)}
  if(z!=="z-hollow")return _tl(c,x,y,seed,M);return hmChain(c,x,y,seed,M,_tl)}}
/* Hollowmere draws its own tiles, but still goes through the rest of the chain (culling, chunk pictures, wall edges) by asking it about a stand-in */
function hmChain(c,x,y,seed,M,_tl){const mine=hmTile(c,x,y,seed,M),r=_tl(c==="#"||c==="B"?"#":c===","?",":"§",x,y,seed,M)||["",""];
  const extra=(r[0]||"").split(/\s+/).filter(k=>k&&!["w","f","r","pr","tl","fd","l","pa","lq"].includes(k)).join(" "),cls=mine[0]+(extra?" "+extra:"");
  if(CH.b&&CH.W===M[0].length){CH.inner[y*CH.W+x]=mine[1]||"";return[cls,""]}return[cls,mine[1]]}

/* ---- the drawings ---- */
const LNT_SVG={
 neep:lit=>`<ellipse cx="20" cy="36" rx="10" ry="2.4" fill="#000" opacity=".3"/>${lit?`<circle class="lnt-halo" cx="20" cy="25" r="17" fill="#FFB43A" opacity=".28"/>`:""}
  <path d="M8 28 Q6 16 20 14 Q34 16 32 28 Q30 36 20 36 Q10 36 8 28 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width="1.3"/><path d="M10 20 Q20 13 30 20" stroke="#9A5AA0" stroke-width="3.4" fill="none" opacity=".6"/>
  <path d="M15 14 Q20 11 25 14 L24 12 Q20 9 16 12 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width=".9"/><path d="M19 11 Q17 5 14 4 M21 11 Q23 5 27 4" stroke="#4A7A3A" stroke-width="1.6" fill="none" stroke-linecap="round"/>
  <g class="lnt-face" fill="${lit?"#FFC24A":"#2A1A12"}"><path d="M12.5 22 L15.5 19 L17 23 Z M23 23 L24.5 19 L27.5 22 Z"/><path d="M12 27 L14 29.5 L16 27.5 L18 30 L20 27.5 L22 30 L24 27.5 L26 29.5 L28 27 Q26 33 20 33 Q14 33 12 27 Z"/></g>`,
 trail:lit=>`<ellipse cx="20" cy="37" rx="8" ry="2" fill="#000" opacity=".3"/>${lit?`<circle class="lnt-halo" cx="20" cy="-4" r="16" fill="#FFC870" opacity=".32"/>`:""}<path d="M20 37 V4" stroke="#1E1E24" stroke-width="2.6"/><path d="M15 37 H25" stroke="#1E1E24" stroke-width="2.4"/>
  <path d="M14 -8 H26 L24 -12 H16 Z" fill="#2A2A30" stroke="#121216" stroke-width=".8"/><rect x="15" y="-8" width="10" height="12" fill="${lit?"#FFE6A0":"#3A3E48"}" stroke="#121216" stroke-width="1"/>
  ${lit?`<path class="lnt-flame" d="M20 -5 Q22.6 -1 20 2.6 Q17.4 -1 20 -5 Z" fill="#FF8A2A"/>`:`<path d="M20 -1 V2" stroke="#5A4A3A" stroke-width="1"/>`}<path d="M14 4 H26" stroke="#121216" stroke-width="1.6"/>
  <path d="M20 9 Q26 11 25 16" stroke="#C83A2A" stroke-width="1.6" fill="none"/>${lit?`<rect x="21.5" y="15" width="7" height="9" rx="1" fill="#F4ECD8" stroke="#5A4A3A" stroke-width=".6" transform="rotate(8 25 19)"/><path d="M23 18 H27 M23 20 H26.4" stroke="#8A7A6A" stroke-width=".6" transform="rotate(8 25 19)"/>`:""}`,
 bogle:()=>`<ellipse cx="20" cy="37" rx="9" ry="2" fill="#000" opacity=".3"/><path d="M20 37 V8" stroke="#5A4028" stroke-width="2.4"/>
  <path d="M4 16 H36" stroke="#5A4028" stroke-width="2"/><path d="M8 14 L32 14 L30 30 L10 30 Z" fill="#5A4A34" stroke="#2A1E12" stroke-width="1"/><rect x="11" y="18" width="5" height="5" fill="#7A3A4A" stroke="#2A1E12" stroke-width=".5"/><rect x="24" y="22" width="4" height="4" fill="#4A6A7A" stroke="#2A1E12" stroke-width=".5"/>
  <path d="M5 13 l-3 -2 M5 16 l-4 0 M5 19 l-3 2 M35 13 l3 -2 M35 16 l4 0 M35 19 l3 2 M12 30 l-1 3 M20 30 v4 M28 30 l1 3" stroke="#E8C860" stroke-width="1.2" stroke-linecap="round"/>
  <g class="lnt-bhead"><path d="M13 9 Q12 2 20 1 Q28 2 27 9 Q26 14 20 14 Q14 14 13 9 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width="1"/><circle cx="17.5" cy="7.5" r="1.3" fill="#2A1A12"/><circle cx="22.5" cy="7.5" r="1.3" fill="#2A1A12"/><path d="M17 11 Q20 12.6 23 11" stroke="#2A1A12" stroke-width=".9" fill="none"/>
   <path d="M11 2 H29 L26 0 Q20 -9 14 0 Z" fill="#3A2E22" stroke="#1A120A" stroke-width="1"/><path d="M14 0 H26" stroke="#8A3A2A" stroke-width="1.4"/></g>`,
 cand:lit=>`<ellipse cx="20" cy="36" rx="12" ry="2.4" fill="#000" opacity=".3"/><path d="M7 36 Q6 30 12 29 H28 Q34 30 33 36 Z" fill="#6A6A72" stroke="#2A2A30" stroke-width="1"/>
  ${[[13,18,10],[20,14,14],[27,20,8]].map(([x,y,h])=>`<rect x="${x-2.2}" y="${y}" width="4.4" height="${h+1}" rx="1" fill="#F2EAD4" stroke="#8A7A5A" stroke-width=".6"/><path d="M${x+1.6} ${y+1} q.8 2 0 3.4" stroke="#F2EAD4" stroke-width="1.4" fill="none"/>`+(lit?`<path class="lnt-flame" d="M${x} ${y-6} Q${x+2.4} ${y-2.4} ${x} ${y} Q${x-2.4} ${y-2.4} ${x} ${y-6} Z" fill="#FFB43A" style="animation-delay:-${(x%5)*.13}s"/><circle cx="${x}" cy="${y-3}" r="5" fill="#FFC870" opacity=".2"/>`:`<path d="M${x} ${y} v-1.4" stroke="#2A2A2A" stroke-width=".8"/>`)).join("")}`,
 bunt:n=>{let s=`<svg viewBox="0 0 ${40*n} 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 9 Q${20*n} 19 ${40*n} 9" stroke="#3A2A1A" stroke-width="1.2" fill="none"/>`;const k=n*3;
  for(let i=0;i<k;i++){const t=(i+.5)/k,x=t*40*n,y=9+10*4*t*(1-t)*.98;s+=`<g class="lnt-flag" style="transform-origin:${x.toFixed(1)}px ${y.toFixed(1)}px;animation-delay:-${(i*.37%1.6).toFixed(2)}s"><path d="M${(x-5).toFixed(1)} ${y.toFixed(1)} L${(x+5).toFixed(1)} ${y.toFixed(1)} L${x.toFixed(1)} ${(y+11).toFixed(1)} Z" fill="${["#C83A2A","#E8A02A","#3A3A4A","#7A4A9A","#E8DCB8"][i%5]}" stroke="#2A1A12" stroke-width=".6"/>${i%5===2?`<path d="M${(x-2.6).toFixed(1)} ${(y+2.6).toFixed(1)} q1.3 -1.6 2.6 0 q1.3 -1.6 2.6 0 l-1.3 2.4 l-1.3 -1 l-1.3 1 Z" fill="#E8DCB8"/>`:""}</g>`}return s+`</svg>`},
 bats:()=>[[12,10,0],[20,13,.4],[28,9,.8]].map(([x,y,d],i)=>`<g class="lnt-bat" style="--d:${d}s;--i:${i}"><g transform="translate(${x} ${y})"><path d="M0 -4 V-1" stroke="#1A1A20" stroke-width=".8"/><path d="M-3.4 0 Q-4 5 0 8 Q4 5 3.4 0 Q0 -1.6 -3.4 0 Z" fill="#2A2430" stroke="#121216" stroke-width=".7"/><circle cx="-1.2" cy="5" r=".6" fill="#E8C040"/><circle cx="1.2" cy="5" r=".6" fill="#E8C040"/><path d="M-1.6 8.4 L-2.4 10 M1.6 8.4 L2.4 10" stroke="#2A2430" stroke-width=".9"/></g></g>`).join(""),
 web:()=>`<path d="M0 0 L22 0 M0 0 L0 22 M0 0 L18 14 M0 0 L9 20 M0 0 L20 6" stroke="#E8E8F0" stroke-width=".55" opacity=".85" fill="none"/>${[6,11,16].map(r=>`<path d="M${r} 0 Q${r*.9} ${r*.3} ${r*.88} ${r*.29} Q${r*.75} ${r*.62} ${r*.8} ${r*.62} Q${r*.42} ${r*.86} ${r*.45} ${r*.9} Q${r*.1} ${r*.9} 0 ${r}" stroke="#E8E8F0" stroke-width=".5" opacity=".75" fill="none"/>`).join("")}
  <g class="lnt-spider"><path d="M14 10 V22" stroke="#E8E8F0" stroke-width=".4" class="lnt-thread"/><g transform="translate(14 24)"><ellipse rx="2.4" ry="3" fill="#1A1A20"/><circle cy="-3" r="1.6" fill="#1A1A20"/>${[-1,1].map(s=>`<path d="M0 -1 l${s*4} -2 M0 0 l${s*4.6} 0 M0 1 l${s*4} 2.4 M0 2 l${s*3} 3.6" stroke="#1A1A20" stroke-width=".7" fill="none"/>`).join("")}<circle cx="-.6" cy="-3.3" r=".4" fill="#E84040"/><circle cx=".6" cy="-3.3" r=".4" fill="#E84040"/></g></g>`,
 hole:k=>`<ellipse cx="20" cy="22" rx="17" ry="9" fill="#06040C" stroke="#3A2A4A" stroke-width="1.6"/><g class="lnt-void"><path d="M20 22 m-12 0 a12 6 0 1 1 24 0" stroke="#5A3A8A" stroke-width="1.4" fill="none" opacity=".7"/><path d="M20 22 m-7 0 a7 3.6 0 1 0 14 0" stroke="#8A6AC8" stroke-width="1" fill="none" opacity=".6"/></g>
  <ellipse cx="20" cy="22" rx="17" ry="9" fill="none" stroke="#1A1220" stroke-width="3" opacity=".6"/>${[0,1,2,3].map(i=>`<circle class="lnt-mote" cx="${12+i*5}" cy="22" r="${.8+i%2*.5}" fill="#C8A8F8" style="animation-delay:-${i*.7}s"/>`).join("")}
  ${k==="quill"?`<path d="M4 26 l3 -2 M36 25 l-3 -2 M6 17 l3 1 M33 16 l-3 2" stroke="#8A8070" stroke-width="1.2"/><path d="M2 30 L8 27 L5 31 Z M35 30 L39 27 L37 31 Z" fill="#B8B0A0" stroke="#5A5040" stroke-width=".6"/>`:`<path d="M3 26 q4 -3 6 0 M31 26 q4 -3 6 0" stroke="#4A6A3A" stroke-width="1.4" fill="none"/>`}`,
 print:()=>`<g opacity=".7"><ellipse cx="15" cy="20" rx="3" ry="4.6" fill="#BFE6FF"/><circle cx="13" cy="14" r="1" fill="#BFE6FF"/><circle cx="15.6" cy="13.4" r="1" fill="#BFE6FF"/><circle cx="17.6" cy="14.6" r="1" fill="#BFE6FF"/>
  <ellipse cx="25" cy="27" rx="3" ry="4.6" fill="#BFE6FF"/><circle cx="23" cy="21" r="1" fill="#BFE6FF"/><circle cx="25.6" cy="20.4" r="1" fill="#BFE6FF"/><circle cx="27.6" cy="21.6" r="1" fill="#BFE6FF"/></g>`};

/* ---- Hollowmere's ground, walls and furniture ---- */
function hmFloor(x,y){if(y<=5)return"hm-moor";if(x<=8&&y>=7&&y<=15)return"hm-kirk";if(x>=29&&x<=37&&y>=8&&y<=12)return"hm-board";if(x>=28&&y>=14&&y<=15)return"hm-yard";if(y>=22)return"hm-garden";return"hm-grass"}
function hmLeaves(seed){const R=k=>{const v=Math.sin(seed*7.3+k*11.9)*43758.5;return v-Math.floor(v)};let h="";
  for(let i=0;i<9;i++){const x=6+R(i)*28,y=16+R(i+9)*18,r=R(i+3)*360,c=["#C8642A","#A8402A","#D8A040","#8A5A2A","#E8862A"][i%5];
    h+=`<path d="M${x.toFixed(1)} ${y.toFixed(1)} q3 -4 6 0 q-3 4 -6 0 Z" transform="rotate(${r.toFixed(0)} ${(x+3).toFixed(1)} ${y.toFixed(1)})" fill="${c}" stroke="#3A1A0A" stroke-width=".5"/>`}
  return`<svg viewBox="0 0 40 40" aria-hidden="true"><ellipse cx="20" cy="28" rx="15" ry="7" fill="#5A2E14" opacity=".45"/>${h}</svg>`}
const HMP={
 X:{tall:1,svg:`<ellipse cx="20" cy="36" rx="11" ry="2.6" fill="#000" opacity=".3"/><path d="M11 36 L9 8 Q12 -4 21 -6 Q30 -3 31 8 L29 36 Z" fill="#7A7A80" stroke="#2A2A30" stroke-width="1.3"/><path d="M14 30 L13 10 Q15 2 20 0" stroke="#9A9AA0" stroke-width="1.4" fill="none"/><path d="M24 14 l3 2 M22 22 l4 -1" stroke="#4A4A50" stroke-width="1"/><path d="M12 33 q4 -3 8 0" stroke="#5A7A4A" stroke-width="2" fill="none"/>`},
 O:{tall:1,svg:`<ellipse cx="20" cy="37" rx="15" ry="3" fill="#000" opacity=".35"/><path d="M6 37 L5 0 Q8 -16 20 -18 Q33 -16 35 0 L34 37 Z" fill="#6E6E76" stroke="#24242A" stroke-width="1.5"/><path d="M10 30 L9 2 Q11 -10 20 -13" stroke="#8E8E96" stroke-width="1.6" fill="none"/>
   <circle cx="20" cy="6" r="7" fill="none" stroke="#3A3A42" stroke-width="1.6"/><circle cx="21.4" cy="6" r="6" fill="#4A4A52" opacity=".6"/><path d="M8 36 q5 -4 10 0 M22 36 q5 -3 10 0" stroke="#4A6A3A" stroke-width="2" fill="none"/>`},
 k:{svg:`<ellipse cx="20" cy="36" rx="15" ry="2.6" fill="#000" opacity=".3"/><path d="M5 36 Q3 18 20 12 Q37 18 35 36 Z" fill="#C8A24A" stroke="#5A4012" stroke-width="1.2"/>${[[10,24],[16,20],[24,22],[30,28],[14,30],[22,30]].map(([x,y])=>`<path d="M${x} ${y} l3 -4 M${x+2} ${y} l-1 -4" stroke="#8A6A22" stroke-width=".9"/>`).join("")}<path d="M5 30 Q20 26 35 30" stroke="#5A4012" stroke-width="1.6" fill="none"/>`},
 t:{tall:1,svg:`<ellipse cx="20" cy="37" rx="16" ry="2.6" fill="#000" opacity=".3"/><path d="M3 36 L20 2 L37 36 Z" fill="#B8A882" stroke="#4A3E2A" stroke-width="1.3"/><path d="M20 2 L14 36 M20 2 L26 36" stroke="#8A7A5A" stroke-width="1"/><path d="M15 36 L20 20 L25 36 Z" fill="#1A1610"/><path d="M20 2 V-8" stroke="#4A3E2A" stroke-width="1.4"/><path d="M20 -8 L30 -5 L20 -2 Z" fill="#C83A2A" stroke="#4A1A12" stroke-width=".6"/><path d="M6 30 l-3 6 M34 30 l3 6" stroke="#4A3E2A" stroke-width="1"/>`},
 G:{svg:(x,y,s)=>{const k=(x*7+y*3)%3;return`<ellipse cx="20" cy="35" rx="10" ry="2.4" fill="#000" opacity=".3"/>`+(k===0?`<path d="M12 35 V16 Q12 8 20 8 Q28 8 28 16 V35 Z" fill="#8A8A90" stroke="#2A2A30" stroke-width="1.2"/><path d="M16 18 H24 M17 22 H23" stroke="#5A5A60" stroke-width="1"/>`
   :k===1?`<path d="M18 35 V18 H12 V13 H18 V7 H22 V13 H28 V18 H22 V35 Z" fill="#7E7E86" stroke="#2A2A30" stroke-width="1.2"/>`:`<g transform="rotate(-8 20 30)"><rect x="11" y="14" width="18" height="21" rx="2" fill="#929298" stroke="#2A2A30" stroke-width="1.2"/><path d="M14 19 H26 M15 23 H25 M16 27 H24" stroke="#606068" stroke-width="1"/></g>`)+`<path d="M10 35 q3 -3 6 0 M24 35 q3 -3 6 0" stroke="#4A6A3A" stroke-width="1.6" fill="none"/>`}},
 Y:{tall:1,svg:`<ellipse cx="20" cy="37" rx="16" ry="3" fill="#000" opacity=".35"/><path d="M17 37 Q16 26 18 20 H23 Q25 28 24 37 Z" fill="#5A3A26" stroke="#2A1A10" stroke-width="1.2"/><path d="M2 22 Q0 6 10 -2 Q20 -14 30 -2 Q40 6 38 22 Q30 30 20 26 Q10 30 2 22 Z" fill="#1E3A26" stroke="#0A1A10" stroke-width="1.4"/><path d="M8 14 Q14 6 20 10 M22 2 Q30 0 32 10 M10 22 Q16 18 22 22" stroke="#2E5A3A" stroke-width="1.6" fill="none"/>${[[12,6],[26,14],[18,18],[30,4]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="1.2" fill="#C83A2A"/>`).join("")}`},
 J:{tall:1,svg:`<ellipse cx="20" cy="37" rx="7" ry="2" fill="#000" opacity=".3"/><path d="M20 37 V-2" stroke="#1E1E24" stroke-width="2.6"/><path d="M15 37 H25 M17 34 H23" stroke="#1E1E24" stroke-width="2"/><path d="M14 -6 H26 L24 -10 H16 Z" fill="#2A2A30"/><rect x="15" y="-6" width="10" height="11" fill="#FFE6A0" stroke="#121216" stroke-width="1"/><path d="M20 -3 Q22 0 20 3 Q18 0 20 -3 Z" fill="#FF8A2A"/><path d="M14 5 H26" stroke="#121216" stroke-width="1.6"/><path d="M20 12 Q30 14 30 20" stroke="#E8A02A" stroke-width="1" fill="none"/>`},
 Q:{svg:`<ellipse cx="20" cy="36" rx="14" ry="2.6" fill="#000" opacity=".3"/><path d="M6 22 H34 V34 Q20 38 6 34 Z" fill="#7A7068" stroke="#2A2420" stroke-width="1.2"/><path d="M6 27 H34 M13 22 V34 M20 22 V35 M27 22 V34" stroke="#4A4440" stroke-width=".8"/><ellipse cx="20" cy="22" rx="14" ry="4" fill="#0E1418" stroke="#2A2420" stroke-width="1.2"/><path d="M8 22 V4 M32 22 V4" stroke="#4A3422" stroke-width="2.2"/><path d="M5 5 L20 -4 L35 5 Z" fill="#5A3A26" stroke="#2A1A10" stroke-width="1"/><path d="M8 10 H32" stroke="#4A3422" stroke-width="1.6"/><path d="M20 10 V16" stroke="#8A8A8A" stroke-width=".8"/><rect x="17" y="16" width="6" height="5" fill="#6A5038" stroke="#2A1A10" stroke-width=".6"/>`},
 C:{svg:`<ellipse cx="20" cy="36" rx="13" ry="2.4" fill="#000" opacity=".3"/><path d="M8 36 L9 28 Q6 10 20 6 Q34 10 31 28 L32 36 Q26 33 20 36 Q14 33 8 36 Z" fill="#E8E2D2" stroke="#3A3428" stroke-width="1.2"/><path d="M12 14 Q20 10 28 14 M10 26 Q20 22 30 26" stroke="#B8B0A0" stroke-width="1" fill="none"/><path d="M9 36 v2 M31 36 v2" stroke="#4A3422" stroke-width="2"/>`},
 b:{svg:`<ellipse cx="20" cy="35" rx="15" ry="2.2" fill="#000" opacity=".3"/><rect x="4" y="22" width="32" height="4" fill="#6A4A2E" stroke="#2A1A0E" stroke-width="1"/><rect x="4" y="14" width="32" height="4" fill="#6A4A2E" stroke="#2A1A0E" stroke-width="1"/><path d="M7 26 V35 M33 26 V35 M7 18 V22 M33 18 V22" stroke="#2A2A30" stroke-width="2"/><path d="M14 20 h12" stroke="#C83A2A" stroke-width="1.6"/>`},
 T:{tall:1,svg:`<ellipse cx="20" cy="37" rx="12" ry="2.6" fill="#000" opacity=".3"/><path d="M17 37 Q18 20 15 8 M17 30 Q22 18 24 10 M19 22 Q26 18 30 6 M16 16 Q10 10 8 2 M24 10 Q28 2 26 -4 M15 8 Q16 0 14 -6" stroke="#3A2A20" stroke-width="2.6" fill="none" stroke-linecap="round"/><path d="M17 37 Q18 20 15 8" stroke="#3A2A20" stroke-width="4.4" fill="none"/>${[[8,4],[28,8],[25,-3],[13,-4]].map(([x,y])=>`<path d="M${x} ${y} q2 -2 4 0 q-2 2 -4 0 Z" fill="#C8642A"/>`).join("")}`}};
function hmTile(c,x,y,seed,M,_tl){const fl=hmFloor(x,y),v=" v"+((x*3+y*5)%3);
  if(c==="#"){const edge=y===0||y===25||x===0||x===39;return["w "+(edge?"hm-hedge":"hm-dyke")+v,""]}
  if(c==="B")return["w hm-brick"+(y===13?" hm-front":""),y===13&&x===30?`<svg viewBox="0 0 40 40" aria-hidden="true"><text x="20" y="27" text-anchor="middle" font-size="9" font-weight="bold" font-family="monospace" fill="#E8DCC0" opacity=".8">1932</text></svg>`:""];
  if("HDANMF".includes(c))return["f hm-solid "+fl+v,""];
  if(c===",")return["r "+fl,hmLeaves(seed)];
  if(c==="=")return["f hm-lane"+v,""];
  if(c==="~"){const n=(dx,dy)=>((M[y+dy]||"")[x+dx]==="~");return["hm-pond"+(n(0,-1)?"":" et")+(n(0,1)?"":" eb")+(n(-1,0)?"":" el")+(n(1,0)?"":" er"),""]}
  if(c==="S")return["f pr "+fl,PS(SIGNPOST)];
  const P=HMP[c];if(P)return[(P.tall?"f tl ":"f pr ")+fl,PS(typeof P.svg==="function"?P.svg(x,y,seed):P.svg)];
  return["f "+fl+v,""]}
/* the cottages, the stalls and the bonfire are one picture each, laid over their tiles */
function hmCottage(v){const roof=["#5A4A3A","#4A3A30","#6A5A44","#544438"][v],wall=["#D8CCB0","#C8BCA0","#E0D4BC","#CCC0A8"][v],door=["#5A2A2A","#2A3A5A","#3A4A2A","#5A4A2A"][v],dx=[3,4,3,5][v]*40,wx=dx<160?220:60;
  return`<svg viewBox="0 0 320 120" preserveAspectRatio="none" aria-hidden="true"><path d="M2 54 L22 2 H298 L318 54 Z" fill="${roof}" stroke="#1A120A" stroke-width="3"/>${[12,24,36,48].map(y=>`<path d="M${10+y*.3} ${y} H${310-y*.3}" stroke="#2A1E14" stroke-width="1.4" opacity=".55"/>`).join("")}
   <rect x="${dx<160?250:40}" y="-14" width="22" height="30" fill="#7A5A44" stroke="#1A120A" stroke-width="2.4"/><rect x="${dx<160?248:38}" y="-18" width="26" height="6" fill="#5A4030" stroke="#1A120A" stroke-width="2"/>
   <g class="hm-smoke">${[0,1,2].map(i=>`<circle cx="${(dx<160?261:51)}" cy="-24" r="${5+i*2}" fill="#8A8A9A" opacity=".35" style="animation-delay:-${i*1.1}s"/>`).join("")}</g>
   <rect x="6" y="54" width="308" height="64" fill="${wall}" stroke="#1A120A" stroke-width="3"/><path d="M6 70 H314 M6 92 H314" stroke="#000" stroke-width="1" opacity=".08"/>
   <rect x="${dx+6}" y="66" width="28" height="52" rx="2" fill="${door}" stroke="#1A120A" stroke-width="2.4"/><circle cx="${dx+28}" cy="94" r="2" fill="#E8C040"/><path d="M${dx+2} 64 H${dx+38}" stroke="#1A120A" stroke-width="3"/>
   ${[wx,wx+48].map(x=>`<g><rect x="${x}" y="66" width="34" height="30" fill="#FFC870" class="hm-win" stroke="#1A120A" stroke-width="2.4"/><path d="M${x+17} 66 V96 M${x} 81 H${x+34}" stroke="#1A120A" stroke-width="2"/><rect x="${x-3}" y="96" width="40" height="5" fill="#6A5A44" stroke="#1A120A" stroke-width="1.4"/></g>`).join("")}
   <g transform="translate(${dx+40} 80)">${LNT_SVG.neep(true).replace(/<ellipse[^>]*\/>/,"")}</g></svg>`}
function hmStall(k){const canopy={dook:["#C83A2A","#F4ECD8"],shuffle:["#3A3A6A","#E8C040"],memory:["#2A5A3A","#F4ECD8"]}[k],[a,b]=canopy;
  const wares=k==="dook"?`<path d="M20 48 L24 76 H56 L60 48 Z" fill="#8A6A44" stroke="#2A1A0E" stroke-width="2"/><ellipse cx="40" cy="48" rx="20" ry="4" fill="#5A8AB8" stroke="#2A1A0E" stroke-width="1.6"/>${[30,40,50].map((x,i)=>`<circle class="hm-bob" cx="${x}" cy="47" r="3.6" fill="#C83A2A" style="animation-delay:-${i*.4}s"/>`).join("")}`
   :k==="shuffle"?`<rect x="10" y="50" width="60" height="26" fill="#6A4A2E" stroke="#2A1A0E" stroke-width="2"/>${[22,40,58].map(x=>`<path d="M${x-7} 50 Q${x-8} 38 ${x} 36 Q${x+8} 38 ${x+7} 50 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width="1.4"/>`).join("")}`
   :`<rect x="10" y="50" width="60" height="26" fill="#4A3A2A" stroke="#2A1A0E" stroke-width="2"/>${[16,28,40,52,64].map((x,i)=>`<g><rect x="${x-4}" y="38" width="8" height="12" fill="${["#E8412C","#F2C94C","#3A9AD8","#7A4A9A","#E8DCB8"][i]}" class="hm-mem" style="animation-delay:-${i*.5}s" stroke="#1A120A" stroke-width="1"/><path d="M${x-5} 38 H${x+5}" stroke="#1A120A" stroke-width="1.6"/></g>`).join("")}`;
  return`<svg viewBox="0 0 80 80" aria-hidden="true" style="overflow:visible"><ellipse cx="40" cy="78" rx="34" ry="4" fill="#000" opacity=".3"/><path d="M8 78 V20 M72 78 V20" stroke="#3A2A1A" stroke-width="3"/>
   <path d="M2 22 L10 4 H70 L78 22 Z" fill="${a}" stroke="#1A120A" stroke-width="2"/>${[0,1,2,3].map(i=>`<path d="M${10+i*15} 4 L${14+i*15} 22 H${22+i*15} L${17+i*15} 4 Z" fill="${b}" opacity=".85"/>`).join("")}<path d="M2 22 ${Array.from({length:8},(_,i)=>`Q${7+i*9.5} 30 ${12+i*9.5} 22`).join(" ")}" fill="${a}" stroke="#1A120A" stroke-width="1.6"/>${wares}</svg>`}
function hmBonfire(){return`<svg viewBox="0 0 120 80" aria-hidden="true" style="overflow:visible"><ellipse cx="60" cy="72" rx="56" ry="8" fill="#1A0A04" opacity=".55"/><circle cx="60" cy="50" r="60" fill="#FF8A2A" opacity=".12" class="hm-fireglow"/>
  ${[[18,70,102,58],[22,58,98,70],[40,74,86,50],[30,52,90,74]].map(([a,b,c,d])=>`<path d="M${a} ${b} L${c} ${d}" stroke="#3A2414" stroke-width="7" stroke-linecap="round"/><path d="M${a} ${b} L${c} ${d}" stroke="#5A3A20" stroke-width="3" stroke-linecap="round"/>`).join("")}
  <g class="hm-flames">${[[60,-20,26,0],[44,0,18,.3],[78,-4,20,.6],[60,6,14,.15],[34,20,12,.45],[86,18,12,.75]].map(([x,top,w,d])=>`<path d="M${x-w} 66 Q${x-w*.8} ${top+30} ${x} ${top} Q${x+w*.8} ${top+30} ${x+w} 66 Z" fill="${top<0?"#FF7A1A":top<10?"#FFB24A":"#FFE27A"}" style="animation-delay:-${d}s"/>`).join("")}</g>
  ${[0,1,2,3,4,5].map(i=>`<circle class="hm-spark" cx="${44+i*6}" cy="20" r="1.6" fill="#FFD27A" style="animation-delay:-${i*.5}s;--sx:${(i%2?1:-1)*(8+i*3)}px"/>`).join("")}</svg>`}

/* ---- the lantern trail ---- */
const LNT_CLUES=["Where the old seam's water lies black and still underground, and a lantern would see itself twice.",
 "Where the planks walk out over the cove and stop, and the next step is the sea.",
 "Where the middle bridge over the burning channel sets you down inside the caldera.",
 "Where the long crossing over the frozen lake comes ashore on the side of the morning sun.",
 "At the far end of the long carpet, where every visitor finally stops walking and looks up.",
 "Beside the pool a falling star left behind, on the shore that faces the setting sun.",
 "Home again. The last one is lit on the hill above Hollowmere, at the tallest stone, where the eclipse camp watched the sky go dark."];
const lntTrail=()=>lntF("trail")||0;
/* ---- small helpers ---- */
function lntEl(cls,x,y,html,w,h){const d=document.createElement("div");d.className=cls;d.style.width=((w||1)*100/EXP.W)+"%";d.style.height=((h||1)*100/EXP.H)+"%";d.style.left=(x/EXP.W*100)+"%";d.style.top=(y/EXP.H*100)+"%";d.innerHTML=html;$("#world").insertBefore(d,$("#player"));return d}
const lntSvg=(b,vb)=>`<svg viewBox="${vb||"0 0 40 40"}" aria-hidden="true" style="overflow:visible">${b}</svg>`;
const lntLit=()=>new Set(store.get("wta_lnt_lit",[]));
const lntSnuffed=k=>inHollow()&&EXP.gwPath&&EXP.gwSnuff&&EXP.gwSnuff.has(k);
function lntFlash(el,cls,ms){el.classList.remove(cls);void el.offsetWidth;el.classList.add(cls);clearTimeout(el["_"+cls]);el["_"+cls]=setTimeout(()=>el.classList.remove(cls),ms)}
const LNT_BOGLE=["A tattie bogle: a turnip head, a hat with a hole in it, and a coat nobody would admit to owning. Its head has turned to look at you.","The tattie bogle creaks round on its pole as you pass. It's only the wind. Probably.","Somebody has tucked a toffee apple into the tattie bogle's top pocket, for later."];
/* ---- decorate the map ---- */
function lntDecorate(){const z=EXP.zone.cls,L=LNT_DECOR[z];if(!L||!lntOn()||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;const lit=lntLit(),cand=new Set(store.get("wta_lnt_cand",[]));
  EXP.bogles=[];
  L.forEach(([k,x,y,n])=>{const key=z+":"+x+","+y;let el,o={x,y,lnt:k};
    if(k==="neep"){const on=lit.has(key)&&!lntSnuffed(key);el=lntEl("mapobj lnt neep"+(on?" lit":""),x,y,lntSvg(LNT_SVG.neep(on)));
      o.use=()=>{if(lntSnuffed(key)){sfx("miss");talk("",["You strike a match. It flares, shivers, and dies against the wick as if the wick were made of ice.","Something has been drinking the light out of the lanterns round here."]);return}
        if(lntLit().has(key)){talk("",[["The neep grins at you from the inside out. It's doing a grand job on its own.","Its carved grin flickers. The candle inside has a good while left in it yet."][(x+y)%2]]);return}
        const s=lntLit();s.add(key);store.set("wta_lnt_lit",[...s]);el.classList.add("lit");el.innerHTML=lntSvg(LNT_SVG.neep(true));lntFlash(el,"catch",900);if(gate("lntlight",600))sfx("sel");
        const all=LNT_NEEPS(),n=all.filter(q=>s.has(q)).length;store.set("wta_qf_seenJ",0);journalDot();
        say0(n>=all.length?`You light the last neep lantern. Every neep on every map is grinning tonight. (${n} of ${all.length})`:`You light the neep. Its carved grin catches and glows. Neep lanterns lit: ${n} of ${all.length}.`);if(inHollow())lntNight()}}
    else if(k==="trail"){const step=n,on=lntTrail()>step;el=lntEl("mapobj lnt trail"+(on?" lit":""),x,y,lntSvg(LNT_SVG.trail(on)));o.use=()=>lntTrailUse(step,el)}
    else if(k==="bogle"){el=lntEl("mapobj lnt bogle",x,y,lntSvg(LNT_SVG.bogle()));EXP.bogles.push(o);o.use=()=>{lntFlash(el,"creak",1200);if(gate("lntbog",900))sfx("clunk");talk("",[LNT_BOGLE[(x*3+y)%LNT_BOGLE.length]])}}
    else if(k==="cand"){let on=!cand.has(key);el=lntEl("mapobj lnt cand"+(on?" lit":""),x,y,lntSvg(LNT_SVG.cand(on)));
      o.use=()=>{const c=new Set(store.get("wta_lnt_cand",[]));on=!on;if(on)c.delete(key);else c.add(key);store.set("wta_lnt_cand",[...c]);el.innerHTML=lntSvg(LNT_SVG.cand(on));el.classList.toggle("lit",on);if(!on)lntFlash(el,"puff",1600);
        if(gate("lntcand",700))sfx(on?"sel":"hiss");say0(on?"You light the candles again. They lean all together towards you, then straighten.":"You blow the candles out. Three little threads of smoke climb up and knot together.")}}
    else if(k==="bunt"){el=lntEl("mapobj lnt bunt",x,y,LNT_SVG.bunt(n),n,1);o.wide=n;o.use=()=>{lntFlash(el,"tug",1400);if(gate("lntbunt",900))sfx("swirl");say0("You give the bunting a tug. Every flag along the string jumps and snaps.")}}
    else if(k==="bats"){el=lntEl("mapobj lnt bats",x,y,lntSvg(LNT_SVG.bats()));o.use=()=>{if(el.classList.contains("fly"))return;lntFlash(el,"fly",5200);if(gate("lntbat",1500))sfx("swirl");say0("The bats drop off the wall all at once and go flickering round your head. They'll be back once you've stopped looking.")}}
    else if(k==="web"){el=lntEl("mapobj lnt web",x,y,lntSvg(LNT_SVG.web()));o.use=()=>{if(el.classList.contains("up"))return;lntFlash(el,"up",3600);say0("The spider shins back up its thread to the top of the web, and sits there, offended.")}}
    if(!el)return;o.el=el;EXP.objs.push(o);
    /* wide pieces can be reached from under any part of them */
    if(o.wide)for(let i=1;i<o.wide;i++)EXP.objs.push({x:x+i,y,el:null,use:o.use,lnt:k})});
  lntBogles()}
function lntBogles(){(EXP.bogles||[]).forEach(b=>{if(!b.el)return;const dx=EXP.x-b.x,dy=EXP.y-b.y,r=Math.max(-28,Math.min(28,dx*7));b.el.style.setProperty("--rot",(Math.abs(dx)+Math.abs(dy)>9?0:r)+"deg")})}
{const _pp=placePlayer;placePlayer=function(i){_pp(i);if(EXP.bogles&&EXP.bogles.length)lntBogles();if(inHollow())lntPlayerLight()}}
function lntTrailUse(step,el){const cur=lntTrail();
  if(step<cur){const nx=LNT_CLUES[step+1];talk("",nx&&step<6?["The trail lantern is burning steadily. The tag tied to its pole says:",`'${nx}'`]:["The last lantern on the trail, burning on top of Hollowmere Hill. You can see every lit window in the village from up here."],step===6&&!lntGot("Besomite")?lntBesom:null);return}
  if(step>cur){talk("",["An iron lantern on a pole, with a ribbon round it. Its wick is cold and damp, and it won't take a match.","This one is waiting its turn. The trail has to be lit in order."]);return}
  if(cur===0&&!lntF("hm")){talk("",["An iron lantern on a pole, with a ribbon round it and nothing else to say for itself.","It's waiting for somebody who knows what it's for."]);return}
  lntSet("trail",cur+1);el.classList.add("lit");el.innerHTML=lntSvg(LNT_SVG.trail(true));lntFlash(el,"catch",900);if(gate("lntlight",600))sfx("whoomph");
  if(step===6){lntSet("lantern",1);talk("",["You light the last lantern on the trail, on top of Hollowmere Hill. Down below, all the windows of the village seem to brighten at once.","Somebody has left an old besom broom leaning against the tallest stone. Wound round its handle is a twist of bright, light metal, and it is very nearly flying off on its own.","There's a lantern hung on the besom too: a little carved neep in a cage of wire. It has your name on a luggage label."],()=>{say0("New: THE HOLLOWMERE LANTERN. Carry it from the wardrobe in the Institute's locker room.");lntBesom()});return}
  talk("",["You light the trail lantern. It catches with a soft whump, and the glass fills up with light.","There's a paper tag tied to the pole. It says:",`'${LNT_CLUES[step+1]}'`],()=>say0(`Lantern trail: ${step+1} of 7 lit. The clue is in your journal.`))}
function lntBesom(){if(lntGot("Besomite"))return;storyFight("Besomite",{intro:"It's trying to take off. Pin it down long enough to find out what it is!"})}

/* ---- the people of Hollowmere ---- */
const HM_LOOK={
 marlow:()=>({...MLOOK(),acc:["glasses","badge","scarf"]}),
 wren:{coat:"#4A3A2A",hair:"#1A1A1A",hs:"bun",acc:["glasses","book","scarf"],skin:"#C88A64"},
 dook:{coat:"#7A3A2A",hair:"#B8B0A8",hs:"bun",acc:["apron"],skin:"#F2C7A5"},
 shuffle:{coat:"#2A2A4A",hair:"#3A2414",hs:"curly",acc:["mustache","cap"],skin:"#8A5A3A"},
 memory:{coat:"#2A5A3A",hair:"#E8C878",hs:"long",acc:["scarf"],skin:"#F2D2B5"},
 sexton:{coat:"#1E1E24",hair:"#C8C8C8",hs:"bald",acc:["beard","lamp"],skin:"#E8B898"}};
const HM_STALLS={dook:{who:"Mrs. Applegarth",game:"Apple Dooking",a:"Dookite",tiles:[[12,8],[13,8],[12,9],[13,9]],
   hi:["Apple dooking! Hands behind your back, face in the tub, and bite one.","Three apples before you've had five goes at it, and the prize is yours. I'll hold your glasses."]},
 shuffle:{who:"Mr. Tobias Quartley",game:"Find the Lit Neep",a:"Rattlecart",tiles:[[22,8],[23,8],[22,9],[23,9]],
   hi:["Roll up! One lit candle, three neeps. Watch the light go under, watch my hands, and tell me where it's got to.","Two out of three and you take home a bit of the ghost train. Honest game. Mostly."]},
 memory:{who:"Miss Lumen Fairley",game:"Lantern Memory",a:"Festoonite",tiles:[[12,14],[13,14],[12,15],[13,15]],
   hi:["The lanterns will light up in an order. Light them again in the same order.","Three runs, each one longer. Get them all and the odd flag is yours."]}};
const HM_DOOR_P=[{who:"Mrs. Tolley",hi:"Guisers! Well, go on then, do your turn. A riddle'll do.",
   r:[["I'm hollowed out and given a grin, with a little fire living within. One night a year I come out to play. What am I?",["lantern","neep","turnip","jack","pumpkin"]],["The more of me there is, the less of anything you can see. What am I?",["dark","night","shadow","fog","mist"]],["I have a round orange face and a stalk for a hat, and on Lantern Night somebody always carves me a smile. What am I?",["pumpkin","jack","lantern"]]]},
 {who:"Granny Moffat",hi:"Oh, come in out of the cold! No treats without a turn, mind. Answer me this.",
   r:[["What has a face and two hands, but no arms and no legs?",["clock","watch"]],["What gets wetter the more it dries?",["towel","cloth","flannel","tea towel"]],["What has keys but can't open a single lock?",["piano","keyboard","typewriter","organ"]]]},
 {who:"Mr. Hamish Cairney",hi:"Aye? Guising, is it. Let's hear you, then.",
   r:[["I stand in the field all year in a coat that isn't mine, with a head full of straw, and I never once sit down. What am I?",["scarecrow","bogle","tattie"]],["What can fill a whole room, and take up no room at all?",["light","air","sound","smell","dark"]],["The more you take, the more you leave behind. What are they?",["footsteps","steps","footprints","prints"]]]},
 {who:"The Ormerod sisters",hi:"A guiser! Nell, a guiser! Quick, quick, do your turn, we've been waiting all night!",
   r:[["I follow you all day, but run from the lamp, and I'm at my longest when the sun's at its lowest. What am I?",["shadow"]],["What has a mouth but never eats, and a bed but never sleeps?",["river","stream","burn","brook"]],["What runs all round the garden without ever moving?",["fence","wall","hedge","path"]]]}];
const HM_TREAT=[["Ha! Very good. Here, hold your hands out.","She drops a twist of paper into them. It's far too heavy to be toffee."],
 ["Clever thing. Here you are, pet: a soul cake, and something that came out of the oven tray with it."],
 ["Not bad. Not bad at all. There's a coat-patch here I've no use for. Take it before it walks off."],
 ["YES! Nell, they got it! Here, here, we saved you the best one, it's been in the hearth all night!"]];
const lntNorm=s=>(s||"").toLowerCase().replace(/[^a-z ]/g," ").replace(/\s+/g," ").trim();
function lntGuise(i){const P=HM_DOOR_P[i],a=LNT_ALLOYS.find(o=>o.door===i).name,got=lntGot(a);
  const ri=(LS()["r"+i]||0)%P.r.length,[q,ok]=P.r[ri],go=()=>storyFight(a,{intro:"The twist of paper comes undone, and the thing inside wakes up. Identify it before it gets away!"});
  if(!got&&lntF("t"+i)){talk(P.who,["You didn't manage to hang on to that treat, did you? Never mind. You did your turn, it's still yours."],go);return}
  /* every door can be guised again: a new turn each time, and another treat for a good one */
  talk(P.who,[got?["Back again? Go on, then, a new turn for a new treat.","You again! I've a different one for you this time."][i%2]:P.hi,q],null,ans=>{const n=lntNorm(ans);
    if(ok.some(w=>n.split(" ").includes(w)||n===w||n.includes(w))){lntSet("t"+i,1);lntSet("r"+i,ri+1);if(gate("lntok",500))sfx("pickup");talk(P.who,got?["Ha! Very good. There's another twist of paper in the bowl with your name on it."]:HM_TREAT[i],go)}
    else{lntSet("r"+i,ri+1);if(gate("lntno",500))sfx("miss");talk(P.who,[n?`'${ans}'? Ha! No. Away and think of a better turn, and come back.`:"Nothing? No turn, no treat. Away and think about it, and come back."])}})}
/* ---- Dr. Marlow, Wren and the sexton ---- */
function lntMarlowTalk(m){const cur=lntTrail(),gw=lntF("gwOn")&&!lntGot(WW_NAME);
  if(!lntF("hm")){lntSet("hm",1);talk(m.n,[...(lntF("met")?["There you are! Welcome to Hollowmere, on Lantern Night."]:["You found the way down on your own! I was going to tell you about it. Welcome to Hollowmere, on Lantern Night."]),
   "Hollowmere keeps one night a year for lanterns, and somehow it keeps it going from the end of October to the middle of November. The village has never explained how. I stopped asking in 1974.",
   "They hang neep lanterns everywhere. I do mean everywhere: the mine, the cove, the crater. Light any you come across. They like that.",
   "And there's the lantern trail: iron lanterns on poles, one in each of six places, lit in order. Light one, and it tells you where the next one is.",
   "Here's the first. I had it off the sexton, and he had it off his grandmother:",`'${LNT_CLUES[0]}'`,
   "The fair's on the green, and every stall has a prize. The guisers are out as well: knock on a door, do your turn, and you might get a treat.",
   "Wren is over by the old storeroom. Something keeps turning up in the leaf piles round the village, and she's sure it's coming from in there.",
   "Enjoy yourself, recruit. It's only once a year."],()=>{say0("The lantern trail's first clue is in your journal.")});return}
  if(gw&&!lntF("gwTold")){lntSet("gwTold",1);talk(m.n,["Recruit. Look at the lanterns along the lane. Half of them are out, and nobody blew them out.","The village says it's the Gutterwick, every Lantern Night, drinking the light out of everything. I say something cold has been walking about, because it's left prints.","Whatever it is, it's after something, and it hasn't got it yet. Follow the prints from the bonfire and see where they stop."]);return}
  const L=[];if(gw)L.push("Those cold prints are still there. Follow them from the bonfire and see where they stop.");
  if(cur<7)L.push(cur===0?`The first trail clue: '${LNT_CLUES[0]}'`:`The trail's waiting on its next lantern. Remember what the last tag said: '${LNT_CLUES[cur]}'`);
  const st=Object.values(HM_STALLS).filter(s=>!lntGot(s.a)).length,dr=HM_DOOR_P.filter((p,i)=>!lntGot(LNT_ALLOYS.find(o=>o.door===i).name)).length;
  if(st)L.push(`${st===1?"One stall still has its prize":st+" stalls still have their prizes"} out on the green.`);if(dr)L.push(`${dr===1?"One door":dr+" doors"} along the lane ${dr===1?"hasn't":"haven't"} had a guiser yet.`);
  if(!L.length)L.push("You've done Hollowmere proud, recruit. Sit by the fire a while. It's only once a year.");talk(m.n,L)}
function lntWrenTalk(w){const n=LNT_LEAF().filter(a=>lntGot(a.name)).length;
  talk(w.n,n>=LNT_LEAF().length?[`${["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"][LNT_LEAF().length]}. Every one of the things from the leaf piles, registered.`+" I've written to the parish council. They wrote back asking if I'd seen their cat."]
   :["The storeroom was bricked up in 1932 with everything still in it. Somebody knocked a hole in the front wall last year to see what was inside.",`Things have been turning up in the leaf piles round the village ever since. ${["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"][LNT_LEAF().length]} different kinds, I'm fairly sure. ${n?`You've registered ${n}.`:"Have a rummage."}`,"There's an armchair in there under a dust sheet that I am NOT going to look under."])}
function lntSextonTalk(p){talk(p.n,lntF("gwOn")&&!lntGot(WW_NAME)?["It's out again. You'll know it by the cold prints and the lanterns it's drunk.","My grandmother used to say it never gets the last lantern. Something always stands over that one till morning.","The prints are never in the same place two nights running. Follow them while they're fresh."]
  :lntGot(WW_NAME)?["You found the thing that stands over the last lantern. Sixty years I've kept this kirkyard and I've never once seen it.","The Gutterwick's still out there, mind. Nobody's ever laid a hand on that. Folk say it doesn't walk about on its own any more."]
  :["Evening. I keep the kirkyard. Sixty Lantern Nights, man and boy.","Most folk light their neeps for the fun of it. Us old ones light them so the Gutterwick has something to drink besides us.","Don't look at me like that. It's a story. Mostly."])}

/* ---- laying out Hollowmere ---- */
const HM_GRAVES={"2,8":["HERE LIES ELSPETH GOW. SHE WAS RIGHT ABOUT THE WEATHER."],"5,9":["IN LOVING MEMORY OF THE TOFFEE PAN, 1911. IT IS NOT IN HERE. IT IS STILL IN USE."],"7,12":["ALBERT FINNEY-GAUNT. LIT EVERY LANTERN, EVERY YEAR, FOR SIXTY YEARS."],"3,13":["The stone's so worn you can only read one word of it: LANTERNS."]};
function hollowPlace(){const sp=SPOTS["z-hollow"],add=(x,y,use)=>{const o={x,y,use};EXP.objs.push(o);return o};
  EXP.npcs.forEach(p=>p.el&&p.el.remove());EXP.npcs=[];(EXP.grunts||[]).forEach(g=>g.el&&g.el.remove());EXP.grunts=[];
  HM_COTS.forEach(([x,y,v])=>lntEl("mapobj hm-big hm-cot",x,y,hmCottage(v),8,3));
  Object.entries(HM_STALLS).forEach(([k,s])=>{const[x,y]=s.tiles[0];lntEl("mapobj hm-big hm-stall",x,y,hmStall(k),2,2);s.tiles.forEach(([tx,ty])=>add(tx,ty,()=>lntStall(k)))});
  lntEl("mapobj hm-big hm-fire",16,11,hmBonfire(),3,2);[[16,11],[17,11],[18,11],[16,12],[17,12],[18,12]].forEach(([x,y])=>add(x,y,()=>talk("",["The Lantern Night bonfire. It's taller than a house, and it smells of toffee and wet leaves.","You warm your hands. It's very hard to leave."])));
  hmHole(add);
  HM_DOORS.forEach(([x,y],i)=>add(x,y,()=>lntGuise(i)));
  Object.entries(HM_SPOTS).forEach(([k,s])=>add(s.at[0],s.at[1],()=>lntSpot(k)));
  EXP.zone.map.forEach((r,y)=>r.split("").forEach((c,x)=>{if(c==="G")add(x,y,()=>talk("",HM_GRAVES[x+","+y]||["An old gravestone, lichen up to its shoulders. Someone has left a little neep lantern at its foot, unlit, and a sweet."]));
    if(c==="X")add(x,y,()=>talk("",["A standing stone, older than the village. The eclipse camp tied their tent ropes to it in 1927 and it hasn't forgiven them."]));
    if(c==="O")add(x,y,()=>talk("",["The tallest stone on Hollowmere Hill. A ring is carved into its face, with a second ring sliding across it: the eclipse, cut in stone."]));
    if(c==="b")add(x,y,()=>talk("",["A bench with a brass plaque: 'FOR SITTING AND WATCHING THE FIRE. NOT FOR STANDING ON TO SEE OVER PEOPLE.'"]));
    if(c==="J")add(x,y,()=>talk("",["A lamp post with a lantern hung on it, lit and swinging a little."]));
    if(c==="B"&&y===13&&(x===31||x===34))add(x,y,()=>talk("",["The storeroom's front wall, bricked up in 1932. Somebody has knocked a hole through it, and chalked beside the hole: OPENED AT LAST. PLEASE STOP ASKING."]))}));
  const P=(look,n,at,t)=>{const o=storyNPC({n,look,talks:[["..."]]},at);o.quest=()=>t(o);return o};
  P(HM_LOOK.marlow(),"Dr. Marlow",sp.marlow,lntMarlowTalk);P(HM_LOOK.wren,"Archivist Wren",sp.wren,lntWrenTalk);P(HM_LOOK.sexton,"Sexton Pyke",sp.sexton,lntSextonTalk);
  Object.entries(HM_STALLS).forEach(([k,s])=>P(HM_LOOK[k],s.who,sp[k],()=>lntStall(k)));
  lntGwPlace();lntNight();
  if(!lntF("hm"))setTimeout(()=>{if(inHollow()&&S.phase==="explore"&&!DLG.open&&!CS.on){const m=EXP.npcs.find(p=>p.n==="Dr. Marlow");if(m)lntMarlowTalk(m)}},900)}
{const _tt=talkTo;talkTo=function(p){if(p&&p.quest&&inHollow()){p.quest(p);return}_tt(p)}}
function lntSpot(k){const s=HM_SPOTS[k];
  if(EXP.gwSpot===k&&lntF("gwOn")&&!lntGot(WW_NAME)){if(gate("lntgw",800))sfx("alert");
    talk("",[`The cold prints stop a little way short of ${s.n}, as if whatever made them didn't dare go any closer.`,"Every lantern behind you is out. Here, one is still burning, and something tall with a crown of candles is standing over it. It turns its head and looks at your lantern."],()=>storyFight(WW_NAME,{intro:"It won't let your light anywhere near its lantern. Identify it before it slips off into the dark!"}));return}
  talk("",{yew:["The old yew in the kirkyard. It's older than the church, and it has seen every Lantern Night there has ever been. It's very cold underneath it."],
   hay:["A haystack on the hill, thatched against the rain. A good place to hide, if you didn't mind the hay."],
   tent:["The last tent of the 1927 eclipse camp, left standing as a memorial. It's patched with flour sacks, and it smells of mothballs."],
   chair:["Something armchair-shaped under a dust sheet. You decide you don't want to know.","It hasn't moved. You're nearly sure it hasn't moved."],
   well:["The village well. A bucket on a chain, and a long way down, a little round piece of night sky."]}[k])}
/* ---- the Gutterwick leaves a trail ---- */
function lntGwCheck(){if(lntF("gwOn")||!lntOn())return;const n=LNT_ALLOYS.filter(o=>lntGot(o.name)).length+lntTrail();if(n>=3)lntSet("gwOn",1)}
function lntGwPlace(){EXP.gwSpot=null;EXP.gwPath=null;EXP.gwSnuff=new Set;lntGwCheck();if(!lntF("gwOn")||lntGot(WW_NAME))return;
  const keys=Object.keys(HM_SPOTS),k=keys[Math.random()*keys.length|0],to=HM_SPOTS[k].from,from=[17,13];EXP.gwSpot=k;
  const W=EXP.W,H=EXP.H,key=(x,y)=>y*W+x,prev=new Map([[key(from[0],from[1]),-1]]),q=[from];
  for(let i=0;i<q.length;i++){const[x,y]=q[i];if(x===to[0]&&y===to[1])break;for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=H||prev.has(key(nx,ny))||!canWalk(tileAt(nx,ny)))continue;prev.set(key(nx,ny),key(x,y));q.push([nx,ny])}}
  const path=[];let c=key(to[0],to[1]);if(!prev.has(c))return;while(c!==-1){path.unshift([c%W,Math.floor(c/W)]);c=prev.get(c)}EXP.gwPath=path;
  path.forEach(([x,y],i)=>{if(i<1||i%2)return;const nx=path[Math.min(i+1,path.length-1)],ang=Math.atan2(nx[1]-y,nx[0]-x)*180/Math.PI+90;
    lntEl("mapobj lnt gwprint",x,y,lntSvg(`<g transform="rotate(${ang.toFixed(0)} 20 20)">${LNT_SVG.print()}</g>`))});
  (LNT_DECOR["z-hollow"]||[]).forEach(([kk,x,y])=>{if(kk==="neep"&&path.some(([px,py])=>Math.abs(px-x)+Math.abs(py-y)<=4))EXP.gwSnuff.add("z-hollow:"+x+","+y)});
  setTimeout(()=>{if(inHollow()&&!DLG.open)say0("Half the lanterns along the green have gone out. By the bonfire, something has left a line of cold, frosted prints.")},1400)}
/* ---- night: everything dims, and every lamp, window and lit neep throws its own pool of light ---- */
function lntNight(){let n=$("#lnt-night");if(!inHollow()){if(n)n.remove();return}if(!n){n=document.createElement("div");n.id="lnt-night";$("#world").appendChild(n)}
  const W=EXP.W,H=EXP.H,lit=lntLit(),L=[],at=(x,y,r,c)=>L.push(`radial-gradient(circle calc(var(--tp,40px)*${r}) at ${((x+.5)/W*100).toFixed(2)}% ${((y+.5)/H*100).toFixed(2)}%,${c} 0,${c.replace(/[\d.]+\)$/,"0)")} 100%)`);
  at(17,11.6,4.6,"rgba(255,214,150,1)");[[17,7],[12,11],[23,11]].forEach(([x,y])=>at(x,y-.6,2.4,"rgba(255,226,170,1)"));
  HM_COTS.forEach(([x,y,v])=>{const dx=[3,4,3,5][v],wx=dx<4?5.5:1.5;[wx,wx+1.2].forEach(o=>at(x+o,y+1.8,1.6,"rgba(255,214,150,.95)"));at(x+dx+1.6,y+2.6,1.1,"rgba(255,200,120,.9)")});
  (LNT_DECOR["z-hollow"]||[]).forEach(([k,x,y,s])=>{const key="z-hollow:"+x+","+y;if(k==="neep"&&lit.has(key)&&!lntSnuffed(key))at(x,y,1.5,"rgba(255,200,120,.95)");if(k==="trail"&&lntTrail()>s)at(x,y-1,2.2,"rgba(255,226,170,1)");if(k==="cand")at(x,y,1.1,"rgba(255,214,150,.9)")});
  at(36,22,1.6,"rgba(200,170,255,.8)");
  n.style.setProperty("--lights",L.join(","));n.style.background=`radial-gradient(circle calc(var(--tp,40px)*2) at var(--px,50%) var(--py,50%),rgba(235,225,255,.9) 0,rgba(235,225,255,0) 100%),${L.join(",")},#5A5E8E`;lntPlayerLight()}
function lntPlayerLight(){const n=$("#lnt-night");if(!n)return;n.style.setProperty("--px",((EXP.x+.5)/EXP.W*100).toFixed(2)+"%");n.style.setProperty("--py",((EXP.y+.5)/EXP.H*100).toFixed(2)+"%")}
/* ---- in the Institute: the hole, and Marlow telling you about it ---- */
function quillHole(){const[x,y]=QUILL_HOLE;lntEl("mapobj lnt hole",x,y,lntSvg(LNT_SVG.hole("quill")));
  EXP.objs.push({x,y,use:()=>talk("",["A hole has opened in the floor of the specimen hall, where the old Hollowmere display case used to stand. Round, black, and going down a long way.","A smell of bonfire comes up out of it, and very far below, music, and somebody laughing.","You climb down into the dark."],lntEnterHollow)})}
{const _wp=worldPlace;worldPlace=function(){_wp();const n=$("#lnt-night");if(n&&!inHollow())n.remove();EXP.bogles=[];
  if(!lntOn()||!EXP.zone||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;
  if(inHollow())hollowPlace();if(EXP.zone.cls==="z-quill")quillHole();lntDecorate();nearMarks();if(typeof depthPeople==="function")depthPeople()}}
{const _tt=talkTo;talkTo=function(p){const z=EXP.zone;
  if(p&&p.n==="Dr. Marlow"&&lntOn()&&!lntF("met")&&!lntF("hm")&&z&&z.cls==="z-quill"&&!z.special&&!(typeof TUT!=="undefined"&&TUT.on)&&p.el){lntSet("met",1);
    talk(p.n,["Ah, recruit! You'll have seen the hole in the floor of the specimen hall. Try not to fall in it by accident. It's much nicer to go in on purpose.",
      "It opens every year around now, where the old Hollowmere display case used to stand. It goes down to Hollowmere, on Lantern Night.",
      "Wren and I are going down now. I'll be popping up and down all fortnight, so don't be surprised to find me here as well. Lantern Night lasts until the fifteenth of November, then the hole closes until next year.",
      "Come down when you're ready. We'll be by the bonfire."],()=>{const w=EXP.npcs.find(q=>q.n==="Archivist Wren");
        npcTravel(p,[24,20],true,()=>{say0("Dr. Marlow climbed down the hole in the specimen hall.");if(w&&w.el)npcTravel(w,[26,22],true,()=>say0("Archivist Wren went down the hole after him, holding her notebook over her head."))})});return}
  _tt(p)}}

/* ---- the fair: three stalls, three games, three different skills (timing, watching, remembering) ---- */
function lntStall(k){const s=HM_STALLS[k];if(DLG.open)return;
  const got=lntGot(s.a);talk(s.who,got?["Back for another go? Win it again and there's another prize in it for you."]:s.hi,()=>lntGame(k,win=>{
    if(!win){const T={dook:["Ooh, so close! Dry your face and have another go.","Hard luck! The tub's not going anywhere."],shuffle:["Ha! Not under that one. Have another go, it's Lantern Night.","The hand is quicker than the eye. Have another go."],memory:["Nearly! The lanterns go quicker than you'd think. Have another go.","So close! Once more, and watch the order."]}[k];talk(s.who,[T[Math.random()*T.length|0]]);return}
    if(got){if(gate("lntok",500))sfx("pickup");talk(s.who,["Well done! There's always another off the same lot. Here, catch."],()=>storyFight(s.a,{intro:"It wriggles out of your hands as soon as you've got it. Identify it before it's off!"}));return}
    lntSet("w_"+k,1);if(gate("lntok",500))sfx("pickup");
    talk(s.who,{dook:["Three apples! You're soaked, and you've won. Here's the prize. Careful, it's still wet."],shuffle:["Well, I'll be. You've a sharp eye. Here: a shaving off the ghost train's wheels. It rattles."],memory:["Every one, in order! Here's the odd flag. It's been flapping about in my apron all evening."]}[k],
      ()=>storyFight(s.a,{intro:"It wriggles out of your hands as soon as you've got it. Identify it before it's off!"}))}))}
function lntGame(k,done){EXP.busy=true;let box=$("#lnt-mg");if(box)box.remove();box=document.createElement("div");box.id="lnt-mg";box.className="lnt-mg "+k;document.body.appendChild(box);
  const end=w=>{clearInterval(box._iv);cancelAnimationFrame(box._raf);document.removeEventListener("keydown",box._key);setTimeout(()=>{box.remove();EXP.busy=false;done(w)},w?900:700)};
  const head=(t,s)=>`<div class="lnt-mg-card"><h3>${t}</h3><p class="lnt-mg-msg" id="mg-msg">${s}</p><div class="lnt-mg-play" id="mg-play"></div><div class="lnt-mg-bar" id="mg-bar"></div><button class="btn" id="mg-quit">WALK AWAY</button></div>`;
  if(k==="dook")lntDook(box,head,end);else if(k==="shuffle")lntShuffle(box,head,end);else lntMemory(box,head,end);
  box.querySelector("#mg-quit").onclick=()=>end(false)}
function lntDook(box,head,end){box.innerHTML=head("APPLE DOOKING","Apples bob past your nose. DOOK when one is right under you. Three apples, five goes.");
  const pl=box.querySelector("#mg-play");pl.innerHTML=`<div class="dk-tub"><div class="dk-water"></div><div class="dk-mark"></div><div class="dk-face"></div></div><button class="btn go dk-go" id="dk-go">DOOK!</button>`;
  const tub=pl.querySelector(".dk-tub"),A=[];let got=0,tries=5,busy=false,last=performance.now();
  for(let i=0;i<4;i++){const e=document.createElement("i");e.className="dk-apple";tub.appendChild(e);A.push({e,x:Math.random(),v:(.12+Math.random()*.16)*(Math.random()<.5?-1:1),ph:Math.random()*6})}
  const bar=()=>box.querySelector("#mg-bar").textContent=`APPLES ${got}/3 · GOES LEFT ${tries}`;bar();
  const tick=t=>{const dt=Math.min(.05,(t-last)/1000);last=t;A.forEach(a=>{a.x+=a.v*dt*(1+got*.25);if(a.x<0){a.x=0;a.v=-a.v}if(a.x>1){a.x=1;a.v=-a.v}a.ph+=dt*3;a.e.style.left=(6+a.x*88)+"%";a.e.style.top=(52+Math.sin(a.ph)*5)+"%"});box._raf=requestAnimationFrame(tick)};box._raf=requestAnimationFrame(tick);
  const go=()=>{if(busy||tries<=0||got>=3)return;busy=true;tries--;tub.classList.remove("dip");void tub.offsetWidth;tub.classList.add("dip");
    const hit=A.find(a=>Math.abs(a.x-.5)<.045);setTimeout(()=>{busy=false;const m=box.querySelector("#mg-msg");
      if(hit){got++;hit.x=Math.random()<.5?0:1;if(gate("dkhit",200))sfx("pickup");m.textContent=got>=3?"THREE APPLES! You come up dripping and triumphant.":"Got one! Teeth in, head up, apple out."}
      else{if(gate("dkmiss",200))sfx("miss");m.textContent="A faceful of cold water and no apple."}
      bar();if(got>=3)end(true);else if(tries<=0)end(false)},420)};
  box.querySelector("#dk-go").onclick=go;box._key=e=>{if(e.key===" "||e.key==="Enter"){e.preventDefault();go()}};document.addEventListener("keydown",box._key)}
function lntShuffle(box,head,end){box.innerHTML=head("FIND THE LIT NEEP","Watch where the light goes. Then pick the neep it's under. Two right out of three wins.");
  const pl=box.querySelector("#mg-play");pl.innerHTML=`<div class="sh-table">${[0,1,2].map(i=>`<button class="sh-cup" data-i="${i}" disabled>${lntSvg(LNT_SVG.neep(false).replace(/<ellipse[^>]*\/>/,""))}</button>`).join("")}<i class="sh-candle"></i></div>`;
  const cups=[...pl.querySelectorAll(".sh-cup")],cand=pl.querySelector(".sh-candle");let pos=[0,1,2],lit=0,round=0,wins=0,miss=0;
  const place=()=>cups.forEach((c,i)=>c.style.left=(pos[i]*33.3+4)+"%");place();
  const bar=()=>box.querySelector("#mg-bar").textContent=`ROUND ${Math.min(round+1,3)}/3 · RIGHT ${wins} · WRONG ${miss}`;bar();
  const play=()=>{const m=box.querySelector("#mg-msg");m.textContent="Here's the candle... and under it goes.";lit=Math.random()*3|0;cand.style.left=(pos[lit]*33.3+15.5)+"%";cand.classList.add("on");cups.forEach(c=>c.classList.add("up"));
    setTimeout(()=>{cups.forEach(c=>c.classList.remove("up"));cand.classList.remove("on");let n=4+round*2,sp=520-round*130;
      const sw=()=>{if(n--<=0){m.textContent="Where's the light?";cups.forEach(c=>c.disabled=false);return}const a=Math.random()*3|0,b=(a+1+(Math.random()*2|0))%3,ia=pos.indexOf(a),ib=pos.indexOf(b);pos[ia]=b;pos[ib]=a;
        cups.forEach(c=>c.style.transitionDuration=sp+"ms");place();if(gate("shsw",120))sfx("step");setTimeout(sw,sp+40)};setTimeout(sw,500)},1300)};
  cups.forEach(c=>c.onclick=()=>{cups.forEach(q=>q.disabled=true);const i=+c.dataset.i,ok=i===lit;cand.style.left=(pos[lit]*33.3+15.5)+"%";cand.classList.add("on");cups[lit].classList.add("up");c.classList.add("up");
    if(ok)wins++;else miss++;if(gate("shp",200))sfx(ok?"pickup":"miss");box.querySelector("#mg-msg").textContent=ok?"There it is! Under that one.":"No! It was under that one.";round++;bar();
    setTimeout(()=>{cups.forEach(q=>q.classList.remove("up"));cand.classList.remove("on");if(wins>=2)end(true);else if(miss>=2)end(false);else setTimeout(play,500)},1300)});
  setTimeout(play,600)}
function lntMemory(box,head,end){box.innerHTML=head("LANTERN MEMORY","Watch the lanterns light up, then light them again in the same order. Three runs, each one longer.");
  const pl=box.querySelector("#mg-play"),C=["#E8412C","#F2C94C","#3A9AD8","#7A4A9A","#E8DCB8"];pl.innerHTML=`<div class="mm-row">${C.map((c,i)=>`<button class="mm-l" data-i="${i}" style="--c:${c}" disabled><i></i></button>`).join("")}</div>`;
  const L=[...pl.querySelectorAll(".mm-l")],tone=i=>{if(typeof AU!=="undefined"&&AU.on&&AU.sfxOn&&gate("mm"+i,120))sfx("sel")};let run=0,seq=[],at=0,spare=1;
  const bar=()=>box.querySelector("#mg-bar").textContent=`RUN ${Math.min(run+1,3)}/3 · ONE SPARE GO: ${spare?"YES":"USED"}`;bar();
  const flash=(i,ms)=>{L[i].classList.add("on");tone(i);setTimeout(()=>L[i].classList.remove("on"),ms)};
  const show=()=>{L.forEach(l=>l.disabled=true);box.querySelector("#mg-msg").textContent="Watch...";const ms=620-run*120;seq.forEach((i,k)=>setTimeout(()=>flash(i,ms*.7),500+k*ms));setTimeout(()=>{at=0;L.forEach(l=>l.disabled=false);box.querySelector("#mg-msg").textContent="Your turn."},500+seq.length*ms)};
  const next=()=>{seq=Array.from({length:3+run},()=>Math.random()*5|0);bar();show()};
  L.forEach(l=>l.onclick=()=>{const i=+l.dataset.i;flash(i,240);if(i!==seq[at]){L.forEach(q=>q.disabled=true);if(spare){spare=0;bar();box.querySelector("#mg-msg").textContent="Wrong lantern! One more try at that run.";setTimeout(show,900)}else{box.querySelector("#mg-msg").textContent="Wrong lantern!";end(false)}return}
    at++;if(at>=seq.length){L.forEach(q=>q.disabled=true);run++;if(run>=3){box.querySelector("#mg-msg").textContent="Every one, in order!";end(true)}else{box.querySelector("#mg-msg").textContent="That's it! Next run...";setTimeout(next,900)}}});
  setTimeout(next,500)}

/* ---- the journal: everything Lantern Night has on the go ---- */
{const _oj=openJournal;openJournal=function(){_oj();if(!lntOn())return;const m=$("#journal");if(!m)return;const list=m.querySelector(".bag-list");if(!list)return;
  const it=(t,p)=>{const d=document.createElement("div");d.className="bag-item key obj lnt-obj";d.innerHTML=`<b>${t}</b><p>${p}</p>`;return d},out=[],hm=lntF("hm");
  if(!hm)out.push(it("LANTERN NIGHT",lntF("met")?"Dr. Marlow and Archivist Wren went down the hole in the floor of the Institute's specimen hall. Lantern Night is on in Hollowmere until the end of 15 November.":"Something has opened in the floor of the Institute's specimen hall. Dr. Marlow will know what it is. Lantern Night lasts until the end of 15 November."));
  else{const cur=lntTrail();out.push(it("LANTERN NIGHT · THE TRAIL",cur>=7?"Every lantern on the trail is lit, all the way up to Hollowmere Hill.":`Lanterns lit: ${cur} of 7. ${cur?"The last tag said":"Dr. Marlow's clue"}: '${LNT_CLUES[cur]}'`));
    if(cur>=7&&!lntGot("Besomite"))out.push(it("LANTERN NIGHT · THE BESOM","Something is still wound round the besom on top of Hollowmere Hill."));
    const st=Object.values(HM_STALLS).filter(s=>!lntGot(s.a));if(st.length)out.push(it("LANTERN NIGHT · THE FAIR",`Prizes still to win on the green: ${st.map(s=>s.game).join(", ")}.`));
    const dr=HM_DOOR_P.filter((p,i)=>!lntGot(LNT_ALLOYS.find(o=>o.door===i).name));if(dr.length)out.push(it("LANTERN NIGHT · GUISING",`${dr.length===1?"One door":dr.length+" doors"} along Hollowmere's lane still to guise at. Do your turn, get your treat.`));
    const lf=LNT_LEAF().filter(a=>!lntGot(a.name)).length;if(lf)out.push(it("LANTERN NIGHT · THE LEAF PILES",`Archivist Wren thinks ${LNT_LEAF().length} different things are hiding in Hollowmere's leaf piles. ${LNT_LEAF().length-lf} registered so far.`));
    if(lntF("gwOn")&&!lntGot(WW_NAME))out.push(it("LANTERN NIGHT · THE COLD PRINTS","Something is putting out the lanterns in Hollowmere and leaving cold prints behind. Follow them from the bonfire and see where they stop."))}
  const all=LNT_NEEPS(),n=all.filter(q=>lntLit().has(q)).length;out.push(it("LANTERN NIGHT · NEEPS",n>=all.length?`Every neep lantern on every map is lit (${n} of ${all.length}).`:`Neep lanterns lit across the maps: ${n} of ${all.length}. They're hung everywhere for Lantern Night.`));
  const none=list.querySelector(".obj-none");if(none)none.remove();const kids=[...list.children],lastObj=kids.filter(e=>e.classList.contains("obj")&&!e.classList.contains("fav")).pop(),after=lastObj?lastObj.nextSibling:list.firstChild;out.forEach(e=>list.insertBefore(e,after))}}
/* ---- the Hollowmere Lantern: carried, from the wardrobe ---- */
const lntCarry=()=>lntF("lantern")&&store.get("wta_lnt_carry",0)===1;
const LNT_CARRY_SVG=`<g class="lnt-carry"><path d="M10.6 32.2 V34" stroke="#2A2A30" stroke-width=".5"/><g class="lnt-swing" style="transform-origin:10.6px 32.4px"><circle cx="10.6" cy="36.6" r="3.6" fill="#FFB43A" opacity=".25"/><path d="M8.2 34.6 Q8 38.6 10.6 38.8 Q13.2 38.6 13 34.6 Q10.6 33.6 8.2 34.6 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width=".45"/><path d="M9.2 35.8 L9.9 35.3 L10.1 36.1 Z M11.1 36.1 L11.3 35.3 L12 35.8 Z M9.3 37.2 Q10.6 38.2 11.9 37.2" stroke="#FFB43A" stroke-width=".5" fill="#FFB43A"/></g></g>`;
{const _ps=playerSVG;playerSVG=function(c){const s=_ps(c);return lntCarry()?s+LNT_CARRY_SVG:s}}
{const _ow=openWardrobe;openWardrobe=function(){_ow();if(!lntF("lantern"))return;const m=$("#wardrobe");if(!m)return;const L=m.querySelector(".bag-list");if(!L)return;const on=lntCarry();
  L.insertAdjacentHTML("beforeend",`<h5 class="bag-h">LANTERNS</h5><div class="bag-item coat${on?" on":""}"><div class="coatpv"><svg viewBox="0 0 40 40">${LNT_SVG.neep(true)}</svg></div><div><b>The Hollowmere Lantern</b><p>A little carved neep in a cage of wire, from the top of Hollowmere Hill. Its candle never seems to burn down, and it grins at everybody.</p></div><button class="btn${on?"":" go"}" data-lnt="1">${on?"PUT DOWN":"CARRY"}</button></div>`);
  L.querySelector("[data-lnt]").onclick=()=>{store.set("wta_lnt_carry",on?0:1);sfx("sel");coatRefresh();openWardrobe();say0(on?"You hang the Hollowmere Lantern back up in the wardrobe.":"You pick up the Hollowmere Lantern. It grins at the mirror.")}}}
/* ---- music: Hollowmere's own take on the theme, and the Gutterwick's ---- */
TRACKS["explore_z-hollow"]={base:"explore",bpm:92,swing:.33,lead:{type:"triangle",vol:.2},parts:[{k:"broken",type:"sine",vol:.07,oct:3},{k:"counter",type:"pulse",vol:.03,oct:5}],bass:{s:"walk",vol:.24},drum:"k . . h s . h .",fill:"k . s . k s c c",chime:true};
TRACKS["threat_gutter"]={base:"threat",bpm:112,swing:.22,lead:{type:"sine",vol:.24,stac:true},parts:[{k:"broken",type:"triangle",vol:.06,oct:4},{k:"pad",type:"sawtooth",vol:.015,oct:3}],bass:{s:"walk",type:"square",vol:.1},drum:"k . h . s . h k",fill:"k . s s k s c c",chime:true};
TLOOK[GW_NAME]={k:"gutter",a:"#140E22",b:"#06040C",core:"255,190,110",tag:"fire",tagc:"#FFB43A",part:"mote",part2:"ember"};

/* =============== THE GUTTERWICK: LIGHTS OUT ===============
   While it's loose the whole lab goes DARK, and the only light is your lantern, which follows your pointer (or your finger).
   Its eyes hunt your light across the screen. SHUTTER the lantern when they get close and it loses you; if it reaches the light,
   it drinks it: your lantern goes out, it spills your oil, and containment takes the hit. The oil burns down while the lantern's open,
   faster with the wick turned HIGH; turn it LOW to make it last, and top up from the OIL flasks, which refill slowly.
   Below half containment it WAKES: it moves faster, and throws a second, false pair of eyes. Only the real ones catch your light. */
BOSS[GW_NAME]={act:"LIGHTS OUT",tell:"It drinks light. While it's loose the lab is DARK: you only see what your LANTERN shows you, and the lantern follows your pointer. Its eyes hunt your light. SHUTTER the lantern when they come close and it loses you; if it reaches your light, it drinks it and leaves you in the dark. Oil burns down: turn the WICK low to make it last, and top up from your OIL flasks.",drain:.3};
const GW={oilHi:2.5,oilLo:1.0,flaskIn:22,flask:48,rHi:175,rLo:100,drink:.8,outFor:4};
const gwOn=()=>TB.on&&TB.a&&TB.a.name===GW_NAME&&TB.gw;
function gwPt(e){if(!TB.gw)return;const p=e.touches?e.touches[0]:e;if(!p)return;TB.gw.lx=p.clientX;TB.gw.ly=p.clientY}
{const _bs=bossStart;bossStart=function(){_bs();if(!(TB.on&&TB.a.name===GW_NAME))return;const W=innerWidth,H=innerHeight;
  TB.gw={oil:100,flasks:2,flaskIn:GW.flaskIn,wick:"hi",shut:false,out:0,dry:false,woke:false,lx:W/2,ly:H/2,last:performance.now(),hud:0,
    eyes:[{x:W*.15,y:H*.2,real:true,drink:0,wx:W*.2,wy:H*.3,wt:0,jt:2}],fol:[],folT:(typeof TUT!=="undefined"&&TUT.on)?22:13,shutFor:0};
  let d=$("#gw-dark");if(!d){d=document.createElement("div");d.id="gw-dark";document.body.appendChild(d)}
  let e=$("#gw-eyes");if(!e){e=document.createElement("div");e.id="gw-eyes";document.body.appendChild(e)}
  e.innerHTML=TB.gw.eyes.map((q,i)=>`<i class="gw-eye${q.real?" real":""}" data-i="${i}">${gwEyeSVG()}</i>`).join("");
  TB.gw.mv=ev=>gwPt(ev);addEventListener("pointermove",TB.gw.mv,{passive:true});addEventListener("pointerdown",TB.gw.mv,{passive:true});
  const bb=$("#bossbar");if(bb)bb.classList.add("gw");bossControls();bossHud();cancelAnimationFrame(gwLoop.raf);gwLoop.raf=requestAnimationFrame(gwLoop)}}
const gwEyeSVG=()=>`<svg viewBox="-30 -14 60 28" aria-hidden="true"><ellipse cx="-12" cy="0" rx="9" ry="6" fill="#FFE6A0"/><ellipse cx="12" cy="0" rx="9" ry="6" fill="#FFE6A0"/><ellipse cx="-12" cy="0" rx="2.6" ry="5" fill="#1A0A04"/><ellipse cx="12" cy="0" rx="2.6" ry="5" fill="#1A0A04"/><circle class="gw-glint" cx="-9" cy="-2" r="1.6" fill="#fff"/><circle class="gw-glint" cx="15" cy="-2" r="1.6" fill="#fff"/></svg>`;
function gwCleanup(){const g=TB.gw;if(g&&g.mv){removeEventListener("pointermove",g.mv);removeEventListener("pointerdown",g.mv)}["#gw-dark","#gw-eyes"].forEach(s=>{const e=$(s);if(e)e.remove()});const bb=$("#bossbar");if(bb)bb.classList.remove("gw");cancelAnimationFrame(gwLoop.raf);TB.gw=null}
{const _be=bossEnd;bossEnd=function(){if(TB.gw)gwCleanup();_be()}}
{const _bc=bossControls;bossControls=function(){_bc();if(!gwOn())return;const c=$("#bb-ctrl");
  c.innerHTML=`<button class="bb-btn gw-shut" id="gw-shut">SHUTTER</button><button class="bb-btn" id="gw-wick">WICK: HIGH</button><button class="bb-btn" id="gw-oilb">OIL ×2</button><div class="bb-gauge"><span>OIL</span><div><i id="gw-oil"></i></div></div><span class="bb-info" id="bb-info"></span>`;
  $("#gw-shut").onclick=()=>{const g=TB.gw;if(!g)return;g.shut=!g.shut;if(gate("gwsh",250))sfx("clunk");if(!g.shut)g.eyes.forEach(q=>q.drink=0);bossHud()};
  $("#gw-wick").onclick=()=>{const g=TB.gw;if(!g)return;g.wick=g.wick==="hi"?"lo":"hi";if(gate("gwwk",300))sfx("sel");bossHud()};
  $("#gw-oilb").onclick=()=>{const g=TB.gw;if(!g||g.flasks<=0)return;g.flasks--;g.oil=Math.min(100,g.oil+GW.flask);g.dry=false;if(gate("gwoil",400))sfx("pickup");say(g.flasks?`You top up the lantern. (${g.flasks} flask left)`:`That was your last flask. The next is ${GW.flaskIn} seconds off.`);bossHud()}}}
{const _bh=bossHud;bossHud=function(){_bh();if(!gwOn()||!$("#gw-oil"))return;const g=TB.gw,o=$("#gw-oil");o.style.width=g.oil+"%";o.className=g.oil<20?"hot":g.oil<45?"warm":"";
  const s=$("#gw-shut");s.textContent=g.shut?"OPEN LANTERN":"SHUTTER";s.classList.toggle("on",g.shut);$("#gw-wick").textContent=g.wick==="hi"?"WICK: HIGH":"WICK: LOW";
  const f=$("#gw-oilb");f.disabled=g.flasks<=0;f.textContent=g.flasks?`OIL ×${g.flasks}`:`OIL · ${Math.ceil(g.flaskIn)}s`;
  const close=g.eyes.some(q=>q.real&&q.drink>0);$("#bb-info").textContent=(g.out>0?`LANTERN OUT ${Math.ceil(g.out)}s · `:g.dry?"OUT OF OIL · ":g.shut?"Shuttered: you're hidden, and blind · ":close?"IT'S AT YOUR LIGHT! SHUTTER! · ":"")+(g.fol&&g.fol.length?`${g.fol.length===1?"Another shadow has":g.fol.length+" shadows have"} followed it in.`:"Watch the eyes.")}}
function gwLoop(t){gwLoop.raf=requestAnimationFrame(gwLoop);const g=TB.gw;if(!g||!TB.on||!TB.a||TB.a.name!==GW_NAME){gwCleanup();return}
  const dt=Math.min(.05,(t-g.last)/1000);g.last=t;const dk=$("#gw-dark"),ey=$("#gw-eyes");if(!dk||!ey)return;
  const live=bossActive()&&S.r.stage==="elements"&&!document.hidden&&$("#stage").offsetParent!==null;
  const fade=TB.grace>0?Math.max(0,1-TB.grace/3.2):1;dk.style.opacity=live?fade:0;ey.style.opacity=live?fade:0;if(!live||TB.grace>0)return;
  const W=innerWidth,H=innerHeight;
  if(g.flasks<2&&(g.flaskIn-=dt)<=0){g.flasks++;g.flaskIn=GW.flaskIn;if(gate("gwfl",800))sfx("sel")}
  if(g.out>0)g.out=Math.max(0,g.out-dt);
  if(!g.shut&&g.out<=0&&g.oil>0){g.oil=Math.max(0,g.oil-(g.wick==="hi"?GW.oilHi:GW.oilLo)*dt);if(g.oil<=0&&!g.dry){g.dry=true;sfx("miss");say("Your lantern has burned dry! Top it up with OIL.")}}
  const r=g.shut?0:g.out>0?24:g.dry?30:g.wick==="hi"?GW.rHi:GW.rLo,lit=r>40;
  dk.style.setProperty("--x",g.lx+"px");dk.style.setProperty("--y",g.ly+"px");dk.style.setProperty("--r",Math.max(1,r)+"px");
  if(!g.woke&&TB.hp<55){g.woke=true;sfx("siren");stageFx("fumes");gwFollow(g,true);say("IT WAKES! It's faster now, and the other shadows in the room have started doing whatever it does.")}
  /* the others follow its lead: every so often another shadow comes up out of the dark at the edge of the room */
  if((g.folT-=dt)<=0){g.folT=(typeof TUT!=="undefined"&&TUT.on)?26:15;gwFollow(g)}
  const els=ey.querySelectorAll(".gw-eye");
  g.eyes.forEach((q,i)=>{const sp=(g.woke?150:105)*(q.real?1:1.15);let tx,ty;
    if(lit){tx=g.lx;ty=g.ly}else{if((q.wt-=dt)<=0){q.wt=2+Math.random()*1.5;q.wx=40+Math.random()*(W-80);q.wy=40+Math.random()*(H-80)}tx=q.wx;ty=q.wy}
    const dx=tx-q.x,dy=ty-q.y,d=Math.hypot(dx,dy)||1,step=Math.min(d,(lit?sp:60)*dt);q.x+=dx/d*step;q.y+=dy/d*step;
    /* it's an erratic one: every so often it jinks sideways, all at once, without crossing the space between */
    if(q.real&&lit&&(q.jt-=dt)<=0){q.jt=1.2+Math.random()*2.2;const a=Math.atan2(dy,dx)+(Math.random()<.5?1:-1)*Math.PI/2,j=60+Math.random()*80;q.x=Math.max(20,Math.min(W-20,q.x+Math.cos(a)*j));q.y=Math.max(20,Math.min(H-20,q.y+Math.sin(a)*j))}
    const near=lit&&q.real&&Math.hypot(g.lx-q.x,g.ly-q.y)<r*.55;q.drink=near?q.drink+dt:Math.max(0,q.drink-dt*2);
    const el=els[i];if(el){el.style.transform=`translate(${q.x.toFixed(0)}px,${q.y.toFixed(0)}px) scale(${(1+q.drink*.6).toFixed(2)})`;el.classList.toggle("lit",lit&&Math.hypot(g.lx-q.x,g.ly-q.y)<r*1.6);el.classList.toggle("drink",q.drink>0)}
    if(q.real&&q.drink>=GW.drink){q.drink=0;g.out=GW.outFor;gwFollow(g);g.oil=Math.max(0,g.oil-18);hurt(9);sfx("hiss");stageFx("shake");say("It reached your light and DRANK it. Your lantern's out, and it's spilled your oil!");
      const s=Math.random()*4|0;q.x=s===0?20:s===1?W-20:Math.random()*W;q.y=s===2?20:s===3?H-20:Math.random()*H}});
  gwFollowers(g,dt,lit,r,W,H);
  if(g.out>0||g.dry){TB.hp-=.22*dt*DRAIN_SCALE*(typeof TUT!=="undefined"&&TUT.on?.5:1);if(TB.hp<=0){bossBreach("CONTAINMENT BREACH! In the dark, the Gutterwick slipped out of the vial and away up the chimney!");return}}
  if((g.hud+=dt)>.25){g.hud=0;bossHud()}}
/* ---- the shadows that follow its lead ----
   They come up out of the dark at the edge of the room, one at a time, never more than three. They don't hunt your light on their own:
   they go where the Gutterwick goes, a little behind it, fanned out around it. When it's at your light, so are they, and every one of
   them in your light drinks your oil and wears at containment. Shutter the lantern and they lose you, and the ones that lose you for
   long enough go back down into the dark. */
function gwFollow(g,force){const max=(typeof TUT!=="undefined"&&TUT.on)?1:3;if(!g.fol||g.fol.length>=max)return;const ey=$("#gw-eyes");if(!ey)return;const W=innerWidth,H=innerHeight;
  const side=Math.random()*4|0,x=side===0?30:side===1?W-30:60+Math.random()*(W-120),y=side===2?60:side===3?H-60:100+Math.random()*(H-200);
  const k=(g.fol.length+(Math.random()*3|0))%SHADE_KINDS.length,el=document.createElement("i");el.className="gw-fol rise";
  el.innerHTML=`<span class="fol-body">${shadeSVG(SHADE_KINDS[k])}</span><span class="fol-eyes"><b></b><b></b></span>`;ey.appendChild(el);setTimeout(()=>el.classList.remove("rise"),1300);
  g.fol.push({x,y,el,ang:Math.random()*6.283,lag:.55+Math.random()*.3,gone:false});if(!force&&!g.folSaid){g.folSaid=1;say("Another shadow has come up out of the dark, and it's doing exactly what the Gutterwick does.")}}
function gwFollowers(g,dt,lit,r,W,H){if(!g.fol||!g.fol.length)return;const L=g.eyes.find(q=>q.real);if(!L)return;
  g.shutFor=g.shut||g.out>0?g.shutFor+dt:0;
  g.fol=g.fol.filter(f=>{if(f.gone)return false;
    /* lost you for long enough: it goes back down into the dark */
    if(g.shutFor>3&&Math.random()<dt*.25){f.gone=true;f.el.classList.add("go");setTimeout(()=>f.el.remove(),1300);return false}
    f.ang+=dt*.6;const ox=Math.cos(f.ang)*90,oy=Math.sin(f.ang)*55,tx=L.x+ox,ty=L.y+oy,dx=tx-f.x,dy=ty-f.y,d=Math.hypot(dx,dy)||1,sp=(g.woke?130:95)*f.lag;
    const st=Math.min(d,sp*dt);f.x+=dx/d*st;f.y+=dy/d*st;
    const dl=Math.hypot(g.lx-f.x,g.ly-f.y);
    if(lit&&dl<r*.55){g.oil=Math.max(0,g.oil-5*dt);TB.hp-=.06*dt*DRAIN_SCALE*(typeof TUT!=="undefined"&&TUT.on?.5:1)}
    const vis=lit?Math.max(.1,Math.min(1,1.25-dl/(r*1.6))):.1;
    f.el.style.transform=`translate(${(f.x-48).toFixed(0)}px,${(f.y-24).toFixed(0)}px)`;const b=f.el.firstElementChild;if(b)b.style.opacity=vis.toFixed(2);return true})}
/* the specimen: the vial stood in a carved neep on a dyke on the moor, at night, with a flame that burns backwards coming out of its mouth */
{const _tf=threatFx;threatFx=function(host,a,mini){if(!a||a.name!==GW_NAME)return _tf(host,a,mini);const svg=host&&host.querySelector("svg");if(!svg||svg.querySelector(".tfx"))return;
  const U="gw"+(threatFx.n=(threatFx.n||0)+1),R=mulberry(41+(threatFx.n||0)),rn=(x,y)=>(x+R()*(y-x)).toFixed(1);svg.style.overflow="visible";
  let back=`<defs><linearGradient id="${U}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#05040E"/><stop offset=".6" stop-color="#1A1438"/><stop offset="1" stop-color="#3A2A4A"/></linearGradient><radialGradient id="${U}m" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#F4ECD0"/><stop offset=".7" stop-color="#E8DCB0"/><stop offset="1" stop-color="#E8DCB0" stop-opacity="0"/></radialGradient></defs>
    <rect x="-260" y="-200" width="820" height="640" fill="url(#${U}s)"/>`;
  for(let i=0;i<40;i++)back+=`<circle cx="${rn(-240,540)}" cy="${rn(-190,120)}" r="${rn(.6,1.8)}" fill="#E8E4FF"><animate attributeName="opacity" values=".2;1;.3" dur="${rn(1.5,4)}s" repeatCount="indefinite"/></circle>`;
  back+=`<circle cx="420" cy="-90" r="46" fill="url(#${U}m)"/><path d="M-260 200 Q-60 150 100 186 Q260 220 400 170 Q480 150 560 176 L560 440 L-260 440 Z" fill="#1A1622"/>`;
  back+=`<path d="M-260 236 H560 V440 H-260 Z" fill="#2A2420"/>`;for(let row=0;row<3;row++)for(let x=-260+(row%2)*30;x<560;x+=60)back+=`<path d="M${x} ${236+row*22} q30 -12 58 0 q-4 18 -30 20 q-26 -2 -28 -20 Z" fill="${["#4A4440","#3E3834","#56504A"][(row+x/60|0)%3]}" stroke="#141010" stroke-width="2"/>`;
  /* the Gutterwick: one of the shadow people has got into a vial, and now it's coming back out of it. The liquid inside has turned to ink;
     out of the open neck pours a thin, gaunt shadow, all neck and arms, its small head bent forward over the glass with two pinprick eyes
     and a grin with far too many teeth. Its arms reach down round the outside and its long fingers grip the front of the glass. Ink runs
     down the sides and pools on the ground, and somewhere in the bottom of the vial the last of a candle flame is going out. */
  const SM=`stroke-linecap="round" stroke-linejoin="round"`,K="#050409",ink=`url(#${U}k)`;
  let box=`<defs><filter id="${U}k" filterUnits="userSpaceOnUse" x="-40" y="-140" width="380" height="420"><feGaussianBlur in="SourceGraphic" stdDeviation=".8" result="d"/>
      <feGaussianBlur in="SourceAlpha" stdDeviation="7" result="b"/><feFlood flood-color="#050409" flood-opacity=".7"/><feComposite in2="b" operator="in" result="halo"/><feMerge><feMergeNode in="halo"/><feMergeNode in="d"/></feMerge></filter>
     <filter id="${U}f" x="-50%" y="-100%" width="200%" height="300%"><feGaussianBlur stdDeviation="12"/></filter><radialGradient id="${U}a" cx=".5" cy=".4" r=".5"><stop offset="0" stop-color="#B8B0D8" stop-opacity=".78"/><stop offset=".45" stop-color="#8A80B8" stop-opacity=".5"/><stop offset=".75" stop-color="#4A4278" stop-opacity=".22"/><stop offset="1" stop-color="#2A2056" stop-opacity="0"/></radialGradient>
     <radialGradient id="${U}p" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#030208" stop-opacity=".95"/><stop offset=".6" stop-color="#06040E" stop-opacity=".7"/><stop offset="1" stop-color="#06040E" stop-opacity="0"/></radialGradient>
     <linearGradient id="${U}i" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0A0716" stop-opacity=".85"/><stop offset="1" stop-color="#030208" stop-opacity=".97"/></linearGradient></defs>
    <ellipse cx="150" cy="30" rx="150" ry="170" fill="url(#${U}a)"/><g opacity=".4" filter="url(#${U}f)">${[[50,160,80],[110,176,70],[240,132,70],[200,186,90],[150,206,110],[300,170,60],[0,140,60]].map(([x,y,r])=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.3}" fill="#C8C4E0"/>`).join("")}</g>
    <g filter="${ink}"><ellipse cx="150" cy="232" rx="96" ry="14" fill="${K}"/>${[[-1,74,248],[1,82,246],[-1,30,252],[1,40,254]].map(([d,l,y])=>`<path d="M${150+d*40} 232 Q${150+d*(40+l*.6)} ${y-6} ${150+d*(40+l)} ${y} Q${150+d*(40+l*.5)} ${y+5} ${150+d*30} 238 Z" fill="${K}"/>`).join("")}</g>`;
  /* in front of the glass */
  let f=`<path d="M118 120 Q150 108 182 120 L182 196 Q182 222 150 222 Q118 222 118 196 Z" fill="url(#${U}i)"/><path d="M118 64 L182 64 L182 120 Q150 108 118 120 Z" fill="#0A0716" opacity=".55"/>
    <g opacity=".75"><path d="M130 206 Q138 172 152 186 Q166 198 172 164 Q176 146 160 134" stroke="#1A1230" stroke-width="10" fill="none" stroke-linecap="round"><animate attributeName="d" values="M130 206 Q138 172 152 186 Q166 198 172 164 Q176 146 160 134;M132 202 Q146 178 156 190 Q168 196 168 158 Q170 142 154 138;M130 206 Q138 172 152 186 Q166 198 172 164 Q176 146 160 134" dur="5s" repeatCount="indefinite"/></path></g>
    <g transform="translate(150 200)"><circle r="7" fill="#FFB43A" opacity=".12"><animate attributeName="opacity" values=".14;.04;.12;.02;.14" dur="1.8s" repeatCount="indefinite"/></circle><path d="M0 2 Q-3 -3 0 -8 Q3 -3 0 2 Z" fill="#FFD890"><animate attributeName="opacity" values=".9;.3;.7;.15;.9" dur="1.8s" repeatCount="indefinite"/></path></g>
    <g filter="${ink}" fill="${K}">
     ${[[113,44,70],[116,46,118],[184,46,92],[187,44,150],[121,48,34],[180,48,46]].map(([x,y,l],i)=>`<path d="M${x-2.6} ${y} Q${x-2.2} ${y+l*.6} ${x} ${y+l} Q${x+2.2} ${y+l*.6} ${x+2.6} ${y} Z"/><circle cx="${x}" cy="${y+l+3.4}" r="3"/>`).join("")}
     <path d="M106 54 Q100 36 116 24 Q130 12 150 14 Q170 12 184 24 Q200 36 194 54 Q170 60 150 58 Q130 60 106 54 Z"/><path d="M134 32 Q138 14 136 -2 Q132 -18 120 -30 Q124 -40 150 -42 Q176 -40 180 -30 Q168 -18 164 -2 Q162 14 166 32 Z"/>
     <path d="M146 -38 Q146 -50 152 -58 Q158 -64 164 -66" stroke="${K}" stroke-width="10" fill="none" ${SM}/>
     <path d="M124 -34 Q100 -30 88 -8 Q80 8 82 26" stroke="${K}" stroke-width="11" fill="none" ${SM}/><path d="M82 26 Q84 70 102 104 Q108 116 114 124" stroke="${K}" stroke-width="7.5" fill="none" ${SM}/>
     <path d="M176 -34 Q200 -30 212 -8 Q220 8 218 26" stroke="${K}" stroke-width="11" fill="none" ${SM}/><path d="M218 26 Q216 70 198 104 Q192 116 186 124" stroke="${K}" stroke-width="7.5" fill="none" ${SM}/>
     <circle cx="82" cy="26" r="5.4"/><circle cx="218" cy="26" r="5.4"/>
     <ellipse cx="114" cy="128" rx="6" ry="8"/>${[0,1,2,3].map(k=>`<path d="M114 ${122+k*4.6} L${126+k*1.6} ${120+k*7} L${138+k*.8} ${126+k*8} L${142} ${134+k*8}" stroke="${K}" stroke-width="${3.6-k*.35}" fill="none" ${SM}/>`).join("")}
     <ellipse cx="186" cy="128" rx="6" ry="8"/>${[0,1,2,3].map(k=>`<path d="M186 ${122+k*4.6} L${174-k*1.6} ${120+k*7} L${162-k*.8} ${126+k*8} L${158} ${134+k*8}" stroke="${K}" stroke-width="${3.6-k*.35}" fill="none" ${SM}/>`).join("")}
     <g transform="rotate(18 168 -74)"><path d="M168 -60 Q156 -62 155 -76 Q156 -92 168 -92 Q180 -92 181 -76 Q180 -62 168 -60 Z"/></g></g>
    <path d="M136 -2 Q132 -18 120 -30 Q124 -40 150 -42 Q176 -40 180 -30 Q168 -18 164 -2 M124 -34 Q100 -30 88 -8 Q80 8 82 26 Q84 70 102 104 M176 -34 Q200 -30 212 -8 Q220 8 218 26 Q216 70 198 104 M116 24 Q130 12 150 14 Q170 12 184 24" stroke="#8A78D0" stroke-width="2" fill="none" opacity=".55"/><path d="M140 -16 Q150 -12 160 -16 M139 -6 Q150 -2 161 -6 M140 4 Q150 8 160 4" stroke="#1A1430" stroke-width="1.6" fill="none"/>
    <g transform="rotate(18 168 -74)">
     <g filter="url(#shdG)"><g class="gweyes"><circle cx="163" cy="-80" r="1.9" fill="#FFFFFF"/><circle cx="173" cy="-80" r="1.9" fill="#FFFFFF"/><animate attributeName="opacity" values="1;1;0;1;1;1;0;1" keyTimes="0;.62;.65;.68;.88;.9;.92;1" dur="4.2s" repeatCount="indefinite"/></g></g>
     <path d="M158 -72 Q168 -78 178 -72 Q176 -60 168 -59 Q160 -60 158 -72 Z" fill="#0A0814"/><path d="M159.2 -71.4 Q168 -76.6 176.8 -71.4 Q175 -61.6 168 -60.8 Q161 -61.6 159.2 -71.4 Z" fill="#EEEAF2"/>
     <path d="M159.8 -67.6 Q168 -64.4 176.2 -67.6" stroke="${K}" stroke-width=".7" fill="none"/>${Array.from({length:8},(_,k)=>{const x=160.4+k*2.2;return`<path d="M${x} ${-75+Math.abs(k-3.5)*.5} L${x+.2} ${-61.6-Math.abs(k-3.5)*.4}" stroke="${K}" stroke-width=".8"/>`}).join("")}</g>`;
  /* the dark coming up off it */
  for(let i=0;i<6;i++){const x=rn(126,176),y=rn(-50,30),d=rn(2.6,4.6),b=rn(0,4);f+=`<path d="M${x} ${y} q-6 -9 0 -18 q6 -8 0 -16" stroke="#0E0A1A" stroke-width="${rn(4,7)}" fill="none" stroke-linecap="round" opacity="0"><animate attributeName="opacity" values="0;.6;0" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/><animateTransform attributeName="transform" type="translate" values="0 4;${rn(-6,6)} -24" dur="${d}s" begin="-${b}s" repeatCount="indefinite"/></path>`}
  svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${box}</g>`);
  if(!mini){const cont=host.closest("#stage,.ddscreen");if(cont){cont.querySelectorAll(":scope>.tscene").forEach(e=>e.remove());const lay=document.createElementNS("http://www.w3.org/2000/svg","svg");lay.setAttribute("class","tscene");lay.setAttribute("aria-hidden","true");
      lay.innerHTML=`<g pointer-events="none">${back}</g>`;lay._spec=svg;cont.prepend(lay);fitScene(lay)}else svg.insertAdjacentHTML("afterbegin",`<g class="tfx-bk" pointer-events="none">${back}</g>`)}
  svg.insertAdjacentHTML("beforeend",`<g class="tfx" pointer-events="none">${f}</g>`);
  /* it stands far taller than the vial it came out of: scale the vial and everything coming out of it down together, from the vial's
     foot, so the whole thing (head and grin included) fits inside the stage instead of being cut off at the top */
  /* ...except in the Alloydex's big screen, which has room for it at its full height */
  if(!(host.closest&&host.closest(".ddscreen")&&!mini)){const NS="http://www.w3.org/2000/svg",wrap=document.createElementNS(NS,"g");wrap.setAttribute("class","gw-fit");wrap.setAttribute("transform","translate(150 236) scale(.58) translate(-150 -236)");
   [...svg.childNodes].filter(n=>n.nodeName!=="defs").forEach(n=>wrap.appendChild(n));svg.appendChild(wrap)}if(mini){svg.style.overflow="hidden";const dd=(back.match(/<defs>[\s\S]*?<\/defs>/g)||[]).join("");if(dd)svg.insertAdjacentHTML("afterbegin",dd)}}}
{const _rs=rubbleSVG;rubbleSVG=function(z,seed){return z==="z-hollow"?hmLeaves(seed):_rs(z,seed)}}

/* =============== DECORATIONS, PROPERLY ===============
   Every piece moves on its own, and most of them notice you: crows turn to watch and take off when you get close, eyes in the dark shut
   when you look for them, wisps dart off, skeletons rattle as you pass. Neeps are each carved differently. */
const NEEP_FACES=[
 `<path d="M12 21 L15.5 17 L17.5 22 Z M22.5 22 L24.5 17 L28 21 Z M19 24.4 L20 22.8 L21 24.4 Z"/><path d="M11 27 L13.5 30 L16 27.6 L18 31 L20 27.6 L22 31 L24 27.6 L26.5 30 L29 27 Q27 34 20 34 Q13 34 11 27 Z"/>`,
 `<circle cx="15" cy="21" r="2.8"/><circle cx="25" cy="21" r="2.8"/><ellipse cx="20" cy="30" rx="3.6" ry="4.2"/>`,
 `<path d="M10.5 19 L18 22.4 L12.6 24.4 Z M29.5 19 L22 22.4 L27.4 24.4 Z"/><path d="M10 27 Q20 32 30 27 L28.4 33 L25.4 30 L22.6 34 L20 30.6 L17.4 34 L14.6 30 L11.6 33 Z"/>`,
 `<path d="M12 22 L15.4 17.4 L18 22 Z"/><path d="M22 21 Q25 18.6 28 21 Q25 20.2 22 21 Z" stroke-width="1.4"/><path d="M12 28 Q21 35 29 26 Q22 31.6 12 28 Z"/>`,
 `<path d="M11.6 22 Q15 17.6 18.4 22 Q15 19.8 11.6 22 Z M21.6 22 Q25 17.6 28.4 22 Q25 19.8 21.6 22 Z"/><path d="M11 28.6 H29 V30.4 H11 Z"/><path d="M13 27 V32 M16 27 V32 M19 27 V32 M22 27 V32 M25 27 V32 M28 27 V32" stroke-width="1"/>`];
LNT_SVG.neep=(lit,v)=>{const f=NEEP_FACES[(v||0)%NEEP_FACES.length],c=lit?"#FFC24A":"#2A1A12";
 return`<ellipse cx="20" cy="37.4" rx="12" ry="2.4" fill="#000" opacity=".32"/>${lit?`<circle class="lnt-halo" cx="20" cy="25" r="19" fill="#FFB43A" opacity=".28"/>`:""}
  <path d="M6 26 Q4 13 20 11 Q36 13 34 26 Q33 36.4 20 37 Q7 36.4 6 26 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width="1.3"/><path d="M8 18 Q20 9.6 32 18" stroke="#8A4A9A" stroke-width="4.6" fill="none" opacity=".55" stroke-linecap="round"/>
  <path d="M14 13 Q10.6 25 14 36 M26 13 Q29.4 25 26 36" stroke="#B8A880" stroke-width=".8" fill="none"/>${lit?`<ellipse cx="20" cy="27" rx="10" ry="7" fill="#FF8A2A" opacity=".18"/>`:""}
  <path d="M14 11.4 Q20 8.4 26 11.4 L25 9 Q20 6 15 9 Z" fill="#E8DCB8" stroke="#3A2A1A" stroke-width=".9"/><path d="M19 8 Q17 2.4 13.6 1.4 M21 8 Q23 2.4 27 1.6 M20 8 V3" stroke="#4A7A3A" stroke-width="1.6" fill="none" stroke-linecap="round"/>
  <g class="lnt-face" fill="${c}" stroke="${c}" stroke-width=".3">${f}</g>`};
LNT_SVG.bunt=n=>{let s=`<svg viewBox="0 0 ${40*n} 40" preserveAspectRatio="none" aria-hidden="true" style="overflow:visible"><path d="M0 7 Q${20*n} 19 ${40*n} 7" stroke="#2A1A12" stroke-width="1.2" fill="none"/>`;const k=n*3;
  for(let i=0;i<k;i++){const t=(i+.5)/k,x=t*40*n,y=7+12*4*t*(1-t)*.98,X=x.toFixed(1),Y=y.toFixed(1),bat=i%3===1;
   s+=`<g class="lnt-flag" style="transform-origin:${X}px ${Y}px;animation-delay:-${(i*.37%1.6).toFixed(2)}s">`+(bat?`<path transform="translate(${X} ${(y+5).toFixed(1)})" d="M-7 0 Q-5 -3 -2 -1 L0 -3.4 L2 -1 Q5 -3 7 0 Q5.4 1 4.4 3.4 Q2 1.6 0 3.4 Q-2 1.6 -4.4 3.4 Q-5.4 1 -7 0 Z" fill="#14121A" stroke="#14121A" stroke-width=".4"/><circle cx="${(x-1).toFixed(1)}" cy="${(y+5).toFixed(1)}" r=".5" fill="#E8C040"/><circle cx="${(x+1).toFixed(1)}" cy="${(y+5).toFixed(1)}" r=".5" fill="#E8C040"/>`
    :`<path d="M${(x-5).toFixed(1)} ${Y} L${(x+5).toFixed(1)} ${Y} L${X} ${(y+12).toFixed(1)} Z" fill="${["#E8762A","#7A3A9A","#C83A2A","#2A2A34"][i%4]}" stroke="#2A1A12" stroke-width=".6"/><path d="M${(x-2).toFixed(1)} ${(y+3).toFixed(1)} l1 1.6 l1 -1.6 l1 1.6 l1 -1.6" stroke="#F4ECD8" stroke-width=".5" fill="none" opacity=".7"/>`)+`</g>`}return s+`</svg>`};
LNT_SVG.ghost=()=>`<ellipse cx="20" cy="38" rx="8" ry="1.8" fill="#000" opacity=".2" class="lnt-ghsh"/><g class="lnt-gh"><path d="M9 34 Q8 15 20 7 Q32 15 31 34 L28 31 L25 35.6 L21.6 31.6 L18.4 35.6 L15 31.6 L12 35.6 Z" fill="#F4F2EC" stroke="#3A3A4A" stroke-width="1" opacity=".92"/>
  <path d="M12 18 Q11 26 12.6 33" stroke="#D8D4CC" stroke-width="1" fill="none"/><ellipse cx="16.4" cy="18.6" rx="2.2" ry="3.2" fill="#14141C"/><ellipse cx="23.6" cy="18.6" rx="2.2" ry="3.2" fill="#14141C"/><ellipse class="lnt-ghm" cx="20" cy="26" rx="2.4" ry="3.2" fill="#14141C"/></g>`;
LNT_SVG.crow=()=>`<ellipse cx="20" cy="36" rx="7" ry="1.6" fill="#000" opacity=".25"/><g class="lnt-crow"><path d="M13 28 L3 33 L4.6 29.6 L13 26 Z" fill="#1A1A22"/><path d="M11 26 Q12 18 21 18 Q28 20 27 27 Q24 32 16 31 Q11 30 11 26 Z" fill="#22222C" stroke="#0A0A10" stroke-width=".8"/>
  <g class="lnt-cw"><path d="M14 24 Q19 20 24 24 Q19 28 14 24 Z" fill="#14141C"/></g><path d="M18 31 L17 36 M22 31 L23 36 M15.6 36 H19 M21.4 36 H24.6" stroke="#2A2A30" stroke-width="1"/>
  <g class="lnt-chd"><circle cx="26" cy="17" r="4.4" fill="#2A2A34" stroke="#0A0A10" stroke-width=".8"/><circle cx="27.4" cy="16.2" r="1.3" fill="#D8DCE8"/><circle cx="27.6" cy="16.2" r=".6" fill="#0A0A10"/><path d="M29.6 16.4 L35 17.8 L29.8 18.4 Z" fill="#3A3A42"/><path class="lnt-cbk" d="M29.8 18.4 L34.4 18.6 L29.6 19.8 Z" fill="#3A3A42"/></g></g>`;
LNT_SVG.pot=c=>`<ellipse cx="20" cy="37.4" rx="13" ry="2.4" fill="#000" opacity=".3"/><g class="lnt-potfire">${[[14,36],[20,37],[26,36]].map(([x,y],i)=>`<path class="lnt-flame" style="animation-delay:-${i*.2}s" d="M${x-3} ${y} Q${x} ${y-8} ${x+3} ${y} Z" fill="#FF8A2A"/>`).join("")}</g>
  <path d="M10 33 L8 37 M30 33 L32 37 M20 35 V38" stroke="#14141A" stroke-width="1.6"/><path d="M7 20 Q6 35 20 35 Q34 35 33 20 Z" fill="#1E1E24" stroke="#0A0A0C" stroke-width="1.2"/><path d="M10 24 Q11 31 16 33" stroke="#3A3A44" stroke-width="1.4" fill="none"/>
  <ellipse cx="20" cy="20" rx="13.6" ry="3.8" fill="#2A2A30" stroke="#0A0A0C" stroke-width="1"/><ellipse class="lnt-brew" cx="20" cy="20" rx="11.4" ry="2.6" fill="${c}"/>
  ${[[15,0],[21,.5],[25,1],[18,1.4]].map(([x,d])=>`<circle class="lnt-bub" style="animation-delay:-${d}s" cx="${x}" cy="20" r="1.4" fill="${c}"/>`).join("")}<g class="lnt-steam">${[14,20,26].map((x,i)=>`<path style="animation-delay:-${i*.9}s" d="M${x} 17 Q${x-3} 12 ${x} 8 Q${x+3} 4 ${x} 0" stroke="${c}" stroke-width="1.6" fill="none" opacity=".5"/>`).join("")}</g>`;
LNT_SVG.skel=()=>`<path d="M17 0 Q20 -2 23 0" stroke="#5A5A62" stroke-width="1.4" fill="none"/><g class="lnt-sk" style="transform-origin:20px 0"><path d="M20 0 V6" stroke="#C8C4B8" stroke-width=".6"/>
  <circle cx="20" cy="10" r="4.4" fill="#F0ECE0" stroke="#3A3A44" stroke-width=".8"/><circle cx="18.4" cy="9.6" r="1.1" fill="#14141C"/><circle cx="21.6" cy="9.6" r="1.1" fill="#14141C"/><path d="M18.6 12.6 H21.4" stroke="#14141C" stroke-width=".7"/>
  <path d="M20 14.4 V25" stroke="#F0ECE0" stroke-width="1.6"/>${[17,19.4,21.8].map(y=>`<path d="M16 ${y} Q20 ${y+1.6} 24 ${y}" stroke="#F0ECE0" stroke-width="1.1" fill="none"/>`).join("")}
  <g class="lnt-ska"><path d="M17 15.4 L13 21 L12 27 M23 15.4 L27 21 L28.6 26" stroke="#F0ECE0" stroke-width="1.2" fill="none" stroke-linecap="round"/></g><path d="M16.6 25 Q20 28 23.4 25 Z" fill="#F0ECE0" stroke="#3A3A44" stroke-width=".5"/>
  <g class="lnt-skl"><path d="M18 27 L17 33 L17.6 38 M22 27 L23 33 L22.6 38" stroke="#F0ECE0" stroke-width="1.3" fill="none" stroke-linecap="round"/></g></g>`;
LNT_SVG.eyes=c=>`<g class="lnt-ey"><ellipse cx="14" cy="20" rx="3" ry="1.8" fill="${c}"/><ellipse cx="26" cy="20" rx="3" ry="1.8" fill="${c}"/><ellipse cx="14" cy="20" rx=".9" ry="1.6" fill="#0A0604"/><ellipse cx="26" cy="20" rx=".9" ry="1.6" fill="#0A0604"/></g>`;
LNT_SVG.strg=(n,lit)=>{let s=`<svg viewBox="0 0 ${40*n} 40" preserveAspectRatio="none" aria-hidden="true" style="overflow:visible"><path d="M0 5 Q${20*n} 15 ${40*n} 5" stroke="#2A1A12" stroke-width="1" fill="none"/>`;const k=n*2;
  for(let i=0;i<k;i++){const t=(i+.5)/k,x=t*40*n,y=5+10*4*t*(1-t),c=["#E8762A","#C83A2A","#E8C040","#7A3A9A"][i%4];
   s+=`<g class="lnt-pl" style="transform-origin:${x.toFixed(1)}px ${y.toFixed(1)}px;animation-delay:-${(i*.41%2).toFixed(2)}s"><path d="M${x.toFixed(1)} ${y.toFixed(1)} v3" stroke="#2A1A12" stroke-width=".7"/>${lit?`<circle cx="${x.toFixed(1)}" cy="${(y+10).toFixed(1)}" r="10" fill="${c}" opacity=".25" class="lnt-halo"/>`:""}<ellipse cx="${x.toFixed(1)}" cy="${(y+10).toFixed(1)}" rx="5.4" ry="6.6" fill="${c}" opacity="${lit?1:.55}" stroke="#2A1A12" stroke-width=".7"/><path d="M${(x-5.4).toFixed(1)} ${(y+10).toFixed(1)} H${(x+5.4).toFixed(1)} M${x.toFixed(1)} ${(y+3.4).toFixed(1)} V${(y+16.6).toFixed(1)}" stroke="#2A1A12" stroke-width=".4" opacity=".5"/>${lit?`<ellipse cx="${x.toFixed(1)}" cy="${(y+10).toFixed(1)}" rx="2.4" ry="3.4" fill="#FFF2C0" opacity=".85"/>`:""}<rect x="${(x-2).toFixed(1)}" y="${(y+16.4).toFixed(1)}" width="4" height="1.6" fill="#2A1A12"/></g>`}return s+`</svg>`};
LNT_SVG.wisp=c=>`<g class="lnt-wp"><circle cx="20" cy="18" r="11" fill="${c}" opacity=".16"/><circle cx="20" cy="18" r="6" fill="${c}" opacity=".4"/><circle cx="20" cy="18" r="3.2" fill="#F4FFFF"/><path d="M20 21 Q17 27 20 32 Q22 27 20 21 Z" fill="${c}" opacity=".35"/></g>`;
const LNT_EYE_C={"z-hollow":"#FFE070","z-mine":"#E8F070","z-glacier":"#9AF0FF","z-vault":"#FF6A5A","z-reactor":"#9AFF7A","z-scrap":"#FFC060"};
const LNT_WISP_C={"z-hollow":"#9AFF9A","z-volcano":"#FFB070","z-glacier":"#BFF4FF","z-reactor":"#B8FF8A"};
const LNT_BREWS=["#6AE86A","#B86AE8","#E8A03A","#5AC8E8"];
lntDecorate=function(){const z=EXP.zone.cls,L=LNT_DECOR[z];if(!L||!lntOn()||EXP.zone.special||(typeof TUT!=="undefined"&&TUT.on))return;const lit=lntLit(),cand=new Set(store.get("wta_lnt_cand",[])),strs=new Set(store.get("wta_lnt_str",[]));
  EXP.bogles=[];EXP.lntProx=[];
  L.forEach(([k,x,y,n],idx)=>{const key=z+":"+x+","+y,vv=(x*7+y*13+z.length)%5;let el,o={x,y,lnt:k};
    if(k==="neep"){const on=lit.has(key)&&!lntSnuffed(key);el=lntEl("mapobj lnt neep"+(on?" lit":""),x,y,lntSvg(LNT_SVG.neep(on,vv)));
      o.use=()=>{if(lntSnuffed(key)){sfx("miss");talk("",["You strike a match. It flares, shivers, and dies against the wick as if the wick were made of ice.","Something has been drinking the light out of the lanterns round here."]);return}
        if(lntLit().has(key)){talk("",[["The neep grins at you from the inside out. It's doing a grand job on its own.","Its carved face flickers. The candle inside has a good while left in it yet.","Somebody carved this one with a great deal of feeling."][vv%3]]);return}
        const s=lntLit();s.add(key);store.set("wta_lnt_lit",[...s]);el.classList.add("lit");el.innerHTML=lntSvg(LNT_SVG.neep(true,vv));lntFlash(el,"catch",900);if(gate("lntlight",600))sfx("sel");
        const all=LNT_NEEPS(),m=all.filter(q=>s.has(q)).length;store.set("wta_qf_seenJ",0);journalDot();
        say0(m>=all.length?`You light the last neep lantern. Every neep on every map is grinning tonight. (${m} of ${all.length})`:`You light the neep. Its carved face catches and glows. Neep lanterns lit: ${m} of ${all.length}.`);if(inHollow())lntNight()}}
    else if(k==="trail"){const step=n,on=lntTrail()>step;el=lntEl("mapobj lnt trail"+(on?" lit":""),x,y,lntSvg(LNT_SVG.trail(on)));o.use=()=>lntTrailUse(step,el)}
    else if(k==="bogle"){el=lntEl("mapobj lnt bogle",x,y,lntSvg(LNT_SVG.bogle()));EXP.bogles.push(o);o.use=()=>{lntFlash(el,"creak",1200);if(gate("lntbog",900))sfx("clunk");talk("",[inHollow()?HM_BOGLE_LINES[Math.min(store.get("wta_lnt_bog",0),HM_BOGLE_LINES.length-1)]:LNT_BOGLE[(x*3+y)%LNT_BOGLE.length]])}}
    else if(k==="cand"){let on=!cand.has(key);el=lntEl("mapobj lnt cand"+(on?" lit":""),x,y,lntSvg(LNT_SVG.cand(on)));
      o.use=()=>{const c=new Set(store.get("wta_lnt_cand",[]));on=!on;if(on)c.delete(key);else c.add(key);store.set("wta_lnt_cand",[...c]);el.innerHTML=lntSvg(LNT_SVG.cand(on));el.classList.toggle("lit",on);if(!on)lntFlash(el,"puff",1600);
        if(gate("lntcand",700))sfx(on?"sel":"hiss");say0(on?"You light the candles again. They lean all together towards you, then straighten.":"You blow the candles out. Three little threads of smoke climb up and knot together.");if(inHollow())lntNight()}}
    else if(k==="pot"){let b=(x+y)%LNT_BREWS.length;el=lntEl("mapobj lnt pot",x,y,lntSvg(LNT_SVG.pot(LNT_BREWS[b])));
      o.use=()=>{b=(b+1)%LNT_BREWS.length;el.innerHTML=lntSvg(LNT_SVG.pot(LNT_BREWS[b]));lntFlash(el,"stir",1000);if(gate("lntpot",900))sfx("swirl");say0(["You give the cauldron a stir. It turns a different colour and burps.","You stir it. Something long and pale comes up to the surface, looks at you, and goes back down. A parsnip. Probably a parsnip.","You stir the pot. It smells of toffee, then of bonfires, then, briefly, of school dinners.","The ladle comes out a different colour from the one it went in."][b])}}
    else if(k==="bunt"){el=lntEl("mapobj lnt bunt",x,y,LNT_SVG.bunt(n),n,1);o.wide=n;o.use=()=>{lntFlash(el,"tug",1400);if(gate("lntbunt",900))sfx("swirl");say0("You give the bunting a tug. Every flag along the string jumps and snaps, and the paper bats swing round to look at you.")}}
    else if(k==="strg"){let on=strs.has(key);el=lntEl("mapobj lnt strg"+(on?" lit":""),x,y,LNT_SVG.strg(n,on),n,1);o.wide=n;
      o.use=()=>{if(on){lntFlash(el,"tug",1400);say0("The paper lanterns swing on their string and their light swings with them.");return}on=true;const s=new Set(store.get("wta_lnt_str",[]));s.add(key);store.set("wta_lnt_str",[...s]);el.innerHTML=LNT_SVG.strg(n,true);el.classList.add("lit");lntFlash(el,"catch",900);if(gate("lntlight",600))sfx("sel");say0("You light the first paper lantern on the string, and the flame runs along all the others, one, two, three, all the way to the end.")}}
    else if(k==="bats"){el=lntEl("mapobj lnt bats",x,y,lntSvg(LNT_SVG.bats()));o.use=()=>{if(el.classList.contains("fly"))return;lntFlash(el,"fly",5200);if(gate("lntbat",1500))sfx("swirl");say0("The bats drop off the wall all at once and go flickering round your head. They'll be back once you've stopped looking.")};
      o.prox=d=>{if(d<=1&&!el.classList.contains("fly"))el.classList.add("stir");else el.classList.remove("stir")}}
    else if(k==="web"){el=lntEl("mapobj lnt web",x,y,lntSvg(LNT_SVG.web()));o.use=()=>{if(el.classList.contains("up"))return;lntFlash(el,"up",3600);say0("The spider shins back up its thread to the top of the web, and sits there, offended.")}}
    else if(k==="skel"){el=lntEl("mapobj lnt skel",x,y,lntSvg(LNT_SVG.skel()));o.use=()=>{lntFlash(el,"rattle",1500);if(gate("lntsk",1200))sfx("clunk");say0(["You shake its hand. The hand comes off. You put it back, carefully.","It's a paper skeleton on a string. It's definitely a paper skeleton on a string.","Its jaw drops open as it swings round, as if it's about to tell you something. It doesn't."][(x+y)%3])};
      o.prox=d=>{if(d<=2){if(!o.near){o.near=1;lntFlash(el,"rattle",1500)}}else o.near=0}}
    else if(k==="eyes"){el=lntEl("mapobj lnt eyes",x,y,lntSvg(LNT_SVG.eyes(LNT_EYE_C[z]||"#FFE070")));el.style.setProperty("--bl",(2.5+((x*3+y)%5)*.7).toFixed(1)+"s");el.style.setProperty("--bd","-"+((x+y*2)%4)+"s");
      o.use=()=>say0(["Nothing there but dark. Probably.","You peer into the dark where the eyes were. The dark peers back.","Whatever it was, it's very good at not being there."][(x+y)%3]);o.prox=d=>el.classList.toggle("shut",d<=3)}
    else if(k==="crow"){el=lntEl("mapobj lnt crow",x,y,lntSvg(LNT_SVG.crow()));el.style.setProperty("--cd","-"+((x*5+y)%6)+"s");
      const fly=()=>{if(el.classList.contains("gone"))return;el.classList.add("gone");if(gate("lntcrow",2000))sfx("swirl");setTimeout(()=>{el.classList.remove("gone");el.classList.add("back");setTimeout(()=>el.classList.remove("back"),900)},9000)};
      o.use=()=>{fly();say0(["The jackdaw tells you exactly what it thinks of you, and leaves.","It cocks its pale eye at you, says something rude, and takes off.","Off it goes, complaining all the way."][(x+y)%3])};
      o.prox=d=>{el.classList.toggle("flip",EXP.x<x);if(d<=2)fly()}}
    else if(k==="ghost"){el=lntEl("mapobj lnt ghost",x,y,lntSvg(LNT_SVG.ghost()));el.style.setProperty("--gd","-"+((x+y)%5)+"s");
      o.use=()=>{if(el.classList.contains("gone"))return;el.classList.add("boo");setTimeout(()=>{el.classList.remove("boo");el.classList.add("gone");setTimeout(()=>el.classList.remove("gone"),9000)},700);say0(["You lift the edge of the sheet. There's nobody underneath. You put it back down, quickly.","'Boo,' says the sheet, very quietly, and isn't there any more.","It drifts away from your hand, the way a sheet on a line does when there's no wind at all."][(x+y)%3])}}
    else if(k==="wisp"){el=lntEl("mapobj lnt wisp",x,y,lntSvg(LNT_SVG.wisp(LNT_WISP_C[z]||"#9AF0FF")));el.style.setProperty("--wd","-"+((x*3+y)%7)+"s");
      o.use=()=>say0("The little light bobs just out of reach, and waits for you to follow.");o.prox=d=>{if(d<=2&&!el.classList.contains("flee")){el.classList.add("flee");setTimeout(()=>el.classList.remove("flee"),5500)}}}
    if(!el)return;o.el=el;EXP.objs.push(o);if(o.prox)EXP.lntProx.push(o);
    if(o.wide)for(let i=1;i<o.wide;i++)EXP.objs.push({x:x+i,y,el:null,use:o.use,lnt:k})});
  lntBogles();lntProxCheck()};
function lntProxCheck(){(EXP.lntProx||[]).forEach(o=>{if(o.el&&o.el.isConnected)o.prox(Math.abs(o.x-EXP.x)+Math.abs(o.y-EXP.y))})}
{const _pp=placePlayer;placePlayer=function(i){_pp(i);if(EXP.lntProx&&EXP.lntProx.length)lntProxCheck();if(inHollow())hmScary()}}
/* ---- ambient life on every decorated map: a flock of bats goes over now and then, and leaves blow through the outdoor ones ---- */
const LNT_LEAFY=new Set(["z-scrap","z-wreck","z-crater","z-hollow"]);
function lntAmbient(){clearTimeout(lntAmbient.t);["#lnt-flock","#lnt-leaves"].forEach(s=>{const e=$(s);if(e)e.remove()});
  const z=EXP.zone&&EXP.zone.cls;if(!lntOn()||!z||EXP.zone.special||!LNT_DECOR[z]||(typeof TUT!=="undefined"&&TUT.on))return;const mw=$("#mapwrap");if(!mw)return;
  const f=document.createElement("div");f.id="lnt-flock";f.innerHTML=Array.from({length:6},(_,i)=>`<i style="--i:${i};--y:${(i*7)%23}px"><svg viewBox="-8 -4 16 8"><path d="M-7 0 Q-5 -3 -2 -1 L0 -3 L2 -1 Q5 -3 7 0 Q5 1 4 3 Q2 1.4 0 3 Q-2 1.4 -4 3 Q-5 1 -7 0 Z" fill="#14121A"/></svg></i>`).join("");mw.appendChild(f);
  const go=()=>{if(!f.isConnected)return;f.classList.remove("go","rtl");void f.offsetWidth;f.style.top=(10+Math.random()*50)+"%";if(Math.random()<.5)f.classList.add("rtl");f.classList.add("go");lntAmbient.t=setTimeout(go,16000+Math.random()*16000)};lntAmbient.t=setTimeout(go,3000+Math.random()*6000);
  if(LNT_LEAFY.has(z)){const l=document.createElement("div");l.id="lnt-leaves";l.innerHTML=Array.from({length:9},(_,i)=>`<i style="--x:${(i*11.3)%100}%;--d:${7+(i*1.7)%6}s;--dl:-${(i*1.3)%9}s;--c:${["#C8642A","#A8402A","#D8A040","#8A5A2A"][i%4]}"></i>`).join("");mw.appendChild(l)}}
{const _wp=worldPlace;worldPlace=function(){_wp();lntAmbient()}}

/* =============== HOLLOWMERE AFTER DARK ===============
   It's darker, the fog comes up off the bog and lies thickest in the kirkyard, the lamps gutter, faces come and go at the windows,
   somebody tall keeps standing at the edge of the light and isn't there when you get close, the little guisers on the lane aren't
   quite right, and the tattie bogle from the top field comes a bit further down the hill every time you visit. */
HOLLOW_ZONE.sub="Every window is lit and every door is shut. The fog comes up off the bog at dusk, and something out there is putting the lanterns out.";
const HM_BOG_PATH=[[32,2],[29,3],[25,4],[21,5],[18,5]];
const HM_BOGLE_LINES=["The tattie bogle from the top field. Its turnip head is turned towards the village.",
 "Wasn't the tattie bogle further up the hill last time? Its coat is soaked, as if it's been standing out in the bog.",
 "The tattie bogle is halfway down the hill now. There are no footprints round its pole, and no hole where its pole used to be.",
 "It's nearly at the stile. Its carved face is turned towards the village, and somebody has lit the candle in its head.",
 "It has reached the stile, and it's looking down at the lights of Hollowmere. You don't remember anybody carving it a smile."];
{const _se=startExplore;startExplore=function(){if(EXP.forceZone===HOLLOW_ZONE&&lntOn()){let st=store.get("wta_lnt_bog",0);if(lntF("hm")&&!EXP.resume&&!(EXP.stash&&EXP.stash.zone===HOLLOW_ZONE)&&!EXP.spawn){st=Math.min(HM_BOG_PATH.length-1,st+1);store.set("wta_lnt_bog",st)}
    const b=LNT_DECOR["z-hollow"].find(d=>d[0]==="bogle");if(b){b[1]=HM_BOG_PATH[st][0];b[2]=HM_BOG_PATH[st][1]}}_se()}}
let HM_DIM=-1;
lntNight=function(){let n=$("#lnt-night");if(!inHollow()){if(n)n.remove();return}if(!n){n=document.createElement("div");n.id="lnt-night";$("#world").appendChild(n)}
  const W=EXP.W,H=EXP.H,lit=lntLit(),L=[];let li=0;const at=(x,y,r,c)=>{const dim=li++===HM_DIM;if(dim){r*=.45;c=c.replace(/,[\d.]+\)$/,",.5)")}L.push(`radial-gradient(circle calc(var(--tp,40px)*${r}) at ${((x+.5)/W*100).toFixed(2)}% ${((y+.5)/H*100).toFixed(2)}%,${c} 0,${c.replace(/[\d.]+\)$/,"0)")} 100%)`)};
  at(17,11.6,4.2,"rgba(255,206,140,1)");[[17,7],[12,11],[23,11]].forEach(([x,y])=>at(x,y-.6,2.1,"rgba(255,220,160,1)"));
  HM_COTS.forEach(([x,y,v])=>{const dx=[3,4,3,5][v],wx=dx<4?5.5:1.5;[wx,wx+1.2].forEach(o=>at(x+o,y+1.8,1.4,"rgba(255,206,140,.95)"));at(x+dx+1.6,y+2.6,1,"rgba(255,190,110,.9)")});
  (LNT_DECOR["z-hollow"]||[]).forEach(([k,x,y,s])=>{const key="z-hollow:"+x+","+y;if(k==="neep"&&lit.has(key)&&!lntSnuffed(key))at(x,y,1.3,"rgba(255,190,110,.95)");if(k==="trail"&&lntTrail()>s)at(x,y-1,2,"rgba(255,220,160,1)");if(k==="cand"&&!new Set(store.get("wta_lnt_cand",[])).has(key))at(x,y,.9,"rgba(255,206,140,.9)");if(k==="wisp")at(x,y,1.1,"rgba(170,255,170,.7)");if(k==="pot")at(x,y,1,"rgba(170,255,140,.7)");if(k==="strg"&&new Set(store.get("wta_lnt_str",[])).has(key))at(x+1.5,y+.6,1.6,"rgba(255,190,120,.9)")});
  at(36,22,1.4,"rgba(200,170,255,.8)");
  n.style.background=`radial-gradient(circle calc(var(--tp,40px)*1.7) at var(--px,50%) var(--py,50%),rgba(220,212,245,.95) 0,rgba(220,212,245,0) 100%),${L.join(",")},#2E3056`;lntPlayerLight()};
/* the fog, the watcher, faces at the windows */
const HM_WATCH=[[2,10],[26,13],[5,23],[34,10],[13,3],[30,24],[36,14],[1,15],[38,24],[20,1],[11,22]];
const HM_WATCH_SVG=`<svg viewBox="0 0 40 80" aria-hidden="true" style="overflow:visible;position:absolute;left:0;bottom:0;width:100%;height:200%"><ellipse cx="20" cy="78" rx="9" ry="2" fill="#000" opacity=".35"/>
  <path d="M11 78 L13 36 Q20 30 27 36 L29 78 Z" fill="#14121C"/><path d="M13 40 Q9 56 10 70 M27 40 Q31 56 30 70" stroke="#14121C" stroke-width="3" fill="none" stroke-linecap="round"/>
  <path d="M10 26 Q9 14 20 13 Q31 14 30 26 Q29 34 20 35 Q11 34 10 26 Z" fill="#B8AC88" stroke="#14121C" stroke-width="1.2"/><path d="M15 13 Q20 10 25 13" stroke="#14121C" stroke-width="1.4" fill="none"/>
  <g class="hm-wey"><path d="M14 23 L17 20 L18 24 Z M22 24 L23 20 L26 23 Z" fill="#FFB43A" opacity=".75"/></g></svg>`;
function hmScaryStart(){hmScaryStop();if(!inHollow())return;const T=hmScaryStart.t=[];EXP.hmSaid=new Set;
  let f=$("#hm-fog");if(!f){f=document.createElement("div");f.id="hm-fog";f.innerHTML=`<i class="f1"></i><i class="f2"></i><i class="fk"></i><i class="fp"></i>`;$("#world").appendChild(f)}
  const at=HM_WATCH[Math.random()*HM_WATCH.length|0];EXP.hmWatch={x:at[0],y:at[1],gone:false,el:lntEl("mapobj hm-watch",at[0],at[1],HM_WATCH_SVG)};
  const face=()=>{const F=[...document.querySelectorAll("#world .hm-face")];if(F.length){const e=F[Math.random()*F.length|0];e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2400)}T.push(setTimeout(face,7000+Math.random()*7000))};T.push(setTimeout(face,5000));
  const flick=()=>{if(!inHollow())return;HM_DIM=Math.random()*4|0;lntNight();setTimeout(()=>{HM_DIM=-1;if(inHollow())lntNight()},380+Math.random()*400);T.push(setTimeout(flick,6000+Math.random()*7000))};T.push(setTimeout(flick,4000));
  hmGuisers()}
function hmScaryStop(){EXP.hmSaid=null;EXP.hmWatch=null;(hmScaryStart.t||[]).forEach(clearTimeout);hmScaryStart.t=[];const f=$("#hm-fog");if(f&&!inHollow())f.remove()}
function hmScary(){if(!EXP.hmSaid)return;const w=EXP.hmWatch;if(w&&!w.gone&&w.el&&w.el.isConnected&&Math.abs(w.x-EXP.x)+Math.abs(w.y-EXP.y)<=3){w.gone=true;w.el.classList.add("gone");
    if(!EXP.hmSaid.has("watch")){EXP.hmSaid.add("watch");setTimeout(()=>{if(inHollow()&&!DLG.open)say0("There was somebody standing just there, at the edge of the light. There isn't now.")},500)}
    (hmScaryStart.t||[]).push(setTimeout(()=>{if(!inHollow()||!w.el.isConnected)return;const far=HM_WATCH.filter(([x,y])=>Math.abs(x-EXP.x)>9||Math.abs(y-EXP.y)>6);const p=far[Math.random()*far.length|0]||HM_WATCH[0];
      w.x=p[0];w.y=p[1];w.el.style.left=(p[0]/EXP.W*100)+"%";w.el.style.top=(p[1]/EXP.H*100)+"%";if(typeof depthPeople==="function")depthPeople();w.el.classList.remove("gone");w.gone=false},9000+Math.random()*7000))}
  const x=EXP.x,y=EXP.y,reg=x<=8&&y>=7&&y<=15?"kirk":x>=29&&x<=37&&y>=8&&y<=12?"store":y<=5?"hill":y>=22&&x<=32?"garden":null;
  if(reg&&EXP.hmSaid&&!EXP.hmSaid.has(reg)){EXP.hmSaid.add(reg);say0({kirk:"Every grave in the kirkyard has a little neep at its foot. None of them are lit. All of them are turned towards you.",
    store:"It's colder in the storeroom than it is outside. Somewhere under the dust sheets, something settles, the way a chair does when it's sat in.",
    hill:"The wind comes up off the bog, and it sounds almost like somebody calling a name. Not yours. Not quite.",
    garden:"The gardens behind the cottages are dark, and the leaf piles are rustling. There isn't any wind down here."}[reg])}
  const b=(EXP.bogles||[])[0];if(b&&!EXP.hmSaid.has("bog")&&store.get("wta_lnt_bog",0)>0&&Math.abs(b.x-x)+Math.abs(b.y-y)<=7){EXP.hmSaid.add("bog");say0("The tattie bogle from the top field is standing somewhere else tonight. A bit nearer the village.")}}
/* the little guisers on the lane */
const HM_GUISER_SVG=(m)=>`<svg viewBox="0 0 40 40" aria-hidden="true" style="overflow:visible"><ellipse cx="20" cy="37.6" rx="8" ry="1.8" fill="#000" opacity=".3"/><path d="M11 37 Q10 22 20 17 Q30 22 29 37 L26 35 L23 37.6 L20 35.4 L17 37.6 L14 35 Z" fill="#E8E4DA" stroke="#3A3A44" stroke-width=".9"/>
  <path d="M13 13 Q20 9 27 13 Q28 21 20 23 Q12 21 13 13 Z" fill="${m}" stroke="#2A1A12" stroke-width=".9"/><path d="M15.4 15 L17.6 15.6 L15.8 17 Z M24.6 15 L22.4 15.6 L24.2 17 Z" fill="#14121C"/><path d="M16 19.4 Q20 21.6 24 19.4" stroke="#14121C" stroke-width=".9" fill="none"/><path d="M13 14 L10 13 M27 14 L30 13" stroke="#8A6A44" stroke-width=".6"/></svg>`;
function hmGuisers(){if(lntF("gzDone")&&Math.random()<.5)return;[[7,17,"#E8C890",["A small guiser in a bedsheet, with a paper mask tied on over the top. It hasn't said trick or treat.","'Have you done your turn yet?'","'We did ours.' It tilts its head. 'A long time ago.'"]],
  [29,21,"#C8D8A0",["Another little guiser, holding a neep lantern on a string. The neep isn't lit.","'Will you light it for me? Nobody will light it for me.'","You strike a match and bend to the wick. When you look up, there's nobody holding the string, and nobody on the lane."]]].forEach(([x,y,m,lines])=>{
    const o=storyNPC({n:"A guiser",look:{coat:"#E8E4DA"},talks:[["..."]]},[x,y]);o.el.innerHTML=`<span class="talkmark">...</span>`+HM_GUISER_SVG(m);o.el.classList.add("hm-guiser");
    o.quest=()=>talk("",lines,()=>{lntSet("gzDone",1);o.el.classList.add("gone");setTimeout(()=>{o.el.remove();EXP.npcs=EXP.npcs.filter(q=>q!==o)},900)})})}
{const _hc=hmCottage;hmCottage=function(v){return _hc(v).replace(/(<rect x="(\d+)" y="66" width="34" height="30" fill="#FFC870" class="hm-win"[^>]*\/>)/g,(m,a,x)=>a+`<g class="hm-face"><circle cx="${+x+17}" cy="80" r="6.4" fill="#1A1210"/><path d="M${+x+5} 96 Q${+x+17} 82 ${+x+29} 96 Z" fill="#1A1210"/></g>`)}}
{const _wp=worldPlace;worldPlace=function(){hmScaryStop();_wp();if(inHollow()&&lntOn())hmScaryStart()}}
/* a lit neep left on the lane where the little guiser stood */
/* Marlow's welcome gets one more line */
{const _mt=lntMarlowTalk;lntMarlowTalk=function(m){if(!lntF("hm")){const _t=talk;talk=function(who,lines,done,prompt){talk=_t;const L=[...lines];L.splice(L.length-1,0,"And recruit: stay in the light where you can. Hollowmere is very friendly. Most of it.");return _t(who,L,done,prompt)}}_mt(m)}}
TRACKS["explore_z-hollow"]={base:"threat",bpm:70,intro:1,lead:{type:"triangle",vol:.2,stac:true},parts:[{k:"ostinato",type:"sine",vol:.04,oct:5},{k:"pad",type:"sawtooth",vol:.012,oct:3}],bass:{s:"walk",vol:.2},drum:"k . . h . . . .",fill:". . . . k . c .",chime:true};
TRACKS["threat_gutter"]={base:"threat",bpm:112,swing:.22,lead:{type:"sine",vol:.24,stac:true},parts:[{k:"arp",type:"sine",vol:.035,oct:5},{k:"counter",type:"triangle",vol:.05,oct:4}],bass:{s:"oompah",vol:.26},drum:"k . h . s . h k",fill:"k . s s k s c c",chime:true};
