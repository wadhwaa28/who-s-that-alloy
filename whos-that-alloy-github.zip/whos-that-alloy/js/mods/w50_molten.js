/* =============== OVERCLOCKED, IN METAL ===============
   Every Overclocked form is poured in its own alloy. Its colours come from the metal (with only a breath of whatever creature it is),
   its surface takes a liquid shine, the whole pour sloshes a beat behind itself, drips hang off its underside and fall, and somewhere in
   the middle of it the metal is still hot. Brass was the first, and stays hand-finished. */
const mixHex=(a,b,t)=>{const A=parseInt(a.slice(1),16),B=parseInt(b.slice(1),16),f=(s)=>Math.round(((A>>s)&255)*(1-t)+((B>>s)&255)*t);return"#"+((1<<24)+(f(16)<<16)+(f(8)<<8)+f(0)).toString(16).slice(1)};
/* the creature's own light-and-dark pattern survives, but every colour in it is now a shade of the metal */
const _fPal0=fPal;fPal=function(a,rad,R){const P=_fPal0(a,rad,R);P.metal=rad?R.rb:a.color;P.hot=rad?"#7AE8FF":"#FF8A2A";return P};
const lumOf=h=>{const n=parseInt(h.slice(1),16);return(.299*(n>>16)+.587*((n>>8)&255)+.114*(n&255))/255};
function metalize(svg,M,hot){const dark=shade(M,-.5),light=shade(M,.34),line=shade(M,-.68),memo={};
  const map=(c,glow)=>{const C=c.toUpperCase();if(glow)return hot;if(C===FI.toUpperCase())return line;if(C===FMOUTH.toUpperCase()||C===FTONGUE.toUpperCase()||C==="#FFFFFF"||C==="#FFF6D8"||C==="#FFF4DC"||C==="#FFD23F")return c;
    if(memo[C])return memo[C];const t=.08+.9*lumOf(C);return memo[C]=mixHex(mixHex(dark,light,t),C,.1)};
  return svg.split(/(<g class="eye"[\s\S]*?<\/g>)/).map((seg,i)=>i%2?seg:seg.replace(/<[a-zA-Z]+\b[^>]*>/g,tag=>{const glow=/class="[^"]*p-glow/.test(tag);
    return tag.replace(/(fill|stroke)="(#[0-9A-Fa-f]{6})"/g,(m,k,c)=>`${k}="${map(c,glow)}"`)})).join("")}
/* one shared liquid-shine filter for the whole page */
(function(){if(document.getElementById("lqDefs"))return;const s=document.createElementNS("http://www.w3.org/2000/svg","svg");s.id="lqDefs";s.setAttribute("aria-hidden","true");s.style.cssText="position:absolute;width:0;height:0;overflow:hidden";
  s.innerHTML=`<defs><filter id="lqGloss" x="-8%" y="-8%" width="116%" height="116%" color-interpolation-filters="sRGB"><feMorphology in="SourceAlpha" operator="erode" radius="1.7" result="e"/><feOffset in="e" dx="2.6" dy="3.2" result="eo"/><feComposite in="e" in2="eo" operator="out" result="rimA"/><feGaussianBlur in="rimA" stdDeviation=".8" result="rimB"/><feFlood flood-color="#FFF6E0" flood-opacity=".92"/><feComposite in2="rimB" operator="in" result="hi"/><feOffset in="e" dx="-2.6" dy="-3.2" result="eu"/><feComposite in="e" in2="eu" operator="out" result="lowA"/><feGaussianBlur in="lowA" stdDeviation="1.3" result="lowB"/><feFlood flood-color="#000000" flood-opacity=".26"/><feComposite in2="lowB" operator="in" result="lo"/><feMorphology in="SourceAlpha" operator="dilate" radius="1.5" result="dil"/><feFlood flood-color="#121B40"/><feComposite in2="dil" operator="in" result="ol"/><feMerge><feMergeNode in="ol"/><feMergeNode in="SourceGraphic"/><feMergeNode in="lo"/><feMergeNode in="hi"/></feMerge></filter></defs>`;
  (document.body||document.documentElement).appendChild(s)})();
const MOLTEN_SKIP=new Set(["Brass"]);
function moltenBits(name,P){const A=(typeof MOLTEN_AT!=="undefined"&&MOLTEN_AT[name])||null;if(!A)return"";let s="";
  const drip=(x,y,l,w)=>`<path d="M${x-w} ${y} Q${x-w*.5} ${y+l*.6} ${x-w*.8} ${y+l} Q${x} ${y+l+w*1.8} ${x+w*.8} ${y+l} Q${x+w*.5} ${y+l*.6} ${x+w} ${y} Z" fill="${P.n}" stroke="${FI}" stroke-width="1.8" stroke-linejoin="round"/><ellipse cx="${x-w*.3}" cy="${y+l*.88}" rx="${w*.28}" ry="${w*.5}" fill="${P.nll}" opacity=".9"/>`;
  (A.d||[]).forEach(([x,y],i)=>{const l=[11,15,8,13][i%4],w=[3.8,4.4,3.2,4][i%4];s+=`<g class="pt p-sway" style="transform-origin:${x}px ${y}px;--dl:${(i*.27).toFixed(2)}s">${drip(x,y-1,l,w)}</g>`});
  if(A.f){const[x,y]=A.f,fd=Math.max(10,Math.min(40,142-y));s+=`<g class="fall" style="transform-origin:${x}px ${y}px;--fd:${fd}px"><path d="M${x} ${y} Q${x-3.4} ${y+6} ${x} ${y+8} Q${x+3.4} ${y+6} ${x} ${y} Z" fill="${P.n}" stroke="${FI}" stroke-width="1.4"/></g>`}
  if(A.c){const[x,y]=A.c;s+=`<path class="p-glow" d="M${x-7} ${y-2} Q${x} ${y+4} ${x+8} ${y-1}" stroke="${P.hot}" stroke-width="2.8" fill="none" stroke-linecap="round" opacity=".7"/>`}
  return s}
function moltenize(svg,name,P){
  svg=svg.replace('class="cr-body L-','class="cr-body molten L-').replace('<g class="ib">','<g class="ib"><g class="lq" filter="url(#lqGloss)">');
  const k=svg.lastIndexOf("</g></g></g></svg>");if(k<0)return svg;
  return svg.slice(0,k)+metalize(moltenBits(name,P),P.metal,P.hot)+"</g>"+svg.slice(k)}
function moltenAll(){Object.keys(BATTLE_FORMS).forEach(name=>{if(MOLTEN_SKIP.has(name)||BATTLE_FORMS[name].molten)return;const f=BATTLE_FORMS[name],R=FORM_R[name];if(!R)return;
  const cache=new Map();const nf=(a,g,rad)=>{const k=g+"|"+(rad?1:0)+"|"+a.color;if(cache.has(k))return cache.get(k);const P=fPal(a,rad,R),v=moltenize(metalize(f(a,g,rad),P.metal,P.hot),name,P);cache.set(k,v);return v};nf.molten=1;BATTLE_FORMS[name]=nf})}
moltenAll();
