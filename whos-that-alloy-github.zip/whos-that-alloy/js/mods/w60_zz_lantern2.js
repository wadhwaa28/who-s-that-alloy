/* =============== LANTERN NIGHT AT HOLLOWMERE: thirteen more ===============
   Ten of them come from new things to do in the village (a grave rubbing, chestnuts at the bonfire, the well, the bell, the costume
   judging, an apple peel, a story by the fire, a paper lantern on the burn, the lights on the bog, and the bog gate itself), and three
   more hide in the leaf piles. Several of them have been close to something that happened in Hollowmere a long time ago. */
const LNT_MORE=[
 {name:"Lychmark",how:"rub",comp:[["Pb",55],["Sn",30],["Sb",10],["Cu",5]],d:9.6,mp:240,mag:0,hard:1.8,cond:9,color:"#8E8C88",finish:"m",rar:"uncommon",
  lore:"Rub a stick of charcoal over paper laid on an old gravestone and the words come up out of the stone. On one Hollowmere stone, years ago, they came up as a different set of words from the ones carved on it. The paper was burnt. The charcoal wasn't.",
  uses:"Lettering punches and the soft cames in kirk windows",tmade:"Rubbed off an old stone in the Hollowmere kirkyard"},
 {name:"Roastling",how:"chest",comp:[["Cu",62],["Zn",26],["Fe",6],["Al",6]],d:8.0,mp:900,mag:0,hard:3.8,cond:20,color:"#B87A48",finish:"p",rar:"uncommon",
  lore:"Hollowmere roasts its chestnuts on a long shovel at the edge of the bonfire. Count them on, count them off. One year the count came off one higher than it went on, and the extra one didn't crack when it popped.",
  uses:"Long-handled pans and fire shovels",tmade:"Popped off the chestnut shovel at the Hollowmere bonfire"},
 {name:"Wellwisher",how:"well",comp:[["Cu",75],["Ni",20],["Mn",5]],d:8.9,mp:1170,mag:0,hard:3.6,cond:6,color:"#C8C4BA",finish:"p",rar:"uncommon",
  lore:"Everybody in Hollowmere has dropped a coin in the well and wished. The bucket brings the odd one back up. The village has an unspoken rule about wishes that come back up, which is that you don't make the same one twice.",
  uses:"Bucket hoops, chain links and coins that have to last",tmade:"Hauled up in the Hollowmere well bucket"},
 {name:"Changeringer",how:"bell",comp:[["Cu",76],["Sn",20],["Zn",2],["Pb",2]],d:8.7,mp:900,mag:0,hard:4.5,cond:10,color:"#C8A060",finish:"p",rar:"rare",
  lore:"The kirkyard bell is rung on Lantern Night at dusk, and once more at three in the morning, which nobody asks for and nobody admits to. The rope is worn smooth at a height that suits a tall man. The sexton is not a tall man.",
  uses:"Bells, gongs and anything that ought to ring true",tmade:"Shaken out of the Hollowmere kirkyard bell after a good peal"},
 {name:"Rosettine",how:"contest",comp:[["Al",70],["Zn",18],["Mg",8],["Cu",4]],d:3.2,mp:560,mag:0,hard:3.2,cond:28,color:"#C8CCD4",finish:"p",rar:"uncommon",
  lore:"Best costume on the green gets the rosette. The judging rules were written in 1890 and only one of them has never been broken: no costume may be a lamplighter. Nobody on the council can tell you why, and every one of them will vote to keep it.",
  uses:"Badge pins, prize cups and the clasps on sashes",tmade:"Pinned to the winner at the Hollowmere costume judging"},
 {name:"Longpeel",how:"peel",comp:[["Ni",52],["Ti",45],["Cu",3]],d:6.5,mp:1300,mag:0,hard:4.2,cond:2,color:"#A8A8A4",finish:"m",rar:"uncommon",
  lore:"Peel an apple in one long strip and throw it over your shoulder, and it lands in the shape of a letter. Straighten this one out as much as you like. It always curls back into the same letter.",
  uses:"Springs and wires that have to remember their shape",tmade:"Curled up on the floor of the Hollowmere cider yard, behind somebody's shoulder"},
 {name:"Hearthtale",how:"story",comp:[["Fe",82],["Cr",9],["Ni",5],["Mn",4]],d:7.8,mp:1450,mag:1,hard:5,cond:4,color:"#8A8680",finish:"m",rar:"rare",
  lore:"Every story Hollowmere tells by the fire ends the same way: and he's out there still. Ask whose story it is and you get a different name every time. Ask how it ends and you never do.",
  uses:"Firedogs, hearth plates and grate bars",tmade:"Raked out of the storytelling fire on Hollowmere green"},
 {name:"Driftlight",how:"float",comp:[["Mg",90],["Al",6],["Zn",3],["Mn",1]],d:1.8,mp:620,mag:0,hard:2,cond:20,color:"#CCD0CC",finish:"p",rar:"uncommon",
  lore:"Hollowmere floats paper lanterns down the burn on Lantern Night, all the way out to the bog, for whoever is still out there. Most of them sink. One year one of them came back up the burn, against the current, still lit.",
  uses:"Lightweight floats and lantern frames",tmade:"Fished out of the Hollowmere burn at the end of the lantern float"},
 {name:"Steadyflame",how:"bog",comp:[["Ga",60],["In",25],["Sn",10],["Zn",5]],d:6.4,mp:15,mag:0,hard:0,cond:3.4,color:"#B4B8C0",finish:"p",rar:"rare",
  lore:"Lights dance over Hollowmere bog every Lantern Night, and the old advice is never to follow one. The older advice, the one only the oldest people know, is that one of them is safe to follow: the one that doesn't dance.",
  uses:"Liquid seals and contacts that must never flicker",tmade:"Caught in a jar at the edge of Hollowmere bog, from the light that didn't move"},
 {name:"Homeward",how:"gate",comp:[["Ag",50],["Cu",25],["Sn",15],["Pd",6],["In",4]],d:9.9,mp:780,mag:0,hard:2.8,cond:40,color:"#D8D2C6",finish:"p",rar:"legendary",
  lore:"There is a hook on the bog gate above Hollowmere that has had a lamp on it every Lantern Night for longer than anyone can remember. Under the hook the wood is worn into a hollow, about the size of a hand that rested there a very long time.",
  uses:"Lamp hooks, gate latches and anything meant to see someone home",tmade:"Found hanging on the hook of the bog gate above Hollowmere, the morning after"},
 {name:"Hollowpenny",how:"leaf",comp:[["Cu",93],["Sn",3],["Zn",3],["Fe",1]],d:8.9,mp:1050,mag:0,hard:3,cond:45,color:"#B07048",finish:"p",rar:"uncommon",
  lore:"Hollowmere children used to leave a penny on the bog gatepost on Lantern Night, 'for the lamp oil'. Nobody ever saw who took them, but they were always gone by morning. The leaf piles have been turning up the pennies ever since the children stopped.",
  uses:"Small coin blanks and tokens",tmade:"Turned up in a Hollowmere leaf pile"},
 {name:"Flueling",how:"leaf",comp:[["Fe",74],["Ni",20],["C",3.5],["Si",2.5]],d:7.4,mp:1250,mag:0,hard:4.5,cond:4,color:"#6A6A6E",finish:"m",rar:"uncommon",
  lore:"Hollowmere sweeps its chimneys the week before Lantern Night, so nothing comes down them that oughtn't. One sweep's brush came out of a cold chimney with this caught in the bristles, and a handful of soot shaped like somebody's fingers.",
  uses:"Flue liners and grate parts that live in the heat",tmade:"Swept out of a Hollowmere chimney, then lost in a leaf pile"},
 {name:"Handshadow",how:"leaf",comp:[["Bi",44],["Pb",22],["Sn",18],["In",16]],d:9.3,mp:60,mag:0,hard:1,cond:5,color:"#9A9CA4",finish:"m",rar:"rare",
  lore:"Children make hares on the wall with their hands by candlelight. In one Hollowmere cottage there was one hare too many on the wall, and nobody's hands were making it. It went out with the candle, and this was on the floor where its shadow had been.",
  uses:"Low-melt castings that soften in a warm hand",tmade:"Found on a cottage floor in Hollowmere where a shadow had been"}];
LNT_ALLOYS.push(...LNT_MORE);LNT_MORE.forEach(o=>LNT_NAMES.add(o.name));
{const names=new Set(LNT_MORE.map(o=>o.name)),out=ALLOYS.filter(a=>!(names.has(a.name)&&a.recovered));
  if(out.length!==ALLOYS.length){ALLOYS.length=0;out.forEach((a,i)=>{a.no=i+1;ALLOYS.push(a)})}
  LNT_MORE.forEach(o=>{if(ALLOYS.some(a=>a.name===o.name))return;
    const a={name:o.name,comp:o.comp,d:o.d,mp:o.mp,mag:o.mag,hard:o.hard,cond:o.cond,color:o.color,finish:o.finish,aliases:[],leak:false,real:false,quest:true,event:"lantern",
      fixedHab:"z-hollow",lore:o.lore,uses:o.uses,tmade:o.tmade,made:o.tmade,origin:LNT_ORIGIN,creditKind:"event",lntHow:o.how};
    a.reactive=isReactive(frac(a));ALLOYS.push(a);a.no=ALLOYS.length;a.types=typesOf(a);a.hab="z-hollow";a.rar=o.rar;
    if(a.mp<25){a.form="vial";a.fill="liquid"}else{a.form="rod";a.fill=null}a.cat=categoryOf(a)})}

/* ---- their battle forms, each drawn by hand ---- */
const LIMB=(d,c,w)=>`<path d="${d}" stroke="${FI}" stroke-width="${(w||4)+3}" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" stroke="${c}" stroke-width="${w||4}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;

/* Lychmark: a moth settled on a headstone with a sheet of rubbing paper taped over it, a stick of charcoal in its feet. The words
   have come up on its own wings instead of the paper. */
addForm("Lychmark",{n:"#8A8478",a:"#E8E2D0",rn:"#E8E4F4",rb:"#4A5AA8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(40,118)+
 `<path d="M94 148 V112 Q94 92 118 92 Q142 92 142 112 V148 Z" fill="#8A8A90" ${SW}/><path d="M98 146 V114 Q98 98 118 98 Q138 98 138 114 V146 Z" fill="#F4F0E2" ${SW2}/>`+
 `<path d="M98 112 l6 -4 M132 108 l6 4" stroke="#D8C890" stroke-width="5" stroke-linecap="round" opacity=".8"/>${[118,126,134].map((y,i)=>`<path d="M${104+i*2} ${y} H${132-i*2}" stroke="#6A6A70" stroke-width="2.4" stroke-dasharray="${3+i} 2" opacity=".55"/>`).join("")}`+
 pt("wingB",112,76,`<path d="M110 80 Q130 40 168 42 Q178 62 150 82 Q132 92 112 86 Z" fill="${P.nd}" ${SW}/><path d="M124 66 Q144 52 162 50" stroke="${P.ac}" stroke-width="2" fill="none" opacity=".7"/>`,.15)+
 pt("legF",96,92,`<path d="M92 86 L84 98 M100 88 L96 100" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/><g transform="rotate(-30 88 102)"><rect x="80" y="99" width="16" height="5" rx="1.5" fill="#2A2A2E" ${SW2}/></g>`)+
 `<path d="M76 84 Q78 70 98 70 Q116 72 118 84 Q112 96 96 96 Q80 96 76 84 Z" fill="${P.n}" ${SW}/>${[84,92,100,108].map(x=>`<path d="M${x} 74 Q${x+2} 84 ${x} 94" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`).join("")}`+
 pt("wingF",104,74,`<path d="M100 78 Q96 30 136 22 Q156 30 150 54 Q138 78 104 84 Z" fill="${P.n}" ${SW}/><path d="M108 74 Q108 44 134 34 Q146 40 142 54 Q132 70 108 76 Z" fill="${P.ac}" ${SW2}/>`+
  `<path d="M116 48 h6 v6 h-6 Z M126 44 l4 8 l4 -8 M118 62 h14" stroke="#4A4A50" stroke-width="2.2" fill="none" opacity=".75"/><circle cx="134" cy="62" r="5" fill="${P.nd}" ${SW2}/>`)+
 pt("head",74,80,`<circle cx="70" cy="80" r="14" fill="${P.n}" ${SW}/><path d="M60 72 Q66 68 72 70" stroke="${P.nl}" stroke-width="3" fill="none"/>${E2(64,78,4.4,"#1A1A1A",[-.4,0])}${E2(76,77,3.8,"#1A1A1A",[-.4,0])}`+
  pt("ant",70,66,`<path d="M66 68 Q56 50 46 46" stroke="${FI}" stroke-width="2" fill="none"/>${[0,1,2,3].map(i=>`<path d="M${60-i*4} ${60-i*3.4} l-4 4 M${60-i*4} ${60-i*3.4} l2 -5" stroke="${FI}" stroke-width="1.4"/>`).join("")}<path d="M74 68 Q78 50 88 42" stroke="${FI}" stroke-width="2" fill="none"/>`)+
  pt("jaw",64,90,`<path d="M58 88 Q64 96 70 88 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M40 120 q3 -6 6 0 q3 6 6 0" stroke="#8A8A90" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="100" cy="86" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Lychmark"]="Grave-Rubbing Moth";SM("Lychmark","Raise The Letters","SCR","s",0,100,"tacc-1,def+1","Charcoal over paper, and the words come up out of the stone. Not always the words that were carved.");

/* Roastling: a hedgehog stood up on its hind legs at the fire, its spines gone to chestnut burrs, holding out the long roasting shovel. */
addForm("Roastling",{n:"#8A5A34",a:"#E8C890",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#FF8A2A"},"stand",(P,g)=>fShadow(46,96)+
 [[84,"legB",.25],[106,"legF",0]].map(([x,c,d])=>pt(c,x,132,`<path d="M${x} 128 Q${x-2} 140 ${x-8} 144" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M${x} 128 Q${x-2} 140 ${x-8} 144" stroke="#C8A080" stroke-width="4" fill="none" stroke-linecap="round"/>`,d)).join("")+
 /* the spines: a cloak of chestnut burrs, every one a point */
 `<path d="M68.3 118.0 L75.8 108.6 L66.0 102.1 L76.4 96.6 L69.7 86.5 L81.2 85.7 L78.7 73.6 L89.6 77.6 L91.6 65.4 L100.2 73.7 L106.4 63.3 L111.4 74.4 L120.9 67.4 L121.4 79.8 L132.7 77.3 L128.8 88.9 L140.1 91.3 L132.3 100.4 L141.9 107.2 L131.4 112.4 L137.8 122.7 L126.3 123.1 L128.4 135.3 Q104 146 74 132 Z" fill="${P.nd}" ${SW}/><path d="M80 96 L74 88 M92 80 L88 70 M108 74 L108 64 M122 80 L128 72 M132 96 L140 92 M134 114 L142 116" stroke="${P.nl}" stroke-width="2" stroke-linecap="round" opacity=".7"/>`+
 `<path d="M84 128 Q80 104 94 90 Q110 92 112 118 Q108 134 94 134 Q86 134 84 128 Z" fill="${P.ac}" ${SW2}/>`+
 /* the shovel, with chestnuts popping on it */
 pt("armF",88,104,`<path d="M90 106 L46 96" stroke="#5A3A20" stroke-width="5" stroke-linecap="round"/><path d="M90 106 L46 96" stroke="#8A6A44" stroke-width="2.4" stroke-linecap="round"/>`+
  `<path d="M48 88 L16 82 Q10 94 18 104 L48 104 Z" fill="#4A4A50" ${SW2}/>${[[24,92],[34,94],[28,98],[40,96]].map(([x,y],i)=>`<g class="pt p-spin" style="transform-origin:${x}px ${y}px;--dl:${i*.3}s"><path d="M${x-4} ${y+2} Q${x} ${y-6} ${x+4} ${y+2} Q${x} ${y+4} ${x-4} ${y+2} Z" fill="#7A4220" stroke="${FI}" stroke-width="1.2"/><path d="M${x-1} ${y-2} l2 -2" stroke="#F4E0B0" stroke-width="1.4"/></g>`).join("")}`+
  LIMB("M92 106 Q86 100 84 98","#C8A080",4))+
 pt("head",90,74,`<path d="M100 66 Q86 56 70 64 Q58 70 54 78 Q66 86 86 84 Q100 80 100 66 Z" fill="#C8A080" ${SW}/><circle cx="54" cy="78" r="3.6" fill="#2A1A10" ${SW2}/>${E2(74,70,4,"#1A1A1A",[-.3,0])}`+
  pt("ear",88,58,`<circle cx="88" cy="58" r="5" fill="#C8A080" ${SW2}/><circle cx="88" cy="58" r="2.2" fill="#8A5A44"/>`)+pt("jaw",64,82,`<path d="M58 80 Q64 90 72 82 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M20 60 q2 -6 4 0 M36 54 q2 -6 4 0" stroke="#FF8A2A" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="98" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(166,40,6)));
FORM_TITLE["Roastling"]="Chestnut-Roasting Hedgehog";SM("Roastling","Count Them Off","HEA","a",60,95,"multi:2-3","Shake the shovel and they pop off the heat one after another. Count them. Count them again.");

/* Wellwisher: a toad sitting in the well bucket, arms folded over the rim, with a wished-on coin balanced on its head. */
addForm("Wellwisher",{n:"#7A8A4A",a:"#E8E0A0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"stand",(P,g)=>fShadow(50,100)+
 `<path d="M100 22 V54" stroke="#6A6A70" stroke-width="3" stroke-dasharray="4 2"/><path d="M70 66 Q100 34 130 66" stroke="#4A4A50" stroke-width="3.4" fill="none"/>`+
 `<path d="M60 92 L68 146 H132 L140 92 Z" fill="#8A6A44" ${SW}/>${[74,88,100,112,126].map(x=>`<path d="M${x} 94 L${x+(x-100)*.12} 146" stroke="#5A4228" stroke-width="2"/>`).join("")}<path d="M62 106 H138 M66 134 H134" stroke="#4A4A50" stroke-width="4"/>`+
 pt("sway",100,92,`<path d="M66 92 Q66 62 100 60 Q134 62 134 92 Z" fill="${P.n}" ${SW}/><path d="M78 84 Q82 72 92 74 M112 74 Q122 72 124 84" stroke="${P.nd}" stroke-width="2" fill="none"/>${[[84,80],[118,78],[100,70]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.6" fill="${P.nd}"/>`).join("")}`+
  pt("head",100,66,`<path d="M74 70 Q72 44 100 42 Q128 44 126 70 Z" fill="${P.n}" ${SW}/><path d="M84 66 Q100 72 116 66" stroke="${P.ac}" stroke-width="4" fill="none" stroke-linecap="round"/>`+
   `<circle cx="84" cy="46" r="9" fill="${P.n}" ${SW2}/><circle cx="116" cy="46" r="9" fill="${P.n}" ${SW2}/>${E2(84,45,5.4,"#C88A2A",[0,.2])}${E2(116,45,5.4,"#C88A2A",[0,.2])}`+
   pt("jaw",100,64,`<path d="M82 62 Q100 74 118 62 Q100 66 82 62 Z" fill="${FMOUTH}"/>`)+
   pt("slow",100,30,`<ellipse cx="100" cy="34" rx="9" ry="4" fill="#C8C4BA" ${SW2}/><ellipse cx="100" cy="33" rx="5" ry="2" fill="none" stroke="#8A867C" stroke-width="1"/>`))+
  pt("armF",76,92,`<path d="M70 86 Q62 96 72 100 L88 98" fill="${P.n}" ${SW2}/><path d="M80 98 l2 4 M86 98 l2 4" stroke="${FI}" stroke-width="1.6"/>`)+pt("armB",124,92,`<path d="M130 86 Q138 96 128 100 L112 98" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<path d="M30 120 q4 -4 8 0 M162 120 q4 -4 8 0" stroke="#8AB8D8" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="100" cy="122" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(166,40,6)));
FORM_TITLE["Wellwisher"]="Well-Bucket Toad";SM("Wellwisher","Wish Again","CUR","s",0,100,"tacc-1@60","It's wishing. You can tell, because its eyes are shut and the coin is balanced exactly.");

/* Changeringer: a bat hanging upside down from the bell rope's woolly sally, the bell itself up in the frame above. */
addForm("Changeringer",{n:"#5A4A40",a:"#D84A3A",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"perch",(P,g)=>
 `<path d="M60 6 H144" stroke="#4A3422" stroke-width="7" stroke-linecap="round"/><path d="M66 6 V2 M138 6 V2" stroke="#4A3422" stroke-width="5"/>`+
 pt("slow",102,10,`<path d="M84 10 Q82 36 76 44 H128 Q122 36 120 10 Z" fill="#C8A060" ${SW}/><path d="M76 44 Q102 52 128 44" stroke="${FI}" stroke-width="3" fill="none"/><path d="M90 16 Q88 32 86 40" stroke="#F4E0A8" stroke-width="2.4" fill="none"/>`+
  `<path d="M102 44 V96" stroke="#8A7A5A" stroke-width="3.4"/><path d="M96 70 h12 v18 h-12 Z" fill="${P.ac}" ${SW2}/><path d="M96 76 h12 M96 82 h12" stroke="#F4ECD8" stroke-width="2"/>`+
  /* the bat, hanging from the sally by its feet */
  `<path d="M98 92 L96 100 M106 92 L108 100" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`+
  pt("wingB",118,112,`<path d="M108 100 Q140 92 158 104 Q150 112 152 124 Q140 118 136 128 Q126 118 110 124 Z" fill="${P.nd}" ${SW}/><path d="M118 108 L150 108 M118 114 L138 124" stroke="${P.ndd}" stroke-width="1.6"/>`,.25)+
  `<path d="M90 100 Q86 118 92 128 Q102 136 112 128 Q118 118 114 100 Q102 96 90 100 Z" fill="${P.n}" ${SW}/>`+
  pt("wingF",88,112,`<path d="M96 100 Q64 92 46 104 Q54 112 52 124 Q64 118 68 128 Q78 118 94 124 Z" fill="${P.n}" ${SW}/><path d="M86 108 L54 108 M86 114 L66 124" stroke="${P.nd}" stroke-width="1.6"/>`)+
  pt("head",102,132,`<path d="M88 128 Q88 148 102 148 Q116 148 116 128 Z" fill="${P.n}" ${SW}/>`+pt("ear",92,148,`<path d="M92 146 L86 158 L98 150 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",112,148,`<path d="M112 146 L118 158 L106 150 Z" fill="${P.n}" ${SW2}/>`,.3)+
   `${E2(96,138,3.4,"#1A1A1A",[0,-.3])}${E2(108,138,3.4,"#1A1A1A",[0,-.3])}<path d="M100 130 l2 -3 l2 3" fill="#E8A8A8" stroke="${FI}" stroke-width="1"/>`+pt("jaw",102,132,`<path d="M96 132 Q102 124 108 132 Z" fill="${FMOUTH}"/><path d="M98 131 l1 -2 M106 131 l-1 -2" stroke="#FFF" stroke-width="1"/>`)))+
 fG(g,1,`<path d="M40 30 q6 -6 12 0 M150 30 q6 -6 12 0" stroke="#C8A060" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="102" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,80,6)));
FORM_TITLE["Changeringer"]="Bell-Rope Bat";SM("Changeringer","Rounds And Changes","STR","a",70,95,"tacc-1@40","Pull, catch the sally, let it fly, and the whole frame sings. Somebody is still ringing at three in the morning.");

/* Rosettine: a barn owl in a bedsheet with two holes cut for its eyes, a prize rosette pinned to the front. */
addForm("Rosettine",{n:"#F4F0E6",a:"#C83A2A",rn:"#3A3A5A",rb:"#C8B8F0",ra:"#F2C94C"},"stand",(P,g)=>fShadow(44,100)+
 pt("legB",112,140,`<path d="M110 136 v8 M106 146 h10" stroke="#C8A060" stroke-width="3" stroke-linecap="round"/>`,.3)+
 /* the sheet: a ghost shape, with hem and folds */
 `<path d="M70 140 Q64 110 68 84 Q72 44 100 42 Q128 44 132 84 Q136 110 130 140 Q124 134 118 142 Q112 134 106 142 Q100 134 94 142 Q88 134 82 142 Q76 134 70 140 Z" fill="${P.n}" ${SW}/>`+
 `<path d="M80 96 Q84 120 80 136 M118 100 Q114 120 120 136" stroke="${P.nd}" stroke-width="2" fill="none"/>`+
 pt("legF",92,140,`<path d="M92 136 v8 M86 146 h12" stroke="#C8A060" stroke-width="3" stroke-linecap="round"/>`)+
 pt("wingF",74,98,`<path d="M72 86 Q56 100 62 120 Q72 112 78 100 Z" fill="${P.n}" ${SW}/>`)+pt("wingB",128,98,`<path d="M128 86 Q144 100 138 120 Q128 112 122 100 Z" fill="${P.n}" ${SW}/>`,.3)+
 /* the rosette */
 `<g transform="translate(112 104)">${[0,1,2,3,4,5,6,7].map(i=>`<ellipse cx="0" cy="-8" rx="4" ry="7" fill="${P.ac}" stroke="${FI}" stroke-width="1.2" transform="rotate(${i*45})"/>`).join("")}<circle r="6" fill="#F2C94C" stroke="${FI}" stroke-width="1.4"/><text x="0" y="2.6" font-size="7" text-anchor="middle" font-weight="bold" fill="${FI}">1</text><path d="M-4 8 L-8 24 L-3 20 L0 26 M4 8 L8 24 L3 20" fill="${P.ac}" stroke="${FI}" stroke-width="1.2"/></g>`+
 pt("head",100,62,`<path d="M74 70 Q72 40 100 38 Q128 40 126 70 Q114 80 100 80 Q86 80 74 70 Z" fill="${P.n}" ${SW}/><path d="M80 52 Q100 44 120 52" stroke="${P.nd}" stroke-width="1.6" fill="none"/>`+
  `<ellipse cx="88" cy="62" rx="8" ry="9" fill="#1A1610" ${SW2}/><ellipse cx="112" cy="62" rx="8" ry="9" fill="#1A1610" ${SW2}/>${E2(88,62,4.4,"#1A1A1A",[0,0])}${E2(112,62,4.4,"#1A1A1A",[0,0])}`+
  `<path d="M96 70 L100 78 L104 70 Z" fill="#E8C090" ${SW2}/>`+pt("beak",100,76,`<path d="M97 76 L100 82 L103 76 Z" fill="#C8A060" stroke="${FI}" stroke-width="1"/>`))+
 fG(g,1,`<path d="M36 50 q4 -6 8 0 M158 50 q4 -6 8 0" stroke="#C8CCD4" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="100" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,120,6)));
FORM_TITLE["Rosettine"]="Bedsheet-Ghost Barn Owl";SM("Rosettine","Best On The Green","RES","s",0,100,"spd+1,tacc-1","Two eyeholes, a lot of flapping, and a rosette. It knows it's won. It wants you to know it's won.");

/* Longpeel: a grass snake that is one long unbroken apple peel, coiled round the bare apple it came off. */
addForm("Longpeel",{n:"#C83A2A",a:"#F4ECC0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#6BE08A"},"slink",(P,g)=>fShadow(56,100)+
 `<circle cx="104" cy="118" r="26" fill="#F4ECC0" ${SW}/><path d="M104 92 Q102 84 106 80" stroke="#5A3A1A" stroke-width="3" fill="none"/><path d="M92 106 Q96 100 102 102" stroke="#FFF" stroke-width="3" fill="none" opacity=".8"/><circle cx="114" cy="126" r="2" fill="#C8B880"/>`+
 /* the peel: two tones, skin outside and white flesh showing on the edge, wound round and round */
 pt("tail",150,132,`<path d="M134 138 Q160 146 176 132 Q186 120 176 112" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M134 138 Q160 146 176 132 Q186 120 176 112" stroke="${P.n}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M136 141 Q160 148 177 135" stroke="${P.ac}" stroke-width="2" fill="none"/>`)+
 `<path d="M76 136 Q100 150 134 138" stroke="${FI}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M76 136 Q100 150 134 138" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M78 140 Q100 152 132 142" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
 `<path d="M76 136 Q70 112 84 100 Q100 90 120 98" stroke="${FI}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M76 136 Q70 112 84 100 Q100 90 120 98" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M72 128 Q68 110 82 98" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
 pt("sway",120,98,`<path d="M120 98 Q138 106 134 82 Q128 62 104 60" stroke="${FI}" stroke-width="14" fill="none" stroke-linecap="round"/><path d="M120 98 Q138 106 134 82 Q128 62 104 60" stroke="${P.n}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M138 90 Q136 70 116 62" stroke="${P.ac}" stroke-width="2.4" fill="none"/>`+
  pt("head",92,60,`<path d="M106 54 Q90 48 74 54 Q62 60 66 68 Q80 72 104 68 Z" fill="${P.n}" ${SW}/><path d="M72 64 Q88 68 104 64" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${E2(80,58,4,"#1A1A1A",[-.4,0])}`+
   pt("tongue",64,64,`<path d="M66 64 L52 64 L46 60 M52 64 L46 68" stroke="#C8243A" stroke-width="1.8" fill="none" stroke-linecap="round"/>`)+pt("jaw",72,66,`<path d="M66 66 Q74 74 86 68 Z" fill="${FMOUTH}"/>`)))+
 fG(g,1,`<path d="M30 70 q4 -6 8 0" stroke="#C83A2A" stroke-width="2.4" fill="none"/>`)+fG(g,2,`<circle cx="104" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,50,6)));
FORM_TITLE["Longpeel"]="Apple-Peel Grass Snake";SM("Longpeel","Over Your Shoulder","CUR","s",0,100,"tacc-1,tspd-1@40","Throw it over your shoulder and see what letter it makes. It always makes the same one.");

/* Hearthtale: a nightjar perched on a three-legged stool by a little fire, one wing flung up mid-story, its huge gape open. */
addForm("Hearthtale",{n:"#7A6450",a:"#E8D8B8",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(54,106)+
 `<path d="M140 146 L148 128 M160 146 L156 128 M172 146 L164 128" stroke="#4A3020" stroke-width="3" stroke-linecap="round"/><ellipse cx="156" cy="146" rx="20" ry="4" fill="#3A2A20"/>`+
 pt("spin",156,128,`<path d="M146 140 Q144 126 152 118 Q150 128 156 130 Q156 116 164 110 Q162 124 168 128 Q170 136 164 142 Z" fill="#FF8A2A" stroke="#8A2A0A" stroke-width="1.4"/><path d="M152 140 Q152 132 156 128 Q160 134 160 140 Z" fill="#FFD23F"/>`)+
 `<path d="M70 120 H124 V128 H70 Z" fill="#8A6A44" ${SW2}/><path d="M76 128 L70 148 M118 128 L124 148 M97 128 V148" stroke="#5A3A20" stroke-width="4" stroke-linecap="round"/>`+
 pt("tail",128,108,`<path d="M124 106 L156 116 L150 104 L156 96 L122 98 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legF",96,118,`<path d="M92 112 v8 M102 112 v8" stroke="${FI}" stroke-width="2.4"/>`)+
 `<path d="M74 100 Q74 80 98 78 Q124 80 128 102 Q116 116 98 116 Q80 116 74 100 Z" fill="${P.n}" ${SW}/>${[[86,90],[100,96],[112,90],[94,106],[114,104]].map(([x,y])=>`<path d="M${x-4} ${y} q4 -3 8 0" stroke="${P.ac}" stroke-width="1.8" fill="none"/>`).join("")}`+
 pt("wingF",112,90,`<path d="M108 92 Q118 60 150 48 Q154 58 146 64 Q152 68 142 76 Q144 84 116 98 Z" fill="${P.nd}" ${SW}/><path d="M120 84 L144 62 M118 90 L140 76" stroke="${P.ac}" stroke-width="1.6"/>`)+
 pt("head",84,78,`<path d="M66 82 Q62 60 82 56 Q102 56 102 76 Q96 86 82 86 Q70 86 66 82 Z" fill="${P.n}" ${SW}/><path d="M70 70 Q78 66 88 70" stroke="${P.ac}" stroke-width="2.4" fill="none"/>${E2(80,66,4.6,"#1A1A1A",[-.3,-.1])}`+
  `<path d="M66 76 Q58 76 56 78 Q62 80 68 80" fill="${P.nd}" ${SW2}/>`+pt("jaw",66,80,`<path d="M68 78 Q54 84 58 92 Q70 92 76 82 Z" fill="${FMOUTH}" ${SW2}/><path d="M58 88 q6 -2 12 -6" stroke="#E87A8A" stroke-width="2.4" fill="none"/>`))+
 fG(g,1,`<path d="M30 40 q8 -10 16 0 q8 10 16 0" stroke="#B8B0A0" stroke-width="2" fill="none" opacity=".7"/>`)+fG(g,2,`<circle cx="98" cy="100" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Hearthtale"]="Fireside Storytelling Nightjar";SM("Hearthtale","And He's Out There Still","CUR","s",0,100,"tatk-1,tacc-1@30","It leans in close to the fire and drops its voice for the end. Everybody leans in. Nobody likes the end.");

/* Driftlight: an otter floating on its back down the burn, a lit paper lantern held up on its chest. */
addForm("Driftlight",{n:"#7A5A3E",a:"#E8D8C0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#FF8A2A"},"swim",(P,g)=>
 `<ellipse cx="102" cy="132" rx="92" ry="16" fill="#4A7A9A" opacity=".8"/><ellipse cx="102" cy="130" rx="70" ry="9" fill="#5A8AAA" opacity=".6"/>`+`<path d="M20 128 q10 -4 20 0 M80 126 q10 -4 20 0 M140 130 q10 -4 20 0" stroke="#BFE2F4" stroke-width="2" fill="none"/>`+
 pt("tail",150,122,`<path d="M140 120 Q166 116 184 126 Q166 130 140 128 Z" fill="${P.nd}" ${SW2}/>`)+
 pt("legF",136,112,`<path d="M134 114 Q146 104 152 108 Q148 116 138 118" fill="${P.nd}" ${SW2}/>`)+
 `<path d="M56 124 Q60 104 96 102 Q134 102 144 120 Q132 132 96 132 Q66 132 56 124 Z" fill="${P.n}" ${SW}/><path d="M74 112 Q96 106 124 112 Q112 122 92 122 Q78 120 74 112 Z" fill="${P.ac}"/>`+
 /* the lantern on its chest */
 pt("sway",100,100,`<path d="M100 104 V96" stroke="${FI}" stroke-width="1.6"/><path d="M86 70 Q84 86 90 96 H110 Q116 86 114 70 Z" fill="#F4E8C8" ${SW2}/><path d="M86 70 H114 M88 80 H112 M88 90 H112" stroke="#C8A878" stroke-width="1.4"/><ellipse cx="100" cy="84" rx="6" ry="9" fill="#FFD66B" opacity=".9"/><path d="M100 80 Q103 84 100 88 Q97 84 100 80 Z" fill="#FF8A2A"/><circle cx="100" cy="84" r="20" fill="#FFD66B" opacity=".18"/><path d="M92 66 H108 L106 70 H94 Z" fill="#5A3A20"/>`)+
 pt("armF",86,104,`<path d="M84 106 Q84 98 90 96" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M84 106 Q84 98 90 96" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+pt("armB",116,104,`<path d="M116 106 Q116 98 110 96" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M116 106 Q116 98 110 96" stroke="${P.n}" stroke-width="3" fill="none" stroke-linecap="round"/>`,.3)+
 pt("head",58,110,`<path d="M66 120 Q60 98 44 100 Q28 104 30 116 Q36 126 58 124 Z" fill="${P.n}" ${SW}/><path d="M34 112 Q42 118 52 116" fill="${P.ac}"/><circle cx="31" cy="110" r="3" fill="#1A1A1A"/>${E2(44,106,3.6,"#1A1A1A",[-.2,-.4])}`+
  `<path d="M36 114 l-10 -2 M36 116 l-10 2" stroke="${FI}" stroke-width="1"/>`+pt("ear",54,100,`<circle cx="54" cy="100" r="4" fill="${P.n}" ${SW2}/>`)+pt("jaw",40,118,`<path d="M36 116 Q42 124 50 118 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<circle cx="160" cy="60" r="3" fill="#FFD66B" opacity=".7"/><circle cx="40" cy="60" r="2" fill="#FFD66B" opacity=".6"/>`)+fG(g,2,`<circle cx="100" cy="120" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,40,6)));
FORM_TITLE["Driftlight"]="Lantern-Floating Otter";SM("Driftlight","Down To The Bog","HEA","a",55,100,"heal:15","It drifts off with the current, light held up, all the way out to whoever's waiting.");

/* Steadyflame: a glow-worm larva with a little lamp for a tail end, which burns perfectly still while everything else about it wiggles. */
addForm("Steadyflame",{n:"#5A5040",a:"#E8E0C0",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#7AE8FF"},"crawl",(P,g)=>fShadow(60,104)+
 `<path d="M20 146 Q40 132 60 146 M150 146 Q166 134 184 146" stroke="#4A6A3A" stroke-width="3" fill="none"/><path d="M28 146 v-12 M34 146 v-16 M170 146 v-14" stroke="#5A7A4A" stroke-width="2.4"/>`+
 [70,88,106,124].map((x,i)=>pt(i%2?"legB":"legF",x,136,`<path d="M${x} 132 l-4 10" stroke="${FI}" stroke-width="2.4" stroke-linecap="round"/>`,i*.12)).join("")+
 [[66,120,14],[84,118,15],[102,118,15],[120,120,14]].map(([x,y,r],i)=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.92}" fill="${i%2?P.nd:P.n}" ${SW}/><path d="M${x-r*.6} ${y-r*.5} Q${x} ${y-r*.9} ${x+r*.6} ${y-r*.5}" stroke="${P.ac}" stroke-width="2" fill="none"/>`).join("")+
 /* the lamp end: a glass chimney, a still flame, and steady light */
 `<circle cx="150" cy="112" r="30" fill="#FFE6A0" opacity=".2"/><circle cx="150" cy="112" r="20" fill="#FFE6A0" opacity=".25"/>`+
 `<path d="M134 124 Q134 104 150 102 Q166 104 166 124 Q160 134 150 134 Q140 134 134 124 Z" fill="#F4ECC8" ${SW}/><path d="M140 104 Q138 90 144 82 H156 Q162 90 160 104" fill="#E6F6FF" fill-opacity=".7" ${SW2}/><path d="M150 86 Q155 94 150 102 Q145 94 150 86 Z" fill="#FFB43A" stroke="#C86A1A" stroke-width="1"/><path d="M142 80 H158" stroke="${FI}" stroke-width="2.4"/>`+
 pt("head",50,116,`<path d="M58 104 Q42 98 32 108 Q26 120 36 128 Q50 132 60 124 Z" fill="${P.n}" ${SW}/>${E2(40,112,4,"#1A1A1A",[-.4,0])}`+
  pt("ant",40,102,`<path d="M40 104 Q34 88 26 84 M46 102 Q46 86 40 78" stroke="${FI}" stroke-width="2" fill="none" stroke-linecap="round"/>`)+pt("jaw",34,124,`<path d="M30 122 Q34 130 42 126 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<circle cx="30" cy="60" r="2" fill="#9AFF9A" opacity=".5"/><circle cx="180" cy="50" r="2" fill="#9AFF9A" opacity=".5"/>`)+fG(g,2,`<circle cx="94" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,40,6)));
FORM_TITLE["Steadyflame"]="Lamp-Tailed Glow-Worm";SM("Steadyflame","The One That Doesn't Dance","RAD","s",0,100,"tacc-2@50","Every other light on the bog wanders off. This one stays exactly where it is, and waits.");

/* Homeward: an old sheepdog sitting by the post of a field gate, an oil lamp hung on the hook above it, its head turned out towards
   the dark, waiting for somebody to come up the path. */
addForm("Homeward",{n:"#4A4040",a:"#F4F0E6",rn:"#F4F0E6",rb:"#3A4A8A",ra:"#FFD66B"},"stand",(P,g)=>fShadow(50,110)+
 `<path d="M150 148 V30" stroke="#4A3422" stroke-width="12" stroke-linecap="round"/><path d="M150 148 V30" stroke="#6A4A30" stroke-width="7" stroke-linecap="round"/><path d="M156 60 H196 M156 96 H196 M156 128 H196 M166 60 L192 128" stroke="#6A4A30" stroke-width="6" stroke-linecap="round"/>`+
 `<path d="M146 44 Q138 44 138 52" stroke="#3A3430" stroke-width="2.6" fill="none"/><path d="M150 38 h6" stroke="#3A3430" stroke-width="3"/>`+
 pt("slow",138,52,`<circle cx="138" cy="72" r="26" fill="#FFD66B" opacity=".16"/><path d="M138 52 V56" stroke="#3A3430" stroke-width="1.6"/><path d="M130 56 H146 L148 60 V80 H128 V60 Z" fill="#FFE6A0" ${SW2}/><path d="M128 60 H148 M128 80 H148" stroke="${FI}" stroke-width="2.4"/><path d="M138 64 Q142 70 138 76 Q134 70 138 64 Z" fill="#FF8A2A"/>`)+
 pt("tail",128,132,`<path d="M126 134 Q150 140 156 124 Q160 112 150 108" stroke="${FI}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M126 134 Q150 140 156 124 Q160 112 150 108" stroke="${P.n}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M152 112 Q158 116 154 122" stroke="${P.ac}" stroke-width="3" fill="none" stroke-linecap="round"/>`)+
 pt("legB",120,136,`<path d="M110 130 Q124 128 130 140 L114 146 Z" fill="${P.n}" ${SW}/>`,.2)+
 `<path d="M84 146 Q78 112 88 92 Q100 78 116 86 Q132 100 130 134 Q122 146 104 146 Z" fill="${P.n}" ${SW}/><path d="M88 92 Q96 104 94 122 Q90 136 92 146 L84 146 Q78 112 88 92 Z" fill="${P.ac}"/>`+
 pt("legF",90,128,`<path d="M88 112 V144 M98 112 V144" stroke="${FI}" stroke-width="7" stroke-linecap="round"/><path d="M88 112 V144 M98 112 V144" stroke="${P.ac}" stroke-width="4" stroke-linecap="round"/>`)+
 pt("head",88,80,`<path d="M100 82 Q100 58 84 56 Q66 56 60 66 Q50 70 50 78 Q56 86 72 86 Q88 92 100 82 Z" fill="${P.n}" ${SW}/><path d="M60 68 Q70 64 76 70 Q74 80 62 82 Q52 80 50 78 Q52 70 60 68 Z" fill="${P.ac}"/><circle cx="50" cy="76" r="3.4" fill="#1A1A1A"/>${E2(78,68,4,"#4A2A10",[-.6,0])}`+
  `<path d="M74 64 Q78 62 82 64" stroke="${P.nl}" stroke-width="1.6" fill="none"/>`+pt("ear",88,58,`<path d="M86 60 Q90 46 98 52 Q100 60 94 66 Z" fill="${P.nd}" ${SW2}/>`)+pt("jaw",62,84,`<path d="M54 82 Q62 92 74 86 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<circle cx="30" cy="40" r="1.6" fill="#FFF"/><circle cx="56" cy="22" r="1.2" fill="#FFF"/><circle cx="20" cy="70" r="1.2" fill="#FFF"/>`)+fG(g,2,`<circle cx="108" cy="116" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(30,110,6)));
FORM_TITLE["Homeward"]="Gate-Waiting Lamp Hound";SM("Homeward","Light Them Home","HEA","s",0,100,"heal:50,cure,ward+1","The lamp stays lit on the gate, and the dog stays by the post, until whoever it's waiting for comes up the path.");

/* Hollowpenny: a magpie on a gatepost with a penny wedged over one eye like a monocle, very pleased with itself. */
addForm("Hollowpenny",{n:"#1E1E28",a:"#F4F4F8",rn:"#F4F0F8",rb:"#3A5AA8",ra:"#F2C94C"},"perch",(P,g)=>fShadow(30,106)+
 `<path d="M96 148 V112 H118 V148 Z" fill="#6A4A30" ${SW}/><path d="M94 112 H120" stroke="${FI}" stroke-width="3"/><circle cx="104" cy="120" r="1.6" fill="#3A2A1A"/>`+
 pt("tail",128,96,`<path d="M124 96 L180 78 L182 86 L128 104 Z" fill="${P.n}" ${SW2}/><path d="M136 94 L178 80" stroke="#3A5AA8" stroke-width="2" opacity=".7"/>`)+
 pt("legF",104,108,`<path d="M100 102 v10 M110 102 v10" stroke="${FI}" stroke-width="2.4"/>`)+
 `<path d="M84 96 Q84 74 104 72 Q126 74 130 96 Q118 108 104 108 Q90 108 84 96 Z" fill="${P.n}" ${SW}/><path d="M86 94 Q90 80 102 82 Q100 98 90 104 Q86 100 86 94 Z" fill="${P.ac}"/>`+
 pt("wingF",112,86,`<path d="M100 82 Q122 76 134 92 Q120 100 104 96 Z" fill="${P.n}" ${SW2}/><path d="M106 86 Q118 84 126 90" stroke="${P.ac}" stroke-width="3" fill="none"/>`)+
 pt("head",92,62,`<circle cx="92" cy="60" r="15" fill="${P.n}" ${SW}/>`+
  `<circle cx="86" cy="58" r="7.6" fill="#B07048" ${SW2}/><circle cx="86" cy="58" r="5.4" fill="none" stroke="#E8A878" stroke-width="1.2"/><path d="M93 58 Q100 64 98 76" stroke="#C8A060" stroke-width="1" fill="none"/>`+
  `${E2(98,56,2.8,"#1A1A1A",[-.4,0])}<path d="M78 64 L62 66 L78 68 Z" fill="${FMOUTH}"/>`+pt("beak",78,68,`<path d="M78 68 L62 68 L76 72 Z" fill="#2A2A30" ${SW2}/>`)+`<path d="M78 62 L60 66 L78 66 Z" fill="#2A2A30" ${SW2}/>`)+
 fG(g,1,`<circle cx="40" cy="50" r="5" fill="#B07048" ${SW2}/><circle cx="160" cy="40" r="4" fill="#B07048" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="96" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,120,6)));
FORM_TITLE["Hollowpenny"]="Penny-Monocled Magpie";SM("Hollowpenny","For The Lamp Oil","QUE","a",60,100,"tacc-1@30","A penny left on the gatepost, and a magpie that thinks it's for it. It isn't. It took it anyway.");

/* Flueling: a swift bursting out of a chimney pot in a cloud of soot, clutching a sweep's brush. */
addForm("Flueling",{n:"#3A3A44",a:"#E8E4DA",rn:"#E8E4F0",rb:"#3A5AA8",ra:"#F2C94C"},"hover",(P,g)=>
 `<path d="M78 148 L84 104 H124 L130 148 Z" fill="#A85A3A" ${SW}/><path d="M80 120 H128 M82 134 H126 M96 104 V120 M112 120 V134 M98 134 V148" stroke="#6A3420" stroke-width="2"/><path d="M80 96 H128 V106 H80 Z" fill="#B86A44" ${SW}/>`+
 `${[[90,90,10],[112,84,12],[100,72,9],[122,70,7]].map(([x,y,r],i)=>`<circle class="pt p-slow" style="transform-origin:${x}px ${y}px;--dl:${i*.4}s" cx="${x}" cy="${y}" r="${r}" fill="#2A2A30" opacity=".55"/>`).join("")}`+
 pt("tail",126,54,`<path d="M122 56 L160 70 L150 58 L164 50 Z" fill="${P.n}" ${SW2}/>`)+
 pt("wingB",112,52,`<path d="M108 54 Q140 18 180 10 Q160 34 116 62 Z" fill="${P.nd}" ${SW}/>`,.2)+
 `<path d="M84 60 Q86 46 104 44 Q124 46 128 58 Q118 70 102 70 Q88 70 84 60 Z" fill="${P.n}" ${SW}/><path d="M90 60 Q96 66 110 66" stroke="${P.ac}" stroke-width="3" fill="none"/>`+
 pt("wingF",100,56,`<path d="M100 58 Q70 26 28 22 Q48 46 92 66 Z" fill="${P.n}" ${SW}/><path d="M90 56 Q66 38 40 30" stroke="${P.nl}" stroke-width="1.6" fill="none"/>`)+
 /* the sweep's brush, in its feet */
 pt("legF",106,70,`<path d="M100 68 L88 92" stroke="#6A4A2A" stroke-width="3.4" stroke-linecap="round"/><g transform="translate(86 96)">${Array.from({length:10},(_,i)=>`<path d="M0 0 L${(Math.cos(i*.63)*12).toFixed(1)} ${(Math.sin(i*.63)*12).toFixed(1)}" stroke="#1A1A1E" stroke-width="2"/>`).join("")}<circle r="3" fill="#6A4A2A"/></g>`)+
 pt("head",86,52,`<circle cx="84" cy="50" r="12" fill="${P.n}" ${SW}/><path d="M76 54 Q80 58 86 58" fill="${P.ac}" stroke="none"/>${E2(80,47,3.4,"#1A1A1A",[-.4,0])}`+
  `<path d="M73 50 L64 50 L72 53 Z" fill="${FMOUTH}"/>`+pt("beak",72,52,`<path d="M72 52 L64 52 L72 56 Z" fill="#1A1A1E" ${SW2}/>`)+`<path d="M73 47 L62 50 L73 50 Z" fill="#1A1A1E" ${SW2}/>`)+
 fG(g,1,`<circle cx="40" cy="110" r="4" fill="#2A2A30" opacity=".4"/><circle cx="160" cy="120" r="5" fill="#2A2A30" opacity=".4"/>`)+fG(g,2,`<circle cx="106" cy="58" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,110,6)));
FORM_TITLE["Flueling"]="Chimney-Sweeping Swift";SM("Flueling","Up The Flue","DRP","a",65,100,"tacc-1@30","Out of the chimney pot in a bang of soot, brush first, and nothing that oughtn't come down it gets a chance to.");

/* Handshadow: the hare that turns up on the wall by candlelight with nobody's hands making it. It's a shadow puppet that has come
   off the wall: flat, ragged at the edges, with a candle in front of it throwing it. */
addForm("Handshadow",{n:"#2A2830",a:"#F4E8C8",rn:"#E8E4F4",rb:"#3A3A6A",ra:"#FFD66B"},"hop",(P,g)=>fShadow(40,104)+
 `<path d="M26 148 V128 Q26 124 30 124 H38 Q42 124 42 128 V148 Z" fill="#F4ECD8" ${SW2}/><path d="M34 124 V118" stroke="${FI}" stroke-width="1.6"/><path d="M34 106 Q39 113 34 120 Q29 113 34 106 Z" fill="#FFB43A" stroke="#C86A1A" stroke-width="1"/><circle cx="34" cy="114" r="14" fill="#FFE6A0" opacity=".22"/>`+
 pt("legB",128,136,`<path d="M120 128 Q140 128 146 144 L126 146 Z" fill="${P.n}" ${SW2}/>`,.2)+
 `<path d="M80 140 Q72 112 92 98 Q114 88 132 102 Q144 118 134 140 Q116 148 96 146 Q84 146 80 140 Z" fill="${P.n}" ${SW}/>`+
 /* where the shadow-hands would join at the wrist, the outline goes knuckly, as if it was made of fingers */
 `<path d="M94 104 q4 -4 8 0 q4 -4 8 0 q4 -4 8 0" stroke="${P.nl}" stroke-width="1.8" fill="none" opacity=".6"/><path d="M84 132 q-4 4 0 8 M136 126 q4 4 0 8" stroke="${P.nl}" stroke-width="1.6" fill="none" opacity=".5"/>`+
 pt("tail",140,118,`<circle cx="142" cy="118" r="7" fill="${P.nd}" ${SW2}/>`)+
 pt("legF",88,136,`<path d="M84 128 Q76 140 70 144 L86 146 Q92 140 94 132 Z" fill="${P.n}" ${SW2}/>`)+
 pt("head",84,94,`<path d="M100 98 Q98 80 82 78 Q66 80 60 90 Q56 98 62 104 Q76 108 100 98 Z" fill="${P.n}" ${SW}/>`+
  pt("ear",86,78,`<path d="M84 80 Q76 46 84 26 Q94 46 92 80 Z" fill="${P.n}" ${SW2}/><path d="M86 72 Q82 50 85 36" stroke="${P.nl}" stroke-width="1.6" fill="none" opacity=".6"/>`)+
  pt("ear",94,80,`<path d="M92 82 Q96 50 108 34 Q110 56 100 84 Z" fill="${P.nd}" ${SW2}/>`,.3)+
  `<circle cx="72" cy="88" r="3.2" fill="#F4E8C8"/><circle cx="72" cy="88" r="1.3" fill="#1A1A1A"/><path d="M60 92 l-6 -2 M60 95 l-6 1" stroke="${P.nl}" stroke-width="1"/>`+
  pt("jaw",64,100,`<path d="M58 98 Q64 106 72 100 Z" fill="${FMOUTH}"/>`))+
 fG(g,1,`<path d="M150 40 q6 -8 12 0 q6 8 12 0" stroke="#4A4458" stroke-width="2" fill="none"/>`)+fG(g,2,`<circle cx="108" cy="124" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,60,6)));
FORM_TITLE["Handshadow"]="Shadow-Puppet Hare";SM("Handshadow","One Hare Too Many","CUR","s",0,100,"tacc-1,tspd-1@40","Count the hands. Count the hares on the wall. Count them again.");
