/* ---- Rustvein Mine, 13 ---- */

/* Stapleproof Metal: never file it near the stapler. Nobody remembers what happened to the stapler. A weasel bent out of one long paperclip wire. */
addForm("Stapleproof Metal",{n:"#C8C8D4",a:"#E8604A",rn:"#3A3A4A",rb:"#7AB8E8",ra:"#F2C94C"},"slink",(P,g)=>fShadow(72)+
 pt("tail",160,100,`<path d="M156 102 Q176 100 182 84 Q186 72 176 70 Q168 72 172 80" stroke="${FI}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M156 102 Q176 100 182 84 Q186 72 176 70 Q168 72 172 80" stroke="${P.n}" stroke-width="4" fill="none" stroke-linecap="round"/>`)+
 [[146,"legB",.5],[118,"legB",1.3]].map(([x,c,d])=>pt(c,x,110,`<path d="M${x} 108 L${x+4} 124 L${x-2} 140 H${x+8}" stroke="${FI}" stroke-width="6" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M${x} 108 L${x+4} 124 L${x-2} 140 H${x+8}" stroke="${P.nd}" stroke-width="3" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,d)).join("")+
 `<path d="M70 96 Q70 86 82 86 H150 Q160 86 160 96 Q160 106 150 106 H90 Q80 106 80 98 Q80 92 88 92 H142 Q150 92 150 98 Q150 102 144 102 H96" stroke="${FI}" stroke-width="9" fill="none" stroke-linecap="round"/><path d="M70 96 Q70 86 82 86 H150 Q160 86 160 96 Q160 106 150 106 H90 Q80 106 80 98 Q80 92 88 92 H142 Q150 92 150 98 Q150 102 144 102 H96" stroke="${P.n}" stroke-width="5.6" fill="none" stroke-linecap="round"/><path d="M84 88 H146" stroke="#fff" stroke-width="1.6" opacity=".7"/>`+
 [[136,"legF",0],[92,"legF",.8]].map(([x,c,d])=>pt(c,x,110,`<path d="M${x} 106 L${x-4} 124 L${x+2} 140 H${x-8}" stroke="${FI}" stroke-width="6" fill="none" stroke-linejoin="round" stroke-linecap="round"/><path d="M${x} 106 L${x-4} 124 L${x+2} 140 H${x-8}" stroke="${P.n}" stroke-width="3" fill="none" stroke-linejoin="round" stroke-linecap="round"/>`,d)).join("")+
 pt("head",70,92,`<path d="M72 96 Q60 90 56 80" stroke="${FI}" stroke-width="9" stroke-linecap="round"/><path d="M72 96 Q60 90 56 80" stroke="${P.n}" stroke-width="5.6" stroke-linecap="round"/><path d="M28 78 Q30 64 48 62 Q64 64 66 76 Q62 86 46 86 Z" fill="${P.n}" ${SW}/><circle cx="28" cy="77" r="2.6" fill="${FI}"/>${E2(48,72,3.6,"#1A1A1A")}`+
  `<path d="M30 80 L44 82 L42 86 L32 84 Z" fill="${FMOUTH}"/>`+pt("jaw",42,85,`<path d="M44 84 Q36 90 30 84 Q36 87 44 87 Z" fill="${P.nd}" ${SW2}/>`)+pt("ear",58,64,`<circle cx="58" cy="64" r="5" fill="none" stroke="${FI}" stroke-width="5"/><circle cx="58" cy="64" r="5" fill="none" stroke="${P.n}" stroke-width="2.4"/>`))+
 fG(g,1,`<path d="M24 136 h20 M24 132 h20" stroke="${P.ac}" stroke-width="3"/><text x="22" y="126" font-size="7" font-weight="bold" fill="${P.ac}">NO!</text>`)+fG(g,2,`<circle cx="118" cy="96" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(120,50,6)));
FORM_TITLE["Stapleproof Metal"]="Paperclip Weasel";SM("Stapleproof Metal","Clip Together","RES","a",55,100,"tspd-1@50","Bend it round twice and it holds anything.");

/* Stuck Lift Special: open an umbrella in its room and the lift sticks between floors. A bat that is also an umbrella, ribs and all. */
addForm("Stuck Lift Special",{n:"#3A3A4A",a:"#C8302A",rn:"#E8D8C8",rb:"#5A8A4A",ra:"#5FE0F0"},"hover",(P,g)=>`<ellipse class="shd" cx="104" cy="148" rx="30" ry="3" fill="#000" opacity=".1"/>`+
 pt("tail",104,92,`<path d="M104 92 V128 Q104 138 96 138 Q90 138 90 132" stroke="${FI}" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M104 92 V128 Q104 138 96 138 Q90 138 90 132" stroke="#8A5A2A" stroke-width="3.4" fill="none" stroke-linecap="round"/>`)+
 pt("wingB",116,60,`<path d="M104 40 Q150 36 176 70 Q164 66 156 74 Q146 66 136 74 Q126 66 116 72 Z" fill="${P.nd}" ${SW}/>${[0,1,2].map(i=>`<path d="M104 42 L${136+i*20} ${74-i*2}" stroke="${FI}" stroke-width="1.4"/>`).join("")}`,.3)+
 pt("wingF",92,60,`<path d="M104 40 Q58 36 32 70 Q44 66 52 74 Q62 66 72 74 Q82 66 92 72 Z" fill="${P.n}" ${SW}/>${[0,1,2].map(i=>`<path d="M104 42 L${72-i*20} ${74-i*2}" stroke="${FI}" stroke-width="1.4"/>`).join("")}<path d="M60 52 Q80 44 100 46" stroke="${P.ac}" stroke-width="3" fill="none" opacity=".7"/>`)+
 `<path d="M104 30 V18" stroke="${FI}" stroke-width="3"/><circle cx="104" cy="16" r="3" fill="${P.b}" ${SW2}/>`+
 pt("head",104,82,`<path d="M90 80 Q90 64 104 64 Q118 64 118 80 Q118 94 104 94 Q90 94 90 80 Z" fill="${P.n}" ${SW}/>${E2(98,78,3.4,"#E8412C")}${E2(110,78,3.4,"#E8412C")}<path d="M100 88 L108 88 L106 92 L102 92 Z" fill="${FMOUTH}"/>`+pt("jaw",104,91,`<path d="M101 90 l1 3 l1 -3 M105 90 l1 3 l1 -3" stroke="#fff" stroke-width="1.2" fill="none"/>`)+
  pt("ear",94,66,`<path d="M92 68 L88 54 L98 64 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",114,66,`<path d="M110 64 L120 54 L116 68 Z" fill="${P.n}" ${SW2}/>`,.3))+
 fG(g,1,`<rect x="160" y="100" width="28" height="40" fill="#C8C8D0" ${SW2}/><path d="M174 100 V140" stroke="${FI}" stroke-width="1.6"/><text x="166" y="96" font-size="8" font-weight="bold" fill="${P.ac}">2½</text>`)+fG(g,2,`<circle cx="104" cy="50" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(40,110,6)));
FORM_TITLE["Stuck Lift Special"]="Umbrella Bat";SM("Stuck Lift Special","Between Floors","RES","s",0,100,"tspd-2","Not up, not down. Just stuck. And the music keeps playing.");

/* Surplus No. 7: a slipped pen turned a 1 into a 7 and they had to make seven times the batch. A seven-headed hydra, each head a little different. */
addForm("Surplus No. 7",{n:"#5A8A6A",a:"#E8C060",rn:"#3A3A4A",rb:"#B85A3A",ra:"#5FE0F0"},"stand",(P,g)=>fShadow(66)+
 pt("tail",152,118,`<path d="M148 116 Q176 118 186 134" stroke="${FI}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M148 116 Q176 118 186 134" stroke="${P.n}" stroke-width="8.6" fill="none" stroke-linecap="round"/>`)+
 fLeg("legB",138,124,20,12,P.nd,P.ndd,.5)+
 `<path d="M76 120 Q76 96 112 94 Q148 96 152 118 Q148 136 114 136 Q80 136 76 120 Z" fill="${P.n}" ${SW}/><path d="M88 128 Q112 136 140 126" stroke="${P.ac}" stroke-width="5" fill="none" opacity=".6"/>`+
 Array.from({length:7},(_,i)=>{const bx=88+i*8,a=-2.6+i*.32,len=40+(i%3)*8,hx=bx+Math.cos(a)*len*.7-6,hy=96+Math.sin(a)*len;return pt(i%2?"head":"ear",hx,hy,`<path d="M${bx} 100 Q${bx-6} ${hy+20} ${hx} ${hy}" stroke="${FI}" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M${bx} 100 Q${bx-6} ${hy+20} ${hx} ${hy}" stroke="${P.n}" stroke-width="5" fill="none" stroke-linecap="round"/><ellipse cx="${hx-4}" cy="${hy-2}" rx="9" ry="6.4" fill="${P.n}" ${SW}/><circle cx="${hx-4}" cy="${hy-5}" r="2.4" fill="#fff" ${SW2}/><circle cx="${hx-4.6}" cy="${hy-5}" r="1.2" fill="${FI}"/><path d="M${hx-13} ${hy} L${hx-4} ${hy+1}" stroke="${FMOUTH}" stroke-width="${i%2?2.6:1.4}"/>${i===3?`<path d="M${hx-2} ${hy-8} l2 -6 l2 6" fill="${P.ac}" ${SW2}/>`:""}`,i*.13)}).join("")+
 fLeg("legF",122,126,18,12,P.n,P.ndd,0)+fLeg("legF",90,126,18,12,P.n,P.ndd,.8)+
 fG(g,1,`<text x="160" y="50" font-size="22" font-weight="bold" fill="${P.ac}" font-family="Georgia,serif">×7</text>`)+fG(g,2,`<circle cx="114" cy="118" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(170,90,6)));
FORM_TITLE["Surplus No. 7"]="Seven-Headed Hydra";SM("Surplus No. 7","Seven Times Over","STR","a",15,90,"multi:7-7","One became seven. Every one of them bites.");



/* Tappium: a bus timetable lists one extra service, marked with a little crate. A capybara waiting patiently at the bus stop. */
addForm("Tappium",{n:"#9A6A40",a:"#E8C080",rn:"#3A3A4A",rb:"#5A8AC8",ra:"#E8412C"},"stand",(P,g)=>`<path d="M174 146 V30" stroke="${FI}" stroke-width="4"/><circle cx="174" cy="30" r="12" fill="#C8302A" ${SW}/><text x="168" y="34" font-size="10" font-weight="bold" fill="#fff">B</text><rect x="164" y="58" width="22" height="30" fill="#F4F0E4" ${SW2}/>${[64,70,76].map(y=>`<path d="M167 ${y} h16" stroke="#8A8A9A" stroke-width="1"/>`).join("")}<rect x="167" y="80" width="6" height="5" fill="#B88A50"/>`+fShadow(76)+
 fLeg("legB",142,120,20,10,P.nd,P.ndd,.5)+fLeg("legB",108,122,18,10,P.nd,P.ndd,1.3)+
 `<path d="M74 114 Q72 80 112 78 Q154 80 156 112 Q152 132 114 132 Q78 132 74 114 Z" fill="${P.n}" ${SW}/>`+
 fLeg("legF",132,122,18,10,P.n,P.ndd,0)+fLeg("legF",88,122,18,10,P.n,P.ndd,.8)+
 pt("head",84,94,`<path d="M42 96 Q42 76 64 74 Q88 76 90 94 Q86 112 64 112 L46 108 Z" fill="${P.n}" ${SW}/><path d="M42 92 Q38 98 42 106 L48 106 Q46 98 48 92 Z" fill="${P.nd}" ${SW2}/><ellipse cx="44" cy="94" rx="2.4" ry="1.6" fill="${FI}"/>${E2(64,86,3.4,"#2A2A2A",[0,.4])}<path d="M58 84 h12" stroke="${FI}" stroke-width="1.8"/>`+HMOUTH(44,104,52,P,2.4)+
  pt("ear",78,76,`<ellipse cx="80" cy="76" rx="5" ry="4" fill="${P.nd}" ${SW2}/>`)+`<path d="M60 74 Q60 62 72 64" stroke="#5AB04A" stroke-width="2.4" fill="none"/><ellipse cx="74" cy="64" rx="5" ry="2.6" fill="#5AB04A"/>`)+
 fG(g,1,`<rect x="20" y="130" width="20" height="12" rx="2" fill="#F4F0E4" ${SW2}/><text x="22" y="139" font-size="7" font-weight="bold" fill="${FI}">TKT</text>`)+fG(g,2,`<circle cx="114" cy="104" r="3" fill="${P.ll}" ${SW2}/>`)+fG(g,3,star(110,40,6)));
FORM_TITLE["Tappium"]="Bus-Stop Capybara";SM("Tappium","Extra Service","RES","s",0,100,"spd+1,heal:20","There's always one more bus, if you wait long enough.");


/* Token Metal: bazaar trade tokens bear the same small stamp as its crates. A cobra whose spread hood is stamped like one of those tokens. */
addForm("Token Metal",{n:"#B89040",a:"#3A3A4A",rn:"#E8D8C8",rb:"#3A6A8A",ra:"#E8412C"},"slink",(P,g)=>fShadow(66)+
 pt("tail",148,132,`<path d="M100 136 Q140 140 168 130 Q186 122 176 114" stroke="${FI}" stroke-width="11" fill="none" stroke-linecap="round"/><path d="M100 136 Q140 140 168 130 Q186 122 176 114" stroke="${P.n}" stroke-width="7.6" fill="none" stroke-linecap="round"/>`)+
 `<path d="M60 134 Q60 118 90 118 Q130 120 124 136 Q100 144 60 134 Z" fill="${P.n}" ${SW}/>`+
 pt("sway",96,90,`<path d="M100 120 Q96 100 98 80" stroke="${FI}" stroke-width="16" fill="none"/><path d="M100 120 Q96 100 98 80" stroke="${P.n}" stroke-width="12.6" fill="none"/><path d="M98 34 Q132 40 128 76 Q120 96 98 100 Q76 96 68 76 Q64 40 98 34 Z" fill="${P.n}" ${SW}/><circle cx="98" cy="70" r="16" fill="${P.b}" ${SW2}/><circle cx="98" cy="70" r="12" fill="none" stroke="${P.d}" stroke-width="1.6"/><path d="M90 66 l8 -6 l8 6 l-4 10 h-8 Z" fill="none" stroke="${P.dd}" stroke-width="2"/>`)+
 pt("head",98,36,`<path d="M84 34 Q84 18 98 18 Q112 18 112 34 Q108 44 98 44 Q88 44 84 34 Z" fill="${P.n}" ${SW}/>${E2(92,30,3.2,"#E8A020",[0,.2])}${E2(104,30,3.2,"#E8A020",[0,.2])}`+pt("jaw",98,42,`<path d="M92 40 Q98 48 104 40 Z" fill="${FMOUTH}" ${SW2}/>`)+pt("tongue",98,44,`<path d="M98 44 V54 l-3 4 M98 54 l3 4" stroke="${FTONGUE}" stroke-width="2" fill="none"/>`))+
 fG(g,1,`${[[28,130],[40,136],[34,122]].map(([x,y])=>`<circle cx="${x}" cy="${y}" r="5" fill="${P.b}" ${SW2}/>`).join("")}`)+fG(g,2,`<circle cx="98" cy="70" r="2.4" fill="${P.ll}"/>`)+fG(g,3,star(160,40,6)));
FORM_TITLE["Token Metal"]="Token-Hooded Cobra";SM("Token Metal","Stamped Strike","SCR","a",70,100,"tdef-1@30","The mark matches. Nobody knows which came first.");

/* Tollbridgite: three look-alike projects; its student skipped judging and still came second. The troll who lives under the toll bridge, collecting fares. */
addForm("Tollbridgite",{n:"#7A8A5A",a:"#E8C060",rn:"#3A3A4A",rb:"#B8A0D0",ra:"#E8412C"},"stand",(P,g)=>`<path d="M14 40 Q104 0 194 40 V52 Q104 14 14 52 Z" fill="#9A9AA0" ${SW}/>${[40,80,120,160].map(x=>`<path d="M${x} ${44-Math.sin((x-14)/180*3.14)*24} v8" stroke="#6A6A74" stroke-width="2"/>`).join("")}`+fShadow(66)+
 pt("legB",122,130,fOL("M120 126 L126 142 H138",P.nd,10),.5)+
 `<path d="M76 128 Q68 84 104 76 Q140 84 134 128 Q126 142 104 142 Q84 142 76 128 Z" fill="${P.n}" ${SW}/><path d="M86 112 Q104 124 124 112 L124 136 Q104 142 86 136 Z" fill="#6A4A2A" ${SW2}/>${[0,1,2].map(i=>`<circle cx="${96+i*8}" cy="${100+i%2*6}" r="2.4" fill="${P.nd}"/>`).join("")}`+
 pt("legF",88,130,fOL("M90 126 L84 142 H72",P.n,10))+
 pt("armB",128,98,fOL("M128 98 Q146 106 146 124",P.nd,10),.4)+
 pt("armF",80,98,fOL("M82 98 Q62 104 56 92",P.n,10)+`<path d="M44 74 h24 v18 h-24 Z" fill="#F4F0E4" ${SW2}/><text x="47" y="86" font-size="8" font-weight="bold" fill="${FI}">2nd</text><circle cx="56" cy="96" r="5" fill="${P.ac}" ${SW2}/>`)+
 pt("head",104,72,`<path d="M80 74 Q78 50 104 48 Q130 50 128 74 Q124 92 104 92 Q84 92 80 74 Z" fill="${P.n}" ${SW}/><path d="M98 70 Q94 82 104 84 Q114 82 108 70 Z" fill="${P.nd}" ${SW2}/>${E2(94,66,3.8,"#E8A020")}${E2(114,66,3.8,"#E8A020")}<path d="M88 58 l10 4 M120 58 l-10 4" stroke="${FI}" stroke-width="2.4"/>`+
  `<path d="M92 86 L116 86 L114 90 L94 90 Z" fill="${FMOUTH}"/>`+pt("jaw",104,90,`<path d="M92 88 Q104 98 116 88 L114 92 Q104 98 94 92 Z" fill="${P.nd}" ${SW2}/><path d="M96 88 l2 -5 l2 5 M108 88 l2 -5 l2 5" fill="#F4F0E4" ${SW2}/>`)+
  pt("ear",80,66,`<path d="M80 66 L64 58 L78 74 Z" fill="${P.n}" ${SW2}/>`)+pt("ear",128,66,`<path d="M128 66 L144 58 L130 74 Z" fill="${P.n}" ${SW2}/>`,.3)+`<path d="M90 50 Q96 40 104 46 Q110 38 118 48" stroke="${P.nd}" stroke-width="3" fill="none"/>`)+
 fG(g,1,`<path d="M160 120 l8 8 l8 -8 l-8 -8 Z" fill="${P.ac}" ${SW2}/>`)+fG(g,2,`<circle cx="104" cy="108" r="3" fill="${P.ac}" ${SW2}/>`)+fG(g,3,star(160,70,6)));
FORM_TITLE["Tollbridgite"]="Toll-Bridge Troll";SM("Tollbridgite","Pay The Toll","RES","a",65,100,"drain:30","Nobody crosses without paying something.");
