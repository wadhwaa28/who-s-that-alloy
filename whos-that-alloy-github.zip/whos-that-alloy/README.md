# Who's That Alloy?

Open `index.html` in a browser, or serve this folder (GitHub Pages works as-is).

- `index.html`: the page markup, and the list of stylesheets and scripts in the order they load.
- `css/`: `base.css` plus one stylesheet per add-on.
- `js/core/`: the original game, split at its section headers.
- `js/mods/`: add-ons, one file each, loaded after the core. Later files wrap or replace functions from earlier ones, so **load order matters**: keep it as `index.html` lists it.
- `js/boot.js`: starts the game, and must load last.

All scripts are ordinary (non-module) scripts sharing one global scope.
